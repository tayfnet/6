(()=>{
  /*
   * TAIF Sales & Purchase workspace module.
   * Owns the live board/workspace renderer, modal windows, flow navigation,
   * execution/reverse/delete operations, and UI synchronization.
   */
  const TAIF = window.TAIF;
  const feature = TAIF.salesPurchaseFeature || (TAIF.salesPurchaseFeature = {});
  const {
    escapeHtml,
    focusElementWithoutScroll,
    wrapControlTextMarkup,
    stopEventPropagation,
    runCleanupCallbacks
  } = TAIF.core.utils;
  const windowChrome = TAIF.ui.windowChrome || {};
  const flowSystem = TAIF.ui.flow || {};
  const {
    runtime,
    ACTIONS,
    SALES_PURCHASE_RECORD_COLUMNS,
    SALES_PURCHASE_PARTY_PHONE_COUNTRY_FIELD_KEY,
    SALES_PURCHASE_NAV_ICON_MARKUP,
    DELETE_ICON_MARKUP,
    SALES_PURCHASE_UPDATED_EVENT,
    SALES_PURCHASE_BALANCE_EPSILON,
    DATE_PICKER_WEEKDAY_LABELS,
    DATE_PICKER_ICON_MARKUP,
    DATE_PICKER_CHEVRON_PREV_MARKUP,
    DATE_PICKER_CHEVRON_NEXT_MARKUP,
    getWindowIcon,
    getChevronDownIcon,
    getTrackArrowIcon,
    renderSalesPurchasePartyAvatarMarkup,
    getSalesPurchasePartyCustomerApi,
    renderSalesPurchasePartyWindow,
    ensureSalesPurchasePartyState,
    resolveSalesPurchasePartyDateMonthCursor,
    normalizeSalesPurchasePageLookup,
    syncSalesPurchasePartyLinkedName,
    isSalesPurchasePartyEntry,
    resolveSalesPurchaseWindowAction,
    resolveSalesPurchaseWindowInstanceId,
    syncSalesPurchaseAttachedOwnerBlocker,
    getSalesPurchaseAttachedPartyOwner,
    snapshotSalesPurchaseWindowPosition,
    withSalesPurchaseAttachmentSync,
    setSalesPurchaseOwnerInteractionLocked,
    releaseSalesPurchasePartyAttachment,
    syncSalesPurchasePartyAttachment,
    handleSalesPurchaseModalPositionApplied,
    handleSalesPurchaseAttachedOwnerHeadInteraction,
    syncSalesPurchaseAttachedExpandButtons,
    clearSalesPurchaseAttachedPartyMaximizedState,
    applySalesPurchaseAttachedPartyMaximizedFrame,
    syncSalesPurchaseAttachedMaximizedPair,
    syncExpandButton,
    createChoicePickerIcon,
    toSafeText,
    ensureSalesPurchaseNavigatorState,
    snapshotSalesPurchaseBaselineFormState,
    resolveSalesPurchaseEffectiveActionId,
    getSalesPurchaseNavigatorRecords,
    resolveSalesPurchaseNavigatorActiveIndex,
    resolveSalesPurchaseNavigatorLinkedRecord,
    isSalesPurchaseEditingExistingRecord,
    buildSalesPurchaseFormStateFromRecord,
    readAccountCatalog,
    findAccountByNo,
    resolveDefaultCashAccount,
    readEntriesStateForSalesPurchase,
    buildSalesPurchaseAccountingSourceFromModel,
    buildSalesPurchaseAccountingIssues,
    appendSalesPurchaseAccountingEntriesFromSource,
    deleteSalesPurchaseLinkedEntryRecords,
    buildEntriesStateExcludingSalesPurchaseRecord,
    buildEntriesStateWithReversedSalesPurchaseRecord,
    hasPersistedSalesPurchaseEntryRecord,
    writeEntriesStateForSalesPurchase,
    upsertSalesPurchaseAccountingEntriesForRecord,
    invertSalesPurchaseCashDeltaMap,
    buildSalesPurchaseCashDeltaMapFromRecord,
    applySalesPurchaseCashDeltaMap,
    hasSalesPurchaseRecordChanged,
    createUpdatedSalesPurchaseRecord,
    repairSalesPurchaseAccountingLinks,
    salesPurchaseTodayInputValue,
    salesPurchaseParseIsoDate,
    normalizeSalesPurchaseRecordDateFilterValue,
    normalizeSalesPurchaseRecordDateFilterRange,
    salesPurchaseNormalizeDateInputValue,
    salesPurchaseNormalizeDatePickerView,
    salesPurchaseResolveMonthCursor,
    salesPurchaseShiftMonthCursor,
    salesPurchaseFormatMonthLabel,
    salesPurchaseBuildDateCells,
    salesPurchaseBuildMonthChoices,
    renderSalesPurchaseCashAccountField,
    renderSalesPurchaseDateField,
    salesPurchaseTypeLabel,
    isSalesPurchaseRecordReversed,
    normalizeSalesPurchaseRecord,
    readSalesPurchaseState,
    writeSalesPurchaseState,
    buildSalesPurchaseRecordNumber,
    appendSalesPurchaseRecord,
    filterSalesPurchaseRecords,
    fallbackCurrencyOption,
    getCurrencySnapshot,
    pickCurrencyCode,
    resolveCurrencyFromList,
    resolveDistinctPairCodes,
    buildFallbackOperationalQuote,
    createDefaultFormState,
    normalizeCurrencyCode,
    normalizeSalesPurchaseEditedAmountField,
    sanitizeNumericInput,
    toNumber,
    formatNumericValue
  } = feature;

  const INLINE_PURCHASE_WORKSPACE_ENTRY_ID = 'inline-purchase-workspace';
  const INLINE_SALES_PURCHASE_ACTION_IDS = new Set(['purchase', 'sale']);
  const SALES_PURCHASE_PURCHASE_VIEW_ID = 'sales-purchase-invoice';
  const SALES_PURCHASE_SALE_VIEW_ID = 'sales-purchase-sale';
  const SALES_PURCHASE_RECORDS_DEFAULT_PAGE_SIZE = 10;
  const SALES_PURCHASE_RECORDS_PAGE_SIZE_OPTIONS = Object.freeze([10, 20, 50]);
  const SALES_PURCHASE_RECORDS_ALL_PAGE_SIZE = 'all';

  function normalizeInlineSalesPurchaseActionId(value){
    return String(value || '').trim() === 'sale' ? 'sale' : 'purchase';
  }

  function resolveSalesPurchaseActionIdForCurrentView(panel = runtime.panel){
    const panelViewId = panel instanceof HTMLElement ? String(panel.dataset.view || '').trim() : '';
    const bodyViewId = typeof document !== 'undefined' ? String(document.body?.dataset?.activeView || '').trim() : '';
    const rootViewId = typeof document !== 'undefined' ? String(document.documentElement?.dataset?.activeView || '').trim() : '';
    const currentViewId = panelViewId || bodyViewId || rootViewId;
    return currentViewId === SALES_PURCHASE_SALE_VIEW_ID ? 'sale' : 'purchase';
  }

  function resolveSalesPurchaseOwnerViewId(panel = runtime.panel){
    return resolveSalesPurchaseActionIdForCurrentView(panel) === 'sale'
      ? SALES_PURCHASE_SALE_VIEW_ID
      : SALES_PURCHASE_PURCHASE_VIEW_ID;
  }

  function getSalesPurchaseActionTitle(actionId){
    return normalizeInlineSalesPurchaseActionId(actionId) === 'sale' ? 'فاتورة مبيع' : 'فاتورة شراء';
  }

  function normalizeSalesPurchaseRecordsPageSize(value){
    if(String(value || '').trim().toLowerCase() === SALES_PURCHASE_RECORDS_ALL_PAGE_SIZE) return SALES_PURCHASE_RECORDS_ALL_PAGE_SIZE;
    const numericValue = Math.floor(Number(value));
    return SALES_PURCHASE_RECORDS_PAGE_SIZE_OPTIONS.includes(numericValue)
      ? numericValue
      : SALES_PURCHASE_RECORDS_DEFAULT_PAGE_SIZE;
  }

  function getSalesPurchaseRecordsPageSize(){
    const pageSize = normalizeSalesPurchaseRecordsPageSize(runtime.salesPurchaseRecordsPageSize);
    runtime.salesPurchaseRecordsPageSize = pageSize;
    return pageSize;
  }

  function getSalesPurchaseRecordsPageIndex(){
    const numericValue = Math.floor(Number(runtime.salesPurchaseRecordsPageIndex));
    const pageIndex = Number.isFinite(numericValue) && numericValue >= 0 ? numericValue : 0;
    runtime.salesPurchaseRecordsPageIndex = pageIndex;
    return pageIndex;
  }

  function resetSalesPurchaseRecordsPagination({ resetPageSize = false } = {}){
    if(resetPageSize) runtime.salesPurchaseRecordsPageSize = SALES_PURCHASE_RECORDS_DEFAULT_PAGE_SIZE;
    runtime.salesPurchaseRecordsPageIndex = 0;
  }

  function resolveSalesPurchaseRecordsPagination(records = []){
    const safeRecords = Array.isArray(records) ? records : [];
    const totalCount = safeRecords.length;
    const pageSize = getSalesPurchaseRecordsPageSize();
    if(pageSize === SALES_PURCHASE_RECORDS_ALL_PAGE_SIZE){
      runtime.salesPurchaseRecordsPageIndex = 0;
      return {
        records: safeRecords,
        pageSize,
        pageIndex: 0,
        totalPages: 1,
        totalCount,
        startIndex: totalCount ? 0 : -1,
        endIndex: totalCount,
        canPrev: false,
        canNext: false
      };
    }
    const safePageSize = Math.max(1, Number(pageSize) || SALES_PURCHASE_RECORDS_DEFAULT_PAGE_SIZE);
    const totalPages = Math.max(1, Math.ceil(totalCount / safePageSize));
    const pageIndex = Math.max(0, Math.min(totalPages - 1, getSalesPurchaseRecordsPageIndex()));
    runtime.salesPurchaseRecordsPageIndex = pageIndex;
    const startIndex = totalCount ? pageIndex * safePageSize : -1;
    const endIndex = totalCount ? Math.min(totalCount, startIndex + safePageSize) : 0;
    return {
      records: totalCount ? safeRecords.slice(startIndex, endIndex) : [],
      pageSize: safePageSize,
      pageIndex,
      totalPages,
      totalCount,
      startIndex,
      endIndex,
      canPrev: totalCount > 0 && pageIndex > 0,
      canNext: totalCount > 0 && pageIndex < totalPages - 1
    };
  }

  function resolveSalesPurchaseRecordsForPaginationSource(records, query = runtime.searchQuery, panel = runtime.panel){
    const scopedRecords = filterSalesPurchaseRecordsForCurrentView(records, panel);
    const searchedRecords = filterSalesPurchaseRecords(scopedRecords, query);
    return filterSalesPurchaseRecordsByDate(searchedRecords);
  }

  function moveSalesPurchaseRecordsPage(direction = '', panel = runtime.panel){
    const safeDirection = String(direction || '').trim();
    const state = readSalesPurchaseState();
    const filteredRecords = resolveSalesPurchaseRecordsForPaginationSource(state.records, runtime.searchQuery, panel);
    const pageState = resolveSalesPurchaseRecordsPagination(filteredRecords);
    let nextPageIndex = pageState.pageIndex;
    if(safeDirection === 'first') nextPageIndex = 0;
    else if(safeDirection === 'prev') nextPageIndex = pageState.pageIndex - 1;
    else if(safeDirection === 'next') nextPageIndex = pageState.pageIndex + 1;
    else if(safeDirection === 'last') nextPageIndex = pageState.totalPages - 1;
    nextPageIndex = Math.max(0, Math.min(Math.max(1, pageState.totalPages) - 1, nextPageIndex));
    if(nextPageIndex === pageState.pageIndex) return false;
    runtime.salesPurchaseRecordsPageIndex = nextPageIndex;
    runtime.selectedRecordId = '';
    refreshWorkbenchUi(panel);
    return true;
  }

  function setSalesPurchaseRecordsPageSize(value, panel = runtime.panel){
    const nextPageSize = normalizeSalesPurchaseRecordsPageSize(value);
    if(runtime.salesPurchaseRecordsPageSize === nextPageSize && getSalesPurchaseRecordsPageIndex() === 0) return false;
    runtime.salesPurchaseRecordsPageSize = nextPageSize;
    runtime.salesPurchaseRecordsPageIndex = 0;
    runtime.selectedRecordId = '';
    refreshWorkbenchUi(panel);
    return true;
  }

  function getInlineSalesPurchaseAction(actionId){
    return ACTIONS[normalizeInlineSalesPurchaseActionId(actionId)] || ACTIONS.purchase;
  }

  function getInlineSalesPurchaseDraftStore(){
    if(!runtime.inlineSalesPurchaseDrafts || typeof runtime.inlineSalesPurchaseDrafts !== 'object'){
      runtime.inlineSalesPurchaseDrafts = Object.create(null);
    }
    return runtime.inlineSalesPurchaseDrafts;
  }

  function getSalesPurchaseRealTodayValue(){
    return salesPurchaseNormalizeDateInputValue(salesPurchaseTodayInputValue());
  }

  function resetSalesPurchaseRecordDateFiltersToToday(){
    const todayValue = getSalesPurchaseRealTodayValue();
    runtime.recordDateFilterFrom = todayValue;
    runtime.recordDateFilterTo = todayValue;
    runtime.recordDateFilterDraftFrom = todayValue;
    runtime.recordDateFilterDraftTo = todayValue;
    runtime.recordDateFilterPickerKey = '';
    runtime.recordDateFilterPickerView = 'days';
    runtime.recordDateFilterPickerMonthCursor = todayValue.slice(0, 7);
    runtime.recordDateFilterAutoDefaultDate = todayValue;
  }

  function resetSalesPurchaseFormDateToTodayIfBlankDraft(formState, todayValue = getSalesPurchaseRealTodayValue()){
    if(!formState || typeof formState !== 'object') return false;
    const navigator = formState.navigator && typeof formState.navigator === 'object' ? formState.navigator : null;
    const hasLoadedRecord = !!toSafeText(navigator?.currentRecordId)
      || Number.isInteger(navigator?.currentRecordIndex)
      || !!(navigator && navigator.loadedRecordSnapshot && typeof navigator.loadedRecordSnapshot === 'object');
    if(hasLoadedRecord) return false;

    formState.voucherDate = todayValue;
    formState.datePickerOpen = false;
    formState.datePickerView = 'days';
    formState.datePickerMonthCursor = salesPurchaseResolveMonthCursor(todayValue, todayValue.slice(0, 7));
    return true;
  }

  function resetInlineSalesPurchaseDateDefaultsToToday(actionId = ''){
    const todayValue = getSalesPurchaseRealTodayValue();
    const activeActionId = actionId ? normalizeInlineSalesPurchaseActionId(actionId) : '';
    const actionIds = activeActionId ? [activeActionId] : Array.from(INLINE_SALES_PURCHASE_ACTION_IDS);
    const store = getInlineSalesPurchaseDraftStore();

    actionIds.forEach((safeActionId) => {
      const draft = store[safeActionId];
      if(draft && typeof draft === 'object'){
        resetSalesPurchaseFormDateToTodayIfBlankDraft(draft.formState, todayValue);
        resetSalesPurchaseFormDateToTodayIfBlankDraft(draft.navigatorBaselineFormState, todayValue);
      }
    });

    const entry = runtime.inlinePurchaseWorkspaceEntry;
    if(entry && entry.formState && (!activeActionId || normalizeInlineSalesPurchaseActionId(entry.action?.id) === activeActionId)){
      resetSalesPurchaseFormDateToTodayIfBlankDraft(entry.formState, todayValue);
      resetSalesPurchaseFormDateToTodayIfBlankDraft(entry.navigatorBaselineFormState, todayValue);
    }
  }

  function rememberInlineSalesPurchaseDraft(entry){
    if(!entry || !entry.formState || !entry.action) return;
    const actionId = normalizeInlineSalesPurchaseActionId(entry.action.id);
    const store = getInlineSalesPurchaseDraftStore();
    store[actionId] = {
      formState: entry.formState,
      navigatorBaselineFormState: entry.navigatorBaselineFormState || snapshotSalesPurchaseBaselineFormState(entry.formState, actionId)
    };
  }

  function createInlineSalesPurchaseFormState(actionId, sourceFormState = null){
    const safeActionId = normalizeInlineSalesPurchaseActionId(actionId);
    const nextState = createDefaultFormState(safeActionId);
    if(sourceFormState && typeof sourceFormState === 'object'){
      if(toSafeText(sourceFormState.cashAccountNo)) nextState.cashAccountNo = toSafeText(sourceFormState.cashAccountNo);
      const sourceDate = salesPurchaseNormalizeDateInputValue(sourceFormState.voucherDate);
      if(sourceDate) nextState.voucherDate = sourceDate;
      nextState.rateMode = String(sourceFormState.rateMode || 'auto').trim() === 'manual' ? 'manual' : 'auto';
      nextState.purchaseCalcMethod = normalizeSalesPurchaseWorkspaceCalcMethod(sourceFormState.purchaseCalcMethod);
    }
    nextState.windowActionId = safeActionId;
    nextState.openPickerKey = null;
    nextState.datePickerOpen = false;
    nextState.datePickerView = 'days';
    nextState.alertIssues = [];
    return nextState;
  }

  function resolveInlineSalesPurchaseDraft(actionId, sourceFormState = null){
    const safeActionId = normalizeInlineSalesPurchaseActionId(actionId);
    const store = getInlineSalesPurchaseDraftStore();
    const draft = store[safeActionId];
    if(draft && draft.formState && typeof draft.formState === 'object'){
      draft.formState.windowActionId = safeActionId;
      return {
        formState: draft.formState,
        navigatorBaselineFormState: draft.navigatorBaselineFormState || snapshotSalesPurchaseBaselineFormState(draft.formState, safeActionId)
      };
    }
    const formState = createInlineSalesPurchaseFormState(safeActionId, sourceFormState);
    const nextDraft = {
      formState,
      navigatorBaselineFormState: snapshotSalesPurchaseBaselineFormState(formState, safeActionId)
    };
    store[safeActionId] = nextDraft;
    return nextDraft;
  }

  function warnSalesPurchaseRecovery(message, error = null){
    if(typeof console !== 'undefined' && typeof console.warn === 'function'){
      console.warn(`[sales-purchase] ${message}`, error || '');
    }
  }

  function restoreSalesPurchaseAccountingStateSnapshot(previousEntriesState, context = ''){
    if(!previousEntriesState || typeof previousEntriesState !== 'object') return false;
    try{
      writeEntriesStateForSalesPurchase(previousEntriesState, { syncCashBoxes: true });
      return true;
    }catch(error){
      const contextSuffix = context ? ` (${context})` : '';
      warnSalesPurchaseRecovery(`تعذر التراجع عن القيود المحاسبية${contextSuffix}.`, error);
      return false;
    }
  }


  function renderSalesPurchaseRecordCell({ className = '', valueMarkup = '' }){
    return `<div class="entries-record-cell sales-purchase-record-cell${className ? ` ${className}` : ''}">${valueMarkup}</div>`;
  }

  function renderSalesPurchaseRecordTextValue(text, { mono = false, center = false, clamp = false } = {}){
    const safeText = String(text || '').trim();
    const classes = [
      'entries-record-cell__value',
      'sales-purchase-record-cell__value',
      mono ? 'entries-record-cell__value--mono sales-purchase-record-cell__value--mono' : '',
      center ? 'entries-record-cell__value--center sales-purchase-record-cell__value--center' : '',
      clamp ? 'entries-record-cell__value--clamp sales-purchase-record-cell__value--clamp' : '',
      safeText ? '' : 'entries-record-cell__value--empty sales-purchase-record-cell__value--empty'
    ].filter(Boolean).join(' ');
    return `<div class="${classes}">${escapeHtml(safeText || '—')}</div>`;
  }

  function renderSalesPurchaseRecordInlinePair(primary, secondary = '', { center = false } = {}){
    const safePrimary = String(primary || '').trim();
    const safeSecondary = String(secondary || '').trim();
    if(!safePrimary && !safeSecondary) return renderSalesPurchaseRecordTextValue('—', { center });
    const visiblePrimary = safePrimary || safeSecondary || '—';
    const shouldShowSecondary = !!safeSecondary && safeSecondary !== safePrimary;
    const titleText = shouldShowSecondary ? `${visiblePrimary} ${safeSecondary}` : visiblePrimary;
    return `
      <div class="entries-record-cell__inline-pair${center ? ' entries-record-cell__inline-pair--center' : ''}" title="${escapeHtml(titleText)}">
        <span class="entries-record-cell__inline-primary">${escapeHtml(visiblePrimary)}</span>
        ${shouldShowSecondary ? `<span class="entries-record-cell__inline-code" dir="ltr">${escapeHtml(safeSecondary)}</span>` : ''}
      </div>
    `;
  }

  function formatSalesPurchaseRecordTime(timestamp){
    const rawTimestamp = Number(timestamp);
    if(!Number.isFinite(rawTimestamp) || rawTimestamp <= 0) return '';
    const date = new Date(rawTimestamp);
    if(Number.isNaN(date.getTime())) return '';
    return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
  }

  function renderSalesPurchaseRecordDateTimeValue(record){
    const safeDate = toSafeText(record?.date) || salesPurchaseTodayInputValue();
    const safeTime = formatSalesPurchaseRecordTime(record?.createdAt || record?.updatedAt);
    return renderSalesPurchaseRecordTextValue(safeTime ? `${safeDate} ${safeTime}` : safeDate, { mono: true, center: true });
  }

  function renderSalesPurchaseRecordAccountValue(record){
    return renderSalesPurchaseRecordInlinePair(record?.cashAccountName, record?.cashAccountNo);
  }

  function renderSalesPurchaseRecordCounterpartyValue(record){
    return renderSalesPurchaseRecordTextValue(record?.counterpartyName || '—', { center: true, clamp: true });
  }

  function renderSalesPurchaseRecordAmountValue(amount, currencyCode, modifier = '', displayText = ''){
    if(!(Number(amount) > 0)) return renderSalesPurchaseRecordTextValue('—', { center: true });
    const visibleAmountText = toSafeText(displayText) || formatNumericValue(amount, { rawText: displayText, mode:'standard', fallback:'0' });
    return `<div class="entries-record-cell__value entries-record-cell__value--amount entries-record-cell__value--center${modifier ? ` ${modifier}` : ''}" dir="ltr">${escapeHtml(visibleAmountText)}</div>`;
  }

  function renderSalesPurchaseRecordNotesValue(record){
    const primary = toSafeText(record?.invoiceSummary) || toSafeText(record?.notes) || '—';
    const secondaryParts = [];
    if(isSalesPurchaseRecordReversed(record)) secondaryParts.push('آخر إجراء: إلغاء / عكس القيد');
    else if(Math.max(0, Number(record?.revisionCount) || 0) > 0) secondaryParts.push(`آخر إجراء: تعديل (${Math.max(0, Number(record?.revisionCount) || 0)})`);
    const secondary = secondaryParts.join(' | ');
    return `
      <div class="entries-record-cell__stack entries-record-cell__stack--notes">
        ${renderSalesPurchaseRecordTextValue(primary, { clamp: true })}
        ${secondary ? `<div class="entries-record-cell__meta entries-record-cell__meta--clamp">${escapeHtml(secondary)}</div>` : ''}
      </div>
    `;
  }

  function renderSalesPurchaseRecordExchangeRateValue(record){
    const rateText = toSafeText(record?.rateText);
    return renderSalesPurchaseRecordTextValue(rateText && rateText !== '—' ? rateText : '—', { mono: true, center: true });
  }

  function renderSalesPurchaseRecordTypeValue(record){
    const typeTone = record?.type === 'sale' ? 'sale' : 'purchase';
    return `
      <div class="entries-record-cell__badges">
        <span class="entries-badge entries-type--${escapeHtml(typeTone)}">${escapeHtml(salesPurchaseTypeLabel(record?.type))}</span>
      </div>
    `;
  }

  function renderSalesPurchaseRecordActionsDots(){
    return `
      <span class="sales-purchase-record-actions-dots" aria-hidden="true">
        <span class="sales-purchase-record-actions-dots__dot"></span>
        <span class="sales-purchase-record-actions-dots__dot"></span>
        <span class="sales-purchase-record-actions-dots__dot"></span>
      </span>
    `;
  }

  function renderSalesPurchaseRecordSelectionDot(isSelected = false){
    return `
      <span class="entries-record-row__state-slot" aria-hidden="true">
        <span class="entries-record-row__state-dot${isSelected ? ' is-active' : ''}"></span>
      </span>
    `;
  }

  function renderSalesPurchaseRecordsHead(){
    return `
      <div class="entries-records__grid entries-records__head entries-records__head--split-scroll" role="row">
        ${SALES_PURCHASE_RECORD_COLUMNS.map((column) => `
          <div class="entries-records__head-cell ${escapeHtml(column.className)}" role="columnheader">${escapeHtml(column.label)}</div>
        `).join('')}
      </div>
    `;
  }

  function renderSalesPurchaseRecordRow(record, serialNumber = 1){
    const isSale = record?.type === 'sale';
    const recordId = toSafeText(record?.id);
    const safeSerialNumber = Math.max(1, Number(serialNumber) || 1);
    const isSelected = !!recordId && recordId === toSafeText(runtime.selectedRecordId);
    return `
      <article class="entries-record-row sales-purchase-record-row${isSelected ? ' entries-record-row--selected' : ''}" role="row" data-sales-purchase-record-id="${escapeHtml(recordId)}" aria-selected="${isSelected ? 'true' : 'false'}" aria-label="${escapeHtml(record?.number || '')}">
        <div class="entries-records__grid entries-record-row__grid">
          ${renderSalesPurchaseRecordSelectionDot(isSelected)}
          ${renderSalesPurchaseRecordCell({ className: 'entries-records__col--serial', valueMarkup: renderSalesPurchaseRecordTextValue(String(safeSerialNumber), { mono: true, center: true }) })}
          ${renderSalesPurchaseRecordCell({ className: 'entries-records__col--notice', valueMarkup: renderSalesPurchaseRecordTextValue(record?.number || '—', { mono: true, center: true }) })}
          ${renderSalesPurchaseRecordCell({ className: 'entries-records__col--date', valueMarkup: renderSalesPurchaseRecordDateTimeValue(record) })}
          ${renderSalesPurchaseRecordCell({ className: 'entries-records__col--counterparty', valueMarkup: renderSalesPurchaseRecordCounterpartyValue(record) })}
          ${renderSalesPurchaseRecordCell({ className: 'entries-records__col--from', valueMarkup: renderSalesPurchaseRecordInlinePair(record?.tradeCurrencyName || record?.tradeCurrencyCode, record?.tradeCurrencyCode) })}
          ${renderSalesPurchaseRecordCell({ className: 'entries-records__col--incoming', valueMarkup: renderSalesPurchaseRecordAmountValue(record?.amountValue, record?.tradeCurrencyCode, isSale ? ' entries-record-cell__value--negative' : ' entries-record-cell__value--positive', record?.amountText) })}
          ${renderSalesPurchaseRecordCell({ className: 'entries-records__col--beneficiary', valueMarkup: renderSalesPurchaseRecordInlinePair(record?.settlementCurrencyName || record?.settlementCurrencyCode, record?.settlementCurrencyCode, { center: true }) })}
          ${renderSalesPurchaseRecordCell({ className: 'entries-records__col--outgoing', valueMarkup: renderSalesPurchaseRecordAmountValue(record?.counterpartAmountValue, record?.settlementCurrencyCode, isSale ? ' entries-record-cell__value--positive' : ' entries-record-cell__value--negative', record?.counterpartAmountText) })}
          ${renderSalesPurchaseRecordCell({ className: 'entries-records__col--exchange-rate', valueMarkup: renderSalesPurchaseRecordExchangeRateValue(record) })}
          ${renderSalesPurchaseRecordCell({ className: 'entries-records__col--to', valueMarkup: renderSalesPurchaseRecordAccountValue(record) })}
          ${renderSalesPurchaseRecordCell({ className: 'entries-records__col--notes', valueMarkup: renderSalesPurchaseRecordNotesValue(record) })}
          ${renderSalesPurchaseRecordCell({ className: 'entries-records__col--type-status', valueMarkup: renderSalesPurchaseRecordTypeValue(record) })}
          ${renderSalesPurchaseRecordCell({ className: 'entries-records__col--actions', valueMarkup: renderSalesPurchaseRecordActionsDots() })}
        </div>
      </article>
    `;
  }

  function renderSalesPurchaseEmptyState(title, text){
    return `
      <div class="entries-empty">
        <div class="entries-empty__box">
          <div class="entries-empty__title">${escapeHtml(title)}</div>
          <div class="entries-empty__text">${escapeHtml(text)}</div>
        </div>
      </div>
    `;
  }

  function filterSalesPurchaseRecordsForCurrentView(records, panel = runtime.panel){
    const safeRecords = Array.isArray(records) ? records : [];
    const activeActionId = resolveSalesPurchaseActionIdForCurrentView(panel);
    return safeRecords.filter((record) => normalizeInlineSalesPurchaseActionId(record?.type) === activeActionId);
  }

  function getSalesPurchaseRecordDateFilter(){
    return normalizeSalesPurchaseRecordDateFilterRange(runtime.recordDateFilterFrom, runtime.recordDateFilterTo);
  }

  function getSalesPurchaseRecordDateFilterDraft(){
    return {
      from: normalizeSalesPurchaseRecordDateFilterValue(runtime.recordDateFilterDraftFrom),
      to: normalizeSalesPurchaseRecordDateFilterValue(runtime.recordDateFilterDraftTo)
    };
  }

  function filterSalesPurchaseRecordsByDate(records, dateFilter = getSalesPurchaseRecordDateFilter()){
    const safeRecords = Array.isArray(records) ? records : [];
    const from = normalizeSalesPurchaseRecordDateFilterValue(dateFilter?.from);
    const to = normalizeSalesPurchaseRecordDateFilterValue(dateFilter?.to);
    if(!from && !to) return safeRecords;
    return safeRecords.filter((record) => {
      const recordDate = normalizeSalesPurchaseRecordDateFilterValue(record?.date);
      if(!recordDate) return false;
      if(from && recordDate < from) return false;
      if(to && recordDate > to) return false;
      return true;
    });
  }

  function filterSalesPurchaseRecordsForVisibleState(records, query = runtime.searchQuery){
    return filterSalesPurchaseRecordsByDate(filterSalesPurchaseRecords(Array.isArray(records) ? records : [], query));
  }

  function getSalesPurchaseRecordFilterManualDateParts(value){
    const safeValue = normalizeSalesPurchaseRecordDateFilterValue(value);
    const parsed = salesPurchaseParseIsoDate(safeValue);
    if(!parsed) return { day:'', month:'', year:'' };
    return {
      day:String(parsed.getDate()).padStart(2, '0'),
      month:String(parsed.getMonth() + 1).padStart(2, '0'),
      year:String(parsed.getFullYear())
    };
  }

  function renderSalesPurchaseRecordDateFilterDayButton(fieldKey, cell){
    const classes = [
      'entries-voucher-date__day',
      cell.outsideMonth ? 'is-outside' : '',
      cell.isToday ? 'is-today' : '',
      cell.isSelected ? 'is-selected' : ''
    ].filter(Boolean).join(' ');
    return `
      <button class="${classes}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="grid" data-sales-purchase-record-date-action="select-day" data-sales-purchase-record-date-field="${escapeHtml(fieldKey)}" data-sales-purchase-record-date-value="${escapeHtml(cell.value)}" aria-pressed="${cell.isSelected ? 'true' : 'false'}" aria-label="اختيار التاريخ ${escapeHtml(cell.value)}">
        <span dir="ltr">${escapeHtml(cell.label)}</span>
      </button>
    `;
  }

  function renderSalesPurchaseRecordDateFilterMonthButton(fieldKey, monthChoice){
    const classes = ['entries-voucher-date__month', monthChoice.isActive ? 'is-active' : ''].filter(Boolean).join(' ');
    return `
      <button class="${classes}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="grid" data-sales-purchase-record-date-action="pick-month" data-sales-purchase-record-date-field="${escapeHtml(fieldKey)}" data-sales-purchase-record-date-month="${escapeHtml(monthChoice.monthCursor)}" aria-pressed="${monthChoice.isActive ? 'true' : 'false'}" aria-label="اختيار شهر ${escapeHtml(monthChoice.label)}">
        <span>${escapeHtml(monthChoice.label)}</span>
      </button>
    `;
  }

  function renderSalesPurchaseRecordDateFilterPicker(fieldKey, labelText, value){
    const safeFieldKey = fieldKey === 'to' ? 'to' : 'from';
    const safeValue = normalizeSalesPurchaseRecordDateFilterValue(value);
    const isOpen = runtime.recordDateFilterPickerKey === safeFieldKey;
    const view = salesPurchaseNormalizeDatePickerView(runtime.recordDateFilterPickerView || 'days');
    const monthCursor = salesPurchaseResolveMonthCursor(safeValue || salesPurchaseTodayInputValue(), runtime.recordDateFilterPickerMonthCursor || (safeValue ? safeValue.slice(0, 7) : ''));
    const parts = getSalesPurchaseRecordFilterManualDateParts(safeValue);
    const cells = salesPurchaseBuildDateCells(monthCursor, safeValue);
    const monthChoices = salesPurchaseBuildMonthChoices(monthCursor);
    const todayValue = salesPurchaseTodayInputValue();
    const currentMonth = typeof feature.salesPurchaseParseMonthCursor === 'function'
      ? feature.salesPurchaseParseMonthCursor(monthCursor)
      : null;
    const currentYearLabel = String(currentMonth?.year || (new Date()).getFullYear());

    return `
      <label class="sales-purchase-records-date-filter__field sales-purchase-records-date-filter__field--manual">
        <span class="sales-purchase-records-date-filter__label">${escapeHtml(labelText)}</span>
        <div class="entries-voucher-date sales-purchase-record-filter-date${isOpen ? ' is-open' : ''}" data-sales-purchase-record-date-picker="${escapeHtml(safeFieldKey)}">
          <input class="sales-purchase-records-date-filter__input" type="hidden" value="${escapeHtml(safeValue)}" data-sales-purchase-date-filter="${escapeHtml(safeFieldKey)}" aria-label="${escapeHtml(labelText)}">
          <div class="entries-voucher-date__trigger sales-purchase-record-filter-date__shell">
            <div class="entries-voucher-date__manual sales-purchase-record-filter-date__manual" data-sales-purchase-record-date-manual="true">
              <input class="entries-voucher-date__manual-input entries-voucher-date__manual-input--day sales-purchase-record-filter-date__part" type="text" value="${escapeHtml(parts.day)}" placeholder="يوم" inputmode="numeric" autocomplete="off" dir="ltr" data-sales-purchase-record-date-part="day" data-sales-purchase-record-date-field="${escapeHtml(safeFieldKey)}" aria-label="يوم ${escapeHtml(labelText)}">
              <span class="entries-voucher-date__manual-sep" aria-hidden="true">/</span>
              <input class="entries-voucher-date__manual-input entries-voucher-date__manual-input--month sales-purchase-record-filter-date__part" type="text" value="${escapeHtml(parts.month)}" placeholder="شهر" inputmode="numeric" autocomplete="off" dir="ltr" data-sales-purchase-record-date-part="month" data-sales-purchase-record-date-field="${escapeHtml(safeFieldKey)}" aria-label="شهر ${escapeHtml(labelText)}">
              <span class="entries-voucher-date__manual-sep" aria-hidden="true">/</span>
              <input class="entries-voucher-date__manual-input entries-voucher-date__manual-input--year sales-purchase-record-filter-date__part" type="text" value="${escapeHtml(parts.year)}" placeholder="سنة" inputmode="numeric" autocomplete="off" dir="ltr" data-sales-purchase-record-date-part="year" data-sales-purchase-record-date-field="${escapeHtml(safeFieldKey)}" aria-label="سنة ${escapeHtml(labelText)}">
            </div>
            <button class="entries-voucher-date__trigger-icon-btn sales-purchase-record-filter-date__icon-btn" type="button" data-sales-purchase-record-date-action="toggle" data-sales-purchase-record-date-field="${escapeHtml(safeFieldKey)}" aria-label="فتح لوحة ${escapeHtml(labelText)}" aria-haspopup="dialog" aria-expanded="${isOpen ? 'true' : 'false'}">
              <span class="entries-voucher-date__trigger-icon" aria-hidden="true">${DATE_PICKER_ICON_MARKUP}</span>
            </button>
          </div>
          ${isOpen ? `
            <div class="entries-voucher-date__popover sales-purchase-record-filter-date__popover" data-taif-dropdown-popup="true" data-taif-dropdown-layout="calendar" role="dialog" aria-label="اختيار ${escapeHtml(labelText)}">
              ${view === 'month-year' ? `
                <div class="entries-voucher-date__header entries-voucher-date__header--month-year">
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-record-date-action="prev-year" data-sales-purchase-record-date-field="${escapeHtml(safeFieldKey)}" data-sales-purchase-record-date-month="${escapeHtml(monthCursor)}" aria-label="السنة السابقة">${DATE_PICKER_CHEVRON_NEXT_MARKUP}</button>
                  <button class="entries-voucher-date__heading-trigger entries-voucher-date__heading-trigger--current" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-record-date-action="toggle-view" data-sales-purchase-record-date-field="${escapeHtml(safeFieldKey)}" data-sales-purchase-record-date-view="days" data-sales-purchase-record-date-month="${escapeHtml(monthCursor)}" aria-label="الرجوع إلى أيام الشهر"><span dir="ltr">${escapeHtml(currentYearLabel)}</span></button>
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-record-date-action="next-year" data-sales-purchase-record-date-field="${escapeHtml(safeFieldKey)}" data-sales-purchase-record-date-month="${escapeHtml(monthCursor)}" aria-label="السنة التالية">${DATE_PICKER_CHEVRON_PREV_MARKUP}</button>
                </div>
                <div class="entries-voucher-date__month-panel"><div class="entries-voucher-date__month-grid">${monthChoices.map((monthChoice) => renderSalesPurchaseRecordDateFilterMonthButton(safeFieldKey, monthChoice)).join('')}</div></div>
                <div class="entries-voucher-date__footer">
                  <button class="entries-voucher-date__footer-btn" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-record-date-action="toggle-view" data-sales-purchase-record-date-field="${escapeHtml(safeFieldKey)}" data-sales-purchase-record-date-view="days" data-sales-purchase-record-date-month="${escapeHtml(monthCursor)}">رجوع للتقويم</button>
                  <button class="entries-voucher-date__footer-btn entries-voucher-date__footer-btn--ghost" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-record-date-action="close" data-sales-purchase-record-date-field="${escapeHtml(safeFieldKey)}">إغلاق</button>
                </div>
              ` : `
                <div class="entries-voucher-date__header">
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-record-date-action="prev-month" data-sales-purchase-record-date-field="${escapeHtml(safeFieldKey)}" data-sales-purchase-record-date-month="${escapeHtml(monthCursor)}" aria-label="الشهر السابق">${DATE_PICKER_CHEVRON_NEXT_MARKUP}</button>
                  <button class="entries-voucher-date__heading-trigger" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-record-date-action="toggle-view" data-sales-purchase-record-date-field="${escapeHtml(safeFieldKey)}" data-sales-purchase-record-date-view="month-year" data-sales-purchase-record-date-month="${escapeHtml(monthCursor)}" aria-label="تغيير الشهر أو السنة">${escapeHtml(salesPurchaseFormatMonthLabel(monthCursor))}</button>
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-record-date-action="next-month" data-sales-purchase-record-date-field="${escapeHtml(safeFieldKey)}" data-sales-purchase-record-date-month="${escapeHtml(monthCursor)}" aria-label="الشهر التالي">${DATE_PICKER_CHEVRON_PREV_MARKUP}</button>
                </div>
                <div class="entries-voucher-date__weekdays" aria-hidden="true">${DATE_PICKER_WEEKDAY_LABELS.map((weekday) => `<span>${escapeHtml(weekday)}</span>`).join('')}</div>
                <div class="entries-voucher-date__grid">${cells.map((cell) => renderSalesPurchaseRecordDateFilterDayButton(safeFieldKey, cell)).join('')}</div>
                <div class="entries-voucher-date__footer">
                  <button class="entries-voucher-date__footer-btn" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-record-date-action="today" data-sales-purchase-record-date-field="${escapeHtml(safeFieldKey)}" data-sales-purchase-record-date-value="${escapeHtml(todayValue)}">اليوم</button>
                  <button class="entries-voucher-date__footer-btn entries-voucher-date__footer-btn--ghost" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-record-date-action="clear" data-sales-purchase-record-date-field="${escapeHtml(safeFieldKey)}">مسح</button>
                  <button class="entries-voucher-date__footer-btn entries-voucher-date__footer-btn--ghost" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-record-date-action="close" data-sales-purchase-record-date-field="${escapeHtml(safeFieldKey)}">إغلاق</button>
                </div>
              `}
            </div>
          ` : ''}
        </div>
      </label>
    `;
  }

  function renderSalesPurchaseRecordsDateFilterBar(){
    const draft = getSalesPurchaseRecordDateFilterDraft();
    const applied = getSalesPurchaseRecordDateFilter();
    const isActive = !!applied.from || !!applied.to;
    return `
      <div class="sales-purchase-records-date-filter" aria-label="فلترة السجلات حسب التاريخ">
        ${renderSalesPurchaseRecordDateFilterPicker('from', 'من تاريخ :', draft.from)}
        ${renderSalesPurchaseRecordDateFilterPicker('to', 'الى تاريخ :', draft.to)}
        <button class="sales-purchase-button sales-purchase-button--primary sales-purchase-records-date-filter__button${isActive ? ' is-active' : ''}" type="button" data-sales-purchase-action="apply-record-date-filter" aria-pressed="${isActive ? 'true' : 'false'}">بحث</button>
      </div>
    `;
  }

  function renderSalesPurchaseRecordsPageSizeOptions(activePageSize){
    const safeActivePageSize = normalizeSalesPurchaseRecordsPageSize(activePageSize);
    const numericOptions = SALES_PURCHASE_RECORDS_PAGE_SIZE_OPTIONS.map((pageSize) => `
      <option value="${escapeHtml(String(pageSize))}"${safeActivePageSize === pageSize ? ' selected' : ''}>${escapeHtml(String(pageSize))} لكل صفحة</option>
    `).join('');
    return `${numericOptions}
      <option value="${escapeHtml(SALES_PURCHASE_RECORDS_ALL_PAGE_SIZE)}"${safeActivePageSize === SALES_PURCHASE_RECORDS_ALL_PAGE_SIZE ? ' selected' : ''}>الكل</option>
    `;
  }

  function renderSalesPurchaseRecordsPaginationButton(action, label, title, disabled = false){
    const safeAction = String(action || '').trim();
    return `
      <button class="sales-purchase-records-pagination__nav-btn" type="button" data-sales-purchase-action="records-page-${escapeHtml(safeAction)}" aria-label="${escapeHtml(title)}" title="${escapeHtml(title)}"${disabled ? ' disabled aria-disabled="true"' : ''}>
        <span aria-hidden="true">${escapeHtml(label)}</span>
      </button>
    `;
  }

  function renderSalesPurchaseRecordsPaginationBar(pageState){
    if(!pageState || !(Number(pageState.totalCount) > 0)) return '';
    const fromLabel = Number(pageState.startIndex) >= 0 ? Number(pageState.startIndex) + 1 : 0;
    const toLabel = Number(pageState.endIndex) || 0;
    const totalLabel = Number(pageState.totalCount) || 0;
    const currentPageLabel = Math.max(1, Number(pageState.pageIndex) + 1 || 1);
    const canPrev = !!pageState.canPrev;
    const canNext = !!pageState.canNext;
    return `
      <div class="sales-purchase-records-pagination" aria-label="شريط تنقل سجل الشراء والمبيع">
        <label class="sales-purchase-records-pagination__page-size">
          <select class="sales-purchase-records-pagination__select" data-sales-purchase-records-page-size="true" aria-label="عدد العمليات في الصفحة">
            ${renderSalesPurchaseRecordsPageSizeOptions(pageState.pageSize)}
          </select>
        </label>
        <div class="sales-purchase-records-pagination__summary" aria-live="polite">
          عرض <span dir="ltr">${escapeHtml(String(fromLabel))}</span> - <span dir="ltr">${escapeHtml(String(toLabel))}</span> من <span dir="ltr">${escapeHtml(String(totalLabel))}</span>
        </div>
        <nav class="sales-purchase-records-pagination__nav" aria-label="تنقل صفحات السجل">
          ${renderSalesPurchaseRecordsPaginationButton('last', '«', 'الصفحة الأخيرة', !canNext)}
          ${renderSalesPurchaseRecordsPaginationButton('next', '‹', 'الصفحة التالية', !canNext)}
          <span class="sales-purchase-records-pagination__page" dir="ltr" aria-label="الصفحة الحالية">${escapeHtml(String(currentPageLabel))}</span>
          ${renderSalesPurchaseRecordsPaginationButton('prev', '›', 'الصفحة السابقة', !canPrev)}
          ${renderSalesPurchaseRecordsPaginationButton('first', '»', 'الصفحة الأولى', !canPrev)}
        </nav>
      </div>
    `;
  }

  function renderSalesPurchaseRecordsTable(records, query = runtime.searchQuery){
    const scopedRecords = filterSalesPurchaseRecordsForCurrentView(records);
    const searchedRecords = filterSalesPurchaseRecords(scopedRecords, query);
    const filteredRecords = filterSalesPurchaseRecordsByDate(searchedRecords);
    const activeActionId = resolveSalesPurchaseActionIdForCurrentView();
    const activeTitle = getSalesPurchaseActionTitle(activeActionId);
    if(!scopedRecords.length){
      return renderSalesPurchaseEmptyState(`سجل ${activeTitle}`, `ابدأ بتنفيذ ${activeTitle} لتظهر عملياتها هنا مباشرة ضمن سجل منظم وواضح.`);
    }
    const hasTextQuery = !!toSafeText(query);
    const activeDateFilter = getSalesPurchaseRecordDateFilter();
    const hasDateFilter = !!activeDateFilter.from || !!activeDateFilter.to;
    let bodyMarkup = '';
    let paginationMarkup = '';
    if(filteredRecords.length){
      const pageState = resolveSalesPurchaseRecordsPagination(filteredRecords);
      bodyMarkup = pageState.records.map((record, index) => {
        const absoluteIndex = Math.max(0, Number(pageState.startIndex) || 0) + index;
        return renderSalesPurchaseRecordRow(record, filteredRecords.length - absoluteIndex);
      }).join('');
      paginationMarkup = renderSalesPurchaseRecordsPaginationBar(pageState);
    }else{
      runtime.salesPurchaseRecordsPageIndex = 0;
      if(hasTextQuery && !searchedRecords.length){
        bodyMarkup = renderSalesPurchaseEmptyState('لا توجد نتائج مطابقة', 'عدّل عبارة البحث أو اضغط إلغاء ليظهر سجل هذا القسم من جديد.');
      }else if(hasDateFilter){
        bodyMarkup = renderSalesPurchaseEmptyState('لا توجد نتائج ضمن الفترة المحددة', 'عدّل تاريخ البداية أو النهاية ثم اضغط بحث لعرض السجلات المطابقة.');
      }else if(hasTextQuery){
        bodyMarkup = renderSalesPurchaseEmptyState('لا توجد نتائج مطابقة', 'عدّل عبارة البحث أو اضغط إلغاء ليظهر سجل هذا القسم من جديد.');
      }else{
        bodyMarkup = renderSalesPurchaseEmptyState('لا توجد سجلات ظاهرة', 'لا توجد عمليات مطابقة للعرض الحالي.');
      }
    }
    return `
      <div class="entries-log__records entries-log__records--split-scroll" aria-label="سجل الشراء والمبيع">
        <div class="entries-records__viewport entries-records__viewport--split-scroll">
          ${renderSalesPurchaseRecordsDateFilterBar()}
          ${renderSalesPurchaseRecordsHead()}
          <div class="entries-records__scroller entries-records__scroller--split-scroll">
            <div class="entries-records__body">
              ${bodyMarkup}
            </div>
          </div>
          ${paginationMarkup}
        </div>
      </div>
    `;
  }

  function renderSalesPurchaseMainArea(records, query = runtime.searchQuery){
    return `
      <section class="entries-log sales-purchase-log" aria-label="سجل عمليات الشراء والمبيع">
        ${renderSalesPurchaseRecordsTable(records, query)}
      </section>
    `;
  }

  function getInlinePurchaseWorkspaceHost(panel = runtime.panel){
    const root = panel instanceof HTMLElement ? panel : runtime.panel;
    if(!(root instanceof HTMLElement)) return null;
    const host = root.querySelector('[data-sales-purchase-inline-purchase-root="true"]');
    return host instanceof HTMLElement ? host : null;
  }

  function ensureInlinePurchaseWorkspaceEntry(host = null, preferredActionId = null){
    let entry = runtime.inlinePurchaseWorkspaceEntry;
    const requestedActionId = preferredActionId !== null && preferredActionId !== undefined
      ? normalizeInlineSalesPurchaseActionId(preferredActionId)
      : normalizeInlineSalesPurchaseActionId(entry?.action?.id || runtime.inlineSalesPurchaseActiveActionId || 'purchase');

    if(!entry || !entry.formState || !entry.action || !INLINE_SALES_PURCHASE_ACTION_IDS.has(String(entry.action.id || '').trim())){
      const draft = resolveInlineSalesPurchaseDraft(requestedActionId);
      entry = {
        id: INLINE_PURCHASE_WORKSPACE_ENTRY_ID,
        action: getInlineSalesPurchaseAction(requestedActionId),
        formState: draft.formState,
        navigatorBaselineFormState: draft.navigatorBaselineFormState,
        backdrop: null,
        modal: host instanceof HTMLElement ? host : null,
        manager: null,
        cleanupCallbacks: [],
        ownerWindowId: '',
        attachedOwnerWindowId: '',
        attachedPartyWindowId: '',
        didMaximizeOwnerForAttachment: false,
        lastModalPosition: null,
        isMutating: false,
        mutationMode: '',
        isInlineWorkspace: true
      };
      runtime.inlinePurchaseWorkspaceEntry = entry;
    } else if(preferredActionId !== null && preferredActionId !== undefined && normalizeInlineSalesPurchaseActionId(entry.action.id) !== requestedActionId){
      rememberInlineSalesPurchaseDraft(entry);
      const draft = resolveInlineSalesPurchaseDraft(requestedActionId, entry.formState);
      entry.action = getInlineSalesPurchaseAction(requestedActionId);
      entry.formState = draft.formState;
      entry.navigatorBaselineFormState = draft.navigatorBaselineFormState;
    }

    const activeActionId = normalizeInlineSalesPurchaseActionId(entry.action?.id || requestedActionId);
    entry.id = INLINE_PURCHASE_WORKSPACE_ENTRY_ID;
    entry.action = getInlineSalesPurchaseAction(activeActionId);
    entry.isInlineWorkspace = true;
    entry.formState.windowActionId = activeActionId;
    runtime.inlineSalesPurchaseActiveActionId = activeActionId;
    if(host instanceof HTMLElement) entry.modal = host;
    if(!entry.navigatorBaselineFormState){
      entry.navigatorBaselineFormState = snapshotSalesPurchaseBaselineFormState(entry.formState, activeActionId);
    }
    if(runtime.windows && typeof runtime.windows.set === 'function'){
      runtime.windows.set(INLINE_PURCHASE_WORKSPACE_ENTRY_ID, entry);
    }
    return entry;
  }

  function switchInlineSalesPurchaseWorkspace(actionId, options = {}){
    const safeActionId = normalizeInlineSalesPurchaseActionId(actionId);
    const host = getInlinePurchaseWorkspaceHost();
    if(!(host instanceof HTMLElement)) return false;
    const entry = ensureInlinePurchaseWorkspaceEntry(host);
    const currentActionId = normalizeInlineSalesPurchaseActionId(entry.action?.id);
    if(currentActionId !== safeActionId){
      rememberInlineSalesPurchaseDraft(entry);
      const draft = resolveInlineSalesPurchaseDraft(safeActionId, entry.formState);
      entry.action = getInlineSalesPurchaseAction(safeActionId);
      entry.formState = draft.formState;
      entry.navigatorBaselineFormState = draft.navigatorBaselineFormState;
      entry.formState.openPickerKey = null;
      entry.formState.datePickerOpen = false;
      entry.formState.datePickerView = 'days';
      entry.formState.alertIssues = [];
      entry.formState.windowActionId = safeActionId;
      runtime.inlineSalesPurchaseActiveActionId = safeActionId;
    }
    renderWindowForm(entry, () => {
      if(options && options.focus === false) return;
      const target = resolveSalesPurchasePreferredAmountFocus(entry, entry.modal)
        || entry.modal?.querySelector('[data-sales-purchase-action="execute-window"]');
      if(target instanceof HTMLElement) focusSalesPurchaseElement(target);
    });
    return true;
  }

  function renderInlineActionIcon(kind){
    const safeKind = String(kind || '').trim();
    const icons = {
      execute: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M20 6 9 17l-5-5" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"></path></svg>',
      fresh: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 5v14M5 12h14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"></path></svg>',
      reverse: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4 7v5h5" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"></path><path d="M20 17a8 8 0 0 1-13.7-5.6L4 12" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"></path></svg>',
      delete: DELETE_ICON_MARKUP
    };
    return `<span class="entries-action-btn__icon sales-purchase-inline-action-btn__icon" aria-hidden="true">${icons[safeKind] || icons.execute}</span>`;
  }

  function renderInlinePurchaseActions(action = ACTIONS.purchase){
    const safeTitle = toSafeText(action?.title) || 'الفاتورة';
    return `
      <div class="sales-purchase-inline-actions" data-taif-footer-actions="true" aria-label="إجراءات ${escapeHtml(safeTitle)} داخل الصندوق">
        <div class="sales-purchase-inline-actions__layout">
          <div class="entries-actions__group entries-actions__group--primary-actions" data-taif-footer-group="true">
            <button class="entries-action-btn sales-purchase-button sales-purchase-button--success sales-purchase-inline-action-btn sales-purchase-inline-action-btn--execute" type="button" data-sales-purchase-action="execute-window" data-taif-action-role="commit" data-taif-action-tone="success">${renderInlineActionIcon('execute')}<span class="taif-control-text">تنفيذ العملية</span></button>
            <button class="entries-action-btn sales-purchase-button sales-purchase-button--primary sales-purchase-inline-action-btn sales-purchase-inline-action-btn--new" type="button" data-sales-purchase-action="open-new-window" data-taif-action-role="auxiliary" data-taif-action-tone="primary" disabled>${renderInlineActionIcon('fresh')}<span class="taif-control-text">جديد</span></button>
            <button class="entries-action-btn sales-purchase-button sales-purchase-button--dark sales-purchase-inline-action-btn sales-purchase-inline-action-btn--reverse" type="button" data-sales-purchase-action="reverse-window-record" data-taif-action-role="destructive" data-taif-action-tone="dark" disabled>${renderInlineActionIcon('reverse')}<span class="taif-control-text">إلغاء القيد</span></button>
            <button class="entries-action-btn sales-purchase-button sales-purchase-button--danger sales-purchase-inline-action-btn sales-purchase-inline-action-btn--delete" type="button" data-sales-purchase-action="delete-window-record" data-taif-action-role="destructive" data-taif-action-tone="danger" disabled>${renderInlineActionIcon('delete')}<span class="taif-control-text">حذف</span></button>
          </div>
        </div>
      </div>
    `;
  }

  const salesPurchaseSideboxCurrencyDomain = TAIF.currencyDomain || {};
  const salesPurchaseSideboxCurrencyDisplay = TAIF.currencyDisplay || {};
  const salesPurchaseSideboxCreateSingleLineHeaderLabel = typeof salesPurchaseSideboxCurrencyDisplay.createSingleLineHeaderLabel === 'function'
    ? salesPurchaseSideboxCurrencyDisplay.createSingleLineHeaderLabel
    : (text) => `<span>${escapeHtml(text)}</span>`;

  const SALES_PURCHASE_SIDEBOX_PRICE_PAGE_SIZE = 5;
  const SALES_PURCHASE_SIDEBOX_RATE_BASIS = Object.freeze({
    counterpart:'counterpart',
    usd:'usd'
  });

  function normalizeSalesPurchaseSideboxRateBasis(value){
    return String(value || '').trim().toLowerCase() === SALES_PURCHASE_SIDEBOX_RATE_BASIS.usd
      ? SALES_PURCHASE_SIDEBOX_RATE_BASIS.usd
      : SALES_PURCHASE_SIDEBOX_RATE_BASIS.counterpart;
  }

  function getSalesPurchaseSideboxRateBasis(){
    const basis = normalizeSalesPurchaseSideboxRateBasis(runtime.salesPurchaseSideboxRateBasis);
    runtime.salesPurchaseSideboxRateBasis = basis;
    return basis;
  }

  function getSalesPurchaseSideboxUsdCurrency(source = null){
    const state = source && source.state && typeof source.state === 'object' ? source.state : null;
    const currencies = Array.isArray(state?.currencies) ? state.currencies : [];
    const usd = currencies.find((currency) => normalizeCurrencyCode(currency && currency.code) === 'USD');
    return usd || { code:'USD', name:'الدولار الأمريكي', flag:'us' };
  }

  function resolveSalesPurchaseSideboxBasisCurrency(source, basis){
    const safeBasis = normalizeSalesPurchaseSideboxRateBasis(basis);
    if(safeBasis === SALES_PURCHASE_SIDEBOX_RATE_BASIS.usd) return getSalesPurchaseSideboxUsdCurrency(source);
    return source?.counterpart || { code:'USD', name:'الدولار الأمريكي', flag:'us' };
  }

  function getSalesPurchaseSideboxBasisDisplayName(currency){
    return toSafeText(currency?.name || currency?.code) || 'الدولار الأمريكي';
  }

  function getSalesPurchaseSideboxRateFields(basis){
    return normalizeSalesPurchaseSideboxRateBasis(basis) === SALES_PURCHASE_SIDEBOX_RATE_BASIS.usd
      ? { buy:'dollarBuy', sell:'dollarSell' }
      : { buy:'buy', sell:'sell' };
  }

  function readSalesPurchaseSideboxPriceRows(){
    const domain = salesPurchaseSideboxCurrencyDomain;
    if(domain && typeof domain.readState === 'function' && typeof domain.computeRows === 'function'){
      const state = domain.readState();
      const rows = domain.computeRows(state);
      const counterpart = typeof domain.getCounterpartCurrency === 'function'
        ? domain.getCounterpartCurrency(state)
        : { code:'USD', name:'الدولار الأمريكي' };
      return {
        state,
        counterpart,
        rows:Array.isArray(rows) ? rows : []
      };
    }
    return { state:{ currencies:[] }, counterpart:{ code:'USD', name:'الدولار الأمريكي' }, rows:[] };
  }

  function getSalesPurchaseSideboxVisiblePriceRows(rows, counterpartCode = ''){
    const safeCounterpartCode = normalizeCurrencyCode(counterpartCode);
    if(!Array.isArray(rows)) return [];
    return rows.filter((row) => {
      if(!row || typeof row !== 'object') return false;
      if(row.isCounterpart) return false;
      const rowCode = normalizeCurrencyCode(row.code);
      if(safeCounterpartCode && rowCode === safeCounterpartCode) return false;
      return !!rowCode;
    });
  }

  function normalizeSalesPurchaseSideboxPageIndex(value, totalPages = 1){
    const pages = Math.max(1, Number(totalPages) || 1);
    const numericValue = Number(value);
    const safeValue = Number.isFinite(numericValue) ? Math.floor(numericValue) : 0;
    return Math.max(0, Math.min(pages - 1, safeValue));
  }

  function resolveSalesPurchaseSideboxPricePage(rows){
    const safeRows = Array.isArray(rows) ? rows : [];
    const pageSize = SALES_PURCHASE_SIDEBOX_PRICE_PAGE_SIZE;
    const totalPages = Math.max(1, Math.ceil(safeRows.length / pageSize));
    const pageIndex = normalizeSalesPurchaseSideboxPageIndex(runtime.salesPurchaseSideboxPricePageIndex, totalPages);
    runtime.salesPurchaseSideboxPricePageIndex = pageIndex;
    const startIndex = pageIndex * pageSize;
    const pageRows = safeRows.slice(startIndex, startIndex + pageSize);
    return {
      rows:pageRows,
      pageSize,
      pageIndex,
      totalPages,
      totalCount:safeRows.length,
      canPrev:pageIndex > 0,
      canNext:pageIndex < totalPages - 1
    };
  }

  function moveSalesPurchaseSideboxPricePage(direction = 'next', panel = runtime.panel){
    const source = readSalesPurchaseSideboxPriceRows();
    const basis = getSalesPurchaseSideboxRateBasis();
    const basisCurrency = resolveSalesPurchaseSideboxBasisCurrency(source, basis);
    const visibleRows = getSalesPurchaseSideboxVisiblePriceRows(source.rows, basisCurrency?.code);
    const pageState = resolveSalesPurchaseSideboxPricePage(visibleRows);
    const step = String(direction || '').trim() === 'prev' ? -1 : 1;
    const nextPageIndex = normalizeSalesPurchaseSideboxPageIndex(pageState.pageIndex + step, pageState.totalPages);
    if(nextPageIndex === pageState.pageIndex) return false;
    runtime.salesPurchaseSideboxPricePageIndex = nextPageIndex;
    refreshSalesPurchaseSideboxPricesUi(panel);
    return true;
  }

  function resolveSalesPurchaseSideboxNavDisabledAttr(isEnabled){
    return isEnabled ? '' : ' disabled aria-disabled="true"';
  }

  function resolveSalesPurchaseSideboxNavTitle(direction, isEnabled){
    if(String(direction || '').trim() === 'prev') return isEnabled ? 'عرض العملات السابقة' : 'لا توجد صفحة سابقة';
    return isEnabled ? 'عرض العملات التالية' : 'لا توجد صفحة تالية';
  }

  function resolveSalesPurchaseSideboxFlagAsset(rowOrCurrency, variant = 'circle'){
    const domain = salesPurchaseSideboxCurrencyDomain;
    if(domain && typeof domain.resolveCurrencyFlagAsset === 'function'){
      return domain.resolveCurrencyFlagAsset(rowOrCurrency, variant);
    }
    const flags = TAIF.assets && TAIF.assets.flags;
    const safeRow = rowOrCurrency && typeof rowOrCurrency === 'object' ? rowOrCurrency : {};
    const explicitFlag = toSafeText(safeRow.flag);
    const fallbackCode = toSafeText(safeRow.code);
    if(flags && typeof flags.resolveFlagAsset === 'function'){
      return flags.resolveFlagAsset(explicitFlag || fallbackCode || 'xx', variant);
    }
    return { src:'assets/flags/circle/xx.png', countryCode:'xx' };
  }

  function formatSalesPurchaseSideboxRateCell(row, field, maxAutoDecimals = 6){
    const domain = salesPurchaseSideboxCurrencyDomain;
    if(domain && typeof domain.formatManagementCellValue === 'function'){
      return domain.formatManagementCellValue(row, field, maxAutoDecimals);
    }
    const safeValue = row && Object.prototype.hasOwnProperty.call(row, field) ? row[field] : '';
    if(safeValue === null || typeof safeValue === 'undefined' || safeValue === '') return '—';
    return escapeHtml(toSafeText(safeValue));
  }

  function renderSalesPurchaseSideboxPriceRow(row, counterpart, basis = SALES_PURCHASE_SIDEBOX_RATE_BASIS.counterpart){
    const flagAsset = resolveSalesPurchaseSideboxFlagAsset(row, 'circle');
    const rowCode = normalizeCurrencyCode(row?.code) || toSafeText(row?.code);
    const rowName = toSafeText(row?.name) || rowCode || '—';
    const flagTitle = rowName || rowCode;
    const rateFields = getSalesPurchaseSideboxRateFields(basis);
    return `
      <div class="sales-purchase-side-prices__row${row?.isUsd ? ' sales-purchase-side-prices__row--usd' : ''}" data-sales-purchase-sidebox-currency-code="${escapeHtml(rowCode)}">
        <div class="sales-purchase-side-prices__flag" title="${escapeHtml(flagTitle)}" aria-hidden="true">
          <img class="sales-purchase-side-prices__flag-image" src="${escapeHtml(flagAsset.src)}" alt="" draggable="false" loading="eager" decoding="async" width="512" height="512">
        </div>
        <div class="sales-purchase-side-prices__name" title="${escapeHtml(rowName)}">${escapeHtml(rowName)}</div>
        <div class="sales-purchase-side-prices__num sales-purchase-side-prices__num--buy" dir="ltr">${wrapControlTextMarkup(formatSalesPurchaseSideboxRateCell(row, rateFields.buy, 6), 'taif-control-text--ltr')}</div>
        <div class="sales-purchase-side-prices__num sales-purchase-side-prices__num--sell" dir="ltr">${wrapControlTextMarkup(formatSalesPurchaseSideboxRateCell(row, rateFields.sell, 6), 'taif-control-text--ltr')}</div>
      </div>
    `;
  }

  function renderSalesPurchaseSideboxBasisOption(value, label, isActive){
    const safeValue = normalizeSalesPurchaseSideboxRateBasis(value);
    return `
      <button class="sales-purchase-side-prices__basis-option${isActive ? ' is-active' : ''}" type="button" data-sales-purchase-sidebox-basis-option="${escapeHtml(safeValue)}" role="option" aria-selected="${isActive ? 'true' : 'false'}">
        <span class="sales-purchase-side-prices__basis-option-check" aria-hidden="true">${isActive ? createChoicePickerIcon('check') : ''}</span>
        <span class="sales-purchase-side-prices__basis-option-label">${escapeHtml(label)}</span>
      </button>
    `;
  }

  function renderSalesPurchaseSideboxBasisPicker(source, basis){
    const safeBasis = normalizeSalesPurchaseSideboxRateBasis(basis);
    const counterpart = source?.counterpart || { code:'USD', name:'الدولار الأمريكي', flag:'us' };
    const usd = getSalesPurchaseSideboxUsdCurrency(source);
    const selectedCurrency = resolveSalesPurchaseSideboxBasisCurrency(source, safeBasis);
    const selectedName = getSalesPurchaseSideboxBasisDisplayName(selectedCurrency);
    const counterpartName = getSalesPurchaseSideboxBasisDisplayName(counterpart);
    const usdName = getSalesPurchaseSideboxBasisDisplayName(usd);
    const isOpen = !!runtime.salesPurchaseSideboxRateBasisOpen;
    return `
      <div class="sales-purchase-side-prices__basis${isOpen ? ' is-open' : ''}" data-sales-purchase-sidebox-basis="true">
        <button class="sales-purchase-side-prices__basis-trigger" type="button" data-sales-purchase-sidebox-basis-toggle="true" aria-haspopup="listbox" aria-expanded="${isOpen ? 'true' : 'false'}">
          <span class="sales-purchase-side-prices__basis-text">
            <span class="sales-purchase-side-prices__basis-title">أسعار الصرف مقابل ${escapeHtml(selectedName)}</span>
          </span>
          <span class="sales-purchase-side-prices__basis-chevron" aria-hidden="true">${getChevronDownIcon()}</span>
        </button>
        <div class="sales-purchase-side-prices__basis-popover" role="listbox"${isOpen ? '' : ' hidden'}>
          ${renderSalesPurchaseSideboxBasisOption(SALES_PURCHASE_SIDEBOX_RATE_BASIS.counterpart, `أسعار الصرف مقابل ${counterpartName}`, safeBasis === SALES_PURCHASE_SIDEBOX_RATE_BASIS.counterpart)}
          ${renderSalesPurchaseSideboxBasisOption(SALES_PURCHASE_SIDEBOX_RATE_BASIS.usd, `أسعار الصرف مقابل ${usdName}`, safeBasis === SALES_PURCHASE_SIDEBOX_RATE_BASIS.usd)}
        </div>
      </div>
    `;
  }

  function renderSalesPurchaseSideboxPriceBoard(){
    const source = readSalesPurchaseSideboxPriceRows();
    const counterpart = source.counterpart || { code:'USD', name:'الدولار الأمريكي' };
    const basis = getSalesPurchaseSideboxRateBasis();
    const basisCurrency = resolveSalesPurchaseSideboxBasisCurrency(source, basis);
    const basisCode = normalizeCurrencyCode(basisCurrency?.code) || 'USD';
    const basisName = getSalesPurchaseSideboxBasisDisplayName(basisCurrency);
    const allRows = getSalesPurchaseSideboxVisiblePriceRows(source.rows, basisCode);
    const pageState = resolveSalesPurchaseSideboxPricePage(allRows);
    const rows = pageState.rows;
    const prevTitle = resolveSalesPurchaseSideboxNavTitle('prev', pageState.canPrev);
    const nextTitle = resolveSalesPurchaseSideboxNavTitle('next', pageState.canNext);
    return `
      <div class="sales-purchase-side-prices" aria-label="أسعار العملات داخل صندوق الشراء والمبيع">
        <div class="sales-purchase-side-prices__top" aria-label="رأس الصندوق الصغير">
          <button class="sales-purchase-side-prices__nav-btn sales-purchase-side-prices__nav-btn--prev" type="button" data-sales-purchase-sidebox-nav="prev" aria-label="${escapeHtml(prevTitle)}" title="${escapeHtml(prevTitle)}"${resolveSalesPurchaseSideboxNavDisabledAttr(pageState.canPrev)}>السابق</button>
          ${renderSalesPurchaseSideboxBasisPicker(source, basis)}
          <button class="sales-purchase-side-prices__nav-btn sales-purchase-side-prices__nav-btn--next" type="button" data-sales-purchase-sidebox-nav="next" aria-label="${escapeHtml(nextTitle)}" title="${escapeHtml(nextTitle)}"${resolveSalesPurchaseSideboxNavDisabledAttr(pageState.canNext)}>التالي</button>
        </div>
        <div class="sales-purchase-side-prices__head" aria-hidden="true">
          <div>${salesPurchaseSideboxCreateSingleLineHeaderLabel('العلم', { className:'taif-singleline-fit--sales-purchase-side-price-head', min:9.6, max:11.8, minScale:.9 })}</div>
          <div>${salesPurchaseSideboxCreateSingleLineHeaderLabel('اسم العملة', { className:'taif-singleline-fit--sales-purchase-side-price-head', min:9.6, max:11.8, minScale:.9 })}</div>
          <div>${salesPurchaseSideboxCreateSingleLineHeaderLabel(`شراء / ${basisName}`, { className:'taif-singleline-fit--sales-purchase-side-price-head', min:9.2, max:11.8, minScale:.86 })}</div>
          <div>${salesPurchaseSideboxCreateSingleLineHeaderLabel(`مبيع / ${basisName}`, { className:'taif-singleline-fit--sales-purchase-side-price-head', min:9.2, max:11.8, minScale:.86 })}</div>
        </div>
        <div class="sales-purchase-side-prices__body" aria-label="قائمة أسعار العملات">
          ${rows.length ? `<div class="sales-purchase-side-prices__list" style="--sales-purchase-side-prices-visible-count:${escapeHtml(String(pageState.pageSize || SALES_PURCHASE_SIDEBOX_PRICE_PAGE_SIZE))}">${rows.map((row) => renderSalesPurchaseSideboxPriceRow(row, counterpart, basis)).join('')}</div>` : `<div class="sales-purchase-side-prices__empty">لا توجد عملات متاحة للعرض حاليًا.</div>`}
        </div>
      </div>
    `;
  }

  function renderInlinePurchaseSideControls(model){
    const activeActionId = normalizeInlineSalesPurchaseActionId(model?.actionId);
    const actionLabel = activeActionId === 'sale' ? 'المبيع' : 'الشراء';
    return `
      <section class="sales-purchase-inline-sidebox__section sales-purchase-inline-sidebox__section--empty-box sales-purchase-inline-sidebox__section--prices-board" aria-label="صندوق أسعار العملات لفواتير ${escapeHtml(actionLabel)}">
        ${renderSalesPurchaseSideboxPriceBoard()}
      </section>

    `;
  }

  function refreshSalesPurchaseSideboxPricesUi(panel = runtime.panel){
    const root = panel instanceof Element
      ? panel.querySelector('.sales-purchase-inline-sidebox__section--prices-board')
      : null;
    if(!(root instanceof HTMLElement)) return false;
    root.innerHTML = renderSalesPurchaseSideboxPriceBoard();
    return true;
  }

  function toggleSalesPurchaseSideboxRateBasisPicker(panel = runtime.panel){
    runtime.salesPurchaseSideboxRateBasisOpen = !runtime.salesPurchaseSideboxRateBasisOpen;
    refreshSalesPurchaseSideboxPricesUi(panel);
    return true;
  }

  function closeSalesPurchaseSideboxRateBasisPicker(panel = runtime.panel){
    if(!runtime.salesPurchaseSideboxRateBasisOpen) return false;
    runtime.salesPurchaseSideboxRateBasisOpen = false;
    refreshSalesPurchaseSideboxPricesUi(panel);
    return true;
  }

  function selectSalesPurchaseSideboxRateBasis(value, panel = runtime.panel){
    const nextBasis = normalizeSalesPurchaseSideboxRateBasis(value);
    const currentBasis = getSalesPurchaseSideboxRateBasis();
    runtime.salesPurchaseSideboxRateBasisOpen = false;
    if(nextBasis !== currentBasis){
      runtime.salesPurchaseSideboxRateBasis = nextBasis;
      runtime.salesPurchaseSideboxPricePageIndex = 0;
    }
    refreshSalesPurchaseSideboxPricesUi(panel);
    return true;
  }

  function renderInlinePurchaseMainBox(entry = null){
    const safeEntry = entry || ensureInlinePurchaseWorkspaceEntry();
    const action = getInlineSalesPurchaseAction(safeEntry.action?.id);
    const actionId = normalizeInlineSalesPurchaseActionId(action.id);
    return `
      <div class="sales-purchase-inline-purchase sales-purchase-inline-purchase--${escapeHtml(actionId)}" data-sales-purchase-window-id="${escapeHtml(INLINE_PURCHASE_WORKSPACE_ENTRY_ID)}" data-sales-purchase-inline-action="${escapeHtml(actionId)}" aria-label="${escapeHtml(action.title)} داخل مساحة العمل">
        <div class="sales-purchase-inline-purchase__body">
          <div class="sales-purchase-empty-shell sales-purchase-empty-shell--split sales-purchase-empty-shell--inline-purchase" data-sales-purchase-form-root>
            ${renderWindowCanvasContent(action, safeEntry.formState, { inlinePurchase:true, includeTopFields:false })}
          </div>
        </div>
        ${renderInlinePurchaseActions(action)}
      </div>
    `;
  }

  function renderSalesPurchaseWorkspacePanelsContent(entry = null){
    const safeEntry = entry || ensureInlinePurchaseWorkspaceEntry();
    const action = getInlineSalesPurchaseAction(safeEntry.action?.id);
    const model = resolveFormModel(action.id, safeEntry.formState);
    return `
        <div class="sales-purchase-workspace-panel--main sales-purchase-workspace-panel--main-direct" aria-label="مساحة الفاتورة المباشرة">${renderInlinePurchaseMainBox(safeEntry)}</div>
        <div class="sales-purchase-workspace-direct-cards sales-purchase-inline-sidebox" aria-label="بطاقات بيانات الفاتورة">${renderInlinePurchaseSideControls(model)}</div>
    `;
  }

  function syncSalesPurchaseInlinePrimaryRowShift(root = runtime.panel){
    const scope = root instanceof Element ? root : document;
    const grid = scope.querySelector('.sales-purchase-deal__fields-grid--inline-purchase');
    if(!(grid instanceof HTMLElement)) return false;
    const beneficiaryField = grid.querySelector('.sales-purchase-top-field--beneficiary');
    if(!(beneficiaryField instanceof HTMLElement)) return false;
    const beneficiaryWidth = beneficiaryField.getBoundingClientRect().width;
    if(!Number.isFinite(beneficiaryWidth) || beneficiaryWidth <= 0) return false;
    const gridStyle = window.getComputedStyle(grid);
    const columnGap = Number.parseFloat(gridStyle.columnGap || gridStyle.gap || '0') || 0;
    const shift = Math.max(0, Math.round((beneficiaryWidth + columnGap) * 10) / 10);
    grid.style.setProperty('--sales-purchase-inline-primary-row-shift', `${shift}px`);
    return true;
  }

  function bindSalesPurchaseInlinePrimaryRowShiftObserver(root = runtime.panel){
    if(typeof ResizeObserver !== 'function') return;
    const scope = root instanceof Element ? root : document;
    const grid = scope.querySelector('.sales-purchase-deal__fields-grid--inline-purchase');
    if(!(grid instanceof HTMLElement)) return;
    if(runtime.inlinePrimaryRowShiftResizeTarget === grid && runtime.inlinePrimaryRowShiftResizeObserver) return;
    if(runtime.inlinePrimaryRowShiftResizeObserver){
      try{ runtime.inlinePrimaryRowShiftResizeObserver.disconnect(); }catch{}
    }
    const observer = new ResizeObserver(() => {
      syncSalesPurchaseInlinePrimaryRowShift(grid);
    });
    observer.observe(grid);
    runtime.inlinePrimaryRowShiftResizeObserver = observer;
    runtime.inlinePrimaryRowShiftResizeTarget = grid;
  }

  function cleanupSalesPurchaseInlinePrimaryRowShiftObserver(){
    if(runtime.inlinePrimaryRowShiftResizeObserver){
      try{ runtime.inlinePrimaryRowShiftResizeObserver.disconnect(); }catch{}
    }
    runtime.inlinePrimaryRowShiftResizeObserver = null;
    runtime.inlinePrimaryRowShiftResizeTarget = null;
  }

  function syncInlinePurchaseWorkspace(panel = runtime.panel){
    const host = getInlinePurchaseWorkspaceHost(panel);
    if(!(host instanceof HTMLElement)) return false;
    const entry = ensureInlinePurchaseWorkspaceEntry(host);
    normalizeSalesPurchaseFlow(host);
    syncWindowDerivedFields(entry);
    syncSalesPurchaseInlinePrimaryRowShift(host);
    bindSalesPurchaseInlinePrimaryRowShiftObserver(host);
    requestAnimationFrame(() => syncSalesPurchaseInlinePrimaryRowShift(host));
    return true;
  }


  function renderSalesPurchaseWorkspacePanels(){
    const entry = ensureInlinePurchaseWorkspaceEntry();
    return `
      <section class="sales-purchase-workspace-panels" data-sales-purchase-inline-purchase-root="true" data-sales-purchase-window-id="${escapeHtml(INLINE_PURCHASE_WORKSPACE_ENTRY_ID)}" aria-label="مساحات عمل الشراء والمبيع">
        ${renderSalesPurchaseWorkspacePanelsContent(entry)}
      </section>
    `;
  }

  function getSalesPurchaseRecordId(record){
    return toSafeText(record?.id);
  }

  function resolveNextSalesPurchaseSelectionAfterDeletion(records, deletedRecordId, query = runtime.searchQuery){
    const safeDeletedRecordId = toSafeText(deletedRecordId);
    if(!safeDeletedRecordId) return '';
    const visibleRecords = filterSalesPurchaseRecordsForVisibleState(filterSalesPurchaseRecordsForCurrentView(Array.isArray(records) ? records : []), query);
    const selectedIndex = visibleRecords.findIndex((record) => getSalesPurchaseRecordId(record) === safeDeletedRecordId);
    const remainingVisibleRecords = visibleRecords.filter((record) => getSalesPurchaseRecordId(record) !== safeDeletedRecordId);
    if(!remainingVisibleRecords.length) return '';
    const fallbackIndex = selectedIndex >= 0 ? selectedIndex : 0;
    const nextIndex = Math.max(0, Math.min(remainingVisibleRecords.length - 1, fallbackIndex));
    return getSalesPurchaseRecordId(remainingVisibleRecords[nextIndex] || remainingVisibleRecords[remainingVisibleRecords.length - 1] || null);
  }

  function updateSalesPurchaseDeleteActionButtonUi(panel = runtime.panel){
    if(!(panel instanceof Element)) return;
    const deleteButton = panel.querySelector('[data-sales-purchase-action="delete-selected-record"]');
    if(!(deleteButton instanceof HTMLButtonElement)) return;
    const hasSelection = !!toSafeText(runtime.selectedRecordId);
    deleteButton.disabled = !hasSelection;
    deleteButton.setAttribute('aria-disabled', hasSelection ? 'false' : 'true');
    const title = hasSelection ? 'حذف البطاقة المحددة نهائياً' : 'حدد بطاقة أولاً';
    deleteButton.setAttribute('title', title);
    deleteButton.setAttribute('aria-label', title);
  }

  function updateSalesPurchaseRecordSelectionUi(panel = runtime.panel){
    if(!(panel instanceof Element)) return;
    const selectedRecordId = toSafeText(runtime.selectedRecordId);
    panel.querySelectorAll('.entries-record-row[data-sales-purchase-record-id]').forEach((row) => {
      const rowId = toSafeText(row.getAttribute('data-sales-purchase-record-id'));
      const isSelected = !!selectedRecordId && rowId === selectedRecordId;
      row.classList.toggle('entries-record-row--selected', isSelected);
      row.setAttribute('aria-selected', isSelected ? 'true' : 'false');
      row.querySelector('.entries-record-row__state-dot')?.classList.toggle('is-active', isSelected);
    });
    updateSalesPurchaseDeleteActionButtonUi(panel);
  }

  function applySalesPurchaseRecordSelection(recordId = ''){
    runtime.selectedRecordId = toSafeText(recordId);
    updateSalesPurchaseRecordSelectionUi();
  }

  function toggleSalesPurchaseRecordSelection(row){
    if(!(row instanceof HTMLElement)) return;
    const recordId = toSafeText(row.getAttribute('data-sales-purchase-record-id'));
    if(!recordId) return;
    applySalesPurchaseRecordSelection(toSafeText(runtime.selectedRecordId) === recordId ? '' : recordId);
  }

  function clearSalesPurchaseRecordSelection(){
    if(!toSafeText(runtime.selectedRecordId)) return;
    applySalesPurchaseRecordSelection('');
  }

  function renderSalesPurchaseConfirmRecordCard(record){
    const safeRecord = record && typeof record === 'object' ? record : {};
    const typeLabel = salesPurchaseTypeLabel(safeRecord.type);
    const number = toSafeText(safeRecord.number) || '—';
    const dateValue = toSafeText(safeRecord.date) || '—';
    const cashAccountName = toSafeText(safeRecord.cashAccountName) || '—';
    return `
      <div class="taif-question-card taif-question-card--stacked" data-sales-purchase-question-card="true">
        <div class="taif-question-card__main">
          <span class="taif-question-card__badge">${escapeHtml(typeLabel)}</span>
          <span class="taif-question-card__badge taif-question-card__badge--mono" dir="ltr">${escapeHtml(number)}</span>
        </div>
        <div class="taif-question-card__meta">
          <span><strong>التاريخ:</strong> ${escapeHtml(dateValue)}</span>
          <span>${escapeHtml(cashAccountName)}</span>
        </div>
      </div>
    `;
  }

  function closeSalesPurchaseQuestionDialog(handleKey){
    const key = toSafeText(handleKey);
    if(!key) return;
    const handle = runtime[key];
    runtime[key] = null;
    if(handle && typeof handle.close === 'function'){
      handle.close(true);
    }
  }

  function closeSalesPurchaseRuntimeDialog(cleanupKey){
    const key = toSafeText(cleanupKey);
    if(!key) return;
    const cleanup = runtime[key];
    runtime[key] = null;
    if(typeof cleanup === 'function'){
      try{ cleanup(); }catch{}
    }
  }

  function openSalesPurchaseQuestionDialog({
    handleKey,
    title,
    record = null,
    cardHtml = '',
    message = '',
    warning = '',
    confirmLabel = 'تأكيد',
    cancelLabel = 'إلغاء',
    confirmTone = 'danger',
    confirmIcon = 'trash',
    onConfirm = null
  } = {}){
    const key = toSafeText(handleKey);
    if(!key) return null;
    closeSalesPurchaseQuestionDialog(key);
    const questionDialog = TAIF?.ui?.questionDialog;
    if(!questionDialog || typeof questionDialog.open !== 'function'){
      if(typeof onConfirm === 'function') onConfirm();
      return null;
    }

    let handle = null;
    handle = questionDialog.open({
      owner: 'sales-purchase-invoice',
      title: toSafeText(title) || 'تأكيد',
      cardHtml: toSafeText(cardHtml) || (record ? renderSalesPurchaseConfirmRecordCard(record) : ''),
      message: toSafeText(message),
      warning: toSafeText(warning),
      confirmLabel,
      cancelLabel,
      confirmTone,
      confirmIcon,
      focusConfirm: true,
      closeOnConfirm: true,
      className: 'taif-question-dialog--sales-purchase',
      bodyClass: 'taif-question-dialog__body--sales-purchase',
      onConfirm: () => {
        runtime[key] = null;
        if(typeof onConfirm === 'function') onConfirm();
      },
      onCancel: () => {
        runtime[key] = null;
      },
      onClose: () => {
        if(runtime[key] === handle) runtime[key] = null;
      }
    });
    runtime[key] = handle || null;
    return handle;
  }

  function closeSalesPurchaseDeleteConfirmDialog(){
    closeSalesPurchaseQuestionDialog('deleteConfirmDialogHandle');
  }

  function openSalesPurchaseDeleteConfirmDialog(record, onConfirm){
    return openSalesPurchaseQuestionDialog({
      handleKey: 'deleteConfirmDialogHandle',
      title: 'حذف بطاقة نهائي',
      warning: 'سيتم حذف هذه الفاتورة نهائياً مع إزالة قيودها وتحديث الأرصدة والسجلات ودفتر الأستاذ تلقائياً.',
      record,
      confirmLabel: 'حذف نهائي',
      cancelLabel: 'إلغاء',
      confirmTone: 'danger',
      confirmIcon: 'trash',
      onConfirm
    });
  }

  function closeSalesPurchaseReverseConfirmDialog(){
    closeSalesPurchaseQuestionDialog('reverseConfirmDialogHandle');
  }

  function openSalesPurchaseReverseConfirmDialog(record, onConfirm){
    return openSalesPurchaseQuestionDialog({
      handleKey: 'reverseConfirmDialogHandle',
      title: 'إلغاء / عكس القيد',
      warning: 'سيتم عكس هذه الفاتورة وإلغاء أثرها المحاسبي مع إبقائها محفوظة للعرض فقط ومنع تعديلها أو تنفيذها مرة أخرى.',
      record,
      confirmLabel: 'تأكيد العكس',
      cancelLabel: 'تراجع',
      confirmTone: 'danger',
      confirmIcon: 'trash',
      onConfirm
    });
  }

  function closeSalesPurchaseDifferentDateConfirmDialog(){
    closeSalesPurchaseQuestionDialog('differentDateConfirmDialogHandle');
  }

  function renderSalesPurchaseDifferentDateConfirmCard({ actionId = 'purchase', voucherDate = '', todayValue = '' } = {}){
    const typeLabel = salesPurchaseTypeLabel(actionId);
    const safeVoucherDate = toSafeText(voucherDate) || '—';
    const safeTodayValue = toSafeText(todayValue) || '—';
    return `
      <div class="taif-question-card taif-question-card--stacked taif-question-dialog__card--sales-purchase-date" data-sales-purchase-question-card="true">
        <div class="taif-question-dialog__sales-purchase-date-head">
          <span class="taif-question-dialog__sales-purchase-date-badge">فاتورة ${escapeHtml(typeLabel)}</span>
          <span class="taif-question-dialog__sales-purchase-date-chip">تنبيه تاريخ</span>
        </div>
        <div class="taif-question-dialog__sales-purchase-date-grid">
          <div class="taif-question-dialog__sales-purchase-date-box">
            <span class="taif-question-dialog__sales-purchase-date-label">تاريخ الفاتورة</span>
            <strong class="taif-question-dialog__sales-purchase-date-value" dir="ltr">${escapeHtml(safeVoucherDate)}</strong>
          </div>
          <div class="taif-question-dialog__sales-purchase-date-box taif-question-dialog__sales-purchase-date-box--today">
            <span class="taif-question-dialog__sales-purchase-date-label">تاريخ اليوم</span>
            <strong class="taif-question-dialog__sales-purchase-date-value" dir="ltr">${escapeHtml(safeTodayValue)}</strong>
          </div>
        </div>
      </div>
    `;
  }

  function openSalesPurchaseDifferentDateConfirmDialog({ entry, actionId, voucherDate, todayValue, onConfirm } = {}){
    closeSalesPurchaseDifferentDateConfirmDialog();
    return openSalesPurchaseQuestionDialog({
      handleKey: 'differentDateConfirmDialogHandle',
      title: 'تنبيه تاريخ الفاتورة',
      cardHtml: renderSalesPurchaseDifferentDateConfirmCard({ actionId, voucherDate, todayValue }),
      message: 'تاريخ الفاتورة يختلف عن تاريخ اليوم الحقيقي.',
      warning: 'اضغط موافق للمتابعة بنفس التاريخ أو إلغاء للرجوع دون تنفيذ.',
      confirmLabel: 'موافق',
      cancelLabel: 'إلغاء',
      confirmTone: 'primary',
      confirmIcon: 'check',
      onConfirm: () => {
        if(entry && entry.formState && typeof onConfirm === 'function') onConfirm();
      }
    });
  }

  function shouldConfirmSalesPurchaseDifferentDateCreation(editingRecord, model, options = {}){
    if(editingRecord) return false;
    if(options && options.allowDifferentDate === true) return false;
    const voucherDate = salesPurchaseNormalizeDateInputValue(model?.voucherDate || model?.formState?.voucherDate);
    const todayValue = getSalesPurchaseRealTodayValue();
    return !!voucherDate && !!todayValue && voucherDate !== todayValue;
  }


  function renderSalesPurchaseSuccessToastMarkup(message = 'تم تنفيذ العملية بنجاح'){
    const safeMessage = toSafeText(message) || 'تم تنفيذ العملية بنجاح';
    return `
      <div class="entries-toast sales-purchase-toast sales-purchase-toast--success" role="status" aria-live="polite">
        <span class="sales-purchase-toast__icon" aria-hidden="true">${createChoicePickerIcon('check')}</span>
        <span class="sales-purchase-toast__message">${escapeHtml(safeMessage)}</span>
      </div>
    `.trim();
  }

  function normalizeSalesPurchaseReviewIssues(issues){
    if(!Array.isArray(issues)) return [];
    return issues
      .map((issue) => toSafeText(issue))
      .filter(Boolean);
  }

  function renderSalesPurchaseReviewToastMarkup(issues){
    const issueList = normalizeSalesPurchaseReviewIssues(issues);
    if(!issueList.length) return '';
    const issuesMarkup = issueList.length === 1
      ? `<span class="sales-purchase-toast__detail">${escapeHtml(issueList[0])}</span>`
      : `<ul class="sales-purchase-toast__list">${issueList.map((issue) => `<li>${escapeHtml(issue)}</li>`).join('')}</ul>`;
    return `
      <div class="entries-toast sales-purchase-toast sales-purchase-toast--warning" role="alert" aria-live="assertive">
        <span class="sales-purchase-toast__icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 9v4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path><path d="M12 17h.01" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"></path><path d="M10.3 4.2 2.7 17.4A2 2 0 0 0 4.4 20h15.2a2 2 0 0 0 1.7-2.6L13.7 4.2a2 2 0 0 0-3.4 0Z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"></path></svg>
        </span>
        <div class="sales-purchase-toast__content">
          <span class="sales-purchase-toast__message sales-purchase-toast__message--title">يوجد ما يحتاج مراجعة قبل تنفيذ العملية</span>
          ${issuesMarkup}
        </div>
      </div>
    `.trim();
  }

  function resolveSalesPurchaseToastTarget(anchor = null){
    const rootSelector = [
      '[data-sales-purchase-inline-purchase-root="true"]',
      '.sales-purchase-inline-purchase',
      '.sales-purchase-modal-window'
    ].join(', ');

    const buildTarget = (root) => {
      if(!(root instanceof HTMLElement) || !root.isConnected) return null;
      const rateTrack = root.querySelector('.sales-purchase-deal__rate-track');
      const arrow = rateTrack instanceof HTMLElement
        ? rateTrack.querySelector('.sales-purchase-rate-track__arrow')
        : null;
      return {
        rootElement: root,
        modalWindow: root.matches('.sales-purchase-modal-window') ? root : null,
        titleElement: root.querySelector('.sales-purchase-sheet__title') || null,
        rateTrackElement: rateTrack instanceof HTMLElement ? rateTrack : null,
        arrowElement: arrow instanceof HTMLElement ? arrow : null
      };
    };

    const resolveRootFromNode = (node) => {
      if(!(node instanceof HTMLElement) || !node.isConnected) return null;
      if(node.matches(rootSelector)) return node;
      return node.closest(rootSelector);
    };

    const anchorRoot = resolveRootFromNode(anchor);
    const anchorTarget = buildTarget(anchorRoot);
    if(anchorTarget) return anchorTarget;

    const inlineRoot = document.querySelector('[data-sales-purchase-inline-purchase-root="true"]');
    const inlineTarget = buildTarget(inlineRoot);
    if(inlineTarget) return inlineTarget;

    const openWindows = Array.from(document.querySelectorAll('.sales-purchase-modal-window'));
    const fallbackWindow = openWindows.length ? openWindows[openWindows.length - 1] : null;
    const fallbackTarget = buildTarget(fallbackWindow);
    if(fallbackTarget) return fallbackTarget;

    return { rootElement: null, modalWindow: null, titleElement: null, rateTrackElement: null, arrowElement: null };
  }

  function positionSalesPurchaseToast(toast, target = null){
    if(!(toast instanceof HTMLElement)) return;

    const rootElement = target?.rootElement instanceof HTMLElement ? target.rootElement : null;
    const titleElement = target?.titleElement instanceof HTMLElement ? target.titleElement : null;
    const modalWindow = target?.modalWindow instanceof HTMLElement ? target.modalWindow : null;
    const rateTrackElement = target?.rateTrackElement instanceof HTMLElement ? target.rateTrackElement : null;
    const arrowElement = target?.arrowElement instanceof HTMLElement ? target.arrowElement : null;
    const rootRect = rootElement?.getBoundingClientRect?.() || null;
    const titleRect = titleElement?.getBoundingClientRect?.() || null;
    const modalRect = modalWindow?.getBoundingClientRect?.() || null;
    const rateTrackRect = rateTrackElement?.getBoundingClientRect?.() || null;
    const arrowRect = arrowElement?.getBoundingClientRect?.() || null;
    const viewportWidth = window.innerWidth || document.documentElement.clientWidth || 0;
    const viewportHeight = window.innerHeight || document.documentElement.clientHeight || 0;
    const anchorWidth = rateTrackRect?.width || rootRect?.width || modalRect?.width || viewportWidth || 420;
    const maxWidth = Math.max(240, Math.min(anchorWidth - 24, 420));
    toast.style.setProperty('--sales-purchase-toast-max-width', `${Math.round(maxWidth)}px`);

    const toastRect = toast.getBoundingClientRect?.() || null;
    const toastWidth = Math.max(0, toastRect?.width || toast.offsetWidth || 0);
    const toastHeight = Math.max(44, toastRect?.height || toast.offsetHeight || 44);
    let left = viewportWidth ? (viewportWidth / 2) : 0;
    let top = 16;

    if(arrowRect && Number.isFinite(arrowRect.left) && Number.isFinite(arrowRect.width)){
      left = arrowRect.left + (arrowRect.width / 2);
    }else if(rateTrackRect && Number.isFinite(rateTrackRect.left) && Number.isFinite(rateTrackRect.width)){
      left = rateTrackRect.left + (rateTrackRect.width / 2);
    }else if(titleRect && Number.isFinite(titleRect.left) && Number.isFinite(titleRect.width)){
      left = titleRect.left + (titleRect.width / 2);
    }else if(rootRect && Number.isFinite(rootRect.left) && Number.isFinite(rootRect.width)){
      left = rootRect.left + (rootRect.width / 2);
    }else if(modalRect && Number.isFinite(modalRect.left) && Number.isFinite(modalRect.width)){
      left = modalRect.left + (modalRect.width / 2);
    }

    if(arrowRect && Number.isFinite(arrowRect.top)){
      top = Math.max(12, arrowRect.top - toastHeight - 8);
    }else if(rateTrackRect && Number.isFinite(rateTrackRect.top)){
      top = Math.max(12, rateTrackRect.top + 6);
    }else if(rootRect && Number.isFinite(rootRect.top)){
      top = Math.max(12, rootRect.top - 10);
    }else if(modalRect && Number.isFinite(modalRect.top)){
      top = Math.max(12, modalRect.top - 10);
    }else if(titleRect && Number.isFinite(titleRect.top)){
      top = Math.max(12, titleRect.top - 8);
    }

    if(viewportWidth && toastWidth){
      const margin = 10;
      const halfWidth = toastWidth / 2;
      left = Math.min(Math.max(left, margin + halfWidth), viewportWidth - margin - halfWidth);
    }
    if(viewportHeight && toastHeight){
      const margin = 10;
      top = Math.min(Math.max(top, margin), viewportHeight - margin - toastHeight);
    }

    toast.style.left = `${Math.round(left)}px`;
    toast.style.top = `${Math.round(top)}px`;
  }

  function closeSalesPurchaseSuccessDialog(){
    closeSalesPurchaseRuntimeDialog('successDialogCleanup');
  }

  function closeSalesPurchaseReviewDialog(){
    closeSalesPurchaseRuntimeDialog('reviewDialogCleanup');
  }

  function mountSalesPurchaseToastDialog({
    markup = '',
    anchor = null,
    duration = 2200,
    defaultDuration = 2200,
    minimumDuration = 1400,
    cleanupKey = '',
    elementKey = '',
    timerKey = '',
    closeSelf = null,
    closeOther = null
  } = {}){
    const safeMarkup = String(markup || '').trim();
    const safeCleanupKey = toSafeText(cleanupKey);
    const safeElementKey = toSafeText(elementKey);
    const safeTimerKey = toSafeText(timerKey);
    if(!safeMarkup || !safeCleanupKey || !safeElementKey || !safeTimerKey || typeof closeSelf !== 'function') return null;

    if(typeof closeOther === 'function') closeOther();
    closeSelf();

    const target = resolveSalesPurchaseToastTarget(anchor);
    const wrapper = document.createElement('div');
    wrapper.innerHTML = safeMarkup;
    const toast = wrapper.firstElementChild;
    if(!(toast instanceof HTMLElement)) return null;

    toast.__cleanup = () => closeSelf();
    TAIF?.core?.utils?.markOwnedNode?.(toast, 'sales-purchase-invoice', { type:'toast' });
    document.body.appendChild(toast);
    runtime[safeElementKey] = toast;
    positionSalesPurchaseToast(toast, target);

    requestAnimationFrame(() => {
      positionSalesPurchaseToast(toast, target);
      toast.classList.add('is-visible');
    });

    const cleanup = () => {
      if(runtime[safeTimerKey]){
        try{ window.clearTimeout(runtime[safeTimerKey]); }catch{}
        runtime[safeTimerKey] = null;
      }
      if(runtime[safeElementKey] === toast) runtime[safeElementKey] = null;
      toast.classList.remove('is-visible');
      window.setTimeout(() => {
        if(toast.isConnected) toast.remove();
      }, 220);
    };

    runtime[safeCleanupKey] = cleanup;
    runtime[safeTimerKey] = window.setTimeout(() => {
      closeSelf();
    }, Math.max(Number(minimumDuration) || 1400, Number(duration) || Number(defaultDuration) || 2200));

    return toast;
  }

  function openSalesPurchaseSuccessDialog(message, { anchor = null, duration = 2200 } = {}){
    mountSalesPurchaseToastDialog({
      markup: renderSalesPurchaseSuccessToastMarkup(message),
      anchor,
      duration,
      defaultDuration: 2200,
      minimumDuration: 1400,
      cleanupKey: 'successDialogCleanup',
      elementKey: 'successToastElement',
      timerKey: 'successToastTimer',
      closeSelf: closeSalesPurchaseSuccessDialog,
      closeOther: closeSalesPurchaseReviewDialog
    });
  }

  function openSalesPurchaseReviewDialog(issues, { anchor = null, duration = 4200 } = {}){
    const issueList = normalizeSalesPurchaseReviewIssues(issues);
    if(!issueList.length){
      closeSalesPurchaseReviewDialog();
      return;
    }

    mountSalesPurchaseToastDialog({
      markup: renderSalesPurchaseReviewToastMarkup(issueList),
      anchor,
      duration,
      defaultDuration: 4200,
      minimumDuration: 2200,
      cleanupKey: 'reviewDialogCleanup',
      elementKey: 'reviewToastElement',
      timerKey: 'reviewToastTimer',
      closeSelf: closeSalesPurchaseReviewDialog,
      closeOther: closeSalesPurchaseSuccessDialog
    });
  }

  function syncSalesPurchaseReviewToast(entry){
    const issues = normalizeSalesPurchaseReviewIssues(entry?.formState?.alertIssues);
    if(!issues.length){
      closeSalesPurchaseReviewDialog();
      return;
    }
    openSalesPurchaseReviewDialog(issues, { anchor: entry?.modal });
  }

  function createReversedSalesPurchaseRecord(record){
    const safeRecord = normalizeSalesPurchaseRecord(record);
    const reverseStamp = Date.now();
    return normalizeSalesPurchaseRecord({
      ...safeRecord,
      status: 'reversed',
      linkedEntryRecordIds: Array.isArray(safeRecord.linkedEntryRecordIds) ? safeRecord.linkedEntryRecordIds.slice() : [],
      linkedEntryVoucherNumbers: Array.isArray(safeRecord.linkedEntryVoucherNumbers) ? safeRecord.linkedEntryVoucherNumbers.slice() : [],
      accountingBridgeAccountNo: toSafeText(safeRecord.accountingBridgeAccountNo),
      accountingBridgeAccountName: toSafeText(safeRecord.accountingBridgeAccountName),
      lastAction: 'reversed',
      reversedAt: reverseStamp,
      updatedAt: reverseStamp
    });
  }

  function reverseSalesPurchaseRecordById(recordId){
    const targetRecordId = toSafeText(recordId);
    if(!targetRecordId) return { ok: false, issues: ['تعذر تحديد الفاتورة المطلوب عكسها.'] };

    const salesState = readSalesPurchaseState();
    const currentRecords = Array.isArray(salesState.records) ? salesState.records : [];
    const targetRecord = currentRecords.find((record) => getSalesPurchaseRecordId(record) === targetRecordId) || null;
    if(!targetRecord) return { ok: false, issues: ['تعذر العثور على الفاتورة المحددة.'] };
    if(isSalesPurchaseRecordReversed(targetRecord)){
      return { ok: false, issues: ['هذه الفاتورة ملغاة مسبقاً ولا يمكن عكسها مرة ثانية.'] };
    }

    const entriesStateBeforeReverse = readEntriesStateForSalesPurchase();
    const hasPersistedAccounting = hasPersistedSalesPurchaseEntryRecord(targetRecord, entriesStateBeforeReverse);
    const reversedRecord = createReversedSalesPurchaseRecord(targetRecord);
    const nextSalesState = {
      ...salesState,
      records: currentRecords.map((record) => {
        return getSalesPurchaseRecordId(record) === targetRecordId
          ? reversedRecord
          : record;
      })
    };

    const persistedState = writeSalesPurchaseState(nextSalesState);
    const reversedEntriesState = buildEntriesStateWithReversedSalesPurchaseRecord(targetRecord, entriesStateBeforeReverse);
    writeEntriesStateForSalesPurchase(reversedEntriesState, { syncCashBoxes: true });
    if(!hasPersistedAccounting){
      const reverseDelta = invertSalesPurchaseCashDeltaMap(buildSalesPurchaseCashDeltaMapFromRecord(targetRecord));
      applySalesPurchaseCashDeltaMap(reverseDelta);
    }
    return { ok: true, record: reversedRecord, state: persistedState };
  }

  function requestReverseSalesPurchaseWindowRecord(entry){
    if(!entry || !entry.action || !entry.formState) return false;
    if(entry.isMutating) return false;
    const effectiveActionId = resolveSalesPurchaseEffectiveActionId(entry.action.id, entry.formState);
    const editingRecord = resolveSalesPurchaseNavigatorLinkedRecord(effectiveActionId, entry.formState);
    if(!editingRecord){
      entry.formState.alertIssues = ['زر إلغاء / عكس القيد يعمل فقط عند استعراض فاتورة سابقة.'];
      renderWindowForm(entry);
      return false;
    }
    if(isSalesPurchaseRecordReversed(editingRecord)){
      entry.formState.alertIssues = ['هذه الفاتورة ملغاة مسبقاً وأصبحت للعرض فقط.'];
      renderWindowForm(entry);
      return false;
    }

    openSalesPurchaseReverseConfirmDialog(editingRecord, () => {
      setSalesPurchaseWindowMutationBusy(entry, true, 'reverse');
      try {
        const result = reverseSalesPurchaseRecordById(editingRecord.id);
        if(!result.ok){
          entry.formState.alertIssues = Array.isArray(result.issues) && result.issues.length
            ? result.issues
            : ['تعذر عكس الفاتورة الحالية.'];
          renderWindowForm(entry);
          return;
        }

        const currentNavigator = ensureSalesPurchaseNavigatorState(entry.formState);
        const nextState = buildSalesPurchaseFormStateFromRecord(entry.action.id, result.record);
        const nextNavigator = ensureSalesPurchaseNavigatorState(nextState);
        nextNavigator.lookupValue = currentNavigator.lookupValue;
        nextNavigator.currentRecordIndex = currentNavigator.currentRecordIndex;
        nextNavigator.currentRecordId = toSafeText(result.record?.id);
        nextState.inlineNotice = { message: 'تم عكس وإلغاء هذه العملية.', tone: 'danger' };
        nextState.alertIssues = [];
        entry.formState = nextState;
        runtime.selectedRecordId = toSafeText(result.record?.id);
        refreshWorkbenchUi();
        renderWindowForm(entry, () => {
          const closeButton = entry.modal?.querySelector('.entries-actions [data-sales-purchase-action="close-window"]');
          if(closeButton instanceof HTMLElement) focusSalesPurchaseElement(closeButton);
        });
      } finally {
        setSalesPurchaseWindowMutationBusy(entry, false);
      }
    });
    return true;
  }


  function deleteSalesPurchaseWindowRecord(entry){
    if(!entry || !entry.action || !entry.formState) return { ok:false, issues:['تعذر حذف هذه الفاتورة حالياً.'] };
    const effectiveActionId = resolveSalesPurchaseEffectiveActionId(entry.action.id, entry.formState);
    const recordsBeforeDelete = getSalesPurchaseNavigatorRecords(effectiveActionId, null, entry.formState);
    const editingRecord = resolveSalesPurchaseNavigatorLinkedRecord(effectiveActionId, entry.formState, recordsBeforeDelete);
    if(!editingRecord) return { ok:false, issues:['يتاح هذا الزر فقط عند استعراض فاتورة سابقة.'] };
    const deletionResult = deleteSalesPurchaseRecordById(editingRecord.id, { focusWorkbench:false });
    if(!deletionResult.ok) return deletionResult;

    entry.formState = buildSalesPurchaseNewBlankFormState(entry.action.id, entry.formState);
    syncSalesPurchaseNavigatorBaseline(entry);
    entry.formState.alertIssues = [];

    renderWindowForm(entry, () => {
      const target = resolveSalesPurchasePreferredAmountFocus(entry, entry.modal)
        || entry.modal?.querySelector('[data-sales-purchase-field="amount"]')
        || entry.modal?.querySelector('.entries-actions [data-sales-purchase-action="close-window"]');
      if(target instanceof HTMLElement) focusSalesPurchaseElement(target);
    });
    return { ok:true, record:deletionResult.record };
  }

  function requestDeleteSalesPurchaseWindowRecord(entry){
    if(!entry || !entry.action || !entry.formState) return false;
    if(entry.isMutating) return false;
    const effectiveActionId = resolveSalesPurchaseEffectiveActionId(entry.action.id, entry.formState);
    const editingRecord = resolveSalesPurchaseNavigatorLinkedRecord(effectiveActionId, entry.formState);
    if(!editingRecord){
      entry.formState.alertIssues = ['زر الحذف يعمل فقط عند استعراض فاتورة سابقة.'];
      renderWindowForm(entry);
      return false;
    }
    openSalesPurchaseDeleteConfirmDialog(editingRecord, () => {
      setSalesPurchaseWindowMutationBusy(entry, true, 'delete');
      try {
        deleteSalesPurchaseWindowRecord(entry);
      } finally {
        setSalesPurchaseWindowMutationBusy(entry, false);
      }
    });
    return true;
  }

  function focusSalesPurchaseBoardSelectionTarget(){
    if(!(runtime.panel instanceof Element) || !runtime.panel.isConnected) return;
    const target = runtime.panel.querySelector('[data-sales-purchase-action="delete-selected-record"]:not([disabled])')
      || runtime.panel.querySelector('[data-sales-purchase-search="true"]');
    if(target instanceof HTMLElement) focusElementWithoutScroll(target);
  }

  function deleteSalesPurchaseRecordById(recordId = toSafeText(runtime.selectedRecordId), options = {}){
    const targetRecordId = toSafeText(recordId);
    const shouldFocusWorkbench = !(options && options.focusWorkbench === false);
    if(!targetRecordId) return { ok: false, issues: ['حدد بطاقة أولاً.'] };

    const state = readSalesPurchaseState();
    const currentRecords = Array.isArray(state.records) ? state.records : [];
    const targetRecord = currentRecords.find((record) => getSalesPurchaseRecordId(record) === targetRecordId) || null;
    if(!targetRecord){
      runtime.selectedRecordId = '';
      refreshWorkbenchUi();
      return { ok: false, issues: ['تعذر العثور على البطاقة المحددة.'] };
    }

    const nextSelectedRecordId = resolveNextSalesPurchaseSelectionAfterDeletion(currentRecords, targetRecordId, runtime.searchQuery);
    const nextState = {
      ...state,
      records: currentRecords.filter((record) => getSalesPurchaseRecordId(record) !== targetRecordId)
    };

    const entriesStateBeforeDelete = readEntriesStateForSalesPurchase();
    const hadPersistedAccounting = hasPersistedSalesPurchaseEntryRecord(targetRecord, entriesStateBeforeDelete);
    deleteSalesPurchaseLinkedEntryRecords(targetRecord);
    writeSalesPurchaseState(nextState);
    if(!hadPersistedAccounting && !isSalesPurchaseRecordReversed(targetRecord)){
      const reverseDelta = invertSalesPurchaseCashDeltaMap(buildSalesPurchaseCashDeltaMapFromRecord(targetRecord));
      applySalesPurchaseCashDeltaMap(reverseDelta);
    }
    runtime.selectedRecordId = nextSelectedRecordId;
    refreshWorkbenchUi();
    if(shouldFocusWorkbench){
      window.requestAnimationFrame(() => {
        focusSalesPurchaseBoardSelectionTarget();
      });
    }
    return { ok: true, record: targetRecord, nextSelectedRecordId };
  }

  function requestSelectedSalesPurchaseDeletion(){
    const selectedRecordId = toSafeText(runtime.selectedRecordId);
    if(!selectedRecordId) return;

    const state = readSalesPurchaseState();
    const targetRecord = (Array.isArray(state.records) ? state.records : []).find((record) => getSalesPurchaseRecordId(record) === selectedRecordId) || null;
    if(!targetRecord){
      runtime.selectedRecordId = '';
      refreshWorkbenchUi();
      return;
    }

    openSalesPurchaseDeleteConfirmDialog(targetRecord, () => {
      deleteSalesPurchaseRecordById(selectedRecordId);
    });
  }

  function refreshWorkbenchUi(panel = runtime.panel){
    if(!(panel instanceof HTMLElement)) return;
    const state = readSalesPurchaseState();
    const visibleRecords = filterSalesPurchaseRecordsForVisibleState(filterSalesPurchaseRecordsForCurrentView(state.records), runtime.searchQuery);
    const hasSelectedRecordVisible = visibleRecords.some((record) => getSalesPurchaseRecordId(record) === toSafeText(runtime.selectedRecordId));
    if(toSafeText(runtime.selectedRecordId) && !hasSelectedRecordVisible){
      runtime.selectedRecordId = '';
    }
    const stage = panel.querySelector('.sales-purchase-stage');
    if(stage instanceof HTMLElement){
      stage.innerHTML = renderSalesPurchaseMainArea(state.records, runtime.searchQuery);
    }
    updateSalesPurchaseDeleteActionButtonUi(panel);
    syncInlinePurchaseWorkspace(panel);
    if(typeof feature.syncSalesPurchaseSearchUi === 'function') feature.syncSalesPurchaseSearchUi();
  }

  function collectExecutionIssues(actionId, model, options = {}){
    const issues = [];
    const editingRecord = options && typeof options === 'object' ? options.editingRecord : null;
    const sourceSalesState = options && typeof options === 'object' && options.salesState
      ? options.salesState
      : readSalesPurchaseState();
    const validationEntriesState = editingRecord
      ? buildEntriesStateExcludingSalesPurchaseRecord(editingRecord)
      : readEntriesStateForSalesPurchase();
    const validationSalesState = editingRecord
      ? {
          ...sourceSalesState,
          records: (Array.isArray(sourceSalesState?.records) ? sourceSalesState.records : []).filter((record) => getSalesPurchaseRecordId(record) !== getSalesPurchaseRecordId(editingRecord))
        }
      : sourceSalesState;
    const isManualRateMode = String(model?.formState?.rateMode || 'auto').trim() === 'manual';
    const editedSide = normalizeSalesPurchaseEditedAmountField(model?.formState?.lastEditedAmountField);
    const rawAmountInputValue = Math.max(0, toNumber(model?.amountInputText || model?.amountText, 0));
    const rawCounterpartInputValue = Math.max(0, toNumber(model?.counterpartInputText || model?.counterpartAmountText, 0));

    if(!toSafeText(model?.cashAccountNo)) issues.push('اختر الصندوق النقدي أولاً.');

    if(editedSide === 'counterpart'){
      if(!(rawCounterpartInputValue > 0)) issues.push('أدخل مبلغاً مقابلاً صحيحاً.');
    }else if(!(rawAmountInputValue > 0)){
      issues.push(actionId === 'purchase' ? 'أدخل مبلغ شراء صحيحاً.' : 'أدخل مبلغ مبيع صحيحاً.');
    }

    if(!(Number(model?.activeRateValue) > 0)){
      issues.push(isManualRateMode ? 'أدخل سعر صرف يدوي صحيحاً.' : 'سعر الصرف غير متاح لهذا الزوج حالياً.');
    }

    if(editedSide === 'counterpart'){
      if(Number(model?.activeRateValue) > 0 && !(Number(model?.amountValue) > 0)){
        issues.push(actionId === 'purchase'
          ? 'تعذر احتساب مبلغ الشراء من المبلغ المقابل، راجع القيم المدخلة.'
          : 'تعذر احتساب مبلغ المبيع من المبلغ المقابل، راجع القيم المدخلة.');
      }
    }else if(!(Number(model?.counterpartAmountValue) > 0)){
      issues.push('تعذر احتساب المبلغ المقابل، راجع المبلغ والعملة المختارة.');
    }

    return [...issues, ...buildSalesPurchaseAccountingIssues(actionId, model, {
      entriesState: validationEntriesState,
      salesState: validationSalesState
    })];
  }

  function syncSalesPurchaseNavigatorBaseline(entry){
    if(!entry || !entry.formState || !entry.action) return;
    const navigator = ensureSalesPurchaseNavigatorState(entry.formState);
    if(navigator.currentRecordIndex !== null || toSafeText(navigator.currentRecordId)) return;
    entry.navigatorBaselineFormState = snapshotSalesPurchaseBaselineFormState(entry.formState, entry.action.id);
  }

  function restoreSalesPurchaseNavigatorBaseline(entry){
    if(!entry || !entry.action) return false;
    const baseline = entry.navigatorBaselineFormState && typeof entry.navigatorBaselineFormState === 'object'
      ? entry.navigatorBaselineFormState
      : createDefaultFormState(entry.action.id);
    entry.formState = snapshotSalesPurchaseBaselineFormState(baseline, entry.action.id);
    return true;
  }

  function detachSalesPurchaseNavigatorRecord(entry, { clearLookup = true, syncBaseline = false } = {}){
    if(!entry || !entry.formState) return false;
    const navigator = ensureSalesPurchaseNavigatorState(entry.formState);
    const hadActiveRecord = navigator.currentRecordIndex !== null || !!toSafeText(navigator.currentRecordId) || !!navigator.loadedRecordSnapshot;
    navigator.currentRecordIndex = null;
    navigator.currentRecordId = '';
    navigator.loadedRecordSnapshot = null;
    if(clearLookup) navigator.lookupValue = '';
    if(syncBaseline) syncSalesPurchaseNavigatorBaseline(entry);
    return hadActiveRecord;
  }


  function prepareSalesPurchaseFormMutation(entry, { clearLookup = true, syncBaseline = true } = {}){
    if(!entry || !entry.formState) return false;
    if(Array.isArray(entry.formState.alertIssues) && entry.formState.alertIssues.length){
      closeSalesPurchaseReviewDialog();
    }
    const navigator = ensureSalesPurchaseNavigatorState(entry.formState);
    if(toSafeText(navigator.currentRecordId)) return true;
    detachSalesPurchaseNavigatorRecord(entry, { clearLookup, syncBaseline:false });
    if(syncBaseline) syncSalesPurchaseNavigatorBaseline(entry);
    return true;
  }

  function loadSalesPurchaseNavigatorRecord(entry, targetIndex){
    if(!entry || !entry.action) return false;
    const effectiveActionId = resolveSalesPurchaseEffectiveActionId(entry.action.id, entry.formState);
    const records = getSalesPurchaseNavigatorRecords(effectiveActionId, null, entry.formState);
    if(targetIndex == null){
      return restoreSalesPurchaseNavigatorBaseline(entry);
    }
    if(!Number.isInteger(targetIndex) || targetIndex < 0 || targetIndex >= records.length) return false;
    const targetRecord = records[targetIndex];
    const nextState = buildSalesPurchaseFormStateFromRecord(entry.action.id, targetRecord);
    const navigator = ensureSalesPurchaseNavigatorState(nextState);
    navigator.lookupValue = String(targetIndex + 1);
    navigator.currentRecordIndex = targetIndex;
    navigator.currentRecordId = toSafeText(targetRecord?.id);
    entry.formState = nextState;
    return true;
  }

  function normalizeSourceRecordNumber(value){
    return toSafeText(value).toUpperCase();
  }

  function findSalesPurchaseSourceRecord(payload = {}){
    const state = readSalesPurchaseState();
    const records = Array.isArray(state.records) ? state.records : [];
    if(!records.length) return null;

    const actionId = payload && typeof payload === 'object' && payload.actionId
      ? normalizeInlineSalesPurchaseActionId(payload.actionId)
      : '';
    const recordId = toSafeText(payload?.recordId);
    const number = normalizeSourceRecordNumber(payload?.number || payload?.query);
    if(!recordId && !number) return null;

    const candidates = actionId
      ? records.filter((record) => normalizeInlineSalesPurchaseActionId(record?.type) === actionId)
      : records.slice();
    const fallbackCandidates = candidates.length ? candidates : records;

    return fallbackCandidates.find((record) => recordId && toSafeText(record?.id) === recordId)
      || fallbackCandidates.find((record) => number && normalizeSourceRecordNumber(record?.number) === number)
      || records.find((record) => recordId && toSafeText(record?.id) === recordId)
      || records.find((record) => number && normalizeSourceRecordNumber(record?.number) === number)
      || null;
  }

  function resolveSalesPurchaseSourceNavigatorIndex(actionId, record, entry = null){
    if(!record) return -1;
    const records = getSalesPurchaseNavigatorRecords(actionId, null, entry?.formState || null);
    const recordId = toSafeText(record?.id);
    const number = normalizeSourceRecordNumber(record?.number);
    return records.findIndex((candidate) => {
      const candidateId = toSafeText(candidate?.id);
      const candidateNumber = normalizeSourceRecordNumber(candidate?.number);
      return (recordId && candidateId === recordId) || (number && candidateNumber === number);
    });
  }

  function focusSalesPurchaseSourceRecord(payload = {}, panel = runtime.panel){
    const record = findSalesPurchaseSourceRecord(payload);
    if(!record) return false;

    const actionId = normalizeInlineSalesPurchaseActionId(record.type || payload?.actionId);
    runtime.inlineSalesPurchaseActiveActionId = actionId;
    runtime.selectedRecordId = toSafeText(record.id);

    const host = getInlinePurchaseWorkspaceHost(panel);
    if(!(host instanceof HTMLElement)) return false;

    const entry = ensureInlinePurchaseWorkspaceEntry(host, actionId);
    entry.action = getInlineSalesPurchaseAction(actionId);
    entry.isInlineWorkspace = true;
    entry.modal = host;

    const navigatorIndex = resolveSalesPurchaseSourceNavigatorIndex(actionId, record, entry);
    if(navigatorIndex >= 0){
      loadSalesPurchaseNavigatorRecord(entry, navigatorIndex);
    }else{
      const nextState = buildSalesPurchaseFormStateFromRecord(actionId, record);
      const navigator = ensureSalesPurchaseNavigatorState(nextState);
      navigator.currentRecordIndex = null;
      navigator.currentRecordId = toSafeText(record.id);
      navigator.lookupValue = '';
      entry.formState = nextState;
    }
    entry.formState.windowActionId = actionId;
    syncSalesPurchaseNavigatorBaseline(entry);

    renderWindowForm(entry, () => {
      updateSalesPurchaseRecordSelectionUi(panel);
      const target = entry.modal?.querySelector('[data-sales-purchase-nav="lookup"]')
        || entry.modal?.querySelector('[data-sales-purchase-action="execute-window"]')
        || entry.modal?.querySelector('input, button, textarea, select');
      if(target instanceof HTMLElement) focusSalesPurchaseElement(target);
    });
    updateSalesPurchaseDeleteActionButtonUi(panel);
    return true;
  }

  function navigateSalesPurchaseRecord(entry, direction){
    if(!entry || !entry.action || !entry.formState) return false;
    const effectiveActionId = resolveSalesPurchaseEffectiveActionId(entry.action.id, entry.formState);
    const records = getSalesPurchaseNavigatorRecords(effectiveActionId, null, entry.formState);
    const navigator = ensureSalesPurchaseNavigatorState(entry.formState);
    const currentIndex = resolveSalesPurchaseNavigatorActiveIndex(effectiveActionId, entry.formState, records);
    navigator.currentRecordIndex = currentIndex;
    if(!records.length) return false;

    if(direction === 'prev' || direction === 'prev10'){
      const step = direction === 'prev10' ? 10 : 1;
      const effectiveIndex = currentIndex == null ? records.length : currentIndex;
      const targetIndex = Math.max(0, effectiveIndex - step);
      if(targetIndex == effectiveIndex) return false;
      return loadSalesPurchaseNavigatorRecord(entry, targetIndex);
    }

    if(direction === 'next'){
      if(currentIndex == null) return false;
      if(currentIndex >= records.length - 1){
        return restoreSalesPurchaseNavigatorBaseline(entry);
      }
      return loadSalesPurchaseNavigatorRecord(entry, currentIndex + 1);
    }

    if(direction === 'next10'){
      if(currentIndex == null) return false;
      const targetIndex = Math.min(records.length - 1, currentIndex + 10);
      if(targetIndex === currentIndex) return false;
      return loadSalesPurchaseNavigatorRecord(entry, targetIndex);
    }

    return false;
  }

  function jumpSalesPurchaseToRecord(entry, lookupValue){
    if(!entry || !entry.action || !entry.formState) return false;
    const effectiveActionId = resolveSalesPurchaseEffectiveActionId(entry.action.id, entry.formState);
    const records = getSalesPurchaseNavigatorRecords(effectiveActionId, null, entry.formState);
    const navigator = ensureSalesPurchaseNavigatorState(entry.formState);
    navigator.lookupValue = normalizeSalesPurchasePageLookup(lookupValue);
    if(!navigator.lookupValue){
      return restoreSalesPurchaseNavigatorBaseline(entry);
    }
    const lookupNumber = Number(navigator.lookupValue);
    if(!Number.isFinite(lookupNumber) || lookupNumber < 1 || lookupNumber > records.length) return false;
    return loadSalesPurchaseNavigatorRecord(entry, lookupNumber - 1);
  }

  function getSalesPurchaseNavigatorFocusTarget(entry, actionName){
    if(!entry || !(entry.modal instanceof HTMLElement)) return null;
    const safeAction = String(actionName || '').trim();
    if(safeAction === 'lookup'){
      return entry.modal.querySelector('[data-sales-purchase-nav="lookup"]');
    }
    return entry.modal.querySelector(`[data-sales-purchase-nav="${safeAction}"]`)
      || entry.modal.querySelector(`[data-sales-purchase-nav="${safeAction.startsWith('next') ? 'next' : 'prev'}"]`);
  }

  function runSalesPurchaseNavigatorAction(entry, actionName){
    if(!entry || !entry.formState) return false;
    entry.formState.openPickerKey = null;
    entry.formState.datePickerOpen = false;
    entry.formState.datePickerView = 'days';

    const safeAction = String(actionName || '').trim();
    const didChange = safeAction === 'lookup'
      ? jumpSalesPurchaseToRecord(entry, ensureSalesPurchaseNavigatorState(entry.formState).lookupValue)
      : navigateSalesPurchaseRecord(entry, safeAction);

    if(!didChange) return false;

    renderWindowForm(entry, () => {
      const target = getSalesPurchaseNavigatorFocusTarget(entry, safeAction);
      if(target instanceof HTMLElement) focusSalesPurchaseElement(target);
    });
    return true;
  }


  function focusSalesPurchaseExecutionIssueTarget(entry, model){
    const firstField = !toSafeText(model?.cashAccountNo)
      ? entry.modal?.querySelector('[data-sales-purchase-action="toggle-picker"][data-sales-purchase-picker-key="cash-account"]')
      : (resolveSalesPurchasePreferredAmountFocus(entry, entry.modal) || entry.modal?.querySelector('[data-sales-purchase-action="toggle-picker"]'));
    if(firstField instanceof HTMLElement) focusSalesPurchaseElement(firstField);
  }

  function showSalesPurchaseExecutionIssues(entry, issues, model){
    entry.formState.alertIssues = Array.isArray(issues) && issues.length ? issues : ['تعذر تنفيذ العملية الحالية.'];
    renderWindowForm(entry, () => focusSalesPurchaseExecutionIssueTarget(entry, model));
    return false;
  }

  function focusSalesPurchaseWindowActionButton(entry, actionName){
    const button = entry.modal?.querySelector(`.entries-actions [data-sales-purchase-action="${actionName}"]`);
    if(button instanceof HTMLElement) focusSalesPurchaseElement(button);
    return button;
  }

  function showSalesPurchaseLockedRecordIssue(entry){
    entry.formState.alertIssues = ['هذه الفاتورة ملغاة / معكوسة وأصبحت للعرض فقط، لذلك لا يمكن تعديلها أو تنفيذها مرة أخرى.'];
    renderWindowForm(entry, () => focusSalesPurchaseWindowActionButton(entry, 'close-window'));
    return false;
  }

  function showSalesPurchaseNoChangesIssue(entry){
    entry.formState.alertIssues = ['لا توجد تعديلات جديدة لتطبيقها على هذه الفاتورة.'];
    renderWindowForm(entry, () => focusSalesPurchaseWindowActionButton(entry, 'execute-window'));
    return false;
  }

  function applySalesPurchaseEditedRecord(entry, context){
    const {
      model,
      salesState,
      editingRecord,
      previousEntriesStateBeforeAccounting,
      editingRecordHadPersistedAccounting,
      accountingResult
    } = context;

    const previousCashDelta = buildSalesPurchaseCashDeltaMapFromRecord(editingRecord);
    const updatedRecord = createUpdatedSalesPurchaseRecord(editingRecord, model, accountingResult, {
      ownerActionId: entry.action.id
    });
    const nextState = {
      ...salesState,
      records: (Array.isArray(salesState.records) ? salesState.records : []).map((record) => {
        return getSalesPurchaseRecordId(record) === getSalesPurchaseRecordId(editingRecord)
          ? updatedRecord
          : record;
      })
    };

    try{
      writeSalesPurchaseState(nextState);
    }catch(error){
      restoreSalesPurchaseAccountingStateSnapshot(previousEntriesStateBeforeAccounting, 'edit-write-failed');
      entry.formState.alertIssues = ['تعذر حفظ تعديل الفاتورة، وتم التراجع عن القيود المحاسبية الخاصة بمحاولة التعديل.'];
      renderWindowForm(entry);
      warnSalesPurchaseRecovery('فشل حفظ تعديل فاتورة الشراء/المبيع بعد إنشاء القيود.', error);
      return false;
    }

    if(!editingRecordHadPersistedAccounting){
      applySalesPurchaseCashDeltaMap(invertSalesPurchaseCashDeltaMap(previousCashDelta));
    }
    runtime.selectedRecordId = toSafeText(updatedRecord?.id);
    refreshWorkbenchUi();

    const currentNavigator = ensureSalesPurchaseNavigatorState(entry.formState);
    const nextFormState = buildSalesPurchaseFormStateFromRecord(entry.action.id, updatedRecord);
    const nextNavigator = ensureSalesPurchaseNavigatorState(nextFormState);
    nextNavigator.lookupValue = currentNavigator.lookupValue;
    nextNavigator.currentRecordIndex = currentNavigator.currentRecordIndex;
    nextNavigator.currentRecordId = toSafeText(updatedRecord?.id);
    nextFormState.inlineNotice = { message: 'تم تعديل هذه العملية.', tone: 'success' };
    nextFormState.alertIssues = [];
    entry.formState = nextFormState;

    renderWindowForm(entry, () => {
      focusSalesPurchaseWindowActionButton(entry, 'execute-window');
      openSalesPurchaseSuccessDialog('تم تنفيذ التعديل بنجاح', { anchor: entry.modal });
    });
    return true;
  }

  function applySalesPurchaseCreatedRecord(entry, context){
    const {
      effectiveActionId,
      model,
      salesState,
      previousEntriesStateBeforeAccounting,
      accountingResult
    } = context;

    const nextSequence = Math.max(0, Number(salesState.sequence) || 0) + 1;
    let result = null;
    try{
      result = appendSalesPurchaseRecord(effectiveActionId, model, {
        preloadedState: salesState,
        sequence: nextSequence,
        accounting: accountingResult,
        ownerActionId: entry.action.id
      });
    }catch(error){
      restoreSalesPurchaseAccountingStateSnapshot(previousEntriesStateBeforeAccounting, 'create-write-failed');
      entry.formState.alertIssues = ['تعذر حفظ الفاتورة، وتم التراجع عن القيود المحاسبية التي تم إنشاؤها لهذه المحاولة.'];
      renderWindowForm(entry);
      warnSalesPurchaseRecovery('فشل حفظ فاتورة الشراء/المبيع بعد إنشاء القيود.', error);
      return false;
    }

    const createdRecord = result?.record ? normalizeSalesPurchaseRecord(result.record) : null;
    if(!createdRecord){
      restoreSalesPurchaseAccountingStateSnapshot(previousEntriesStateBeforeAccounting, 'create-record-missing');
      entry.formState.alertIssues = ['تعذر تحميل الفاتورة المنفذة داخل النافذة الحالية، وتم التراجع عن القيود المحاسبية الخاصة بها.'];
      renderWindowForm(entry);
      return false;
    }

    runtime.selectedRecordId = toSafeText(createdRecord.id);
    resetSalesPurchaseRecordsPagination();
    refreshWorkbenchUi();

    entry.formState = buildSalesPurchaseNewBlankFormState(entry.action.id, entry.formState);
    syncSalesPurchaseNavigatorBaseline(entry);

    renderWindowForm(entry, () => {
      const amountField = resolveSalesPurchasePreferredAmountFocus(entry, entry.modal)
        || entry.modal?.querySelector('[data-sales-purchase-field="amount"]');
      if(amountField instanceof HTMLElement) focusSalesPurchaseElement(amountField);
      openSalesPurchaseSuccessDialog('تم تنفيذ العملية بنجاح', { anchor: entry.modal });
    });
    return true;
  }

  function executeWindowOperation(entry, options = {}){
    if(!entry || !entry.action || !entry.formState) return false;
    if(entry.isMutating) return false;

    const safeOptions = options && typeof options === 'object' ? options : {};
    const salesState = readSalesPurchaseState();
    const effectiveActionId = resolveSalesPurchaseEffectiveActionId(entry.action.id, entry.formState);
    const editingRecord = resolveSalesPurchaseNavigatorLinkedRecord(effectiveActionId, entry.formState, salesState.records);
    const model = resolveFormModel(effectiveActionId, entry.formState);
    setSalesPurchaseWindowMutationBusy(entry, true, editingRecord ? 'edit' : 'execute');

    try{
      if(editingRecord && isSalesPurchaseRecordReversed(editingRecord)){
        return showSalesPurchaseLockedRecordIssue(entry);
      }

      const issues = collectExecutionIssues(effectiveActionId, model, { editingRecord, salesState });
      if(issues.length){
        return showSalesPurchaseExecutionIssues(entry, issues, model);
      }

      if(shouldConfirmSalesPurchaseDifferentDateCreation(editingRecord, model, safeOptions)){
        const voucherDate = salesPurchaseNormalizeDateInputValue(model?.voucherDate || entry.formState.voucherDate);
        const todayValue = getSalesPurchaseRealTodayValue();
        openSalesPurchaseDifferentDateConfirmDialog({
          entry,
          actionId: effectiveActionId,
          voucherDate,
          todayValue,
          onConfirm: () => executeWindowOperation(entry, { allowDifferentDate:true })
        });
        return false;
      }

      if(editingRecord && !hasSalesPurchaseRecordChanged(editingRecord, model)){
        return showSalesPurchaseNoChangesIssue(entry);
      }

      const sourceNumber = editingRecord
        ? editingRecord.number
        : buildSalesPurchaseRecordNumber(Math.max(0, Number(salesState.sequence) || 0) + 1, effectiveActionId);
      const nextRevisionCount = editingRecord ? (Math.max(0, Number(editingRecord.revisionCount) || 0) + 1) : 0;
      const previousEntriesStateBeforeAccounting = readEntriesStateForSalesPurchase();
      const editingRecordHadPersistedAccounting = editingRecord
        ? hasPersistedSalesPurchaseEntryRecord(editingRecord, previousEntriesStateBeforeAccounting)
        : false;
      const accountingSource = buildSalesPurchaseAccountingSourceFromModel(effectiveActionId, model, sourceNumber, {
        sourceRecordId: editingRecord ? editingRecord.id : '',
        operationKind: editingRecord ? 'updated' : 'created',
        revisionCount: nextRevisionCount
      });
      const accountingResult = editingRecord
        ? upsertSalesPurchaseAccountingEntriesForRecord(editingRecord, accountingSource)
        : appendSalesPurchaseAccountingEntriesFromSource(accountingSource);

      if(!accountingResult.ok){
        const accountingIssues = Array.isArray(accountingResult.issues) && accountingResult.issues.length
          ? accountingResult.issues
          : ['تعذر تنفيذ الربط المحاسبي لهذه العملية.'];
        return showSalesPurchaseExecutionIssues(entry, accountingIssues, model);
      }

      entry.formState.alertIssues = [];

      const operationContext = {
        effectiveActionId,
        model,
        salesState,
        editingRecord,
        previousEntriesStateBeforeAccounting,
        editingRecordHadPersistedAccounting,
        accountingResult
      };

      return editingRecord
        ? applySalesPurchaseEditedRecord(entry, operationContext)
        : applySalesPurchaseCreatedRecord(entry, operationContext);
    } finally {
      setSalesPurchaseWindowMutationBusy(entry, false);
    }
  }

  function renderShell(){
    const activeActionId = resolveSalesPurchaseActionIdForCurrentView();
    ensureInlinePurchaseWorkspaceEntry(null, activeActionId);
    resetInlineSalesPurchaseDateDefaultsToToday(activeActionId);
    runtime.searchQuery = '';
    runtime.searchQueryDraft = '';
    resetSalesPurchaseRecordDateFiltersToToday();
    resetSalesPurchaseRecordsPagination({ resetPageSize: true });
    const state = readSalesPurchaseState();
    const activeTitle = getSalesPurchaseActionTitle(activeActionId);
    return `
      <div class="entries-workbench sales-purchase-workbench" aria-label="قسم ${escapeHtml(activeTitle)}">
        ${renderSalesPurchaseWorkspacePanels()}
        <section class="sales-purchase-records-box" aria-label="صندوق سجلات العمليات">
          <section class="sales-purchase-stage" aria-label="منطقة السجلات">${renderSalesPurchaseMainArea(state.records, '')}</section>
        </section>
      </div>
    `;
  }

  function resolveWorkspaceElement(){
    if(runtime.panel instanceof HTMLElement && runtime.panel.isConnected) return runtime.panel;
    return document.getElementById('panel') || document.querySelector('.content') || null;
  }

  function getModalManager(){
    const ownerView = resolveSalesPurchaseOwnerViewId();
    if(runtime.modalManager && runtime.modalManagerOwnerView === ownerView) return runtime.modalManager;

    if(runtime.modalManager && runtime.modalManagerOwnerView !== ownerView){
      try{ runtime.modalManager.cleanupModalRegistry?.(); }catch{}
      runtime.modalManager = null;
      runtime.modalManagerOwnerView = '';
    }

    if(typeof windowChrome.createModalWindowManager !== 'function') return null;

    runtime.modalManager = windowChrome.createModalWindowManager({
      runtime,
      layerSelector: '.sales-purchase-window-layer',
      layerClassName: 'sales-purchase-window-layer',
      backdropSelector: '.sales-purchase-modal-backdrop',
      modalSelector: '.sales-purchase-modal-window',
      dragHandleSelector: '.sales-purchase-sheet__head',
      dragBlockSelectors: '.sales-purchase-sheet__window-actions, button, input, textarea, select, option, a, [data-sales-purchase-action]',
      bodyDraggingClass: 'sales-purchase--dragging-window',
      getWorkspace: resolveWorkspaceElement,
      getCascadeSlotLimit: () => 4,
      onPositionApplied: handleSalesPurchaseModalPositionApplied,
      baseZIndex: 2398,
      ownerView
    });
    runtime.modalManagerOwnerView = ownerView;

    return runtime.modalManager;
  }

  function focusWindow(modal){
    if(!(modal instanceof HTMLElement)) return;
    requestAnimationFrame(() => {
      focusElementWithoutScroll(modal);
    });
  }

  function isSalesPurchaseElementVisible(element){
    return windowChrome.isElementVisible(element);
  }

  function focusSalesPurchaseElement(element){
    return windowChrome.focusElement(element) || focusElementWithoutScroll(element);
  }

  function triggerSalesPurchaseElementPress(element){
    return windowChrome.triggerElementPress(element);
  }

  function findSalesPurchaseDirectionalTarget(current, candidates, key){
    return windowChrome.findDirectionalTarget(current, candidates, key);
  }

  function normalizeSalesPurchaseFlow(root){
    if(root instanceof Element && typeof flowSystem.normalizeRoot === 'function'){
      try{ flowSystem.normalizeRoot(root); }catch{}
    }
  }

  function isSalesPurchaseFlowSkipped(element){
    return element instanceof Element
      && typeof flowSystem.isSkipped === 'function'
      && flowSystem.isSkipped(element);
  }

  function uniqueSalesPurchaseTargets(targets){
    const seen = new Set();
    return (Array.isArray(targets) ? targets : []).filter((element) => {
      if(!(element instanceof HTMLElement)) return false;
      if(seen.has(element)) return false;
      if(isSalesPurchaseFlowSkipped(element)) return false;
      if(!isSalesPurchaseElementVisible(element)) return false;
      seen.add(element);
      return true;
    });
  }

  function getSalesPurchasePickerTrigger(modal, pickerKey){
    if(!(modal instanceof HTMLElement)) return null;
    return modal.querySelector(`[data-sales-purchase-action="toggle-picker"][data-sales-purchase-picker-key="${String(pickerKey || '').trim()}"]`);
  }

  function getSalesPurchaseDateTrigger(modal){
    if(!(modal instanceof HTMLElement)) return null;
    return modal.querySelector('[data-sales-purchase-date-action="toggle"]');
  }

  function getSalesPurchaseFlowTargets(modal){
    if(!(modal instanceof HTMLElement)) return [];

    const partyTargets = Array.from(modal.querySelectorAll([
      '[data-sales-purchase-party-field]:not([disabled]):not([readonly])',
      '[data-sales-purchase-party-date-part]:not([disabled]):not([readonly])',
      '[data-sales-purchase-party-choice-trigger="true"]:not([disabled])',
      '[data-sales-purchase-party-date-trigger="true"]:not([disabled])',
      '[data-sales-purchase-party-segment][data-taif-flow-item="true"]:not([disabled])'
    ].join(',')));

    if(partyTargets.length){
      const partyFooterTargets = Array.from(modal.querySelectorAll('.entries-actions [data-sales-purchase-action="close-window"]:not([disabled])'));
      return uniqueSalesPurchaseTargets(partyTargets.concat(partyFooterTargets));
    }

    const targets = [
      modal.querySelector('[data-sales-purchase-nav="lookup"]'),
      modal.querySelector('[data-sales-purchase-nav="prev"]'),
      modal.querySelector('[data-sales-purchase-nav="prev10"]'),
      modal.querySelector('[data-sales-purchase-nav="next"]'),
      modal.querySelector('[data-sales-purchase-nav="next10"]'),
      getSalesPurchasePickerTrigger(modal, 'cash-account'),
      getSalesPurchaseDateTrigger(modal),
      modal.querySelector('[data-sales-purchase-field="invoice-summary"]'),
      modal.querySelector('[data-sales-purchase-field="counterparty-name"]'),
      modal.querySelector('[data-sales-purchase-action="open-party-window"]'),
      getSalesPurchasePickerTrigger(modal, 'buy-card'),
      getSalesPurchasePickerTrigger(modal, 'sell-card'),
      modal.querySelector('[data-sales-purchase-field="amount"]'),
      modal.querySelector('[data-sales-purchase-field="counterpart-amount"]'),
      modal.querySelector('[data-sales-purchase-field="manual-rate"]'),
      modal.querySelector('[data-sales-purchase-field="notes"]'),
      modal.querySelector('.entries-actions [data-sales-purchase-action="execute-window"]'),
      modal.querySelector('.entries-actions [data-sales-purchase-action="delete-window-record"]'),
      modal.querySelector('.entries-actions [data-sales-purchase-action="reverse-window-record"]'),
      modal.querySelector('.entries-actions [data-sales-purchase-action="open-new-window"]'),
      modal.querySelector('.entries-actions [data-sales-purchase-action="close-window"]')
    ];
    return uniqueSalesPurchaseTargets(targets);
  }

  function getSalesPurchaseFlowReference(modal, control){
    if(!(modal instanceof HTMLElement) || !(control instanceof HTMLElement) || !modal.contains(control)) return null;
    const choiceHost = control.closest('[data-sales-purchase-picker-host]');
    if(choiceHost instanceof HTMLElement){
      const trigger = choiceHost.querySelector('[data-sales-purchase-action="toggle-picker"]');
      if(trigger instanceof HTMLElement) return trigger;
    }
    const dateHost = control.closest('[data-sales-purchase-date-picker="true"]');
    if(dateHost instanceof HTMLElement){
      const trigger = dateHost.querySelector('[data-sales-purchase-date-action="toggle"]');
      if(trigger instanceof HTMLElement) return trigger;
    }
    const partyChoiceHost = control.closest('[data-sales-purchase-party-choice-picker]');
    if(partyChoiceHost instanceof HTMLElement){
      const trigger = partyChoiceHost.querySelector('[data-sales-purchase-party-choice-trigger="true"]');
      if(trigger instanceof HTMLElement) return trigger;
    }
    const partyDateHost = control.closest('[data-sales-purchase-party-date-picker]');
    if(partyDateHost instanceof HTMLElement){
      const trigger = partyDateHost.querySelector('[data-sales-purchase-party-date-trigger="true"]');
      if(trigger instanceof HTMLElement) return trigger;
    }
    return control;
  }

  function focusRelativeSalesPurchaseTarget(modal, current, step, { clamp = true, referenceElement = null } = {}){
    if(!(modal instanceof HTMLElement)) return false;
    const targets = getSalesPurchaseFlowTargets(modal);
    if(!targets.length) return false;
    const safeStep = step < 0 ? -1 : 1;
    const reference = referenceElement instanceof HTMLElement && modal.contains(referenceElement)
      ? referenceElement
      : getSalesPurchaseFlowReference(modal, current);
    const currentTarget = current instanceof HTMLElement && modal.contains(current) ? current : null;
    const currentIndex = reference ? targets.indexOf(reference) : targets.indexOf(currentTarget);
    let nextIndex = currentIndex === -1 ? (safeStep < 0 ? targets.length - 1 : 0) : currentIndex + safeStep;
    if(clamp) nextIndex = Math.max(0, Math.min(targets.length - 1, nextIndex));
    const nextTarget = targets[nextIndex] || reference || currentTarget || targets[0];
    return nextTarget instanceof HTMLElement ? focusSalesPurchaseElement(nextTarget) : false;
  }

  function resolveSalesPurchaseArrowGroup(modal, control){
    if(!(modal instanceof HTMLElement) || !(control instanceof HTMLElement) || !modal.contains(control)) return null;
    return control.closest([
      '.entries-voucher-choice-popover',
      '.entries-voucher-date__grid',
      '.entries-voucher-date__month-grid',
      '.entries-voucher-date__header',
      '.entries-voucher-date__footer',
      '.sales-purchase-topdock-layout',
      '.entries-voucher-navcluster',
      '.sales-purchase-deal__top-grid',
      '.sales-purchase-deal__rate-track',
      '.entries-actions',
      '.entries-actions__group',
      '.sales-purchase-sheet__window-actions'
    ].join(', '));
  }

  function collectSalesPurchaseArrowTargets(group){
    if(!(group instanceof HTMLElement)) return [];
    const candidates = Array.from(group.querySelectorAll('button:not([disabled]), [role="option"]:not([disabled])'));
    return candidates.filter((element, index) => element instanceof HTMLElement && isSalesPurchaseElementVisible(element) && group.contains(element) && candidates.indexOf(element) === index);
  }


  function focusSalesPurchaseChoiceOption(entry, pickerKey, placement = 'current'){
    if(!entry || !(entry.modal instanceof HTMLElement)) return false;
    const host = entry.modal.querySelector(`[data-sales-purchase-picker-host="${String(pickerKey || '').trim()}"]`);
    const popover = host instanceof HTMLElement ? host.querySelector('.entries-voucher-choice-popover') : null;
    if(!(popover instanceof HTMLElement)) return false;
    const buttons = collectSalesPurchaseArrowTargets(popover);
    if(!buttons.length) return false;
    const activeButton = buttons.find((button) => button.classList.contains('is-active') || button.getAttribute('aria-selected') === 'true' || button.getAttribute('aria-pressed') === 'true');
    const target = placement === 'last'
      ? buttons[buttons.length - 1]
      : (activeButton || buttons[0]);
    return focusSalesPurchaseElement(target);
  }

  function focusSalesPurchaseDateControl(entry, placement = 'current'){
    if(!entry || !(entry.modal instanceof HTMLElement)) return false;
    const host = entry.modal.querySelector('[data-sales-purchase-date-picker="true"]');
    if(!(host instanceof HTMLElement)) return false;
    const monthButtons = collectSalesPurchaseArrowTargets(host.querySelector('.entries-voucher-date__month-grid'));
    if(monthButtons.length){
      const activeMonth = monthButtons.find((button) => button.classList.contains('is-active') || button.getAttribute('aria-pressed') === 'true');
      const monthTarget = placement === 'last' ? monthButtons[monthButtons.length - 1] : (activeMonth || monthButtons[0]);
      return focusSalesPurchaseElement(monthTarget);
    }
    const dayButtons = collectSalesPurchaseArrowTargets(host.querySelector('.entries-voucher-date__grid'));
    if(dayButtons.length){
      const selectedDay = dayButtons.find((button) => button.classList.contains('is-selected') || button.getAttribute('aria-pressed') === 'true');
      const dayTarget = placement === 'last' ? dayButtons[dayButtons.length - 1] : (selectedDay || dayButtons[0]);
      return focusSalesPurchaseElement(dayTarget);
    }
    const footerButtons = collectSalesPurchaseArrowTargets(host.querySelector('.entries-voucher-date__footer'));
    if(footerButtons.length){
      const footerTarget = placement === 'last' ? footerButtons[footerButtons.length - 1] : footerButtons[0];
      return focusSalesPurchaseElement(footerTarget);
    }
    const trigger = getSalesPurchaseDateTrigger(entry.modal);
    return trigger instanceof HTMLElement ? focusSalesPurchaseElement(trigger) : false;
  }

  function focusSalesPurchaseInitialTarget(entry){
    if(!entry || !(entry.modal instanceof HTMLElement)) return false;
    if(entry.action?.id === 'party'){
      const partyNameField = entry.modal.querySelector('[data-sales-purchase-party-field="fullName"]');
      if(partyNameField instanceof HTMLElement && focusSalesPurchaseElement(partyNameField)) return true;
    }
    const explicitTarget = entry.modal.querySelector('[data-taif-initial-focus="true"]');
    if(explicitTarget instanceof HTMLElement && focusSalesPurchaseElement(explicitTarget)) return true;
    const firstTarget = getSalesPurchaseFlowTargets(entry.modal)[0] || null;
    if(firstTarget instanceof HTMLElement && focusSalesPurchaseElement(firstTarget)) return true;
    focusWindow(entry.modal);
    return false;
  }

  function toggleSalesPurchasePicker(entry, pickerKey, { placement = 'current' } = {}){
    if(!entry || !entry.formState) return;
    const safeKey = String(pickerKey || '').trim();
    const willOpen = entry.formState.openPickerKey !== safeKey;
    entry.formState.datePickerOpen = false;
    entry.formState.datePickerView = 'days';
    entry.formState.openPickerKey = willOpen ? safeKey : null;
    renderWindowForm(entry, () => {
      if(willOpen){
        if(focusSalesPurchaseChoiceOption(entry, safeKey, placement)) return;
      }
      const trigger = getSalesPurchasePickerTrigger(entry.modal, safeKey);
      if(trigger instanceof HTMLElement) focusSalesPurchaseElement(trigger);
    });
  }

  function toggleSalesPurchaseDatePicker(entry, { placement = 'current' } = {}){
    if(!entry || !entry.formState) return;
    const willOpen = !entry.formState.datePickerOpen;
    entry.formState.openPickerKey = null;
    entry.formState.datePickerOpen = willOpen;
    entry.formState.datePickerView = willOpen ? salesPurchaseNormalizeDatePickerView(entry.formState.datePickerView) : 'days';
    entry.formState.datePickerMonthCursor = salesPurchaseResolveMonthCursor(salesPurchaseNormalizeDateInputValue(entry.formState.voucherDate), entry.formState.datePickerMonthCursor);
    renderWindowForm(entry, () => {
      if(willOpen){
        if(focusSalesPurchaseDateControl(entry, placement)) return;
      }
      const trigger = getSalesPurchaseDateTrigger(entry.modal);
      if(trigger instanceof HTMLElement) focusSalesPurchaseElement(trigger);
    });
  }

  function resolveSalesPurchasePickerStepContext(entry, safeKey, model){
    if(safeKey === 'buy-card'){
      return {
        options: Array.isArray(model.buyOptions) ? model.buyOptions : [],
        currentValue: normalizeCurrencyCode(model.buyCurrency?.code),
        normalizeOption: (option) => normalizeCurrencyCode(option?.code),
        applySelection: (value) => {
          entry.formState.buyCurrencyCode = normalizeCurrencyCode(value);
          entry.formState.lastChangedPickerKey = 'buy-card';
        }
      };
    }
    if(safeKey === 'sell-card'){
      return {
        options: Array.isArray(model.sellOptions) ? model.sellOptions : [],
        currentValue: normalizeCurrencyCode(model.sellCurrency?.code),
        normalizeOption: (option) => normalizeCurrencyCode(option?.code),
        applySelection: (value) => {
          entry.formState.sellCurrencyCode = normalizeCurrencyCode(value);
          entry.formState.lastChangedPickerKey = 'sell-card';
        }
      };
    }
    if(safeKey === 'cash-account'){
      return {
        options: Array.isArray(model.cashAccountOptions) ? model.cashAccountOptions : [],
        currentValue: toSafeText(model.cashAccountNo),
        normalizeOption: (option) => toSafeText(option?.accountNo),
        applySelection: (value) => {
          entry.formState.cashAccountNo = toSafeText(value);
        }
      };
    }
    if(safeKey === 'purchase-calc-method'){
      return {
        options: getSalesPurchaseCalcMethodOptions(),
        currentValue: normalizeSalesPurchaseWorkspaceCalcMethod(entry.formState.purchaseCalcMethod),
        normalizeOption: (option) => normalizeSalesPurchaseWorkspaceCalcMethod(option?.value),
        applySelection: (value) => {
          entry.formState.purchaseCalcMethod = normalizeSalesPurchaseWorkspaceCalcMethod(value);
        }
      };
    }
    return null;
  }

  function normalizeSalesPurchasePickerStepOptions(context){
    return (Array.isArray(context?.options) ? context.options : [])
      .map((option) => ({
        raw: option,
        value: typeof context.normalizeOption === 'function' ? context.normalizeOption(option) : ''
      }))
      .filter((option) => option.value);
  }

  function resolveSalesPurchasePickerStepValue(options, currentValue, safeStep){
    if(!Array.isArray(options) || options.length < 2) return '';
    const currentIndex = options.findIndex((option) => option.value === currentValue);
    const nextIndex = currentIndex === -1
      ? (safeStep > 0 ? 0 : options.length - 1)
      : currentIndex + safeStep;
    return nextIndex < 0 || nextIndex >= options.length ? '' : options[nextIndex].value;
  }

  function commitSalesPurchasePickerStep(entry, safeKey, nextValue, applySelection){
    if(!nextValue || typeof applySelection !== 'function') return false;
    prepareSalesPurchaseFormMutation(entry, { clearLookup:true, syncBaseline:true });
    applySelection(nextValue);
    entry.formState.alertIssues = [];
    entry.formState.openPickerKey = null;
    renderWindowForm(entry, () => {
      const trigger = getSalesPurchasePickerTrigger(entry.modal, safeKey);
      if(trigger instanceof HTMLElement) focusSalesPurchaseElement(trigger);
    });
    return true;
  }

  function stepSalesPurchasePickerSelection(entry, pickerKey, step){
    if(!entry || !entry.formState) return false;
    const safeKey = String(pickerKey || '').trim();
    const safeStep = step < 0 ? -1 : 1;
    const model = resolveFormModel(entry.action?.id, entry.formState);
    const context = resolveSalesPurchasePickerStepContext(entry, safeKey, model);
    if(!context) return false;
    const normalizedOptions = normalizeSalesPurchasePickerStepOptions(context);
    const nextValue = resolveSalesPurchasePickerStepValue(normalizedOptions, context.currentValue, safeStep);
    return commitSalesPurchasePickerStep(entry, safeKey, nextValue, context.applySelection);
  }

  function isSalesPurchaseTextField(control){
    return control instanceof HTMLInputElement || control instanceof HTMLTextAreaElement;
  }

  function isSalesPurchaseFlowControl(control){
    if(!(control instanceof HTMLElement)) return false;
    if(isSalesPurchaseFlowSkipped(control)) return false;
    if(control.matches('[data-taif-flow-item="true"]')) return true;
    if(control.matches('[data-sales-purchase-party-field], [data-sales-purchase-party-date-part], [data-sales-purchase-party-choice-trigger="true"], [data-sales-purchase-party-date-trigger="true"], [data-sales-purchase-party-segment]')) return true;
    if(control.matches('[data-sales-purchase-nav]')) return true;
    if(control.matches('[data-sales-purchase-field]')) return true;
    if(control.matches('[data-sales-purchase-action="toggle-picker"]')) return true;
    if(control.matches('[data-sales-purchase-action="open-party-window"]')) return true;
    if(control.matches('[data-sales-purchase-date-action="toggle"]')) return true;
    if(control.matches('.entries-actions [data-sales-purchase-action="execute-window"], .entries-actions [data-sales-purchase-action="delete-window-record"], .entries-actions [data-sales-purchase-action="reverse-window-record"], .entries-actions [data-sales-purchase-action="close-window"], .entries-actions [data-sales-purchase-action="open-new-window"]')) return true;
    if(control.matches('[data-sales-purchase-action="select-currency"], [data-sales-purchase-action="select-cash-account"], [data-sales-purchase-action="select-purchase-calc-method"], [data-sales-purchase-date-action]:not([data-sales-purchase-date-action="toggle"])')) return true;
    return false;
  }

  function isSalesPurchasePopoverControl(control){
    return control instanceof HTMLElement && !!control.closest('.entries-voucher-choice-popover, .entries-voucher-date__popover');
  }

  function moveSalesPurchaseArrowFocus(modal, control, key){
    const group = resolveSalesPurchaseArrowGroup(modal, control);
    if(!(group instanceof HTMLElement)) return false;
    const candidates = collectSalesPurchaseArrowTargets(group);
    if(candidates.length < 2) return false;
    const nextTarget = findSalesPurchaseDirectionalTarget(control, candidates, key);
    if(!(nextTarget instanceof HTMLElement)) return false;
    return focusSalesPurchaseElement(nextTarget);
  }


  function resolveSalesPurchaseCashAccountSelection(formState, cashAccountOptions){
    const defaultCashAccount = resolveDefaultCashAccount(cashAccountOptions);
    let cashAccountNo = toSafeText(formState.cashAccountNo);
    let cashAccount = findAccountByNo(cashAccountNo, cashAccountOptions);
    if(!cashAccount){
      cashAccount = defaultCashAccount || cashAccountOptions[0] || null;
      cashAccountNo = cashAccount ? cashAccount.accountNo : '';
    }
    formState.cashAccountNo = cashAccountNo;
    return { cashAccountNo, cashAccount };
  }

  function syncSalesPurchaseDateModelState(formState){
    const voucherDate = salesPurchaseNormalizeDateInputValue(formState.voucherDate);
    formState.voucherDate = voucherDate;
    formState.datePickerOpen = !!formState.datePickerOpen;
    formState.datePickerView = salesPurchaseNormalizeDatePickerView(formState.datePickerView);
    formState.datePickerMonthCursor = salesPurchaseResolveMonthCursor(voucherDate, formState.datePickerMonthCursor);
    return voucherDate;
  }

  function resolveSalesPurchaseModelCurrencyState(actionId, formState, pairCodes, currencies){
    const buyCurrency = resolveCurrencyFromList(currencies, pairCodes.buyCurrencyCode)
      || currencies[0]
      || fallbackCurrencyOption();
    const sellCurrency = resolveCurrencyFromList(currencies, pairCodes.sellCurrencyCode)
      || resolveCurrencyFromList(currencies, pickCurrencyCode(currencies, [], [buyCurrency.code]))
      || buyCurrency;

    formState.buyCurrencyCode = normalizeCurrencyCode(buyCurrency.code);
    formState.sellCurrencyCode = normalizeCurrencyCode(sellCurrency.code);
    formState.lastChangedPickerKey = '';

    const tradeCurrency = actionId === 'purchase' ? buyCurrency : sellCurrency;
    const settlementCurrency = actionId === 'purchase' ? sellCurrency : buyCurrency;
    return { buyCurrency, sellCurrency, tradeCurrency, settlementCurrency };
  }

  function resolveSalesPurchaseLoadedModelState(actionId, formState, tradeCurrency, settlementCurrency){
    const navigatorState = ensureSalesPurchaseNavigatorState(formState);
    const loadedSnapshot = navigatorState.currentRecordIndex !== null
      && navigatorState.loadedRecordSnapshot
      && typeof navigatorState.loadedRecordSnapshot === 'object'
        ? navigatorState.loadedRecordSnapshot
        : null;
    const loadedRecord = resolveSalesPurchaseNavigatorLinkedRecord(actionId, formState);
    const useLoadedSnapshot = !!loadedSnapshot && !!loadedRecord;
    const loadedPairMatchesCurrentPair = !!loadedRecord
      && normalizeCurrencyCode(loadedRecord.tradeCurrencyCode) === normalizeCurrencyCode(tradeCurrency.code)
      && normalizeCurrencyCode(loadedRecord.settlementCurrencyCode) === normalizeCurrencyCode(settlementCurrency.code);

    return {
      navigatorState,
      loadedSnapshot,
      loadedRecord,
      useLoadedSnapshot,
      loadedPairMatchesCurrentPair
    };
  }

  function readSalesPurchaseOperationalQuote(snapshot, feature, tradeCurrency, settlementCurrency){
    return feature && typeof feature.readOperationalQuote === 'function'
      ? feature.readOperationalQuote(snapshot.state, tradeCurrency.code, settlementCurrency.code)
      : buildFallbackOperationalQuote(snapshot, tradeCurrency.code, settlementCurrency.code);
  }

  function normalizePositiveSalesPurchaseRate(value){
    const numericValue = Number(value);
    return Number.isFinite(numericValue) && numericValue > 0 ? numericValue : Number.NaN;
  }

  function normalizeSalesPurchaseUsdConvention(value, fallbackMethod = 'multiply'){
    const raw = String(value ?? '').trim().toLowerCase();
    if(raw === 'usd-base' || raw === 'usdbase' || raw === 'usd_per_currency') return 'usd-base';
    if(raw === 'currency-base' || raw === 'currencybase' || raw === 'currency_per_usd') return 'currency-base';
    return normalizeSalesPurchaseWorkspaceCalcMethod(fallbackMethod) === 'divide' ? 'usd-base' : 'currency-base';
  }

  function getSalesPurchaseSystemCurrencyCode(snapshot){
    return normalizeCurrencyCode(snapshot?.state?.systemCurrencyCode) || 'USD';
  }

  function readSalesPurchaseUsdAnchorQuote(snapshot, feature, currencyCode){
    const safeCode = normalizeCurrencyCode(currencyCode);
    const systemCode = getSalesPurchaseSystemCurrencyCode(snapshot);
    if(!safeCode) return null;
    if(safeCode === systemCode){
      return {
        baseCode: systemCode,
        quoteCode: systemCode,
        bid: 1,
        ask: 1,
        bidText: '1',
        askText: '1',
        usdConvention: 'identity'
      };
    }

    const apiQuote = feature && typeof feature.getUsdManualQuote === 'function'
      ? feature.getUsdManualQuote(snapshot.state, safeCode)
      : null;
    if(apiQuote){
      const apiBaseCode = normalizeCurrencyCode(apiQuote.baseCode);
      const apiQuoteCode = normalizeCurrencyCode(apiQuote.quoteCode);
      const apiBid = normalizePositiveSalesPurchaseRate(apiQuote.bid);
      const apiAsk = normalizePositiveSalesPurchaseRate(apiQuote.ask);
      if(apiBaseCode && apiQuoteCode && Number.isFinite(apiBid) && Number.isFinite(apiAsk)){
        return {
          baseCode: apiBaseCode,
          quoteCode: apiQuoteCode,
          bid: apiBid,
          ask: apiAsk,
          bidText: String(apiQuote.bidText || ''),
          askText: String(apiQuote.askText || ''),
          usdConvention: normalizeSalesPurchaseUsdConvention(apiQuote.usdConvention)
        };
      }
    }

    const currency = resolveCurrencyFromList(Array.isArray(snapshot?.currencies) ? snapshot.currencies : [], safeCode);
    if(!currency) return null;
    const convention = normalizeSalesPurchaseUsdConvention(currency.usdConvention, currency.method);
    const baseCode = convention === 'usd-base' ? systemCode : safeCode;
    const quoteCode = convention === 'usd-base' ? safeCode : systemCode;
    const bid = normalizePositiveSalesPurchaseRate(currency.ratioBuy);
    const ask = normalizePositiveSalesPurchaseRate(currency.ratioSell);
    if(!Number.isFinite(bid) || !Number.isFinite(ask)) return null;
    return {
      baseCode,
      quoteCode,
      bid,
      ask,
      bidText: String(currency.ratioBuyText || ''),
      askText: String(currency.ratioSellText || ''),
      usdConvention: convention
    };
  }

  function resolveSalesPurchaseRegisteredUsdRateModel({ actionId, snapshot, feature, tradeCurrency, settlementCurrency }){
    const tradeCode = normalizeCurrencyCode(tradeCurrency && tradeCurrency.code);
    const settlementCode = normalizeCurrencyCode(settlementCurrency && settlementCurrency.code);
    const systemCode = getSalesPurchaseSystemCurrencyCode(snapshot);
    if(!tradeCode || !settlementCode) return null;
    if(tradeCode === settlementCode){
      return {
        rateValue: 1,
        rateRawText: '1',
        calcMethod: 'multiply'
      };
    }

    const anchorCurrencyCode = tradeCode === systemCode
      ? settlementCode
      : (settlementCode === systemCode ? tradeCode : '');
    if(!anchorCurrencyCode) return null;

    const anchorQuote = readSalesPurchaseUsdAnchorQuote(snapshot, feature, anchorCurrencyCode);
    if(!anchorQuote) return null;

    const anchorBaseCode = normalizeCurrencyCode(anchorQuote.baseCode);
    const anchorQuoteCode = normalizeCurrencyCode(anchorQuote.quoteCode);
    const isSameDirection = anchorBaseCode === tradeCode && anchorQuoteCode === settlementCode;
    const isReverseDirection = anchorBaseCode === settlementCode && anchorQuoteCode === tradeCode;
    if(!isSameDirection && !isReverseDirection) return null;

    const rateSide = isSameDirection
      ? (actionId === 'purchase' ? 'bid' : 'ask')
      : (actionId === 'purchase' ? 'ask' : 'bid');
    const rateValue = normalizePositiveSalesPurchaseRate(anchorQuote[rateSide]);
    if(!Number.isFinite(rateValue)) return null;

    return {
      rateValue,
      rateRawText: String(anchorQuote[`${rateSide}Text`] || ''),
      calcMethod: isSameDirection ? 'multiply' : 'divide'
    };
  }

  function formatSalesPurchaseRateValue(rateValue, rawText, settlementCurrency, fallback = '—'){
    return Number.isFinite(rateValue) && rateValue > 0
      ? formatNumericValue(rateValue, {
          rawText,
          decimals: settlementCurrency.decimals,
          mode: 'rate',
          fallback
        })
      : fallback;
  }

  function resolveSalesPurchaseAutoRateModel({
    actionId,
    operationalQuote,
    snapshot,
    feature,
    tradeCurrency,
    settlementCurrency,
    loadedSnapshot,
    useLoadedSnapshot,
    loadedPairMatchesCurrentPair
  }){
    const normalizedBid = normalizePositiveSalesPurchaseRate(operationalQuote && operationalQuote.bid);
    const normalizedAsk = normalizePositiveSalesPurchaseRate(operationalQuote && operationalQuote.ask);
    const snapshotRateValue = useLoadedSnapshot ? Math.max(0, toNumber(loadedSnapshot.rateValue, 0)) : Number.NaN;
    const snapshotRateReady = useLoadedSnapshot && loadedPairMatchesCurrentPair && snapshotRateValue > 0;
    const registeredRate = snapshotRateReady
      ? null
      : resolveSalesPurchaseRegisteredUsdRateModel({
          actionId,
          snapshot,
          feature,
          tradeCurrency,
          settlementCurrency
        });

    const autoRateValue = snapshotRateReady
      ? snapshotRateValue
      : (registeredRate ? registeredRate.rateValue : (actionId === 'purchase' ? normalizedBid : normalizedAsk));
    const autoRateRawText = snapshotRateReady
      ? String(loadedSnapshot.rateText || '')
      : (registeredRate
          ? registeredRate.rateRawText
          : (actionId === 'purchase'
              ? String(operationalQuote && operationalQuote.bidText || '')
              : String(operationalQuote && operationalQuote.askText || '')));
    const calcMethod = snapshotRateReady
      ? normalizeSalesPurchaseWorkspaceCalcMethod(loadedSnapshot.purchaseCalcMethod)
      : (registeredRate ? registeredRate.calcMethod : 'multiply');

    return {
      snapshotRateValue,
      autoRateValue,
      autoRateRawText,
      autoRateText: formatSalesPurchaseRateValue(autoRateValue, autoRateRawText, settlementCurrency),
      calcMethod
    };
  }

  function resolveSalesPurchaseManualRateModel(formState, loadedSnapshot, useLoadedSnapshot){
    const manualRateText = sanitizeSalesPurchaseFormNumericText(
      formState.manualRateText
      || (useLoadedSnapshot && String(loadedSnapshot.rateMode || '').trim() === 'manual'
          ? (loadedSnapshot.manualRateText || loadedSnapshot.rateText || '')
          : '')
      || ''
    );
    const manualRateSelected = String(
      formState.rateMode
      || (useLoadedSnapshot && String(loadedSnapshot.rateMode || '').trim() === 'manual' ? 'manual' : 'auto')
      || 'auto'
    ).trim() === 'manual';
    return {
      manualRateText,
      manualRateValue: Math.max(0, toNumber(manualRateText, 0)),
      manualRateSelected
    };
  }

  function resolveSalesPurchaseRateModel({
    actionId,
    formState,
    snapshot,
    feature,
    tradeCurrency,
    settlementCurrency,
    loadedSnapshot,
    useLoadedSnapshot,
    loadedPairMatchesCurrentPair
  }){
    const operationalQuote = readSalesPurchaseOperationalQuote(snapshot, feature, tradeCurrency, settlementCurrency);
    const autoRate = resolveSalesPurchaseAutoRateModel({
      actionId,
      operationalQuote,
      snapshot,
      feature,
      tradeCurrency,
      settlementCurrency,
      loadedSnapshot,
      useLoadedSnapshot,
      loadedPairMatchesCurrentPair
    });
    const manualRate = resolveSalesPurchaseManualRateModel(formState, loadedSnapshot, useLoadedSnapshot);
    const activeRateValue = manualRate.manualRateSelected ? manualRate.manualRateValue : autoRate.autoRateValue;
    const activeRateRawText = manualRate.manualRateSelected ? manualRate.manualRateText : autoRate.autoRateRawText;
    const hasActiveRate = Number.isFinite(activeRateValue) && activeRateValue > 0;
    const calcMethod = manualRate.manualRateSelected
      ? normalizeSalesPurchaseWorkspaceCalcMethod(formState.purchaseCalcMethod)
      : normalizeSalesPurchaseWorkspaceCalcMethod(autoRate.calcMethod);
    formState.purchaseCalcMethod = calcMethod;

    return {
      snapshotRateValue: autoRate.snapshotRateValue,
      autoRateValue: autoRate.autoRateValue,
      autoRateText: autoRate.autoRateText,
      activeRateValue,
      activeRateText: hasActiveRate
        ? formatSalesPurchaseRateValue(activeRateValue, activeRateRawText, settlementCurrency)
        : (manualRate.manualRateSelected ? '' : '—'),
      hasActiveRate,
      manualRateText: manualRate.manualRateText,
      manualRateSelected: manualRate.manualRateSelected,
      calcMethod
    };
  }

  function resolveSalesPurchaseAmountSources(formState, loadedSnapshot, useLoadedSnapshot){
    const lastEditedAmountField = normalizeSalesPurchaseEditedAmountField(
      formState.lastEditedAmountField
      || (useLoadedSnapshot ? loadedSnapshot.amountEntrySide : '')
    );
    const amountText = sanitizeSalesPurchaseFormNumericText(
      formState.amountText
      || (useLoadedSnapshot ? (toSafeText(loadedSnapshot.amountText) || String(loadedSnapshot.amountValue || '')) : '')
      || ''
    );
    const counterpartText = sanitizeSalesPurchaseFormNumericText(
      formState.counterpartText
      || (useLoadedSnapshot ? (toSafeText(loadedSnapshot.counterpartAmountText) || String(loadedSnapshot.counterpartAmountValue || '')) : '')
      || ''
    );
    const amountValue = Math.max(0, toNumber(amountText, useLoadedSnapshot ? toNumber(loadedSnapshot.amountValue, 0) : 0));
    const counterpartValue = Math.max(0, toNumber(counterpartText, useLoadedSnapshot ? toNumber(loadedSnapshot.counterpartAmountValue, 0) : 0));
    return { lastEditedAmountField, amountText, counterpartText, amountValue, counterpartValue };
  }

  function computeSalesPurchaseAmountPair({ lastEditedAmountField, amountValue, counterpartValue, hasActiveRate, activeRateValue, calcMethod }){
    if(lastEditedAmountField === 'counterpart'){
      return {
        amountValue: hasActiveRate
          ? (calcMethod === 'divide' ? (counterpartValue * activeRateValue) : (counterpartValue / activeRateValue))
          : 0,
        counterpartAmountValue: counterpartValue
      };
    }
    return {
      amountValue,
      counterpartAmountValue: hasActiveRate
        ? (calcMethod === 'divide' ? (amountValue / activeRateValue) : (amountValue * activeRateValue))
        : Number.NaN
    };
  }

  function shouldPreserveSalesPurchaseLoadedAmounts({
    lastEditedAmountField,
    loadedSnapshot,
    useLoadedSnapshot,
    loadedPairMatchesCurrentPair,
    snapshotRateValue,
    manualRateSelected,
    activeRateValue,
    amountSourceValue,
    counterpartSourceValue,
    snapshotAmountValue,
    snapshotCounterpartAmountValue
  }){
    if(!useLoadedSnapshot || !loadedPairMatchesCurrentPair) return false;
    const loadedRateModeMatchesCurrent = !manualRateSelected
      ? String(loadedSnapshot && loadedSnapshot.rateMode || 'auto').trim() !== 'manual'
      : (String(loadedSnapshot && loadedSnapshot.rateMode || '').trim() === 'manual'
          && Math.abs(snapshotRateValue - activeRateValue) <= SALES_PURCHASE_BALANCE_EPSILON);
    if(!loadedRateModeMatchesCurrent) return false;
    if(lastEditedAmountField === 'counterpart'){
      return Number.isFinite(snapshotCounterpartAmountValue)
        && Math.abs(snapshotCounterpartAmountValue - counterpartSourceValue) <= SALES_PURCHASE_BALANCE_EPSILON;
    }
    return Number.isFinite(snapshotAmountValue)
      && Math.abs(snapshotAmountValue - amountSourceValue) <= SALES_PURCHASE_BALANCE_EPSILON;
  }

  function formatSalesPurchaseAmountModelTexts({
    lastEditedAmountField,
    amountSourceText,
    counterpartSourceText,
    amountValue,
    counterpartAmountValue,
    hasActiveRate,
    counterpartSourceValue,
    tradeCurrency,
    settlementCurrency
  }){
    const amountDisplayText = (lastEditedAmountField === 'counterpart' && !hasActiveRate && counterpartSourceValue > 0)
      ? '—'
      : formatNumericValue(amountValue, {
          rawText: lastEditedAmountField === 'amount' ? amountSourceText : '',
          decimals: tradeCurrency.decimals,
          mode: 'standard',
          fallback: '0'
        });

    const counterpartFallbackText = counterpartSourceText
      ? counterpartSourceText
      : (amountValue > 0 ? '—' : '0');
    const counterpartAmountText = Number.isFinite(counterpartAmountValue)
      ? formatNumericValue(counterpartAmountValue, {
          rawText: lastEditedAmountField === 'counterpart' ? counterpartSourceText : '',
          decimals: settlementCurrency.decimals,
          mode: 'standard',
          fallback: counterpartFallbackText
        })
      : counterpartFallbackText;

    return {
      amountDisplayText,
      counterpartAmountText,
      amountInputText: lastEditedAmountField === 'amount'
        ? amountSourceText
        : (amountDisplayText === '—' ? '' : sanitizeNumericInput(amountDisplayText)),
      counterpartInputText: lastEditedAmountField === 'counterpart'
        ? counterpartSourceText
        : (counterpartAmountText === '—' ? '' : sanitizeNumericInput(counterpartAmountText))
    };
  }

  function resolveSalesPurchaseAmountModel({
    formState,
    loadedSnapshot,
    useLoadedSnapshot,
    loadedPairMatchesCurrentPair,
    snapshotRateValue,
    manualRateSelected,
    activeRateValue,
    hasActiveRate,
    calcMethod,
    tradeCurrency,
    settlementCurrency
  }){
    const amountSources = resolveSalesPurchaseAmountSources(formState, loadedSnapshot, useLoadedSnapshot);
    let { amountValue, counterpartAmountValue } = computeSalesPurchaseAmountPair({
      lastEditedAmountField: amountSources.lastEditedAmountField,
      amountValue: amountSources.amountValue,
      counterpartValue: amountSources.counterpartValue,
      hasActiveRate,
      activeRateValue,
      calcMethod
    });

    const snapshotAmountValue = useLoadedSnapshot
      ? Math.max(0, toNumber(loadedSnapshot.amountValue, 0))
      : Number.NaN;
    const snapshotCounterpartAmountValue = useLoadedSnapshot
      ? toNumber(loadedSnapshot.counterpartAmountValue, Number.NaN)
      : Number.NaN;

    const preserveLoadedAmounts = shouldPreserveSalesPurchaseLoadedAmounts({
      lastEditedAmountField: amountSources.lastEditedAmountField,
      loadedSnapshot,
      useLoadedSnapshot,
      loadedPairMatchesCurrentPair,
      snapshotRateValue,
      manualRateSelected,
      activeRateValue,
      amountSourceValue: amountSources.amountValue,
      counterpartSourceValue: amountSources.counterpartValue,
      snapshotAmountValue,
      snapshotCounterpartAmountValue
    });

    if(preserveLoadedAmounts && Number.isFinite(snapshotAmountValue) && Number.isFinite(snapshotCounterpartAmountValue)){
      amountValue = Math.max(0, snapshotAmountValue);
      counterpartAmountValue = Math.max(0, snapshotCounterpartAmountValue);
    }

    const formattedTexts = formatSalesPurchaseAmountModelTexts({
      lastEditedAmountField: amountSources.lastEditedAmountField,
      amountSourceText: amountSources.amountText,
      counterpartSourceText: amountSources.counterpartText,
      amountValue,
      counterpartAmountValue,
      hasActiveRate,
      counterpartSourceValue: amountSources.counterpartValue,
      tradeCurrency,
      settlementCurrency
    });

    return {
      amountText: amountSources.amountText,
      counterpartText: amountSources.counterpartText,
      lastEditedAmountField: amountSources.lastEditedAmountField,
      amountValue,
      counterpartAmountValue,
      ...formattedTexts
    };
  }

  function resolveSalesPurchaseFieldLabelModel(actionId, tradeCurrency, settlementCurrency){
    const buyCardCaption = actionId === 'purchase' ? 'العملة المشتراة' : 'العملة المقبوضة';
    const sellCardCaption = actionId === 'purchase' ? 'العملة المدفوع بها' : 'العملة المباعة';
    const amountLabelBase = actionId === 'purchase' ? 'إجمالي مبلغ الشراء' : 'إجمالي مبلغ المبيع';
    const counterpartLabelBase = actionId === 'purchase' ? 'المبلغ المدفوع' : 'المبلغ المقبوض';
    const amountLabel = `${amountLabelBase} (${tradeCurrency.code || ''})`.trim();
    const counterpartLabel = `${counterpartLabelBase} (${settlementCurrency.code || ''})`.trim();
    return { buyCardCaption, sellCardCaption, amountLabel, counterpartLabel };
  }

  function resolveSalesPurchaseCurrencyOptionModel(currencies, buyCurrency, sellCurrency){
    const buyOptions = currencies.filter((currency) => normalizeCurrencyCode(currency && currency.code) !== normalizeCurrencyCode(sellCurrency.code));
    const sellOptions = currencies.filter((currency) => normalizeCurrencyCode(currency && currency.code) !== normalizeCurrencyCode(buyCurrency.code));
    return {
      buyOptions: buyOptions.length ? buyOptions : [buyCurrency],
      sellOptions: sellOptions.length ? sellOptions : [sellCurrency]
    };
  }

  function resolveFormModel(actionId, formStateInput){
    const formState = formStateInput && typeof formStateInput === 'object' ? formStateInput : createDefaultFormState(actionId);
    const snapshot = getCurrencySnapshot();
    const currencies = Array.isArray(snapshot.currencies) ? snapshot.currencies : [fallbackCurrencyOption()];
    const feature = snapshot.feature;
    const activeBook = snapshot.activeBook || { code:'MAIN', label:'السعر الرئيسي' };
    const pairCodes = resolveDistinctPairCodes(snapshot, actionId, formState);
    const cashAccountOptions = readAccountCatalog();
    const { cashAccountNo, cashAccount } = resolveSalesPurchaseCashAccountSelection(formState, cashAccountOptions);
    const voucherDate = syncSalesPurchaseDateModelState(formState);
    const {
      buyCurrency,
      sellCurrency,
      tradeCurrency,
      settlementCurrency
    } = resolveSalesPurchaseModelCurrencyState(actionId, formState, pairCodes, currencies);
    const loadedState = resolveSalesPurchaseLoadedModelState(actionId, formState, tradeCurrency, settlementCurrency);
    const rateModel = resolveSalesPurchaseRateModel({
      actionId,
      formState,
      snapshot,
      feature,
      tradeCurrency,
      settlementCurrency,
      loadedSnapshot:loadedState.loadedSnapshot,
      useLoadedSnapshot:loadedState.useLoadedSnapshot,
      loadedPairMatchesCurrentPair:loadedState.loadedPairMatchesCurrentPair
    });
    const amountModel = resolveSalesPurchaseAmountModel({
      formState,
      loadedSnapshot:loadedState.loadedSnapshot,
      useLoadedSnapshot:loadedState.useLoadedSnapshot,
      loadedPairMatchesCurrentPair:loadedState.loadedPairMatchesCurrentPair,
      snapshotRateValue:rateModel.snapshotRateValue,
      manualRateSelected:rateModel.manualRateSelected,
      activeRateValue:rateModel.activeRateValue,
      hasActiveRate:rateModel.hasActiveRate,
      calcMethod:rateModel.calcMethod,
      tradeCurrency,
      settlementCurrency
    });
    const labels = resolveSalesPurchaseFieldLabelModel(actionId, tradeCurrency, settlementCurrency);
    const currencyOptions = resolveSalesPurchaseCurrencyOptionModel(currencies, buyCurrency, sellCurrency);

    formState.amountText = amountModel.amountText;
    formState.counterpartText = amountModel.counterpartText;
    formState.manualRateText = rateModel.manualRateText;
    formState.lastEditedAmountField = amountModel.lastEditedAmountField;

    const lockedRecord = loadedState.loadedRecord && isSalesPurchaseRecordReversed(loadedState.loadedRecord)
      ? loadedState.loadedRecord
      : null;

    return {
      actionId,
      feature,
      snapshot,
      formState,
      navigatorState: loadedState.navigatorState,
      loadedRecord: loadedState.loadedRecord,
      lockedRecord,
      isLocked: !!lockedRecord,
      buyCurrency,
      sellCurrency,
      tradeCurrency,
      settlementCurrency,
      buyOptions: currencyOptions.buyOptions,
      sellOptions: currencyOptions.sellOptions,
      activeBook,
      cashAccountNo,
      cashAccount,
      cashAccountOptions,
      voucherDate,
      amountText: amountModel.amountText,
      amountInputText: amountModel.amountInputText,
      amountValue: amountModel.amountValue,
      amountDisplayText: amountModel.amountDisplayText,
      counterpartInputText: amountModel.counterpartInputText,
      counterpartAmountValue: amountModel.counterpartAmountValue,
      counterpartAmountText: amountModel.counterpartAmountText,
      activeRateValue: rateModel.activeRateValue,
      activeRateText: rateModel.activeRateText,
      calcMethod: rateModel.calcMethod,
      autoRateValue: rateModel.autoRateValue,
      autoRateText: rateModel.autoRateText,
      hasActiveRate: rateModel.hasActiveRate,
      manualRateText: rateModel.manualRateText,
      manualRateSelected: rateModel.manualRateSelected,
      lastEditedAmountField: amountModel.lastEditedAmountField,
      amountLabel: labels.amountLabel,
      counterpartLabel: labels.counterpartLabel,
      rateFieldLabel: 'سعر الصرف',
      buyCardCaption: labels.buyCardCaption,
      sellCardCaption: labels.sellCardCaption,
      buyCardFigureText: actionId === 'purchase' ? amountModel.amountDisplayText : amountModel.counterpartAmountText,
      sellCardFigureText: actionId === 'purchase' ? amountModel.counterpartAmountText : amountModel.amountDisplayText
    };
  }


  function renderCurrencyOption(optionCurrency, activeCode, feature, pickerKey){
    const safeCode = normalizeCurrencyCode(optionCurrency && optionCurrency.code);
    const isActive = safeCode === normalizeCurrencyCode(activeCode);
    const flagMarkup = feature && typeof feature.createFlagImageMarkup === 'function'
      ? feature.createFlagImageMarkup(optionCurrency, { className: 'entries-voucher-choice-picker__flag-image' })
      : '';
    return `
      <button class="entries-voucher-choice-popover__option${isActive ? ' is-active' : ''}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-taif-inline-picker-option="true" role="option" data-sales-purchase-action="select-currency" data-sales-purchase-picker-key="${escapeHtml(pickerKey)}" data-sales-purchase-currency-option="${escapeHtml(safeCode)}" aria-selected="${isActive ? 'true' : 'false'}" aria-pressed="${isActive ? 'true' : 'false'}">
        <span class="entries-voucher-choice-popover__check" aria-hidden="true">${isActive ? '<svg viewBox="0 0 20 20" focusable="false"><path d="m4 10 4 4 8-8" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"></path></svg>' : ''}</span>
        <span class="entries-voucher-choice-picker__value-layout entries-voucher-choice-picker__value-layout--with-flag">
          <span class="entries-voucher-choice-picker__meta-group">
            <span class="entries-voucher-choice-picker__flag" aria-hidden="true">${flagMarkup}</span>
          </span>
          <span class="entries-voucher-choice-popover__label" data-taif-dropdown-label="true">${escapeHtml(optionCurrency && optionCurrency.name || safeCode)}</span>
        </span>
      </button>
    `;
  }


  function renderCurrencyPicker({ selectedCurrency, options, feature, pickerKey, caption, openPickerKey }){
    const safeSelectedCurrency = selectedCurrency || fallbackCurrencyOption();
    const flagMarkup = feature && typeof feature.createFlagImageMarkup === 'function'
      ? feature.createFlagImageMarkup(safeSelectedCurrency, { className: 'entries-voucher-choice-picker__flag-image' })
      : '';
    const currencies = Array.isArray(options) && options.length ? options : [safeSelectedCurrency];
    const isOpen = openPickerKey === pickerKey;

    return `
      <div class="entries-voucher-choice-picker sales-purchase-currency-picker${isOpen ? ' is-open' : ''}" data-sales-purchase-picker-host="${escapeHtml(pickerKey)}" data-taif-inline-picker-host="true">
        <button class="sales-purchase-rate-card__currency-trigger" type="button" data-taif-picker-trigger="true" data-sales-purchase-action="toggle-picker" data-sales-purchase-picker-key="${escapeHtml(pickerKey)}" aria-haspopup="listbox" aria-expanded="${isOpen ? 'true' : 'false'}">
          <span class="sales-purchase-rate-card__currency-icon" aria-hidden="true">${getChevronDownIcon()}</span>
          <span class="sales-purchase-rate-card__currency-stack">
            <span class="sales-purchase-rate-card__currency-caption">${escapeHtml(caption)}</span>
            <span class="sales-purchase-rate-card__currency-line">
              <span class="sales-purchase-rate-card__currency-flag" aria-hidden="true">${flagMarkup}</span>
              <span class="sales-purchase-rate-card__currency-name">${wrapControlTextMarkup(`${escapeHtml(safeSelectedCurrency.name || safeSelectedCurrency.code)} <b>(${escapeHtml(safeSelectedCurrency.code || '')})</b>`, 'taif-control-text--ltr')}</span>
            </span>
          </span>
        </button>
        <div class="entries-voucher-choice-popover sales-purchase-currency-popover" data-taif-dropdown-popup="true" data-taif-dropdown-layout="list" data-taif-inline-picker="true" role="listbox"${isOpen ? '' : ' hidden'}>
          ${currencies.map((currency) => renderCurrencyOption(currency, safeSelectedCurrency.code, feature, pickerKey)).join('')}
        </div>
      </div>
    `;
  }


  function renderRateCard({ tone = 'buy', title = '', caption = '', figureText = '0', selectedCurrency, options, feature, pickerKey, openPickerKey }){
    return `
      <article class="sales-purchase-rate-card sales-purchase-rate-card--${escapeHtml(tone)}">
        <header class="sales-purchase-rate-card__head">
          <span class="sales-purchase-rate-card__title">${escapeHtml(title)}</span>
          <span class="sales-purchase-rate-card__figure" data-sales-purchase-display="${escapeHtml(pickerKey)}-figure">${wrapControlTextMarkup(escapeHtml(figureText || '0'), 'taif-control-text--ltr')}</span>
        </header>
        <div class="sales-purchase-rate-card__body">
          ${renderCurrencyPicker({ selectedCurrency, options, feature, pickerKey, caption, openPickerKey })}
        </div>
      </article>
    `;
  }


  function getSalesPurchaseNavigatorRenderState(actionId, formState){
    const records = getSalesPurchaseNavigatorRecords(actionId, null, formState);
    const navigator = ensureSalesPurchaseNavigatorState(formState);
    const currentIndex = resolveSalesPurchaseNavigatorActiveIndex(actionId, formState, records);
    if(currentIndex == null){
      navigator.currentRecordIndex = null;
      navigator.currentRecordId = '';
      if(!navigator.loadedRecordSnapshot || typeof navigator.loadedRecordSnapshot !== 'object'){
        navigator.loadedRecordSnapshot = null;
      }
    }else{
      navigator.currentRecordIndex = currentIndex;
      const activeRecord = records[currentIndex] || null;
      if(activeRecord) navigator.currentRecordId = toSafeText(activeRecord.id);
    }
    return {
      count: records.length,
      lookupValue: String(navigator.lookupValue || ''),
      canPrev: !!records.length && currentIndex !== 0,
      canNext: !!records.length && currentIndex !== null,
      currentIndex
    };
  }

  function renderSalesPurchaseTopDockNavStack({ title = '', stackClass = '', hiddenTitle = false, content = '' } = {}){
    const safeTitle = title ? escapeHtml(title) : '&nbsp;';
    const titleClass = ['entries-voucher-rail__title', 'entries-voucher-navstack__title', hiddenTitle ? 'entries-voucher-navstack__title--ghost' : ''].filter(Boolean).join(' ');
    const wrapperClass = ['entries-voucher-navstack', stackClass].filter(Boolean).join(' ');
    return `
      <div class="${wrapperClass}">
        <span class="${titleClass}"${hiddenTitle ? ' aria-hidden="true"' : ''}>${safeTitle}</span>
        ${content}
      </div>
    `;
  }

  function renderSalesPurchaseNavIconButton({ action = '', label = '', icon = '', jumpLabel = '', disabled = false } = {}){
    const classes = ['entries-voucher-navicon', jumpLabel ? 'entries-voucher-navicon--jump' : ''].filter(Boolean).join(' ');
    return `
      <button class="${classes}" type="button" data-sales-purchase-nav="${escapeHtml(action)}" aria-label="${escapeHtml(label)}" title="${escapeHtml(label)}" ${disabled ? 'disabled' : ''}>
        <span class="entries-voucher-navicon__glyph" aria-hidden="true">${icon}</span>
        ${jumpLabel ? `<span class="entries-voucher-navicon__badge" aria-hidden="true">${escapeHtml(jumpLabel)}</span>` : ''}
      </button>
    `;
  }

  function renderSalesPurchaseNavIconCluster({ direction = 'prev', canNavigate = false } = {}){
    const isPrev = direction === 'prev';
    const primaryAction = isPrev ? 'prev' : 'next';
    const primaryLabel = isPrev ? 'العملية السابقة' : 'العملية التالية';
    const primaryIcon = isPrev ? SALES_PURCHASE_NAV_ICON_MARKUP.prev : SALES_PURCHASE_NAV_ICON_MARKUP.next;
    return `
      <div class="entries-voucher-navcluster" role="group" aria-label="${escapeHtml(isPrev ? 'السابق' : 'التالي')}">
        ${renderSalesPurchaseNavIconButton({
          action: primaryAction,
          label: primaryLabel,
          icon: primaryIcon,
          disabled: !canNavigate
        })}
      </div>
    `;
  }

  function renderSalesPurchaseNavigator(actionId, formState, { wrap = true } = {}){
    const navState = getSalesPurchaseNavigatorRenderState(actionId, formState);
    const actionLabel = resolveSalesPurchaseEffectiveActionId(actionId, formState) === 'sale' ? 'المبيع' : 'الشراء';
    const stacksMarkup = `
      ${renderSalesPurchaseTopDockNavStack({
        title: '',
        hiddenTitle: true,
        stackClass: 'sales-purchase-navstack sales-purchase-navstack--prev',
        content: renderSalesPurchaseNavIconCluster({ direction: 'prev', canNavigate: navState.canPrev })
      })}
      ${renderSalesPurchaseTopDockNavStack({
        title: '#',
        hiddenTitle: true,
        stackClass: 'sales-purchase-navstack sales-purchase-navstack--lookup',
        content: `<label class="entries-voucher-navbox__field" aria-label="الانتقال برقم العملية"><input class="entries-voucher-navbox__input" type="text" value="${escapeHtml(navState.lookupValue)}" placeholder="#" inputmode="numeric" data-sales-purchase-nav="lookup" autocomplete="off" spellcheck="false"></label><span class="sales-purchase-navstack__lookup-divider" aria-hidden="true">/</span>`
      })}
      ${renderSalesPurchaseTopDockNavStack({
        title: '',
        hiddenTitle: true,
        stackClass: 'sales-purchase-navstack sales-purchase-navstack--count',
        content: `<div class="entries-voucher-navbox__count" aria-live="polite"><strong>${escapeHtml(String(navState.count))}</strong></div>`
      })}
      ${renderSalesPurchaseTopDockNavStack({
        title: '',
        hiddenTitle: true,
        stackClass: 'sales-purchase-navstack sales-purchase-navstack--next',
        content: renderSalesPurchaseNavIconCluster({ direction: 'next', canNavigate: navState.canNext })
      })}
    `;
    const navGroupMarkup = `<div class="sales-purchase-topdock-navgroup">${stacksMarkup}</div>`;
    if(!wrap) return navGroupMarkup;
    return `
      <div class="sales-purchase-topdock" aria-label="تنقل عمليات ${escapeHtml(actionLabel)}">
        <div class="sales-purchase-topdock-layout">${navGroupMarkup}</div>
      </div>
    `;
  }


  function renderSalesPurchaseBeneficiaryAutocompletePopover(){
    return `
      <div class="entries-voucher-choice-popover sales-purchase-beneficiary-autocomplete__popover" data-taif-dropdown-popup="true" data-taif-dropdown-layout="list" data-sales-purchase-beneficiary-suggestions="true" role="listbox" aria-label="اقتراحات اسم المستفيد" hidden></div>
    `;
  }

  function renderSalesPurchaseTopBeneficiaryField(model){
    const safeName = toSafeText(model?.formState?.counterpartyName);
    const avatarVariant = safeName.trim() ? 'plain' : 'add';
    return `
      <div class="sales-purchase-top-field sales-purchase-top-field--beneficiary">
        <span class="sales-purchase-top-field__stack-label">اسم المستفيد</span>
        <div class="sales-purchase-name-field__control-row sales-purchase-top-field__name-row sales-purchase-beneficiary-autocomplete" data-sales-purchase-beneficiary-autocomplete="true">
          <input class="entries-voucher-field__control sales-purchase-top-field__text-input sales-purchase-top-field__text-input--with-launcher taif-control-text" type="text" value="${escapeHtml(safeName)}" placeholder="اكتب الاسم او اضغط على صورة لإضافة عميل" autocomplete="off" spellcheck="false" data-sales-purchase-field="counterparty-name" data-sales-purchase-beneficiary-input="true" aria-label="اسم المستفيد" aria-autocomplete="list" aria-expanded="false">
          <button class="sales-purchase-name-field__icon-button sales-purchase-top-field__icon-button" type="button" data-sales-purchase-action="open-party-window" aria-label="فتح بطاقة الاسم" title="فتح بطاقة الاسم">
            <span class="sales-purchase-name-field__avatar sales-purchase-top-field__avatar" aria-hidden="true">${renderSalesPurchasePartyAvatarMarkup({ variant: avatarVariant })}</span>
          </button>
          ${renderSalesPurchaseBeneficiaryAutocompletePopover()}
        </div>
      </div>
    `;
  }

  function renderSalesPurchaseNameLauncher(model){
    const safeName = toSafeText(model?.formState?.counterpartyName);
    const avatarVariant = safeName.trim() ? 'plain' : 'add';

    return `
      <div class="sales-purchase-name-field">
        <span class="sales-purchase-name-field__label">الاسم</span>
        <div class="sales-purchase-name-field__control-row sales-purchase-beneficiary-autocomplete" data-sales-purchase-beneficiary-autocomplete="true">
          <input class="entries-voucher-field__control sales-purchase-name-field__input taif-control-text" type="text" value="${escapeHtml(safeName)}" placeholder="اكتب الاسم او رقم الوطني او اضغط على صورة" autocomplete="off" spellcheck="false" data-sales-purchase-field="counterparty-name" data-sales-purchase-beneficiary-input="true" aria-label="الاسم" aria-autocomplete="list" aria-expanded="false">
          <button class="sales-purchase-name-field__icon-button" type="button" data-sales-purchase-action="open-party-window" aria-label="فتح بطاقة الاسم" title="فتح بطاقة الاسم">
            <span class="sales-purchase-name-field__avatar" aria-hidden="true">${renderSalesPurchasePartyAvatarMarkup({ variant: avatarVariant })}</span>
          </button>
          ${renderSalesPurchaseBeneficiaryAutocompletePopover()}
        </div>
      </div>
    `;
  }


  function renderSalesPurchaseNotesLauncher(model){
    return `
      <div class="sales-purchase-side-field sales-purchase-side-field--notes-top">
        <span class="sales-purchase-side-field__label">ملاحظات</span>
        <input class="entries-voucher-field__control sales-purchase-side-field__control taif-control-text" type="text" value="${escapeHtml(model?.formState?.notes || '')}" placeholder="ملاحظات" autocomplete="off" spellcheck="false" data-sales-purchase-field="notes" aria-label="ملاحظات">
      </div>
    `;
  }

  function renderSalesPurchaseSummaryLauncher(model){
    return `
      <div class="sales-purchase-side-field sales-purchase-side-field--summary-top">
        <span class="sales-purchase-side-field__label">ملخص</span>
        <input class="entries-voucher-field__control sales-purchase-side-field__control sales-purchase-side-field__control--summary taif-control-text" type="text" value="${escapeHtml(model?.formState?.invoiceSummary || '')}" placeholder="ملخص" autocomplete="off" spellcheck="false" data-sales-purchase-field="invoice-summary" aria-label="ملخص">
      </div>
    `;
  }


  function renderSalesPurchaseSideExtraFields(model){
    return `
      <div class="sales-purchase-side-panel__extras sales-purchase-side-panel__extras--name-notes">
        ${renderSalesPurchaseNameLauncher(model)}
        ${renderSalesPurchaseNotesLauncher(model)}
      </div>
    `;
  }

  function renderSalesPurchaseInlinePurchaseMetaFields(model){
    return `
      <div class="sales-purchase-inline-purchase-meta-fields" aria-label="بيانات المستفيد والملخص والملاحظات">
        ${renderSalesPurchaseTopBeneficiaryField(model)}
        ${renderSalesPurchaseNotesLauncher(model)}
        ${renderSalesPurchaseSummaryLauncher(model)}
      </div>
    `;
  }

  function renderSalesPurchaseTopFields(model, options = {}){
    const includeExtraFields = options.includeExtraFields !== false;
    const includeDateField = options.includeDateField !== false;
    const effectiveActionId = resolveSalesPurchaseEffectiveActionId(model?.actionId, model?.formState);
    const dockLabel = `تنقل وبيانات عمليات ${effectiveActionId === 'sale' ? 'المبيع' : 'الشراء'}`;
    const topLayoutMarkup = `
          <div class="sales-purchase-topdock-layout sales-purchase-topdock-layout--inline-fields">
            ${renderSalesPurchaseCashAccountField(model)}
            ${includeDateField ? renderSalesPurchaseDateField(model) : ''}
            ${renderSalesPurchaseNavigator(model.actionId, model.formState, { wrap:false })}
          </div>
        `;
    return `
      <div class="sales-purchase-side-panel">
        <div class="sales-purchase-topdock" aria-label="${escapeHtml(dockLabel)}">
          ${topLayoutMarkup}
        </div>
        ${includeExtraFields ? renderSalesPurchaseSideExtraFields(model) : ''}
      </div>
    `;
  }


  function renderSalesPurchaseRateModeToggleIcon(activeRateMode){
    if(String(activeRateMode || '').trim() === 'manual'){
      return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4 20h4.5L19 9.5a2.12 2.12 0 0 0 0-3L17.5 5a2.12 2.12 0 0 0-3 0L4 15.5V20Z" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="m13.5 6.5 4 4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
    }
    return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="5" y="8" width="14" height="10" rx="3" fill="none" stroke="currentColor" stroke-width="2"></rect><path d="M12 8V5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path><circle cx="9" cy="13" r="1" fill="currentColor"></circle><circle cx="15" cy="13" r="1" fill="currentColor"></circle><path d="M10 16h4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path><path d="M3.5 13h1.5M19 13h1.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path></svg>';
  }

  function renderSalesPurchaseRateModeToggleButton(formState){
    const activeRateMode = String(formState?.rateMode || 'auto').trim() === 'manual' ? 'manual' : 'auto';
    const targetRateMode = activeRateMode === 'manual' ? 'auto' : 'manual';
    const buttonLabel = activeRateMode === 'manual' ? 'يدوي' : 'تلقائي';
    const buttonTitle = activeRateMode === 'manual' ? 'اضغط للتحويل إلى تلقائي' : 'اضغط للتحويل إلى يدوي';
    return `
      <button class="sales-purchase-rate-mode-toggle sales-purchase-rate-mode-toggle--${escapeHtml(activeRateMode)}" type="button" data-sales-purchase-action="select-rate-mode" data-sales-purchase-rate-mode="${escapeHtml(targetRateMode)}" aria-label="${escapeHtml(buttonTitle)}" title="${escapeHtml(buttonTitle)}">
        <span class="sales-purchase-rate-mode-toggle__icon">${renderSalesPurchaseRateModeToggleIcon(activeRateMode)}</span>
        <span class="sales-purchase-rate-mode-toggle__label">${escapeHtml(buttonLabel)}</span>
      </button>
    `;
  }

  function renderSalesPurchaseAlert(){
    return '';
  }

  function getSalesPurchaseInlineNoticeState(formState){
    const notice = formState && typeof formState === 'object' && formState.inlineNotice && typeof formState.inlineNotice === 'object'
      ? formState.inlineNotice
      : null;
    const message = toSafeText(notice?.message);
    if(!message) return null;
    const tone = String(notice?.tone || '').trim() === 'danger'
      ? 'danger'
      : (String(notice?.tone || '').trim() === 'info' ? 'info' : 'success');
    return { message, tone };
  }

  function renderSalesPurchaseInlineNotice(formState){
    const noticeState = getSalesPurchaseInlineNoticeState(formState);
    if(!noticeState) return '';
    return `
      <div class="sales-purchase-stage-reserved-slot sales-purchase-stage-reserved-slot--notice sales-purchase-stage-reserved-slot--notice-${escapeHtml(noticeState.tone)}" role="status" aria-live="polite">
        <span class="sales-purchase-stage-reserved-slot__label sales-purchase-stage-reserved-slot__label--notice">${escapeHtml(noticeState.message)}</span>
      </div>
    `;
  }

  function buildSalesPurchaseNewBlankFormState(actionId, sourceFormState){
    const safeActionId = toSafeText(actionId);
    const source = sourceFormState && typeof sourceFormState === 'object'
      ? sourceFormState
      : createDefaultFormState(safeActionId);
    const nextState = snapshotSalesPurchaseBaselineFormState(source, safeActionId);
    resetSalesPurchaseFormDateToTodayIfBlankDraft(nextState);
    nextState.amountText = '';
    nextState.counterpartText = '';
    nextState.notes = '';
    nextState.invoiceSummary = '';
    nextState.counterpartyName = '';
    nextState.lastEditedAmountField = 'amount';
    nextState.inlineNotice = null;
    return nextState;
  }


  function renderSalesPurchaseFieldLabelWithCurrencyCode(label){
    const safeLabel = toSafeText(label);
    const match = safeLabel.match(/^(.*?)(?:\s*\(([A-Z]{2,8})\))\s*$/);
    if(!match){
      return escapeHtml(safeLabel);
    }
    const baseLabel = match[1].trim();
    const currencyCode = match[2].trim();
    return `${escapeHtml(baseLabel)} <span class="sales-purchase-form-field__label-currency-code" dir="ltr">(${escapeHtml(currencyCode)})</span>`;
  }

  function resolveSalesPurchaseRenderOptions(options = {}){
    const optionSource = options && typeof options === 'object' ? options : {};
    return {
      inlinePurchase: !!optionSource.inlinePurchase,
      includeTopFields: optionSource.includeTopFields !== false
    };
  }

  function renderSalesPurchaseDealRateTrack(action, model){
    const arrowDirection = action?.arrowDirection || 'right';
    return `
      <div class="sales-purchase-deal__rate-track">
        ${renderRateCard({ tone:'buy', title:'شراء', caption:model.buyCardCaption, figureText:model.buyCardFigureText, selectedCurrency:model.buyCurrency, options:model.buyOptions, feature:model.feature, pickerKey:'buy-card', openPickerKey:model.formState.openPickerKey })}
        <div class="sales-purchase-rate-track__arrow sales-purchase-rate-track__arrow--${escapeHtml(arrowDirection)}" aria-hidden="true">${getTrackArrowIcon(arrowDirection)}</div>
        ${renderRateCard({ tone:'sell', title:'بيع', caption:model.sellCardCaption, figureText:model.sellCardFigureText, selectedCurrency:model.sellCurrency, options:model.sellOptions, feature:model.feature, pickerKey:'sell-card', openPickerKey:model.formState.openPickerKey })}
      </div>
    `;
  }

  function renderSalesPurchaseAmountInputField({ label, value, field, extraClass = '', initialFocus = false }){
    const safeField = toSafeText(field);
    const className = `sales-purchase-form-field${extraClass ? ` ${extraClass}` : ''}`;
    return `
      <div class="${escapeHtml(className)}">
        <span class="sales-purchase-form-field__label">${renderSalesPurchaseFieldLabelWithCurrencyCode(label)}</span>
        <input class="entries-voucher-field__control sales-purchase-form-field__control taif-control-text taif-control-text--ltr" type="text" inputmode="decimal" autocomplete="off" spellcheck="false" placeholder="0" value="${escapeHtml(value)}" data-sales-purchase-field="${escapeHtml(safeField)}"${initialFocus ? ' data-taif-initial-focus="true"' : ''}>
      </div>
    `;
  }

  function renderSalesPurchaseInlineAmountDateCard(action, model){
    return `
      <div class="sales-purchase-amount-date-card" aria-label="بطاقة الصندوق النقدي والتاريخ">
        <div class="sales-purchase-amount-date-card__cash">
          ${renderSalesPurchaseCashAccountField(model, { showLabelColon:false })}
        </div>
        <div class="sales-purchase-amount-date-card__date-row">
          <div class="sales-purchase-amount-date-card__field">
            ${renderSalesPurchaseDateField(model, { showLabelColon:false })}
          </div>
          <span class="sales-purchase-amount-date-card__date-side-label">التاريخ</span>
        </div>
        <div class="sales-purchase-amount-date-card__ghost" aria-label="تنقل العملية">
          <span class="sales-purchase-amount-date-card__navigator-label">شريط التنقل</span>
          <div class="sales-purchase-amount-date-card__navigator sales-purchase-amount-date-card__navigator--bare">
            ${renderSalesPurchaseNavigator(action.id, model.formState, { wrap:false })}
          </div>
        </div>
      </div>
    `;
  }

  function renderSalesPurchaseExchangeRateField(model){
    const isManualRateMode = String(model.formState?.rateMode || 'auto').trim() === 'manual';
    const inputMarkup = isManualRateMode
      ? `<input class="entries-voucher-field__control sales-purchase-form-field__control taif-control-text taif-control-text--ltr" type="text" aria-label="سعر الصرف" value="${escapeHtml(model.manualRateText || '')}" inputmode="decimal" autocomplete="off" spellcheck="false" placeholder="0" data-sales-purchase-field="manual-rate">`
      : `<input class="entries-voucher-field__control sales-purchase-form-field__control sales-purchase-form-field__control--derived taif-control-text taif-control-text--ltr" type="text" aria-label="سعر الصرف" value="${escapeHtml(model.activeRateText)}" readonly tabindex="-1" aria-readonly="true" data-sales-purchase-display-field="active-rate">`;
    return `
      <div class="sales-purchase-form-field sales-purchase-form-field--rate-shell sales-purchase-form-field--rate-field">
        <span class="sales-purchase-form-field__label sales-purchase-form-field__label--rate">سعر الصرف</span>
        <div class="sales-purchase-rate-inline-control sales-purchase-rate-inline-control--merged">
          <div class="sales-purchase-rate-number-stack">
            ${inputMarkup}
          </div>
          <div class="sales-purchase-rate-mode-stack">
            ${renderSalesPurchaseRateModeToggleButton(model.formState)}
          </div>
        </div>
      </div>
    `;
  }

  function renderSalesPurchaseDealFieldsGrid(action, model, { inlinePurchase = false, inlineNoticeMarkup = '' } = {}){
    const hasInlineNotice = !!String(inlineNoticeMarkup || '').trim();
    return `
      <div class="sales-purchase-deal__fields-grid${inlinePurchase ? ' sales-purchase-deal__fields-grid--inline-purchase' : ''}${hasInlineNotice ? ' sales-purchase-deal__fields-grid--has-notice' : ''}">
        ${hasInlineNotice ? `<div class="sales-purchase-deal__inline-notice" aria-label="تنبيه العملية">${inlineNoticeMarkup}</div>` : ''}
        ${inlinePurchase ? renderPurchaseCalcMethodField(model.formState) : ''}
        ${inlinePurchase ? renderSalesPurchaseInlinePurchaseMetaFields(model) : ''}
        ${renderSalesPurchaseAmountInputField({
          label: model.amountLabel,
          value: model.amountInputText,
          field: 'amount',
          extraClass: 'sales-purchase-form-field--primary-amount',
          initialFocus: true
        })}
        ${inlinePurchase ? renderSalesPurchaseInlineAmountDateCard(action, model) : ''}
        ${renderSalesPurchaseExchangeRateField(model)}
        ${renderSalesPurchaseAmountInputField({
          label: model.counterpartLabel,
          value: model.counterpartInputText,
          field: 'counterpart-amount',
          extraClass: 'sales-purchase-form-field--counterpart-amount'
        })}
      </div>
    `;
  }

  function renderStructuredForm(action, formState, resolvedModel = null, options = {}){
    const model = resolvedModel || resolveFormModel(action.id, formState);
    const { inlinePurchase } = resolveSalesPurchaseRenderOptions(options);
    const inlineNoticeMarkup = typeof options.inlineNoticeMarkup === 'string' ? options.inlineNoticeMarkup : '';
    return `
      <div class="sales-purchase-deal" data-sales-purchase-form-layout="${escapeHtml(action.id)}">
        ${renderSalesPurchaseDealRateTrack(action, model)}
        ${renderSalesPurchaseDealFieldsGrid(action, model, { inlinePurchase, inlineNoticeMarkup })}
        ${renderSalesPurchaseAlert(model.formState.alertIssues)}
      </div>
    `;
  }


  function normalizeSalesPurchaseWorkspaceCalcMethod(value){
    return String(value || '').trim() === 'divide' ? 'divide' : 'multiply';
  }

  function getSalesPurchaseCalcMethodOptions(){
    return [
      Object.freeze({ value:'multiply', label:'ضرب', meta:'×', ariaLabel:'طريقة الاحتساب ضرب' }),
      Object.freeze({ value:'divide', label:'تقسيم', meta:'÷', ariaLabel:'طريقة الاحتساب تقسيم' })
    ];
  }

  function resolveSalesPurchaseCalcMethodPickerData(selectedValue){
    const options = getSalesPurchaseCalcMethodOptions();
    const resolvedValue = normalizeSalesPurchaseWorkspaceCalcMethod(selectedValue);
    const activeOption = options.find((option) => option.value === resolvedValue) || options[0] || null;
    return {
      options,
      resolvedValue,
      activeOption
    };
  }

  function renderSalesPurchaseCalcMethodChoiceValue(option, { placeholder = '' } = {}){
    if(!option){
      return placeholder ? `<span class="entries-voucher-choice-picker__placeholder">${escapeHtml(placeholder)}</span>` : '';
    }
    return `
      <span class="entries-voucher-choice-picker__value-layout">
        <span class="entries-voucher-choice-picker__text">${escapeHtml(option.label || option.value || '')}</span>
        ${option.meta ? `<span class="entries-voucher-choice-picker__meta" dir="ltr">${wrapControlTextMarkup(escapeHtml(option.meta), 'taif-control-text--ltr')}</span>` : ''}
      </span>
    `;
  }

  function renderPurchaseCalcMethodField(formState){
    const pickerKey = 'purchase-calc-method';
    const pickerData = resolveSalesPurchaseCalcMethodPickerData(formState && formState.purchaseCalcMethod);
    const isOpen = String(formState && formState.openPickerKey || '').trim() === pickerKey;
    const listContent = pickerData.options.map((option) => {
      const isActive = option.value === pickerData.resolvedValue;
      return `
        <button class="entries-voucher-choice-popover__option${isActive ? ' is-active' : ''}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-taif-inline-picker-option="true" role="option" data-sales-purchase-action="select-purchase-calc-method" data-sales-purchase-calc-method-option="${escapeHtml(option.value)}" aria-selected="${isActive ? 'true' : 'false'}" aria-label="اختيار ${escapeHtml(option.ariaLabel || option.label || '')}">
          <span class="entries-voucher-choice-popover__label sales-purchase-form-field__picker-option-label" data-taif-dropdown-label="true">${renderSalesPurchaseCalcMethodChoiceValue(option)}</span>
          <span class="entries-voucher-choice-popover__check" aria-hidden="true">${createChoicePickerIcon('check')}</span>
        </button>
      `;
    }).join('');

    return `
      <div class="sales-purchase-form-field sales-purchase-form-field--calc-method sales-purchase-form-field--purchase-calc">
        <span class="sales-purchase-form-field__label">طريقة الاحتساب</span>
        <div class="entries-voucher-choice-picker sales-purchase-form-field__picker${isOpen ? ' is-open' : ''}" data-sales-purchase-picker-host="${pickerKey}" data-taif-inline-picker-host="true">
          <button class="entries-voucher-field__control entries-voucher-choice-picker__trigger sales-purchase-form-field__picker-trigger" type="button" data-taif-picker-trigger="true" data-sales-purchase-action="toggle-picker" data-sales-purchase-picker-key="${pickerKey}" aria-label="طريقة الاحتساب" aria-haspopup="listbox" aria-expanded="${isOpen ? 'true' : 'false'}">
            <span class="entries-voucher-choice-picker__value sales-purchase-form-field__picker-value">${renderSalesPurchaseCalcMethodChoiceValue(pickerData.activeOption)}</span>
            <span class="entries-voucher-choice-picker__icon" aria-hidden="true">${createChoicePickerIcon('chevronDown') || getChevronDownIcon()}</span>
          </button>
          <div class="entries-voucher-choice-popover sales-purchase-form-field__picker-popover" data-taif-dropdown-popup="true" data-taif-dropdown-layout="list" data-taif-inline-picker="true" role="listbox" aria-label="طريقة الاحتساب"${isOpen ? '' : ' hidden'}>${listContent}</div>
        </div>
      </div>
    `;
  }


  function renderSalesPurchaseStructuredWindowContent(action, formState, options = {}){
    const model = resolveFormModel(action.id, formState);
    const { inlinePurchase, includeTopFields } = resolveSalesPurchaseRenderOptions(options);
    const inlineNoticeMarkup = renderSalesPurchaseInlineNotice(model.formState);
    return `
      <div class="sales-purchase-window-fieldset${model.isLocked ? ' sales-purchase-window-fieldset--locked' : ''}" style="border:0;margin:0;padding:0;min-inline-size:0;"${model.isLocked ? ' data-sales-purchase-locked="true"' : ''}>
        ${includeTopFields ? `
        <section class="sales-purchase-stage-section sales-purchase-stage-section--top sales-purchase-stage-section--top-fields">
          ${renderSalesPurchaseTopFields(model, inlinePurchase ? { includeExtraFields:false, includeDateField:true } : {})}
        </section>` : ''}
        ${inlineNoticeMarkup && !inlinePurchase ? `
        <section class="sales-purchase-stage-section sales-purchase-stage-section--reserved" aria-label="ملاحظات العملية">
          ${inlineNoticeMarkup}
        </section>` : ''}
        <section class="sales-purchase-stage-section sales-purchase-stage-section--bottom">
          ${renderStructuredForm(action, formState, model, { inlinePurchase, inlineNoticeMarkup: inlinePurchase ? inlineNoticeMarkup : '' })}
        </section>
      </div>
    `;
  }

  function renderWindowCanvasContent(action, formState, options = {}){
    const { inlinePurchase, includeTopFields } = resolveSalesPurchaseRenderOptions(options);
    if((action?.id === 'purchase' || action?.id === 'sale') && inlinePurchase){
      return renderSalesPurchaseStructuredWindowContent(action, formState, {
        inlinePurchase:true,
        includeTopFields
      });
    }

    if(action?.id === 'purchase'){
      return '<div class="sales-purchase-empty-canvas sales-purchase-empty-canvas--purchase-window" aria-hidden="true"></div>';
    }

    if(action?.id === 'sale'){
      return renderSalesPurchaseStructuredWindowContent(action, formState);
    }

    if(action?.id === 'party'){
      return renderSalesPurchasePartyWindow(formState);
    }


    return '<div class="sales-purchase-empty-canvas" aria-hidden="true"></div>';
  }

  function renderWindowCanvas(action, formState, options = {}){
    const { inlinePurchase } = resolveSalesPurchaseRenderOptions(options);
    const isStructuredWindow = action?.id === 'sale' || (action?.id === 'purchase' && inlinePurchase);
    const isPartyWindow = action?.id === 'party';
    return `
      <div class="sales-purchase-empty-shell${isStructuredWindow ? ' sales-purchase-empty-shell--split' : ''}${isPartyWindow ? ' sales-purchase-empty-shell--party' : ''}" data-sales-purchase-form-root>
        ${renderWindowCanvasContent(action, formState, options)}
      </div>
    `;
  }


  function renderSalesPurchaseWindowFooterSpacer(){
    return '<div class="sales-purchase-sheet__footer-spacer entries-actions" data-taif-footer-actions="true" aria-hidden="true"></div>';
  }

  function renderSalesPurchaseWindowFooterButton({ action, tone, role, label, disabled = false }){
    const safeTone = toSafeText(tone) || 'primary';
    return `<button class="entries-action-btn entries-action-btn--${escapeHtml(safeTone)} sales-purchase-button sales-purchase-button--${escapeHtml(safeTone)}" type="button" data-sales-purchase-action="${escapeHtml(action)}" data-taif-action-role="${escapeHtml(role)}" data-taif-action-tone="${escapeHtml(safeTone)}"${disabled ? ' disabled' : ''}><span class="taif-control-text">${escapeHtml(label)}</span></button>`;
  }

  function renderSalesPurchaseWindowFooterShell({ ariaLabel, buttons }){
    return `
      <div class="entries-actions entries-actions--shell" data-taif-footer-actions="true" aria-label="${escapeHtml(ariaLabel)}">
        <div class="entries-actions__group entries-actions__group--primary-actions" data-taif-footer-group="true">
          ${buttons.join('')}
        </div>
      </div>
    `;
  }

  function renderSalesPurchasePartyWindowFooter(){
    return renderSalesPurchaseWindowFooterShell({
      ariaLabel: 'إجراءات بطاقة الاسم',
      buttons: [
        renderSalesPurchaseWindowFooterButton({ action:'close-window', tone:'dark', role:'cancel', label:'إغلاق' }),
        renderSalesPurchaseWindowFooterButton({ action:'save-party-customer', tone:'success', role:'commit', label:'إضافة' })
      ]
    });
  }

  function renderSalesPurchaseSaleWindowFooter(){
    return renderSalesPurchaseWindowFooterShell({
      ariaLabel: 'إجراءات نافذة الشراء والمبيع',
      buttons: [
        renderSalesPurchaseWindowFooterButton({ action:'close-window', tone:'dark', role:'cancel', label:'إغلاق' }),
        renderSalesPurchaseWindowFooterButton({ action:'delete-window-record', tone:'danger', role:'destructive', label:'حذف', disabled:true }),
        renderSalesPurchaseWindowFooterButton({ action:'reverse-window-record', tone:'danger', role:'destructive', label:'إلغاء القيد', disabled:true }),
        renderSalesPurchaseWindowFooterButton({ action:'open-new-window', tone:'primary', role:'auxiliary', label:'جديد', disabled:true }),
        renderSalesPurchaseWindowFooterButton({ action:'execute-window', tone:'success', role:'commit', label:'تنفيذ العملية' })
      ]
    });
  }

  function renderWindowFooter(action){
    if(action?.id === 'party') return renderSalesPurchasePartyWindowFooter();
    if(action?.id === 'sale') return renderSalesPurchaseSaleWindowFooter();
    return renderSalesPurchaseWindowFooterSpacer();
  }

  function buildWindowMarkup(action, formState, windowId = ''){
    const safeWindowId = toSafeText(windowId) || toSafeText(action?.id);
    const windowSizeClass = action?.id === 'party'
      ? 'sales-purchase-modal-window--party-shell'
      : 'sales-purchase-modal-window--settlement-shell';
    return `
      <div class="sales-purchase-modal-backdrop" data-sales-purchase-window-id="${escapeHtml(safeWindowId)}" aria-hidden="false">
        <div class="sales-purchase-attached-owner-blocker" data-sales-purchase-attached-owner-blocker="true" aria-hidden="true" hidden></div>
        <div class="sales-purchase-modal-window sales-purchase-modal-window--grand sales-purchase-modal-window--size-lg ${windowSizeClass}" data-sales-purchase-window-id="${escapeHtml(safeWindowId)}" role="dialog" aria-modal="false" aria-label="${escapeHtml(action.title)}" tabindex="-1">
          <aside class="sales-purchase-sheet" data-sales-purchase-window-id="${escapeHtml(safeWindowId)}">
            <div class="sales-purchase-sheet__head">
              <div class="sales-purchase-sheet__heading">
                <h2 class="sales-purchase-sheet__title" data-taif-detail-title="true">
                  <span class="sales-purchase-sheet__title-text">${escapeHtml(action.title)}</span>
                  ${action?.iconMarkup ? `<span class="sales-purchase-sheet__title-icon" aria-hidden="true">${action.iconMarkup}</span>` : ''}
                </h2>
              </div>
              <div class="sales-purchase-sheet__window-actions" data-taif-window-actions="true">
                <button class="sales-purchase-sheet__chrome-btn sales-purchase-sheet__expand" type="button" data-sales-purchase-action="expand-window" aria-label="تكبير النافذة" title="تكبير النافذة">${getWindowIcon('expand')}</button>
                <button class="sales-purchase-sheet__close" type="button" data-sales-purchase-action="close-window" aria-label="إغلاق" title="إغلاق">${getWindowIcon('close')}</button>
              </div>
            </div>
            <div class="sales-purchase-sheet__body sales-purchase-sheet__body--settlement">
              <div class="sales-purchase-sheet__shell-space sales-purchase-sheet__shell-space--settlement">
                ${renderWindowCanvas(action, formState)}
              </div>
              ${renderWindowFooter(action)}
            </div>
          </aside>
        </div>
      </div>
    `;
  }

  function detachWindowRecord(windowId){
    runtime.windows.delete(windowId);
  }

  function closeWindow(windowId, event = null){
    if(event){
      event.preventDefault();
      event.stopPropagation();
    }

    try{ closeSalesPurchaseDeleteConfirmDialog(); }catch{}
    try{ closeSalesPurchaseReverseConfirmDialog(); }catch{}
    try{ closeSalesPurchaseSuccessDialog(); }catch{}
    try{ closeSalesPurchaseReviewDialog(); }catch{}

    const entry = runtime.windows.get(windowId);
    if(!entry) return;

    const attachedChildId = toSafeText(entry.attachedPartyWindowId);
    if(attachedChildId && attachedChildId !== toSafeText(windowId) && runtime.windows.has(attachedChildId)){
      closeWindow(attachedChildId);
    }

    if(isSalesPurchasePartyEntry(entry)){
      cancelSalesPurchasePartyCustomer(entry);
      releaseSalesPurchasePartyAttachment(entry);
    }

    const { backdrop, modal, manager, cleanupCallbacks = [] } = entry;

    if(typeof runCleanupCallbacks === 'function'){
      runCleanupCallbacks(cleanupCallbacks, { clearSource:true });
    } else {
      cleanupCallbacks.slice().forEach((cleanup) => {
        if(typeof cleanup !== 'function') return;
        try{ cleanup(); }catch{}
      });
      cleanupCallbacks.length = 0;
    }

    if(manager && backdrop instanceof HTMLElement) manager.unregisterModalWindow(backdrop);
    if(backdrop instanceof HTMLElement && backdrop.isConnected) backdrop.remove();
    if(modal instanceof HTMLElement){
      if(typeof modal.blur === 'function') modal.blur();
      setSalesPurchaseOwnerInteractionLocked(entry, false);
    }

    detachWindowRecord(windowId);
    manager?.cleanupModalRegistry?.();
  }

  function closeAllWindows(){
    Array.from(runtime.windows.keys()).forEach((windowId) => closeWindow(windowId));
    closeSalesPurchaseDifferentDateConfirmDialog();
    cleanupSalesPurchaseInlinePrimaryRowShiftObserver();
    runtime.modalManager?.cleanupModalRegistry?.();
    runtime.modalManager = null;
    runtime.modalManagerOwnerView = '';
  }

  function scheduleSalesPurchasePostRender(entry, afterRender = null, { refreshInlineHost = false } = {}){
    if(!entry) return;
    requestAnimationFrame(() => {
      if(refreshInlineHost){
        const freshInlineHost = getInlinePurchaseWorkspaceHost();
        if(freshInlineHost instanceof HTMLElement) entry.modal = freshInlineHost;
      }
      if(!(entry.modal instanceof HTMLElement) || !entry.modal.isConnected) return;
      if(!entry.isInlineWorkspace && entry.id && runtime.windows && !runtime.windows.has(entry.id)) return;
      if(typeof afterRender === 'function') afterRender();
      syncSalesPurchaseReviewToast(entry);
    });
  }

  function renderWindowForm(entry, afterRender = null){
    if(!entry || !entry.action) return;
    if(entry.isInlineWorkspace){
      const inlineHost = getInlinePurchaseWorkspaceHost();
      if(inlineHost instanceof HTMLElement) entry.modal = inlineHost;
      if(!entry.modal || !(entry.modal instanceof HTMLElement)) return;
      entry.modal.innerHTML = renderSalesPurchaseWorkspacePanelsContent(entry);
      normalizeSalesPurchaseFlow(entry.modal);
      syncWindowDerivedFields(entry);
      syncSalesPurchaseInlinePrimaryRowShift(entry.modal);
      bindSalesPurchaseInlinePrimaryRowShiftObserver(entry.modal);
      requestAnimationFrame(() => syncSalesPurchaseInlinePrimaryRowShift(entry.modal));
      scheduleSalesPurchasePostRender(entry, afterRender, { refreshInlineHost:true });
      return;
    }
    if(!entry.modal || !(entry.modal instanceof HTMLElement)) return;
    const formRoot = entry.modal.querySelector('[data-sales-purchase-form-root]');
    if(!(formRoot instanceof HTMLElement)) return;
    formRoot.innerHTML = renderWindowCanvasContent(entry.action, entry.formState, {});
    normalizeSalesPurchaseFlow(formRoot);
    syncWindowDerivedFields(entry);
    scheduleSalesPurchasePostRender(entry, afterRender);
  }

  function rerenderSalesPurchaseEntryAndFocus(entry, resolveTarget){
    if(!entry) return;
    renderWindowForm(entry, () => {
      const host = entry.modal instanceof HTMLElement ? entry.modal : null;
      const target = typeof resolveTarget === 'function' ? resolveTarget(host) : null;
      if(target instanceof HTMLElement) focusSalesPurchaseElement(target);
    });
  }

  function rerenderSalesPurchaseEntryAndFocusPreferredAmount(entry){
    rerenderSalesPurchaseEntryAndFocus(entry, (host) => resolveSalesPurchasePreferredAmountFocus(entry, host));
  }

  function rerenderSalesPurchaseEntryAndFocusMainDateControl(entry){
    renderWindowForm(entry, () => {
      focusSalesPurchaseDateControl(entry, 'current');
    });
  }

  function rerenderSalesPurchaseEntryAndFocusMainDateTrigger(entry){
    rerenderSalesPurchaseEntryAndFocus(entry, (host) => host?.querySelector('[data-sales-purchase-date-action="toggle"]'));
  }

  function getSalesPurchaseCurrencyNumberFeature(){
    return TAIF && TAIF.currencyManagementFeature && typeof TAIF.currencyManagementFeature === 'object'
      ? TAIF.currencyManagementFeature
      : {};
  }

  function normalizeSalesPurchaseLocalizedNumericText(value){
    return String(value ?? '')
      .replace(/[٠-٩]/g, (digit) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)))
      .replace(/[۰-۹]/g, (digit) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)))
      .replace(/[٫]/g, '.')
      .replace(/[٬،]/g, ',')
      .replace(/\s+/g, '');
  }

  function formatSalesPurchaseInteractiveNumericText(value){
    const currencyFeature = getSalesPurchaseCurrencyNumberFeature();
    if(typeof currencyFeature.formatSmartNumericText === 'function'){
      const formatted = currencyFeature.formatSmartNumericText(value, {
        allowDecimal:true,
        allowNegative:false,
        preserveTrailingDecimal:true
      });
      return formatted === '-' ? '' : formatted;
    }

    const normalized = normalizeSalesPurchaseLocalizedNumericText(value);
    let result = '';
    let hasDecimal = false;

    for(const character of normalized){
      if(character >= '0' && character <= '9'){
        result += character;
        continue;
      }

      if(character === '.' && !hasDecimal){
        if(result === '') result = '0';
        result += '.';
        hasDecimal = true;
      }
    }

    if(!result) return '';

    const parts = result.split('.');
    const integerPart = (parts[0] || '0').replace(/^0+(?=\d)/, '') || '0';
    const groupedInteger = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    if(hasDecimal) return `${groupedInteger}.${parts.slice(1).join('')}`;
    return groupedInteger;
  }

  function sanitizeSalesPurchaseFormNumericText(value){
    return formatSalesPurchaseInteractiveNumericText(value);
  }

  function sanitizeSalesPurchaseLiveNumericInput(value, input = null){
    const currencyFeature = getSalesPurchaseCurrencyNumberFeature();
    if(input instanceof HTMLInputElement && typeof currencyFeature.applySmartNumericFormatting === 'function'){
      return currencyFeature.applySmartNumericFormatting(input, {
        preserveCaret:true,
        preserveTrailingDecimal:true,
        allowDecimal:true,
        allowNegative:false
      });
    }
    return formatSalesPurchaseInteractiveNumericText(value);
  }

  function commitSalesPurchaseNumericFieldInput(entry, target, { assign, lastEditedAmountField = '', syncDerived = false } = {}){
    if(!entry || !(target instanceof HTMLInputElement) || typeof assign !== 'function') return false;
    prepareSalesPurchaseFormMutation(entry, { clearLookup:true, syncBaseline:true });
    const sanitized = sanitizeSalesPurchaseLiveNumericInput(target.value, target);
    assign(sanitized);
    if(lastEditedAmountField) entry.formState.lastEditedAmountField = lastEditedAmountField;
    entry.formState.alertIssues = [];
    if(target.value !== sanitized) target.value = sanitized;
    if(syncDerived) syncWindowDerivedFields(entry);
    return true;
  }


  function handleSalesPurchaseAmountFieldInput(entry, target){
    if(!entry || !(target instanceof HTMLInputElement)) return false;
    const field = String(target.getAttribute('data-sales-purchase-field') || '').trim();
    if(field === 'amount'){
      return commitSalesPurchaseNumericFieldInput(entry, target, {
        assign: (sanitized) => { entry.formState.amountText = sanitized; },
        lastEditedAmountField: 'amount',
        syncDerived: true
      });
    }
    if(field === 'counterpart-amount'){
      return commitSalesPurchaseNumericFieldInput(entry, target, {
        assign: (sanitized) => { entry.formState.counterpartText = sanitized; },
        lastEditedAmountField: 'counterpart',
        syncDerived: true
      });
    }
    if(field === 'manual-rate'){
      return commitSalesPurchaseNumericFieldInput(entry, target, {
        assign: (sanitized) => { entry.formState.manualRateText = sanitized; },
        syncDerived: true
      });
    }
    return false;
  }


  function sanitizeSalesPurchaseMainDatePart(partKey, value){
    const digits = String(value || '').replace(/\D+/g, '');
    return partKey === 'year' ? digits.slice(0, 4) : digits.slice(0, 2);
  }

  function handleSalesPurchaseMainDatePartInput(entry, target){
    if(!entry || !(target instanceof HTMLInputElement) || !target.matches('[data-sales-purchase-date-part]')) return false;
    const partKey = toSafeText(target.getAttribute('data-sales-purchase-date-part'));
    const safeValue = sanitizeSalesPurchaseMainDatePart(partKey, target.value || '');
    if(target.value !== safeValue) target.value = safeValue;
    const dateHost = target.closest('[data-sales-purchase-date-picker="true"]');
    const dayInput = dateHost instanceof HTMLElement ? dateHost.querySelector('[data-sales-purchase-date-part="day"]') : null;
    const monthInput = dateHost instanceof HTMLElement ? dateHost.querySelector('[data-sales-purchase-date-part="month"]') : null;
    const yearInput = dateHost instanceof HTMLElement ? dateHost.querySelector('[data-sales-purchase-date-part="year"]') : null;
    const day = dayInput instanceof HTMLInputElement ? String(dayInput.value || '').trim() : '';
    const month = monthInput instanceof HTMLInputElement ? String(monthInput.value || '').trim() : '';
    const year = yearInput instanceof HTMLInputElement ? String(yearInput.value || '').trim() : '';
    if(day.length === 2 && month.length === 2 && year.length === 4){
      const nextIso = `${year}-${month}-${day}`;
      if(salesPurchaseParseIsoDate(nextIso)){
        prepareSalesPurchaseFormMutation(entry, { clearLookup:true, syncBaseline:true });
        entry.formState.voucherDate = nextIso;
        entry.formState.alertIssues = [];
        entry.formState.datePickerMonthCursor = salesPurchaseResolveMonthCursor(nextIso, nextIso.slice(0, 7));
      }
    }
    return true;
  }

  function normalizeSalesPurchaseBeneficiaryLookupText(value){
    return String(value ?? '')
      .replace(/[أإآٱ]/g, 'ا')
      .replace(/ى/g, 'ي')
      .replace(/ة/g, 'ه')
      .replace(/ـ/g, '')
      .toLowerCase()
      .replace(/\s+/g, ' ')
      .trim();
  }

  function normalizeSalesPurchaseBeneficiaryDigitsText(value){
    return String(value ?? '')
      .replace(/[٠-٩]/g, (digit) => String(digit.charCodeAt(0) - 0x0660))
      .replace(/[۰-۹]/g, (digit) => String(digit.charCodeAt(0) - 0x06F0))
      .replace(/[^\d+]+/g, '')
      .trim();
  }

  function readSalesPurchaseCustomerCardRecords(){
    const api = typeof getSalesPurchasePartyCustomerApi === 'function' ? getSalesPurchasePartyCustomerApi() : null;
    if(!api || typeof api.readRecords !== 'function') return [];
    try{
      const records = api.readRecords();
      return Array.isArray(records) ? records : [];
    }catch{
      return [];
    }
  }

  function buildSalesPurchaseBeneficiarySuggestionNameText(record){
    return normalizeSalesPurchaseBeneficiaryLookupText([
      record?.fullName,
      record?.latinName
    ].filter(Boolean).join(' '));
  }

  function buildSalesPurchaseBeneficiarySuggestionSecondaryText(record){
    return normalizeSalesPurchaseBeneficiaryLookupText(record?.idNumber || '');
  }

  function createSalesPurchaseBeneficiarySuggestionItem(record, sourceIndex){
    const name = toSafeText(record?.fullName || record?.latinName);
    if(!name) return null;
    const idNumber = toSafeText(record?.idNumber);
    const meta = idNumber ? `رقم تعريف: ${idNumber}` : '';
    return {
      id: toSafeText(record?.id) || `customer-${sourceIndex}`,
      name,
      meta,
      nameSearchText: buildSalesPurchaseBeneficiarySuggestionNameText(record),
      secondarySearchText: buildSalesPurchaseBeneficiarySuggestionSecondaryText(record),
      updatedAt: Number(record?.updatedAt || record?.createdAt || 0) || 0
    };
  }

  function scoreSalesPurchaseBeneficiarySuggestion(item, query){
    if(!item || !query) return 0;
    const safeName = normalizeSalesPurchaseBeneficiaryLookupText(item.nameSearchText || item.name);
    const safeSecondary = normalizeSalesPurchaseBeneficiaryLookupText(item.secondarySearchText || '');
    const queryTokens = query.split(' ').filter(Boolean);
    const hasLetters = /[a-z؀-ۿ]/i.test(query);
    const digitQuery = normalizeSalesPurchaseBeneficiaryDigitsText(query);
    const shouldSearchSecondary = !hasLetters && digitQuery.length >= 3;
    let score = 0;
    if(safeName === query) score += 1600;
    if(safeName.startsWith(query)) score += 1200;
    else if(safeName.split(' ').some((part) => part.startsWith(query))) score += 980;
    else if(query.length >= 2 && safeName.includes(query)) score += 620;
    queryTokens.forEach((token) => {
      if(!token) return;
      if(safeName.startsWith(token)) score += 180;
      else if(safeName.split(' ').some((part) => part.startsWith(token))) score += 142;
      else if(token.length >= 2 && safeName.includes(token)) score += 84;
    });
    if(score <= 0 && shouldSearchSecondary && safeSecondary){
      if(safeSecondary.startsWith(digitQuery)) score += 460;
      else if(safeSecondary.includes(digitQuery)) score += 260;
    }
    if(score <= 0) return 0;
    score += Math.min(90, Math.floor(Math.max(0, item.updatedAt || 0) / 100000000000));
    return score;
  }

  function findSalesPurchaseCustomerRecordByBeneficiaryName(name){
    const normalizedName = normalizeSalesPurchaseBeneficiaryLookupText(name);
    if(!normalizedName) return null;
    return readSalesPurchaseCustomerCardRecords().find((record) => {
      return normalizeSalesPurchaseBeneficiaryLookupText(record?.fullName) === normalizedName
        || normalizeSalesPurchaseBeneficiaryLookupText(record?.latinName) === normalizedName;
    }) || null;
  }

  function getSalesPurchaseBeneficiarySuggestions(query){
    const normalizedQuery = normalizeSalesPurchaseBeneficiaryLookupText(query);
    if(!normalizedQuery) return [];
    const seenNames = new Set();
    return readSalesPurchaseCustomerCardRecords()
      .map((record, index) => createSalesPurchaseBeneficiarySuggestionItem(record, index))
      .filter(Boolean)
      .map((item, index) => ({ item, index, score: scoreSalesPurchaseBeneficiarySuggestion(item, normalizedQuery) }))
      .filter((entry) => entry.score > 0)
      .sort((a, b) => b.score - a.score || b.item.updatedAt - a.item.updatedAt || a.index - b.index)
      .filter((entry) => {
        const key = normalizeSalesPurchaseBeneficiaryLookupText(entry.item.name);
        if(!key || seenNames.has(key)) return false;
        seenNames.add(key);
        return true;
      })
      .slice(0, 8)
      .map((entry) => entry.item);
  }

  function renderSalesPurchaseBeneficiarySuggestionOption(item, index, activeIndex){
    if(!item) return '';
    const isActive = Number(index) === Number(activeIndex);
    return `
      <button class="entries-voucher-choice-popover__option sales-purchase-beneficiary-autocomplete__option${isActive ? ' is-active' : ''}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-taif-inline-picker-option="true" role="option" data-sales-purchase-beneficiary-suggestion-index="${escapeHtml(String(index))}" data-sales-purchase-beneficiary-suggestion-name="${escapeHtml(item.name)}" aria-selected="${isActive ? 'true' : 'false'}" aria-label="اختيار ${escapeHtml(item.name)}">
        <span class="sales-purchase-beneficiary-autocomplete__avatar" aria-hidden="true">${renderSalesPurchasePartyAvatarMarkup({ variant:'plain' })}</span>
        <span class="sales-purchase-beneficiary-autocomplete__text">
          <strong class="sales-purchase-beneficiary-autocomplete__name">${escapeHtml(item.name)}</strong>
          ${item.meta ? `<span class="sales-purchase-beneficiary-autocomplete__meta">${escapeHtml(item.meta)}</span>` : ''}
        </span>
        <span class="entries-voucher-choice-popover__check sales-purchase-beneficiary-autocomplete__check" aria-hidden="true">${createChoicePickerIcon('check')}</span>
      </button>
    `;
  }

  function getSalesPurchaseBeneficiaryAutocompleteHost(input){
    const host = input instanceof HTMLElement ? input.closest('[data-sales-purchase-beneficiary-autocomplete="true"]') : null;
    return host instanceof HTMLElement ? host : null;
  }

  function getSalesPurchaseBeneficiaryAutocompleteInput(host){
    const input = host instanceof HTMLElement ? host.querySelector('[data-sales-purchase-beneficiary-input="true"]') : null;
    return input instanceof HTMLInputElement ? input : null;
  }

  function getSalesPurchaseBeneficiaryAutocompletePopover(host){
    const popover = host instanceof HTMLElement ? host.querySelector('[data-sales-purchase-beneficiary-suggestions="true"]') : null;
    return popover instanceof HTMLElement ? popover : null;
  }

  function closeSalesPurchaseBeneficiarySuggestions(scope){
    const root = scope instanceof HTMLElement ? scope : null;
    const hosts = root
      ? (root.matches('[data-sales-purchase-beneficiary-autocomplete="true"]') ? [root] : Array.from(root.querySelectorAll('[data-sales-purchase-beneficiary-autocomplete="true"]')))
      : [];
    hosts.forEach((host) => {
      const popover = getSalesPurchaseBeneficiaryAutocompletePopover(host);
      const input = getSalesPurchaseBeneficiaryAutocompleteInput(host);
      if(popover){
        popover.hidden = true;
        popover.innerHTML = '';
      }
      host.classList.remove('is-open');
      host.dataset.salesPurchaseBeneficiaryActiveIndex = '-1';
      if(input) input.setAttribute('aria-expanded', 'false');
    });
  }

  function syncSalesPurchaseBeneficiarySuggestions(entry, input, { activeIndex = 0, open = true } = {}){
    if(!entry || !(input instanceof HTMLInputElement)) return [];
    const host = getSalesPurchaseBeneficiaryAutocompleteHost(input);
    const popover = getSalesPurchaseBeneficiaryAutocompletePopover(host);
    if(!(host instanceof HTMLElement) || !(popover instanceof HTMLElement)) return [];
    const items = getSalesPurchaseBeneficiarySuggestions(input.value);
    if(!open || !items.length){
      closeSalesPurchaseBeneficiarySuggestions(host);
      return [];
    }
    const safeActiveIndex = Math.max(0, Math.min(items.length - 1, Number(activeIndex) || 0));
    host.dataset.salesPurchaseBeneficiaryActiveIndex = String(safeActiveIndex);
    popover.innerHTML = items.map((item, index) => renderSalesPurchaseBeneficiarySuggestionOption(item, index, safeActiveIndex)).join('');
    popover.hidden = false;
    host.classList.add('is-open');
    input.setAttribute('aria-expanded', 'true');
    const activeButton = popover.querySelector(`[data-sales-purchase-beneficiary-suggestion-index="${String(safeActiveIndex)}"]`);
    if(activeButton && typeof activeButton.scrollIntoView === 'function'){
      try{ activeButton.scrollIntoView({ block:'nearest', inline:'nearest', behavior:'auto' }); }catch{}
    }
    return items;
  }

  function setSalesPurchaseOwnerBeneficiaryName(ownerEntry, name, { render = false } = {}){
    if(!ownerEntry || !ownerEntry.formState) return false;
    const safeName = toSafeText(name);
    prepareSalesPurchaseFormMutation(ownerEntry, { clearLookup:true, syncBaseline:true });
    ownerEntry.formState.counterpartyName = safeName;
    ownerEntry.formState.alertIssues = [];
    const host = ownerEntry.modal instanceof HTMLElement ? ownerEntry.modal : null;
    if(render){
      renderWindowForm(ownerEntry);
    } else if(host){
      const input = host.querySelector('[data-sales-purchase-field="counterparty-name"]');
      if(input instanceof HTMLInputElement && input.value !== safeName) input.value = safeName;
      const avatarNode = host.querySelector('.sales-purchase-name-field__avatar');
      if(avatarNode instanceof HTMLElement){
        avatarNode.innerHTML = renderSalesPurchasePartyAvatarMarkup({ variant: safeName ? 'plain' : 'add' });
      }
      closeSalesPurchaseBeneficiarySuggestions(host);
      syncSalesPurchaseNavigatorUi(ownerEntry);
      syncSalesPurchaseWindowActionButtons(ownerEntry);
    }
    if(ownerEntry.isInlineWorkspace) rememberInlineSalesPurchaseDraft(ownerEntry);
    return true;
  }

  function applySalesPurchaseBeneficiarySuggestion(entry, input, optionNode = null){
    if(!entry || !(input instanceof HTMLInputElement)) return false;
    const nameFromNode = optionNode instanceof HTMLElement ? toSafeText(optionNode.getAttribute('data-sales-purchase-beneficiary-suggestion-name')) : '';
    const host = getSalesPurchaseBeneficiaryAutocompleteHost(input);
    const activeIndex = Number(host?.dataset?.salesPurchaseBeneficiaryActiveIndex || 0) || 0;
    const items = getSalesPurchaseBeneficiarySuggestions(input.value);
    const name = nameFromNode || toSafeText(items[Math.max(0, Math.min(items.length - 1, activeIndex))]?.name);
    if(!name) return false;
    setSalesPurchaseOwnerBeneficiaryName(entry, name);
    input.value = name;
    try{ input.focus({ preventScroll:true }); }catch{ try{ input.focus(); }catch{} }
    return true;
  }

  function handleSalesPurchaseBeneficiarySuggestionClick(event, entry, scope){
    const target = event?.target instanceof Element ? event.target : null;
    const option = target ? target.closest('[data-sales-purchase-beneficiary-suggestion-index]') : null;
    if(!(option instanceof HTMLElement)) return false;
    const root = scope instanceof HTMLElement ? scope : entry?.modal;
    if(!(root instanceof HTMLElement) || !root.contains(option)) return false;
    stopSalesPurchaseControlEvent(event);
    const host = option.closest('[data-sales-purchase-beneficiary-autocomplete="true"]');
    const input = getSalesPurchaseBeneficiaryAutocompleteInput(host);
    return applySalesPurchaseBeneficiarySuggestion(entry, input, option);
  }

  function handleSalesPurchaseBeneficiarySuggestionKey(event, entry, control){
    if(!(control instanceof HTMLInputElement) || !control.matches('[data-sales-purchase-field="counterparty-name"]')) return false;
    const host = getSalesPurchaseBeneficiaryAutocompleteHost(control);
    const popover = getSalesPurchaseBeneficiaryAutocompletePopover(host);
    const isOpen = !!(popover instanceof HTMLElement && !popover.hidden);
    if(event.key === 'ArrowDown' || event.key === 'ArrowUp'){
      stopSalesPurchaseControlEvent(event);
      const currentIndex = Number(host?.dataset?.salesPurchaseBeneficiaryActiveIndex || 0) || 0;
      const items = syncSalesPurchaseBeneficiarySuggestions(entry, control, {
        activeIndex: isOpen ? currentIndex + (event.key === 'ArrowDown' ? 1 : -1) : 0,
        open: true
      });
      if(!items.length) closeSalesPurchaseBeneficiarySuggestions(host);
      return true;
    }
    if(event.key === 'Enter' || event.key === 'NumpadEnter'){
      if(!isOpen) return false;
      stopSalesPurchaseControlEvent(event);
      applySalesPurchaseBeneficiarySuggestion(entry, control);
      return true;
    }
    if(event.key === 'Escape'){
      if(!isOpen) return false;
      stopSalesPurchaseControlEvent(event);
      closeSalesPurchaseBeneficiarySuggestions(host);
      return true;
    }
    return false;
  }

  function closeSalesPurchaseBeneficiarySuggestionsOutside(entry, target){
    if(!entry || !(entry.modal instanceof HTMLElement)) return false;
    if(target && entry.modal.contains(target) && target.closest('[data-sales-purchase-beneficiary-autocomplete="true"]')) return false;
    closeSalesPurchaseBeneficiarySuggestions(entry.modal);
    return true;
  }

  function notifySalesPurchaseCustomerCardsUpdated(detail = {}){
    const events = TAIF?.core?.events;
    if(events && typeof events.emitDomainUpdate === 'function'){
      events.emitDomainUpdate('customer-card', detail, { source:'sales-purchase' });
      return;
    }
    if(typeof window !== 'undefined' && typeof window.dispatchEvent === 'function'){
      try{ window.dispatchEvent(new CustomEvent('taif:customer-card-updated', { detail:{ domain:'customer-card', ...detail } })); }catch{}
    }
  }

  function commitSalesPurchasePartyCustomer(entry){
    if(!entry || !isSalesPurchasePartyEntry(entry) || !entry.formState) return false;
    const ownerEntry = getSalesPurchaseAttachedPartyOwner(entry);
    const { draft } = ensureSalesPurchasePartyState(entry.formState);
    const safeName = toSafeText(draft.fullName || ownerEntry?.formState?.counterpartyName);
    if(!safeName){
      const nameInput = entry.modal instanceof HTMLElement ? entry.modal.querySelector('[data-sales-purchase-party-field="fullName"]') : null;
      if(nameInput instanceof HTMLElement) focusSalesPurchaseElement(nameInput);
      return true;
    }

    let selectedName = safeName;
    let savedRecord = null;
    let customerRecords = readSalesPurchaseCustomerCardRecords();
    const existingRecord = findSalesPurchaseCustomerRecordByBeneficiaryName(safeName);
    if(existingRecord){
      selectedName = toSafeText(existingRecord.fullName || existingRecord.latinName || safeName);
    }else{
      const api = typeof getSalesPurchasePartyCustomerApi === 'function' ? getSalesPurchasePartyCustomerApi() : null;
      if(api && typeof api.addRecordFromState === 'function'){
        const result = api.addRecordFromState({ ...draft, fullName:safeName });
        savedRecord = result && result.record ? result.record : null;
        customerRecords = Array.isArray(result?.records) ? result.records : readSalesPurchaseCustomerCardRecords();
        notifySalesPurchaseCustomerCardsUpdated({ record:savedRecord, records:customerRecords, reason:'sales-purchase-beneficiary-add' });
      }
    }

    if(ownerEntry) setSalesPurchaseOwnerBeneficiaryName(ownerEntry, selectedName);
    entry.partyCommitAccepted = true;
    closeWindow(entry.id);
    return true;
  }

  function cancelSalesPurchasePartyCustomer(entry){
    if(!entry || !isSalesPurchasePartyEntry(entry) || entry.partyCommitAccepted) return false;
    const ownerEntry = getSalesPurchaseAttachedPartyOwner(entry);
    if(!ownerEntry) return false;
    setSalesPurchaseOwnerBeneficiaryName(ownerEntry, '');
    return true;
  }

  function handleSalesPurchaseTextFieldInput(entry, target, options = {}){
    if(!entry || !(target instanceof HTMLElement)) return false;
    const field = String(target.getAttribute('data-sales-purchase-field') || '').trim();
    const host = options && options.host instanceof HTMLElement ? options.host : entry.modal;
    const commitTextValue = (fieldKey, stateKey, allowTextarea = false) => {
      if(field !== fieldKey) return false;
      if(!(target instanceof HTMLInputElement) && !(allowTextarea && target instanceof HTMLTextAreaElement)) return false;
      prepareSalesPurchaseFormMutation(entry, { clearLookup:true, syncBaseline:true });
      entry.formState[stateKey] = String(target.value || '');
      entry.formState.alertIssues = [];
      syncSalesPurchaseNavigatorUi(entry);
      return true;
    };

    if(field === 'counterparty-name' && target instanceof HTMLInputElement){
      prepareSalesPurchaseFormMutation(entry, { clearLookup:true, syncBaseline:true });
      entry.formState.counterpartyName = String(target.value || '');
      entry.formState.alertIssues = [];
      const avatarNode = host?.querySelector('.sales-purchase-name-field__avatar');
      if(avatarNode instanceof HTMLElement){
        avatarNode.innerHTML = renderSalesPurchasePartyAvatarMarkup({ variant: toSafeText(entry.formState.counterpartyName) ? 'plain' : 'add' });
      }
      syncSalesPurchaseBeneficiarySuggestions(entry, target, { open:true });
      return true;
    }

    return commitTextValue('invoice-summary', 'invoiceSummary')
      || commitTextValue('notes', 'notes', true);
  }

  function handleSalesPurchaseSharedInputTarget(entry, target, options = {}){
    if(!entry || !(target instanceof HTMLElement)) return false;
    if(syncSalesPurchaseNavigatorLookupInput(entry, target)) return true;
    if(handleSalesPurchaseMainDatePartInput(entry, target)) return true;
    if(handleSalesPurchaseAmountFieldInput(entry, target)) return true;
    return handleSalesPurchaseTextFieldInput(entry, target, options);
  }

  function syncSalesPurchaseNavigatorLookupInput(entry, target){
    if(!(target instanceof HTMLInputElement)) return false;
    if(!target.matches('[data-sales-purchase-nav="lookup"]')) return false;
    const navigator = ensureSalesPurchaseNavigatorState(entry.formState);
    const normalizedValue = normalizeSalesPurchasePageLookup(target.value || '');
    navigator.lookupValue = normalizedValue;
    if(target.value !== normalizedValue) target.value = normalizedValue;
    return true;
  }

  function stopSalesPurchaseControlEvent(event){
    event.preventDefault();
    event.stopPropagation();
  }

  const SALES_PURCHASE_DATE_MONTH_STEPS = Object.freeze({
    'prev-month': -1,
    'next-month': 1,
    'prev-year': -12,
    'next-year': 12
  });

  function resolveSalesPurchaseDateControlAction(dateControl){
    return String(dateControl?.getAttribute('data-sales-purchase-date-action') || '').trim();
  }

  function updateSalesPurchaseDatePickerView(entry, dateControl, selectedValue){
    entry.formState.datePickerView = salesPurchaseNormalizeDatePickerView(dateControl.getAttribute('data-sales-purchase-date-view') || 'days');
    entry.formState.datePickerMonthCursor = salesPurchaseResolveMonthCursor(
      selectedValue,
      dateControl.getAttribute('data-sales-purchase-date-month') || entry.formState.datePickerMonthCursor
    );
    rerenderSalesPurchaseEntryAndFocusMainDateControl(entry);
  }

  function shiftSalesPurchaseDatePickerMonth(entry, monthCursor, dateAction){
    if(!Object.prototype.hasOwnProperty.call(SALES_PURCHASE_DATE_MONTH_STEPS, dateAction)) return false;
    entry.formState.datePickerMonthCursor = salesPurchaseShiftMonthCursor(monthCursor, SALES_PURCHASE_DATE_MONTH_STEPS[dateAction]);
    rerenderSalesPurchaseEntryAndFocusMainDateControl(entry);
    return true;
  }

  function pickSalesPurchaseDatePickerMonth(entry, selectedValue, monthCursor){
    entry.formState.datePickerMonthCursor = salesPurchaseResolveMonthCursor(selectedValue, monthCursor);
    entry.formState.datePickerView = 'days';
    rerenderSalesPurchaseEntryAndFocusMainDateControl(entry);
  }

  function commitSalesPurchaseDatePickerValue(entry, dateControl, selectedValue){
    const nextDateValue = salesPurchaseNormalizeDateInputValue(dateControl.getAttribute('data-sales-purchase-date-value') || selectedValue);
    prepareSalesPurchaseFormMutation(entry, { clearLookup:true, syncBaseline:true });
    entry.formState.voucherDate = nextDateValue;
    entry.formState.alertIssues = [];
    entry.formState.datePickerMonthCursor = salesPurchaseResolveMonthCursor(nextDateValue, nextDateValue.slice(0, 7));
    entry.formState.datePickerOpen = false;
    entry.formState.datePickerView = 'days';
    rerenderSalesPurchaseEntryAndFocusMainDateTrigger(entry);
  }

  function closeSalesPurchaseDatePicker(entry){
    entry.formState.datePickerOpen = false;
    entry.formState.datePickerView = 'days';
    rerenderSalesPurchaseEntryAndFocusMainDateTrigger(entry);
  }

  function handleSalesPurchaseMainDateControlClick(event, entry, dateControl){
    if(!entry || !(dateControl instanceof HTMLElement)) return false;
    stopSalesPurchaseControlEvent(event);
    const dateAction = resolveSalesPurchaseDateControlAction(dateControl);
    const selectedValue = salesPurchaseNormalizeDateInputValue(entry.formState.voucherDate);

    if(dateAction === 'toggle'){
      entry.formState.datePickerMonthCursor = salesPurchaseResolveMonthCursor(selectedValue, entry.formState.datePickerMonthCursor);
      toggleSalesPurchaseDatePicker(entry, { placement:'current' });
      return true;
    }

    if(!entry.formState.datePickerOpen) return true;

    if(dateAction === 'toggle-view'){
      updateSalesPurchaseDatePickerView(entry, dateControl, selectedValue);
      return true;
    }

    const monthCursor = dateControl.getAttribute('data-sales-purchase-date-month') || entry.formState.datePickerMonthCursor;
    if(shiftSalesPurchaseDatePickerMonth(entry, monthCursor, dateAction)) return true;

    if(dateAction === 'pick-month'){
      pickSalesPurchaseDatePickerMonth(entry, selectedValue, monthCursor);
      return true;
    }

    if(dateAction === 'today' || dateAction === 'select-day'){
      commitSalesPurchaseDatePickerValue(entry, dateControl, selectedValue);
      return true;
    }

    if(dateAction === 'clear'){
      commitSalesPurchaseDatePickerValue(entry, dateControl, '');
      return true;
    }

    if(dateAction === 'close'){
      closeSalesPurchaseDatePicker(entry);
      return true;
    }

    return true;
  }

  function handleSalesPurchaseNavigatorControlClick(event, entry, navControl){
    if(!entry || !(navControl instanceof HTMLElement)) return false;
    stopSalesPurchaseControlEvent(event);
    runSalesPurchaseNavigatorAction(entry, String(navControl.getAttribute('data-sales-purchase-nav') || ''));
    return true;
  }

  function resetInlineSalesPurchaseEntryToNewRecord(entry){
    const activeActionId = normalizeInlineSalesPurchaseActionId(entry.action?.id || entry.formState?.windowActionId);
    entry.formState = buildSalesPurchaseNewBlankFormState(activeActionId, entry.formState);
    entry.formState.windowActionId = activeActionId;
    rememberInlineSalesPurchaseDraft(entry);
    syncSalesPurchaseNavigatorBaseline(entry);
    renderWindowForm(entry, () => {
      const amountField = resolveSalesPurchasePreferredAmountFocus(entry, entry.modal)
        || entry.modal?.querySelector('[data-sales-purchase-field="amount"]');
      if(amountField instanceof HTMLElement) focusSalesPurchaseElement(amountField);
    });
  }

  function isSalesPurchaseActionControlDisabled(control){
    return (control instanceof HTMLButtonElement && control.disabled)
      || control.getAttribute('aria-disabled') === 'true';
  }

  function resolveSalesPurchaseActionName(control){
    return String(control.getAttribute('data-sales-purchase-action') || '').trim();
  }

  function handleSalesPurchaseCloseWindowAction(actionName, event, safeOptions){
    if(actionName !== 'close-window') return false;
    if(typeof safeOptions.closeWindow !== 'function') return false;
    safeOptions.closeWindow(event);
    return true;
  }

  function handleSalesPurchaseInlineSwitchAction(actionName, event, control, safeOptions){
    if(actionName !== 'open-window' || !safeOptions.inlineMode) return false;
    const nextActionId = control.getAttribute('data-sales-purchase-inline-invoice')
      || control.getAttribute('data-sales-purchase-window')
      || '';
    if(!INLINE_SALES_PURCHASE_ACTION_IDS.has(String(nextActionId || '').trim())) return false;
    stopSalesPurchaseControlEvent(event);
    switchInlineSalesPurchaseWorkspace(nextActionId);
    return true;
  }

  function handleSalesPurchaseRecordCommandAction(actionName, event, entry){
    const commandHandlers = {
      'execute-window': () => executeWindowOperation(entry),
      'reverse-window-record': () => requestReverseSalesPurchaseWindowRecord(entry),
      'delete-window-record': () => requestDeleteSalesPurchaseWindowRecord(entry)
    };
    const handler = commandHandlers[actionName];
    if(typeof handler !== 'function') return false;
    stopSalesPurchaseControlEvent(event);
    handler();
    return true;
  }

  function handleSalesPurchaseNewRecordAction(actionName, event, entry, safeOptions){
    if(actionName !== 'open-new-window') return false;
    stopSalesPurchaseControlEvent(event);
    if(safeOptions.inlineMode){
      resetInlineSalesPurchaseEntryToNewRecord(entry);
      return true;
    }
    if(!isSalesPurchaseEditingExistingRecord(resolveSalesPurchaseEffectiveActionId(entry.action.id, entry.formState), entry.formState)) return true;
    openWindow(entry.action.id, { forceNew:true });
    return true;
  }

  function handleSalesPurchasePartyWindowAction(actionName, event, entry, safeOptions){
    if(actionName !== 'open-party-window') return false;
    stopSalesPurchaseControlEvent(event);
    openWindow('party', {
      sourceFormState: entry.formState,
      ownerWindowId: String(safeOptions.ownerWindowId || entry.id || '').trim()
    });
    return true;
  }

  function handleSalesPurchaseTogglePickerAction(actionName, event, entry, control){
    if(actionName !== 'toggle-picker') return false;
    stopSalesPurchaseControlEvent(event);
    const pickerKey = String(control.getAttribute('data-sales-purchase-picker-key') || '').trim();
    toggleSalesPurchasePicker(entry, pickerKey, { placement:'current' });
    return true;
  }

  function prepareSalesPurchaseSelectionAction(event, entry){
    stopSalesPurchaseControlEvent(event);
    prepareSalesPurchaseFormMutation(entry, { clearLookup:true, syncBaseline:true });
    entry.formState.alertIssues = [];
  }

  function handleSalesPurchaseCurrencySelectionAction(actionName, event, entry, control){
    if(actionName !== 'select-currency') return false;
    prepareSalesPurchaseSelectionAction(event, entry);
    const pickerKey = String(control.getAttribute('data-sales-purchase-picker-key') || '').trim();
    const nextCurrencyCode = String(control.getAttribute('data-sales-purchase-currency-option') || '').trim().toUpperCase();
    if(pickerKey === 'buy-card') entry.formState.buyCurrencyCode = nextCurrencyCode;
    if(pickerKey === 'sell-card') entry.formState.sellCurrencyCode = nextCurrencyCode;
    entry.formState.lastChangedPickerKey = pickerKey;
    entry.formState.openPickerKey = null;
    rerenderSalesPurchaseEntryAndFocusPreferredAmount(entry);
    return true;
  }

  function handleSalesPurchaseRateModeAction(actionName, event, entry, control){
    if(actionName !== 'select-rate-mode') return false;
    stopSalesPurchaseControlEvent(event);
    if(document.activeElement instanceof HTMLElement) document.activeElement.blur();
    prepareSalesPurchaseFormMutation(entry, { clearLookup:true, syncBaseline:true });
    entry.formState.rateMode = String(control.getAttribute('data-sales-purchase-rate-mode') || '').trim() === 'manual' ? 'manual' : 'auto';
    entry.formState.alertIssues = [];
    rerenderSalesPurchaseEntryAndFocus(entry, (host) => entry.formState.rateMode === 'manual'
      ? host?.querySelector('[data-sales-purchase-field="manual-rate"]')
      : resolveSalesPurchasePreferredAmountFocus(entry, host));
    return true;
  }

  function handleSalesPurchaseCalcMethodAction(actionName, event, entry, control){
    if(actionName !== 'select-purchase-calc-method') return false;
    prepareSalesPurchaseSelectionAction(event, entry);
    entry.formState.purchaseCalcMethod = normalizeSalesPurchaseWorkspaceCalcMethod(control.getAttribute('data-sales-purchase-calc-method-option'));
    entry.formState.openPickerKey = null;
    rerenderSalesPurchaseEntryAndFocusPreferredAmount(entry);
    return true;
  }

  function handleSalesPurchaseCashAccountAction(actionName, event, entry, control){
    if(actionName !== 'select-cash-account') return false;
    prepareSalesPurchaseSelectionAction(event, entry);
    entry.formState.cashAccountNo = String(control.getAttribute('data-sales-purchase-account-option') || '').trim();
    entry.formState.openPickerKey = null;
    rerenderSalesPurchaseEntryAndFocusPreferredAmount(entry);
    return true;
  }

  function handleSalesPurchasePartyCustomerSaveAction(actionName, event, entry){
    if(actionName !== 'save-party-customer') return false;
    stopSalesPurchaseControlEvent(event);
    commitSalesPurchasePartyCustomer(entry);
    return true;
  }

  function handleSalesPurchaseMainActionClick(event, entry, control, options = {}){
    if(!entry || !(control instanceof HTMLElement)) return false;
    if(isSalesPurchaseActionControlDisabled(control)){
      stopSalesPurchaseControlEvent(event);
      return true;
    }

    const safeOptions = options && typeof options === 'object' ? options : {};
    const actionName = resolveSalesPurchaseActionName(control);

    return handleSalesPurchasePartyCustomerSaveAction(actionName, event, entry)
      || handleSalesPurchaseCloseWindowAction(actionName, event, safeOptions)
      || handleSalesPurchaseInlineSwitchAction(actionName, event, control, safeOptions)
      || handleSalesPurchaseRecordCommandAction(actionName, event, entry)
      || handleSalesPurchaseNewRecordAction(actionName, event, entry, safeOptions)
      || handleSalesPurchasePartyWindowAction(actionName, event, entry, safeOptions)
      || handleSalesPurchaseTogglePickerAction(actionName, event, entry, control)
      || handleSalesPurchaseCurrencySelectionAction(actionName, event, entry, control)
      || handleSalesPurchaseRateModeAction(actionName, event, entry, control)
      || handleSalesPurchaseCalcMethodAction(actionName, event, entry, control)
      || handleSalesPurchaseCashAccountAction(actionName, event, entry, control);
  }

  function resolveInlinePurchaseWorkspaceEntry(panel = runtime.panel){
    const host = getInlinePurchaseWorkspaceHost(panel);
    if(!(host instanceof HTMLElement)) return null;
    return ensureInlinePurchaseWorkspaceEntry(host);
  }

  function handleInlinePurchaseWorkspacePointerDown(event, panel = runtime.panel){
    const entry = resolveInlinePurchaseWorkspaceEntry(panel);
    if(!entry || !(entry.modal instanceof HTMLElement)) return false;
    const control = event.target instanceof Element ? event.target.closest('[data-sales-purchase-action="select-rate-mode"]') : null;
    if(!(control instanceof HTMLElement) || !entry.modal.contains(control)) return false;
    event.preventDefault();
    if(document.activeElement instanceof HTMLElement) document.activeElement.blur();
    return true;
  }

  function handleInlinePurchaseWorkspaceClick(event, panel = runtime.panel){
    const entry = resolveInlinePurchaseWorkspaceEntry(panel);
    if(!entry || !(entry.modal instanceof HTMLElement)) return false;
    const host = entry.modal;
    const target = event.target instanceof Element ? event.target : null;
    if(!target || !host.contains(target)) return false;

    const isSideboxBasisInteraction = !!target.closest('[data-sales-purchase-sidebox-basis="true"]');
    const shouldCloseSideboxBasisAfterClick = runtime.salesPurchaseSideboxRateBasisOpen && !isSideboxBasisInteraction;
    if(shouldCloseSideboxBasisAfterClick) runtime.salesPurchaseSideboxRateBasisOpen = false;

    const dateControl = target.closest('[data-sales-purchase-date-action]');
    if(dateControl instanceof HTMLElement && host.contains(dateControl)){
      return handleSalesPurchaseMainDateControlClick(event, entry, dateControl);
    }

    const sideboxBasisToggle = target.closest('[data-sales-purchase-sidebox-basis-toggle]');
    if(sideboxBasisToggle instanceof HTMLElement && host.contains(sideboxBasisToggle)){
      stopSalesPurchaseControlEvent(event);
      toggleSalesPurchaseSideboxRateBasisPicker(panel);
      return true;
    }

    const sideboxBasisOption = target.closest('[data-sales-purchase-sidebox-basis-option]');
    if(sideboxBasisOption instanceof HTMLElement && host.contains(sideboxBasisOption)){
      stopSalesPurchaseControlEvent(event);
      selectSalesPurchaseSideboxRateBasis(sideboxBasisOption.getAttribute('data-sales-purchase-sidebox-basis-option'), panel);
      return true;
    }

    const sideboxNavControl = target.closest('[data-sales-purchase-sidebox-nav]');
    if(sideboxNavControl instanceof HTMLElement && host.contains(sideboxNavControl)){
      stopSalesPurchaseControlEvent(event);
      runtime.salesPurchaseSideboxRateBasisOpen = false;
      if(sideboxNavControl instanceof HTMLButtonElement && sideboxNavControl.disabled) return true;
      moveSalesPurchaseSideboxPricePage(String(sideboxNavControl.getAttribute('data-sales-purchase-sidebox-nav') || 'next'), panel);
      return true;
    }

    if(handleSalesPurchaseBeneficiarySuggestionClick(event, entry, host)) return true;

    const navControl = target.closest('[data-sales-purchase-nav]:not([disabled])');
    if(navControl instanceof HTMLElement && host.contains(navControl)){
      return handleSalesPurchaseNavigatorControlClick(event, entry, navControl);
    }

    const control = target.closest('[data-sales-purchase-action]');
    if(!(control instanceof HTMLElement) || !host.contains(control)){
      if(shouldCloseSideboxBasisAfterClick){
        refreshSalesPurchaseSideboxPricesUi(panel);
        return true;
      }
      return false;
    }
    if(handleSalesPurchaseMainActionClick(event, entry, control, {
      inlineMode: true,
      ownerWindowId: INLINE_PURCHASE_WORKSPACE_ENTRY_ID
    })) return true;

    if(shouldCloseSideboxBasisAfterClick){
      refreshSalesPurchaseSideboxPricesUi(panel);
      return true;
    }

    return false;
  }

  function handleInlinePurchaseWorkspaceInput(event, panel = runtime.panel){
    const entry = resolveInlinePurchaseWorkspaceEntry(panel);
    if(!entry || !(entry.modal instanceof HTMLElement)) return false;
    const target = event.target;
    if(!(target instanceof HTMLElement) || !entry.modal.contains(target)) return false;
    return handleSalesPurchaseSharedInputTarget(entry, target, { host: entry.modal });
  }

  function handleInlinePurchaseWorkspaceKeyDown(event, panel = runtime.panel){
    const entry = resolveInlinePurchaseWorkspaceEntry(panel);
    if(!entry || !(entry.modal instanceof HTMLElement)) return false;
    if(event.defaultPrevented || event.isComposing || event.altKey || event.ctrlKey || event.metaKey) return false;
    const target = event.target instanceof Element ? event.target : null;
    const control = target ? target.closest('input') : null;
    if(!(control instanceof HTMLInputElement) || !entry.modal.contains(control)) return false;
    return handleSalesPurchaseBeneficiarySuggestionKey(event, entry, control);
  }

  function handleInlinePurchaseWorkspaceDocumentPointerDown(event, panel = runtime.panel){
    const entry = runtime.inlinePurchaseWorkspaceEntry;
    if(!entry || !entry.formState) return false;
    const host = getInlinePurchaseWorkspaceHost(panel);
    if(!(host instanceof HTMLElement)) return false;
    entry.modal = host;
    const target = event.target instanceof Element ? event.target : null;

    if(runtime.salesPurchaseSideboxRateBasisOpen){
      if(target && host.contains(target)) return false;
      closeSalesPurchaseSideboxRateBasisPicker(panel);
    }

    const hasBeneficiaryAutocomplete = !!host.querySelector('[data-sales-purchase-beneficiary-suggestions="true"]:not([hidden])');
    if(hasBeneficiaryAutocomplete){
      closeSalesPurchaseBeneficiarySuggestionsOutside(entry, target);
    }

    const hasPopover = !!entry.formState.openPickerKey || !!entry.formState.datePickerOpen;
    if(!hasPopover) return hasBeneficiaryAutocomplete;
    if(target && host.contains(target) && target.closest('[data-sales-purchase-picker-host], [data-sales-purchase-date-picker="true"], [data-sales-purchase-beneficiary-autocomplete="true"]')) return false;
    const focusField = target && host.contains(target)
      ? String(target.getAttribute('data-sales-purchase-field') || '').trim()
      : '';
    entry.formState.openPickerKey = null;
    entry.formState.datePickerOpen = false;
    entry.formState.datePickerView = 'days';
    renderWindowForm(entry, () => {
      if(!focusField) return;
      const nextTarget = entry.modal?.querySelector(`[data-sales-purchase-field="${focusField}"]`);
      if(nextTarget instanceof HTMLElement) focusSalesPurchaseElement(nextTarget);
    });
    return true;
  }


  function syncSalesPurchaseNavigatorUi(entry){
    if(!entry || !(entry.modal instanceof HTMLElement) || !entry.action) return;
    const navState = getSalesPurchaseNavigatorRenderState(resolveSalesPurchaseEffectiveActionId(entry.action.id, entry.formState), entry.formState);
    const lookupInput = entry.modal.querySelector('[data-sales-purchase-nav="lookup"]');
    const countStrong = entry.modal.querySelector('.sales-purchase-topdock .entries-voucher-navbox__count strong');
    const prevButtons = entry.modal.querySelectorAll('[data-sales-purchase-nav="prev"], [data-sales-purchase-nav="prev10"]');
    const nextButtons = entry.modal.querySelectorAll('[data-sales-purchase-nav="next"], [data-sales-purchase-nav="next10"]');

    if(lookupInput instanceof HTMLInputElement){
      const safeLookupValue = String(navState.lookupValue || '');
      if(lookupInput.value !== safeLookupValue) lookupInput.value = safeLookupValue;
    }
    if(countStrong instanceof HTMLElement){
      countStrong.textContent = String(navState.count);
    }
    prevButtons.forEach((button) => {
      if(!(button instanceof HTMLButtonElement)) return;
      button.disabled = !navState.canPrev;
    });
    nextButtons.forEach((button) => {
      if(!(button instanceof HTMLButtonElement)) return;
      button.disabled = !navState.canNext;
    });
  }


  function setSalesPurchaseWindowMutationBusy(entry, isBusy = false, mode = ''){
    if(!entry || !(entry.modal instanceof HTMLElement)){
      if(entry){
        entry.isMutating = !!isBusy;
        entry.mutationMode = entry.isMutating ? String(mode || '').trim() : '';
      }
      return;
    }
    entry.isMutating = !!isBusy;
    entry.mutationMode = entry.isMutating ? String(mode || '').trim() : '';
    syncSalesPurchaseWindowActionButtons(entry);
  }

  function resolveSalesPurchaseWindowActionState(entry){
    if(!entry || !(entry.modal instanceof HTMLElement) || !entry.action) return null;
    const effectiveActionId = resolveSalesPurchaseEffectiveActionId(entry.action.id, entry.formState);
    const editingRecord = resolveSalesPurchaseNavigatorLinkedRecord(effectiveActionId, entry.formState);
    const isEditing = !!editingRecord;
    const isReversed = isSalesPurchaseRecordReversed(editingRecord);
    const isBusy = !!entry.isMutating;
    const busyMode = String(entry.mutationMode || '').trim();
    return {
      effectiveActionId,
      editingRecord,
      isEditing,
      isReversed,
      isBusy,
      busyMode
    };
  }

  function applySalesPurchaseWindowButtonState(button, { enabled = true, title = '', label = null, datasets = null } = {}){
    if(!(button instanceof HTMLElement)) return;
    if(button instanceof HTMLButtonElement) button.disabled = !enabled;
    button.setAttribute('aria-disabled', enabled ? 'false' : 'true');
    button.setAttribute('aria-label', title);
    button.setAttribute('title', title);
    if(label !== null){
      const textNode = button.querySelector('.taif-control-text');
      if(textNode instanceof HTMLElement) textNode.textContent = String(label || '');
    }
    if(datasets && typeof datasets === 'object'){
      Object.entries(datasets).forEach(([key, value]) => {
        if(value == null){
          delete button.dataset[key];
          return;
        }
        button.dataset[key] = String(value);
      });
    }
  }

  const SALES_PURCHASE_WINDOW_BUSY_LABELS = Object.freeze({
    execute: 'جارٍ التنفيذ...',
    edit: 'جارٍ التعديل...',
    delete: 'جارٍ الحذف...',
    reverse: 'جارٍ العكس...'
  });

  const SALES_PURCHASE_WINDOW_BUSY_TITLES = Object.freeze({
    execute: 'تتم الآن معالجة تنفيذ العملية الحالية.',
    edit: 'تتم الآن معالجة تعديل الفاتورة الحالية.',
    delete: 'تتم الآن معالجة حذف الفاتورة الحالية.',
    reverse: 'تتم الآن معالجة عكس الفاتورة الحالية.'
  });

  function resolveSalesPurchaseCommitButtonSpec(state){
    const { isEditing, isReversed, isBusy, busyMode } = state;
    return {
      selector: 'button[data-sales-purchase-action="execute-window"]',
      enabled: !(isBusy || isReversed),
      title: isBusy
        ? (SALES_PURCHASE_WINDOW_BUSY_TITLES[busyMode] || 'تتم الآن معالجة الطلب الحالي.')
        : (isReversed
            ? 'هذه الفاتورة ملغاة وأصبحت للعرض فقط'
            : (isEditing ? 'تطبيق التعديل على الفاتورة الحالية' : 'تنفيذ العملية')),
      label: isBusy
        ? (SALES_PURCHASE_WINDOW_BUSY_LABELS[busyMode] || 'قيد المعالجة...')
        : (isReversed ? 'ملغاة' : (isEditing ? 'تعديل' : 'تنفيذ العملية')),
      datasets: {
        salesPurchaseCommitMode: isBusy ? (busyMode || 'busy') : (isReversed ? 'reversed' : (isEditing ? 'edit' : 'create')),
        salesPurchaseBusy: isBusy ? 'true' : 'false'
      }
    };
  }

  function resolveSalesPurchaseNewButtonSpec(state){
    const { isEditing, isBusy } = state;
    return {
      selector: 'button[data-sales-purchase-action="open-new-window"]',
      enabled: !isBusy,
      title: isBusy
        ? 'انتظر حتى تنتهي المعالجة الحالية قبل فتح نافذة جديدة.'
        : (isEditing ? 'فتح فاتورة جديدة مع إبقاء هذه الفاتورة مفتوحة' : 'تفريغ الحقول وبدء فاتورة جديدة'),
      datasets: {
        salesPurchaseWindowMode: isBusy ? 'busy' : (isEditing ? 'editing' : 'create')
      }
    };
  }

  function resolveSalesPurchaseDeleteButtonSpec(state){
    const { editingRecord, isBusy } = state;
    const enabled = !!editingRecord && !isBusy;
    return {
      selector: 'button[data-sales-purchase-action="delete-window-record"]',
      enabled,
      title: isBusy
        ? 'انتظر حتى تنتهي المعالجة الحالية قبل الحذف.'
        : (enabled
            ? 'حذف هذه الفاتورة نهائياً مع تنظيف كامل أثرها المرتبط من السجلات والقيود'
            : 'يتاح هذا الزر فقط عند استعراض فاتورة سابقة'),
      datasets: {
        salesPurchaseBusy: isBusy ? 'true' : 'false'
      }
    };
  }

  function resolveSalesPurchaseReverseButtonSpec(state){
    const { isEditing, isReversed, isBusy } = state;
    const enabled = isEditing && !isReversed && !isBusy;
    return {
      selector: 'button[data-sales-purchase-action="reverse-window-record"]',
      enabled,
      title: isBusy
        ? 'انتظر حتى تنتهي المعالجة الحالية قبل تنفيذ العكس.'
        : (!isEditing
            ? 'يتاح هذا الزر فقط عند استعراض فاتورة سابقة'
            : (isReversed
                ? 'تم عكس هذه الفاتورة مسبقاً وأصبحت للعرض فقط'
                : 'إلغاء / عكس أثر هذه الفاتورة وإعادة الأرصدة إلى وضعها الأصلي')),
      datasets: {
        salesPurchaseReverseState: isBusy ? 'busy' : (!isEditing ? 'create' : (isReversed ? 'reversed' : 'ready')),
        salesPurchaseBusy: isBusy ? 'true' : 'false'
      }
    };
  }

  const SALES_PURCHASE_WINDOW_ACTION_BUTTON_RESOLVERS = Object.freeze({
    commit: resolveSalesPurchaseCommitButtonSpec,
    new: resolveSalesPurchaseNewButtonSpec,
    delete: resolveSalesPurchaseDeleteButtonSpec,
    reverse: resolveSalesPurchaseReverseButtonSpec
  });

  function resolveSalesPurchaseWindowActionButtonSpec(actionKey, entry, state = resolveSalesPurchaseWindowActionState(entry)){
    if(!state) return null;
    const resolver = SALES_PURCHASE_WINDOW_ACTION_BUTTON_RESOLVERS[String(actionKey || '').trim()];
    return typeof resolver === 'function' ? resolver(state) : null;
  }

  function syncSalesPurchaseWindowActionButton(entry, actionKey){
    if(!entry || !(entry.modal instanceof HTMLElement)) return;
    const spec = resolveSalesPurchaseWindowActionButtonSpec(actionKey, entry);
    if(!spec) return;
    const button = entry.modal.querySelector(spec.selector);
    if(!(button instanceof HTMLButtonElement)) return;
    applySalesPurchaseWindowButtonState(button, spec);
  }

  function syncSalesPurchaseWindowActionButtons(entry){
    ['commit', 'new', 'delete', 'reverse'].forEach((actionKey) => {
      syncSalesPurchaseWindowActionButton(entry, actionKey);
    });
  }


  function syncWindowDerivedFields(entry){
    if(!entry || !(entry.modal instanceof HTMLElement) || !entry.action) return;
    const model = resolveFormModel(resolveSalesPurchaseEffectiveActionId(entry.action.id, entry.formState), entry.formState);
    const activeRateInput = entry.modal.querySelector('[data-sales-purchase-display-field="active-rate"], [data-sales-purchase-field="manual-rate"]');
    const counterpartAmountInput = entry.modal.querySelector('[data-sales-purchase-field="counterpart-amount"]');
    const amountInput = entry.modal.querySelector('[data-sales-purchase-field="amount"]');
    const buyFigureNodes = entry.modal.querySelectorAll('[data-sales-purchase-display="buy-card-figure"]');
    const sellFigureNodes = entry.modal.querySelectorAll('[data-sales-purchase-display="sell-card-figure"]');
    const useManualRate = String(entry.formState?.rateMode || 'auto').trim() === 'manual';

    if(activeRateInput instanceof HTMLInputElement && document.activeElement !== activeRateInput){
      activeRateInput.value = String(useManualRate ? (model.manualRateText || '') : model.activeRateText);
    }
    if(counterpartAmountInput instanceof HTMLInputElement && document.activeElement !== counterpartAmountInput){
      counterpartAmountInput.value = model.counterpartInputText || '';
    }
    if(amountInput instanceof HTMLInputElement && document.activeElement !== amountInput){
      amountInput.value = model.amountInputText || '';
    }
    buyFigureNodes.forEach((node) => {
      if(node instanceof HTMLElement) node.innerHTML = wrapControlTextMarkup(escapeHtml(model.buyCardFigureText), 'taif-control-text--ltr');
    });
    sellFigureNodes.forEach((node) => {
      if(node instanceof HTMLElement) node.innerHTML = wrapControlTextMarkup(escapeHtml(model.sellCardFigureText), 'taif-control-text--ltr');
    });
    syncSalesPurchaseNavigatorUi(entry);
    syncSalesPurchaseWindowActionButtons(entry);
    syncSalesPurchaseWindowLockedUi(entry);
  }

  function resolveSalesPurchasePreferredAmountFocus(entry, modal = entry && entry.modal){
    if(!(modal instanceof HTMLElement)) return null;
    const preferredField = normalizeSalesPurchaseEditedAmountField(entry?.formState?.lastEditedAmountField);
    if(preferredField === 'counterpart'){
      const counterpartInput = modal.querySelector('[data-sales-purchase-field="counterpart-amount"]');
      if(counterpartInput instanceof HTMLElement) return counterpartInput;
    }
    const amountInput = modal.querySelector('[data-sales-purchase-field="amount"]');
    return amountInput instanceof HTMLElement ? amountInput : null;
  }


  function syncSalesPurchaseWindowLockedUi(entry){
    if(!entry || !(entry.modal instanceof HTMLElement) || !entry.action) return;
    const effectiveActionId = resolveSalesPurchaseEffectiveActionId(entry.action.id, entry.formState);
    const editingRecord = resolveSalesPurchaseNavigatorLinkedRecord(effectiveActionId, entry.formState);
    const isLocked = isSalesPurchaseRecordReversed(editingRecord);
    entry.modal.classList.toggle('sales-purchase-window--locked', !!isLocked);
    const controls = entry.modal.querySelectorAll([
      '[data-sales-purchase-field="counterparty-name"]',
      '[data-sales-purchase-action="open-party-window"]',
      '[data-sales-purchase-field="invoice-summary"]',
      '[data-sales-purchase-field="notes"]',
      '[data-sales-purchase-field="amount"]',
      '[data-sales-purchase-field="counterpart-amount"]',
      '[data-sales-purchase-field="manual-rate"]',
      '[data-sales-purchase-action="toggle-picker"]',
      '[data-sales-purchase-date-action="toggle"]',
      '[data-sales-purchase-action="select-rate-mode"]',
      '[data-sales-purchase-action="select-purchase-calc-method"]'
    ].join(','));
    controls.forEach((control) => {
      if(!(control instanceof HTMLElement)) return;
      if(control instanceof HTMLInputElement || control instanceof HTMLButtonElement || control instanceof HTMLTextAreaElement || control instanceof HTMLSelectElement){
        control.disabled = !!isLocked;
      }
      if(control instanceof HTMLInputElement || control instanceof HTMLTextAreaElement){
        control.readOnly = !!isLocked;
      }
      control.setAttribute('aria-disabled', isLocked ? 'true' : 'false');
      if(isLocked){
        control.setAttribute('tabindex', '-1');
      }else if(control.getAttribute('tabindex') === '-1'){
        control.removeAttribute('tabindex');
      }
    });
  }


  function centerSalesPurchaseWindowOverOwner(entry){
    if(!entry || !(entry.modal instanceof HTMLElement)) return false;
    const ownerWindowId = toSafeText(entry.ownerWindowId);
    if(!ownerWindowId) return false;
    const ownerEntry = runtime.windows.get(ownerWindowId);
    if(!ownerEntry || !(ownerEntry.modal instanceof HTMLElement)) return false;
    const ownerRect = ownerEntry.modal.getBoundingClientRect();
    const modalRect = entry.modal.getBoundingClientRect();
    if(ownerRect.width < 40 || ownerRect.height < 40 || modalRect.width < 40 || modalRect.height < 40) return false;
    const horizontalOffset = 22;
    const verticalOffset = 62;
    const nextLeft = ownerRect.left + ((ownerRect.width - modalRect.width) / 2) + horizontalOffset;
    const nextTop = ownerRect.top + ((ownerRect.height - modalRect.height) / 2) + verticalOffset;
    if(entry.manager && typeof entry.manager.applyModalPosition === 'function'){
      withSalesPurchaseAttachmentSync(() => {
        entry.manager.applyModalPosition(entry.modal, nextLeft, nextTop);
      });
      snapshotSalesPurchaseWindowPosition(entry);
      syncSalesPurchaseAttachedOwnerBlocker(entry);
      return true;
    }
    entry.modal.style.left = `${Math.round(nextLeft)}px`;
    entry.modal.style.top = `${Math.round(nextTop)}px`;
    entry.modal.dataset.windowLeft = String(Math.round(nextLeft));
    entry.modal.dataset.windowTop = String(Math.round(nextTop));
    entry.modal.classList.add('is-positioned');
    snapshotSalesPurchaseWindowPosition(entry);
    syncSalesPurchaseAttachedOwnerBlocker(entry);
    return true;
  }


  function applySalesPurchaseWindowContext(actionId, entryLike, sourceOptions){
    if(!entryLike || !entryLike.formState || !sourceOptions || typeof sourceOptions !== 'object') return false;
    if(actionId !== 'party') return false;
    let didChange = false;
    const sourceFormState = sourceOptions.sourceFormState && typeof sourceOptions.sourceFormState === 'object'
      ? sourceOptions.sourceFormState
      : null;
    const ownerWindowId = toSafeText(sourceOptions.ownerWindowId);
    if(ownerWindowId && entryLike.ownerWindowId !== ownerWindowId){
      entryLike.ownerWindowId = ownerWindowId;
    }
    if(sourceFormState){
      const nextName = toSafeText(sourceFormState.counterpartyName);
      if(entryLike.formState.counterpartyName !== nextName){
        entryLike.formState.counterpartyName = nextName;
        didChange = true;
      }
      const { draft } = ensureSalesPurchasePartyState(entryLike.formState);
      if(nextName && toSafeText(draft.fullName) !== nextName){
        draft.fullName = nextName;
        didChange = true;
      }
    }
    return didChange;
  }

  function activateExistingSalesPurchaseWindow(existing, action, manager, options){
    if(!(existing?.backdrop instanceof HTMLElement) || !existing.backdrop.isConnected) return false;
    const didChangeExistingContext = applySalesPurchaseWindowContext(action.id, existing, options);
    if(didChangeExistingContext) renderWindowForm(existing);
    if(action.id === 'party') syncSalesPurchasePartyAttachment(existing);
    const didCenterExisting = action.id === 'party' ? centerSalesPurchaseWindowOverOwner(existing) : false;
    if(!didCenterExisting) manager.syncModalWithinViewport(existing.modal);
    manager.activateModalWindow(existing.backdrop);
    focusWindow(existing.modal);
    return true;
  }

  function createSalesPurchaseWindowController(entry, config = {}){
    const resolvedWindowId = toSafeText(config.resolvedWindowId);
    const closeButton = config.closeButton instanceof HTMLElement ? config.closeButton : null;
    const expandButton = config.expandButton instanceof HTMLElement ? config.expandButton : null;
    const registerCleanup = typeof config.registerCleanup === 'function' ? config.registerCleanup : (cleanup) => cleanup;
    const action = entry && entry.action ? entry.action : {};
    const backdrop = entry ? entry.backdrop : null;
    const modal = entry ? entry.modal : null;
    const manager = entry ? entry.manager : null;
    if(!(backdrop instanceof HTMLElement) || !(modal instanceof HTMLElement) || !manager){
      return { bind: () => {} };
    }

    function stopPointer(event){
      if(typeof stopEventPropagation === 'function'){
        stopEventPropagation(event);
        return;
      }
      event.stopPropagation();
    }

    function activate(){
      manager.activateModalWindow(backdrop);
    }

    function stopBackdropBlockingPointer(event){
      if(!(backdrop instanceof HTMLElement) || !backdrop.classList.contains('sales-purchase-modal-backdrop--attached-blocker')) return;
      if(event.target instanceof Node && modal.contains(event.target)) return;
      if(handleSalesPurchaseAttachedOwnerHeadInteraction(entry, event)) return;
      event.preventDefault();
      stopPointer(event);
      manager.activateModalWindow(backdrop);
    }

    const toggleExpand = (() => {
      const ownerEntry = action.id === 'party' ? getSalesPurchaseAttachedPartyOwner(entry) : null;
      if(ownerEntry && ownerEntry.manager){
        const shouldRestore = modal.classList.contains('is-maximized');
        withSalesPurchaseAttachmentSync(() => {
          if(shouldRestore){
            if(modal.classList.contains('is-maximized')) manager.restoreModalWindow(modal);
            clearSalesPurchaseAttachedPartyMaximizedState(entry);
            if(entry.didMaximizeOwnerForAttachment && ownerEntry.modal.classList.contains('is-maximized')) ownerEntry.manager.restoreModalWindow(ownerEntry.modal);
            entry.didMaximizeOwnerForAttachment = false;
            syncSalesPurchaseAttachedOwnerBlocker(entry);
          } else {
            if(!ownerEntry.modal.classList.contains('is-maximized')){
              ownerEntry.manager.maximizeModalWindow(ownerEntry.modal);
              entry.didMaximizeOwnerForAttachment = true;
            } else {
              entry.didMaximizeOwnerForAttachment = false;
            }
            manager.maximizeModalWindow(modal);
            applySalesPurchaseAttachedPartyMaximizedFrame(ownerEntry, entry);
            syncSalesPurchaseAttachedOwnerBlocker(entry);
          }
        });
        syncSalesPurchaseAttachedOwnerBlocker(entry);
        syncSalesPurchaseAttachedExpandButtons([ownerEntry, entry]);
        manager.activateModalWindow(backdrop);
        return;
      }

      if(typeof windowChrome.createToggleExpandHandler === 'function'){
        windowChrome.createToggleExpandHandler({
          modal,
          expandButton,
          maximizeModalWindow: manager.maximizeModalWindow,
          restoreModalWindow: manager.restoreModalWindow,
          syncExpandButton: () => syncExpandButton(expandButton, modal),
          activateModalWindow: () => manager.activateModalWindow(backdrop)
        })();
        return;
      }

      if(modal.classList.contains('is-maximized')) manager.restoreModalWindow(modal);
      else manager.maximizeModalWindow(modal);
      syncExpandButton(expandButton, modal);
      manager.activateModalWindow(backdrop);
    });

    function onResize(){
      if(syncSalesPurchaseAttachedMaximizedPair(entry)) return;
      manager.syncModalWithinViewport(modal);
    }

    function onCloseButtonClick(event){
      closeWindow(resolvedWindowId, event);
    }

    const resizeObserverTarget = (runtime.panel && runtime.panel.isConnected)
      ? (runtime.panel.querySelector('.sales-purchase-workbench') || runtime.panel)
      : null;
    let resizeObserver = null;

    function onExternalDataUpdated(){
      if(!runtime.windows.has(resolvedWindowId)) return;
      renderWindowForm(entry);
    }

    function onSalesPurchaseStateUpdated(){
      if(!runtime.windows.has(resolvedWindowId)) return;
      const navigator = ensureSalesPurchaseNavigatorState(entry.formState);
      const currentRecordId = toSafeText(navigator.currentRecordId);
      if(currentRecordId){
        const effectiveActionId = resolveSalesPurchaseEffectiveActionId(entry.action.id, entry.formState);
        const records = getSalesPurchaseNavigatorRecords(effectiveActionId, null, entry.formState);
        const recordStillExists = records.some((record) => toSafeText(record?.id) === currentRecordId);
        if(!recordStillExists){
          restoreSalesPurchaseNavigatorBaseline(entry);
        }
      }
      renderWindowForm(entry);
    }

    function onDocumentPointerDown(event){
      const partyState = entry.action?.id === 'party'
        ? ensureSalesPurchasePartyState(entry.formState)
        : { ui: { openChoiceField:'', openDateField:'', datePickerView:'days' } };
      const ui = partyState.ui;
      const hasSalesPurchasePopover = !!entry.formState.openPickerKey || !!entry.formState.datePickerOpen;
      const hasPartyPopover = !!ui.openChoiceField || !!ui.openDateField;
      const target = event.target instanceof Element ? event.target : null;
      closeSalesPurchaseBeneficiarySuggestionsOutside(entry, target);
      if(!hasSalesPurchasePopover && !hasPartyPopover) return;
      if(target && modal.contains(target) && target.closest('[data-sales-purchase-picker-host], [data-sales-purchase-date-picker="true"], [data-sales-purchase-party-choice-picker], [data-sales-purchase-party-date-picker]')) return;
      const focusField = target && modal.contains(target)
        ? String(target.getAttribute('data-sales-purchase-field') || '').trim()
        : '';
      const focusPartyField = target && modal.contains(target)
        ? String(target.getAttribute('data-sales-purchase-party-field') || '').trim()
        : '';
      let didChange = false;
      if(hasSalesPurchasePopover){
        entry.formState.openPickerKey = null;
        entry.formState.datePickerOpen = false;
        entry.formState.datePickerView = 'days';
        didChange = true;
      }
      if(hasPartyPopover){
        ui.openChoiceField = '';
        ui.openDateField = '';
        ui.datePickerView = 'days';
        didChange = true;
      }
      if(!didChange) return;
      renderWindowForm(entry);
      if(focusField){
        requestAnimationFrame(() => {
          const nextTarget = modal.querySelector(`[data-sales-purchase-field="${focusField}"]`);
          if(nextTarget instanceof HTMLElement) focusSalesPurchaseElement(nextTarget);
        });
        return;
      }
      if(focusPartyField){
        requestAnimationFrame(() => {
          const nextTarget = modal.querySelector(`[data-sales-purchase-party-field="${focusPartyField}"]`);
          if(nextTarget instanceof HTMLElement) focusSalesPurchaseElement(nextTarget);
        });
      }
    }

    function onModalPointerDown(event){
      const control = event.target instanceof Element ? event.target.closest('[data-sales-purchase-action="select-rate-mode"]') : null;
      if(!(control instanceof HTMLElement) || !modal.contains(control)) return;
      event.preventDefault();
      if(document.activeElement instanceof HTMLElement) document.activeElement.blur();
    }

    function rerenderAndFocusSelector(resolveTarget){
      renderWindowForm(entry, () => {
        const target = typeof resolveTarget === 'function' ? resolveTarget() : null;
        if(target instanceof HTMLElement) focusSalesPurchaseElement(target);
      });
    }

    function rerenderAndFocusPartyDateTrigger(fieldKey){
      rerenderAndFocusSelector(() => modal.querySelector(`[data-sales-purchase-party-date-trigger="true"][data-sales-purchase-party-date-field="${fieldKey}"]`));
    }

    function rerenderAndFocusPartyChoiceTarget(fieldKey){
      rerenderAndFocusSelector(() => fieldKey == SALES_PURCHASE_PARTY_PHONE_COUNTRY_FIELD_KEY
        ? modal.querySelector('[data-sales-purchase-party-field="phone"]')
        : modal.querySelector(`[data-sales-purchase-party-choice-trigger="true"][data-sales-purchase-party-choice-field="${fieldKey}"]`));
    }

    function closestModalControl(event, selector){
      const control = event.target instanceof Element ? event.target.closest(selector) : null;
      return control instanceof HTMLElement && modal.contains(control) ? control : null;
    }

    function consumeSalesPurchaseModalEvent(event){
      event.preventDefault();
      event.stopPropagation();
    }

    function isSalesPurchasePressKey(event){
      return event.key === 'Enter' || event.key === 'NumpadEnter' || event.key === ' ' || event.key === 'Spacebar';
    }

    function handlePartyPhoneCountrySearchClearClick(event){
      const control = closestModalControl(event, '[data-sales-purchase-party-phone-country-search-action="clear"]');
      if(!control) return false;
      consumeSalesPurchaseModalEvent(event);
      const { ui } = ensureSalesPurchasePartyState(entry.formState);
      ui.phoneCountrySearchQuery = '';
      rerenderAndFocusSelector(() => modal.querySelector('[data-sales-purchase-party-phone-country-search="true"]'));
      return true;
    }

    function handlePartyDatePickerNavigation(control, ui, selectedValue, dateAction){
      const monthCursor = control.getAttribute('data-sales-purchase-party-date-month') || ui.datePickerMonthCursor;
      if(dateAction === 'toggle-view'){
        ui.datePickerView = salesPurchaseNormalizeDatePickerView(control.getAttribute('data-sales-purchase-party-date-view') || 'days');
        ui.datePickerMonthCursor = salesPurchaseResolveMonthCursor(selectedValue || salesPurchaseTodayInputValue(), monthCursor);
        return 'focus';
      }
      if(dateAction === 'prev-month' || dateAction === 'next-month' || dateAction === 'prev-year' || dateAction === 'next-year'){
        const shiftBy = dateAction === 'prev-month' ? -1 : (dateAction === 'next-month' ? 1 : (dateAction === 'prev-year' ? -12 : 12));
        ui.datePickerMonthCursor = salesPurchaseShiftMonthCursor(monthCursor, shiftBy);
        return 'render';
      }
      if(dateAction === 'pick-month'){
        ui.datePickerMonthCursor = salesPurchaseResolveMonthCursor(selectedValue || salesPurchaseTodayInputValue(), monthCursor);
        ui.datePickerView = 'days';
        return 'render';
      }
      return '';
    }

    function handlePartyDatePickerSelection(control, draft, ui, partyFieldKey, dateAction){
      if(dateAction === 'today' || dateAction === 'select-day'){
        const nextDateValue = salesPurchaseParseIsoDate(control.getAttribute('data-sales-purchase-party-date-value'))
          ? String(control.getAttribute('data-sales-purchase-party-date-value') || '').trim()
          : salesPurchaseTodayInputValue();
        draft[partyFieldKey] = nextDateValue;
        ui.datePickerMonthCursor = salesPurchaseResolveMonthCursor(nextDateValue, nextDateValue.slice(0, 7));
        ui.openDateField = '';
        ui.datePickerView = 'days';
        return true;
      }
      if(dateAction === 'clear'){
        draft[partyFieldKey] = '';
        ui.openDateField = '';
        ui.datePickerView = 'days';
        return true;
      }
      if(dateAction === 'close'){
        ui.openDateField = '';
        ui.datePickerView = 'days';
        return true;
      }
      return false;
    }

    function handlePartyDateControlClick(event){
      const control = closestModalControl(event, '[data-sales-purchase-party-date-action], [data-sales-purchase-party-date-trigger="true"]');
      if(!control) return false;
      consumeSalesPurchaseModalEvent(event);
      const partyFieldKey = toSafeText(
        control.getAttribute('data-sales-purchase-party-date-field')
        || control.getAttribute('data-sales-purchase-party-date-trigger')
      );
      const { draft, ui } = ensureSalesPurchasePartyState(entry.formState);
      const selectedValue = salesPurchaseParseIsoDate(draft[partyFieldKey]) ? String(draft[partyFieldKey] || '').trim() : '';
      const dateAction = toSafeText(control.getAttribute('data-sales-purchase-party-date-action')) || 'toggle';
      if(dateAction === 'toggle'){
        const willOpen = toSafeText(ui.openDateField) !== partyFieldKey;
        ui.openChoiceField = '';
        ui.openDateField = willOpen ? partyFieldKey : '';
        ui.datePickerView = 'days';
        ui.datePickerMonthCursor = resolveSalesPurchasePartyDateMonthCursor(entry.formState, partyFieldKey, selectedValue);
        rerenderAndFocusPartyDateTrigger(partyFieldKey);
        return true;
      }
      if(toSafeText(ui.openDateField) !== partyFieldKey) return true;
      const navigationResult = handlePartyDatePickerNavigation(control, ui, selectedValue, dateAction);
      if(navigationResult === 'focus'){
        rerenderAndFocusPartyDateTrigger(partyFieldKey);
        return true;
      }
      if(navigationResult === 'render'){
        renderWindowForm(entry);
        return true;
      }
      if(handlePartyDatePickerSelection(control, draft, ui, partyFieldKey, dateAction)){
        rerenderAndFocusPartyDateTrigger(partyFieldKey);
        return true;
      }
      return true;
    }

    function handlePartySegmentClick(event){
      const control = closestModalControl(event, '[data-sales-purchase-party-segment]');
      if(!control) return false;
      consumeSalesPurchaseModalEvent(event);
      const fieldKey = toSafeText(control.getAttribute('data-sales-purchase-party-segmented-field'));
      const value = toSafeText(control.getAttribute('data-sales-purchase-party-segment'));
      const { draft } = ensureSalesPurchasePartyState(entry.formState);
      draft[fieldKey] = value;
      rerenderAndFocusSelector(() => modal.querySelector(`[data-sales-purchase-party-segment][data-sales-purchase-party-segmented-field="${fieldKey}"][data-sales-purchase-party-segment="${value}"]`));
      return true;
    }

    function handlePartyChoiceSelectClick(event){
      const control = closestModalControl(event, '[data-sales-purchase-party-choice-action="select"]');
      if(!control) return false;
      consumeSalesPurchaseModalEvent(event);
      const fieldKey = toSafeText(control.getAttribute('data-sales-purchase-party-choice-field'));
      const value = toSafeText(control.getAttribute('data-sales-purchase-party-choice-value'));
      const { draft, ui } = ensureSalesPurchasePartyState(entry.formState);
      draft[fieldKey] = value;
      ui.openChoiceField = '';
      if(fieldKey == SALES_PURCHASE_PARTY_PHONE_COUNTRY_FIELD_KEY) ui.phoneCountrySearchQuery = '';
      rerenderAndFocusPartyChoiceTarget(fieldKey);
      return true;
    }

    function handlePartyChoiceTriggerClick(event){
      const control = closestModalControl(event, '[data-sales-purchase-party-choice-trigger="true"]');
      if(!control) return false;
      consumeSalesPurchaseModalEvent(event);
      const fieldKey = toSafeText(control.getAttribute('data-sales-purchase-party-choice-field'));
      const { ui } = ensureSalesPurchasePartyState(entry.formState);
      const willOpen = toSafeText(ui.openChoiceField) !== fieldKey;
      ui.openDateField = '';
      ui.openChoiceField = willOpen ? fieldKey : '';
      if(fieldKey !== SALES_PURCHASE_PARTY_PHONE_COUNTRY_FIELD_KEY) ui.phoneCountrySearchQuery = '';
      rerenderAndFocusSelector(() => {
        if(fieldKey == SALES_PURCHASE_PARTY_PHONE_COUNTRY_FIELD_KEY && !willOpen){
          return modal.querySelector('[data-sales-purchase-party-field="phone"]');
        }
        return modal.querySelector(`[data-sales-purchase-party-choice-trigger="true"][data-sales-purchase-party-choice-field="${fieldKey}"]`);
      });
      return true;
    }

    function handleModalDateControlClick(event){
      const control = closestModalControl(event, '[data-sales-purchase-date-action]');
      if(!control) return false;
      handleSalesPurchaseMainDateControlClick(event, entry, control);
      return true;
    }

    function handleModalNavigatorControlClick(event){
      const control = closestModalControl(event, '[data-sales-purchase-nav]:not([disabled])');
      if(!control) return false;
      handleSalesPurchaseNavigatorControlClick(event, entry, control);
      return true;
    }

    function handleModalMainActionClick(event){
      const control = closestModalControl(event, '[data-sales-purchase-action]');
      if(!control) return false;
      handleSalesPurchaseMainActionClick(event, entry, control, {
        ownerWindowId: resolvedWindowId,
        closeWindow: (sourceEvent) => closeWindow(resolvedWindowId, sourceEvent)
      });
      return true;
    }

    function onModalClick(event){
      if(handleSalesPurchaseBeneficiarySuggestionClick(event, entry, modal)) return;
      if(handlePartyPhoneCountrySearchClearClick(event)) return;
      if(handlePartyDateControlClick(event)) return;
      if(handlePartySegmentClick(event)) return;
      if(handlePartyChoiceSelectClick(event)) return;
      if(handlePartyChoiceTriggerClick(event)) return;
      if(handleModalDateControlClick(event)) return;
      if(handleModalNavigatorControlClick(event)) return;
      handleModalMainActionClick(event);
    }

    function focusPartyPhoneCountrySearchInput(ui){
      renderWindowForm(entry, () => {
        const searchInput = modal.querySelector('[data-sales-purchase-party-phone-country-search="true"]');
        if(searchInput instanceof HTMLInputElement){
          searchInput.focus();
          searchInput.setSelectionRange(ui.phoneCountrySearchQuery.length, ui.phoneCountrySearchQuery.length);
        }
      });
    }

    function handlePartyPhoneCountrySearchInput(target){
      if(!(target instanceof HTMLInputElement) || !target.matches('[data-sales-purchase-party-phone-country-search="true"]')) return false;
      const { ui } = ensureSalesPurchasePartyState(entry.formState);
      ui.phoneCountrySearchQuery = String(target.value || '');
      focusPartyPhoneCountrySearchInput(ui);
      return true;
    }

    function sanitizeSalesPurchasePartyDatePart(partKey, value){
      const digits = String(value || '').replace(/\D+/g, '');
      return partKey === 'year' ? digits.slice(0, 4) : digits.slice(0, 2);
    }

    function handlePartyDatePartInput(target){
      if(!(target instanceof HTMLInputElement) || !target.matches('[data-sales-purchase-party-date-part]')) return false;
      const partKey = toSafeText(target.getAttribute('data-sales-purchase-party-date-part'));
      const fieldKey = toSafeText(target.getAttribute('data-sales-purchase-party-date-field'));
      if(!fieldKey || !partKey) return true;
      const safeValue = sanitizeSalesPurchasePartyDatePart(partKey, target.value || '');
      if(target.value !== safeValue) target.value = safeValue;

      const dateHost = target.closest('[data-sales-purchase-party-date-picker]');
      const dayInput = dateHost instanceof HTMLElement ? dateHost.querySelector('[data-sales-purchase-party-date-part="day"]') : null;
      const monthInput = dateHost instanceof HTMLElement ? dateHost.querySelector('[data-sales-purchase-party-date-part="month"]') : null;
      const yearInput = dateHost instanceof HTMLElement ? dateHost.querySelector('[data-sales-purchase-party-date-part="year"]') : null;
      const day = dayInput instanceof HTMLInputElement ? String(dayInput.value || '').trim() : '';
      const month = monthInput instanceof HTMLInputElement ? String(monthInput.value || '').trim() : '';
      const year = yearInput instanceof HTMLInputElement ? String(yearInput.value || '').trim() : '';
      const { draft, ui } = ensureSalesPurchasePartyState(entry.formState);

      if(!day && !month && !year){
        draft[fieldKey] = '';
        return true;
      }

      if(day.length === 2 && month.length === 2 && year.length === 4){
        const nextIso = `${year}-${month}-${day}`;
        if(salesPurchaseParseIsoDate(nextIso)){
          draft[fieldKey] = nextIso;
          ui.datePickerMonthCursor = salesPurchaseResolveMonthCursor(nextIso, nextIso.slice(0, 7));
        }
      }
      return true;
    }

    function handlePartyDraftFieldInput(target){
      const partyField = String(target.getAttribute('data-sales-purchase-party-field') || '').trim();
      if(!partyField || (!(target instanceof HTMLInputElement) && !(target instanceof HTMLTextAreaElement))) return false;
      const { draft } = ensureSalesPurchasePartyState(entry.formState);
      draft[partyField] = String(target.value || '');
      if(partyField === 'fullName') syncSalesPurchasePartyLinkedName(entry);
      return true;
    }

    function handleModalInputTarget(target){
      if(syncSalesPurchaseNavigatorLookupInput(entry, target)) return true;
      return handlePartyPhoneCountrySearchInput(target)
        || handlePartyDatePartInput(target)
        || handlePartyDraftFieldInput(target)
        || handleSalesPurchaseAmountFieldInput(entry, target)
        || handleSalesPurchaseTextFieldInput(entry, target, { host: modal });
    }

    function onModalInput(event){
      const target = event.target;
      if(!(target instanceof HTMLElement) || !modal.contains(target)) return;
      handleModalInputTarget(target);
    }

    function isSalesPurchaseEnterKey(event){
      return event.key === 'Enter' || event.key === 'NumpadEnter';
    }

    function handleNavigatorLookupKey(event, control){
      if(!control.matches('[data-sales-purchase-nav="lookup"]') || !isSalesPurchaseEnterKey(event)) return false;
      consumeSalesPurchaseModalEvent(event);
      runSalesPurchaseNavigatorAction(entry, 'lookup');
      return true;
    }

    function closePartyPopoverForTab(partyUi, reference, safeStep){
      const partyChoiceField = toSafeText(partyUi.openChoiceField);
      const partyDateField = toSafeText(partyUi.openDateField);
      partyUi.openChoiceField = '';
      partyUi.openDateField = '';
      partyUi.datePickerView = 'days';
      if(partyChoiceField === SALES_PURCHASE_PARTY_PHONE_COUNTRY_FIELD_KEY) partyUi.phoneCountrySearchQuery = '';
      renderWindowForm(entry, () => {
        const freshReference = partyDateField
          ? modal.querySelector(`[data-sales-purchase-party-date-trigger="true"][data-sales-purchase-party-date-field="${partyDateField}"]`)
          : (partyChoiceField
            ? modal.querySelector(`[data-sales-purchase-party-choice-trigger="true"][data-sales-purchase-party-choice-field="${partyChoiceField}"]`)
            : reference);
        focusRelativeSalesPurchaseTarget(modal, freshReference || reference, safeStep, { clamp:true, referenceElement:freshReference || reference });
      });
    }

    function closeMainPopoverForTab(control, reference, safeStep, isPickerTrigger, isDateTrigger){
      const pickerHost = control.closest('[data-sales-purchase-picker-host]');
      const pickerKey = pickerHost instanceof HTMLElement
        ? String(pickerHost.getAttribute('data-sales-purchase-picker-host') || '').trim()
        : (isPickerTrigger ? String(control.getAttribute('data-sales-purchase-picker-key') || '').trim() : '');
      const useDateReference = isDateTrigger || !!control.closest('[data-sales-purchase-date-picker="true"]');
      entry.formState.openPickerKey = null;
      entry.formState.datePickerOpen = false;
      entry.formState.datePickerView = 'days';
      renderWindowForm(entry, () => {
        const freshReference = useDateReference
          ? getSalesPurchaseDateTrigger(modal)
          : (pickerKey ? getSalesPurchasePickerTrigger(modal, pickerKey) : null);
        focusRelativeSalesPurchaseTarget(modal, freshReference || reference, safeStep, { clamp:true, referenceElement: freshReference || reference });
      });
    }

    function handleModalTabKey(event, control, context){
      if(event.key !== 'Tab') return false;
      consumeSalesPurchaseModalEvent(event);
      const { isPickerTrigger, isDateTrigger, safeStep, partyUi } = context;
      const reference = getSalesPurchaseFlowReference(modal, control) || control;
      if(partyUi && (partyUi.openChoiceField || partyUi.openDateField)){
        closePartyPopoverForTab(partyUi, reference, safeStep);
        return true;
      }
      if(entry.formState.openPickerKey || entry.formState.datePickerOpen){
        closeMainPopoverForTab(control, reference, safeStep, isPickerTrigger, isDateTrigger);
        return true;
      }
      focusRelativeSalesPurchaseTarget(modal, control, safeStep, { clamp:true, referenceElement: reference });
      return true;
    }

    function handlePickerTriggerKey(event, control){
      if(!control.matches('[data-sales-purchase-action="toggle-picker"]')) return false;
      const pickerKey = String(control.getAttribute('data-sales-purchase-picker-key') || '').trim();
      if(isSalesPurchasePressKey(event)){
        consumeSalesPurchaseModalEvent(event);
        if(event.shiftKey){
          focusRelativeSalesPurchaseTarget(modal, control, -1, { clamp:true, referenceElement:control });
          return true;
        }
        toggleSalesPurchasePicker(entry, pickerKey, { placement:'current' });
        return true;
      }
      if(event.key === 'ArrowDown' || event.key === 'ArrowUp'){
        consumeSalesPurchaseModalEvent(event);
        if(entry.formState.openPickerKey === pickerKey){
          focusSalesPurchaseChoiceOption(entry, pickerKey, event.key === 'ArrowUp' ? 'last' : 'current');
          return true;
        }
        toggleSalesPurchasePicker(entry, pickerKey, { placement:event.key === 'ArrowUp' ? 'last' : 'current' });
        return true;
      }
      if(!event.shiftKey && !entry.formState.openPickerKey && !entry.formState.datePickerOpen && (event.key === 'ArrowRight' || event.key === 'ArrowLeft')){
        const didStep = stepSalesPurchasePickerSelection(entry, pickerKey, event.key === 'ArrowRight' ? 1 : -1);
        if(didStep) consumeSalesPurchaseModalEvent(event);
        return true;
      }
      return false;
    }

    function handleDateTriggerKey(event, control){
      if(!control.matches('[data-sales-purchase-date-action="toggle"]')) return false;
      if(isSalesPurchasePressKey(event)){
        consumeSalesPurchaseModalEvent(event);
        if(event.shiftKey){
          focusRelativeSalesPurchaseTarget(modal, control, -1, { clamp:true, referenceElement:control });
          return true;
        }
        toggleSalesPurchaseDatePicker(entry, { placement:'current' });
        return true;
      }
      if(event.key === 'ArrowDown' || event.key === 'ArrowUp'){
        consumeSalesPurchaseModalEvent(event);
        if(entry.formState.datePickerOpen){
          focusSalesPurchaseDateControl(entry, event.key === 'ArrowUp' ? 'last' : 'current');
          return true;
        }
        toggleSalesPurchaseDatePicker(entry, { placement:event.key === 'ArrowUp' ? 'last' : 'current' });
        return true;
      }
      return false;
    }

    function handlePopoverPressKey(event, control, isPopoverControl){
      if(!isPopoverControl || !isSalesPurchasePressKey(event)) return false;
      consumeSalesPurchaseModalEvent(event);
      triggerSalesPurchaseElementPress(control);
      return true;
    }

    function handleTextFieldEnterKey(event, control, safeStep){
      if(!isSalesPurchaseTextField(control) || !isSalesPurchaseEnterKey(event)) return false;
      consumeSalesPurchaseModalEvent(event);
      focusRelativeSalesPurchaseTarget(modal, control, safeStep, { clamp:true });
      return true;
    }

    function handleHomeEndKey(event, control, isPopoverControl){
      if((event.key !== 'Home' && event.key !== 'End') || !(isPopoverControl || control.matches('[data-sales-purchase-action="toggle-picker"], [data-sales-purchase-date-action="toggle"]'))) return false;
      const group = resolveSalesPurchaseArrowGroup(modal, control);
      if(group instanceof HTMLElement){
        consumeSalesPurchaseModalEvent(event);
        const targets = collectSalesPurchaseArrowTargets(group);
        const targetIndex = event.key === 'Home' ? 0 : (targets.length - 1);
        const targetButton = targets[targetIndex] || null;
        if(targetButton instanceof HTMLElement) focusSalesPurchaseElement(targetButton);
      }
      return true;
    }

    function handleModalArrowNavigationKey(event, control){
      if(event.shiftKey) return false;
      if(!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) return false;
      if(!(control instanceof HTMLButtonElement) && control.getAttribute('role') !== 'option') return false;
      if(moveSalesPurchaseArrowFocus(modal, control, event.key)){
        consumeSalesPurchaseModalEvent(event);
      }
      return true;
    }

    function onModalKeyDown(event){
      if(!manager.isTopmostModal(backdrop)) return;
      if(event.defaultPrevented || event.isComposing || event.altKey || event.ctrlKey || event.metaKey) return;
      const target = event.target instanceof Element ? event.target : null;
      const control = target ? target.closest('input, textarea, button, [role="option"]') : null;
      if(!(control instanceof HTMLElement) || !modal.contains(control) || !isSalesPurchaseFlowControl(control)) return;

      const isPopoverControl = isSalesPurchasePopoverControl(control);
      const safeStep = event.shiftKey ? -1 : 1;
      const partyState = entry.action?.id === 'party' ? ensureSalesPurchasePartyState(entry.formState) : null;
      const partyUi = partyState && partyState.ui ? partyState.ui : null;
      const context = {
        isPickerTrigger: control.matches('[data-sales-purchase-action="toggle-picker"]'),
        isDateTrigger: control.matches('[data-sales-purchase-date-action="toggle"]'),
        safeStep,
        partyUi
      };

      if(handleNavigatorLookupKey(event, control)) return;
      if(handleModalTabKey(event, control, context)) return;
      if(handlePickerTriggerKey(event, control)) return;
      if(handleDateTriggerKey(event, control)) return;
      if(handlePopoverPressKey(event, control, isPopoverControl)) return;
      if(handleSalesPurchaseBeneficiarySuggestionKey(event, entry, control)) return;
      if(handleTextFieldEnterKey(event, control, safeStep)) return;
      if(handleHomeEndKey(event, control, isPopoverControl)) return;
      handleModalArrowNavigationKey(event, control);
    }

    function onKeyDown(event){
      if(!manager.isTopmostModal(backdrop)) return;
      if(event.key === 'Escape'){
        if(entry.formState.openPickerKey || entry.formState.datePickerOpen){
          event.preventDefault();
          entry.formState.openPickerKey = null;
          entry.formState.datePickerOpen = false;
          entry.formState.datePickerView = 'days';
          renderWindowForm(entry);
          return;
        }
        closeWindow(resolvedWindowId, event);
        return;
      }
      if(event.key === 'F11' || (event.altKey && event.key === 'Enter')){
        event.preventDefault();
        toggleExpand();
      }
    }

    function registerControllerListener(target, type, listener, options = undefined){
      if(!target || typeof target.addEventListener !== 'function' || typeof listener !== 'function') return;
      target.addEventListener(type, listener, options);
      registerCleanup(() => target.removeEventListener(type, listener, options));
    }

    function bindSalesPurchaseDomainRefreshEvents(){
      const events = TAIF.core && TAIF.core.events;
      if(events && typeof events.onMany === 'function'){
        registerCleanup(events.onMany([
          events.EVENT_NAMES.CURRENCY_UPDATED,
          events.EVENT_NAMES.CHART_OF_ACCOUNTS_UPDATED,
          events.EVENT_NAMES.CASH_BOXES_UPDATED
        ], onExternalDataUpdated));
        if(typeof events.on === 'function'){
          registerCleanup(events.on(events.EVENT_NAMES.SALES_PURCHASE_UPDATED, onSalesPurchaseStateUpdated));
        }
        return;
      }
      registerControllerListener(window, 'taif:currency-domain-updated', onExternalDataUpdated);
      registerControllerListener(window, 'taif:chart-of-accounts-updated', onExternalDataUpdated);
      registerControllerListener(window, 'taif:cash-boxes-updated', onExternalDataUpdated);
      registerControllerListener(window, SALES_PURCHASE_UPDATED_EVENT, onSalesPurchaseStateUpdated);
    }

    function bindSalesPurchaseWindowResizeObserver(){
      if(typeof ResizeObserver !== 'function' || !(resizeObserverTarget instanceof HTMLElement)) return;
      resizeObserver = new ResizeObserver(() => {
        manager.syncModalWithinViewport(modal);
      });
      resizeObserver.observe(resizeObserverTarget);
      registerCleanup(() => resizeObserver?.disconnect());
    }

    function bind(){
      registerControllerListener(closeButton, 'click', onCloseButtonClick);
      registerControllerListener(closeButton, 'pointerdown', stopPointer, true);
      registerControllerListener(expandButton, 'click', toggleExpand);
      registerControllerListener(expandButton, 'pointerdown', stopPointer, true);
      registerControllerListener(backdrop, 'pointerdown', stopBackdropBlockingPointer, true);
      registerControllerListener(backdrop, 'click', stopBackdropBlockingPointer, true);
      registerControllerListener(modal, 'pointerdown', activate, true);
      registerControllerListener(modal, 'pointerdown', onModalPointerDown);
      registerControllerListener(modal, 'click', onModalClick);
      registerControllerListener(modal, 'input', onModalInput);
      registerControllerListener(modal, 'keydown', onModalKeyDown, true);
      registerControllerListener(document, 'keydown', onKeyDown);
      registerControllerListener(document, 'pointerdown', onDocumentPointerDown, true);
      registerControllerListener(window, 'resize', onResize, { passive: true });
      bindSalesPurchaseDomainRefreshEvents();
      bindSalesPurchaseWindowResizeObserver();
      registerCleanup(manager.bindModalDragging({ backdrop, modal }));
    }

    return { bind, toggleExpand };
  }

  function openWindow(windowId, options = null){
    const requestedWindowId = toSafeText(windowId);
    const shouldRouteToInlineWorkspace = INLINE_SALES_PURCHASE_ACTION_IDS.has(requestedWindowId)
      && !(options && typeof options === 'object' && options.forceModal === true);
    if(shouldRouteToInlineWorkspace){
      switchInlineSalesPurchaseWorkspace(requestedWindowId);
      return;
    }
    const action = resolveSalesPurchaseWindowAction(requestedWindowId);
    if(!action) return;
    const resolvedWindowId = resolveSalesPurchaseWindowInstanceId(action.id, options);
    if(!resolvedWindowId) return;
    const manager = getModalManager();
    if(!manager) return;

    const existing = runtime.windows.get(resolvedWindowId);
    if(activateExistingSalesPurchaseWindow(existing, action, manager, options)) return;

    const initialFormState = createDefaultFormState(action.id);
    applySalesPurchaseWindowContext(action.id, { formState: initialFormState }, options);
    const shell = document.createElement('div');
    shell.innerHTML = buildWindowMarkup(action, initialFormState, resolvedWindowId).trim();
    const backdrop = shell.firstElementChild;
    const modal = backdrop?.querySelector('.sales-purchase-modal-window');
    const expandButton = backdrop?.querySelector('[data-sales-purchase-action="expand-window"]');
    const closeButton = backdrop?.querySelector('[data-sales-purchase-action="close-window"]');

    if(!(backdrop instanceof HTMLElement) || !(modal instanceof HTMLElement)) return;

    if(action.id === 'party'){
      modal.dataset.cascadeTopShift = '56';
      modal.dataset.cascadeLeftShift = '22';
    }
    normalizeSalesPurchaseFlow(modal);

    const cleanupCallbacks = [];
    const registerCleanup = (cleanup) => {
      if(typeof cleanup === 'function') cleanupCallbacks.push(cleanup);
      return cleanup;
    };

    const entry = {
      id: resolvedWindowId,
      action,
      formState: initialFormState,
      navigatorBaselineFormState: snapshotSalesPurchaseBaselineFormState(initialFormState, action.id),
      backdrop,
      modal,
      manager,
      cleanupCallbacks,
      ownerWindowId: toSafeText(options && typeof options === 'object' ? options.ownerWindowId : ''),
      attachedOwnerWindowId: '',
      attachedPartyWindowId: '',
      didMaximizeOwnerForAttachment: false,
      lastModalPosition: null,
      isMutating: false,
      mutationMode: ''
    };

    const controller = createSalesPurchaseWindowController(entry, {
      resolvedWindowId,
      closeButton,
      expandButton,
      registerCleanup
    });
    controller.bind();

    const layer = manager.ensureModalLayer();
    layer.appendChild(backdrop);
    manager.registerModalWindow(backdrop);
    syncExpandButton(expandButton, modal);

    runtime.windows.set(resolvedWindowId, entry);
    if(action.id === 'party') syncSalesPurchasePartyAttachment(entry);
    syncSalesPurchaseNavigatorBaseline(entry);

    requestAnimationFrame(() => {
      const didCenterWindow = action.id === 'party' ? centerSalesPurchaseWindowOverOwner(entry) : false;
      if(!didCenterWindow) manager.syncModalWithinViewport(modal);
      snapshotSalesPurchaseWindowPosition(entry);
      if(action.id === 'party') syncSalesPurchaseAttachedOwnerBlocker(entry);
      manager.activateModalWindow(backdrop);
      syncWindowDerivedFields(entry);
      focusSalesPurchaseInitialTarget(entry);
    });
  }


  Object.assign(feature, {
    runtime,
    toSafeText,
    readSalesPurchaseState,
    writeSalesPurchaseState,
    repairSalesPurchaseAccountingLinks,
    renderSalesPurchaseShell: renderShell,
    normalizeInlineSalesPurchaseActionId,
    resolveSalesPurchaseActionIdForCurrentView,
    filterSalesPurchaseRecordsForCurrentView,
    ensureInlinePurchaseWorkspaceEntry,
    switchInlineSalesPurchaseWorkspace,
    focusSalesPurchaseSourceRecord,
    refreshWorkbenchUi,
    resetSalesPurchaseRecordsPagination,
    moveSalesPurchaseRecordsPage,
    setSalesPurchaseRecordsPageSize,
    updateSalesPurchaseDeleteActionButtonUi,
    toggleSalesPurchaseRecordSelection,
    clearSalesPurchaseRecordSelection,
    requestSelectedSalesPurchaseDeletion,
    prepareSalesPurchaseFormMutation,
    syncInlinePurchaseWorkspace,
    refreshSalesPurchaseSideboxPricesUi,
    handleInlinePurchaseWorkspacePointerDown,
    handleInlinePurchaseWorkspaceClick,
    handleInlinePurchaseWorkspaceInput,
    handleInlinePurchaseWorkspaceKeyDown,
    handleInlinePurchaseWorkspaceDocumentPointerDown,
    openSalesPurchaseWindow: openWindow,
    closeSalesPurchaseWindow: closeWindow,
    closeAllSalesPurchaseWindows: closeAllWindows,
    closeSalesPurchaseDeleteConfirmDialog,
    closeSalesPurchaseReverseConfirmDialog,
    closeSalesPurchaseSuccessDialog,
    closeSalesPurchaseReviewDialog
  });
})();
