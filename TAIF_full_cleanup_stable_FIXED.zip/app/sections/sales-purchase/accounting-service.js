(()=>{

  const TAIF = window.TAIF;
  const feature = TAIF.salesPurchaseFeature || (TAIF.salesPurchaseFeature = {});
  const { normalizeAccountCatalog, readChartAccountCatalogSource, persistJsonState, readJsonStorage } = TAIF.core.utils;
  const {
    ACCOUNT_STORAGE_KEY,
    CASH_BOX_STORAGE_KEY,
    ENTRIES_STORAGE_KEY,
    DEFAULT_ENTRIES_COUNTERS,
    SALES_PURCHASE_BALANCE_EPSILON,
    toSafeText,
    dedupeSalesPurchaseStringList,
    normalizeSalesPurchaseRecord,
    readSalesPurchaseState,
    writeSalesPurchaseState,
    normalizeCurrencyCode,
    toNumber,
    formatNumericValue,
    salesPurchaseTypeLabel,
    salesPurchaseTodayInputValue,
    sanitizeNumericInput,
    normalizeSalesPurchaseEditedAmountField,
    salesPurchaseNormalizeDateInputValue,
    normalizeSalesPurchaseSearchText,
    getCurrencySnapshot,
    resolveCurrencyFromList,
    resolveSalesPurchaseEffectiveActionId,
    normalizeSalesPurchaseActionOwnerId,
    resolveSalesPurchaseRecordOwnerActionId,
    buildSalesPurchaseOperationLabel,
    salesPurchaseLifecycleActionKey
  } = feature;
  const readJsonStorageSafe = readJsonStorage;

  function resolveDomainAdapter(name){
    const registry = TAIF.domain || {};
    if(typeof registry.resolve === 'function') return registry.resolve(name);
    return registry[name] || null;
  }

  function resolveServiceAdapter(name){
    const registry = TAIF.services || {};
    if(typeof registry.resolve === 'function') return registry.resolve(name);
    return registry[name] || null;
  }

  function warnSalesPurchaseAccounting(message, error = null){
    if(typeof console !== 'undefined' && typeof console.warn === 'function'){
      console.warn(`[sales-purchase-accounting-service] ${message}`, error || '');
    }
  }

  function emitSalesPurchaseAccountingDomainUpdate(domainName, eventName, state){
    const events = TAIF.core && TAIF.core.events;
    if(events && typeof events.emitDomainUpdate === 'function'){
      events.emitDomainUpdate(domainName, { state }, { source:'sales-purchase-accounting' });
      return;
    }
    if(typeof window === 'undefined' || typeof window.dispatchEvent !== 'function') return;
    try{
      window.dispatchEvent(new CustomEvent(eventName, { detail: { state } }));
    }catch{}
  }


  function ensureAccountCatalog(source){
    return typeof normalizeAccountCatalog === 'function'
      ? normalizeAccountCatalog(source, toSafeText)
      : [];
  }

  function readAccountCatalog(){
    const accountsDomain = resolveDomainAdapter('accounts');
    if(accountsDomain && typeof accountsDomain.readCatalog === 'function'){
      const catalog = accountsDomain.readCatalog();
      if(Array.isArray(catalog)) return ensureAccountCatalog(catalog);
    }

    if(typeof readChartAccountCatalogSource === 'function'){
      const source = readChartAccountCatalogSource(ACCOUNT_STORAGE_KEY, readJsonStorageSafe);
      return ensureAccountCatalog(source);
    }

    const publicApi = TAIF.chartOfAccounts || {};
    const internalApi = publicApi.internal || {};
    let source = [];

    if(typeof publicApi.readState === 'function'){
      source = publicApi.readState();
    }else if(typeof internalApi.getCenters === 'function'){
      source = internalApi.getCenters(true);
    }else if(typeof internalApi.readCenters === 'function'){
      source = internalApi.readCenters();
    }else{
      const stored = readJsonStorageSafe(ACCOUNT_STORAGE_KEY, null);
      source = Array.isArray(stored) ? stored : (Array.isArray(stored?.centers) ? stored.centers : []);
    }

    return ensureAccountCatalog(source);
  }

  function findAccountByNo(accountNo, catalog = readAccountCatalog()){
    const safeAccountNo = toSafeText(accountNo);
    return (Array.isArray(catalog) ? catalog : []).find((item) => item && item.accountNo === safeAccountNo) || null;
  }

  function readPrimaryCashAccount(catalog = readAccountCatalog()){
    const safeCatalog = Array.isArray(catalog) ? catalog : [];
    const cashBoxDomain = resolveDomainAdapter('cash-boxes') || TAIF.cashBoxesDomain || {};
    const cashBoxApi = TAIF.cashBoxes || {};
    const state = typeof cashBoxDomain.readState === 'function'
      ? cashBoxDomain.readState()
      : (typeof cashBoxApi.readState === 'function'
          ? cashBoxApi.readState()
          : readJsonStorageSafe(CASH_BOX_STORAGE_KEY, null));
    const mainBox = Array.isArray(state?.boxes) && state.boxes.length ? state.boxes[0] : null;
    return mainBox ? findAccountByNo(mainBox.linkedAccountNo, safeCatalog) : null;
  }

  function findFirstAccountByName(keywords, catalog = readAccountCatalog()){
    const safeCatalog = Array.isArray(catalog) ? catalog : [];
    const normalizedKeywords = (Array.isArray(keywords) ? keywords : [])
      .map((keyword) => normalizeSalesPurchaseSearchText(keyword))
      .filter(Boolean);
    if(!normalizedKeywords.length) return null;
    return safeCatalog.find((account) => {
      const accountName = normalizeSalesPurchaseSearchText(account?.name);
      return !!accountName && normalizedKeywords.some((keyword) => accountName.includes(keyword));
    }) || null;
  }

  function resolveDefaultCashAccount(catalog = readAccountCatalog()){
    const safeCatalog = Array.isArray(catalog) ? catalog : [];
    return readPrimaryCashAccount(safeCatalog)
      || findFirstAccountByName(['الصندوق'], safeCatalog)
      || safeCatalog.find((item) => item.accountNo === '001')
      || safeCatalog[0]
      || null;
  }

  function parseEntriesVoucherNumberIndex(number, expectedPrefix = ''){
    const safeNumber = toSafeText(number).toUpperCase();
    const safePrefix = toSafeText(expectedPrefix).toUpperCase();
    const match = safeNumber.match(/^([A-Z]+)-(\d+)$/);
    if(!match) return Number.NaN;
    if(safePrefix && match[1] !== safePrefix) return Number.NaN;
    return Number(match[2]);
  }

  function formatSalesPurchaseEntriesVoucherNumber(prefix = 'JV', counterValue = 1){
    const safePrefix = toSafeText(prefix).toUpperCase() || 'JV';
    const safeCounter = Math.max(1, Number(counterValue) || 1);
    return `${safePrefix}-${String(safeCounter).padStart(5, '0')}`;
  }

  function normalizeSalesPurchaseCalcMethod(value){
    return String(value || '').trim() === 'divide' ? 'divide' : 'multiply';
  }

  function createEntriesStateFallback(){
    return {
      version: 1,
      updatedAt: Date.now(),
      counters: { ...DEFAULT_ENTRIES_COUNTERS },
      records: []
    };
  }

  function isSalesPurchaseGeneratedEntryRecord(record){
    const safeRecord = record && typeof record === 'object' ? record : {};
    const safeId = toSafeText(safeRecord.id);
    if(safeId.startsWith('entry-record-sales-purchase-')) return true;
    if(toSafeText(safeRecord.sourceSalesPurchaseRecordId)) return true;
    if(toSafeText(safeRecord.sourceSalesPurchaseNumber)) return true;
    return false;
  }

  function areNormalizedStringListsEqual(left, right){
    const safeLeft = Array.isArray(left) ? left : [];
    const safeRight = Array.isArray(right) ? right : [];
    if(safeLeft.length !== safeRight.length) return false;
    for(let index = 0; index < safeLeft.length; index += 1){
      if(safeLeft[index] !== safeRight[index]) return false;
    }
    return true;
  }

  function recordMentionsSalesPurchaseNumber(record, salesPurchaseNumber = ''){
    const safeNumber = toSafeText(salesPurchaseNumber).toUpperCase();
    if(!safeNumber) return false;
    const description = toSafeText(record?.description).toUpperCase();
    const summary = toSafeText(record?.summary).toUpperCase();
    return description.includes(safeNumber) || summary.includes(safeNumber);
  }

  function hasPersistedSalesPurchaseEntryRecord(record, entriesState = readEntriesStateForSalesPurchase()){
    const safeRecord = normalizeSalesPurchaseRecord(record);
    if(!toSafeText(safeRecord.id) && !toSafeText(safeRecord.number)) return false;
    const matches = resolveSalesPurchaseLinkedEntryMatches(safeRecord, entriesState);
    return Array.isArray(matches?.matchedRecords) && matches.matchedRecords.length > 0;
  }

  function buildSalesPurchaseLinkedEntryReferenceIndex(salesState = readSalesPurchaseState()){
    const safeSalesState = salesState && typeof salesState === 'object' ? salesState : { records: [] };
    const safeRecords = Array.isArray(safeSalesState.records) ? safeSalesState.records : [];
    const salesRecordIds = new Set();
    const salesNumbers = new Set();
    const entryRecordIds = new Set();
    const entryVoucherNumbers = new Set();

    safeRecords.forEach((record) => {
      const safeRecord = normalizeSalesPurchaseRecord(record);
      const safeRecordId = toSafeText(safeRecord.id);
      const safeRecordNumber = toSafeText(safeRecord.number).toUpperCase();
      if(safeRecordId) salesRecordIds.add(safeRecordId);
      if(safeRecordNumber) salesNumbers.add(safeRecordNumber);
      (Array.isArray(safeRecord.linkedEntryRecordIds) ? safeRecord.linkedEntryRecordIds : []).forEach((value) => {
        const safeValue = toSafeText(value);
        if(safeValue) entryRecordIds.add(safeValue);
      });
      (Array.isArray(safeRecord.linkedEntryVoucherNumbers) ? safeRecord.linkedEntryVoucherNumbers : []).forEach((value) => {
        const safeValue = toSafeText(value).toUpperCase();
        if(safeValue) entryVoucherNumbers.add(safeValue);
      });
    });

    return {
      salesRecordIds,
      salesNumbers,
      entryRecordIds,
      entryVoucherNumbers
    };
  }

  function normalizeEntryLineForSalesPurchase(line, index = 0){
    const safeLine = line && typeof line === 'object' ? line : {};
    const debit = Math.max(0, toNumber(safeLine.debit, 0));
    const credit = Math.max(0, toNumber(safeLine.credit, 0));
    return {
      ...safeLine,
      lineNo: Math.max(1, Number(safeLine.lineNo) || index + 1),
      roleKey: toSafeText(safeLine.roleKey),
      roleLabel: toSafeText(safeLine.roleLabel),
      accountNo: toSafeText(safeLine.accountNo),
      accountName: toSafeText(safeLine.accountName),
      description: toSafeText(safeLine.description),
      debit,
      credit,
      side: safeLine.side === 'credit' ? 'credit' : 'debit',
      amount: Math.max(0, toNumber(safeLine.amount, Math.max(debit, credit)))
    };
  }

  function normalizeEntryRecordForSalesPurchase(record, index = 0){
    const safeRecord = record && typeof record === 'object' ? record : {};
    const createdAt = Number(safeRecord.createdAt) > 0 ? Number(safeRecord.createdAt) : (Date.now() + index);
    const lines = Array.isArray(safeRecord.lines)
      ? safeRecord.lines.map((line, lineIndex) => normalizeEntryLineForSalesPurchase(line, lineIndex)).filter((line) => line.accountNo)
      : [];
    const amount = Math.max(0, toNumber(safeRecord.amount, 0));
    const grossAmount = Math.max(0, toNumber(safeRecord.grossAmount, amount));
    const netAmount = Math.max(0, toNumber(safeRecord.netAmount, amount));
    return {
      ...safeRecord,
      id: toSafeText(safeRecord.id) || `entry-record-sales-purchase-${createdAt}-${index + 1}`,
      type: toSafeText(safeRecord.type) || 'journal',
      number: toSafeText(safeRecord.number).toUpperCase(),
      status: safeRecord.status === 'reversed' ? 'reversed' : (safeRecord.status === 'draft' ? 'draft' : 'posted'),
      date: toSafeText(safeRecord.date) || salesPurchaseTodayInputValue(),
      description: toSafeText(safeRecord.description),
      summary: toSafeText(safeRecord.summary),
      counterpartAccountNo: toSafeText(safeRecord.counterpartAccountNo),
      counterpartAccountName: toSafeText(safeRecord.counterpartAccountName),
      partyName: toSafeText(safeRecord.partyName),
      currency: normalizeCurrencyCode(safeRecord.currency) || 'USD',
      amount,
      grossAmount,
      netAmount,
      cashAccountNo: toSafeText(safeRecord.cashAccountNo),
      cashAccountName: toSafeText(safeRecord.cashAccountName),
      lines,
      createdAt,
      updatedAt: Number(safeRecord.updatedAt) > 0 ? Number(safeRecord.updatedAt) : createdAt,
      receiptAmount: Math.max(0, toNumber(safeRecord.receiptAmount, 0)),
      paymentAmount: Math.max(0, toNumber(safeRecord.paymentAmount, 0)),
      cashMotionPickerCode: toSafeText(safeRecord.cashMotionPickerCode),
      sourceSalesPurchaseRecordId: toSafeText(safeRecord.sourceSalesPurchaseRecordId),
      sourceSalesPurchaseNumber: toSafeText(safeRecord.sourceSalesPurchaseNumber).toUpperCase()
    };
  }

  function normalizeEntriesCountersForSalesPurchase(sourceCounters, records = []){
    const safeCounters = sourceCounters && typeof sourceCounters === 'object' ? sourceCounters : {};
    const floors = Object.keys(DEFAULT_ENTRIES_COUNTERS).reduce((accumulator, prefix) => {
      accumulator[prefix] = DEFAULT_ENTRIES_COUNTERS[prefix];
      return accumulator;
    }, {});

    (Array.isArray(records) ? records : []).forEach((record) => {
      const recordNumber = toSafeText(record?.number).toUpperCase();
      if(!recordNumber) return;
      Object.keys(DEFAULT_ENTRIES_COUNTERS).forEach((prefix) => {
        const parsedIndex = parseEntriesVoucherNumberIndex(recordNumber, prefix);
        if(Number.isFinite(parsedIndex)){
          floors[prefix] = Math.max(floors[prefix], parsedIndex + 1);
        }
      });
    });

    return Object.keys(DEFAULT_ENTRIES_COUNTERS).reduce((normalized, prefix) => {
      normalized[prefix] = Math.max(
        DEFAULT_ENTRIES_COUNTERS[prefix],
        Number(safeCounters[prefix]) || DEFAULT_ENTRIES_COUNTERS[prefix],
        Number(floors[prefix]) || DEFAULT_ENTRIES_COUNTERS[prefix]
      );
      return normalized;
    }, {});
  }

  function normalizeEntriesStateForSalesPurchase(stateInput){
    const fallback = createEntriesStateFallback();
    const safeState = stateInput && typeof stateInput === 'object' ? stateInput : fallback;
    const records = (Array.isArray(safeState.records) ? safeState.records : [])
      .map((record, index) => normalizeEntryRecordForSalesPurchase(record, index))
      .sort((left, right) => {
        const createdDelta = (Number(right.createdAt) || 0) - (Number(left.createdAt) || 0);
        if(createdDelta) return createdDelta;
        const updatedDelta = (Number(right.updatedAt) || 0) - (Number(left.updatedAt) || 0);
        if(updatedDelta) return updatedDelta;
        return toSafeText(right.number).localeCompare(toSafeText(left.number), 'en');
      });

    return {
      version: 1,
      updatedAt: Date.now(),
      counters: normalizeEntriesCountersForSalesPurchase(safeState.counters, records),
      records
    };
  }

  function readLegacyEntriesStateForSalesPurchase(){
    const entriesDomain = resolveDomainAdapter('entries') || TAIF.entriesVouchersDomain || {};
    const state = typeof entriesDomain.readState === 'function'
      ? entriesDomain.readState()
      : readJsonStorageSafe(ENTRIES_STORAGE_KEY, createEntriesStateFallback());
    return normalizeEntriesStateForSalesPurchase(state);
  }

  function readEntriesStateForSalesPurchase(){
    return readLegacyEntriesStateForSalesPurchase();
  }

  function readSalesPurchaseRawCashBoxesState(){
    const stored = readJsonStorageSafe(CASH_BOX_STORAGE_KEY, null);
    if(stored && typeof stored === 'object') return stored;
    const cashBoxDomain = resolveDomainAdapter('cash-boxes') || TAIF.cashBoxesDomain || {};
    const cashBoxApi = TAIF.cashBoxes || {};
    if(typeof cashBoxDomain.readState === 'function') return cashBoxDomain.readState();
    if(typeof cashBoxApi.readState === 'function') return cashBoxApi.readState();
    return null;
  }

  function normalizeSalesPurchaseCashBoxesState(stateInput){
    const cashBoxDomain = resolveDomainAdapter('cash-boxes') || TAIF.cashBoxesDomain || {};
    if(typeof cashBoxDomain.normalizeState === 'function'){
      return cashBoxDomain.normalizeState(stateInput);
    }

    const safeState = stateInput && typeof stateInput === 'object' ? stateInput : {};
    const boxes = Array.isArray(safeState.boxes) && safeState.boxes.length
      ? safeState.boxes.map((box, index) => {
          const safeBox = box && typeof box === 'object' ? box : {};
          const balancesSource = safeBox.balances && typeof safeBox.balances === 'object' ? safeBox.balances : {};
          const balances = Object.keys(balancesSource).reduce((accumulator, code) => {
            const safeCode = normalizeCurrencyCode(code);
            if(!safeCode) return accumulator;
            accumulator[safeCode] = toNumber(balancesSource[code], 0);
            return accumulator;
          }, {});
          if(!Object.prototype.hasOwnProperty.call(balances, 'USD')) balances.USD = 0;
          return {
            id: toSafeText(safeBox.id) || `cash-box-sales-purchase-${index + 1}`,
            linkedAccountNo: toSafeText(safeBox.linkedAccountNo) || '001',
            linkedAccountName: toSafeText(safeBox.linkedAccountName) || 'صندوق محلي اساسي',
            balances
          };
        })
      : [{
          id: 'cash-box-main-local',
          linkedAccountNo: '001',
          linkedAccountName: 'صندوق محلي اساسي',
          balances: { USD: 0 }
        }];

    return {
      version: 1,
      updatedAt: Number(safeState.updatedAt) > 0 ? Number(safeState.updatedAt) : Date.now(),
      selectedCenterId: toSafeText(safeState.selectedCenterId),
      boxes
    };
  }

  function readCashBoxesStateForSalesPurchase(){
    return normalizeSalesPurchaseCashBoxesState(readSalesPurchaseRawCashBoxesState());
  }

  function writeCashBoxesStateForSalesPurchase(nextState, { notify = true } = {}){
    const normalized = normalizeSalesPurchaseCashBoxesState(nextState);
    const cashBoxDomain = resolveDomainAdapter('cash-boxes') || TAIF.cashBoxesDomain || {};
    if(typeof cashBoxDomain.writeState === 'function'){
      return normalizeSalesPurchaseCashBoxesState(cashBoxDomain.writeState(normalized, { notify }));
    }
    const persisted = typeof persistJsonState === 'function'
      ? persistJsonState(CASH_BOX_STORAGE_KEY, normalized, normalizeSalesPurchaseCashBoxesState)
      : normalized;
    const safeState = normalizeSalesPurchaseCashBoxesState(persisted);
    if(notify){
      emitSalesPurchaseAccountingDomainUpdate('cash-boxes', 'taif:cash-boxes-updated', safeState);
    }
    return safeState;
  }

  function readSalesPurchaseStoredCashBoxBalance(accountNo, currencyCode, rawState = readSalesPurchaseRawCashBoxesState()){
    const safeAccountNo = toSafeText(accountNo);
    const safeCurrencyCode = normalizeCurrencyCode(currencyCode);
    if(!safeAccountNo || !safeCurrencyCode) return { hasBalance: false, amount: 0 };

    const boxes = Array.isArray(rawState?.boxes) ? rawState.boxes : [];
    let hasBalance = false;
    let total = 0;

    boxes.forEach((box) => {
      if(toSafeText(box?.linkedAccountNo) !== safeAccountNo) return;
      const balances = box?.balances && typeof box.balances === 'object' ? box.balances : {};
      const matchedKey = Object.keys(balances).find((code) => normalizeCurrencyCode(code) === safeCurrencyCode);
      if(!matchedKey) return;
      hasBalance = true;
      total += toNumber(balances[matchedKey], 0);
    });

    if(hasBalance) return { hasBalance: true, amount: total };

    const normalizedState = normalizeSalesPurchaseCashBoxesState(rawState);
    normalizedState.boxes.forEach((box) => {
      if(toSafeText(box?.linkedAccountNo) !== safeAccountNo) return;
      const balances = box?.balances && typeof box.balances === 'object' ? box.balances : {};
      if(!Object.prototype.hasOwnProperty.call(balances, safeCurrencyCode)) return;
      hasBalance = true;
      total += toNumber(balances[safeCurrencyCode], 0);
    });

    return { hasBalance, amount: total };
  }

  function buildSalesPurchasePostedEntryAccountCurrencyTotals(entriesState = readEntriesStateForSalesPurchase()){
    const safeState = normalizeEntriesStateForSalesPurchase(entriesState);
    const totals = new Map();

    (Array.isArray(safeState.records) ? safeState.records : []).forEach((record) => {
      if(record?.status !== 'posted') return;
      const currencyCode = normalizeCurrencyCode(record?.currency);
      if(!currencyCode) return;
      const lines = Array.isArray(record?.lines) ? record.lines : [];
      lines.forEach((line) => {
        const accountNo = toSafeText(line?.accountNo);
        if(!accountNo) return;
        const delta = toNumber(line?.debit, 0) - toNumber(line?.credit, 0);
        if(Math.abs(delta) <= SALES_PURCHASE_BALANCE_EPSILON) return;
        const key = `${accountNo}::${currencyCode}`;
        totals.set(key, toNumber(totals.get(key), 0) + delta);
      });
    });

    return totals;
  }

  function updateSalesPurchaseCashBoxBalances(resolveNextBalance, { notify = true } = {}){
    if(typeof resolveNextBalance !== 'function') return readCashBoxesStateForSalesPurchase();
    const currentState = readCashBoxesStateForSalesPurchase();
    const currentBoxes = Array.isArray(currentState.boxes) ? currentState.boxes : [];
    if(!currentBoxes.length) return currentState;

    let didChange = false;
    const nextBoxes = currentBoxes.map((box) => {
      const safeBox = box && typeof box === 'object' ? box : {};
      const accountNo = toSafeText(safeBox.linkedAccountNo);
      if(!accountNo) return safeBox;

      const balances = safeBox.balances && typeof safeBox.balances === 'object'
        ? { ...safeBox.balances }
        : { USD: 0 };
      let boxChanged = false;

      Object.keys(balances).forEach((rawCurrencyCode) => {
        const safeCurrencyCode = normalizeCurrencyCode(rawCurrencyCode);
        if(!safeCurrencyCode || rawCurrencyCode === safeCurrencyCode) return;
        if(Object.prototype.hasOwnProperty.call(balances, safeCurrencyCode)) return;
        balances[safeCurrencyCode] = balances[rawCurrencyCode];
        delete balances[rawCurrencyCode];
        boxChanged = true;
      });

      const context = {
        box: safeBox,
        accountNo,
        balances,
        hasBalance: (currencyCode) => Object.prototype.hasOwnProperty.call(balances, normalizeCurrencyCode(currencyCode)),
        readBalance: (currencyCode) => toNumber(balances[normalizeCurrencyCode(currencyCode)], 0),
        writeBalance: (currencyCode, amount) => {
          const safeCurrencyCode = normalizeCurrencyCode(currencyCode);
          if(!safeCurrencyCode) return false;
          const currentAmount = toNumber(balances[safeCurrencyCode], 0);
          const numericAmount = toNumber(amount, 0);
          const nextAmount = Math.abs(numericAmount) <= SALES_PURCHASE_BALANCE_EPSILON ? 0 : numericAmount;
          if(Math.abs(nextAmount - currentAmount) <= SALES_PURCHASE_BALANCE_EPSILON && Object.prototype.hasOwnProperty.call(balances, safeCurrencyCode)) return false;
          balances[safeCurrencyCode] = nextAmount;
          return true;
        }
      };

      if(resolveNextBalance(context) === true) boxChanged = true;
      if(!boxChanged) return safeBox;
      didChange = true;
      return { ...safeBox, balances };
    });

    if(!didChange) return currentState;
    return writeCashBoxesStateForSalesPurchase({
      ...currentState,
      boxes: nextBoxes
    }, { notify });
  }

  function applySalesPurchaseCashBoxLedgerDelta(previousEntriesState, nextEntriesState, { notify = true } = {}){
    const previousTotals = buildSalesPurchasePostedEntryAccountCurrencyTotals(previousEntriesState);
    const nextTotals = buildSalesPurchasePostedEntryAccountCurrencyTotals(nextEntriesState);
    const deltaMap = new Map();
    const allKeys = new Set([...previousTotals.keys(), ...nextTotals.keys()]);

    allKeys.forEach((key) => {
      const delta = toNumber(nextTotals.get(key), 0) - toNumber(previousTotals.get(key), 0);
      if(Math.abs(delta) <= SALES_PURCHASE_BALANCE_EPSILON) return;
      deltaMap.set(key, delta);
    });

    if(!deltaMap.size) return readCashBoxesStateForSalesPurchase();

    const rawState = readSalesPurchaseRawCashBoxesState();
    return updateSalesPurchaseCashBoxBalances(({ accountNo, readBalance, writeBalance }) => {
      let boxChanged = false;
      deltaMap.forEach((delta, key) => {
        const [deltaAccountNo, currencyCode = ''] = key.split('::');
        const safeCurrencyCode = normalizeCurrencyCode(currencyCode);
        if(deltaAccountNo !== accountNo || !safeCurrencyCode) return;

        const storedBalance = readSalesPurchaseStoredCashBoxBalance(accountNo, safeCurrencyCode, rawState);
        const previousLedgerAmount = toNumber(previousTotals.get(key), 0);
        const currentAmount = readBalance(safeCurrencyCode);
        const hasMeaningfulStoredBalance = storedBalance.hasBalance && Math.abs(storedBalance.amount) > SALES_PURCHASE_BALANCE_EPSILON;
        const baselineAmount = hasMeaningfulStoredBalance
          ? currentAmount
          : ((Math.abs(previousLedgerAmount) > SALES_PURCHASE_BALANCE_EPSILON || storedBalance.hasBalance)
              ? previousLedgerAmount
              : currentAmount);
        if(writeBalance(safeCurrencyCode, baselineAmount + delta)) boxChanged = true;
      });
      return boxChanged;
    }, { notify });
  }


  function writeEntriesStateForSalesPurchase(nextState, { notify = true, syncCashBoxes = true } = {}){
    const previousState = readEntriesStateForSalesPurchase();
    const normalized = normalizeEntriesStateForSalesPurchase(nextState);
    const entriesDomain = resolveDomainAdapter('entries') || TAIF.entriesVouchersDomain || {};
    const persisted = typeof entriesDomain.writeState === 'function'
      ? entriesDomain.writeState(normalized, { notify })
      : (typeof persistJsonState === 'function'
          ? persistJsonState(ENTRIES_STORAGE_KEY, normalized, normalizeEntriesStateForSalesPurchase)
          : normalized);
    const safeState = normalizeEntriesStateForSalesPurchase(persisted);

    if(syncCashBoxes !== false){
      applySalesPurchaseCashBoxLedgerDelta(previousState, safeState, { notify });
    }

    if(typeof entriesDomain.writeState !== 'function' && notify){
      emitSalesPurchaseAccountingDomainUpdate('entries', 'taif:entries-vouchers-updated', safeState);
    }
    return safeState;
  }

  function accumulateSalesPurchaseCashDelta(deltaMap, accountNo, currencyCode, amount){
    const safeDeltaMap = deltaMap instanceof Map ? deltaMap : new Map();
    const safeAccountNo = toSafeText(accountNo);
    const safeCurrencyCode = normalizeCurrencyCode(currencyCode);
    const numericAmount = toNumber(amount, 0);
    if(!safeAccountNo || !safeCurrencyCode || Math.abs(numericAmount) <= SALES_PURCHASE_BALANCE_EPSILON) return safeDeltaMap;
    const key = `${safeAccountNo}::${safeCurrencyCode}`;
    const nextAmount = toNumber(safeDeltaMap.get(key), 0) + numericAmount;
    if(Math.abs(nextAmount) <= SALES_PURCHASE_BALANCE_EPSILON){
      safeDeltaMap.delete(key);
      return safeDeltaMap;
    }
    safeDeltaMap.set(key, nextAmount);
    return safeDeltaMap;
  }

  function invertSalesPurchaseCashDeltaMap(deltaMap){
    const inverted = new Map();
    if(!(deltaMap instanceof Map)) return inverted;
    deltaMap.forEach((amount, key) => {
      const numericAmount = toNumber(amount, 0);
      if(Math.abs(numericAmount) <= SALES_PURCHASE_BALANCE_EPSILON) return;
      inverted.set(key, -numericAmount);
    });
    return inverted;
  }


  function buildSalesPurchaseCashDeltaMapFromSource(source){
    const safeSource = source && typeof source === 'object' ? source : {};
    const deltaMap = new Map();
    const cashAccountNo = toSafeText(safeSource.cashAccountNo);
    if(!cashAccountNo) return deltaMap;

    const legs = buildSalesPurchaseAccountingLegs(safeSource);
    legs.forEach((leg) => {
      const currencyCode = normalizeCurrencyCode(leg?.currency?.code);
      if(!currencyCode) return;
      const signedAmount = leg?.cashSide === 'credit' ? -leg.amount : leg.amount;
      accumulateSalesPurchaseCashDelta(deltaMap, cashAccountNo, currencyCode, signedAmount);
    });

    return deltaMap;
  }

  function buildSalesPurchaseCashDeltaMapFromRecord(record){
    return buildSalesPurchaseCashDeltaMapFromSource(buildSalesPurchaseAccountingSourceFromRecord(record));
  }

  function buildSalesPurchasePostedCashTotals(salesState = readSalesPurchaseState()){
    const safeState = salesState && typeof salesState === 'object' ? salesState : { records: [] };
    const totals = new Map();
    (Array.isArray(safeState.records) ? safeState.records : []).forEach((record) => {
      const safeRecord = normalizeSalesPurchaseRecord(record);
      if(safeRecord.status !== 'posted') return;
      const recordTotals = buildSalesPurchaseCashDeltaMapFromRecord(safeRecord);
      recordTotals.forEach((amount, key) => {
        const [accountNo = '', currencyCode = ''] = String(key || '').split('::');
        accumulateSalesPurchaseCashDelta(totals, accountNo, currencyCode, amount);
      });
    });
    return totals;
  }

  function applySalesPurchaseCashDeltaMap(deltaMap, { notify = true } = {}){
    const safeDeltaMap = deltaMap instanceof Map ? deltaMap : new Map();
    if(!safeDeltaMap.size) return readCashBoxesStateForSalesPurchase();

    const cashboxService = resolveServiceAdapter('cashbox-service');
    if(cashboxService && typeof cashboxService.applyBalanceDelta === 'function'){
      try{
        const serviceResult = cashboxService.applyBalanceDelta(safeDeltaMap, { notify });
        if(serviceResult && serviceResult.ok !== false && serviceResult.state){
          return normalizeSalesPurchaseCashBoxesState(serviceResult.state);
        }
      }catch(error){
        warnSalesPurchaseAccounting('فشل تطبيق فرق الصندوق عبر خدمة الصناديق، سيتم استخدام المسار المحلي الاحتياطي.', error);
      }
    }

    return updateSalesPurchaseCashBoxBalances(({ accountNo, readBalance, writeBalance }) => {
      let boxChanged = false;
      safeDeltaMap.forEach((deltaAmount, key) => {
        const [deltaAccountNo, currencyCode = ''] = String(key || '').split('::');
        const safeCurrencyCode = normalizeCurrencyCode(currencyCode);
        if(deltaAccountNo !== accountNo || !safeCurrencyCode) return;
        const nextAmount = readBalance(safeCurrencyCode) + toNumber(deltaAmount, 0);
        if(writeBalance(safeCurrencyCode, nextAmount)) boxChanged = true;
      });
      return boxChanged;
    }, { notify });
  }

  function resolveSalesPurchaseBridgeAccount(catalog = readAccountCatalog(), cashAccountNo = ''){
    const safeCatalog = Array.isArray(catalog) ? catalog : [];
    const safeCashAccountNo = toSafeText(cashAccountNo);

    const exactNameMatchers = [
      'حسابات القطع الأجنبي',
      'حسابات القطع الاجنبي',
      'حسابات القطع',
      'القطع الأجنبي',
      'القطع الاجنبي'
    ].map((keyword) => normalizeSalesPurchaseSearchText(keyword));

    const exactMatch = safeCatalog.find((account) => {
      if(!account || toSafeText(account.accountNo) === safeCashAccountNo) return false;
      const normalizedName = normalizeSalesPurchaseSearchText(account.name);
      return !!normalizedName && exactNameMatchers.includes(normalizedName);
    }) || null;
    if(exactMatch) return exactMatch;

    const fallbackByCanonicalNo = findAccountByNo('005', safeCatalog);
    if(fallbackByCanonicalNo && fallbackByCanonicalNo.accountNo !== safeCashAccountNo) return fallbackByCanonicalNo;

    const keywordMatchers = ['حسابات القطع', 'القطع الاجنبي', 'القطع الأجنبي', 'قطع اجنبي', 'قطع أجنبي', 'صرف'];
    const matchedByName = safeCatalog.find((account) => {
      if(!account || toSafeText(account.accountNo) === safeCashAccountNo) return false;
      const normalizedName = normalizeSalesPurchaseSearchText(account.name);
      return keywordMatchers.some((keyword) => normalizedName.includes(normalizeSalesPurchaseSearchText(keyword)));
    }) || null;

    if(matchedByName) return matchedByName;
    return null;
  }

  function resolveAccountingCurrencyMeta(code, name = '', decimals = null){
    const safeCode = normalizeCurrencyCode(code);
    const snapshot = getCurrencySnapshot();
    const resolvedCurrency = resolveCurrencyFromList(Array.isArray(snapshot.currencies) ? snapshot.currencies : [], safeCode) || null;
    const resolvedDecimals = Number.isFinite(Number(decimals))
      ? Math.max(0, Number(decimals))
      : Math.max(0, Number(resolvedCurrency?.decimals) || 2);
    return {
      code: safeCode || normalizeCurrencyCode(resolvedCurrency?.code) || 'USD',
      name: toSafeText(name || resolvedCurrency?.name || safeCode || 'USD'),
      decimals: resolvedDecimals
    };
  }

  function buildSalesPurchaseAccountingSourceFromModel(actionId, model, sourceNumber = '', options = {}){
    const safeModel = model && typeof model === 'object' ? model : {};
    const safeFormState = safeModel.formState && typeof safeModel.formState === 'object'
      ? safeModel.formState
      : null;
    const safeType = resolveSalesPurchaseEffectiveActionId(actionId, safeFormState);
    const safeOptions = options && typeof options === 'object' ? options : {};
    const operationKind = toSafeText(safeOptions.operationKind || 'created') || 'created';
    return {
      type: safeType,
      sourceRecordId: toSafeText(safeOptions.sourceRecordId),
      sourceNumber: toSafeText(sourceNumber).toUpperCase(),
      date: salesPurchaseNormalizeDateInputValue(safeModel?.voucherDate || salesPurchaseTodayInputValue()),
      cashAccountNo: toSafeText(safeModel?.cashAccountNo),
      cashAccountName: toSafeText(safeModel?.cashAccount?.name),
      tradeCurrency: resolveAccountingCurrencyMeta(safeModel?.tradeCurrency?.code, safeModel?.tradeCurrency?.name, safeModel?.tradeCurrency?.decimals),
      settlementCurrency: resolveAccountingCurrencyMeta(safeModel?.settlementCurrency?.code, safeModel?.settlementCurrency?.name, safeModel?.settlementCurrency?.decimals),
      amountValue: Math.max(0, Number(safeModel?.amountValue) || 0),
      counterpartAmountValue: Math.max(0, Number(safeModel?.counterpartAmountValue) || 0),
      rateText: toSafeText(safeModel?.activeRateText),
      notes: toSafeText(safeFormState?.notes),
      invoiceSummary: toSafeText(safeFormState?.invoiceSummary),
      counterpartyName: toSafeText(safeFormState?.counterpartyName),
      documentNumber: toSafeText(safeFormState?.documentNumber || safeFormState?.documentNo),
      purchaseCalcMethod: normalizeSalesPurchaseCalcMethod(safeFormState?.purchaseCalcMethod),
      operationKind,
      operationLabel: buildSalesPurchaseOperationLabel(operationKind, safeOptions.revisionCount)
    };
  }

  function buildSalesPurchaseAccountingSourceFromRecord(record){
    const safeRecord = record && typeof record === 'object' ? record : {};
    return {
      type: safeRecord.type === 'sale' ? 'sale' : 'purchase',
      sourceRecordId: toSafeText(safeRecord.id),
      sourceNumber: toSafeText(safeRecord.number).toUpperCase(),
      date: salesPurchaseNormalizeDateInputValue(safeRecord.date || salesPurchaseTodayInputValue()),
      cashAccountNo: toSafeText(safeRecord.cashAccountNo),
      cashAccountName: toSafeText(safeRecord.cashAccountName),
      tradeCurrency: resolveAccountingCurrencyMeta(safeRecord.tradeCurrencyCode, safeRecord.tradeCurrencyName),
      settlementCurrency: resolveAccountingCurrencyMeta(safeRecord.settlementCurrencyCode, safeRecord.settlementCurrencyName),
      amountValue: Math.max(0, Number(safeRecord.amountValue) || 0),
      counterpartAmountValue: Math.max(0, Number(safeRecord.counterpartAmountValue) || 0),
      rateText: toSafeText(safeRecord.rateText),
      notes: toSafeText(safeRecord.notes),
      invoiceSummary: toSafeText(safeRecord.invoiceSummary || safeRecord.summary),
      counterpartyName: toSafeText(safeRecord.counterpartyName),
      documentNumber: toSafeText(safeRecord.documentNumber || safeRecord.documentNo),
      purchaseCalcMethod: normalizeSalesPurchaseCalcMethod(safeRecord.purchaseCalcMethod || safeRecord.calcMethod),
      operationKind: salesPurchaseLifecycleActionKey(safeRecord),
      operationLabel: buildSalesPurchaseOperationLabel(salesPurchaseLifecycleActionKey(safeRecord), safeRecord.revisionCount)
    };
  }

  function buildSalesPurchaseFundingRequirement(source, bridgeAccount = null){
    const safeSource = source && typeof source === 'object' ? source : {};
    if(safeSource.type === 'purchase'){
      return {
        accountNo: toSafeText(safeSource.cashAccountNo),
        accountName: toSafeText(safeSource.cashAccountName),
        currency: safeSource.settlementCurrency,
        amount: Math.max(0, Number(safeSource.counterpartAmountValue) || 0)
      };
    }
    return {
      accountNo: toSafeText(safeSource.cashAccountNo),
      accountName: toSafeText(safeSource.cashAccountName),
      currency: safeSource.tradeCurrency,
      amount: Math.max(0, Number(safeSource.amountValue) || 0)
    };
  }

  function buildSalesPurchaseFallbackCashTotalsFromSalesState(salesState = readSalesPurchaseState(), entriesState = readEntriesStateForSalesPurchase()){
    const safeSalesState = salesState && typeof salesState === 'object' ? salesState : { records: [] };
    const safeEntriesState = normalizeEntriesStateForSalesPurchase(entriesState);
    const totals = new Map();

    (Array.isArray(safeSalesState.records) ? safeSalesState.records : []).forEach((record) => {
      const safeRecord = normalizeSalesPurchaseRecord(record);
      if(safeRecord.status !== 'posted') return;
      if(hasPersistedSalesPurchaseEntryRecord(safeRecord, safeEntriesState)) return;
      const fallbackTotals = buildSalesPurchaseCashDeltaMapFromRecord(safeRecord);
      fallbackTotals.forEach((amount, key) => {
        const [accountNo = '', currencyCode = ''] = String(key || '').split('::');
        accumulateSalesPurchaseCashDelta(totals, accountNo, currencyCode, amount);
      });
    });

    return totals;
  }

  function buildSalesPurchaseCompositeAccountCurrencyTotals(entriesState = readEntriesStateForSalesPurchase(), salesState = readSalesPurchaseState()){
    const postedEntryTotals = buildSalesPurchasePostedEntryAccountCurrencyTotals(entriesState);
    const fallbackTotals = buildSalesPurchaseFallbackCashTotalsFromSalesState(salesState, entriesState);
    const totals = new Map(postedEntryTotals);
    fallbackTotals.forEach((amount, key) => {
      totals.set(key, toNumber(totals.get(key), 0) + toNumber(amount, 0));
    });
    return totals;
  }

  function buildSalesPurchaseComputedAccountCurrencyBalance(accountNo, currencyCode, entriesState = readEntriesStateForSalesPurchase(), salesState = readSalesPurchaseState()){
    const safeAccountNo = toSafeText(accountNo);
    const safeCurrencyCode = normalizeCurrencyCode(currencyCode);
    if(!safeAccountNo || !safeCurrencyCode) return { amount: 0, hasLedgerActivity: false };

    const compositeTotals = buildSalesPurchaseCompositeAccountCurrencyTotals(entriesState, salesState);
    const amount = toNumber(compositeTotals.get(`${safeAccountNo}::${safeCurrencyCode}`), 0);
    return {
      amount,
      hasLedgerActivity: compositeTotals.has(`${safeAccountNo}::${safeCurrencyCode}`)
    };
  }

  function readSalesPurchaseAccountCurrencyBalance(accountNo, currencyCode, entriesState = readEntriesStateForSalesPurchase(), salesState = readSalesPurchaseState()){
    const safeAccountNo = toSafeText(accountNo);
    const safeCurrencyCode = normalizeCurrencyCode(currencyCode);
    if(!safeAccountNo || !safeCurrencyCode) return 0;

    const storedBalance = readSalesPurchaseStoredCashBoxBalance(safeAccountNo, safeCurrencyCode);
    const computed = buildSalesPurchaseComputedAccountCurrencyBalance(safeAccountNo, safeCurrencyCode, entriesState, salesState);
    if(computed.hasLedgerActivity) return computed.amount;
    if(storedBalance.hasBalance) return storedBalance.amount;
    return 0;
  }

  function formatSalesPurchaseAccountingAmount(amount, currency){
    return formatNumericValue(amount, {
      decimals: Number.isFinite(Number(currency?.decimals)) ? Number(currency.decimals) : 2,
      mode: 'standard',
      fallback: '0'
    });
  }

  function buildSalesPurchaseAccountingIssues(actionId, model, options = {}){
    const issues = [];
    const source = buildSalesPurchaseAccountingSourceFromModel(actionId, model);
    const validationEntriesState = options && typeof options === 'object' && options.entriesState
      ? normalizeEntriesStateForSalesPurchase(options.entriesState)
      : readEntriesStateForSalesPurchase();
    const validationSalesState = options && typeof options === 'object' && options.salesState
      ? options.salesState
      : readSalesPurchaseState();

    if(source.tradeCurrency.code && source.tradeCurrency.code === source.settlementCurrency.code){
      issues.push('يجب أن تكون عملة الشراء والمقابل عملتين مختلفتين.');
    }

    const bridgeAccount = resolveSalesPurchaseBridgeAccount(readAccountCatalog(), source.cashAccountNo);
    if(!bridgeAccount){
      issues.push('تعذر تحديد الحساب المحاسبي الوسيط لعملية الصرف. تأكد من وجود حساب مناسب مثل "حسابات القطع الأجنبي" داخل شجرة الحسابات.');
      return issues;
    }

    const funding = buildSalesPurchaseFundingRequirement(source, bridgeAccount);
    const requiredAmount = Math.max(0, Number(funding.amount) || 0);
    const fundingCurrency = funding.currency || resolveAccountingCurrencyMeta('USD', 'USD', 2);
    if(requiredAmount <= SALES_PURCHASE_BALANCE_EPSILON) return issues;

    const fundingAccountNo = toSafeText(funding.accountNo) || toSafeText(source.cashAccountNo);
    const availableAmount = readSalesPurchaseAccountCurrencyBalance(fundingAccountNo, fundingCurrency.code, validationEntriesState, validationSalesState);
    if((availableAmount + SALES_PURCHASE_BALANCE_EPSILON) < requiredAmount){
      const requiredText = formatSalesPurchaseAccountingAmount(requiredAmount, fundingCurrency);
      const availableText = formatSalesPurchaseAccountingAmount(Math.max(0, availableAmount), fundingCurrency);
      const fundingScopeLabel = fundingAccountNo === toSafeText(source.cashAccountNo)
        ? 'داخل الصندوق النقدي المحدد'
        : `داخل ${toSafeText(funding.accountName) || 'الحساب المطلوب'}`;
      issues.push(`الرصيد غير كافٍ ${fundingScopeLabel} لهذه العملية. المتاح ${availableText} ${fundingCurrency.code} بينما المطلوب ${requiredText} ${fundingCurrency.code}.`);
    }

    return issues;
  }

  function describeSalesPurchaseAccountingLeg(source, leg){
    const operationLabel = source.type === 'sale' ? 'مبيع' : 'شراء';
    const referenceSuffix = source.sourceNumber ? ` - ${source.sourceNumber}` : '';
    if(source.type === 'purchase'){
      return leg.kind === 'trade'
        ? `${operationLabel} ${leg.currency.name}${referenceSuffix}`
        : `دفع ${leg.currency.name}${referenceSuffix}`;
    }
    return leg.kind === 'trade'
      ? `${operationLabel} ${leg.currency.name}${referenceSuffix}`
      : `قبض ${leg.currency.name}${referenceSuffix}`;
  }

  function buildSalesPurchaseAccountingLegs(source){
    const safeSource = source && typeof source === 'object' ? source : {};
    const tradeLeg = {
      kind: 'trade',
      currency: safeSource.tradeCurrency,
      amount: Math.max(0, Number(safeSource.amountValue) || 0),
      cashSide: safeSource.type === 'purchase' ? 'debit' : 'credit'
    };
    const settlementLeg = {
      kind: 'settlement',
      currency: safeSource.settlementCurrency,
      amount: Math.max(0, Number(safeSource.counterpartAmountValue) || 0),
      cashSide: safeSource.type === 'sale' ? 'debit' : 'credit'
    };
    return [tradeLeg, settlementLeg].filter((leg) => leg.amount > SALES_PURCHASE_BALANCE_EPSILON && leg.currency?.code);
  }

  function resolveSalesPurchaseAccountingLegPostingTargets(source, leg, bridgeAccount){
    const safeSource = source && typeof source === 'object' ? source : {};
    const safeLeg = leg && typeof leg === 'object' ? leg : {};
    const safeBridgeAccount = bridgeAccount && typeof bridgeAccount === 'object' ? bridgeAccount : {};
    const primaryAccountNo = toSafeText(safeSource.cashAccountNo);
    const primaryAccountName = toSafeText(safeSource.cashAccountName);
    const counterpartAccountNo = toSafeText(safeBridgeAccount.accountNo);
    const counterpartAccountName = toSafeText(safeBridgeAccount.name);
    const isPrimaryDebit = safeLeg.cashSide !== 'credit';
    const primaryLabelBase = primaryAccountName || 'الصندوق النقدي';
    const counterpartLabelBase = counterpartAccountName || 'حسابات القطع الأجنبي';
    return {
      primaryAccountNo,
      primaryAccountName,
      counterpartAccountNo,
      counterpartAccountName,
      isPrimaryDebit,
      primaryRoleLabel: `${isPrimaryDebit ? 'زيادة' : 'تخفيض'} ${primaryLabelBase}`,
      counterpartRoleLabel: `${counterpartLabelBase} ${isPrimaryDebit ? 'دائن' : 'مدين'}`
    };
  }

  function buildSalesPurchaseAccountingEntryText(source, leg){
    const description = describeSalesPurchaseAccountingLeg(source, leg);
    const sourceSummary = toSafeText(source.invoiceSummary);
    const sourceNotes = toSafeText(source.notes);
    const lineDescriptionExtras = [sourceSummary, sourceNotes].filter(Boolean).join(' | ');
    const summaryParts = [
      `${source.type === 'sale' ? 'فاتورة مبيع' : 'فاتورة شراء'} ${source.tradeCurrency.code}/${source.settlementCurrency.code}`.trim(),
      toSafeText(source.operationLabel),
      source.rateText && source.rateText !== '—' ? `سعر الصرف: ${source.rateText}` : '',
      source.counterpartyName ? `الاسم: ${source.counterpartyName}` : '',
      sourceSummary ? `ملخص الفاتورة: ${sourceSummary}` : '',
      sourceNotes
    ].filter(Boolean);
    return {
      lineDescription: lineDescriptionExtras ? `${description} | ${lineDescriptionExtras}` : description,
      summary: summaryParts.join(' | ')
    };
  }

  function buildSalesPurchaseAccountingEntryLines(leg, targets, amount, lineDescription){
    const isPrimaryDebit = targets.isPrimaryDebit;
    const counterpartDescription = `${toSafeText(targets.counterpartAccountName) || 'الحساب المقابل'} ${leg.currency.name}`;
    return [
      {
        lineNo: 1,
        roleKey: leg.kind === 'trade' ? 'bridge' : 'cash',
        roleLabel: toSafeText(targets.primaryRoleLabel),
        accountNo: toSafeText(targets.primaryAccountNo),
        accountName: toSafeText(targets.primaryAccountName),
        description: lineDescription,
        debit: isPrimaryDebit ? amount : 0,
        credit: isPrimaryDebit ? 0 : amount,
        side: isPrimaryDebit ? 'debit' : 'credit',
        amount
      },
      {
        lineNo: 2,
        roleKey: leg.kind === 'trade' ? 'cash' : 'bridge',
        roleLabel: toSafeText(targets.counterpartRoleLabel),
        accountNo: toSafeText(targets.counterpartAccountNo),
        accountName: toSafeText(targets.counterpartAccountName),
        description: counterpartDescription,
        debit: isPrimaryDebit ? 0 : amount,
        credit: isPrimaryDebit ? amount : 0,
        side: isPrimaryDebit ? 'credit' : 'debit',
        amount
      }
    ];
  }

  function createSalesPurchaseAccountingEntryRecord(source, leg, bridgeAccount, voucherNumber, createdAt, ordinal = 0){
    const amount = Math.max(0, Number(leg.amount) || 0);
    const targets = resolveSalesPurchaseAccountingLegPostingTargets(source, leg, bridgeAccount);
    const { lineDescription, summary } = buildSalesPurchaseAccountingEntryText(source, leg);
    const lines = buildSalesPurchaseAccountingEntryLines(leg, targets, amount, lineDescription);
    const isPrimaryDebit = targets.isPrimaryDebit;
    return normalizeEntryRecordForSalesPurchase({
      id: `entry-record-sales-purchase-${createdAt}-${voucherNumber}-${ordinal + 1}`.replace(/[^a-zA-Z0-9-_]/g, '-'),
      type: 'journal',
      number: voucherNumber,
      status: 'posted',
      date: salesPurchaseNormalizeDateInputValue(source.date),
      description: lineDescription,
      summary,
      counterpartAccountNo: toSafeText(targets.counterpartAccountNo),
      counterpartAccountName: toSafeText(targets.counterpartAccountName),
      partyName: toSafeText(source.counterpartyName),
      currency: leg.currency.code,
      amount,
      grossAmount: amount,
      netAmount: amount,
      cashAccountNo: toSafeText(source.cashAccountNo),
      cashAccountName: toSafeText(source.cashAccountName),
      lines,
      receiptAmount: leg.kind === 'settlement' && isPrimaryDebit ? amount : 0,
      paymentAmount: leg.kind === 'settlement' && !isPrimaryDebit ? amount : 0,
      cashMotionPickerCode: leg.kind === 'settlement' ? (isPrimaryDebit ? 'cash-in-box' : 'cash-out-box') : 'journal',
      createdAt,
      updatedAt: createdAt,
      sourceSalesPurchaseRecordId: toSafeText(source.sourceRecordId),
      sourceSalesPurchaseNumber: toSafeText(source.sourceNumber).toUpperCase()
    }, ordinal);
  }


  function prepareSalesPurchaseAccountingSource(source){
    const safeSource = source && typeof source === 'object' ? source : null;
    if(!safeSource) return { ok: false, issues: ['تعذر تجهيز الحركة المحاسبية.'] };

    const accountCatalog = readAccountCatalog();
    const bridgeAccount = resolveSalesPurchaseBridgeAccount(accountCatalog, safeSource.cashAccountNo);
    if(!bridgeAccount){
      return { ok: false, issues: ['تعذر تحديد الحساب المحاسبي الوسيط لعملية الصرف.'] };
    }

    const legs = buildSalesPurchaseAccountingLegs(safeSource);
    if(!legs.length){
      return { ok: false, issues: ['تعذر تجهيز قيود محاسبية صالحة لهذه العملية.'] };
    }

    return { ok: true, source: safeSource, bridgeAccount, legs };
  }

  function buildSalesPurchaseAccountingEntryInsert(state, source, bridgeAccount, legs){
    const currentState = normalizeEntriesStateForSalesPurchase(state);
    const currentRecords = Array.isArray(currentState.records) ? currentState.records : [];
    const currentCounters = normalizeEntriesCountersForSalesPurchase(currentState.counters, currentRecords);
    const nextJournalCounter = Math.max(DEFAULT_ENTRIES_COUNTERS.JV, Number(currentCounters.JV) || DEFAULT_ENTRIES_COUNTERS.JV);
    const createdAtSeed = Date.now();
    const records = legs.map((leg, index) => {
      const voucherNumber = formatSalesPurchaseEntriesVoucherNumber('JV', nextJournalCounter + index);
      return createSalesPurchaseAccountingEntryRecord(source, leg, bridgeAccount, voucherNumber, createdAtSeed + index, index);
    });
    const nextState = normalizeEntriesStateForSalesPurchase({
      ...currentState,
      counters: {
        ...(currentState.counters && typeof currentState.counters === 'object' ? currentState.counters : {}),
        JV: nextJournalCounter + records.length
      },
      records: [...records, ...currentRecords]
    });
    return { nextState, records };
  }

  function persistSalesPurchaseAccountingEntryInsert(nextState, records, bridgeAccount){
    const persistedState = writeEntriesStateForSalesPurchase(nextState, { syncCashBoxes: true });
    return {
      ok: true,
      state: persistedState,
      records,
      recordIds: records.map((record) => toSafeText(record?.id)).filter(Boolean),
      voucherNumbers: records.map((record) => toSafeText(record?.number).toUpperCase()).filter(Boolean),
      bridgeAccount
    };
  }

  function appendSalesPurchaseAccountingEntriesFromSource(source){
    const prepared = prepareSalesPurchaseAccountingSource(source);
    if(!prepared.ok) return prepared;
    const insert = buildSalesPurchaseAccountingEntryInsert(
      readEntriesStateForSalesPurchase(),
      prepared.source,
      prepared.bridgeAccount,
      prepared.legs
    );
    return persistSalesPurchaseAccountingEntryInsert(insert.nextState, insert.records, prepared.bridgeAccount);
  }

  function deleteSalesPurchaseLinkedEntryRecords(recordOrIds = [], voucherNumbers = []){
    const safeRecord = recordOrIds && typeof recordOrIds === 'object' && !Array.isArray(recordOrIds)
      ? normalizeSalesPurchaseRecord(recordOrIds)
      : null;
    const safeIds = safeRecord
      ? dedupeSalesPurchaseStringList(safeRecord.linkedEntryRecordIds, (value) => toSafeText(value))
      : dedupeSalesPurchaseStringList(recordOrIds, (value) => toSafeText(value));
    const safeVoucherNumbers = safeRecord
      ? dedupeSalesPurchaseStringList(safeRecord.linkedEntryVoucherNumbers, (value) => toSafeText(value).toUpperCase())
      : dedupeSalesPurchaseStringList(voucherNumbers, (value) => toSafeText(value).toUpperCase());
    const safeSourceRecordId = toSafeText(safeRecord?.id);
    const safeSourceNumber = toSafeText(safeRecord?.number).toUpperCase();
    if(!safeIds.length && !safeVoucherNumbers.length && !safeSourceRecordId && !safeSourceNumber){
      return { ok: false, deletedCount: 0 };
    }

    const idSet = new Set(safeIds);
    const numberSet = new Set(safeVoucherNumbers);
    const state = readEntriesStateForSalesPurchase();
    const currentRecords = Array.isArray(state.records) ? state.records : [];
    const nextRecords = currentRecords.filter((record) => {
      const recordId = toSafeText(record?.id);
      const recordNumber = toSafeText(record?.number).toUpperCase();
      const sourceRecordId = toSafeText(record?.sourceSalesPurchaseRecordId);
      const sourceNumber = toSafeText(record?.sourceSalesPurchaseNumber).toUpperCase();
      if(idSet.has(recordId) || numberSet.has(recordNumber)) return false;
      if(safeSourceRecordId && sourceRecordId === safeSourceRecordId) return false;
      if(safeSourceNumber && sourceNumber === safeSourceNumber) return false;
      if(safeSourceNumber && isSalesPurchaseGeneratedEntryRecord(record) && recordMentionsSalesPurchaseNumber(record, safeSourceNumber)) return false;
      return true;
    });
    const deletedCount = currentRecords.length - nextRecords.length;
    if(deletedCount <= 0) return { ok: false, deletedCount: 0 };

    writeEntriesStateForSalesPurchase({
      ...state,
      records: nextRecords
    }, { syncCashBoxes: true });

    return { ok: true, deletedCount };
  }


  function resolveSalesPurchaseLinkedEntryMatches(record, entriesState = readEntriesStateForSalesPurchase()){
    const safeRecord = normalizeSalesPurchaseRecord(record);
    const safeRecordId = toSafeText(safeRecord.id);
    const safeRecordNumber = toSafeText(safeRecord.number).toUpperCase();
    const idSet = new Set((Array.isArray(safeRecord.linkedEntryRecordIds) ? safeRecord.linkedEntryRecordIds : []).map((value) => toSafeText(value)).filter(Boolean));
    const numberSet = new Set((Array.isArray(safeRecord.linkedEntryVoucherNumbers) ? safeRecord.linkedEntryVoucherNumbers : []).map((value) => toSafeText(value).toUpperCase()).filter(Boolean));
    const sourceRecords = Array.isArray(entriesState?.records) ? entriesState.records : [];
    const matchedRecords = [];
    const remainingRecords = [];

    sourceRecords.forEach((record, index) => {
      const safeId = toSafeText(record?.id);
      const safeNumber = toSafeText(record?.number).toUpperCase();
      const sourceRecordId = toSafeText(record?.sourceSalesPurchaseRecordId);
      const sourceNumber = toSafeText(record?.sourceSalesPurchaseNumber).toUpperCase();
      const isMatch = (idSet.size > 0 && idSet.has(safeId))
        || (numberSet.size > 0 && numberSet.has(safeNumber))
        || (!!safeRecordId && sourceRecordId === safeRecordId)
        || (!!safeRecordNumber && sourceNumber === safeRecordNumber)
        || (!!safeRecordNumber && isSalesPurchaseGeneratedEntryRecord(record) && recordMentionsSalesPurchaseNumber(record, safeRecordNumber));
      if(isMatch){
        matchedRecords.push(normalizeEntryRecordForSalesPurchase(record, index));
        return;
      }
      remainingRecords.push(record);
    });

    matchedRecords.sort((left, right) => {
      const leftIndex = parseEntriesVoucherNumberIndex(left?.number, 'JV');
      const rightIndex = parseEntriesVoucherNumberIndex(right?.number, 'JV');
      if(Number.isFinite(leftIndex) && Number.isFinite(rightIndex) && leftIndex !== rightIndex) return leftIndex - rightIndex;
      const createdDelta = (Number(left?.createdAt) || 0) - (Number(right?.createdAt) || 0);
      if(createdDelta) return createdDelta;
      return toSafeText(left?.id).localeCompare(toSafeText(right?.id), 'en');
    });

    return { matchedRecords, remainingRecords };
  }

  function pruneOrphanSalesPurchaseEntryRecords(entriesState = readEntriesStateForSalesPurchase(), options = {}){
    const state = normalizeEntriesStateForSalesPurchase(entriesState);
    const safeOptions = options && typeof options === 'object' ? options : {};
    const salesState = safeOptions.salesState && typeof safeOptions.salesState === 'object'
      ? safeOptions.salesState
      : readSalesPurchaseState();
    const references = buildSalesPurchaseLinkedEntryReferenceIndex(salesState);
    const currentRecords = Array.isArray(state.records) ? state.records : [];
    const nextRecords = currentRecords.filter((record) => {
      if(!isSalesPurchaseGeneratedEntryRecord(record)) return true;
      const safeId = toSafeText(record?.id);
      const safeNumber = toSafeText(record?.number).toUpperCase();
      const sourceRecordId = toSafeText(record?.sourceSalesPurchaseRecordId);
      const sourceNumber = toSafeText(record?.sourceSalesPurchaseNumber).toUpperCase();
      if(references.entryRecordIds.has(safeId) || references.entryVoucherNumbers.has(safeNumber)) return true;
      if(sourceRecordId && references.salesRecordIds.has(sourceRecordId) && references.entryRecordIds.has(safeId)) return true;
      if(sourceNumber && references.salesNumbers.has(sourceNumber) && references.entryVoucherNumbers.has(safeNumber)) return true;
      return false;
    });
    const removedCount = currentRecords.length - nextRecords.length;
    if(removedCount <= 0) return { ok: false, removedCount: 0, state };
    const persistedState = writeEntriesStateForSalesPurchase({
      ...state,
      records: nextRecords
    }, {
      notify: safeOptions.notify !== false,
      syncCashBoxes: safeOptions.syncCashBoxes !== false
    });
    return { ok: true, removedCount, state: persistedState };
  }

  function buildEntriesStateExcludingSalesPurchaseRecord(record, entriesState = readEntriesStateForSalesPurchase()){
    const state = normalizeEntriesStateForSalesPurchase(entriesState);
    const { remainingRecords } = resolveSalesPurchaseLinkedEntryMatches(record, state);
    return normalizeEntriesStateForSalesPurchase({
      ...state,
      records: remainingRecords
    });
  }

  function createReversedEntryRecordForSalesPurchase(record, salesRecord){
    const safeRecord = normalizeEntryRecordForSalesPurchase(record);
    const safeSalesRecord = normalizeSalesPurchaseRecord(salesRecord);
    const reverseStamp = Date.now();
    const sourceLabel = `${salesPurchaseTypeLabel(safeSalesRecord.type)} ${toSafeText(safeSalesRecord.number) || ''}`.trim();
    const reversedDescription = toSafeText(safeRecord.description)
      ? `${toSafeText(safeRecord.description)} · ملغى / معكوس`
      : `قيد ملغى / معكوس${sourceLabel ? ` · ${sourceLabel}` : ''}`;
    const summaryParts = [
      'تم عكس هذا القيد من فاتورة البيع/الشراء',
      sourceLabel,
      toSafeText(safeRecord.summary)
    ].filter(Boolean);
    return normalizeEntryRecordForSalesPurchase({
      ...safeRecord,
      status: 'reversed',
      description: reversedDescription,
      summary: summaryParts.join(' | '),
      updatedAt: reverseStamp,
      reversedAt: reverseStamp,
      sourceSalesPurchaseRecordId: toSafeText(safeSalesRecord.id),
      sourceSalesPurchaseNumber: toSafeText(safeSalesRecord.number)
    });
  }

  function buildEntriesStateWithReversedSalesPurchaseRecord(record, entriesState = readEntriesStateForSalesPurchase()){
    const state = normalizeEntriesStateForSalesPurchase(entriesState);
    const { matchedRecords, remainingRecords } = resolveSalesPurchaseLinkedEntryMatches(record, state);
    const reversedRecords = matchedRecords.map((entryRecord) => createReversedEntryRecordForSalesPurchase(entryRecord, record));
    return normalizeEntriesStateForSalesPurchase({
      ...state,
      records: [...reversedRecords, ...remainingRecords]
    });
  }

  function upsertSalesPurchaseAccountingEntriesForRecord(record, source){
    const prepared = prepareSalesPurchaseAccountingSource(source);
    if(!prepared.ok) return prepared;
    const insert = buildSalesPurchaseAccountingEntryInsert(
      buildEntriesStateExcludingSalesPurchaseRecord(record),
      prepared.source,
      prepared.bridgeAccount,
      prepared.legs
    );
    return persistSalesPurchaseAccountingEntryInsert(insert.nextState, insert.records, prepared.bridgeAccount);
  }

  function hasSalesPurchaseRecordChanged(record, model){
    const safeRecord = normalizeSalesPurchaseRecord(record);
    const tradeCurrencyCode = normalizeCurrencyCode(model?.tradeCurrency?.code);
    const settlementCurrencyCode = normalizeCurrencyCode(model?.settlementCurrency?.code);
    const amountValue = Math.max(0, Number(model?.amountValue) || 0);
    const counterpartAmountValue = Math.max(0, Number(model?.counterpartAmountValue) || 0);
    const rateValue = Math.max(0, Number(model?.activeRateValue) || 0);
    if(safeRecord.date !== salesPurchaseNormalizeDateInputValue(model?.voucherDate || safeRecord.date)) return true;
    if(safeRecord.cashAccountNo !== toSafeText(model?.cashAccountNo)) return true;
    if(normalizeCurrencyCode(safeRecord.tradeCurrencyCode) !== tradeCurrencyCode) return true;
    if(normalizeCurrencyCode(safeRecord.settlementCurrencyCode) !== settlementCurrencyCode) return true;
    if(Math.abs((Number(safeRecord.amountValue) || 0) - amountValue) > SALES_PURCHASE_BALANCE_EPSILON) return true;
    if(Math.abs((Number(safeRecord.counterpartAmountValue) || 0) - counterpartAmountValue) > SALES_PURCHASE_BALANCE_EPSILON) return true;
    if(Math.abs((Number(safeRecord.rateValue) || 0) - rateValue) > SALES_PURCHASE_BALANCE_EPSILON) return true;
    if(toSafeText(safeRecord.notes) !== toSafeText(model?.formState?.notes)) return true;
    if(toSafeText(safeRecord.invoiceSummary || safeRecord.summary) !== toSafeText(model?.formState?.invoiceSummary)) return true;
    if(toSafeText(safeRecord.counterpartyName) !== toSafeText(model?.formState?.counterpartyName)) return true;
    if(toSafeText(safeRecord.documentNumber || safeRecord.documentNo) !== toSafeText(model?.formState?.documentNumber || model?.formState?.documentNo)) return true;
    if(normalizeSalesPurchaseCalcMethod(safeRecord.purchaseCalcMethod || safeRecord.calcMethod) !== normalizeSalesPurchaseCalcMethod(model?.formState?.purchaseCalcMethod)) return true;
    return false;
  }

  function createUpdatedSalesPurchaseRecord(record, model, accounting, options = {}){
    const safeRecord = normalizeSalesPurchaseRecord(record);
    const ownerActionId = normalizeSalesPurchaseActionOwnerId(options?.ownerActionId)
      || resolveSalesPurchaseRecordOwnerActionId(safeRecord);
    return normalizeSalesPurchaseRecord({
      ...safeRecord,
      ownerActionId,
      status: 'posted',
      date: salesPurchaseNormalizeDateInputValue(model?.voucherDate || safeRecord.date),
      cashAccountNo: toSafeText(model?.cashAccountNo),
      cashAccountName: toSafeText(model?.cashAccount?.name),
      tradeCurrencyCode: normalizeCurrencyCode(model?.tradeCurrency?.code),
      tradeCurrencyName: toSafeText(model?.tradeCurrency?.name),
      settlementCurrencyCode: normalizeCurrencyCode(model?.settlementCurrency?.code),
      settlementCurrencyName: toSafeText(model?.settlementCurrency?.name),
      amountValue: Math.max(0, Number(model?.amountValue) || 0),
      counterpartAmountValue: Math.max(0, Number(model?.counterpartAmountValue) || 0),
      rateValue: Math.max(0, Number(model?.activeRateValue) || 0),
      amountText: toSafeText(model?.amountDisplayText || model?.amountText || safeRecord.amountText || '0'),
      counterpartAmountText: toSafeText(model?.counterpartAmountText || safeRecord.counterpartAmountText || '0'),
      rateText: toSafeText(model?.activeRateText || safeRecord.rateText || '—'),
      rateMode: String(model?.formState?.rateMode || '').trim() === 'manual' ? 'manual' : 'auto',
      manualRateText: sanitizeNumericInput(model?.formState?.manualRateText || ''),
      amountEntrySide: normalizeSalesPurchaseEditedAmountField(model?.formState?.lastEditedAmountField),
      notes: toSafeText(model?.formState?.notes),
      invoiceSummary: toSafeText(model?.formState?.invoiceSummary),
      counterpartyName: toSafeText(model?.formState?.counterpartyName),
      documentNumber: toSafeText(model?.formState?.documentNumber || model?.formState?.documentNo),
      purchaseCalcMethod: normalizeSalesPurchaseCalcMethod(model?.formState?.purchaseCalcMethod),
      linkedEntryRecordIds: Array.isArray(accounting?.recordIds) ? accounting.recordIds : [],
      linkedEntryVoucherNumbers: Array.isArray(accounting?.voucherNumbers) ? accounting.voucherNumbers : [],
      accountingBridgeAccountNo: toSafeText(accounting?.bridgeAccount?.accountNo),
      accountingBridgeAccountName: toSafeText(accounting?.bridgeAccount?.name),
      revisionCount: Math.max(0, Number(safeRecord.revisionCount) || 0) + 1,
      lastAction: 'updated',
      createdAt: Number(safeRecord.createdAt) || Date.now(),
      updatedAt: Date.now(),
      reversedAt: 0
    });
  }

  function repairSalesPurchaseAccountingLinks(){
    const salesState = readSalesPurchaseState();
    const salesRecords = Array.isArray(salesState.records) ? salesState.records : [];
    const workingEntriesState = readEntriesStateForSalesPurchase();
    let didRepair = false;

    if(!salesRecords.length){
      const pruneResult = pruneOrphanSalesPurchaseEntryRecords(workingEntriesState, {
        salesState,
        notify: false,
        syncCashBoxes: false
      });
      return !!(pruneResult.ok || pruneResult.removedCount > 0);
    }

    const nextRecords = salesRecords.map((record) => {
      const safeRecord = normalizeSalesPurchaseRecord(record);
      const bridgeAccount = resolveSalesPurchaseBridgeAccount(readAccountCatalog(), safeRecord.cashAccountNo)
        || { accountNo: safeRecord.accountingBridgeAccountNo, name: safeRecord.accountingBridgeAccountName };
      const { matchedRecords } = resolveSalesPurchaseLinkedEntryMatches(safeRecord, workingEntriesState);
      const canonicalIds = matchedRecords.length
        ? dedupeSalesPurchaseStringList(matchedRecords.map((entryRecord) => toSafeText(entryRecord?.id)), (value) => toSafeText(value))
        : dedupeSalesPurchaseStringList(safeRecord.linkedEntryRecordIds, (value) => toSafeText(value));
      const canonicalNumbers = matchedRecords.length
        ? dedupeSalesPurchaseStringList(matchedRecords.map((entryRecord) => toSafeText(entryRecord?.number).toUpperCase()), (value) => toSafeText(value).toUpperCase())
        : dedupeSalesPurchaseStringList(safeRecord.linkedEntryVoucherNumbers, (value) => toSafeText(value).toUpperCase());
      const nextBridgeAccountNo = toSafeText(bridgeAccount?.accountNo || safeRecord.accountingBridgeAccountNo);
      const nextBridgeAccountName = toSafeText(bridgeAccount?.name || safeRecord.accountingBridgeAccountName);
      const hasLinkDelta = !areNormalizedStringListsEqual(canonicalIds, safeRecord.linkedEntryRecordIds)
        || !areNormalizedStringListsEqual(canonicalNumbers, safeRecord.linkedEntryVoucherNumbers)
        || nextBridgeAccountNo !== toSafeText(safeRecord.accountingBridgeAccountNo)
        || nextBridgeAccountName !== toSafeText(safeRecord.accountingBridgeAccountName);

      if(!hasLinkDelta) return safeRecord;
      didRepair = true;
      return normalizeSalesPurchaseRecord({
        ...safeRecord,
        linkedEntryRecordIds: canonicalIds,
        linkedEntryVoucherNumbers: canonicalNumbers,
        accountingBridgeAccountNo: nextBridgeAccountNo,
        accountingBridgeAccountName: nextBridgeAccountName
      });
    });

    const nextSalesState = didRepair
      ? writeSalesPurchaseState({
          ...salesState,
          records: nextRecords
        }, { notify: false })
      : salesState;

    const pruneResult = pruneOrphanSalesPurchaseEntryRecords(workingEntriesState, {
      salesState: didRepair ? nextSalesState : salesState,
      notify: false,
      syncCashBoxes: false
    });

    return didRepair || !!(pruneResult.ok || pruneResult.removedCount > 0);
  }

  Object.assign(feature, {
    ensureAccountCatalog,
    readAccountCatalog,
    findAccountByNo,
    readPrimaryCashAccount,
    findFirstAccountByName,
    resolveDefaultCashAccount,
    parseEntriesVoucherNumberIndex,
    createEntriesStateFallback,
    isSalesPurchaseGeneratedEntryRecord,
    normalizeEntryLineForSalesPurchase,
    normalizeEntryRecordForSalesPurchase,
    normalizeEntriesCountersForSalesPurchase,
    normalizeEntriesStateForSalesPurchase,
    readEntriesStateForSalesPurchase,
    readSalesPurchaseRawCashBoxesState,
    normalizeSalesPurchaseCashBoxesState,
    readCashBoxesStateForSalesPurchase,
    writeCashBoxesStateForSalesPurchase,
    readSalesPurchaseStoredCashBoxBalance,
    readLegacyEntriesStateForSalesPurchase,
    buildSalesPurchasePostedEntryAccountCurrencyTotals,
    applySalesPurchaseCashBoxLedgerDelta,
    writeEntriesStateForSalesPurchase,
    accumulateSalesPurchaseCashDelta,
    invertSalesPurchaseCashDeltaMap,
    buildSalesPurchaseCashDeltaMapFromSource,
    buildSalesPurchaseCashDeltaMapFromRecord,
    buildSalesPurchasePostedCashTotals,
    applySalesPurchaseCashDeltaMap,
    resolveSalesPurchaseBridgeAccount,
    resolveAccountingCurrencyMeta,
    buildSalesPurchaseAccountingSourceFromModel,
    buildSalesPurchaseAccountingSourceFromRecord,
    buildSalesPurchaseFundingRequirement,
    buildSalesPurchaseFallbackCashTotalsFromSalesState,
    buildSalesPurchaseCompositeAccountCurrencyTotals,
    buildSalesPurchaseComputedAccountCurrencyBalance,
    readSalesPurchaseAccountCurrencyBalance,
    formatSalesPurchaseAccountingAmount,
    buildSalesPurchaseAccountingIssues,
    describeSalesPurchaseAccountingLeg,
    buildSalesPurchaseAccountingLegs,
    resolveSalesPurchaseAccountingLegPostingTargets,
    createSalesPurchaseAccountingEntryRecord,
    appendSalesPurchaseAccountingEntriesFromSource,
    deleteSalesPurchaseLinkedEntryRecords,
    resolveSalesPurchaseLinkedEntryMatches,
    pruneOrphanSalesPurchaseEntryRecords,
    hasPersistedSalesPurchaseEntryRecord,
    buildEntriesStateExcludingSalesPurchaseRecord,
    createReversedEntryRecordForSalesPurchase,
    buildEntriesStateWithReversedSalesPurchaseRecord,
    upsertSalesPurchaseAccountingEntriesForRecord,
    hasSalesPurchaseRecordChanged,
    createUpdatedSalesPurchaseRecord,
    repairSalesPurchaseAccountingLinks
  });
})();
