(()=>{
  /*
   * TAIF Sales & Purchase records/store module.
   * Owns persisted records, form defaults, search normalization,
   * date/account field render helpers, and currency defaults.
   */
  const TAIF = window.TAIF;
  const feature = TAIF.salesPurchaseFeature || (TAIF.salesPurchaseFeature = {});
  const dateSystem = TAIF.ui?.dateSystem || {};
  const {
    escapeHtml,
    normalizeTypeaheadText,
    persistJsonState,
    readJsonStorage,
    wrapControlTextMarkup
  } = TAIF.core.utils;
  const {
    runtime,
    SALES_PURCHASE_STORAGE_KEY,
    SALES_PURCHASE_UPDATED_EVENT,
    DATE_PICKER_MONTH_NAMES,
    DATE_PICKER_WEEKDAY_LABELS,
    DATE_PICKER_ICON_MARKUP,
    DATE_PICKER_CHEVRON_PREV_MARKUP,
    DATE_PICKER_CHEVRON_NEXT_MARKUP,
    createChoicePickerIcon,
    toSafeText,
    createDefaultSalesPurchaseNavigatorState,
    ensureSalesPurchaseNavigatorState,
    buildSalesPurchaseNavigatorLoadedSnapshot,
    resolveSalesPurchaseEffectiveActionId,
    normalizeSalesPurchaseActionOwnerId,
    resolveSalesPurchaseRecordOwnerActionId,
    normalizeSalesPurchasePartyDraft,
    createDefaultSalesPurchasePartyUiState
  } = feature;


  const readAccountCatalog = (...args) => typeof feature.readAccountCatalog === 'function'
    ? feature.readAccountCatalog(...args)
    : [];
  const resolveDefaultCashAccount = (...args) => typeof feature.resolveDefaultCashAccount === 'function'
    ? feature.resolveDefaultCashAccount(...args)
    : null;

  const readJsonStorageSafe = readJsonStorage;

  function normalizeSalesPurchaseStoredCalcMethod(value){
    return String(value || '').trim() === 'divide' ? 'divide' : 'multiply';
  }

  function buildSalesPurchaseFormStateFromRecord(actionId, record){
    const safeRecord = normalizeSalesPurchaseRecord(record);
    const nextState = createDefaultFormState(actionId);
    const effectiveActionId = resolveSalesPurchaseEffectiveActionId(actionId, nextState);
    nextState.purchaseCalcMethod = normalizeSalesPurchaseStoredCalcMethod(safeRecord.purchaseCalcMethod || safeRecord.calcMethod || nextState.purchaseCalcMethod);

    if(effectiveActionId === 'sale'){
      nextState.buyCurrencyCode = normalizeCurrencyCode(safeRecord.settlementCurrencyCode);
      nextState.sellCurrencyCode = normalizeCurrencyCode(safeRecord.tradeCurrencyCode);
    }else{
      nextState.buyCurrencyCode = normalizeCurrencyCode(safeRecord.tradeCurrencyCode);
      nextState.sellCurrencyCode = normalizeCurrencyCode(safeRecord.settlementCurrencyCode);
    }

    nextState.cashAccountNo = toSafeText(safeRecord.cashAccountNo);
    nextState.voucherDate = salesPurchaseNormalizeDateInputValue(safeRecord.date || nextState.voucherDate);
    nextState.amountText = sanitizeNumericInput(safeRecord.amountText || '');
    nextState.counterpartText = sanitizeNumericInput(safeRecord.counterpartAmountText || '');
    nextState.lastEditedAmountField = normalizeSalesPurchaseEditedAmountField(safeRecord.amountEntrySide);
    nextState.rateMode = String(safeRecord.rateMode || '').trim() === 'manual' ? 'manual' : 'auto';
    nextState.manualRateText = sanitizeNumericInput(safeRecord.manualRateText || '');
    nextState.notes = toSafeText(safeRecord.notes);
    nextState.invoiceSummary = toSafeText(safeRecord.invoiceSummary || safeRecord.summary);
    nextState.counterpartyName = toSafeText(safeRecord.counterpartyName);
    nextState.documentNumber = toSafeText(safeRecord.documentNumber || safeRecord.documentNo);
    nextState.alertIssues = [];
    nextState.openPickerKey = null;
    nextState.datePickerOpen = false;
    nextState.datePickerView = 'days';
    nextState.datePickerMonthCursor = salesPurchaseResolveMonthCursor(nextState.voucherDate, nextState.voucherDate.slice(0, 7));
    nextState.lastChangedPickerKey = '';
    const navigator = ensureSalesPurchaseNavigatorState(nextState);
    navigator.currentRecordId = toSafeText(safeRecord.id);
    navigator.loadedRecordSnapshot = buildSalesPurchaseNavigatorLoadedSnapshot(safeRecord);

    const lifecycleKey = salesPurchaseLifecycleActionKey(safeRecord);
    if(lifecycleKey === 'reversed'){
      nextState.inlineNotice = { message: 'تم عكس وإلغاء هذه العملية.', tone: 'danger' };
    }else if(lifecycleKey === 'updated'){
      nextState.inlineNotice = { message: 'تم تعديل هذه العملية.', tone: 'success' };
    }else{
      nextState.inlineNotice = null;
    }
    return nextState;
  }

  function normalizeSalesPurchaseSearchText(value){
    const normalized = typeof normalizeTypeaheadText === 'function'
      ? normalizeTypeaheadText(value)
      : String(value ?? '');
    return normalized.replace(/\s+/g, ' ').trim();
  }

  function salesPurchaseTodayInputValue(){
    return typeof dateSystem.todayIsoDate === 'function' ? dateSystem.todayIsoDate() : salesPurchaseToIsoDate(new Date());
  }

  function salesPurchaseParseIsoDate(value){
    if(typeof dateSystem.parseIsoDate === 'function') return dateSystem.parseIsoDate(value);
    const safeValue = String(value || '').trim();
    const match = safeValue.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if(!match) return null;
    const year = Number(match[1]);
    const month = Number(match[2]);
    const day = Number(match[3]);
    if(!Number.isInteger(year) || !Number.isInteger(month) || !Number.isInteger(day)) return null;
    const date = new Date(year, month - 1, day);
    if(
      Number.isNaN(date.getTime())
      || date.getFullYear() != year
      || date.getMonth() !== (month - 1)
      || date.getDate() != day
    ) return null;
    return date;
  }

  function salesPurchaseToIsoDate(date){
    if(typeof dateSystem.toIsoDate === 'function') return dateSystem.toIsoDate(date);
    if(!(date instanceof Date) || Number.isNaN(date.getTime())) return salesPurchaseTodayInputValue();
    return `${String(date.getFullYear()).padStart(4, '0')}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  }

  function salesPurchaseNormalizeDateInputValue(value){
    return typeof dateSystem.normalizeIsoDate === 'function' ? dateSystem.normalizeIsoDate(value) : (salesPurchaseParseIsoDate(value) ? String(value || '').trim() : salesPurchaseTodayInputValue());
  }

  function salesPurchaseToMonthCursor(date){
    if(typeof dateSystem.toMonthCursor === 'function') return dateSystem.toMonthCursor(date);
    if(!(date instanceof Date) || Number.isNaN(date.getTime())) return salesPurchaseTodayInputValue().slice(0, 7);
    return `${String(date.getFullYear()).padStart(4, '0')}-${String(date.getMonth() + 1).padStart(2, '0')}`;
  }

  function salesPurchaseParseMonthCursor(value){
    if(typeof dateSystem.parseMonthCursor === 'function') return dateSystem.parseMonthCursor(value);
    const safeValue = String(value || '').trim();
    const match = safeValue.match(/^(\d{4})-(\d{2})$/);
    if(!match) return null;
    const year = Number(match[1]);
    const month = Number(match[2]);
    if(!Number.isInteger(year) || !Number.isInteger(month) || month < 1 || month > 12) return null;
    return { year, monthIndex: month - 1 };
  }

  function salesPurchaseNormalizeDatePickerView(value){
    return typeof dateSystem.normalizePickerView === 'function' ? dateSystem.normalizePickerView(value) : (String(value || '').trim() === 'month-year' ? 'month-year' : 'days');
  }

  function salesPurchaseResolveMonthCursor(selectedValue, currentCursor = ''){
    return typeof dateSystem.resolveMonthCursor === 'function'
      ? dateSystem.resolveMonthCursor(selectedValue, currentCursor)
      : (salesPurchaseParseMonthCursor(currentCursor) ? currentCursor : salesPurchaseToMonthCursor(salesPurchaseParseIsoDate(selectedValue) || new Date()));
  }

  function salesPurchaseShiftMonthCursor(monthCursor, offset = 0){
    if(typeof dateSystem.shiftMonthCursor === 'function') return dateSystem.shiftMonthCursor(monthCursor, offset);
    const parsed = salesPurchaseParseMonthCursor(monthCursor) || salesPurchaseParseMonthCursor(salesPurchaseToMonthCursor(new Date()));
    const date = new Date(parsed.year, parsed.monthIndex + Number(offset || 0), 1);
    return salesPurchaseToMonthCursor(date);
  }

  function salesPurchaseFormatDateTriggerValue(value){
    const parts = typeof dateSystem.getDisplayParts === 'function'
      ? dateSystem.getDisplayParts(value)
      : { day: '--', month: '--', year: '----' };
    return `
      <span class="entries-voucher-date__trigger-date" aria-hidden="true">
        <span class="entries-voucher-date__trigger-part entries-voucher-date__trigger-part--day">${escapeHtml(parts.day)}</span>
        <span class="entries-voucher-date__trigger-sep" aria-hidden="true">/</span>
        <span class="entries-voucher-date__trigger-part entries-voucher-date__trigger-part--month">${escapeHtml(parts.month)}</span>
        <span class="entries-voucher-date__trigger-sep" aria-hidden="true">/</span>
        <span class="entries-voucher-date__trigger-part entries-voucher-date__trigger-part--year">${escapeHtml(parts.year)}</span>
      </span>
    `;
  }

  function salesPurchaseGetManualDateParts(value){
    const safeValue = salesPurchaseNormalizeDateInputValue(value);
    const parsed = salesPurchaseParseIsoDate(safeValue);
    if(!parsed) return { day:'', month:'', year:'' };
    return {
      day:String(parsed.getDate()).padStart(2, '0'),
      month:String(parsed.getMonth() + 1).padStart(2, '0'),
      year:String(parsed.getFullYear())
    };
  }

  function salesPurchaseFormatMonthLabel(monthCursor){
    return typeof dateSystem.formatMonthLabel === 'function'
      ? dateSystem.formatMonthLabel(monthCursor, DATE_PICKER_MONTH_NAMES)
      : String(monthCursor || '').trim();
  }

  function salesPurchaseBuildDateCells(monthCursor, selectedValue){
    return typeof dateSystem.buildCalendarCells === 'function' ? dateSystem.buildCalendarCells(monthCursor, selectedValue) : [];
  }

  function salesPurchaseBuildMonthChoices(monthCursor){
    return typeof dateSystem.buildMonthChoices === 'function' ? dateSystem.buildMonthChoices(monthCursor, DATE_PICKER_MONTH_NAMES) : [];
  }

  function renderSalesPurchaseDateDayButton(cell){
    const classes = [
      'entries-voucher-date__day',
      cell.outsideMonth ? 'is-outside' : '',
      cell.isToday ? 'is-today' : '',
      cell.isSelected ? 'is-selected' : ''
    ].filter(Boolean).join(' ');
    return `
      <button class="${classes}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="grid" data-sales-purchase-date-action="select-day" data-sales-purchase-date-value="${escapeHtml(cell.value)}" aria-pressed="${cell.isSelected ? 'true' : 'false'}" aria-label="اختيار التاريخ ${escapeHtml(cell.value)}">
        <span dir="ltr">${escapeHtml(cell.label)}</span>
      </button>
    `;
  }

  function renderSalesPurchaseDateMonthButton(monthChoice){
    const classes = ['entries-voucher-date__month', monthChoice.isActive ? 'is-active' : ''].filter(Boolean).join(' ');
    return `
      <button class="${classes}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="grid" data-sales-purchase-date-action="pick-month" data-sales-purchase-date-month="${escapeHtml(monthChoice.monthCursor)}" aria-pressed="${monthChoice.isActive ? 'true' : 'false'}" aria-label="اختيار شهر ${escapeHtml(monthChoice.label)}">
        <span>${escapeHtml(monthChoice.label)}</span>
      </button>
    `;
  }

  function normalizeSalesPurchaseAccountOption(account){
    const value = toSafeText(account?.accountNo);
    const label = toSafeText(account?.name, value) || value;
    if(!value && !label) return null;
    return {
      value,
      label,
      meta: value,
      ariaLabel: value ? `${label} ${value}` : label
    };
  }

  function resolveSalesPurchaseAccountPickerData(options, selectedValue){
    const normalizedOptions = (Array.isArray(options) ? options : []).map((option) => normalizeSalesPurchaseAccountOption(option)).filter(Boolean);
    const activeOption = normalizedOptions.find((option) => option.value === String(selectedValue || '').trim()) || null;
    return {
      options: normalizedOptions,
      activeOption,
      resolvedValue: activeOption ? activeOption.value : ''
    };
  }

  function renderSalesPurchaseChoiceValue(option, { placeholder = '' } = {}){
    if(!option){
      return `<span class="entries-voucher-choice-picker__placeholder">${escapeHtml(placeholder || '')}</span>`;
    }

    return `
      <span class="entries-voucher-choice-picker__value-layout">
        <span class="entries-voucher-choice-picker__text">${escapeHtml(option.label)}</span>
        ${option.meta ? `<span class="entries-voucher-choice-picker__meta" dir="ltr">${wrapControlTextMarkup(escapeHtml(option.meta), 'taif-control-text--ltr')}</span>` : ''}
      </span>
    `;
  }

  function renderSalesPurchaseCashAccountField(model, options = {}){
    const showLabelColon = options.showLabelColon !== false;
    const pickerData = resolveSalesPurchaseAccountPickerData(model.cashAccountOptions, model.cashAccountNo);
    const isOpen = model.formState.openPickerKey === 'cash-account';
    const triggerValueClass = pickerData.activeOption ? 'entries-voucher-choice-picker__value' : 'entries-voucher-choice-picker__value is-placeholder';
    const listContent = pickerData.options.length
      ? pickerData.options.map((option) => {
          const isActive = option.value === pickerData.resolvedValue;
          return `
            <button class="entries-voucher-choice-popover__option${isActive ? ' is-active' : ''}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-taif-inline-picker-option="true" role="option" data-sales-purchase-action="select-cash-account" data-sales-purchase-account-option="${escapeHtml(option.value)}" aria-selected="${isActive ? 'true' : 'false'}" aria-label="اختيار ${escapeHtml(option.ariaLabel || option.label || '')}">
              <span class="entries-voucher-choice-popover__label has-meta" data-taif-dropdown-label="true">${renderSalesPurchaseChoiceValue(option)}</span>
              <span class="entries-voucher-choice-popover__check" aria-hidden="true">${createChoicePickerIcon('check')}</span>
            </button>
          `;
        }).join('')
      : '<div class="entries-voucher-choice-popover__empty">لا يوجد حسابات متاحة.</div>';

    return `
      <div class="entries-voucher-rail__card sales-purchase-top-field sales-purchase-top-field--cash">
        <span class="entries-voucher-rail__title sales-purchase-top-field__inline-label">الصندوق النقدي${showLabelColon ? " :" : ""}</span>
        <div class="entries-voucher-choice-picker${isOpen ? ' is-open' : ''}" data-sales-purchase-picker-host="cash-account" data-taif-inline-picker-host="true">
          <input class="entries-voucher-choice-picker__value-input" type="hidden" value="${escapeHtml(pickerData.resolvedValue)}">
          <button class="entries-voucher-field__control entries-voucher-rail__control entries-voucher-choice-picker__trigger sales-purchase-top-field__trigger" type="button" data-taif-picker-trigger="true" data-sales-purchase-action="toggle-picker" data-sales-purchase-picker-key="cash-account" data-field="cashAccountNo" aria-label="الصندوق النقدي" aria-haspopup="listbox" aria-expanded="${isOpen ? 'true' : 'false'}">
            <span class="${triggerValueClass}">${renderSalesPurchaseChoiceValue(pickerData.activeOption, { placeholder: 'اختر الصندوق النقدي' })}</span>
            <span class="entries-voucher-choice-picker__icon" aria-hidden="true">${createChoicePickerIcon('chevronDown')}</span>
          </button>
          <div class="entries-voucher-choice-popover sales-purchase-top-field__popover" data-taif-dropdown-popup="true" data-taif-dropdown-layout="list" data-taif-inline-picker="true" role="listbox" aria-label="الصندوق النقدي"${isOpen ? '' : ' hidden'}>${listContent}</div>
        </div>
      </div>
    `;
  }

  function renderSalesPurchaseDateField(model, options = {}){
    const showLabelColon = options.showLabelColon !== false;
    const selectedValue = salesPurchaseNormalizeDateInputValue(model.voucherDate);
    const isOpen = !!model.formState.datePickerOpen;
    const view = salesPurchaseNormalizeDatePickerView(model.formState.datePickerView);
    const monthCursor = salesPurchaseResolveMonthCursor(selectedValue, model.formState.datePickerMonthCursor);
    const cells = salesPurchaseBuildDateCells(monthCursor, selectedValue);
    const monthChoices = salesPurchaseBuildMonthChoices(monthCursor);
    const todayValue = salesPurchaseTodayInputValue();
    const currentMonth = salesPurchaseParseMonthCursor(monthCursor) || salesPurchaseParseMonthCursor(salesPurchaseToMonthCursor(new Date()));
    const currentYearLabel = String(currentMonth?.year || new Date().getFullYear());
    const dateParts = salesPurchaseGetManualDateParts(selectedValue);

    return `
      <div class="entries-voucher-rail__card entries-voucher-rail__card--date sales-purchase-top-field sales-purchase-top-field--date">
        <span class="entries-voucher-rail__title sales-purchase-top-field__inline-label">التاريخ${showLabelColon ? " :" : ""}</span>
        <div class="entries-voucher-date${isOpen ? ' is-open' : ''}" data-sales-purchase-date-picker="true">
          <input class="entries-voucher-date__native" type="hidden" value="${escapeHtml(selectedValue)}">
          <div class="entries-voucher-field__control entries-voucher-rail__control entries-voucher-date__trigger sales-purchase-top-field__date-trigger sales-purchase-main-date-shell" aria-label="التاريخ">
            <div class="entries-voucher-date__manual sales-purchase-main-date-manual" data-sales-purchase-main-date-manual="true">
              <input class="entries-voucher-date__manual-input entries-voucher-date__manual-input--day sales-purchase-main-date-part" type="text" value="${escapeHtml(dateParts.day)}" placeholder="يوم" inputmode="numeric" autocomplete="off" dir="ltr" data-taif-flow-item="true" data-sales-purchase-date-part="day" aria-label="يوم التاريخ">
              <span class="entries-voucher-date__manual-sep" aria-hidden="true">/</span>
              <input class="entries-voucher-date__manual-input entries-voucher-date__manual-input--month sales-purchase-main-date-part" type="text" value="${escapeHtml(dateParts.month)}" placeholder="شهر" inputmode="numeric" autocomplete="off" dir="ltr" data-taif-flow-item="true" data-sales-purchase-date-part="month" aria-label="شهر التاريخ">
              <span class="entries-voucher-date__manual-sep" aria-hidden="true">/</span>
              <input class="entries-voucher-date__manual-input entries-voucher-date__manual-input--year sales-purchase-main-date-part" type="text" value="${escapeHtml(dateParts.year)}" placeholder="سنة" inputmode="numeric" autocomplete="off" dir="ltr" data-taif-flow-item="true" data-sales-purchase-date-part="year" aria-label="سنة التاريخ">
            </div>
            <button class="entries-voucher-date__trigger-icon-btn sales-purchase-main-date-icon-btn" type="button" data-taif-picker-trigger="true" data-taif-flow-item="true" data-sales-purchase-date-action="toggle" aria-label="فتح لوحة التاريخ" aria-haspopup="dialog" aria-expanded="${isOpen ? 'true' : 'false'}">
              <span class="entries-voucher-date__trigger-icon" aria-hidden="true">${DATE_PICKER_ICON_MARKUP}</span>
            </button>
          </div>
          ${isOpen ? `
            <div class="entries-voucher-date__popover" data-taif-dropdown-popup="true" data-taif-dropdown-layout="calendar" role="dialog" aria-label="اختيار التاريخ">
              ${view === 'month-year' ? `
                <div class="entries-voucher-date__header entries-voucher-date__header--month-year">
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-date-action="prev-year" data-sales-purchase-date-month="${escapeHtml(monthCursor)}" aria-label="السنة السابقة">${DATE_PICKER_CHEVRON_NEXT_MARKUP}</button>
                  <button class="entries-voucher-date__heading-trigger entries-voucher-date__heading-trigger--current" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-date-action="toggle-view" data-sales-purchase-date-view="days" data-sales-purchase-date-month="${escapeHtml(monthCursor)}" aria-label="الرجوع إلى أيام الشهر">
                    <span dir="ltr">${escapeHtml(currentYearLabel)}</span>
                  </button>
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-date-action="next-year" data-sales-purchase-date-month="${escapeHtml(monthCursor)}" aria-label="السنة التالية">${DATE_PICKER_CHEVRON_PREV_MARKUP}</button>
                </div>
                <div class="entries-voucher-date__month-panel">
                  <div class="entries-voucher-date__month-grid">
                    ${monthChoices.map((monthChoice) => renderSalesPurchaseDateMonthButton(monthChoice)).join('')}
                  </div>
                </div>
                <div class="entries-voucher-date__footer">
                  <button class="entries-voucher-date__footer-btn" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-date-action="toggle-view" data-sales-purchase-date-view="days" data-sales-purchase-date-month="${escapeHtml(monthCursor)}">رجوع للتقويم</button>
                  <button class="entries-voucher-date__footer-btn entries-voucher-date__footer-btn--ghost" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-date-action="close">إغلاق</button>
                </div>
              ` : `
                <div class="entries-voucher-date__header">
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-date-action="prev-month" data-sales-purchase-date-month="${escapeHtml(monthCursor)}" aria-label="الشهر السابق">${DATE_PICKER_CHEVRON_NEXT_MARKUP}</button>
                  <button class="entries-voucher-date__heading-trigger" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-date-action="toggle-view" data-sales-purchase-date-view="month-year" data-sales-purchase-date-month="${escapeHtml(monthCursor)}" aria-label="تغيير الشهر أو السنة">${escapeHtml(salesPurchaseFormatMonthLabel(monthCursor))}</button>
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-date-action="next-month" data-sales-purchase-date-month="${escapeHtml(monthCursor)}" aria-label="الشهر التالي">${DATE_PICKER_CHEVRON_PREV_MARKUP}</button>
                </div>
                <div class="entries-voucher-date__weekdays" aria-hidden="true">
                  ${DATE_PICKER_WEEKDAY_LABELS.map((label) => `<span>${escapeHtml(label)}</span>`).join('')}
                </div>
                <div class="entries-voucher-date__grid">
                  ${cells.map((cell) => renderSalesPurchaseDateDayButton(cell)).join('')}
                </div>
                <div class="entries-voucher-date__footer">
                  <button class="entries-voucher-date__footer-btn" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-date-action="today" data-sales-purchase-date-value="${escapeHtml(todayValue)}">اليوم</button>
                  <button class="entries-voucher-date__footer-btn entries-voucher-date__footer-btn--ghost" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-date-action="clear">مسح</button>
                  <button class="entries-voucher-date__footer-btn entries-voucher-date__footer-btn--ghost" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-date-action="close">إغلاق</button>
                </div>
              `}
            </div>
          ` : ''}
        </div>
      </div>
    `;
  }

  function salesPurchaseTypeLabel(type){
    return String(type || '').trim() === 'sale' ? 'مبيع' : 'شراء';
  }

  function isSalesPurchaseRecordReversed(recordOrStatus){
    const status = typeof recordOrStatus === 'string'
      ? String(recordOrStatus || '').trim()
      : String(recordOrStatus?.status || '').trim();
    return status === 'reversed';
  }

  function salesPurchaseStatusLabel(status){
    const safeStatus = String(status || '').trim();
    if(isSalesPurchaseRecordReversed(safeStatus)) return 'ملغاة';
    return safeStatus === 'posted' ? 'منفذ' : 'مسودة';
  }

  function salesPurchaseLifecycleActionKey(record){
    const safeRecord = record && typeof record === 'object' ? record : {};
    if(isSalesPurchaseRecordReversed(safeRecord)) return 'reversed';
    const lastAction = toSafeText(safeRecord.lastAction).toLowerCase();
    if(lastAction === 'updated' || Math.max(0, Number(safeRecord.revisionCount) || 0) > 0) return 'updated';
    return 'created';
  }

  function salesPurchaseLifecycleActionLabel(record){
    const actionKey = salesPurchaseLifecycleActionKey(record);
    if(actionKey === 'reversed') return 'ملغاة';
    if(actionKey === 'updated') return 'معدلة';
    return 'منشأة';
  }

  function buildSalesPurchaseOperationLabel(operationKind, revisionCount = 0){
    const safeKind = String(operationKind || '').trim().toLowerCase();
    if(safeKind === 'updated'){
      const normalizedRevision = Math.max(1, Number(revisionCount) || 1);
      return `تعديل الفاتورة · نسخة ${normalizedRevision}`;
    }
    if(safeKind === 'reversed') return 'إلغاء / عكس القيد';
    return 'إنشاء الفاتورة';
  }

  function createSalesPurchaseEmptyState(){
    return {
      version: 1,
      updatedAt: Date.now(),
      sequence: 0,
      records: []
    };
  }

  function dedupeSalesPurchaseStringList(values, normalizer){
    const normalizeValue = typeof normalizer === 'function'
      ? normalizer
      : ((value) => toSafeText(value));
    const seen = new Set();
    return (Array.isArray(values) ? values : []).reduce((result, value) => {
      const normalized = normalizeValue(value);
      if(!normalized || seen.has(normalized)) return result;
      seen.add(normalized);
      result.push(normalized);
      return result;
    }, []);
  }

  function normalizeSalesPurchaseRecord(record){
    const safeRecord = record && typeof record === 'object' ? record : {};
    const type = String(safeRecord.type || '').trim() === 'sale' ? 'sale' : 'purchase';
    const amountValue = Math.max(0, toNumber(safeRecord.amountValue, 0));
    const counterpartAmountValue = Math.max(0, toNumber(safeRecord.counterpartAmountValue, 0));
    const rateValue = Math.max(0, toNumber(safeRecord.rateValue, 0));
    const rateMode = String(safeRecord.rateMode || '').trim() === 'manual' ? 'manual' : 'auto';
    const manualRateText = sanitizeNumericInput(safeRecord.manualRateText || (rateMode === 'manual' ? safeRecord.rateText : ''));
    const createdAtValue = Number(safeRecord.createdAt);
    const updatedAtValue = Number(safeRecord.updatedAt);
    const sequenceValue = Math.max(0, Number(safeRecord.sequence) || 0);
    const fallbackDate = salesPurchaseTodayInputValue();
    const revisionCount = Math.max(0, Number(safeRecord.revisionCount) || 0);
    const status = isSalesPurchaseRecordReversed(safeRecord.status)
      ? 'reversed'
      : (String(safeRecord.status || '').trim() === 'draft' ? 'draft' : 'posted');
    const lastActionRaw = toSafeText(safeRecord.lastAction).toLowerCase();
    const lastAction = status === 'reversed'
      ? 'reversed'
      : (lastActionRaw === 'updated'
          ? 'updated'
          : (lastActionRaw === 'created' ? 'created' : (revisionCount > 0 ? 'updated' : 'created')));
    const createdAt = Number.isFinite(createdAtValue) && createdAtValue > 0 ? createdAtValue : Date.now();
    const ownerActionId = resolveSalesPurchaseRecordOwnerActionId(safeRecord);
    return {
      id: toSafeText(safeRecord.id) || `sp-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      sequence: sequenceValue,
      number: toSafeText(safeRecord.number) || buildSalesPurchaseRecordNumber(Math.max(1, sequenceValue || 1), type),
      type,
      ownerActionId,
      status,
      date: salesPurchaseNormalizeDateInputValue(safeRecord.date || fallbackDate),
      cashAccountNo: toSafeText(safeRecord.cashAccountNo),
      cashAccountName: toSafeText(safeRecord.cashAccountName),
      tradeCurrencyCode: normalizeCurrencyCode(safeRecord.tradeCurrencyCode),
      tradeCurrencyName: toSafeText(safeRecord.tradeCurrencyName),
      settlementCurrencyCode: normalizeCurrencyCode(safeRecord.settlementCurrencyCode),
      settlementCurrencyName: toSafeText(safeRecord.settlementCurrencyName),
      amountValue,
      counterpartAmountValue,
      rateValue,
      amountText: toSafeText(safeRecord.amountText),
      counterpartAmountText: toSafeText(safeRecord.counterpartAmountText),
      rateText: toSafeText(safeRecord.rateText),
      rateMode,
      manualRateText,
      amountEntrySide: normalizeSalesPurchaseEditedAmountField(safeRecord.amountEntrySide),
      notes: toSafeText(safeRecord.notes),
      invoiceSummary: toSafeText(safeRecord.invoiceSummary || safeRecord.summary),
      counterpartyName: toSafeText(safeRecord.counterpartyName || safeRecord.partyName || safeRecord.beneficiaryName),
      documentNumber: toSafeText(safeRecord.documentNumber || safeRecord.documentNo),
      purchaseCalcMethod: normalizeSalesPurchaseStoredCalcMethod(safeRecord.purchaseCalcMethod || safeRecord.calcMethod),
      linkedEntryRecordIds: dedupeSalesPurchaseStringList(safeRecord.linkedEntryRecordIds, (value) => toSafeText(value)),
      linkedEntryVoucherNumbers: dedupeSalesPurchaseStringList(safeRecord.linkedEntryVoucherNumbers, (value) => toSafeText(value).toUpperCase()),
      accountingBridgeAccountNo: toSafeText(safeRecord.accountingBridgeAccountNo),
      accountingBridgeAccountName: toSafeText(safeRecord.accountingBridgeAccountName),
      revisionCount,
      lastAction,
      reversedAt: Number(safeRecord.reversedAt) > 0 ? Number(safeRecord.reversedAt) : 0,
      createdAt,
      updatedAt: Number.isFinite(updatedAtValue) && updatedAtValue > 0 ? updatedAtValue : createdAt
    };
  }


  function normalizeSalesPurchaseState(stateInput){
    const fallbackState = createSalesPurchaseEmptyState();
    const safeState = stateInput && typeof stateInput === 'object' ? stateInput : fallbackState;
    const records = (Array.isArray(safeState.records) ? safeState.records : [])
      .map((record) => normalizeSalesPurchaseRecord(record))
      .sort((left, right) => {
        const leftSequence = Number(left.sequence) || 0;
        const rightSequence = Number(right.sequence) || 0;
        if(leftSequence !== rightSequence) return rightSequence - leftSequence;
        return (Number(right.createdAt) || 0) - (Number(left.createdAt) || 0);
      });
    const maxSequence = records.reduce((max, record) => Math.max(max, Number(record.sequence) || 0), 0);
    const sequence = Math.max(maxSequence, Number(safeState.sequence) || 0, 0);

    return {
      version: 1,
      updatedAt: Date.now(),
      sequence,
      records
    };
  }

  function readSalesPurchaseState(){
    return normalizeSalesPurchaseState(readJsonStorageSafe(SALES_PURCHASE_STORAGE_KEY, createSalesPurchaseEmptyState()));
  }

  function writeSalesPurchaseState(nextState, { notify = true } = {}){
    const normalized = normalizeSalesPurchaseState(nextState);
    const persisted = typeof persistJsonState === 'function'
      ? persistJsonState(SALES_PURCHASE_STORAGE_KEY, normalized, normalizeSalesPurchaseState)
      : normalized;
    const safeState = normalizeSalesPurchaseState(persisted);
    if(notify){
      const events = TAIF.core && TAIF.core.events;
      if(events && typeof events.emitDomainUpdate === 'function'){
        events.emitDomainUpdate('sales-purchase', { state: safeState }, { source:'sales-purchase-state' });
      }else if(typeof window !== 'undefined' && typeof window.dispatchEvent === 'function'){
        try{
          window.dispatchEvent(new CustomEvent(SALES_PURCHASE_UPDATED_EVENT, { detail: { state: safeState } }));
        }catch{}
      }
    }
    return safeState;
  }

  function buildSalesPurchaseRecordNumber(sequence, type){
    const safeSequence = Math.max(1, Number(sequence) || 1);
    const prefix = String(type || '').trim() === 'sale' ? 'SAL' : 'PUR';
    return `${prefix}-${String(safeSequence).padStart(5, '0')}`;
  }

  function createSalesPurchaseRecord(type, model, sequence, options = {}){
    const safeType = String(type || '').trim() === 'sale' ? 'sale' : 'purchase';
    const safeSequence = Math.max(1, Number(sequence) || 1);
    const accounting = options && typeof options === 'object' ? options.accounting : null;
    const ownerActionId = normalizeSalesPurchaseActionOwnerId(options?.ownerActionId) || safeType;
    return normalizeSalesPurchaseRecord({
      id: `sp-${safeType}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      sequence: safeSequence,
      number: buildSalesPurchaseRecordNumber(safeSequence, safeType),
      type: safeType,
      ownerActionId,
      status: 'posted',
      date: model?.voucherDate || salesPurchaseTodayInputValue(),
      cashAccountNo: model?.cashAccountNo || '',
      cashAccountName: model?.cashAccount?.name || '',
      tradeCurrencyCode: model?.tradeCurrency?.code || '',
      tradeCurrencyName: model?.tradeCurrency?.name || '',
      settlementCurrencyCode: model?.settlementCurrency?.code || '',
      settlementCurrencyName: model?.settlementCurrency?.name || '',
      amountValue: Math.max(0, Number(model?.amountValue) || 0),
      counterpartAmountValue: Math.max(0, Number(model?.counterpartAmountValue) || 0),
      rateValue: Math.max(0, Number(model?.activeRateValue) || 0),
      amountText: model?.amountDisplayText || model?.amountText || '0',
      counterpartAmountText: model?.counterpartAmountText || '0',
      rateText: model?.activeRateText || '—',
      rateMode: String(model?.formState?.rateMode || '').trim() === 'manual' ? 'manual' : 'auto',
      manualRateText: sanitizeNumericInput(model?.formState?.manualRateText || ''),
      amountEntrySide: normalizeSalesPurchaseEditedAmountField(model?.formState?.lastEditedAmountField),
      notes: toSafeText(model?.formState?.notes),
      invoiceSummary: toSafeText(model?.formState?.invoiceSummary),
      counterpartyName: toSafeText(model?.formState?.counterpartyName),
      documentNumber: toSafeText(model?.formState?.documentNumber || model?.formState?.documentNo),
      purchaseCalcMethod: normalizeSalesPurchaseStoredCalcMethod(model?.formState?.purchaseCalcMethod),
      linkedEntryRecordIds: Array.isArray(accounting?.recordIds) ? accounting.recordIds : [],
      linkedEntryVoucherNumbers: Array.isArray(accounting?.voucherNumbers) ? accounting.voucherNumbers : [],
      accountingBridgeAccountNo: accounting?.bridgeAccount?.accountNo || '',
      accountingBridgeAccountName: accounting?.bridgeAccount?.name || '',
      revisionCount: 0,
      lastAction: 'created',
      createdAt: Date.now(),
      updatedAt: Date.now()
    });
  }

  function appendSalesPurchaseRecord(type, model, options = {}){
    const state = options?.preloadedState && typeof options.preloadedState === 'object'
      ? normalizeSalesPurchaseState(options.preloadedState)
      : readSalesPurchaseState();
    const nextSequence = Math.max(
      0,
      Number(state.sequence) || 0,
      Number(options?.sequence) ? Number(options.sequence) - 1 : 0
    ) + 1;
    const record = createSalesPurchaseRecord(type, model, nextSequence, options);
    const nextState = {
      ...state,
      sequence: nextSequence,
      records: [record, ...(Array.isArray(state.records) ? state.records : [])]
    };
    return {
      state: writeSalesPurchaseState(nextState),
      record
    };
  }

  function buildSalesPurchaseRecordSearchText(record){
    const safeRecord = record && typeof record === 'object' ? record : {};
    return normalizeSalesPurchaseSearchText([
      safeRecord.number,
      safeRecord.date,
      salesPurchaseTypeLabel(safeRecord.type),
      safeRecord.cashAccountName,
      safeRecord.cashAccountNo,
      safeRecord.tradeCurrencyName,
      safeRecord.tradeCurrencyCode,
      safeRecord.settlementCurrencyName,
      safeRecord.settlementCurrencyCode,
      safeRecord.amountText,
      safeRecord.counterpartAmountText,
      safeRecord.rateText,
      safeRecord.notes,
      safeRecord.invoiceSummary,
      safeRecord.counterpartyName,
      safeRecord.documentNumber,
      salesPurchaseStatusLabel(safeRecord.status),
      salesPurchaseLifecycleActionLabel(safeRecord)
    ].filter(Boolean).join(' '));
  }

  function filterSalesPurchaseRecords(records, query = runtime.searchQuery){
    const safeRecords = Array.isArray(records) ? records : [];
    const normalizedQuery = normalizeSalesPurchaseSearchText(query);
    if(!normalizedQuery) return safeRecords;
    return safeRecords.filter((record) => buildSalesPurchaseRecordSearchText(record).includes(normalizedQuery));
  }
  function getCurrencyFeature(){
    const feature = TAIF && TAIF.currencyDomain;
    if(!feature || typeof feature !== 'object') return null;
    const required = ['readState', 'computeRows', 'getCounterpartOptions', 'getCounterpartCurrencyFromState', 'formatManagementCellValue', 'createFlagImageMarkup', 'readOperationalQuote'];
    return required.every((key) => typeof feature[key] === 'function') ? feature : null;
  }

  function fallbackCurrencyOption(){
    return { code:'USD', name:'الدولار الأمريكي', flag:'us', decimals:0 };
  }

  function getCurrencySnapshot(){
    const feature = getCurrencyFeature();
    if(!feature){
      const fallbackCurrency = fallbackCurrencyOption();
      return {
        feature: null,
        state: null,
        rows: [{ code:'USD', name:'الدولار الأمريكي', flag:'us', displayBuy:1, displaySell:1, displayBuyText:'1', displaySellText:'1', currencyDecimals:0, counterpartDecimals:0 }],
        currencies: [fallbackCurrency],
        counterpart: fallbackCurrency,
        activeBook: { code:'MAIN', label:'السعر الرئيسي' }
      };
    }

    const state = feature.readState();
    const rows = Array.isArray(feature.computeRows(state)) ? feature.computeRows(state) : [];
    const currencies = Array.isArray(feature.getCounterpartOptions(state)) ? feature.getCounterpartOptions(state) : [];
    const counterpart = feature.getCounterpartCurrencyFromState(state) || currencies[0] || fallbackCurrencyOption();
    const activeBook = typeof feature.getActiveRateBook === 'function'
      ? (feature.getActiveRateBook(state) || { code:'MAIN', label:'السعر الرئيسي' })
      : { code:'MAIN', label:'السعر الرئيسي' };

    return { feature, state, rows, currencies, counterpart, activeBook };
  }

  function resolveDefaultCurrencyCode(snapshot){
    const currencies = Array.isArray(snapshot && snapshot.currencies) ? snapshot.currencies : [];
    const preferred = currencies.find((currency) => String(currency && currency.code || '').trim().toUpperCase() === 'USD');
    return String((preferred || currencies[0] || fallbackCurrencyOption()).code || 'USD').trim().toUpperCase();
  }


  function pickCurrencyCode(currencies, preferredCodes = [], excludedCodes = []){
    const list = Array.isArray(currencies) ? currencies : [];
    const excluded = new Set((Array.isArray(excludedCodes) ? excludedCodes : []).map((code) => normalizeCurrencyCode(code)).filter(Boolean));
    const normalizedPreferredCodes = Array.isArray(preferredCodes) ? preferredCodes : [];

    for(const preferredCode of normalizedPreferredCodes){
      const safePreferredCode = normalizeCurrencyCode(preferredCode);
      if(!safePreferredCode || excluded.has(safePreferredCode)) continue;
      const match = list.find((currency) => normalizeCurrencyCode(currency && currency.code) === safePreferredCode);
      if(match) return safePreferredCode;
    }

    const firstAvailable = list.find((currency) => {
      const safeCode = normalizeCurrencyCode(currency && currency.code);
      return safeCode && !excluded.has(safeCode);
    });

    return normalizeCurrencyCode(firstAvailable && firstAvailable.code);
  }

  function resolveCurrencyFromList(currencies, code){
    const safeCode = normalizeCurrencyCode(code);
    return (Array.isArray(currencies) ? currencies : []).find((currency) => normalizeCurrencyCode(currency && currency.code) === safeCode) || null;
  }

  function resolveTradeDefaults(snapshot, actionId){
    const currencies = Array.isArray(snapshot && snapshot.currencies) ? snapshot.currencies : [fallbackCurrencyOption()];
    const counterpartCode = normalizeCurrencyCode(snapshot && snapshot.counterpart && snapshot.counterpart.code);
    const usdCode = normalizeCurrencyCode(resolveDefaultCurrencyCode(snapshot));
    const firstTradeCode = pickCurrencyCode(currencies, [usdCode, counterpartCode], []) || counterpartCode || 'USD';
    const primaryTradeCode = pickCurrencyCode(currencies, [usdCode], [counterpartCode]) || firstTradeCode;
    const settlementCode = pickCurrencyCode(currencies, [counterpartCode, usdCode], [primaryTradeCode]) || primaryTradeCode;

    if(actionId === 'sale'){
      return {
        buyCurrencyCode: settlementCode,
        sellCurrencyCode: primaryTradeCode
      };
    }

    return {
      buyCurrencyCode: primaryTradeCode,
      sellCurrencyCode: settlementCode
    };
  }

  function resolveDistinctPairCodes(snapshot, actionId, formState){
    const currencies = Array.isArray(snapshot && snapshot.currencies) ? snapshot.currencies : [fallbackCurrencyOption()];
    const defaults = resolveTradeDefaults(snapshot, actionId);
    const counterpartCode = normalizeCurrencyCode(snapshot && snapshot.counterpart && snapshot.counterpart.code);
    const usdCode = normalizeCurrencyCode(resolveDefaultCurrencyCode(snapshot));

    let buyCurrencyCode = normalizeCurrencyCode(formState && formState.buyCurrencyCode) || defaults.buyCurrencyCode;
    let sellCurrencyCode = normalizeCurrencyCode(formState && formState.sellCurrencyCode) || defaults.sellCurrencyCode;

    if(!resolveCurrencyFromList(currencies, buyCurrencyCode)) buyCurrencyCode = defaults.buyCurrencyCode;
    if(!resolveCurrencyFromList(currencies, sellCurrencyCode)) sellCurrencyCode = defaults.sellCurrencyCode;

    if(!buyCurrencyCode) buyCurrencyCode = pickCurrencyCode(currencies, [defaults.buyCurrencyCode, usdCode, counterpartCode], []);
    if(!sellCurrencyCode) sellCurrencyCode = pickCurrencyCode(currencies, [defaults.sellCurrencyCode, counterpartCode, usdCode], [buyCurrencyCode]);

    if(buyCurrencyCode === sellCurrencyCode){
      const lastChangedPickerKey = String(formState && formState.lastChangedPickerKey || '').trim();

      if(lastChangedPickerKey === 'buy-card'){
        sellCurrencyCode = pickCurrencyCode(currencies, [defaults.sellCurrencyCode, counterpartCode, usdCode], [buyCurrencyCode]) || sellCurrencyCode;
      }else if(lastChangedPickerKey === 'sell-card'){
        buyCurrencyCode = pickCurrencyCode(currencies, [defaults.buyCurrencyCode, usdCode, counterpartCode], [sellCurrencyCode]) || buyCurrencyCode;
      }else{
        sellCurrencyCode = pickCurrencyCode(currencies, [defaults.sellCurrencyCode, counterpartCode, usdCode], [buyCurrencyCode]) || sellCurrencyCode;
        if(buyCurrencyCode === sellCurrencyCode){
          buyCurrencyCode = pickCurrencyCode(currencies, [defaults.buyCurrencyCode, usdCode, counterpartCode], [sellCurrencyCode]) || buyCurrencyCode;
        }
      }
    }

    return { buyCurrencyCode, sellCurrencyCode };
  }


  function buildFallbackOperationalQuote(snapshot, tradeCurrencyCode, settlementCurrencyCode){
    const rows = Array.isArray(snapshot && snapshot.rows) ? snapshot.rows : [];
    const counterpartCode = normalizeCurrencyCode(snapshot && snapshot.counterpart && snapshot.counterpart.code);
    const safeTradeCode = normalizeCurrencyCode(tradeCurrencyCode);
    const safeSettlementCode = normalizeCurrencyCode(settlementCurrencyCode);
    if(!safeTradeCode || !safeSettlementCode || safeSettlementCode !== counterpartCode) return null;
    const row = rows.find((item) => normalizeCurrencyCode(item && item.code) === safeTradeCode) || null;
    if(!row) return null;
    const bid = Number(row && row.displayBuy);
    const ask = Number(row && row.displaySell);
    if(!Number.isFinite(bid) || bid <= 0 || !Number.isFinite(ask) || ask <= 0) return null;
    return {
      bid,
      ask,
      bidText: String(row && row.displayBuyText || ''),
      askText: String(row && row.displaySellText || ''),
      derived: true,
      via: 'fallback'
    };
  }


  function createDefaultSalesPurchaseFormUiState(voucherDate){
    return {
      alertIssues: [],
      openPickerKey: null,
      datePickerOpen: false,
      datePickerView: 'days',
      datePickerMonthCursor: salesPurchaseNormalizeDateInputValue(voucherDate).slice(0, 7),
      lastChangedPickerKey: '',
      navigator: createDefaultSalesPurchaseNavigatorState()
    };
  }

  function createDefaultFormState(actionId){
    const voucherDate = salesPurchaseTodayInputValue();
    if(String(actionId || '').trim() === 'party'){
      return {
        counterpartyName: '',
        ...createDefaultSalesPurchaseFormUiState(voucherDate),
        partyDraft: normalizeSalesPurchasePartyDraft(null),
        partyUi: createDefaultSalesPurchasePartyUiState(voucherDate)
      };
    }
    const snapshot = getCurrencySnapshot();
    const defaults = resolveTradeDefaults(snapshot, actionId);
    const accounts = readAccountCatalog();
    const defaultCashAccount = resolveDefaultCashAccount(accounts);
    return {
      buyCurrencyCode: defaults.buyCurrencyCode,
      sellCurrencyCode: defaults.sellCurrencyCode,
      cashAccountNo: defaultCashAccount ? defaultCashAccount.accountNo : '',
      windowActionId: normalizeSalesPurchaseActionOwnerId(actionId) || '',
      voucherDate,
      amountText: '',
      counterpartText: '',
      lastEditedAmountField: 'amount',
      rateMode: 'auto',
      purchaseCalcMethod: 'multiply',
      manualRateText: '',
      notes: '',
      invoiceSummary: '',
      counterpartyName: '',
      documentNumber: '',
      ...createDefaultSalesPurchaseFormUiState(voucherDate)
    };
  }

  function normalizeCurrencyCode(value){
    return String(value || '').trim().toUpperCase();
  }

  function normalizeSalesPurchaseEditedAmountField(value){
    return String(value || '').trim() === 'counterpart' ? 'counterpart' : 'amount';
  }

  function sanitizeNumericInput(value){
    const feature = getCurrencyFeature();
    const raw = String(value ?? '');
    if(feature && typeof feature.normalizeStoredNumericText === 'function'){
      return feature.normalizeStoredNumericText(raw, { allowDecimal:true, allowNegative:false });
    }
    return raw.replace(/[^0-9.]/g, '').replace(/(\..*?)\./g, '$1');
  }

  function toNumber(value, fallback = 0){
    const feature = getCurrencyFeature();
    if(feature && typeof feature.toNumber === 'function') return feature.toNumber(value, fallback);
    const parsed = Number(String(value || '').replace(/,/g, ''));
    return Number.isFinite(parsed) ? parsed : fallback;
  }

  function formatNumericValue(value, { rawText = '', decimals = 0, mode = 'rate', fallback = '0' } = {}){
    const feature = getCurrencyFeature();
    const displayMode = String(mode || '').trim() || 'standard';
    const isRateMode = displayMode === 'rate';
    if(feature && typeof feature.formatCurrencyNumericDisplay === 'function'){
      return feature.formatCurrencyNumericDisplay(value, {
        rawText,
        decimals: isRateMode ? null : decimals,
        maxAutoDecimals: isRateMode ? 8 : 6,
        mode: displayMode,
        fallback,
        respectConfiguredDecimals: !isRateMode
      });
    }
    const number = Number(value);
    if(!Number.isFinite(number)) return fallback;
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: isRateMode ? 8 : 6
    }).format(number);
  }

  Object.assign(feature, {
    buildSalesPurchaseFormStateFromRecord,
    normalizeSalesPurchaseSearchText,
    salesPurchaseTodayInputValue,
    salesPurchaseParseIsoDate,
    salesPurchaseToIsoDate,
    salesPurchaseNormalizeDateInputValue,
    salesPurchaseToMonthCursor,
    salesPurchaseParseMonthCursor,
    salesPurchaseNormalizeDatePickerView,
    salesPurchaseResolveMonthCursor,
    salesPurchaseShiftMonthCursor,
    salesPurchaseFormatDateTriggerValue,
    salesPurchaseGetManualDateParts,
    salesPurchaseFormatMonthLabel,
    salesPurchaseBuildDateCells,
    salesPurchaseBuildMonthChoices,
    renderSalesPurchaseDateDayButton,
    renderSalesPurchaseDateMonthButton,
    normalizeSalesPurchaseAccountOption,
    resolveSalesPurchaseAccountPickerData,
    renderSalesPurchaseChoiceValue,
    renderSalesPurchaseCashAccountField,
    renderSalesPurchaseDateField,
    salesPurchaseTypeLabel,
    isSalesPurchaseRecordReversed,
    salesPurchaseStatusLabel,
    salesPurchaseLifecycleActionKey,
    salesPurchaseLifecycleActionLabel,
    buildSalesPurchaseOperationLabel,
    createSalesPurchaseEmptyState,
    dedupeSalesPurchaseStringList,
    normalizeSalesPurchaseRecord,
    normalizeSalesPurchaseState,
    readSalesPurchaseState,
    writeSalesPurchaseState,
    buildSalesPurchaseRecordNumber,
    createSalesPurchaseRecord,
    appendSalesPurchaseRecord,
    buildSalesPurchaseRecordSearchText,
    filterSalesPurchaseRecords,
    getCurrencyFeature,
    fallbackCurrencyOption,
    getCurrencySnapshot,
    resolveDefaultCurrencyCode,
    pickCurrencyCode,
    resolveCurrencyFromList,
    resolveTradeDefaults,
    resolveDistinctPairCodes,
    buildFallbackOperationalQuote,
    createDefaultFormState,
    normalizeCurrencyCode,
    normalizeSalesPurchaseEditedAmountField,
    sanitizeNumericInput,
    toNumber,
    formatNumericValue,
  });
})();
