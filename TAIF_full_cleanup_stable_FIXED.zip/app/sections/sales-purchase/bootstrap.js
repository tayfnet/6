(()=>{
  /*
   * TAIF Sales & Purchase bootstrap module.
   * Registers the purchase/sale renderers and exposes the stable public API
   * after the section services have been loaded in architectural order.
   */
  const TAIF = window.TAIF;
  const feature = TAIF.salesPurchaseFeature || (TAIF.salesPurchaseFeature = {});
  const {
    runtime,
    readSalesPurchaseState,
    writeSalesPurchaseState,
    openSalesPurchaseWindow,
    closeAllSalesPurchaseWindows,
    cleanupSalesPurchaseView,
    renderSalesPurchaseBoard,
    focusSalesPurchaseSourceRecord
  } = feature;

  TAIF.salesPurchaseInvoice = TAIF.salesPurchaseInvoice || {};
  TAIF.salesPurchaseInvoice.readState = readSalesPurchaseState;
  TAIF.salesPurchaseInvoice.writeState = writeSalesPurchaseState;
  TAIF.salesPurchaseInvoice.open = openSalesPurchaseWindow;
  TAIF.salesPurchaseInvoice.closeAll = closeAllSalesPurchaseWindows;
  TAIF.salesPurchaseInvoice.cleanup = cleanupSalesPurchaseView;

  const VIEW_ACTION_MAP = Object.freeze({
    'sales-purchase-invoice': 'purchase',
    'sales-purchase-sale': 'sale'
  });

  Object.entries(VIEW_ACTION_MAP).forEach(([viewId, actionId]) => {
    TAIF.registerViewCleanup(viewId, cleanupSalesPurchaseView);
    TAIF.registerViewRenderer(viewId, ({ panel }) => {
      runtime.panel = panel;
      renderSalesPurchaseBoard(panel, { actionId, viewId });
      const pendingSourceFocus = TAIF.generalLedger && typeof TAIF.generalLedger.consumePendingSourceFocus === 'function'
        ? TAIF.generalLedger.consumePendingSourceFocus()
        : null;
      if(pendingSourceFocus && pendingSourceFocus.sourceKind === 'sales-purchase' && typeof focusSalesPurchaseSourceRecord === 'function'){
        requestAnimationFrame(() => {
          focusSalesPurchaseSourceRecord(pendingSourceFocus, panel);
        });
      }
    });
  });
})();
