(()=>{
  /*
   * TAIF Sales & Purchase board-controller module.
   * Owns panel-level bindings, search mode synchronization, adaptive toolbar
   * fitting, cleanup, and view rendering entry points.
   */
  const TAIF = window.TAIF;
  const feature = TAIF.salesPurchaseFeature || (TAIF.salesPurchaseFeature = {});
  const { focusElementWithoutScroll, mountAdaptiveToolbarFit } = TAIF.core.utils;
  const {
    runtime,
    toSafeText,
    DATE_PICKER_WEEKDAY_LABELS,
    DATE_PICKER_CHEVRON_PREV_MARKUP,
    DATE_PICKER_CHEVRON_NEXT_MARKUP,
    normalizeSalesPurchaseRecordDateFilterValue,
    normalizeSalesPurchaseRecordDateFilterRange,
    salesPurchaseTodayInputValue,
    salesPurchaseParseIsoDate,
    salesPurchaseNormalizeDatePickerView,
    salesPurchaseResolveMonthCursor,
    salesPurchaseShiftMonthCursor,
    salesPurchaseFormatMonthLabel,
    normalizeInlineSalesPurchaseActionId,
    ensureInlinePurchaseWorkspaceEntry,
    renderSalesPurchaseShell,
    refreshWorkbenchUi,
    resetSalesPurchaseRecordsPagination,
    moveSalesPurchaseRecordsPage,
    setSalesPurchaseRecordsPageSize,
    updateSalesPurchaseDeleteActionButtonUi,
    toggleSalesPurchaseRecordSelection,
    clearSalesPurchaseRecordSelection,
    requestSelectedSalesPurchaseDeletion,
    openSalesPurchaseWindow,
    closeAllSalesPurchaseWindows,
    closeSalesPurchaseDeleteConfirmDialog,
    closeSalesPurchaseReverseConfirmDialog,
    syncInlinePurchaseWorkspace,
    refreshSalesPurchaseSideboxPricesUi,
    handleInlinePurchaseWorkspacePointerDown,
    handleInlinePurchaseWorkspaceClick,
    handleInlinePurchaseWorkspaceInput,
    handleInlinePurchaseWorkspaceDocumentPointerDown
  } = feature;

  function getSalesPurchaseSearchDraft(){
    return typeof runtime.searchQueryDraft === 'string' ? runtime.searchQueryDraft : String(runtime.searchQuery || '');
  }

  function getSalesPurchaseRecordDateFilterDraftValue(key){
    return normalizeSalesPurchaseRecordDateFilterValue(key === 'to' ? runtime.recordDateFilterDraftTo : runtime.recordDateFilterDraftFrom);
  }

  function setSalesPurchaseRecordDateFilterDraftValue(key, value){
    const safeKey = key === 'to' ? 'to' : 'from';
    const normalizedValue = normalizeSalesPurchaseRecordDateFilterValue(value);
    if(safeKey === 'to') runtime.recordDateFilterDraftTo = normalizedValue;
    else runtime.recordDateFilterDraftFrom = normalizedValue;
    return normalizedValue;
  }

  function getSalesPurchaseRecordDateFilterManualParts(value){
    const safeValue = normalizeSalesPurchaseRecordDateFilterValue(value);
    const parsed = salesPurchaseParseIsoDate(safeValue);
    if(!parsed) return { day:'', month:'', year:'' };
    return {
      day:String(parsed.getDate()).padStart(2, '0'),
      month:String(parsed.getMonth() + 1).padStart(2, '0'),
      year:String(parsed.getFullYear())
    };
  }

  function updateSalesPurchaseRecordDateFilterInputUi(panel, key){
    if(!(panel instanceof HTMLElement)) return;
    const safeKey = key === 'to' ? 'to' : 'from';
    const value = getSalesPurchaseRecordDateFilterDraftValue(safeKey);
    const parts = getSalesPurchaseRecordDateFilterManualParts(value);
    const host = panel.querySelector(`[data-sales-purchase-record-date-picker="${safeKey}"]`);
    const hidden = panel.querySelector(`[data-sales-purchase-date-filter="${safeKey}"]`);
    if(hidden instanceof HTMLInputElement) hidden.value = value;
    if(host instanceof HTMLElement){
      const day = host.querySelector('[data-sales-purchase-record-date-part="day"]');
      const month = host.querySelector('[data-sales-purchase-record-date-part="month"]');
      const year = host.querySelector('[data-sales-purchase-record-date-part="year"]');
      if(day instanceof HTMLInputElement && day.value !== parts.day) day.value = parts.day;
      if(month instanceof HTMLInputElement && month.value !== parts.month) month.value = parts.month;
      if(year instanceof HTMLInputElement && year.value !== parts.year) year.value = parts.year;
    }
  }

  function closeSalesPurchaseRecordDateFilterPicker(panel = runtime.panel){
    if(!runtime.recordDateFilterPickerKey && !runtime.recordDateFilterPickerView) return;
    runtime.recordDateFilterPickerKey = '';
    runtime.recordDateFilterPickerView = 'days';
    refreshWorkbenchUi(panel);
    syncSalesPurchaseRecordDateFilterUi(panel);
  }

  function sanitizeSalesPurchaseRecordDateFilterPart(partKey, value){
    const digits = String(value || '').replace(/\D+/g, '');
    return partKey === 'year' ? digits.slice(0, 4) : digits.slice(0, 2);
  }

  function handleSalesPurchaseRecordDatePartInput(input, panel){
    if(!(input instanceof HTMLInputElement) || !input.matches('[data-sales-purchase-record-date-part]')) return false;
    const key = String(input.getAttribute('data-sales-purchase-record-date-field') || '').trim() === 'to' ? 'to' : 'from';
    const partKey = String(input.getAttribute('data-sales-purchase-record-date-part') || '').trim();
    const safeValue = sanitizeSalesPurchaseRecordDateFilterPart(partKey, input.value || '');
    if(input.value !== safeValue) input.value = safeValue;
    const host = input.closest(`[data-sales-purchase-record-date-picker="${key}"]`);
    const dayInput = host instanceof HTMLElement ? host.querySelector('[data-sales-purchase-record-date-part="day"]') : null;
    const monthInput = host instanceof HTMLElement ? host.querySelector('[data-sales-purchase-record-date-part="month"]') : null;
    const yearInput = host instanceof HTMLElement ? host.querySelector('[data-sales-purchase-record-date-part="year"]') : null;
    const day = dayInput instanceof HTMLInputElement ? String(dayInput.value || '').trim() : '';
    const month = monthInput instanceof HTMLInputElement ? String(monthInput.value || '').trim() : '';
    const year = yearInput instanceof HTMLInputElement ? String(yearInput.value || '').trim() : '';
    const hidden = panel instanceof HTMLElement ? panel.querySelector(`[data-sales-purchase-date-filter="${key}"]`) : null;
    if(!day && !month && !year){
      setSalesPurchaseRecordDateFilterDraftValue(key, '');
      if(hidden instanceof HTMLInputElement) hidden.value = '';
      syncSalesPurchaseRecordDateFilterUi(panel);
      return true;
    }
    if(day.length === 2 && month.length === 2 && year.length === 4){
      const nextIso = `${year}-${month}-${day}`;
      if(salesPurchaseParseIsoDate(nextIso)){
        setSalesPurchaseRecordDateFilterDraftValue(key, nextIso);
        runtime.recordDateFilterPickerMonthCursor = salesPurchaseResolveMonthCursor(nextIso, nextIso.slice(0, 7));
        if(hidden instanceof HTMLInputElement) hidden.value = nextIso;
        syncSalesPurchaseRecordDateFilterUi(panel);
      }
    }
    return true;
  }

  const SALES_PURCHASE_RECORD_DATE_FILTER_MONTH_STEPS = Object.freeze({
    'prev-month': -1,
    'next-month': 1,
    'prev-year': -12,
    'next-year': 12
  });

  function handleSalesPurchaseRecordDateControlClick(event, panel){
    const control = event.target instanceof Element ? event.target.closest('[data-sales-purchase-record-date-action]') : null;
    if(!(control instanceof HTMLElement) || !(panel instanceof HTMLElement) || !panel.contains(control)) return false;
    event.preventDefault();
    event.stopPropagation();
    const key = String(control.getAttribute('data-sales-purchase-record-date-field') || '').trim() === 'to' ? 'to' : 'from';
    const action = String(control.getAttribute('data-sales-purchase-record-date-action') || '').trim();
    const selectedValue = getSalesPurchaseRecordDateFilterDraftValue(key);
    const currentMonthCursor = control.getAttribute('data-sales-purchase-record-date-month') || runtime.recordDateFilterPickerMonthCursor || (selectedValue ? selectedValue.slice(0, 7) : '');

    if(action === 'toggle'){
      const willOpen = runtime.recordDateFilterPickerKey !== key;
      runtime.recordDateFilterPickerKey = willOpen ? key : '';
      runtime.recordDateFilterPickerView = 'days';
      runtime.recordDateFilterPickerMonthCursor = salesPurchaseResolveMonthCursor(selectedValue || salesPurchaseTodayInputValue(), currentMonthCursor);
      refreshWorkbenchUi(panel);
      syncSalesPurchaseRecordDateFilterUi(panel);
      return true;
    }

    if(runtime.recordDateFilterPickerKey !== key) return true;

    if(action === 'toggle-view'){
      runtime.recordDateFilterPickerView = salesPurchaseNormalizeDatePickerView(control.getAttribute('data-sales-purchase-record-date-view') || 'days');
      runtime.recordDateFilterPickerMonthCursor = salesPurchaseResolveMonthCursor(selectedValue || salesPurchaseTodayInputValue(), currentMonthCursor);
      refreshWorkbenchUi(panel);
      syncSalesPurchaseRecordDateFilterUi(panel);
      return true;
    }

    if(Object.prototype.hasOwnProperty.call(SALES_PURCHASE_RECORD_DATE_FILTER_MONTH_STEPS, action)){
      runtime.recordDateFilterPickerMonthCursor = salesPurchaseShiftMonthCursor(currentMonthCursor, SALES_PURCHASE_RECORD_DATE_FILTER_MONTH_STEPS[action]);
      refreshWorkbenchUi(panel);
      syncSalesPurchaseRecordDateFilterUi(panel);
      return true;
    }

    if(action === 'pick-month'){
      runtime.recordDateFilterPickerMonthCursor = salesPurchaseResolveMonthCursor(selectedValue || salesPurchaseTodayInputValue(), currentMonthCursor);
      runtime.recordDateFilterPickerView = 'days';
      refreshWorkbenchUi(panel);
      syncSalesPurchaseRecordDateFilterUi(panel);
      return true;
    }

    if(action === 'today' || action === 'select-day'){
      const nextValue = normalizeSalesPurchaseRecordDateFilterValue(control.getAttribute('data-sales-purchase-record-date-value') || selectedValue);
      setSalesPurchaseRecordDateFilterDraftValue(key, nextValue);
      runtime.recordDateFilterPickerKey = '';
      runtime.recordDateFilterPickerView = 'days';
      runtime.recordDateFilterPickerMonthCursor = nextValue ? nextValue.slice(0, 7) : currentMonthCursor;
      refreshWorkbenchUi(panel);
      syncSalesPurchaseRecordDateFilterUi(panel);
      return true;
    }

    if(action === 'clear'){
      setSalesPurchaseRecordDateFilterDraftValue(key, '');
      runtime.recordDateFilterPickerKey = '';
      runtime.recordDateFilterPickerView = 'days';
      refreshWorkbenchUi(panel);
      syncSalesPurchaseRecordDateFilterUi(panel);
      return true;
    }

    if(action === 'close'){
      runtime.recordDateFilterPickerKey = '';
      runtime.recordDateFilterPickerView = 'days';
      refreshWorkbenchUi(panel);
      syncSalesPurchaseRecordDateFilterUi(panel);
      return true;
    }

    return true;
  }

  function isSalesPurchaseSearchCancelMode(){
    const activeQuery = String(runtime.searchQuery || '').trim();
    const draftQuery = getSalesPurchaseSearchDraft().trim();
    return !!activeQuery && draftQuery === activeQuery;
  }

  function readSalesPurchaseRecordDateFilterInput(panel, key){
    if(!(panel instanceof HTMLElement)) return '';
    const input = panel.querySelector(`[data-sales-purchase-date-filter="${key}"]`);
    return input instanceof HTMLInputElement ? normalizeSalesPurchaseRecordDateFilterValue(input.value) : '';
  }

  function syncSalesPurchaseRecordDateFilterUi(panel = runtime.panel){
    if(!(panel instanceof HTMLElement)) return;
    updateSalesPurchaseRecordDateFilterInputUi(panel, 'from');
    updateSalesPurchaseRecordDateFilterInputUi(panel, 'to');
    const searchButton = panel.querySelector('[data-sales-purchase-action="apply-record-date-filter"]');
    const isActive = !!normalizeSalesPurchaseRecordDateFilterValue(runtime.recordDateFilterFrom) || !!normalizeSalesPurchaseRecordDateFilterValue(runtime.recordDateFilterTo);
    if(searchButton instanceof HTMLElement){
      searchButton.classList.toggle('is-active', isActive);
      searchButton.setAttribute('aria-pressed', isActive ? 'true' : 'false');
    }
  }

  function applySalesPurchaseRecordDateFilter(panel){
    runtime.recordDateFilterDraftFrom = readSalesPurchaseRecordDateFilterInput(panel, 'from');
    runtime.recordDateFilterDraftTo = readSalesPurchaseRecordDateFilterInput(panel, 'to');
    const nextRange = normalizeSalesPurchaseRecordDateFilterRange(runtime.recordDateFilterDraftFrom, runtime.recordDateFilterDraftTo);
    runtime.recordDateFilterDraftFrom = nextRange.from;
    runtime.recordDateFilterDraftTo = nextRange.to;
    runtime.recordDateFilterFrom = nextRange.from;
    runtime.recordDateFilterTo = nextRange.to;
    runtime.recordDateFilterPickerKey = '';
    runtime.recordDateFilterPickerView = 'days';
    if(typeof resetSalesPurchaseRecordsPagination === 'function') resetSalesPurchaseRecordsPagination();
    refreshWorkbenchUi(panel);
    syncSalesPurchaseRecordDateFilterUi(panel);
  }

  function syncSearchUi(){
    if(!(runtime.panel instanceof HTMLElement)) return;
    const input = runtime.panel.querySelector('[data-sales-purchase-search="true"]');
    const searchButton = runtime.panel.querySelector('[data-sales-purchase-action="toggle-search"]');
    const draftQuery = getSalesPurchaseSearchDraft();
    const isCancelMode = isSalesPurchaseSearchCancelMode();
    if(input instanceof HTMLInputElement && input.value !== draftQuery){
      input.value = draftQuery;
    }
    if(searchButton instanceof HTMLElement){
      searchButton.textContent = isCancelMode ? 'إلغاء' : 'بحث';
      searchButton.classList.toggle('is-active', isCancelMode);
      searchButton.setAttribute('aria-pressed', isCancelMode ? 'true' : 'false');
    }
    syncSalesPurchaseRecordDateFilterUi(runtime.panel);
  }

  function toggleSalesPurchaseRecordsSearch(panel){
    const input = panel.querySelector('[data-sales-purchase-search="true"]');
    const draftQuery = input instanceof HTMLInputElement
      ? String(input.value || '').trim()
      : getSalesPurchaseSearchDraft().trim();
    if(isSalesPurchaseSearchCancelMode()){
      runtime.searchQuery = '';
      runtime.searchQueryDraft = '';
    }else{
      runtime.searchQuery = draftQuery;
      runtime.searchQueryDraft = draftQuery;
    }
    if(typeof resetSalesPurchaseRecordsPagination === 'function') resetSalesPurchaseRecordsPagination();
    refreshWorkbenchUi(panel);
    const nextInput = panel.querySelector('[data-sales-purchase-search="true"]');
    if(nextInput instanceof HTMLInputElement){
      focusElementWithoutScroll(nextInput);
      nextInput.setSelectionRange(nextInput.value.length, nextInput.value.length);
    }
  }

  function mountToolbarAdaptiveFit(panel){
    if(typeof runtime.toolbarFitCleanup === 'function'){
      runtime.toolbarFitCleanup();
      runtime.toolbarFitCleanup = null;
    }

    runtime.toolbarFitCleanup = typeof mountAdaptiveToolbarFit === 'function'
      ? mountAdaptiveToolbarFit({
          panel,
          topbarSelector: '.sales-purchase-toolbar',
          toolsSelector: '.entries-toolbar__group',
          searchSelector: '.entries-toolbar__search'
        })
      : null;
  }

  function detachSalesPurchaseSideboxPriceListeners(){
    if(typeof runtime.sideboxPriceCurrencyEventsCleanup === 'function'){
      runtime.sideboxPriceCurrencyEventsCleanup();
      runtime.sideboxPriceCurrencyEventsCleanup = null;
    }
    if(typeof runtime.sideboxPriceCurrencyWindowHandler === 'function'){
      window.removeEventListener('taif:currency-domain-updated', runtime.sideboxPriceCurrencyWindowHandler);
      runtime.sideboxPriceCurrencyWindowHandler = null;
    }
  }

  function bindSalesPurchaseSideboxPriceListeners(panel){
    detachSalesPurchaseSideboxPriceListeners();
    const refreshSidebox = () => {
      if(!(panel instanceof HTMLElement) || panel !== runtime.panel || !panel.isConnected) return;
      if(typeof refreshSalesPurchaseSideboxPricesUi === 'function') refreshSalesPurchaseSideboxPricesUi(panel);
    };
    const events = TAIF.core && TAIF.core.events;
    if(events && typeof events.on === 'function' && events.EVENT_NAMES && events.EVENT_NAMES.CURRENCY_UPDATED){
      runtime.sideboxPriceCurrencyEventsCleanup = events.on(events.EVENT_NAMES.CURRENCY_UPDATED, refreshSidebox);
      return;
    }
    runtime.sideboxPriceCurrencyWindowHandler = refreshSidebox;
    window.addEventListener('taif:currency-domain-updated', runtime.sideboxPriceCurrencyWindowHandler);
  }

  function detachSalesPurchasePanelListeners(){
    const activePanel = runtime.panel instanceof HTMLElement ? runtime.panel : null;
    if(activePanel && typeof runtime.clickHandler === 'function'){
      activePanel.removeEventListener('click', runtime.clickHandler);
    }
    if(activePanel && typeof runtime.inputHandler === 'function'){
      activePanel.removeEventListener('input', runtime.inputHandler);
    }
    if(activePanel && typeof runtime.changeHandler === 'function'){
      activePanel.removeEventListener('change', runtime.changeHandler);
    }
    if(activePanel && typeof runtime.pointerHandler === 'function'){
      activePanel.removeEventListener('pointerdown', runtime.pointerHandler);
    }
    if(activePanel && typeof runtime.keydownHandler === 'function'){
      activePanel.removeEventListener('keydown', runtime.keydownHandler);
    }
    if(typeof runtime.documentPointerHandler === 'function'){
      document.removeEventListener('pointerdown', runtime.documentPointerHandler, true);
    }

    runtime.clickHandler = null;
    runtime.inputHandler = null;
    runtime.changeHandler = null;
    runtime.pointerHandler = null;
    runtime.keydownHandler = null;
    runtime.documentPointerHandler = null;
    runtime.panelListenersBound = false;
    detachSalesPurchaseSideboxPriceListeners();
  }

  function bindSalesPurchasePanel(panel){
    if(runtime.panelListenersBound && runtime.panel === panel) return;

    detachSalesPurchasePanelListeners();
    runtime.panel = panel;

    runtime.clickHandler = (event) => {
      if(typeof handleInlinePurchaseWorkspaceClick === 'function' && handleInlinePurchaseWorkspaceClick(event, panel)) return;
      if(handleSalesPurchaseRecordDateControlClick(event, panel)) return;
      const control = event.target instanceof Element ? event.target.closest('[data-sales-purchase-action]') : null;
      if(control instanceof HTMLElement && panel.contains(control)){
        if((control instanceof HTMLButtonElement && control.disabled) || control.getAttribute('aria-disabled') === 'true'){
          event.preventDefault();
          event.stopPropagation();
          return;
        }
        const action = String(control.getAttribute('data-sales-purchase-action') || '').trim();
        if(action === 'open-window'){
          openSalesPurchaseWindow(String(control.getAttribute('data-sales-purchase-window') || '').trim());
          return;
        }
        if(action === 'toggle-search'){
          toggleSalesPurchaseRecordsSearch(panel);
          return;
        }
        if(action === 'apply-record-date-filter'){
          applySalesPurchaseRecordDateFilter(panel);
          return;
        }
        if(action.startsWith('records-page-')){
          if(typeof moveSalesPurchaseRecordsPage === 'function') moveSalesPurchaseRecordsPage(action.replace('records-page-', ''), panel);
          return;
        }
        if(action === 'delete-selected-record'){
          requestSelectedSalesPurchaseDeletion();
          return;
        }
      }

      const recordRow = event.target instanceof Element ? event.target.closest('.entries-record-row[data-sales-purchase-record-id]') : null;
      if(recordRow instanceof HTMLElement && panel.contains(recordRow)){
        toggleSalesPurchaseRecordSelection(recordRow);
        return;
      }

      clearSalesPurchaseRecordSelection();
    };

    runtime.inputHandler = (event) => {
      if(typeof handleInlinePurchaseWorkspaceInput === 'function' && handleInlinePurchaseWorkspaceInput(event, panel)) return;
      const input = event.target;
      if(!(input instanceof HTMLInputElement)) return;
      if(handleSalesPurchaseRecordDatePartInput(input, panel)) return;
      if(input.matches('[data-sales-purchase-date-filter]')){
        const key = String(input.getAttribute('data-sales-purchase-date-filter') || '').trim();
        if(key === 'from') runtime.recordDateFilterDraftFrom = normalizeSalesPurchaseRecordDateFilterValue(input.value);
        if(key === 'to') runtime.recordDateFilterDraftTo = normalizeSalesPurchaseRecordDateFilterValue(input.value);
        syncSalesPurchaseRecordDateFilterUi(panel);
        return;
      }
      if(!input.matches('[data-sales-purchase-search="true"]')) return;
      runtime.searchQueryDraft = String(input.value || '');
      syncSearchUi();
    };

    runtime.changeHandler = (event) => {
      const input = event.target;
      if(input instanceof HTMLSelectElement && input.matches('[data-sales-purchase-records-page-size]')){
        event.preventDefault();
        if(typeof setSalesPurchaseRecordsPageSize === 'function') setSalesPurchaseRecordsPageSize(input.value, panel);
      }
    };

    runtime.pointerHandler = (event) => {
      if(typeof handleInlinePurchaseWorkspacePointerDown === 'function') handleInlinePurchaseWorkspacePointerDown(event, panel);
    };

    runtime.keydownHandler = (event) => {
      if(typeof feature.handleInlinePurchaseWorkspaceKeyDown === 'function' && feature.handleInlinePurchaseWorkspaceKeyDown(event, panel)) return;
      const input = event.target;
      if(!(input instanceof HTMLInputElement)) return;
      if(input.matches('[data-sales-purchase-date-filter], [data-sales-purchase-record-date-part]')){
        if(event.key === 'Escape'){
          event.preventDefault();
          closeSalesPurchaseRecordDateFilterPicker(panel);
          return;
        }
        if(event.key !== 'Enter') return;
        event.preventDefault();
        applySalesPurchaseRecordDateFilter(panel);
        return;
      }
      if(!input.matches('[data-sales-purchase-search="true"]')) return;
      if(event.key !== 'Enter') return;
      event.preventDefault();
      runtime.searchQueryDraft = String(input.value || '');
      toggleSalesPurchaseRecordsSearch(panel);
    };

    runtime.documentPointerHandler = (event) => {
      if(typeof handleInlinePurchaseWorkspaceDocumentPointerDown === 'function') handleInlinePurchaseWorkspaceDocumentPointerDown(event, panel);
      if(runtime.recordDateFilterPickerKey && panel instanceof HTMLElement){
        const target = event.target instanceof Element ? event.target : null;
        if(!target || !target.closest('[data-sales-purchase-record-date-picker]')){
          runtime.recordDateFilterPickerKey = '';
          runtime.recordDateFilterPickerView = 'days';
          refreshWorkbenchUi(panel);
          syncSalesPurchaseRecordDateFilterUi(panel);
        }
      }
      if(!toSafeText(runtime.selectedRecordId)) return;
      if(!(runtime.panel instanceof Element) || !runtime.panel.isConnected) return;
      const target = event.target instanceof Element ? event.target : null;
      if(target && (runtime.panel.contains(target) || target.closest('.taif-question-backdrop'))) return;
      clearSalesPurchaseRecordSelection();
    };

    panel.addEventListener('click', runtime.clickHandler);
    panel.addEventListener('input', runtime.inputHandler);
    panel.addEventListener('change', runtime.changeHandler);
    panel.addEventListener('pointerdown', runtime.pointerHandler);
    panel.addEventListener('keydown', runtime.keydownHandler);
    document.addEventListener('pointerdown', runtime.documentPointerHandler, true);
    runtime.panelListenersBound = true;
    mountToolbarAdaptiveFit(panel);
    updateSalesPurchaseDeleteActionButtonUi(panel);
    bindSalesPurchaseSideboxPriceListeners(panel);
  }

  function cleanupSalesPurchaseView(){
    closeAllSalesPurchaseWindows();
    closeSalesPurchaseDeleteConfirmDialog();
    closeSalesPurchaseReverseConfirmDialog();
    detachSalesPurchasePanelListeners();
    runtime.panel = null;
    runtime.selectedRecordId = '';

    if(typeof runtime.toolbarFitCleanup === 'function'){
      runtime.toolbarFitCleanup();
      runtime.toolbarFitCleanup = null;
    }
  }

  function renderSalesPurchaseBoard(panel = runtime.panel, options = {}){
    if(!(panel instanceof HTMLElement)) return;
    runtime.panel = panel;
    const requestedActionId = options && typeof options === 'object'
      ? String(options.actionId || '').trim()
      : '';
    const preferredActionId = typeof normalizeInlineSalesPurchaseActionId === 'function' && requestedActionId
      ? normalizeInlineSalesPurchaseActionId(requestedActionId)
      : '';
    if(preferredActionId){
      runtime.inlineSalesPurchaseActiveActionId = preferredActionId;
      if(typeof ensureInlinePurchaseWorkspaceEntry === 'function'){
        ensureInlinePurchaseWorkspaceEntry(null, preferredActionId);
      }
    }
    panel.innerHTML = renderSalesPurchaseShell();
    bindSalesPurchasePanel(panel);
    syncSearchUi();
    if(typeof syncInlinePurchaseWorkspace === 'function') syncInlinePurchaseWorkspace(panel);
  }

  Object.assign(feature, {
    syncSalesPurchaseSearchUi: syncSearchUi,
    bindSalesPurchasePanel,
    cleanupSalesPurchaseView,
    renderSalesPurchaseBoard
  });
})();
