(()=>{
  /*
   * TAIF Sales & Purchase foundation module.
   * Owns runtime state, shared constants, party-window helpers,
   * attachment synchronization, and navigator primitives.
   */
  const TAIF = window.TAIF;
  const feature = TAIF.salesPurchaseFeature || (TAIF.salesPurchaseFeature = {});
  const dateSystem = TAIF.ui?.dateSystem || {};
  const {
    escapeHtml,
    toText
  } = TAIF.core.utils;
  const windowChrome = TAIF.ui.windowChrome || {};
  const datePickerMonthNames = TAIF.core?.constants?.datePickerMonthNames || [];
  const datePickerWeekdayLabels = TAIF.core?.constants?.datePickerWeekdayLabels || [];

  const runtime = feature.runtime || TAIF.salesPurchaseInvoiceRuntime || (TAIF.salesPurchaseInvoiceRuntime = {
    panel: null,
    searchQuery: '',
    searchQueryDraft: '',
    selectedRecordId: '',
    deleteConfirmDialogHandle: null,
    reverseConfirmDialogHandle: null,
    successDialogCleanup: null,
    successToastTimer: null,
    successToastElement: null,
    modalManager: null,
    toolbarFitCleanup: null,
    panelListenersBound: false,
    clickHandler: null,
    inputHandler: null,
    changeHandler: null,
    documentPointerHandler: null,
    windows: new Map()
  });
  feature.runtime = runtime;
  TAIF.salesPurchaseInvoiceRuntime = runtime;
  if(typeof runtime.searchQuery !== 'string') runtime.searchQuery = '';
  if(typeof runtime.searchQueryDraft !== 'string') runtime.searchQueryDraft = runtime.searchQuery;
  if(typeof runtime.recordDateFilterFrom !== 'string') runtime.recordDateFilterFrom = '';
  if(typeof runtime.recordDateFilterTo !== 'string') runtime.recordDateFilterTo = '';
  if(typeof runtime.recordDateFilterDraftFrom !== 'string') runtime.recordDateFilterDraftFrom = runtime.recordDateFilterFrom;
  if(typeof runtime.recordDateFilterDraftTo !== 'string') runtime.recordDateFilterDraftTo = runtime.recordDateFilterTo;
  if(typeof runtime.recordDateFilterAutoDefaultDate !== 'string') runtime.recordDateFilterAutoDefaultDate = '';
  if(!Number.isInteger(runtime.salesPurchaseRecordsPageIndex) || runtime.salesPurchaseRecordsPageIndex < 0) runtime.salesPurchaseRecordsPageIndex = 0;
  if(typeof runtime.salesPurchaseRecordsPageSize === 'undefined' || runtime.salesPurchaseRecordsPageSize === null) runtime.salesPurchaseRecordsPageSize = 10;
  if(!('differentDateConfirmDialogHandle' in runtime)) runtime.differentDateConfirmDialogHandle = null;
  if(typeof runtime.recordDateFilterPickerKey !== 'string') runtime.recordDateFilterPickerKey = '';
  if(typeof runtime.recordDateFilterPickerView !== 'string') runtime.recordDateFilterPickerView = 'days';
  if(typeof runtime.recordDateFilterPickerMonthCursor !== 'string') runtime.recordDateFilterPickerMonthCursor = '';
  if(!Number.isInteger(runtime.windowSequence) || runtime.windowSequence < 0) runtime.windowSequence = 0;

  const storageKeys = TAIF?.core?.storageKeys || {};
  const ACCOUNT_STORAGE_KEY = storageKeys.chartOfAccounts || 'taif-chart-of-accounts-centers-v3';
  const CASH_BOX_STORAGE_KEY = storageKeys.cashBoxes || 'taif-cash-boxes-module-v1';
  const ENTRIES_STORAGE_KEY = storageKeys.entriesVouchers || 'taif-entries-vouchers-module-v1';
  const SALES_PURCHASE_STORAGE_KEY = storageKeys.salesPurchaseInvoice || 'taif-sales-purchase-invoice-records-v1';
  const SALES_PURCHASE_UPDATED_EVENT = 'taif:sales-purchase-invoice-updated';
  const DEFAULT_ENTRIES_COUNTERS = Object.freeze({ PV:1, RV:1, JV:1, SV:1, OV:1 });
  const SALES_PURCHASE_BALANCE_EPSILON = 1e-9;

  const CHOICE_PICKER_ICON_MARKUP = Object.freeze({
    chevronDown: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>',
    check: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m5 13 4 4L19 7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>'
  });

  const DELETE_ICON_MARKUP = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M3 6h18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M8 6V4h8v2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M19 6l-1 14H6L5 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M10 11v6M14 11v6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>';

  const DATE_PICKER_MONTH_NAMES = datePickerMonthNames;

  const DATE_PICKER_WEEKDAY_LABELS = datePickerWeekdayLabels;
  const DATE_PICKER_ICON_MARKUP = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M7 3v3M17 3v3M4 9h16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><rect x="4" y="5" width="16" height="15" rx="3" fill="none" stroke="currentColor" stroke-width="2"></rect></svg>';
  const DATE_PICKER_CHEVRON_PREV_MARKUP = '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m12.5 4.5-5 5 5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
  const DATE_PICKER_CHEVRON_NEXT_MARKUP = '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m7.5 4.5 5 5-5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>';

  const ACTIONS = Object.freeze({
    purchase: Object.freeze({
      id: 'purchase',
      label: 'فاتورة شراء',
      title: 'فاتورة شراء',
      buttonClass: 'sales-purchase-toolbar-btn--purchase entries-toolbar-btn--success',
      iconMarkup: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 5v14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path><path d="m6 13 6 6 6-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M6 5h12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path></svg>',
      activeCardTone: 'buy',
      passiveCardTone: 'sell',
      arrowDirection: 'left',
      primaryRateField: 'buy'
    }),
    sale: Object.freeze({
      id: 'sale',
      label: 'فاتورة مبيع',
      title: 'فاتورة مبيع',
      buttonClass: 'sales-purchase-toolbar-btn--sale entries-toolbar-btn--danger',
      iconMarkup: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 19V5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path><path d="m6 11 6-6 6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M6 19h12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path></svg>',
      activeCardTone: 'sell',
      passiveCardTone: 'buy',
      arrowDirection: 'right',
      primaryRateField: 'sell'
    }),
    party: Object.freeze({
      id: 'party',
      label: 'بطاقة الاسم',
      title: 'بطاقة الاسم'
    })
  });

  const SALES_PURCHASE_RECORD_COLUMNS = Object.freeze([
    Object.freeze({ key: 'serial', label: '#', className: 'sales-purchase-records__col--serial entries-records__col--serial' }),
    Object.freeze({ key: 'notice', label: 'رقم العملية', className: 'sales-purchase-records__col--notice entries-records__col--notice' }),
    Object.freeze({ key: 'date', label: 'التاريخ', className: 'sales-purchase-records__col--date entries-records__col--date' }),
    Object.freeze({ key: 'counterparty', label: 'اسم المستفيد', className: 'sales-purchase-records__col--counterparty entries-records__col--counterparty' }),
    Object.freeze({ key: 'from', label: 'من عملة', className: 'sales-purchase-records__col--from entries-records__col--from' }),
    Object.freeze({ key: 'incoming', label: 'المبلغ', className: 'sales-purchase-records__col--incoming entries-records__col--incoming' }),
    Object.freeze({ key: 'beneficiary', label: 'الى عملة', className: 'sales-purchase-records__col--beneficiary entries-records__col--beneficiary' }),
    Object.freeze({ key: 'outgoing', label: 'المقابل', className: 'sales-purchase-records__col--outgoing entries-records__col--outgoing' }),
    Object.freeze({ key: 'exchangeRate', label: 'سعر الصرف', className: 'sales-purchase-records__col--exchange-rate entries-records__col--exchange-rate' }),
    Object.freeze({ key: 'to', label: 'الصندوق', className: 'sales-purchase-records__col--to entries-records__col--to' }),
    Object.freeze({ key: 'notes', label: 'ملاحظات', className: 'sales-purchase-records__col--notes entries-records__col--notes' }),
    Object.freeze({ key: 'type', label: 'النوع', className: 'sales-purchase-records__col--type-status entries-records__col--type-status' }),
    Object.freeze({ key: 'actions', label: 'الإجراءات', className: 'sales-purchase-records__col--actions entries-records__col--actions' })
  ]);


  const SALES_PURCHASE_PARTY_AVATAR_SRC = 'assets/icons/chart-of-accounts-default-avatar.png';
  const SALES_PURCHASE_PARTY_AVATAR_ADD_SRC = 'assets/icons/sales-purchase-party-avatar-add.png';
  const SALES_PURCHASE_PARTY_PHONE_COUNTRY_FIELD_KEY = 'phoneCountryCode';
  const SALES_PURCHASE_PARTY_SEARCH_CLEAR_ICON = `
    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <path d="M18 6 6 18M6 6l12 12" fill="none" stroke="currentColor" stroke-width="2.35" stroke-linecap="round" stroke-linejoin="round"></path>
    </svg>
  `;


  function callFeatureMethod(methodName, fallback, ...args){
    const method = feature[methodName];
    return typeof method === 'function' ? method(...args) : fallback(...args);
  }

  function invokeSalesPurchaseFormMutation(entry, options){
    const method = feature.prepareSalesPurchaseFormMutation;
    if(typeof method === 'function') method(entry, options);
  }

  function closeSalesPurchaseWindow(windowId, event = null){
    const method = feature.closeSalesPurchaseWindow;
    if(typeof method === 'function') method(windowId, event);
  }

  function foundationFallbackReadSalesPurchaseState(){
    return callFeatureMethod('readSalesPurchaseState', () => ({ version:1, updatedAt:0, counters:{}, records:[] }));
  }

  function foundationFallbackCreateDefaultFormState(actionId){
    return callFeatureMethod('createDefaultFormState', () => ({ actionId: toSafeText(actionId) }), actionId);
  }

  function foundationFallbackNormalizeSalesPurchaseRecord(record){
    return callFeatureMethod('normalizeSalesPurchaseRecord', () => (record && typeof record === 'object' ? { ...record } : {}), record);
  }

  function foundationFallbackNormalizeSalesPurchaseEditedAmountField(value){
    return callFeatureMethod('normalizeSalesPurchaseEditedAmountField', () => (String(value || '').trim() === 'counterpart' ? 'counterpart' : 'amount'), value);
  }

  function foundationFallbackSanitizeNumericInput(value){
    return callFeatureMethod('sanitizeNumericInput', () => String(value ?? '').replace(/[^0-9.]/g, '').replace(/(\..*?)\./g, '$1'), value);
  }

  function foundationFallbackToNumber(value, fallback = 0){
    return callFeatureMethod(
      'toNumber',
      () => (Number.isFinite(Number(String(value || '').replace(/,/g, ''))) ? Number(String(value || '').replace(/,/g, '')) : fallback),
      value,
      fallback
    );
  }

  function foundationFallbackSalesPurchaseTodayInputValue(){
    return callFeatureMethod('salesPurchaseTodayInputValue', () => (typeof dateSystem.todayIsoDate === 'function' ? dateSystem.todayIsoDate() : new Date().toISOString().slice(0, 10)));
  }

  function foundationFallbackSalesPurchaseParseIsoDate(value){
    return callFeatureMethod('salesPurchaseParseIsoDate', () => (typeof dateSystem.parseIsoDate === 'function' ? dateSystem.parseIsoDate(value) : null), value);
  }

  function normalizeSalesPurchaseRecordDateFilterValue(value){
    const safeValue = toSafeText(value);
    return safeValue && foundationFallbackSalesPurchaseParseIsoDate(safeValue) ? safeValue : '';
  }

  function normalizeSalesPurchaseRecordDateFilterRange(fromValue = '', toValue = ''){
    const from = normalizeSalesPurchaseRecordDateFilterValue(fromValue);
    const to = normalizeSalesPurchaseRecordDateFilterValue(toValue);
    if(from && to && from > to) return { from: to, to: from };
    return { from, to };
  }

  function foundationFallbackSalesPurchaseToMonthCursor(date){
    return callFeatureMethod('salesPurchaseToMonthCursor', () => (typeof dateSystem.toMonthCursor === 'function' ? dateSystem.toMonthCursor(date) : foundationFallbackSalesPurchaseTodayInputValue().slice(0, 7)), date);
  }

  function foundationFallbackSalesPurchaseParseMonthCursor(value){
    return callFeatureMethod('salesPurchaseParseMonthCursor', () => (typeof dateSystem.parseMonthCursor === 'function' ? dateSystem.parseMonthCursor(value) : null), value);
  }

  function foundationFallbackSalesPurchaseNormalizeDatePickerView(value){
    return callFeatureMethod('salesPurchaseNormalizeDatePickerView', () => (typeof dateSystem.normalizePickerView === 'function' ? dateSystem.normalizePickerView(value) : (String(value || '').trim() === 'month-year' ? 'month-year' : 'days')), value);
  }

  function foundationFallbackSalesPurchaseNormalizeDateInputValue(value){
    return callFeatureMethod('salesPurchaseNormalizeDateInputValue', () => (typeof dateSystem.normalizeIsoDate === 'function' ? dateSystem.normalizeIsoDate(value) : (foundationFallbackSalesPurchaseParseIsoDate(value) ? String(value || '').trim() : foundationFallbackSalesPurchaseTodayInputValue())), value);
  }

  function foundationFallbackSalesPurchaseResolveMonthCursor(selectedValue, currentCursor = ''){
    return callFeatureMethod(
      'salesPurchaseResolveMonthCursor',
      () => (typeof dateSystem.resolveMonthCursor === 'function' ? dateSystem.resolveMonthCursor(selectedValue, currentCursor) : (foundationFallbackSalesPurchaseParseMonthCursor(currentCursor) ? currentCursor : foundationFallbackSalesPurchaseToMonthCursor(foundationFallbackSalesPurchaseParseIsoDate(selectedValue) || new Date()))),
      selectedValue,
      currentCursor
    );
  }

  function foundationFallbackSalesPurchaseBuildDateCells(monthCursor, selectedValue){
    return callFeatureMethod('salesPurchaseBuildDateCells', () => (typeof dateSystem.buildCalendarCells === 'function' ? dateSystem.buildCalendarCells(monthCursor, selectedValue) : []), monthCursor, selectedValue);
  }

  function foundationFallbackSalesPurchaseBuildMonthChoices(monthCursor){
    return callFeatureMethod('salesPurchaseBuildMonthChoices', () => (typeof dateSystem.buildMonthChoices === 'function' ? dateSystem.buildMonthChoices(monthCursor, DATE_PICKER_MONTH_NAMES) : []), monthCursor);
  }

  function foundationFallbackSalesPurchaseFormatMonthLabel(monthCursor){
    return callFeatureMethod('salesPurchaseFormatMonthLabel', () => (typeof dateSystem.formatMonthLabel === 'function' ? dateSystem.formatMonthLabel(monthCursor, DATE_PICKER_MONTH_NAMES) : String(monthCursor || '').trim()), monthCursor);
  }

  function getWindowIcon(type){
    return typeof windowChrome.getIconMarkup === 'function' ? windowChrome.getIconMarkup(type) : '';
  }

  function getChevronDownIcon(){
    return '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m5 7 5 6 5-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
  }

  function getTrackArrowIcon(direction = 'right'){
    const safeDirection = String(direction || '').trim() === 'left' ? 'left' : 'right';
    const upperLine = safeDirection === 'left' ? 'M114 20H32' : 'M12 20h82';
    const upperHead = safeDirection === 'left' ? 'm44 8-18 12 18 12' : 'm82 8 18 12-18 12';
    const lowerLine = safeDirection === 'left' ? 'M12 56h82' : 'M114 56H32';
    const lowerHead = safeDirection === 'left' ? 'm82 44 18 12-18 12' : 'm44 44-18 12 18 12';
    return `
      <div class="sales-purchase-rate-track__exchange-arrows sales-purchase-rate-track__exchange-arrows--${escapeHtml(safeDirection)}" aria-hidden="true">
        <svg class="sales-purchase-rate-track__exchange-arrows-svg" viewBox="0 0 126 68" focusable="false" aria-hidden="true">
          <path class="sales-purchase-rate-track__exchange-arrow sales-purchase-rate-track__exchange-arrow--upper" d="${upperLine}"></path>
          <path class="sales-purchase-rate-track__exchange-arrow-head sales-purchase-rate-track__exchange-arrow-head--upper" d="${upperHead}"></path>
          <path class="sales-purchase-rate-track__exchange-arrow sales-purchase-rate-track__exchange-arrow--lower" d="${lowerLine}"></path>
          <path class="sales-purchase-rate-track__exchange-arrow-head sales-purchase-rate-track__exchange-arrow-head--lower" d="${lowerHead}"></path>
        </svg>
      </div>
    `;
  }

  function renderSalesPurchasePartyAvatarMarkup({ variant = 'plain', className = '', alt = '' } = {}){
    const source = variant === 'add' ? SALES_PURCHASE_PARTY_AVATAR_ADD_SRC : SALES_PURCHASE_PARTY_AVATAR_SRC;
    const imageClass = ['sales-purchase-party-avatar', String(className || '').trim()].filter(Boolean).join(' ');
    const safeAlt = String(alt || '').trim();
    return `<img class="${escapeHtml(imageClass)}" src="${escapeHtml(source)}" alt="${escapeHtml(safeAlt)}" draggable="false" loading="eager" decoding="async">`;
  }


  function getSalesPurchasePartyCustomerApi(){
    return TAIF && TAIF.customerCard && typeof TAIF.customerCard === 'object'
      ? TAIF.customerCard
      : null;
  }

  function createSalesPurchasePartyEmptyDraft(){
    const api = getSalesPurchasePartyCustomerApi();
    if(api && typeof api.createEmptyState === 'function'){
      const state = api.createEmptyState();
      if(state && typeof state === 'object') return cloneSalesPurchaseValue(state) || {};
    }
    return {
      fullName: '',
      latinName: '',
      incomeSource: '',
      phone: '',
      phoneCountryCode: 'sy',
      nationality: '',
      gender: 'male',
      entityType: 'person',
      idType: '',
      idNumber: '',
      issuedBy: '',
      issueDate: '',
      expiryDate: '',
      birthPlace: '',
      birthDate: '',
      motherName: '',
      country: '',
      city: '',
      region: '',
      district: '',
      street: '',
      otherDetails: '',
      updatedAt: 0
    };
  }

  function normalizeSalesPurchasePartyDraft(value){
    const api = getSalesPurchasePartyCustomerApi();
    if(api && typeof api.normalizeDraft === 'function'){
      const normalized = api.normalizeDraft(value);
      return normalized && typeof normalized === 'object'
        ? (cloneSalesPurchaseValue(normalized) || createSalesPurchasePartyEmptyDraft())
        : createSalesPurchasePartyEmptyDraft();
    }
    return {
      ...createSalesPurchasePartyEmptyDraft(),
      ...(value && typeof value === 'object' ? value : {})
    };
  }

  function createDefaultSalesPurchasePartyUiState(selectedValue = ''){
    const safeSelectedValue = foundationFallbackSalesPurchaseParseIsoDate(selectedValue)
      ? String(selectedValue || '').trim()
      : foundationFallbackSalesPurchaseTodayInputValue();
    return {
      openChoiceField: '',
      openDateField: '',
      datePickerMonthCursor: foundationFallbackSalesPurchaseResolveMonthCursor(safeSelectedValue, safeSelectedValue.slice(0, 7)),
      datePickerView: 'days',
      phoneCountrySearchQuery: ''
    };
  }

  function ensureSalesPurchasePartyState(formState){
    if(!formState || typeof formState !== 'object'){
      return {
        draft: normalizeSalesPurchasePartyDraft(null),
        ui: createDefaultSalesPurchasePartyUiState()
      };
    }

    formState.partyDraft = normalizeSalesPurchasePartyDraft(formState.partyDraft);
    if(!formState.partyUi || typeof formState.partyUi !== 'object'){
      formState.partyUi = createDefaultSalesPurchasePartyUiState(formState.partyDraft.birthDate || formState.partyDraft.issueDate || formState.partyDraft.expiryDate);
    }

    const ui = formState.partyUi;
    ui.openChoiceField = toSafeText(ui.openChoiceField);
    ui.openDateField = toSafeText(ui.openDateField);
    ui.datePickerView = foundationFallbackSalesPurchaseNormalizeDatePickerView(ui.datePickerView);
    ui.phoneCountrySearchQuery = String(ui.phoneCountrySearchQuery || '');
    ui.datePickerMonthCursor = foundationFallbackSalesPurchaseResolveMonthCursor(
      foundationFallbackSalesPurchaseParseIsoDate(formState.partyDraft.birthDate) ? formState.partyDraft.birthDate : foundationFallbackSalesPurchaseTodayInputValue(),
      ui.datePickerMonthCursor
    );

    if(!toSafeText(formState.partyDraft.fullName) && toSafeText(formState.counterpartyName)){
      formState.partyDraft.fullName = toSafeText(formState.counterpartyName);
    }

    return { draft: formState.partyDraft, ui };
  }

  function getSalesPurchasePartyGroups(){
    const api = getSalesPurchasePartyCustomerApi();
    return Array.isArray(api?.groups) ? api.groups : [];
  }

  function getSalesPurchasePartyOptions(optionsKey){
    const api = getSalesPurchasePartyCustomerApi();
    const source = api && api.options && Object.prototype.hasOwnProperty.call(api.options, optionsKey)
      ? api.options[optionsKey]
      : [];
    return Array.isArray(source) ? source : [];
  }

  function getSalesPurchasePartyPhoneCountryCatalog(){
    const api = getSalesPurchasePartyCustomerApi();
    return api && typeof api.getPhoneCountryCatalog === 'function'
      ? api.getPhoneCountryCatalog()
      : [];
  }

  function getSalesPurchasePartyPhoneCountryMeta(value){
    const api = getSalesPurchasePartyCustomerApi();
    return api && typeof api.getPhoneCountryMeta === 'function'
      ? api.getPhoneCountryMeta(value)
      : null;
  }

  function normalizeSalesPurchasePartyPhoneCountrySearch(value){
    return String(value ?? '').toLowerCase().replace(/\s+/g, ' ').trim();
  }

  function getSalesPurchasePartyPhoneCountryOptions(formState){
    const { ui } = ensureSalesPurchasePartyState(formState);
    const query = normalizeSalesPurchasePartyPhoneCountrySearch(ui.phoneCountrySearchQuery);
    const catalog = Array.isArray(getSalesPurchasePartyPhoneCountryCatalog())
      ? getSalesPurchasePartyPhoneCountryCatalog()
      : [];
    if(!query) return catalog;
    return catalog.filter((entry) => normalizeSalesPurchasePartyPhoneCountrySearch(entry?.searchText || `${entry?.label || ''} ${entry?.dialCode || ''} ${entry?.englishLabel || ''} ${entry?.code || ''}`).includes(query));
  }

  function createSalesPurchasePartyPhoneCountryFlagMarkup(option){
    const code = String(option?.code || '').trim().toLowerCase();
    if(!code) return '<span class="customer-card-phone-country__flag customer-card-phone-country__flag--placeholder" aria-hidden="true">+</span>';
    return `<span class="customer-card-phone-country__flag" aria-hidden="true"><img class="customer-card-phone-country__flag-image" src="assets/flags/circle/${escapeHtml(code)}.png" alt="" draggable="false" loading="eager" decoding="async" width="512" height="512"></span>`;
  }

  function renderSalesPurchasePartyPhoneCountryTriggerValue(option){
    if(!option){
      return `
        <span class="customer-card-phone-country__trigger-content is-placeholder">
          <span class="customer-card-phone-country__trigger-label">النداء</span>
        </span>
      `;
    }
    return `
      <span class="customer-card-phone-country__trigger-content">
        ${createSalesPurchasePartyPhoneCountryFlagMarkup(option)}
        <span class="customer-card-phone-country__trigger-code" dir="ltr">${escapeHtml(option.dialCode || '')}</span>
      </span>
    `;
  }

  function renderSalesPurchasePartyPhoneCountryOptionMarkup(option, activeCountryCode){
    const safeCode = String(option?.code || '').trim();
    const isActive = safeCode === String(activeCountryCode || '').trim();
    const accessibleLabel = [option?.label || option?.englishLabel || option?.code || '', option?.dialCode || ''].filter(Boolean).join(' ');
    return `
      <button class="entries-voucher-choice-popover__option customer-card-phone-country__option${isActive ? ' is-active' : ''}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-taif-inline-picker-option="true" role="option" data-sales-purchase-party-choice-action="select" data-sales-purchase-party-choice-field="${SALES_PURCHASE_PARTY_PHONE_COUNTRY_FIELD_KEY}" data-sales-purchase-party-choice-value="${escapeHtml(option?.code || '')}" aria-selected="${isActive ? 'true' : 'false'}" aria-label="اختيار ${escapeHtml(accessibleLabel)}">
        <span class="customer-card-phone-country__option-leading">${createSalesPurchasePartyPhoneCountryFlagMarkup(option)}</span>
        <span class="customer-card-phone-country__option-code" dir="ltr">${escapeHtml(option?.dialCode || '')}</span>
      </button>
    `;
  }

  function renderSalesPurchasePartyPhoneCountryOptionsMarkup(formState, activeCountryCode){
    const options = getSalesPurchasePartyPhoneCountryOptions(formState);
    if(!options.length) return '<div class="entries-voucher-choice-popover__empty">لا توجد دول مطابقة للبحث الحالي.</div>';
    return options.map((option) => renderSalesPurchasePartyPhoneCountryOptionMarkup(option, activeCountryCode)).join('');
  }

  function isSalesPurchasePartyChoiceOpen(formState, fieldKey){
    const { ui } = ensureSalesPurchasePartyState(formState);
    return toSafeText(ui.openChoiceField) === toSafeText(fieldKey);
  }

  function isSalesPurchasePartyDateOpen(formState, fieldKey){
    const { ui } = ensureSalesPurchasePartyState(formState);
    return toSafeText(ui.openDateField) === toSafeText(fieldKey);
  }

  function renderSalesPurchasePartyChoiceValue(option, { placeholder = '' } = {}){
    if(!option){
      return `<span class="entries-voucher-choice-picker__placeholder">${escapeHtml(placeholder || '')}</span>`;
    }
    return `<span class="entries-voucher-choice-picker__text">${escapeHtml(option.label || option.value || '')}</span>`;
  }

  function renderSalesPurchasePartySegmentedMarkup(field, formState){
    const { draft } = ensureSalesPurchasePartyState(formState);
    const safeFieldKey = toSafeText(field?.key);
    const safeValue = toSafeText(draft[safeFieldKey]);
    const options = getSalesPurchasePartyOptions(field?.optionsKey);
    const activeIndex = options.findIndex((option) => toSafeText(option?.value) === safeValue);
    const focusIndex = activeIndex >= 0 ? activeIndex : 0;
    const optionsMarkup = options.map((option, index) => {
      const optionValue = toSafeText(option?.value);
      const isActive = optionValue === safeValue;
      const isTabStop = index === focusIndex;
      return `
        <button class="customer-card-segmented__option${isActive ? ' is-active' : ''}" type="button" role="radio" data-taif-flow-item="${isTabStop ? 'true' : 'false'}" data-sales-purchase-party-segmented-field="${escapeHtml(safeFieldKey)}" data-sales-purchase-party-segment="${escapeHtml(optionValue)}" aria-checked="${isActive ? 'true' : 'false'}" tabindex="${isTabStop ? '0' : '-1'}">
          ${escapeHtml(option?.label || optionValue || '—')}
        </button>
      `;
    }).join('');

    return `
      <div class="customer-card-segmented" role="radiogroup" aria-label="${escapeHtml(field?.label || safeFieldKey)}">
        ${optionsMarkup}
      </div>
    `;
  }

  function renderSalesPurchasePartyChoicePickerMarkup(field, formState){
    const { draft } = ensureSalesPurchasePartyState(formState);
    const safeFieldKey = toSafeText(field?.key);
    const safeValue = toSafeText(draft[safeFieldKey]);
    const options = getSalesPurchasePartyOptions(field?.optionsKey).map((option) => ({
      value: toSafeText(option?.value),
      label: toSafeText(option?.label || option?.value)
    }));
    const activeOption = options.find((option) => option.value === safeValue) || null;
    const isOpen = isSalesPurchasePartyChoiceOpen(formState, safeFieldKey);
    const listboxId = `sales-purchase-party-choice-${escapeHtml(safeFieldKey)}`;
    const placeholder = toSafeText(field?.placeholder || field?.label || '');
    const listContent = options.length
      ? options.map((option) => {
          const isActive = option.value === safeValue;
          return `
            <button class="entries-voucher-choice-popover__option${isActive ? ' is-active' : ''}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-taif-inline-picker-option="true" role="option" data-sales-purchase-party-choice-action="select" data-sales-purchase-party-choice-field="${escapeHtml(safeFieldKey)}" data-sales-purchase-party-choice-value="${escapeHtml(option.value)}" aria-selected="${isActive ? 'true' : 'false'}" aria-label="اختيار ${escapeHtml(option.label)}">
              <span class="entries-voucher-choice-popover__label" data-taif-dropdown-label="true">${renderSalesPurchasePartyChoiceValue(option)}</span>
            </button>
          `;
        }).join('')
      : '<div class="entries-voucher-choice-popover__empty">لا يوجد عناصر متاحة.</div>';

    return `
      <div class="customer-card-field__control-wrap customer-card-field__control-wrap--picker">
        <div class="entries-voucher-choice-picker${isOpen ? ' is-open' : ''}" data-sales-purchase-party-choice-picker="${escapeHtml(safeFieldKey)}" data-taif-inline-picker-host="true">
          <button class="customer-card-field__control customer-card-field__control--picker entries-voucher-choice-picker__trigger" type="button" data-taif-picker-trigger="true" data-taif-flow-item="true" data-sales-purchase-party-choice-trigger="true" data-sales-purchase-party-choice-field="${escapeHtml(safeFieldKey)}" aria-label="${escapeHtml(field?.label || safeFieldKey)}" aria-haspopup="listbox" aria-controls="${listboxId}" aria-expanded="${isOpen ? 'true' : 'false'}">
            <span class="entries-voucher-choice-picker__value${activeOption ? '' : ' is-placeholder'}">${renderSalesPurchasePartyChoiceValue(activeOption, { placeholder })}</span>
            <span class="entries-voucher-choice-picker__icon" aria-hidden="true">${getChevronDownIcon()}</span>
          </button>
          <div class="entries-voucher-choice-popover" data-taif-dropdown-popup="true" data-taif-dropdown-layout="list" id="${listboxId}" role="listbox" aria-label="${escapeHtml(field?.label || safeFieldKey)}"${isOpen ? '' : ' hidden'}>${listContent}</div>
        </div>
      </div>
    `;
  }

  function resolveSalesPurchasePartyDateMonthCursor(formState, fieldKey, selectedValue){
    const { ui } = ensureSalesPurchasePartyState(formState);
    const safeSelectedValue = foundationFallbackSalesPurchaseParseIsoDate(selectedValue)
      ? String(selectedValue || '').trim()
      : foundationFallbackSalesPurchaseTodayInputValue();
    if(toSafeText(ui.openDateField) === toSafeText(fieldKey)){
      return foundationFallbackSalesPurchaseResolveMonthCursor(safeSelectedValue, ui.datePickerMonthCursor);
    }
    return foundationFallbackSalesPurchaseResolveMonthCursor(safeSelectedValue, safeSelectedValue.slice(0, 7));
  }

  function renderSalesPurchasePartyDateDayButton(fieldKey, cell){
    const classes = [
      'entries-voucher-date__day',
      cell.outsideMonth ? 'is-outside' : '',
      cell.isToday ? 'is-today' : '',
      cell.isSelected ? 'is-selected' : ''
    ].filter(Boolean).join(' ');
    return `
      <button class="${classes}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="grid" data-sales-purchase-party-date-action="select-day" data-sales-purchase-party-date-field="${escapeHtml(fieldKey)}" data-sales-purchase-party-date-value="${escapeHtml(cell.value)}" aria-pressed="${cell.isSelected ? 'true' : 'false'}" aria-label="اختيار التاريخ ${escapeHtml(cell.value)}">
        <span dir="ltr">${escapeHtml(cell.label)}</span>
      </button>
    `;
  }

  function renderSalesPurchasePartyDateMonthButton(fieldKey, monthChoice){
    const classes = ['entries-voucher-date__month', monthChoice.isActive ? 'is-active' : ''].filter(Boolean).join(' ');
    return `
      <button class="${classes}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="grid" data-sales-purchase-party-date-action="pick-month" data-sales-purchase-party-date-field="${escapeHtml(fieldKey)}" data-sales-purchase-party-date-month="${escapeHtml(monthChoice.monthCursor)}" aria-pressed="${monthChoice.isActive ? 'true' : 'false'}" aria-label="اختيار شهر ${escapeHtml(monthChoice.label)}">
        <span>${escapeHtml(monthChoice.label)}</span>
      </button>
    `;
  }


  function getSalesPurchasePartyDateInputParts(value){
    const parsedDate = foundationFallbackSalesPurchaseParseIsoDate(value);
    return {
      day: parsedDate ? String(parsedDate.getDate()).padStart(2, '0') : '',
      month: parsedDate ? String(parsedDate.getMonth() + 1).padStart(2, '0') : '',
      year: parsedDate ? String(parsedDate.getFullYear()) : ''
    };
  }

  function renderSalesPurchasePartyDatePickerMarkup(field, formState){
    const { draft, ui } = ensureSalesPurchasePartyState(formState);
    const safeFieldKey = toSafeText(field?.key);
    const rawValue = String(draft[safeFieldKey] || '').trim();
    const safeValue = foundationFallbackSalesPurchaseParseIsoDate(rawValue) ? rawValue : '';
    const isOpen = isSalesPurchasePartyDateOpen(formState, safeFieldKey);
    const monthCursor = resolveSalesPurchasePartyDateMonthCursor(formState, safeFieldKey, safeValue);
    const view = foundationFallbackSalesPurchaseNormalizeDatePickerView(ui.datePickerView);
    const cells = foundationFallbackSalesPurchaseBuildDateCells(monthCursor, safeValue);
    const monthChoices = foundationFallbackSalesPurchaseBuildMonthChoices(monthCursor);
    const todayValue = foundationFallbackSalesPurchaseTodayInputValue();
    const currentMonth = foundationFallbackSalesPurchaseParseMonthCursor(monthCursor) || foundationFallbackSalesPurchaseParseMonthCursor(foundationFallbackSalesPurchaseToMonthCursor(new Date()));
    const currentYearLabel = String(currentMonth?.year || new Date().getFullYear());
    const dateParts = getSalesPurchasePartyDateInputParts(safeValue);
    const safeLabel = escapeHtml(field?.label || safeFieldKey);

    return `
      <div class="customer-card-field__control-wrap customer-card-field__control-wrap--picker">
        <div class="entries-voucher-date${isOpen ? ' is-open' : ''}" data-sales-purchase-party-date-picker="${escapeHtml(safeFieldKey)}">
          <div class="customer-card-field__control customer-card-field__control--date-shell entries-voucher-date__trigger sales-purchase-party-date-shell">
            <div class="entries-voucher-date__manual sales-purchase-party-date-manual" data-sales-purchase-party-date-manual="true">
              <input class="entries-voucher-date__manual-input entries-voucher-date__manual-input--day sales-purchase-party-date-part" type="text" value="${escapeHtml(dateParts.day)}" placeholder="يوم" inputmode="numeric" autocomplete="off" dir="ltr" data-taif-flow-item="true" data-sales-purchase-party-date-part="day" data-sales-purchase-party-date-field="${escapeHtml(safeFieldKey)}" aria-label="يوم ${safeLabel}">
              <span class="entries-voucher-date__manual-sep" aria-hidden="true">/</span>
              <input class="entries-voucher-date__manual-input entries-voucher-date__manual-input--month sales-purchase-party-date-part" type="text" value="${escapeHtml(dateParts.month)}" placeholder="شهر" inputmode="numeric" autocomplete="off" dir="ltr" data-taif-flow-item="true" data-sales-purchase-party-date-part="month" data-sales-purchase-party-date-field="${escapeHtml(safeFieldKey)}" aria-label="شهر ${safeLabel}">
              <span class="entries-voucher-date__manual-sep" aria-hidden="true">/</span>
              <input class="entries-voucher-date__manual-input entries-voucher-date__manual-input--year sales-purchase-party-date-part" type="text" value="${escapeHtml(dateParts.year)}" placeholder="سنة" inputmode="numeric" autocomplete="off" dir="ltr" data-taif-flow-item="true" data-sales-purchase-party-date-part="year" data-sales-purchase-party-date-field="${escapeHtml(safeFieldKey)}" aria-label="سنة ${safeLabel}">
            </div>
            <button class="entries-voucher-date__trigger-icon-btn sales-purchase-party-date-icon-btn" type="button" data-taif-picker-trigger="true" data-taif-flow-item="true" data-sales-purchase-party-date-trigger="true" data-sales-purchase-party-date-field="${escapeHtml(safeFieldKey)}" aria-label="فتح لوحة ${safeLabel}" aria-haspopup="dialog" aria-expanded="${isOpen ? 'true' : 'false'}">
              <span class="entries-voucher-date__trigger-icon" aria-hidden="true">${DATE_PICKER_ICON_MARKUP}</span>
            </button>
          </div>
          ${isOpen ? `
            <div class="entries-voucher-date__popover" data-taif-dropdown-popup="true" data-taif-dropdown-layout="calendar" role="dialog" aria-label="اختيار التاريخ">
              ${view === 'month-year' ? `
                <div class="entries-voucher-date__header entries-voucher-date__header--month-year">
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-party-date-action="prev-year" data-sales-purchase-party-date-field="${escapeHtml(safeFieldKey)}" data-sales-purchase-party-date-month="${escapeHtml(monthCursor)}" aria-label="السنة السابقة">${DATE_PICKER_CHEVRON_NEXT_MARKUP}</button>
                  <button class="entries-voucher-date__heading-trigger entries-voucher-date__heading-trigger--current" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-party-date-action="toggle-view" data-sales-purchase-party-date-field="${escapeHtml(safeFieldKey)}" data-sales-purchase-party-date-view="days" data-sales-purchase-party-date-month="${escapeHtml(monthCursor)}" aria-label="الرجوع إلى أيام الشهر">
                    <span dir="ltr">${escapeHtml(currentYearLabel)}</span>
                  </button>
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-party-date-action="next-year" data-sales-purchase-party-date-field="${escapeHtml(safeFieldKey)}" data-sales-purchase-party-date-month="${escapeHtml(monthCursor)}" aria-label="السنة التالية">${DATE_PICKER_CHEVRON_PREV_MARKUP}</button>
                </div>
                <div class="entries-voucher-date__month-panel">
                  <div class="entries-voucher-date__month-grid">
                    ${monthChoices.map((monthChoice) => renderSalesPurchasePartyDateMonthButton(safeFieldKey, monthChoice)).join('')}
                  </div>
                </div>
                <div class="entries-voucher-date__footer">
                  <button class="entries-voucher-date__footer-btn" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-party-date-action="toggle-view" data-sales-purchase-party-date-field="${escapeHtml(safeFieldKey)}" data-sales-purchase-party-date-view="days" data-sales-purchase-party-date-month="${escapeHtml(monthCursor)}">رجوع للتقويم</button>
                  <button class="entries-voucher-date__footer-btn entries-voucher-date__footer-btn--ghost" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-party-date-action="close" data-sales-purchase-party-date-field="${escapeHtml(safeFieldKey)}">إغلاق</button>
                </div>
              ` : `
                <div class="entries-voucher-date__header">
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-party-date-action="prev-month" data-sales-purchase-party-date-field="${escapeHtml(safeFieldKey)}" data-sales-purchase-party-date-month="${escapeHtml(monthCursor)}" aria-label="الشهر السابق">${DATE_PICKER_CHEVRON_NEXT_MARKUP}</button>
                  <button class="entries-voucher-date__heading-trigger" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-party-date-action="toggle-view" data-sales-purchase-party-date-field="${escapeHtml(safeFieldKey)}" data-sales-purchase-party-date-view="month-year" data-sales-purchase-party-date-month="${escapeHtml(monthCursor)}" aria-label="تغيير الشهر أو السنة">${escapeHtml(foundationFallbackSalesPurchaseFormatMonthLabel(monthCursor))}</button>
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-party-date-action="next-month" data-sales-purchase-party-date-field="${escapeHtml(safeFieldKey)}" data-sales-purchase-party-date-month="${escapeHtml(monthCursor)}" aria-label="الشهر التالي">${DATE_PICKER_CHEVRON_PREV_MARKUP}</button>
                </div>
                <div class="entries-voucher-date__weekdays" aria-hidden="true">
                  ${DATE_PICKER_WEEKDAY_LABELS.map((label) => `<span>${escapeHtml(label)}</span>`).join('')}
                </div>
                <div class="entries-voucher-date__grid">
                  ${cells.map((cell) => renderSalesPurchasePartyDateDayButton(safeFieldKey, cell)).join('')}
                </div>
                <div class="entries-voucher-date__footer">
                  <button class="entries-voucher-date__footer-btn" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-party-date-action="today" data-sales-purchase-party-date-field="${escapeHtml(safeFieldKey)}" data-sales-purchase-party-date-value="${escapeHtml(todayValue)}">اليوم</button>
                  <button class="entries-voucher-date__footer-btn entries-voucher-date__footer-btn--ghost" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-party-date-action="clear" data-sales-purchase-party-date-field="${escapeHtml(safeFieldKey)}">مسح</button>
                  <button class="entries-voucher-date__footer-btn entries-voucher-date__footer-btn--ghost" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-sales-purchase-party-date-action="close" data-sales-purchase-party-date-field="${escapeHtml(safeFieldKey)}">إغلاق</button>
                </div>
              `}
            </div>
          ` : ''}
        </div>
      </div>
    `;
  }

  function renderSalesPurchasePartyPhoneFieldMarkup(field, formState){
    const { draft, ui } = ensureSalesPurchasePartyState(formState);
    const phoneValue = Object.prototype.hasOwnProperty.call(draft, 'phone') ? String(draft.phone || '') : '';
    const countryValue = Object.prototype.hasOwnProperty.call(draft, SALES_PURCHASE_PARTY_PHONE_COUNTRY_FIELD_KEY)
      ? String(draft[SALES_PURCHASE_PARTY_PHONE_COUNTRY_FIELD_KEY] || '')
      : '';
    const activeCountry = getSalesPurchasePartyPhoneCountryMeta(countryValue);
    const isOpen = isSalesPurchasePartyChoiceOpen(formState, SALES_PURCHASE_PARTY_PHONE_COUNTRY_FIELD_KEY);
    const listboxId = 'sales-purchase-party-phone-country-listbox';
    const searchValue = String(ui.phoneCountrySearchQuery || '');
    const optionsMarkup = renderSalesPurchasePartyPhoneCountryOptionsMarkup(formState, countryValue);

    return `
      <div class="customer-card-phone-field" data-sales-purchase-party-phone-field="true">
        <div class="customer-card-phone-field__picker customer-card-field__control-wrap customer-card-field__control-wrap--picker">
          <div class="entries-voucher-choice-picker${isOpen ? ' is-open' : ''}" data-sales-purchase-party-choice-picker="${SALES_PURCHASE_PARTY_PHONE_COUNTRY_FIELD_KEY}" data-taif-inline-picker-host="true" data-taif-flow-skip="true">
            <button class="customer-card-field__control customer-card-field__control--picker customer-card-phone-country__trigger" type="button" data-taif-flow-skip="true" tabindex="-1" data-sales-purchase-party-choice-trigger="true" data-sales-purchase-party-choice-field="${SALES_PURCHASE_PARTY_PHONE_COUNTRY_FIELD_KEY}" aria-label="اختيار نداء الدولة" aria-haspopup="listbox" aria-controls="${listboxId}" aria-expanded="${isOpen ? 'true' : 'false'}">
              ${renderSalesPurchasePartyPhoneCountryTriggerValue(activeCountry)}
              <span class="entries-voucher-choice-picker__icon" aria-hidden="true">${getChevronDownIcon()}</span>
            </button>
            <div class="entries-voucher-choice-popover customer-card-phone-country__popover" data-taif-dropdown-popup="true" data-taif-dropdown-layout="list"${isOpen ? '' : ' hidden'}>
              <div class="customer-card-phone-country__search-wrap">
                <input class="customer-card-phone-country__search${searchValue ? '' : ' is-empty'}" type="text" value="${escapeHtml(searchValue)}" data-sales-purchase-party-phone-country-search="true" placeholder="دولة / النداء" autocomplete="off" autocapitalize="off" inputmode="search" enterkeyhint="search" dir="auto" spellcheck="false" aria-label="بحث نداء الدولة">
                <button class="entries-search__clear customer-card-phone-country__search-clear" type="button" data-sales-purchase-party-phone-country-search-action="clear" data-taif-clear-control="true" aria-label="مسح بحث نداء الدولة"${searchValue ? '' : ' hidden'}>${SALES_PURCHASE_PARTY_SEARCH_CLEAR_ICON}</button>
              </div>
              <div class="customer-card-phone-country__options" data-sales-purchase-party-phone-country-options="true" id="${listboxId}" role="listbox" aria-label="قائمة نداءات الدول">
                ${optionsMarkup}
              </div>
            </div>
          </div>
        </div>
        <input class="customer-card-field__control customer-card-phone-field__number" type="tel" value="${escapeHtml(phoneValue)}" data-sales-purchase-party-field="phone" aria-label="${escapeHtml(field?.label || 'رقم الهاتف')}" placeholder="${escapeHtml(field?.placeholder || 'الرقم بدون صفر')}" autocomplete="tel" inputmode="tel" dir="ltr" spellcheck="false" maxlength="18">
      </div>
    `;
  }

  function renderSalesPurchasePartyInputMarkup(field, formState){
    const { draft } = ensureSalesPurchasePartyState(formState);
    const type = toSafeText(field?.type || 'text') || 'text';
    const safeValue = Object.prototype.hasOwnProperty.call(draft, field?.key)
      ? String(draft[field.key] ?? '')
      : '';
    const safeLabel = escapeHtml(field?.label || field?.key || '');
    const inputMode = field?.inputMode ? ` inputmode="${escapeHtml(field.inputMode)}"` : '';
    const dir = field?.dir ? ` dir="${escapeHtml(field.dir)}"` : '';
    const autoComplete = field?.autoComplete ? ` autocomplete="${escapeHtml(field.autoComplete)}"` : ' autocomplete="off"';
    const placeholder = field?.placeholder ? ` placeholder="${escapeHtml(field.placeholder)}"` : '';

    return `<input class="customer-card-field__control" type="${escapeHtml(type)}" value="${escapeHtml(safeValue)}" data-sales-purchase-party-field="${escapeHtml(field?.key || '')}" aria-label="${safeLabel}"${placeholder}${autoComplete}${inputMode}${dir} spellcheck="false">`;
  }

  function renderSalesPurchasePartyFieldMarkup(field, formState){
    let controlMarkup = '';
    if(field?.control === 'segmented') controlMarkup = renderSalesPurchasePartySegmentedMarkup(field, formState);
    else if(field?.control === 'phone') controlMarkup = renderSalesPurchasePartyPhoneFieldMarkup(field, formState);
    else if(field?.control === 'select') controlMarkup = renderSalesPurchasePartyChoicePickerMarkup(field, formState);
    else if(toSafeText(field?.type) === 'date') controlMarkup = renderSalesPurchasePartyDatePickerMarkup(field, formState);
    else controlMarkup = renderSalesPurchasePartyInputMarkup(field, formState);

    return `
      <div class="customer-card-field${field?.span === 'full' ? ' customer-card-field--full' : ''}" data-sales-purchase-party-field-wrap="${escapeHtml(field?.key || '')}">
        <span class="customer-card-field__label">${escapeHtml(field?.label || '')}</span>
        ${controlMarkup}
      </div>
    `;
  }

  function splitSalesPurchasePartyGroupFields(fields){
    const inlineRows = [];
    const inlineRowMap = new Map();
    const gridFields = [];
    (Array.isArray(fields) ? fields : []).forEach((field) => {
      const rowKey = toSafeText(field?.row);
      if(!rowKey){
        gridFields.push(field);
        return;
      }
      if(!inlineRowMap.has(rowKey)){
        const row = { key: rowKey, fields: [] };
        inlineRowMap.set(rowKey, row);
        inlineRows.push(row);
      }
      inlineRowMap.get(rowKey).fields.push(field);
    });
    return { inlineRows, gridFields };
  }

  function renderSalesPurchasePartyInlineRowMarkup(row, formState){
    const fields = Array.isArray(row?.fields) ? row.fields : [];
    if(!fields.length) return '';
    return `
      <div class="customer-card-group__row" data-sales-purchase-party-row="${escapeHtml(row?.key || '')}">
        ${fields.map((field) => renderSalesPurchasePartyFieldMarkup(field, formState)).join('')}
      </div>
    `;
  }

  function renderSalesPurchasePartyGroupMarkup(group, formState){
    const fields = Array.isArray(group?.fields) ? group.fields : [];
    const { inlineRows, gridFields } = splitSalesPurchasePartyGroupFields(fields);
    const safeGroupKey = escapeHtml(group?.key || '');
    const safeTitle = escapeHtml(group?.title || '');
    const shouldRenderHead = String(group?.key || '').trim() !== 'identity' && safeTitle;
    return `
      <section class="customer-card-group sales-purchase-party-group sales-purchase-party-group--${safeGroupKey}${shouldRenderHead ? '' : ' sales-purchase-party-group--headless'}" ${shouldRenderHead ? `aria-labelledby="sales-purchase-party-group-${safeGroupKey}"` : `aria-label="${safeTitle || 'بطاقة الاسم'}"`}>
        ${shouldRenderHead ? `
          <div class="customer-card-group__head">
            <h2 id="sales-purchase-party-group-${safeGroupKey}" class="customer-card-group__title">${safeTitle}</h2>
          </div>
        ` : ''}
        ${inlineRows.map((row) => renderSalesPurchasePartyInlineRowMarkup(row, formState)).join('')}
        ${gridFields.length ? `<div class="customer-card-group__grid">${gridFields.map((field) => renderSalesPurchasePartyFieldMarkup(field, formState)).join('')}</div>` : ''}
      </section>
    `;
  }

  function renderSalesPurchasePartyWindow(formState){
    ensureSalesPurchasePartyState(formState);
    const groups = getSalesPurchasePartyGroups();
    if(!groups.length){
      return '<div class="sales-purchase-empty-canvas" aria-label="بطاقة الاسم" data-sales-purchase-party-canvas="true"></div>';
    }
    return `
      <div class="sales-purchase-party-form" aria-label="بطاقة الاسم">
        ${groups.map((group) => renderSalesPurchasePartyGroupMarkup(group, formState)).join('')}
      </div>
    `;
  }

  function syncSalesPurchasePartyLinkedName(entry){
    if(!entry || !entry.formState) return;
    const { draft } = ensureSalesPurchasePartyState(entry.formState);
    const safeName = toSafeText(draft.fullName);
    entry.formState.counterpartyName = safeName;
    const ownerWindowId = toSafeText(entry.ownerWindowId);
    if(!ownerWindowId) return;
    const ownerEntry = runtime.windows.get(ownerWindowId);
    if(!ownerEntry || !ownerEntry.formState) return;
    ownerEntry.formState.counterpartyName = safeName;
    const ownerInput = ownerEntry.modal instanceof HTMLElement
      ? ownerEntry.modal.querySelector('[data-sales-purchase-field="counterparty-name"]')
      : null;
    if(ownerInput instanceof HTMLInputElement && ownerInput.value !== safeName) ownerInput.value = safeName;
    invokeSalesPurchaseFormMutation(ownerEntry, { clearLookup:true, syncBaseline:true });
    const ownerAvatar = ownerEntry.modal instanceof HTMLElement
      ? ownerEntry.modal.querySelector('.sales-purchase-name-field__avatar')
      : null;
    if(ownerAvatar instanceof HTMLElement){
      ownerAvatar.innerHTML = renderSalesPurchasePartyAvatarMarkup({ variant: safeName ? 'plain' : 'add' });
    }
  }


  function getSalesPurchaseWindowEntry(windowId){
    const safeWindowId = toSafeText(windowId);
    return safeWindowId ? (runtime.windows.get(safeWindowId) || null) : null;
  }

  function getSalesPurchaseWindowEntryByModal(modal){
    if(!(modal instanceof HTMLElement)) return null;
    for(const entry of runtime.windows.values()){
      if(entry && entry.modal === modal) return entry;
    }
    return null;
  }

  function isSalesPurchasePartyEntry(entry){
    return !!entry && toSafeText(entry.action?.id) === 'party';
  }

  function resolveSalesPurchaseWindowAction(windowId){
    const safeWindowId = toSafeText(windowId);
    if(!safeWindowId) return null;
    if(ACTIONS[safeWindowId]) return ACTIONS[safeWindowId];
    const baseWindowId = toSafeText(safeWindowId.split('::')[0]);
    return baseWindowId ? (ACTIONS[baseWindowId] || null) : null;
  }

  function resolveSalesPurchaseWindowInstanceId(actionId, options = null){
    const safeActionId = toSafeText(actionId);
    const safeOptions = options && typeof options === 'object' ? options : null;
    if(safeActionId === 'party'){
      const ownerWindowId = toSafeText(safeOptions ? safeOptions.ownerWindowId : '');
      return ownerWindowId ? `party::${ownerWindowId}` : safeActionId;
    }
    const shouldForceNew = !!(safeOptions && safeOptions.forceNew);
    if(shouldForceNew && (safeActionId === 'purchase' || safeActionId === 'sale')){
      runtime.windowSequence = Math.max(0, Number(runtime.windowSequence) || 0) + 1;
      return `${safeActionId}::${Date.now().toString(36)}-${runtime.windowSequence.toString(36)}`;
    }
    return safeActionId;
  }

  function getSalesPurchaseAttachedOwnerBlocker(entry){
    if(!entry || !(entry.backdrop instanceof HTMLElement)) return null;
    const blocker = entry.backdrop.querySelector('[data-sales-purchase-attached-owner-blocker="true"]');
    return blocker instanceof HTMLElement ? blocker : null;
  }

  function resetSalesPurchaseAttachedOwnerBlocker(entry){
    const blocker = getSalesPurchaseAttachedOwnerBlocker(entry);
    if(!(blocker instanceof HTMLElement)) return;
    blocker.hidden = true;
    blocker.style.left = '0px';
    blocker.style.top = '0px';
    blocker.style.width = '0px';
    blocker.style.height = '0px';
  }

  function syncSalesPurchaseAttachedOwnerBlocker(childEntry){
    const blocker = getSalesPurchaseAttachedOwnerBlocker(childEntry);
    if(!(blocker instanceof HTMLElement)) return;
    const ownerEntry = getSalesPurchaseAttachedPartyOwner(childEntry);
    if(!ownerEntry || !(ownerEntry.modal instanceof HTMLElement)){
      resetSalesPurchaseAttachedOwnerBlocker(childEntry);
      return;
    }

    const ownerRect = ownerEntry.modal.getBoundingClientRect();
    if(ownerRect.width < 1 || ownerRect.height < 1){
      resetSalesPurchaseAttachedOwnerBlocker(childEntry);
      return;
    }

    blocker.hidden = false;
    blocker.style.left = `${Math.round(ownerRect.left)}px`;
    blocker.style.top = `${Math.round(ownerRect.top)}px`;
    blocker.style.width = `${Math.round(ownerRect.width)}px`;
    blocker.style.height = `${Math.round(ownerRect.height)}px`;
  }

  function getSalesPurchaseAttachedPartyOwner(entry){
    if(!isSalesPurchasePartyEntry(entry)) return null;
    const ownerEntry = getSalesPurchaseWindowEntry(entry.ownerWindowId);
    if(!ownerEntry || ownerEntry === entry || !(ownerEntry.modal instanceof HTMLElement)) return null;
    return ownerEntry;
  }

  function getSalesPurchaseAttachedPartyChild(entry){
    if(!entry || !(entry.modal instanceof HTMLElement)) return null;
    const childEntry = getSalesPurchaseWindowEntry(entry.attachedPartyWindowId);
    if(!childEntry || !isSalesPurchasePartyEntry(childEntry) || toSafeText(childEntry.ownerWindowId) !== toSafeText(entry.id)) return null;
    return childEntry;
  }

  function snapshotSalesPurchaseWindowPosition(entry, position = null){
    if(!entry || !(entry.modal instanceof HTMLElement)) return null;
    const rect = entry.modal.getBoundingClientRect();
    const resolvedLeft = Number.isFinite(Number(position?.left))
      ? Number(position.left)
      : (Number.isFinite(Number(entry.modal.dataset.windowLeft)) ? Number(entry.modal.dataset.windowLeft) : rect.left);
    const resolvedTop = Number.isFinite(Number(position?.top))
      ? Number(position.top)
      : (Number.isFinite(Number(entry.modal.dataset.windowTop)) ? Number(entry.modal.dataset.windowTop) : rect.top);
    const snapshot = {
      left: Math.round(resolvedLeft),
      top: Math.round(resolvedTop)
    };
    entry.lastModalPosition = snapshot;
    return snapshot;
  }

  function withSalesPurchaseAttachmentSync(callback){
    runtime.attachedWindowSyncDepth = Number(runtime.attachedWindowSyncDepth) || 0;
    runtime.attachedWindowSyncDepth += 1;
    try{
      return typeof callback === 'function' ? callback() : undefined;
    } finally {
      runtime.attachedWindowSyncDepth = Math.max(0, (Number(runtime.attachedWindowSyncDepth) || 1) - 1);
    }
  }

  function isSalesPurchaseAttachmentSyncActive(){
    return (Number(runtime.attachedWindowSyncDepth) || 0) > 0;
  }

  function setSalesPurchaseOwnerInteractionLocked(ownerEntry, shouldLock){
    if(!ownerEntry || !(ownerEntry.modal instanceof HTMLElement)) return;
    ownerEntry.modal.classList.toggle('is-attached-locked', !!shouldLock);
    ownerEntry.modal.dataset.attachedLocked = shouldLock ? 'true' : 'false';
  }

  function setSalesPurchaseAttachmentBackdropState(childEntry, isAttached){
    if(!childEntry || !(childEntry.backdrop instanceof HTMLElement)) return;
    childEntry.backdrop.classList.toggle('sales-purchase-modal-backdrop--attached-blocker', !!isAttached);
    childEntry.modal?.classList.toggle('is-attached-party-window', !!isAttached);
    if(isAttached) syncSalesPurchaseAttachedOwnerBlocker(childEntry);
    else resetSalesPurchaseAttachedOwnerBlocker(childEntry);
  }

  function releaseSalesPurchasePartyAttachment(childEntry){
    if(!isSalesPurchasePartyEntry(childEntry)) return;
    const previousOwnerEntry = getSalesPurchaseWindowEntry(childEntry.attachedOwnerWindowId || childEntry.ownerWindowId);
    if(previousOwnerEntry && toSafeText(previousOwnerEntry.attachedPartyWindowId) === toSafeText(childEntry.id)){
      previousOwnerEntry.attachedPartyWindowId = '';
      setSalesPurchaseOwnerInteractionLocked(previousOwnerEntry, false);
    }
    childEntry.attachedOwnerWindowId = '';
    setSalesPurchaseAttachmentBackdropState(childEntry, false);
  }

  function syncSalesPurchasePartyAttachment(childEntry){
    if(!isSalesPurchasePartyEntry(childEntry)) return;
    const nextOwnerId = toSafeText(childEntry.ownerWindowId);
    const previousOwnerId = toSafeText(childEntry.attachedOwnerWindowId);
    if(previousOwnerId && previousOwnerId !== nextOwnerId){
      const previousOwnerEntry = getSalesPurchaseWindowEntry(previousOwnerId);
      if(previousOwnerEntry && toSafeText(previousOwnerEntry.attachedPartyWindowId) === toSafeText(childEntry.id)){
        previousOwnerEntry.attachedPartyWindowId = '';
        setSalesPurchaseOwnerInteractionLocked(previousOwnerEntry, false);
      }
    }

    childEntry.attachedOwnerWindowId = '';
    setSalesPurchaseAttachmentBackdropState(childEntry, false);

    const ownerEntry = getSalesPurchaseWindowEntry(nextOwnerId);
    if(!ownerEntry || ownerEntry === childEntry || !(ownerEntry.modal instanceof HTMLElement)) return;

    childEntry.attachedOwnerWindowId = nextOwnerId;
    ownerEntry.attachedPartyWindowId = childEntry.id;
    setSalesPurchaseOwnerInteractionLocked(ownerEntry, true);
    setSalesPurchaseAttachmentBackdropState(childEntry, true);
    snapshotSalesPurchaseWindowPosition(ownerEntry);
    snapshotSalesPurchaseWindowPosition(childEntry);
  }

  function moveSalesPurchaseWindowByDelta(entry, deltaX, deltaY){
    if(!entry || !(entry.modal instanceof HTMLElement) || !entry.manager || typeof entry.manager.applyModalPosition !== 'function'){
      return { requestedDeltaX: Number(deltaX) || 0, requestedDeltaY: Number(deltaY) || 0, appliedDeltaX: 0, appliedDeltaY: 0 };
    }
    const current = snapshotSalesPurchaseWindowPosition(entry);
    const requestedDeltaX = Number(deltaX) || 0;
    const requestedDeltaY = Number(deltaY) || 0;
    entry.manager.applyModalPosition(entry.modal, current.left + requestedDeltaX, current.top + requestedDeltaY);
    const next = snapshotSalesPurchaseWindowPosition(entry);
    return {
      requestedDeltaX,
      requestedDeltaY,
      appliedDeltaX: next.left - current.left,
      appliedDeltaY: next.top - current.top
    };
  }

  function handleSalesPurchaseModalPositionApplied(modal, position){
    const entry = getSalesPurchaseWindowEntryByModal(modal);
    if(!entry) return;
    const previous = entry.lastModalPosition && Number.isFinite(Number(entry.lastModalPosition.left)) && Number.isFinite(Number(entry.lastModalPosition.top))
      ? { left: Number(entry.lastModalPosition.left), top: Number(entry.lastModalPosition.top) }
      : null;
    const current = snapshotSalesPurchaseWindowPosition(entry, position);
    if(isSalesPurchasePartyEntry(entry)) syncSalesPurchaseAttachedOwnerBlocker(entry);
    if(isSalesPurchaseAttachmentSyncActive() || !previous) return;

    const deltaX = current.left - previous.left;
    const deltaY = current.top - previous.top;
    if(!deltaX && !deltaY) return;

    if(isSalesPurchasePartyEntry(entry)){
      const ownerEntry = getSalesPurchaseAttachedPartyOwner(entry);
      if(!ownerEntry){
        syncSalesPurchaseAttachedOwnerBlocker(entry);
        return;
      }
      withSalesPurchaseAttachmentSync(() => {
        const ownerMove = moveSalesPurchaseWindowByDelta(ownerEntry, deltaX, deltaY);
        if(ownerMove.appliedDeltaX != deltaX || ownerMove.appliedDeltaY != deltaY){
          entry.manager.applyModalPosition(entry.modal, previous.left + ownerMove.appliedDeltaX, previous.top + ownerMove.appliedDeltaY);
        }
        syncSalesPurchaseAttachedOwnerBlocker(entry);
      });
      return;
    }

    const childEntry = getSalesPurchaseAttachedPartyChild(entry);
    if(!childEntry) return;
    withSalesPurchaseAttachmentSync(() => {
      moveSalesPurchaseWindowByDelta(childEntry, deltaX, deltaY);
      syncSalesPurchaseAttachedOwnerBlocker(childEntry);
    });
  }

  function resolveSalesPurchaseAttachedOwnerHeadHit(childEntry, clientX, clientY){
    if(!isSalesPurchasePartyEntry(childEntry) || !(childEntry.backdrop instanceof HTMLElement)) return null;
    const ownerEntry = getSalesPurchaseAttachedPartyOwner(childEntry);
    if(!ownerEntry || !(ownerEntry.modal instanceof HTMLElement)) return null;
    const ownerHead = ownerEntry.modal.querySelector('.sales-purchase-sheet__head');
    if(!(ownerHead instanceof HTMLElement)) return null;

    const previousBackdropPointerEvents = childEntry.backdrop.style.pointerEvents;
    const blocker = getSalesPurchaseAttachedOwnerBlocker(childEntry);
    const previousBlockerPointerEvents = blocker instanceof HTMLElement ? blocker.style.pointerEvents : '';
    childEntry.backdrop.style.pointerEvents = 'none';
    if(blocker instanceof HTMLElement) blocker.style.pointerEvents = 'none';
    let hitTarget = null;
    try{
      hitTarget = document.elementFromPoint(Number(clientX) || 0, Number(clientY) || 0);
    }catch{}
    childEntry.backdrop.style.pointerEvents = previousBackdropPointerEvents;
    if(blocker instanceof HTMLElement) blocker.style.pointerEvents = previousBlockerPointerEvents;

    if(!(hitTarget instanceof Element) || !ownerHead.contains(hitTarget)) return null;
    const closeButton = hitTarget.closest('[data-sales-purchase-action="close-window"]');
    const expandButton = hitTarget.closest('[data-sales-purchase-action="expand-window"]');
    return {
      ownerEntry,
      ownerHead,
      target: hitTarget,
      closeButton: closeButton instanceof HTMLElement && ownerEntry.modal.contains(closeButton) ? closeButton : null,
      expandButton: expandButton instanceof HTMLElement && ownerEntry.modal.contains(expandButton) ? expandButton : null
    };
  }

  function toggleSalesPurchaseAttachedOwnerWindow(ownerEntry){
    if(!ownerEntry || !(ownerEntry.modal instanceof HTMLElement) || !ownerEntry.manager) return false;
    const childEntry = getSalesPurchaseAttachedPartyChild(ownerEntry);
    if(!childEntry || !(childEntry.modal instanceof HTMLElement) || !childEntry.manager) return false;

    const shouldRestore = ownerEntry.modal.classList.contains('is-maximized') || childEntry.modal.classList.contains('is-maximized');
    withSalesPurchaseAttachmentSync(() => {
      if(shouldRestore){
        if(ownerEntry.modal.classList.contains('is-maximized')) ownerEntry.manager.restoreModalWindow(ownerEntry.modal);
        if(childEntry.modal.classList.contains('is-maximized')) childEntry.manager.restoreModalWindow(childEntry.modal);
        clearSalesPurchaseAttachedPartyMaximizedState(childEntry);
        childEntry.didMaximizeOwnerForAttachment = false;
        syncSalesPurchaseAttachedOwnerBlocker(childEntry);
        return;
      }

      ownerEntry.manager.maximizeModalWindow(ownerEntry.modal);
      childEntry.manager.maximizeModalWindow(childEntry.modal);
      applySalesPurchaseAttachedPartyMaximizedFrame(ownerEntry, childEntry);
      childEntry.didMaximizeOwnerForAttachment = true;
      syncSalesPurchaseAttachedOwnerBlocker(childEntry);
    });

    syncSalesPurchaseAttachedOwnerBlocker(childEntry);
    syncSalesPurchaseAttachedExpandButtons([ownerEntry, childEntry]);
    childEntry.manager.activateModalWindow(childEntry.backdrop);
    snapshotSalesPurchaseWindowPosition(ownerEntry);
    snapshotSalesPurchaseWindowPosition(childEntry);
    return true;
  }

  function startSalesPurchaseAttachedOwnerProxyDrag(childEntry, pointerEvent){
    if(!isSalesPurchasePartyEntry(childEntry) || !(pointerEvent instanceof PointerEvent)) return false;
    const ownerEntry = getSalesPurchaseAttachedPartyOwner(childEntry);
    if(!ownerEntry || !(ownerEntry.modal instanceof HTMLElement) || !ownerEntry.manager || typeof ownerEntry.manager.applyModalPosition !== 'function') return false;
    if(ownerEntry.modal.classList.contains('is-maximized')) return false;

    const rect = ownerEntry.modal.getBoundingClientRect();
    const origin = snapshotSalesPurchaseWindowPosition(ownerEntry);
    const bounds = typeof ownerEntry.manager.getModalViewportBoundsForSize === 'function'
      ? ownerEntry.manager.getModalViewportBoundsForSize(rect.width, rect.height)
      : null;
    const dragState = {
      pointerId: pointerEvent.pointerId,
      startX: pointerEvent.clientX,
      startY: pointerEvent.clientY,
      originLeft: Number(origin?.left) || rect.left,
      originTop: Number(origin?.top) || rect.top,
      bounds,
      hasMoved: false
    };

    const ownerBackdrop = ownerEntry.backdrop instanceof HTMLElement ? ownerEntry.backdrop : null;
    const childBackdrop = childEntry.backdrop instanceof HTMLElement ? childEntry.backdrop : null;

    const clearDragClasses = () => {
      ownerBackdrop?.classList.remove('is-dragging');
      childBackdrop?.classList.remove('is-dragging');
      document.body.classList.remove('sales-purchase--dragging-window');
    };

    const releaseDrag = (event = null) => {
      if(event && typeof event.pointerId === 'number' && dragState.pointerId !== event.pointerId) return;
      document.removeEventListener('pointermove', onPointerMove, true);
      document.removeEventListener('pointerup', onPointerUp, true);
      document.removeEventListener('pointercancel', onPointerUp, true);
      clearDragClasses();
      childEntry.consumeAttachedOwnerProxyClick = dragState.hasMoved;
    };

    const onPointerMove = (event) => {
      if(dragState.pointerId !== event.pointerId) return;
      const deltaX = event.clientX - dragState.startX;
      const deltaY = event.clientY - dragState.startY;
      if(!dragState.hasMoved && Math.hypot(deltaX, deltaY) < 2) return;
      if(!dragState.hasMoved){
        dragState.hasMoved = true;
        ownerBackdrop?.classList.add('is-dragging');
        childBackdrop?.classList.add('is-dragging');
        document.body.classList.add('sales-purchase--dragging-window');
      }
      event.preventDefault();
      const nextLeft = dragState.bounds
        ? Math.max(dragState.bounds.minLeft, Math.min(dragState.bounds.maxLeft, dragState.originLeft + deltaX))
        : (dragState.originLeft + deltaX);
      const nextTop = dragState.bounds
        ? Math.max(dragState.bounds.minTop, Math.min(dragState.bounds.maxTop, dragState.originTop + deltaY))
        : (dragState.originTop + deltaY);
      ownerEntry.manager.applyModalPosition(ownerEntry.modal, nextLeft, nextTop, dragState.bounds || undefined);
    };

    const onPointerUp = (event) => {
      releaseDrag(event);
    };

    document.addEventListener('pointermove', onPointerMove, true);
    document.addEventListener('pointerup', onPointerUp, true);
    document.addEventListener('pointercancel', onPointerUp, true);
    return true;
  }

  function handleSalesPurchaseAttachedOwnerHeadInteraction(childEntry, event){
    if(!isSalesPurchasePartyEntry(childEntry) || !(event instanceof Event)) return false;
    if(!(childEntry.backdrop instanceof HTMLElement) || !childEntry.backdrop.classList.contains('sales-purchase-modal-backdrop--attached-blocker')) return false;
    const pointerLikeEvent = event instanceof MouseEvent || event instanceof PointerEvent ? event : null;
    if(!pointerLikeEvent) return false;

    if(event.type === 'click' && childEntry.consumeAttachedOwnerProxyClick){
      childEntry.consumeAttachedOwnerProxyClick = false;
      event.preventDefault();
      event.stopPropagation();
      childEntry.manager?.activateModalWindow?.(childEntry.backdrop);
      return true;
    }

    const hit = resolveSalesPurchaseAttachedOwnerHeadHit(childEntry, pointerLikeEvent.clientX, pointerLikeEvent.clientY);
    if(!hit) return false;

    if(event.type === 'pointerdown'){
      event.preventDefault();
      event.stopPropagation();
      if(hit.closeButton || hit.expandButton){
        childEntry.manager?.activateModalWindow?.(childEntry.backdrop);
        return true;
      }
      startSalesPurchaseAttachedOwnerProxyDrag(childEntry, pointerLikeEvent);
      childEntry.manager?.activateModalWindow?.(childEntry.backdrop);
      return true;
    }

    if(event.type === 'click'){
      event.preventDefault();
      event.stopPropagation();
      if(hit.closeButton){
        closeSalesPurchaseWindow(hit.ownerEntry.id);
        return true;
      }
      if(hit.expandButton){
        toggleSalesPurchaseAttachedOwnerWindow(hit.ownerEntry);
        return true;
      }
      childEntry.manager?.activateModalWindow?.(childEntry.backdrop);
      return true;
    }

    return false;
  }

  function syncSalesPurchaseAttachedExpandButtons(entries){
    (Array.isArray(entries) ? entries : []).forEach((targetEntry) => {
      if(!targetEntry || !(targetEntry.backdrop instanceof HTMLElement) || !(targetEntry.modal instanceof HTMLElement)) return;
      const targetButton = targetEntry.backdrop.querySelector('[data-sales-purchase-action="expand-window"]');
      syncExpandButton(targetButton, targetEntry.modal);
    });
  }

  function resolveSalesPurchaseAttachedPartyMaximizedFrame(ownerEntry, childEntry){
    if(!ownerEntry || !childEntry || !(ownerEntry.modal instanceof HTMLElement) || !(childEntry.modal instanceof HTMLElement)) return null;
    const ownerRect = ownerEntry.modal.getBoundingClientRect();
    if(ownerRect.width < 80 || ownerRect.height < 80) return null;

    const insetX = Math.max(28, Math.min(56, Math.round(ownerRect.width * 0.045)));
    const insetTop = Math.max(22, Math.min(46, Math.round(ownerRect.height * 0.055)));
    const insetBottom = Math.max(24, Math.min(54, Math.round(ownerRect.height * 0.07)));

    const width = Math.max(320, Math.min(
      Math.round(ownerRect.width - (insetX * 2)),
      Math.round(ownerRect.width - 24)
    ));
    const height = Math.max(260, Math.min(
      Math.round(ownerRect.height - insetTop - insetBottom),
      Math.round(ownerRect.height - 24)
    ));

    return {
      left: Math.round(ownerRect.left + ((ownerRect.width - width) / 2)),
      top: Math.round(ownerRect.top + insetTop),
      width: Math.round(width),
      height: Math.round(height)
    };
  }

  function clearSalesPurchaseAttachedPartyMaximizedState(childEntry){
    if(!childEntry || !(childEntry.modal instanceof HTMLElement)) return;
    delete childEntry.modal.dataset.attachedPartyMaximized;
  }

  function applySalesPurchaseAttachedPartyMaximizedFrame(ownerEntry, childEntry){
    if(!ownerEntry || !childEntry || !(childEntry.modal instanceof HTMLElement) || !childEntry.manager) return false;
    const frame = resolveSalesPurchaseAttachedPartyMaximizedFrame(ownerEntry, childEntry);
    if(!frame) return false;

    childEntry.modal.style.width = `${frame.width}px`;
    childEntry.modal.style.maxWidth = `${frame.width}px`;
    childEntry.modal.style.height = `${frame.height}px`;
    childEntry.modal.style.maxHeight = `${frame.height}px`;
    childEntry.modal.classList.add('is-maximized');
    childEntry.modal.dataset.attachedPartyMaximized = 'true';

    if(typeof childEntry.manager.applyModalPosition === 'function'){
      childEntry.manager.applyModalPosition(childEntry.modal, frame.left, frame.top, {
        minLeft: frame.left,
        maxLeft: frame.left,
        minTop: frame.top,
        maxTop: frame.top
      });
    } else {
      childEntry.modal.style.left = `${frame.left}px`;
      childEntry.modal.style.top = `${frame.top}px`;
      childEntry.modal.dataset.windowLeft = String(frame.left);
      childEntry.modal.dataset.windowTop = String(frame.top);
      childEntry.modal.classList.add('is-positioned');
    }

    snapshotSalesPurchaseWindowPosition(ownerEntry);
    snapshotSalesPurchaseWindowPosition(childEntry);
    syncSalesPurchaseAttachedOwnerBlocker(childEntry);
    return true;
  }

  function syncSalesPurchaseAttachedMaximizedPair(entry){
    const childEntry = isSalesPurchasePartyEntry(entry) ? entry : getSalesPurchaseAttachedPartyChild(entry);
    const ownerEntry = isSalesPurchasePartyEntry(entry) ? getSalesPurchaseAttachedPartyOwner(entry) : entry;
    if(!ownerEntry || !childEntry || !(ownerEntry.modal instanceof HTMLElement) || !(childEntry.modal instanceof HTMLElement)) return false;

    const ownerIsMaximized = ownerEntry.modal.classList.contains('is-maximized');
    const childIsMaximized = childEntry.modal.classList.contains('is-maximized') || childEntry.modal.dataset.attachedPartyMaximized === 'true';
    if(!ownerIsMaximized && !childIsMaximized) return false;

    withSalesPurchaseAttachmentSync(() => {
      if(ownerIsMaximized && ownerEntry.manager && typeof ownerEntry.manager.syncModalWithinViewport === 'function'){
        ownerEntry.manager.syncModalWithinViewport(ownerEntry.modal);
      }
      if(childIsMaximized){
        applySalesPurchaseAttachedPartyMaximizedFrame(ownerEntry, childEntry);
      }
    });

    syncSalesPurchaseAttachedOwnerBlocker(childEntry);
    syncSalesPurchaseAttachedExpandButtons([ownerEntry, childEntry]);
    return true;
  }

  function syncExpandButton(button, modal){
    if(!(button instanceof HTMLElement) || !(modal instanceof HTMLElement)) return;
    if(typeof windowChrome.syncExpandButton === 'function'){
      windowChrome.syncExpandButton(button, modal.classList.contains('is-maximized'));
      return;
    }
    const isMaximized = modal.classList.contains('is-maximized');
    button.innerHTML = getWindowIcon(isMaximized ? 'collapse' : 'expand');
    button.setAttribute('aria-label', isMaximized ? 'استعادة الحجم المرجعي' : 'تكبير النافذة');
    button.setAttribute('title', isMaximized ? 'استعادة الحجم المرجعي' : 'تكبير النافذة');
    button.setAttribute('aria-pressed', isMaximized ? 'true' : 'false');
  }


  function createChoicePickerIcon(type){
    return CHOICE_PICKER_ICON_MARKUP[type] || '';
  }

  const toSafeText = toText;

  const SALES_PURCHASE_NAV_ICON_MARKUP = Object.freeze({
    prev: '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m7 4.5 5 5-5 5" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"></path></svg>',
    next: '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m13 4.5-5 5 5 5" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"></path></svg>',
    prev10: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m6.5 6 6 6-6 6" fill="none" stroke="currentColor" stroke-width="2.15" stroke-linecap="round" stroke-linejoin="round"></path><path d="m12.5 6 6 6-6 6" fill="none" stroke="currentColor" stroke-width="2.15" stroke-linecap="round" stroke-linejoin="round"></path></svg>',
    next10: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m17.5 6-6 6 6 6" fill="none" stroke="currentColor" stroke-width="2.15" stroke-linecap="round" stroke-linejoin="round"></path><path d="m11.5 6-6 6 6 6" fill="none" stroke="currentColor" stroke-width="2.15" stroke-linecap="round" stroke-linejoin="round"></path></svg>'
  });

  function cloneSalesPurchaseValue(value){
    if(value == null) return value;
    try{
      return JSON.parse(JSON.stringify(value));
    }catch{
      return value;
    }
  }

  function normalizeSalesPurchaseLookupDigits(value){
    return String(value || '')
      .replace(/[٠-٩]/g, (digit) => String(digit.charCodeAt(0) - 0x0660))
      .replace(/[۰-۹]/g, (digit) => String(digit.charCodeAt(0) - 0x06F0));
  }

  function normalizeSalesPurchasePageLookup(value){
    return normalizeSalesPurchaseLookupDigits(value).replace(/\D+/g, '').trim();
  }

  function createDefaultSalesPurchaseNavigatorState(){
    return {
      lookupValue:'',
      currentRecordIndex:null,
      currentRecordId:'',
      loadedRecordSnapshot:null
    };
  }

  function ensureSalesPurchaseNavigatorState(formState){
    if(!formState || typeof formState !== 'object') return createDefaultSalesPurchaseNavigatorState();
    const current = formState.navigator && typeof formState.navigator === 'object'
      ? cloneSalesPurchaseValue(formState.navigator)
      : {};
    formState.navigator = {
      ...createDefaultSalesPurchaseNavigatorState(),
      ...(current && typeof current === 'object' ? current : {})
    };
    if(typeof formState.navigator.lookupValue !== 'string') formState.navigator.lookupValue = '';
    formState.navigator.lookupValue = normalizeSalesPurchasePageLookup(formState.navigator.lookupValue);
    formState.navigator.currentRecordIndex = Number.isInteger(formState.navigator.currentRecordIndex)
      ? formState.navigator.currentRecordIndex
      : null;
    formState.navigator.currentRecordId = toSafeText(formState.navigator.currentRecordId);
    if(!formState.navigator.loadedRecordSnapshot || typeof formState.navigator.loadedRecordSnapshot !== 'object'){
      formState.navigator.loadedRecordSnapshot = null;
    }
    return formState.navigator;
  }

  function snapshotSalesPurchaseBaselineFormState(formState, actionId){
    const source = formState && typeof formState === 'object'
      ? formState
      : foundationFallbackCreateDefaultFormState(actionId);
    const cloned = cloneSalesPurchaseValue(source) || foundationFallbackCreateDefaultFormState(actionId);
    cloned.alertIssues = [];
    cloned.openPickerKey = null;
    cloned.datePickerOpen = false;
    cloned.datePickerView = 'days';
    cloned.lastChangedPickerKey = '';
    cloned.inlineNotice = null;
    cloned.navigator = createDefaultSalesPurchaseNavigatorState();
    if(!toSafeText(cloned.voucherDate)) cloned.voucherDate = foundationFallbackSalesPurchaseTodayInputValue();
    cloned.datePickerMonthCursor = foundationFallbackSalesPurchaseResolveMonthCursor(
      foundationFallbackSalesPurchaseNormalizeDateInputValue(cloned.voucherDate),
      cloned.datePickerMonthCursor || String(cloned.voucherDate).slice(0, 7)
    );
    return cloned;
  }

  function resolveSalesPurchaseEffectiveActionId(actionId, formState = null){
    const safeActionId = String(actionId || '').trim();
    return safeActionId === 'sale' ? 'sale' : 'purchase';
  }

  function normalizeSalesPurchaseActionOwnerId(value){
    const safeValue = String(value || '').trim();
    if(safeValue === 'sale') return 'sale';
    if(safeValue === 'purchase') return 'purchase';
    return '';
  }

  function resolveSalesPurchaseRecordOwnerActionId(record){
    const safeRecord = record && typeof record === 'object' ? record : {};
    const explicitOwnerActionId = normalizeSalesPurchaseActionOwnerId(
      safeRecord.ownerActionId
      || safeRecord.originActionId
      || safeRecord.windowActionId
    );
    if(explicitOwnerActionId) return explicitOwnerActionId;
    return String(safeRecord.type || '').trim() === 'sale' ? 'sale' : 'purchase';
  }

  function resolveSalesPurchaseWindowActionId(actionId, formState = null){
    return normalizeSalesPurchaseActionOwnerId(formState && formState.windowActionId)
      || normalizeSalesPurchaseActionOwnerId(actionId)
      || '';
  }

  function doesSalesPurchaseRecordMatchAction(actionId, record, formState = null){
    if(!record || typeof record !== 'object') return false;
    const safeType = resolveSalesPurchaseEffectiveActionId(actionId, formState);
    const safeWindowActionId = resolveSalesPurchaseWindowActionId(actionId, formState);
    const recordOwnerActionId = resolveSalesPurchaseRecordOwnerActionId(record);
    return record.type === safeType && recordOwnerActionId === safeWindowActionId;
  }

  function getSalesPurchaseNavigatorRecords(actionId, records = null, formState = null){
    const sourceRecords = Array.isArray(records) ? records : foundationFallbackReadSalesPurchaseState().records;
    return sourceRecords
      .filter((record) => doesSalesPurchaseRecordMatchAction(actionId, record, formState))
      .slice()
      .sort((left, right) => {
        const leftSequence = Number(left?.sequence) || 0;
        const rightSequence = Number(right?.sequence) || 0;
        if(leftSequence != rightSequence) return leftSequence - rightSequence;
        const leftCreatedAt = Number(left?.createdAt) || 0;
        const rightCreatedAt = Number(right?.createdAt) || 0;
        if(leftCreatedAt != rightCreatedAt) return leftCreatedAt - rightCreatedAt;
        return toSafeText(left?.id).localeCompare(toSafeText(right?.id), 'en');
      });
  }

  function resolveSalesPurchaseNavigatorActiveIndex(actionId, formState, records = null){
    const safeRecords = getSalesPurchaseNavigatorRecords(actionId, records, formState);
    const navigator = ensureSalesPurchaseNavigatorState(formState);
    const currentRecordId = toSafeText(navigator.currentRecordId);
    if(currentRecordId){
      const indexById = safeRecords.findIndex((record) => toSafeText(record?.id) === currentRecordId);
      if(indexById >= 0) return indexById;
    }
    const currentIndex = Number.isInteger(navigator.currentRecordIndex) ? navigator.currentRecordIndex : null;
    if(currentIndex != null && currentIndex >= 0 && currentIndex < safeRecords.length) return currentIndex;
    return null;
  }

  function buildSalesPurchaseNavigatorLoadedSnapshot(record){
    const safeRecord = record && typeof record === 'object' ? record : {};
    return {
      recordId: toSafeText(safeRecord.id),
      recordNumber: toSafeText(safeRecord.number),
      rateValue: Math.max(0, foundationFallbackToNumber(safeRecord.rateValue, 0)),
      rateText: toSafeText(safeRecord.rateText),
      amountValue: Math.max(0, foundationFallbackToNumber(safeRecord.amountValue, 0)),
      amountText: toSafeText(safeRecord.amountText),
      counterpartAmountValue: Math.max(0, foundationFallbackToNumber(safeRecord.counterpartAmountValue, 0)),
      counterpartAmountText: toSafeText(safeRecord.counterpartAmountText),
      rateMode: String(safeRecord.rateMode || '').trim() === 'manual' ? 'manual' : 'auto',
      manualRateText: foundationFallbackSanitizeNumericInput(safeRecord.manualRateText || ''),
      amountEntrySide: foundationFallbackNormalizeSalesPurchaseEditedAmountField(safeRecord.amountEntrySide),
      counterpartyName: toSafeText(safeRecord.counterpartyName),
      invoiceSummary: toSafeText(safeRecord.invoiceSummary || safeRecord.summary),
      documentNumber: toSafeText(safeRecord.documentNumber || safeRecord.documentNo),
      purchaseCalcMethod: String(safeRecord.purchaseCalcMethod || safeRecord.calcMethod || '').trim() === 'divide' ? 'divide' : 'multiply',
      createdAt: Number(safeRecord.createdAt) || 0
    };
  }


  function resolveSalesPurchaseNavigatorLinkedRecord(actionId, formState, records = null){
    const navigator = ensureSalesPurchaseNavigatorState(formState);
    const currentRecordId = toSafeText(navigator.currentRecordId);
    if(!currentRecordId) return null;
    const sourceRecords = Array.isArray(records) ? records : foundationFallbackReadSalesPurchaseState().records;
    const matchedRecord = (Array.isArray(sourceRecords) ? sourceRecords : []).find((record) => {
      return doesSalesPurchaseRecordMatchAction(actionId, record, formState) && toSafeText(record.id) === currentRecordId;
    }) || null;
    return matchedRecord ? foundationFallbackNormalizeSalesPurchaseRecord(matchedRecord) : null;
  }

  function isSalesPurchaseEditingExistingRecord(actionId, formState, records = null){
    return !!resolveSalesPurchaseNavigatorLinkedRecord(actionId, formState, records);
  }

  Object.assign(feature, {
    runtime,
    ACCOUNT_STORAGE_KEY,
    CASH_BOX_STORAGE_KEY,
    ENTRIES_STORAGE_KEY,
    SALES_PURCHASE_STORAGE_KEY,
    SALES_PURCHASE_UPDATED_EVENT,
    DEFAULT_ENTRIES_COUNTERS,
    SALES_PURCHASE_BALANCE_EPSILON,
    CHOICE_PICKER_ICON_MARKUP,
    DELETE_ICON_MARKUP,
    DATE_PICKER_MONTH_NAMES,
    DATE_PICKER_WEEKDAY_LABELS,
    DATE_PICKER_ICON_MARKUP,
    DATE_PICKER_CHEVRON_PREV_MARKUP,
    DATE_PICKER_CHEVRON_NEXT_MARKUP,
    ACTIONS,
    SALES_PURCHASE_RECORD_COLUMNS,
    SALES_PURCHASE_PARTY_PHONE_COUNTRY_FIELD_KEY,
    SALES_PURCHASE_NAV_ICON_MARKUP,
    toSafeText,
    normalizeSalesPurchaseRecordDateFilterValue,
    normalizeSalesPurchaseRecordDateFilterRange,
    getWindowIcon,
    getChevronDownIcon,
    getTrackArrowIcon,
    renderSalesPurchasePartyAvatarMarkup,
    getSalesPurchasePartyCustomerApi,
    createSalesPurchasePartyEmptyDraft,
    normalizeSalesPurchasePartyDraft,
    createDefaultSalesPurchasePartyUiState,
    ensureSalesPurchasePartyState,
    getSalesPurchasePartyGroups,
    getSalesPurchasePartyOptions,
    getSalesPurchasePartyPhoneCountryCatalog,
    getSalesPurchasePartyPhoneCountryMeta,
    normalizeSalesPurchasePartyPhoneCountrySearch,
    getSalesPurchasePartyPhoneCountryOptions,
    createSalesPurchasePartyPhoneCountryFlagMarkup,
    renderSalesPurchasePartyPhoneCountryTriggerValue,
    renderSalesPurchasePartyPhoneCountryOptionMarkup,
    renderSalesPurchasePartyPhoneCountryOptionsMarkup,
    isSalesPurchasePartyChoiceOpen,
    isSalesPurchasePartyDateOpen,
    renderSalesPurchasePartyChoiceValue,
    renderSalesPurchasePartySegmentedMarkup,
    renderSalesPurchasePartyChoicePickerMarkup,
    resolveSalesPurchasePartyDateMonthCursor,
    renderSalesPurchasePartyDateDayButton,
    renderSalesPurchasePartyDateMonthButton,
    renderSalesPurchasePartyDatePickerMarkup,
    renderSalesPurchasePartyPhoneFieldMarkup,
    renderSalesPurchasePartyInputMarkup,
    renderSalesPurchasePartyFieldMarkup,
    splitSalesPurchasePartyGroupFields,
    renderSalesPurchasePartyInlineRowMarkup,
    renderSalesPurchasePartyGroupMarkup,
    renderSalesPurchasePartyWindow,
    syncSalesPurchasePartyLinkedName,
    getSalesPurchaseWindowEntry,
    getSalesPurchaseWindowEntryByModal,
    isSalesPurchasePartyEntry,
    resolveSalesPurchaseWindowAction,
    resolveSalesPurchaseWindowInstanceId,
    getSalesPurchaseAttachedOwnerBlocker,
    resetSalesPurchaseAttachedOwnerBlocker,
    syncSalesPurchaseAttachedOwnerBlocker,
    getSalesPurchaseAttachedPartyOwner,
    getSalesPurchaseAttachedPartyChild,
    snapshotSalesPurchaseWindowPosition,
    withSalesPurchaseAttachmentSync,
    isSalesPurchaseAttachmentSyncActive,
    setSalesPurchaseOwnerInteractionLocked,
    setSalesPurchaseAttachmentBackdropState,
    releaseSalesPurchasePartyAttachment,
    syncSalesPurchasePartyAttachment,
    moveSalesPurchaseWindowByDelta,
    handleSalesPurchaseModalPositionApplied,
    resolveSalesPurchaseAttachedOwnerHeadHit,
    toggleSalesPurchaseAttachedOwnerWindow,
    startSalesPurchaseAttachedOwnerProxyDrag,
    handleSalesPurchaseAttachedOwnerHeadInteraction,
    syncSalesPurchaseAttachedExpandButtons,
    resolveSalesPurchaseAttachedPartyMaximizedFrame,
    clearSalesPurchaseAttachedPartyMaximizedState,
    applySalesPurchaseAttachedPartyMaximizedFrame,
    syncSalesPurchaseAttachedMaximizedPair,
    syncExpandButton,
    createChoicePickerIcon,
    cloneSalesPurchaseValue,
    normalizeSalesPurchaseLookupDigits,
    normalizeSalesPurchasePageLookup,
    createDefaultSalesPurchaseNavigatorState,
    ensureSalesPurchaseNavigatorState,
    snapshotSalesPurchaseBaselineFormState,
    resolveSalesPurchaseEffectiveActionId,
    normalizeSalesPurchaseActionOwnerId,
    resolveSalesPurchaseRecordOwnerActionId,
    resolveSalesPurchaseWindowActionId,
    doesSalesPurchaseRecordMatchAction,
    getSalesPurchaseNavigatorRecords,
    resolveSalesPurchaseNavigatorActiveIndex,
    buildSalesPurchaseNavigatorLoadedSnapshot,
    resolveSalesPurchaseNavigatorLinkedRecord,
    isSalesPurchaseEditingExistingRecord,
  });
})();
