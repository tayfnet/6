(() => {
  const TAIF = window.TAIF;
  const { escapeHtml, wrapControlTextMarkup, mountSteppedFitClasses } = TAIF.core.utils;
  const api = TAIF.chartOfAccounts = TAIF.chartOfAccounts || {};
  const internal = api.internal && typeof api.internal === 'object' ? api.internal : {};
  api.internal = internal;
  const {
    runtime,
    sharedState,
    getCenterImageSrc,
    toText,
    typeLabel,
    isCenterDeletionLocked,
    getCenterDeletionBlockedMessage,
    getCenters,
    getSelectedCenter,
    setSelected,
    getCenterFilterText,
    filterActiveCenters,
    ensureCenterImageFallbackHandling,
    hydrateCenterImages,
    createCoaChoicePickerMarkup,
    mountCoaChoicePicker,
    focusElementSafely,
    clampNumber,
    formatDateTime
  } = internal;

  const DEFAULT_PAGE_SIZE = 10;
  const PAGE_SIZE_OPTIONS = Object.freeze([10, 25, 50, 100]);
  const PAGE_SIZE_CHOICE_OPTIONS = Object.freeze(PAGE_SIZE_OPTIONS.map((size) => Object.freeze({ value:String(size), label:`عرض ${size}` })));
  const SEARCH_INPUT_SELECTOR = '[data-coa-action="search-centers"]';
  const CLEAR_SEARCH_SELECTOR = '[data-coa-action="clear-search"]';
  const PREV_PAGE_SELECTOR = '[data-coa-action="page-prev"]';
  const NEXT_PAGE_SELECTOR = '[data-coa-action="page-next"]';
  const PAGE_SIZE_INPUT_SELECTOR = '#coa-page-size-input';
  const PAGE_SIZE_TRIGGER_SELECTOR = '#coa-page-size-trigger';

  function normalizePageSize(value){
    const numericValue = Number(value) || 0;
    return PAGE_SIZE_OPTIONS.includes(numericValue) ? numericValue : DEFAULT_PAGE_SIZE;
  }

  function normalizePageNumber(value, totalPages){
    const safeTotalPages = Math.max(0, Number(totalPages) || 0);
    if(!safeTotalPages) return 0;
    return clampNumber(Number(value) || 1, 1, safeTotalPages);
  }

  function resolvePaginationModel(centers){
    const safeCenters = Array.isArray(centers) ? centers : [];
    const pageSize = normalizePageSize(runtime.pageSize);
    const totalItems = safeCenters.length;
    const totalPages = totalItems ? Math.ceil(totalItems / pageSize) : 0;
    const currentPage = normalizePageNumber(runtime.page, totalPages);
    const startIndex = currentPage ? (currentPage - 1) * pageSize : 0;
    const endIndex = currentPage ? Math.min(totalItems, startIndex + pageSize) : 0;

    runtime.pageSize = pageSize;
    runtime.page = totalPages ? currentPage : 1;

    return {
      items: currentPage ? safeCenters.slice(startIndex, endIndex) : [],
      pageSize,
      totalItems,
      totalPages,
      currentPage,
      hasPrevious: currentPage > 1,
      hasNext: currentPage > 0 && currentPage < totalPages
    };
  }


  function pagerButtonIconMarkup(direction){
    if(direction === 'next'){
      return '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13 4.5 7.5 10 13 15.5"></path></svg>';
    }

    return '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 4.5 12.5 10 7 15.5"></path></svg>';
  }

  function pageCounterMarkup(pageModel){
    if(pageModel.totalItems <= 0){
      return wrapControlTextMarkup('<b>0</b> / <b>0</b>');
    }

    return wrapControlTextMarkup(`<b>${pageModel.currentPage}</b> / <b>${pageModel.totalPages}</b>`);
  }

  function pageSizePickerMarkup(pageModel){
    if(typeof createCoaChoicePickerMarkup !== 'function') return '';

    return createCoaChoicePickerMarkup({
      pickerDataAttribute:'data-coa-page-size-picker',
      triggerId:'coa-page-size-trigger',
      inputId:'coa-page-size-input',
      fieldName:'pageSize',
      valueDataAttribute:'data-coa-page-size-value',
      value:String(pageModel.pageSize),
      options:PAGE_SIZE_CHOICE_OPTIONS,
      placeholder:`عرض ${DEFAULT_PAGE_SIZE}`,
      fallbackValue:String(DEFAULT_PAGE_SIZE)
    });
  }

  function toolbarPagerMarkup(pageModel){
    return `
      <div class="chart-accounts__toolbar-group chart-accounts__toolbar-group--pager" aria-label="التنقل بين صفحات شجرة الحسابات">
        <div class="chart-accounts__pager-shell">
          <button class="chart-accounts__pager-btn coa-btn" type="button" data-coa-action="page-prev" aria-label="الصفحة السابقة" title="الصفحة السابقة"${pageModel.hasPrevious ? '' : ' disabled'}>
            <span class="chart-accounts__pager-icon">${pagerButtonIconMarkup('prev')}</span>
            <span class="taif-control-text">السابق</span>
          </button>
          <span class="chart-accounts__pager-chip" data-coa-slot="page-counter" title="رقم الصفحة الحالية من إجمالي الصفحات">${pageCounterMarkup(pageModel)}</span>
          <div class="chart-accounts__pager-size" title="عدد المراكز المعروضة في الصفحة">${pageSizePickerMarkup(pageModel)}</div>
          <button class="chart-accounts__pager-btn coa-btn" type="button" data-coa-action="page-next" aria-label="الصفحة التالية" title="الصفحة التالية"${pageModel.hasNext ? '' : ' disabled'}>
            <span class="taif-control-text">التالي</span>
            <span class="chart-accounts__pager-icon">${pagerButtonIconMarkup('next')}</span>
          </button>
        </div>
      </div>
    `;
  }

  function runToolbarCleanup(){
    if(typeof runtime.toolbarCleanup === 'function'){
      try{
        runtime.toolbarCleanup();
      }catch{}
    }
    runtime.toolbarCleanup = null;
  }

  function mountTopbarAdaptiveFit(panel){
    const topbar = panel.querySelector('.chart-accounts__toolbar--top');
    const tools = topbar && topbar.querySelector('.chart-accounts__toolbar-group--full');
    const pager = topbar && topbar.querySelector('.chart-accounts__toolbar-group--pager');
    if(!(topbar instanceof HTMLElement) || !(tools instanceof HTMLElement) || !(pager instanceof HTMLElement) || typeof mountSteppedFitClasses !== 'function') return () => {};

    const queueFit = () => {
      if(!topbar || !topbar.isConnected) return;
      topbar.__coaQueueFit = queueFit;
    };

    const cleanup = mountSteppedFitClasses({
      element: topbar,
      fitClasses: ['is-fit-1', 'is-fit-2', 'is-fit-3', 'is-fit-4'],
      observedElements: [tools, pager],
      fitsLayout(){
        const tolerance = 2;
        const toolsFits = tools.scrollWidth <= (tools.clientWidth + tolerance);
        const pagerFits = pager.scrollWidth <= (pager.clientWidth + tolerance);
        const topbarFits = topbar.scrollWidth <= (topbar.clientWidth + tolerance);
        return toolsFits && pagerFits && topbarFits;
      },
      onQueue: queueFit,
      onDispose(){
        if(topbar.__coaQueueFit === queueFit){
          try{ delete topbar.__coaQueueFit; }catch{ topbar.__coaQueueFit = null; }
        }
      }
    });

    queueFit();
    return cleanup;
  }

  function avatarMarkup(center){
    const imageSrc = getCenterImageSrc(center && center.imageDataUrl);
    return `<div class="chart-accounts__avatar"><img data-coa-center-image="true" src="${escapeHtml(imageSrc)}" alt="" draggable="false" loading="eager" decoding="async"></div>`;
  }

  function selectionDotMarkup(isActive){
    return `<span class="chart-accounts__state-slot"><span class="chart-accounts__state-dot${isActive ? ' is-active' : ''}" aria-hidden="true"></span></span>`;
  }

  function centerRowActionIconMarkup(action){
    if(action === 'edit'){
      return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"></path><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"></path></svg>';
    }

    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18"></path><path d="M8 6V4h8v2"></path><path d="M19 6l-1 14H6L5 6"></path><path d="M10 11v6M14 11v6"></path></svg>';
  }

  function centerRowActionsMarkup(center){
    const centerId = escapeHtml(center && center.id);
    const centerName = escapeHtml(toText(center && center.name, 'هذا المركز'));
    const deletionLocked = isCenterDeletionLocked(center);
    const archiveButtonTitle = escapeHtml(deletionLocked ? getCenterDeletionBlockedMessage(center) : 'حذف المركز');
    return `
      <div class="chart-accounts__actions" role="group" aria-label="إجراءات ${centerName}">
        <button class="chart-accounts__iconbtn" type="button" data-coa-row-action="edit" data-center-id="${centerId}" aria-label="تعديل ${centerName}" title="تعديل المركز">
          ${centerRowActionIconMarkup('edit')}
        </button>
        <button class="chart-accounts__iconbtn chart-accounts__iconbtn--danger chart-accounts__iconbtn--archive${deletionLocked ? ' is-disabled' : ''}" type="button" data-coa-row-action="archive" data-center-id="${centerId}" aria-label="${escapeHtml(deletionLocked ? `لا يمكن حذف ${toText(center && center.name, 'هذا المركز')}` : `حذف ${toText(center && center.name, 'هذا المركز')}`)}" title="${archiveButtonTitle}"${deletionLocked ? ' disabled aria-disabled="true" data-coa-protected-delete="true"' : ''}>
          ${centerRowActionIconMarkup('archive')}
        </button>
      </div>
    `;
  }

  function centerCreatedAtMarkup(center){
    const createdAtText = escapeHtml(formatDateTime(center && (center.createdAt || center.updatedAt)));
    return `<span class="chart-accounts__created-at" title="${createdAtText}">${createdAtText}</span>`;
  }

  const TABLE_COLUMNS = [
    {
      colClass:'chart-accounts__col chart-accounts__col--state',
      headClass:'chart-accounts__state-head chart-accounts__col-head chart-accounts__col-head--state',
      headLabel:'',
      headAttrs:' aria-label="حالة التحديد"',
      renderCell:(_center, { isSelected }) => (
        `<td class="chart-accounts__state-cell">${selectionDotMarkup(isSelected)}</td>`
      )
    },
    {
      colClass:'chart-accounts__col chart-accounts__col--avatar',
      headClass:'chart-accounts__col-head chart-accounts__col-head--avatar',
      headLabel:'صورة المركز',
      renderCell:(center) => (
        `<td class="chart-accounts__avatar-cell chart-accounts__cell--avatar">${avatarMarkup(center)}</td>`
      )
    },
    {
      colClass:'chart-accounts__col chart-accounts__col--account',
      headClass:'chart-accounts__col-head chart-accounts__col-head--account',
      headLabel:'رقم حساب المركز',
      renderCell:(center) => (
        `<td class="chart-accounts__cell--account"><span class="chart-accounts__account">${wrapControlTextMarkup(escapeHtml(center.accountNo || '—'), 'taif-control-text--ltr')}</span></td>`
      )
    },
    {
      colClass:'chart-accounts__col chart-accounts__col--name',
      headClass:'chart-accounts__col-head chart-accounts__col-head--name',
      headLabel:'اسم المركز',
      renderCell:(center) => (
        `<td class="chart-accounts__cell--name"><div class="chart-accounts__name-wrap"><div class="chart-accounts__name">${escapeHtml(center.name)}</div></div></td>`
      )
    },
    {
      colClass:'chart-accounts__col chart-accounts__col--type',
      headClass:'chart-accounts__col-head chart-accounts__col-head--type',
      headLabel:'نوع مركز',
      renderCell:(center) => (
        `<td class="chart-accounts__cell--type"><span class="chart-accounts__type chart-accounts__type--${escapeHtml(center.centerType)}">${wrapControlTextMarkup(escapeHtml(typeLabel(center)))}</span></td>`
      )
    },
    {
      colClass:'chart-accounts__col chart-accounts__col--location',
      headClass:'chart-accounts__col-head chart-accounts__col-head--location',
      headLabel:'الدولة / المدينة',
      renderCell:(_center, { locationMain }) => (
        `<td class="chart-accounts__cell--location"><div class="chart-accounts__location"><div class="chart-accounts__location-main">${escapeHtml(locationMain)}</div></div></td>`
      )
    },
    {
      colClass:'chart-accounts__col chart-accounts__col--phone',
      headClass:'chart-accounts__col-head chart-accounts__col-head--phone',
      headLabel:'رقم الهاتف',
      renderCell:(center) => (
        `<td class="chart-accounts__cell--phone"><span class="chart-accounts__phone">${wrapControlTextMarkup(escapeHtml(center.phone || '—'), 'taif-control-text--ltr')}</span></td>`
      )
    },
    {
      colClass:'chart-accounts__col chart-accounts__col--address',
      headClass:'chart-accounts__col-head chart-accounts__col-head--address',
      headLabel:'عنوان المركز',
      renderCell:(center) => (
        `<td class="chart-accounts__cell--address"><div class="chart-accounts__address"><div class="chart-accounts__address-main">${escapeHtml(center.address || '—')}</div></div></td>`
      )
    },
    {
      colClass:'chart-accounts__col chart-accounts__col--created-at',
      headClass:'chart-accounts__col-head chart-accounts__col-head--created-at',
      headLabel:'تاريخ الإنشاء',
      renderCell:(center) => (
        `<td class="chart-accounts__cell--created-at">${centerCreatedAtMarkup(center)}</td>`
      )
    },
    {
      colClass:'chart-accounts__col chart-accounts__col--actions',
      headClass:'chart-accounts__col-head chart-accounts__col-head--actions',
      headLabel:'إجراءات',
      renderCell:(center) => (
        `<td class="chart-accounts__cell--actions">${centerRowActionsMarkup(center)}</td>`
      )
    }
  ];

  const EMPTY_STATE_MARKUP = '<div class="chart-accounts__empty"><div class="chart-accounts__empty-box"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5h16v14H4z"></path><path d="M8 9h8"></path><path d="M8 13h5"></path></svg><div>لا توجد مراكز نشطة حتى الآن.</div><div>ابدأ بإضافة مركز جديد لتجهيز شجرة الحسابات لهذه المرحلة.</div></div></div>';
  const EMPTY_FILTER_STATE_MARKUP = '<div class="chart-accounts__empty"><div class="chart-accounts__empty-box"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"></circle><path d="m20 20-3.5-3.5"></path></svg><div>لا توجد نتائج مطابقة للبحث الحالي.</div><div>جرّب اسم مركز آخر أو رقم حساب مختلف.</div></div></div>';

  function buildTableMarkup(activeCenters, filterText = ''){
    if(!activeCenters.length) return filterText ? EMPTY_FILTER_STATE_MARKUP : EMPTY_STATE_MARKUP;

    const colgroupMarkup = TABLE_COLUMNS
      .map((column) => `<col class="${column.colClass}">`)
      .join('');

    const headMarkup = TABLE_COLUMNS
      .map((column) => `<th class="${column.headClass}"${column.headAttrs || ''}>${column.headLabel}</th>`)
      .join('');

    const rowsMarkup = activeCenters.map((center) => {
      const isSelected = sharedState.selectedId === center.id;
      const rowClass = isSelected ? ' class="chart-accounts__row--selected"' : '';
      const viewModel = {
        isSelected,
        locationMain:[center.country || '—', center.city || '—'].join(' / ')
      };

      const cellsMarkup = TABLE_COLUMNS
        .map((column) => column.renderCell(center, viewModel))
        .join('');

      return `<tr${rowClass} data-center-id="${escapeHtml(center.id)}">${cellsMarkup}</tr>`;
    }).join('');

    return `
      <div class="chart-accounts__table-head-shell" aria-hidden="true">
        <div class="chart-accounts__table-head-viewport" data-coa-slot="table-head-viewport">
          <table class="chart-accounts__table chart-accounts__table--head" role="presentation">
            <colgroup>${colgroupMarkup}</colgroup>
            <thead><tr>${headMarkup}</tr></thead>
          </table>
        </div>
      </div>
      <div class="chart-accounts__table-scroll" data-coa-slot="table-scroll">
        <table class="chart-accounts__table chart-accounts__table--body" role="table" aria-label="جدول المراكز">
          <colgroup>${colgroupMarkup}</colgroup>
          <tbody>${rowsMarkup}</tbody>
        </table>
      </div>
    `;
  }

  function syncToolbar(panel){
    const selected = getSelectedCenter();
    if(!selected) sharedState.selectedId = null;

    const selectedChip = panel.querySelector('[data-coa-slot="selected-name"]');
    if(selectedChip){
      selectedChip.innerHTML = selected
        ? wrapControlTextMarkup(`المحدد: <b>${escapeHtml(selected.name)}</b>`)
        : wrapControlTextMarkup('المحدد: <b>لا يوجد</b>');
    }

    const topbar = panel.querySelector('.chart-accounts__toolbar--top');
    if(topbar && typeof topbar.__coaQueueFit === 'function'){
      topbar.__coaQueueFit();
    }
  }

  function syncSelectionState(panel){
    if(!(panel instanceof Element)) return;

    const chartRoot = panel.querySelector('.chart-accounts');
    if(!(chartRoot instanceof Element)) return;

    chartRoot.querySelectorAll('tr[data-center-id]').forEach((row) => {
      const isSelected = !!sharedState.selectedId && row.getAttribute('data-center-id') === sharedState.selectedId;
      row.classList.toggle('chart-accounts__row--selected', isSelected);
      const stateDot = row.querySelector('.chart-accounts__state-dot');
      if(stateDot) stateDot.classList.toggle('is-active', isSelected);
    });

    syncToolbar(panel);
  }

  function clearSelection(panel){
    if(!sharedState.selectedId) return;
    sharedState.selectedId = null;
    syncSelectionState(panel);
  }

  function detachSelectionDismiss(){
    if(typeof runtime.selectionDismissHandler === 'function'){
      document.removeEventListener('click', runtime.selectionDismissHandler, true);
    }
    runtime.selectionDismissHandler = null;
  }

  function bindSelectionDismiss(panel){
    if(!(panel instanceof Element)) return;
    detachSelectionDismiss();

    const handler = (event) => {
      if(!sharedState.selectedId) return;

      const activePanel = runtime.panel;
      if(!(activePanel instanceof Element) || !activePanel.isConnected){
        detachSelectionDismiss();
        return;
      }

      const target = event.target;
      if(!(target instanceof Element)) return;

      const chartRoot = activePanel.querySelector('.chart-accounts');
      if(!(chartRoot instanceof Element)) return;

      const row = target.closest('tr[data-center-id]');
      if(row && chartRoot.contains(row)) return;

      clearSelection(activePanel);
    };

    runtime.selectionDismissHandler = handler;
    document.addEventListener('click', handler, true);
  }

  function renderShell(panel){
    runtime.panel = panel;
    runToolbarCleanup();

    const previousTableScroll = panel instanceof Element
      ? panel.querySelector('[data-coa-slot="table-scroll"]')
      : null;
    const preservedTableScrollTop = previousTableScroll ? previousTableScroll.scrollTop : 0;
    const preservedTableScrollLeft = previousTableScroll ? previousTableScroll.scrollLeft : 0;
    const shouldResetTableScroll = !!runtime.resetTableScrollPosition;
    runtime.resetTableScrollPosition = false;

    const activeCenters = getCenters(true);
    const filterText = getCenterFilterText();
    const filteredCenters = filterActiveCenters(activeCenters, filterText);
    let selected = getSelectedCenter();

    if(selected && !filteredCenters.some((center) => center.id === selected.id)){
      sharedState.selectedId = null;
      selected = null;
    }

    const pageModel = resolvePaginationModel(filteredCenters);
    const searchValue = escapeHtml(runtime.filter || '');
    const searchClearHidden = runtime.filter ? '' : ' hidden';

    panel.innerHTML = `
      <div class="chart-accounts">
        <div class="chart-accounts__toolbar chart-accounts__toolbar--top" role="toolbar" aria-label="إجراءات شجرة الحسابات">
          <div class="chart-accounts__toolbar-group chart-accounts__toolbar-group--full">
            <div class="chart-accounts__toolbar-search">
              <div class="chart-accounts__search-wrap">
                <input class="chart-accounts__search-input" type="search" placeholder="ابحث باسم المركز أو رقم الحساب" value="${searchValue}" data-coa-action="search-centers" autocomplete="off" spellcheck="false" aria-label="بحث داخل شجرة الحسابات">
                <button class="chart-accounts__search-clear" type="button" data-coa-action="clear-search" data-taif-clear-control="true" aria-label="مسح البحث"${searchClearHidden}>
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
                </button>
              </div>
            </div>
            <button class="chart-accounts__toolbar-btn coa-btn coa-btn--success" type="button" data-coa-action="add-center"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14"></path><path d="M5 12h14"></path></svg><span class="taif-control-text">إضافة مركز</span></button>
            <button class="chart-accounts__toolbar-btn coa-btn coa-btn--danger" type="button" data-coa-action="open-deleted"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M8 6V4h8v2"></path><path d="M19 6l-1 14H6L5 6"></path></svg><span class="taif-control-text">المراكز المحذوفة</span></button>
            <span class="chart-accounts__chip chart-accounts__chip--selected" data-coa-slot="selected-name">${wrapControlTextMarkup(`المحدد: <b>${selected ? escapeHtml(selected.name) : 'لا يوجد'}</b>`)}</span>
          </div>
          ${toolbarPagerMarkup(pageModel)}
        </div>
        <div class="chart-accounts__table-shell">
          ${buildTableMarkup(pageModel.items, filterText)}
        </div>
        <div class="chart-accounts__toolbar chart-accounts__toolbar--bottom" aria-label="شريط إجراءات سفلي">
          <div class="chart-accounts__placeholder">شريط سفلي ثابت محجوز لإجراءات إضافية مستقبلية داخل شجرة الحسابات.</div>
        </div>
      </div>
    `;

    const toolbarCleanups = [];
    const registerToolbarCleanup = (cleanup) => {
      if(typeof cleanup === 'function') toolbarCleanups.push(cleanup);
    };
    runtime.toolbarCleanup = () => {
      while(toolbarCleanups.length){
        const cleanup = toolbarCleanups.pop();
        try{
          cleanup();
        }catch{}
      }
    };

    syncToolbar(panel);
    registerToolbarCleanup(mountTopbarAdaptiveFit(panel));
    ensureCenterImageFallbackHandling(panel);
    hydrateCenterImages(panel);

    const chartRoot = panel.querySelector('.chart-accounts');
    if(chartRoot instanceof HTMLElement && typeof mountCoaChoicePicker === 'function' && typeof createCoaChoicePickerMarkup === 'function'){
      mountCoaChoicePicker({
        modal: panel,
        scrollArea: chartRoot,
        pickerSelector:'[data-coa-page-size-picker]',
        triggerSelector:'#coa-page-size-trigger',
        inputSelector:'#coa-page-size-input',
        valueSelector:'[data-coa-page-size-value]',
        options:PAGE_SIZE_CHOICE_OPTIONS,
        ariaLabel:'عدد المراكز المعروضة في الصفحة',
        registerCleanup:registerToolbarCleanup,
        maxPopoverHeight:216,
        placeholder:`عرض ${DEFAULT_PAGE_SIZE}`,
        fallbackValue:String(pageModel.pageSize)
      });
    }

    const tableShell = panel.querySelector('.chart-accounts__table-shell');
    const tableHeadViewport = panel.querySelector('[data-coa-slot="table-head-viewport"]');
    const tableScroll = panel.querySelector('[data-coa-slot="table-scroll"]');
    if(tableShell instanceof HTMLElement && tableHeadViewport instanceof HTMLElement && tableScroll instanceof HTMLElement){
      const syncTableHeadViewport = () => {
        tableHeadViewport.scrollLeft = tableScroll.scrollLeft;
        const scrollbarWidth = Math.max(0, tableScroll.offsetWidth - tableScroll.clientWidth);
        tableShell.style.setProperty('--coa-body-scrollbar-offset', `${scrollbarWidth}px`);
      };

      syncTableHeadViewport();
      const handleTableScroll = () => syncTableHeadViewport();
      tableScroll.addEventListener('scroll', handleTableScroll, { passive:true });
      registerToolbarCleanup(() => tableScroll.removeEventListener('scroll', handleTableScroll));

      if(typeof ResizeObserver === 'function'){
        const resizeObserver = new ResizeObserver(() => syncTableHeadViewport());
        resizeObserver.observe(tableShell);
        resizeObserver.observe(tableScroll);
        registerToolbarCleanup(() => resizeObserver.disconnect());
      } else {
        window.addEventListener('resize', syncTableHeadViewport, { passive:true });
        registerToolbarCleanup(() => window.removeEventListener('resize', syncTableHeadViewport));
      }
    }

    if(tableScroll){
      tableScroll.addEventListener('click', (event) => {
        const target = event.target instanceof Element ? event.target : null;
        if(!target) return;

        const actionButton = target.closest('[data-coa-row-action]');
        if(actionButton){
          const centerId = actionButton.getAttribute('data-center-id');
          if(!centerId) return;

          setSelected(centerId);
          syncSelectionState(panel);
          const actionRow = actionButton.closest('tr[data-center-id]');
          if(actionRow && typeof actionRow.scrollIntoView === 'function'){
            actionRow.scrollIntoView({ block:'nearest', inline:'nearest' });
          }

          const action = actionButton.getAttribute('data-coa-row-action');
          if(action === 'edit'){
            internal.openCenterEditor(panel, centerId);
            return;
          }

          if(action === 'archive'){
            const center = getCenters(true).find((item) => item.id === centerId) || null;
            if(isCenterDeletionLocked(center)){
              internal.showToast?.(getCenterDeletionBlockedMessage(center));
              return;
            }
            internal.requestArchiveCenter(panel, centerId);
            return;
          }

          return;
        }

        const row = target.closest('tr[data-center-id]');
        if(!row) return;

        const rowId = row.getAttribute('data-center-id');
        setSelected(sharedState.selectedId === rowId ? null : rowId);
        renderShell(panel);
      });
    }

    bindSelectionDismiss(panel);

    const nextTableScroll = panel.querySelector('[data-coa-slot="table-scroll"]');
    const nextTableHeadViewport = panel.querySelector('[data-coa-slot="table-head-viewport"]');
    if(nextTableScroll){
      nextTableScroll.scrollTop = shouldResetTableScroll ? 0 : preservedTableScrollTop;
      nextTableScroll.scrollLeft = preservedTableScrollLeft;
      if(nextTableHeadViewport instanceof HTMLElement){
        nextTableHeadViewport.scrollLeft = preservedTableScrollLeft;
      }
    }

    const searchInput = panel.querySelector(SEARCH_INPUT_SELECTOR);
    const clearSearchButton = panel.querySelector(CLEAR_SEARCH_SELECTOR);
    const prevPageButton = panel.querySelector(PREV_PAGE_SELECTOR);
    const nextPageButton = panel.querySelector(NEXT_PAGE_SELECTOR);
    const pageSizeInput = panel.querySelector(PAGE_SIZE_INPUT_SELECTOR);

    function rerenderWithFocus(selector, afterFocus = null){
      renderShell(panel);
      if(!selector) return null;
      const focusTarget = panel.querySelector(selector);
      if(!(focusTarget instanceof HTMLElement)) return null;
      if(typeof focusElementSafely === 'function'){
        focusElementSafely(focusTarget);
      } else {
        try{ focusTarget.focus({ preventScroll:true }); }catch{ try{ focusTarget.focus(); }catch{} }
      }
      if(typeof afterFocus === 'function') afterFocus(focusTarget);
      return focusTarget;
    }

    function resetPagingForFreshResults(){
      runtime.page = 1;
      runtime.resetTableScrollPosition = true;
    }

    function rerenderSearchInput(selection = null){
      const nextInput = rerenderWithFocus(SEARCH_INPUT_SELECTOR);
      if(!(nextInput instanceof HTMLInputElement) || !selection) return;
      const safeStart = Math.min(selection.start, nextInput.value.length);
      const safeEnd = Math.min(selection.end, nextInput.value.length);
      nextInput.setSelectionRange(safeStart, safeEnd);
    }

    function navigatePage(nextPage, focusSelector){
      const normalizedNextPage = normalizePageNumber(nextPage, pageModel.totalPages);
      if(!normalizedNextPage || normalizedNextPage === pageModel.currentPage) return;
      runtime.page = normalizedNextPage;
      runtime.resetTableScrollPosition = true;
      rerenderWithFocus(focusSelector);
    }

    if(searchInput instanceof HTMLInputElement){
      searchInput.addEventListener('input', () => {
        const nextValue = searchInput.value || '';
        const selectionStart = searchInput.selectionStart == null ? nextValue.length : searchInput.selectionStart;
        const selectionEnd = searchInput.selectionEnd == null ? selectionStart : searchInput.selectionEnd;
        runtime.filter = nextValue;
        resetPagingForFreshResults();
        rerenderSearchInput({ start:selectionStart, end:selectionEnd });
      });
    }

    if(clearSearchButton instanceof HTMLButtonElement){
      clearSearchButton.addEventListener('click', () => {
        if(!runtime.filter) return;
        runtime.filter = '';
        resetPagingForFreshResults();
        rerenderSearchInput();
      });
    }

    if(prevPageButton instanceof HTMLButtonElement){
      prevPageButton.addEventListener('click', () => navigatePage(pageModel.currentPage - 1, PREV_PAGE_SELECTOR));
    }

    if(nextPageButton instanceof HTMLButtonElement){
      nextPageButton.addEventListener('click', () => navigatePage(pageModel.currentPage + 1, NEXT_PAGE_SELECTOR));
    }

    if(pageSizeInput instanceof HTMLInputElement){
      pageSizeInput.addEventListener('input', () => {
        const nextPageSize = normalizePageSize(pageSizeInput.value);
        if(nextPageSize === pageModel.pageSize) return;
        runtime.pageSize = nextPageSize;
        resetPagingForFreshResults();
        rerenderWithFocus(PAGE_SIZE_TRIGGER_SELECTOR);
      });
    }

    panel.querySelector('[data-coa-action="add-center"]')?.addEventListener('click', () => internal.openCenterEditor(panel, null));
    panel.querySelector('[data-coa-action="open-deleted"]')?.addEventListener('click', () => internal.openDeletedCenters(panel));
  }

  Object.assign(internal, {
    avatarMarkup,
    selectionDotMarkup,
    centerRowActionIconMarkup,
    centerRowActionsMarkup,
    TABLE_COLUMNS,
    EMPTY_STATE_MARKUP,
    EMPTY_FILTER_STATE_MARKUP,
    buildTableMarkup,
    syncToolbar,
    syncSelectionState,
    clearSelection,
    detachSelectionDismiss,
    bindSelectionDismiss,
    renderShell
  });
})();
