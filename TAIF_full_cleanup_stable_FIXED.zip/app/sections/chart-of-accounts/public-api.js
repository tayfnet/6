(()=>{
  /*
   * TAIF Chart of Accounts public API.
   * Exposes catalog/state access without loading the Chart view renderer.
   */
  const TAIF = window.TAIF || (window.TAIF = {});
  const api = TAIF.chartOfAccounts = TAIF.chartOfAccounts || {};
  const internal = api.internal && typeof api.internal === 'object' ? api.internal : {};
  api.internal = internal;

  if(typeof internal.readCenters === 'function') api.readState = internal.readCenters;
  if(typeof internal.writeCenters === 'function') api.writeState = internal.writeCenters;
  if(typeof internal.getCenters === 'function') api.getCenters = internal.getCenters;
  if(typeof internal.getCenterImageSrc === 'function') api.getCenterImageSrc = internal.getCenterImageSrc;
  if(typeof internal.hydrateCenterImages === 'function') api.hydrateCenterImages = internal.hydrateCenterImages;
  if(typeof internal.ensureCenterImageFallbackHandling === 'function') api.ensureCenterImageFallbackHandling = internal.ensureCenterImageFallbackHandling;
})();
