(() => {
  const TAIF = window.TAIF;
  const { escapeHtml, wrapControlTextMarkup } = TAIF.core.utils;
  const api = TAIF.chartOfAccounts = TAIF.chartOfAccounts || {};
  const internal = api.internal && typeof api.internal === 'object' ? api.internal : {};
  api.internal = internal;
  const {
    sharedState,
    CENTER_TYPE_OPTIONS,
    CENTER_NAME_MAX_LENGTH,
    CENTER_ACCOUNT_MAX_LENGTH,
    CENTER_PHONE_MAX_LENGTH,
    CENTER_ADDRESS_MAX_LENGTH,
    MAIN_CENTER_DELETION_POLICY_NOTE,
    MAIN_CENTER_TYPE_LOCK_NOTE,
    toText,
    typeLabel,
    isCenterTypeChangeLocked,
    isCenterDeletionLocked,
    getCenterDeletionBlockedMessage,
    getCenterImageSrc,
    avatarMarkup,
    showToast,
    findCenter,
    replaceCenter,
    removeCenter,
    setSelected,
    buildCountryChoiceOptions,
    buildCityChoiceOptions,
    buildCenterTypeOptions,
    readCenterCurrencyCatalog,
    createCoaChoicePickerMarkup,
    createCoaMultiChoicePickerMarkup,
    createEmptyCenterDraft,
    formatDateTime,
    bindNormalizedInput,
    normalizeCenterNameValue,
    normalizeAccountNumberValue,
    finalizeAccountNumberValue,
    normalizePhoneValue,
    normalizeFreeTextValue,
    clearCenterFieldValidationState,
    hasCustomCenterImage,
    applyCenterImageSource,
    normalizeCenterImageFile,
    validateCenterDraft,
    getCenters,
    writeCenters,
    normalizeCenterDraftFields,
    mountCoaChoicePicker,
    mountCoaMultiChoicePicker,
    openModalWindow,
    renderShell,
    dismissOverlays
  } = internal;

  function buildConfirmCenterCardMarkup(center, tone = 'danger'){
    if(!center || typeof center !== 'object') return '';

    const name = toText(center.name, 'هذا المركز');
    const accountNo = toText(center.accountNo, '—');
    const type = typeLabel(center);
    const locationParts = [toText(center.country), toText(center.city)].filter(Boolean);
    const location = locationParts.length ? locationParts.join(' / ') : 'بدون موقع محدد';
    const imageSrc = escapeHtml(getCenterImageSrc(center.imageDataUrl));
    const avatarHtml = `<img data-coa-center-image="true" src="${imageSrc}" alt="" draggable="false" loading="eager" decoding="async">`;
    const questionDialog = TAIF?.ui?.questionDialog;

    if(questionDialog && typeof questionDialog.createCardMarkup === 'function'){
      return questionDialog.createCardMarkup({
        title:name,
        subtitle:accountNo,
        meta:[type, location],
        avatarHtml,
        tone,
        className:'taif-question-dialog__card--coa-center'
      });
    }

    return `
      <div class="taif-question-dialog__card taif-question-dialog__card--coa-center" data-taif-question-card="true">
        <span class="taif-question-dialog__card-avatar taif-question-dialog__card-avatar--${tone === 'danger' ? 'danger' : 'primary'}" aria-hidden="true">${avatarHtml}</span>
        <div class="taif-question-dialog__card-text">
          <strong>${escapeHtml(name)}</strong>
          <span>${wrapControlTextMarkup(escapeHtml(accountNo), 'taif-control-text--ltr')}</span>
        </div>
        <div class="taif-question-dialog__card-meta">
          <span class="taif-question-dialog__card-badge">${wrapControlTextMarkup(escapeHtml(type))}</span>
          <span class="taif-question-dialog__card-badge">${wrapControlTextMarkup(escapeHtml(location))}</span>
        </div>
      </div>
    `;
  }

  function openConfirm(options){
    const title = toText(options && options.title, 'تأكيد');
    const message = toText(options && options.message, 'هل أنت متأكد؟');
    const confirmLabel = toText(options && options.confirmLabel, 'تأكيد');
    const tone = options && options.tone === 'danger' ? 'danger' : 'primary';
    const centerCardMarkup = buildConfirmCenterCardMarkup(options && options.center, tone);
    const questionDialog = TAIF?.ui?.questionDialog;

    if(questionDialog && typeof questionDialog.open === 'function'){
      return questionDialog.open({
        owner:'chart-of-accounts',
        title,
        cardHtml:centerCardMarkup,
        message,
        confirmLabel,
        confirmTone:tone,
        confirmIcon:tone === 'danger' ? 'trash' : 'check',
        className:'taif-question-dialog--chart-of-accounts',
        onCancel(){
          if(typeof (options && options.onCancel) === 'function') options.onCancel();
        },
        onConfirm(){
          if(typeof (options && options.onConfirm) === 'function') options.onConfirm();
        }
      });
    }

    // Official question-dialog is required for destructive confirmations.
    // If it is unavailable, fail closed instead of falling back to a native browser dialog.
    if(typeof (options && options.onCancel) === 'function') options.onCancel();
    return null;
  }

  function refreshCenterList(panel, options = null){
    renderShell(panel);
    if(options && options.reopenDeleted === true){
      openDeletedCenters(panel);
    }
  }

  function clearSelectionIfMatches(centerId){
    if(sharedState.selectedId === centerId) sharedState.selectedId = null;
  }

  function requestArchiveCenter(panel, centerId){
    const center = findCenter(centerId);
    if(!center || center.deleted){
      showToast('المركز المطلوب غير موجود.');
      refreshCenterList(panel);
      return;
    }

    if(isCenterDeletionLocked(center)){
      showToast(getCenterDeletionBlockedMessage(center));
      return;
    }

    openConfirm({
      title:'أرشفة المركز',
      center,
      message:'سيتم نقل هذا المركز إلى قائمة المراكز المحذوفة مع الاحتفاظ ببياناته لمرحلة لاحقة. هل تريد المتابعة؟',
      confirmLabel:'أرشفة الآن',
      tone:'danger',
      onConfirm(){
        const archivedAt = Date.now();
        replaceCenter(centerId, (item) => ({
          ...item,
          deleted:true,
          deletedAt:archivedAt,
          updatedAt:archivedAt
        }));
        clearSelectionIfMatches(centerId);
        dismissOverlays();
        refreshCenterList(panel);
        showToast('تمت أرشفة المركز.');
      }
    });
  }

  function buildCenterCurrenciesPickerMarkup(draft){
    return createCoaMultiChoicePickerMarkup({
      pickerDataAttribute:'data-coa-center-currencies-picker',
      triggerId:'coa-center-currencies-trigger',
      valueDataAttribute:'data-coa-center-currencies-value',
      summaryInputId:'coa-center-currencies-summary',
      modeInputId:'coa-center-currencies-mode',
      codesInputId:'coa-center-currencies-codes',
      selection:draft
    });
  }

  function buildCenterEditorMarkup(draft, editing){
    const saveLabel = editing ? 'حفظ التعديل' : 'إضافة المركز';
    const countryOptions = buildCountryChoiceOptions();
    const cityOptions = buildCityChoiceOptions(draft.country);
    const centerTypeOptions = typeof buildCenterTypeOptions === 'function'
      ? buildCenterTypeOptions(draft)
      : CENTER_TYPE_OPTIONS;
    const cityPlaceholder = draft.country ? '' : 'اختر الدولة أولًا';
    const typeLockActive = editing && isCenterTypeChangeLocked(draft);
    const showMainTypeNote = toText(draft && draft.centerType) === 'main';
    const mainTypeNoteText = typeLockActive ? MAIN_CENTER_TYPE_LOCK_NOTE : MAIN_CENTER_DELETION_POLICY_NOTE;

    return `
      <div class="coa-editor-panel">
        <div class="coa-form">
          <div class="coa-single-editor-scroll">
            <div class="coa-form__grid coa-form__grid--editor coa-form__grid--editor-with-media">
              <label class="coa-form__field coa-form__field--name"><span class="coa-form__label">اسم المركز</span><input class="coa-form__input coa-form__input--center" type="text" value="${escapeHtml(draft.name)}" data-coa-field="name" data-taif-initial-focus="true" maxlength="${CENTER_NAME_MAX_LENGTH}" autocomplete="off" spellcheck="false"></label>
              <label class="coa-form__field coa-form__field--account"><span class="coa-form__label">رقم حساب المركز</span><input class="coa-form__input coa-form__input--center" type="text" value="${escapeHtml(draft.accountNo)}" data-coa-field="accountNo" inputmode="numeric" dir="ltr" maxlength="${CENTER_ACCOUNT_MAX_LENGTH}" autocomplete="off" spellcheck="false"></label>
              <div class="coa-form__media-field">
                <span class="coa-form__label">صورة المركز</span>
                <div class="coa-form__media-frame">
                  <div class="coa-form__media-preview" data-coa-slot="center-image-preview">
                    <img class="coa-form__media-image" data-coa-slot="center-image" data-coa-center-image="true" src="${escapeHtml(getCenterImageSrc(draft.imageDataUrl))}" alt="" draggable="false" loading="eager" decoding="async">
                  </div>
                  <div class="coa-form__media-actions">
                    <button class="coa-btn coa-form__media-btn coa-form__media-btn--upload" type="button" data-coa-image-upload>إضافة صورة</button>
                    <button class="coa-btn coa-form__media-btn coa-form__media-btn--clear" type="button" data-coa-image-clear data-taif-clear-control="true">حذف الصورة</button>
                  </div>
                  <input class="coa-form__media-input" type="file" accept="image/*" data-coa-image-file hidden>
                </div>
              </div>
              <div class="coa-form__field coa-form__field--type"><span class="coa-form__label">نوع المركز</span>${createCoaChoicePickerMarkup({ pickerDataAttribute:'data-coa-center-type-picker', triggerId:'coa-center-type-trigger', inputId:'coa-center-type-input', fieldName:'centerType', valueDataAttribute:'data-coa-center-type-value', value:draft.centerType, options:centerTypeOptions, disabled:typeLockActive })}<div class="coa-form__inline-note coa-form__inline-note--warning" data-coa-main-type-note${showMainTypeNote ? '' : ' hidden'} aria-live="polite">${escapeHtml(mainTypeNoteText)}</div></div>
              <div class="coa-form__field coa-form__field--currencies"><span class="coa-form__label">العملات</span>${buildCenterCurrenciesPickerMarkup(draft)}</div>
              <div class="coa-form__field coa-form__field--country"><span class="coa-form__label">الدولة</span>${createCoaChoicePickerMarkup({ pickerDataAttribute:'data-coa-country-picker', triggerId:'coa-country-trigger', inputId:'coa-country-input', fieldName:'country', valueDataAttribute:'data-coa-country-value', value:draft.country, options:countryOptions, placeholder:'', fallbackValue:'' })}</div>
              <div class="coa-form__field coa-form__field--city"><span class="coa-form__label">المدينة</span>${createCoaChoicePickerMarkup({ pickerDataAttribute:'data-coa-city-picker', triggerId:'coa-city-trigger', inputId:'coa-city-input', fieldName:'city', valueDataAttribute:'data-coa-city-value', value:draft.city, options:cityOptions, placeholder:cityPlaceholder, fallbackValue:'', disabled:!cityOptions.length })}</div>
              <label class="coa-form__field coa-form__field--phone"><span class="coa-form__label">رقم الهاتف</span><input class="coa-form__input coa-form__input--center" type="text" value="${escapeHtml(draft.phone)}" data-coa-field="phone" inputmode="tel" dir="ltr" maxlength="${CENTER_PHONE_MAX_LENGTH}" autocomplete="tel" spellcheck="false"></label>
              <label class="coa-form__field coa-form__field--full coa-form__field--address"><span class="coa-form__label">عنوان المركز</span><input class="coa-form__input coa-form__input--center" type="text" value="${escapeHtml(draft.address)}" data-coa-field="address" maxlength="${CENTER_ADDRESS_MAX_LENGTH}"></label>
            </div>
          </div>
          <div class="coa-form__actions coa-form__actions--editor" data-taif-footer-actions="true">
            <div class="coa-form__actions-group" data-taif-footer-group="true"><button class="coa-btn coa-btn--danger" type="button" data-coa-cancel data-taif-action-role="cancel" data-taif-action-tone="danger"><span class="taif-control-text">إلغاء</span></button><button class="coa-btn coa-btn--success" type="button" data-coa-save data-taif-action-role="commit" data-taif-action-tone="success">${wrapControlTextMarkup(escapeHtml(saveLabel))}</button></div>
          </div>
        </div>
      </div>
    `;
  }

  function buildDeletedCenterSummary(center){
    const parts = [];
    const location = [center && center.country, center && center.city].filter(Boolean).join(' / ');
    if(location) parts.push(location);
    if(center && center.phone) parts.push(center.phone);
    if(center && center.currencies) parts.push(`العملات: ${center.currencies}`);
    if(center && center.address) parts.push(center.address);
    return parts.length ? parts.join(' • ') : 'بدون تفاصيل إضافية';
  }

  function buildDeletedCentersMarkup(deletedCenters){
    if(!deletedCenters.length){
      return '<div class="chart-accounts__empty chart-accounts__empty--inside-modal"><div class="chart-accounts__empty-box"><div>لا توجد مراكز محذوفة حاليًا.</div></div></div>';
    }

    return deletedCenters.map((center) => {
      const name = escapeHtml(center.name || 'بدون اسم');
      const summary = escapeHtml(buildDeletedCenterSummary(center));
      const createdAt = escapeHtml(formatDateTime(center.createdAt || center.updatedAt));
      const deletedAt = escapeHtml(formatDateTime(center.deletedAt || center.updatedAt));
      const deletionLocked = isCenterDeletionLocked(center);
      const deleteButtonTitle = escapeHtml(deletionLocked ? getCenterDeletionBlockedMessage(center) : 'حذف المركز نهائيًا');
      return `
        <article class="coa-deleted-row">
          <div class="coa-deleted-row__avatar">${avatarMarkup(center)}</div>
          <div class="coa-deleted-row__account"><span class="chart-accounts__account">${escapeHtml(center.accountNo || '—')}</span></div>
          <div class="coa-deleted-row__main">
            <div class="coa-deleted-row__name" title="${name}">${name}</div>
            <div class="coa-deleted-row__summary" title="${summary}">${summary}</div>
          </div>
          <div class="coa-deleted-row__created-at"><span class="coa-deleted-row__created-at-value">${createdAt}</span></div>
          <div class="coa-deleted-row__type"><span class="chart-accounts__type chart-accounts__type--${escapeHtml(center.centerType)}">${wrapControlTextMarkup(escapeHtml(typeLabel(center)))}</span></div>
          <div class="coa-deleted-row__deleted-at"><span class="coa-deleted-row__deleted-at-value">${deletedAt}</span></div>
          <div class="coa-deleted-row__actions">
            <button class="coa-btn coa-btn--success" type="button" data-coa-restore="${escapeHtml(center.id)}" data-taif-action-role="commit" data-taif-action-tone="success">${wrapControlTextMarkup('استعادة')}</button>
            <button class="coa-btn coa-btn--danger" type="button" data-coa-hard-delete="${escapeHtml(center.id)}" data-taif-action-role="commit" data-taif-action-tone="danger" title="${deleteButtonTitle}"${deletionLocked ? ' disabled aria-disabled="true" data-coa-protected-delete="true"' : ''}>${wrapControlTextMarkup('حذف')}</button>
          </div>
        </article>
      `;
    }).join('');
  }

  function buildDeletedCentersPanelMarkup(deletedCenters){
    return `
      <div class="coa-deleted-bulk">
        <div class="coa-deleted-bulk__scrollarea">
          <div class="coa-deleted-bulk__sticky">
            <div class="coa-deleted-bulk__headrow" aria-hidden="true">
              <div>الصورة</div>
              <div>رقم الحساب</div>
              <div>المركز المحذوف</div>
              <div>تاريخ الإنشاء</div>
              <div>النوع</div>
              <div>وقت الحذف</div>
              <div>إجراءات</div>
            </div>
          </div>
          <div class="coa-deleted-list coa-deleted-list--bulk" data-taif-arrow-group="vertical">${buildDeletedCentersMarkup(deletedCenters)}</div>
        </div>
      </div>
    `;
  }

  function openCenterEditor(panel, centerId){
    const existing = centerId ? findCenter(centerId) : null;
    if(centerId && !existing){
      showToast('المركز المطلوب غير موجود.');
      refreshCenterList(panel);
      return;
    }

    const editing = !!existing;
    const now = Date.now();
    let draft = existing
      ? { ...existing }
      : createEmptyCenterDraft(now);

    openModalWindow({
      title:editing ? 'تعديل مركز' : 'إضافة مركز جديد',
      size:'md',
      modalClass:'coa-modal--single-editor',
      bodyClass:'coa-modal__body--single-editor',
      bodyHtml:buildCenterEditorMarkup(draft, editing),
      onMount({ modal, close, registerCleanup }){
        const scrollArea = modal.querySelector('.coa-single-editor-scroll');
        const imagePreview = modal.querySelector('[data-coa-slot="center-image-preview"]');
        const imageNode = modal.querySelector('[data-coa-slot="center-image"]');
        const imageUploadButton = modal.querySelector('[data-coa-image-upload]');
        const imageClearButton = modal.querySelector('[data-coa-image-clear]');
        const imageFileInput = modal.querySelector('[data-coa-image-file]');
        const nameInput = modal.querySelector('[data-coa-field="name"]');
        const accountInput = modal.querySelector('[data-coa-field="accountNo"]');
        const phoneInput = modal.querySelector('[data-coa-field="phone"]');
        const addressInput = modal.querySelector('[data-coa-field="address"]');
        const currenciesPickerController = mountCoaMultiChoicePicker({
          modal,
          scrollArea,
          registerCleanup,
          pickerSelector:'[data-coa-center-currencies-picker]',
          triggerSelector:'#coa-center-currencies-trigger',
          valueSelector:'[data-coa-center-currencies-value]',
          summaryInputSelector:'#coa-center-currencies-summary',
          modeInputSelector:'#coa-center-currencies-mode',
          codesInputSelector:'#coa-center-currencies-codes',
          options:readCenterCurrencyCatalog().map((currency) => ({ value:currency.code, label:currency.label, flag:currency.flag, richType:currency.richType })),
          ariaLabel:'العملات المتاحة للمركز'
        });

        const centerTypePickerController = mountCoaChoicePicker({
          modal,
          scrollArea,
          registerCleanup,
          pickerSelector:'[data-coa-center-type-picker]',
          triggerSelector:'#coa-center-type-trigger',
          inputSelector:'#coa-center-type-input',
          valueSelector:'[data-coa-center-type-value]',
          options:typeof buildCenterTypeOptions === 'function' ? buildCenterTypeOptions(draft) : CENTER_TYPE_OPTIONS,
          ariaLabel:'نوع المركز',
          disabled:editing && isCenterTypeChangeLocked(draft)
        });

        const centerTypeInput = modal.querySelector('#coa-center-type-input');
        const mainTypeNote = modal.querySelector('[data-coa-main-type-note]');

        function syncMainTypeNote(){
          if(!(mainTypeNote instanceof HTMLElement)) return;
          const lockedMainType = editing && isCenterTypeChangeLocked(draft);
          const shouldShow = lockedMainType || toText(centerTypeInput && centerTypeInput.value) === 'main';
          mainTypeNote.textContent = lockedMainType ? MAIN_CENTER_TYPE_LOCK_NOTE : MAIN_CENTER_DELETION_POLICY_NOTE;
          mainTypeNote.hidden = !shouldShow;
          mainTypeNote.classList.toggle('is-visible', shouldShow);
          mainTypeNote.setAttribute('aria-hidden', shouldShow ? 'false' : 'true');
          if(centerTypePickerController && typeof centerTypePickerController.setDisabled === 'function'){
            centerTypePickerController.setDisabled(lockedMainType);
          }
        }

        centerTypeInput?.addEventListener('input', syncMainTypeNote);
        centerTypeInput?.addEventListener('change', syncMainTypeNote);
        registerCleanup(() => {
          centerTypeInput?.removeEventListener('input', syncMainTypeNote);
          centerTypeInput?.removeEventListener('change', syncMainTypeNote);
        });

        syncMainTypeNote();

        const countryInput = modal.querySelector('#coa-country-input');
        const initialCityOptions = buildCityChoiceOptions(draft.country);
        const cityPickerController = mountCoaChoicePicker({
          modal,
          scrollArea,
          registerCleanup,
          pickerSelector:'[data-coa-city-picker]',
          triggerSelector:'#coa-city-trigger',
          inputSelector:'#coa-city-input',
          valueSelector:'[data-coa-city-value]',
          options:initialCityOptions,
          ariaLabel:'المدينة',
          placeholder:draft.country ? '' : 'اختر الدولة أولًا',
          fallbackValue:'',
          disabled:!initialCityOptions.length
        });

        mountCoaChoicePicker({
          modal,
          scrollArea,
          registerCleanup,
          pickerSelector:'[data-coa-country-picker]',
          triggerSelector:'#coa-country-trigger',
          inputSelector:'#coa-country-input',
          valueSelector:'[data-coa-country-value]',
          options:buildCountryChoiceOptions(),
          ariaLabel:'الدولة',
          placeholder:'',
          fallbackValue:''
        });

        function syncCityPickerForCountry({ preserveValue = true } = {}){
          const selectedCountry = toText(countryInput && countryInput.value);
          const nextCityOptions = buildCityChoiceOptions(selectedCountry);
          const hasCountrySelection = !!selectedCountry;

          cityPickerController.setPlaceholder(hasCountrySelection ? '' : 'اختر الدولة أولًا');
          cityPickerController.setOptions(nextCityOptions, { preserveValue, fallbackValue:'' });
          cityPickerController.setDisabled(!nextCityOptions.length);
        }

        function onCountryValueChange(){
          syncCityPickerForCountry({ preserveValue:true });
        }

        countryInput?.addEventListener('input', onCountryValueChange);
        countryInput?.addEventListener('change', onCountryValueChange);
        registerCleanup(() => {
          countryInput?.removeEventListener('input', onCountryValueChange);
          countryInput?.removeEventListener('change', onCountryValueChange);
        });

        syncCityPickerForCountry({ preserveValue:true });

        bindNormalizedInput(nameInput, normalizeCenterNameValue, registerCleanup, { normalizeOnInput:false });
        bindNormalizedInput(accountInput, normalizeAccountNumberValue, registerCleanup);
        if(accountInput instanceof HTMLInputElement){
          const finalizeAccountInputValue = () => {
            const nextValue = finalizeAccountNumberValue(accountInput.value);
            if(accountInput.value !== nextValue) accountInput.value = nextValue;
          };
          accountInput.addEventListener('blur', finalizeAccountInputValue);
          registerCleanup(() => {
            accountInput.removeEventListener('blur', finalizeAccountInputValue);
          });
        }
        bindNormalizedInput(phoneInput, normalizePhoneValue, registerCleanup);
        bindNormalizedInput(addressInput, (value) => normalizeFreeTextValue(value, CENTER_ADDRESS_MAX_LENGTH), registerCleanup, { normalizeOnInput:false });

        modal.querySelectorAll('[data-coa-field]').forEach((field) => {
          const fieldName = field.getAttribute('data-coa-field');
          if(!fieldName) return;

          const clearFieldError = () => {
            clearCenterFieldValidationState(modal, fieldName);
          };

          field.addEventListener('input', clearFieldError);
          field.addEventListener('change', clearFieldError);
          registerCleanup(() => {
            field.removeEventListener('input', clearFieldError);
            field.removeEventListener('change', clearFieldError);
          });
        });

        function syncImagePreview(){
          const hasCustomImage = hasCustomCenterImage(draft);
          const imageSource = getCenterImageSrc(draft.imageDataUrl);
          if(imagePreview){
            imagePreview.classList.toggle('is-custom-image', hasCustomImage);
          }
          if(imageNode){
            applyCenterImageSource(imageNode, imageSource);
            imageNode.hidden = false;
          }
          if(imageClearButton) imageClearButton.disabled = !hasCustomImage;
          if(imageUploadButton){
            const uploadLabel = hasCustomImage ? 'تغيير صورة المركز' : 'إضافة صورة للمركز';
            imageUploadButton.setAttribute('aria-label', uploadLabel);
            imageUploadButton.setAttribute('title', uploadLabel);
          }
        }

        function clearImageSelection(){
          draft.imageDataUrl = '';
          if(imageFileInput) imageFileInput.value = '';
          syncImagePreview();
        }

        function onImageUploadClick(){
          imageFileInput?.click();
        }

        function onImageClearClick(){
          clearImageSelection();
        }

        async function onImageFileChange(event){
          const input = event.currentTarget;
          if(!(input instanceof HTMLInputElement)) return;
          const file = input.files && input.files[0];
          if(!file) return;
          if(file.type && !file.type.startsWith('image/')){
            showToast('يرجى اختيار ملف صورة صالح.');
            input.value = '';
            return;
          }

          if(imageUploadButton) imageUploadButton.disabled = true;
          if(imageClearButton) imageClearButton.disabled = true;

          try {
            draft.imageDataUrl = await normalizeCenterImageFile(file);
            syncImagePreview();
          } catch{
            showToast('تعذر تجهيز الصورة المحددة.');
            syncImagePreview();
          } finally {
            input.value = '';
            if(imageUploadButton) imageUploadButton.disabled = false;
            syncImagePreview();
          }
        }

        function readFormIntoDraft(){
          modal.querySelectorAll('[data-coa-field]').forEach((node) => {
            draft[node.getAttribute('data-coa-field')] = toText(node.value);
          });
          if(currenciesPickerController && typeof currenciesPickerController.readDraftInto === 'function'){
            currenciesPickerController.readDraftInto(draft);
          }
          normalizeCenterDraftFields(draft);
        }

        function saveDraft(){
          readFormIntoDraft();

          if(!validateCenterDraft(modal, draft, editing ? draft.id : null)){
            return;
          }

          const savedAt = Date.now();
          draft.updatedAt = savedAt;

          const next = editing
            ? getCenters().map((item) => (
                item.id === draft.id
                  ? { ...draft, deleted:false, updatedAt:savedAt }
                  : item
              ))
            : getCenters().concat({
                ...draft,
                deleted:false,
                createdAt:savedAt,
                updatedAt:savedAt
              });

          writeCenters(next);
          setSelected(draft.id);
          dismissOverlays();
          refreshCenterList(panel);
          showToast(editing ? 'تم حفظ تعديل المركز.' : 'تمت إضافة المركز الجديد.');
        }

        syncImagePreview();

        imageUploadButton?.addEventListener('click', onImageUploadClick);
        imageClearButton?.addEventListener('click', onImageClearClick);
        imageFileInput?.addEventListener('change', onImageFileChange);
        registerCleanup(() => {
          imageUploadButton?.removeEventListener('click', onImageUploadClick);
          imageClearButton?.removeEventListener('click', onImageClearClick);
          imageFileInput?.removeEventListener('change', onImageFileChange);
        });

        modal.querySelector('[data-coa-cancel]')?.addEventListener('click', close);
        modal.querySelector('[data-coa-save]')?.addEventListener('click', saveDraft);

      }
    });
  }

  function openDeletedCenters(panel){
    const deletedCenters = getCenters(false);

    openModalWindow({
      title:'المراكز المحذوفة',
      size:'lg',
      modalClass:'coa-modal--deleted-centers-bulk',
      bodyClass:'coa-modal__body--deleted-centers-bulk',
      bodyHtml:buildDeletedCentersPanelMarkup(deletedCenters),
      initialFocus:'modal',
      onMount({ modal, close }){
        modal.querySelectorAll('[data-coa-restore]').forEach((button) => {
          button.addEventListener('click', () => {
            const centerId = button.getAttribute('data-coa-restore');
            const restoredAt = Date.now();
            replaceCenter(centerId, (item) => ({
              ...item,
              deleted:false,
              deletedAt:0,
              updatedAt:restoredAt
            }));
            setSelected(centerId);
            close();
            refreshCenterList(panel, { reopenDeleted:true });
            showToast('تمت استعادة المركز.');
          });
        });

        modal.querySelectorAll('[data-coa-hard-delete]').forEach((button) => {
          button.addEventListener('click', () => {
            const centerId = button.getAttribute('data-coa-hard-delete');
            const center = findCenter(centerId);
            if(isCenterDeletionLocked(center)){
              showToast(getCenterDeletionBlockedMessage(center));
              return;
            }

            openConfirm({
              title:'حذف نهائي',
              center,
              message:`سيتم حذف ${center ? center.name : 'هذا المركز'} نهائيًا من المرجع الحالي. لا يمكن التراجع بعد التنفيذ.`,
              confirmLabel:'حذف نهائي',
              tone:'danger',
              onConfirm(){
                removeCenter(centerId);
                clearSelectionIfMatches(centerId);
                close();
                refreshCenterList(panel, { reopenDeleted:true });
                showToast('تم حذف المركز نهائيًا.');
              }
            });
          });
        });
      }
    });
  }

  Object.assign(internal, {
    buildConfirmCenterCardMarkup,
    openConfirm,
    requestArchiveCenter,
    buildCenterEditorMarkup,
    buildDeletedCenterSummary,
    buildDeletedCentersMarkup,
    buildDeletedCentersPanelMarkup,
    openCenterEditor,
    openDeletedCenters
  });
})();
