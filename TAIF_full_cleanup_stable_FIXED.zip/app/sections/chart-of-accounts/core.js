(() => {
  const TAIF = window.TAIF;
  const { clone, escapeHtml, readJsonStorage, storageSet, setDisclosureOpenState, createInlinePickerCommitController: createSharedInlinePickerCommitController, registerInlinePickerApi: registerSharedInlinePickerApi, toText, clampNumber } = TAIF.core.utils;
  const api = TAIF.chartOfAccounts = TAIF.chartOfAccounts || {};
  const internal = api.internal && typeof api.internal === 'object' ? api.internal : {};
  api.internal = internal;
  const storageKeys = TAIF?.core?.storageKeys || {};
  const STORAGE_KEY = storageKeys.chartOfAccounts || 'taif-chart-of-accounts-centers-v3';
  const AUTO_SEQUENCE_STORAGE_KEY = storageKeys.chartOfAccountsAutoSequence || 'taif-chart-of-accounts-account-sequence-v1';
  const DEFAULT_CENTER_TIMESTAMP = Date.now();
  const EMPTY_CENTER_TEMPLATE = Object.freeze({
    accountNo:'',
    name:'',
    centerType:'client',
    centerTypeLocked:false,
    country:'',
    city:'',
    phone:'',
    currencies:'',
    currencySelectionMode:'all',
    currencyCodes:[],
    address:'',
    imageDataUrl:'',
    deleted:false
  });
  const RETIRED_DEFAULT_CENTER_IDS = Object.freeze(new Set([
    'coa-default-002',
    'coa-default-009'
  ]));
  const DEFAULT_CENTER_SEEDS = [
    { id:'coa-default-001', accountNo:'001', name:'صندوق محلي اساسي', offsetMs:1080000 },
    { id:'coa-default-003', accountNo:'002', name:'عملات مدفوعة', offsetMs:960000 },
    { id:'coa-default-004', accountNo:'003', name:'عملات محققة', offsetMs:900000 },
    { id:'coa-default-005', accountNo:'004', name:'حوالات لم تسلم', offsetMs:840000 },
    { id:'coa-default-006', accountNo:'005', name:'حسابات القطع الأجنبي', offsetMs:780000 },
    { id:'coa-default-007', accountNo:'006', name:'رأس المال المدفوع', offsetMs:720000 },
    { id:'coa-default-008', accountNo:'007', name:'مصاريف', offsetMs:660000 }
  ];
  const DEFAULT_CENTER_ACCOUNT_BY_ID = Object.freeze(DEFAULT_CENTER_SEEDS.reduce((accumulator, seed) => {
    accumulator[toText(seed && seed.id)] = toText(seed && seed.accountNo);
    return accumulator;
  }, {}));
  const DEFAULT_CENTER_NAME_BY_ID = Object.freeze(DEFAULT_CENTER_SEEDS.reduce((accumulator, seed) => {
    accumulator[toText(seed && seed.id)] = toText(seed && seed.name);
    return accumulator;
  }, {}));
  const DEFAULT_CENTERS = DEFAULT_CENTER_SEEDS.map(({ offsetMs, ...seed }) => ({
    ...EMPTY_CENTER_TEMPLATE,
    centerType:'main',
    ...seed,
    createdAt:DEFAULT_CENTER_TIMESTAMP - offsetMs,
    updatedAt:DEFAULT_CENTER_TIMESTAMP - offsetMs
  }));
  const MAIN_CENTER_DELETION_POLICY_NOTE = 'تنبيه: المركز الأساسي لا يمكن حذفه.';
  const MAIN_CENTER_TYPE_LOCK_NOTE = 'تنبيه: المركز الأساسي لا يمكن حذفُه أو تغيير نوعه.';
  const MAIN_CENTER_DELETION_BLOCK_MESSAGE = 'لا يمكن حذف المراكز من النوع الأساسي.';
  const CENTER_TYPE_OPTIONS = Object.freeze([
    { value:'client', label:'عميل' },
    { value:'box', label:'صندوق' },
    { value:'main', label:'أساسي' }
  ]);
  const COUNTRY_OPTIONS = Object.freeze([
    { value:'سوريا', label:'سوريا' },
    { value:'تركيا', label:'تركيا' }
  ]);
  const COUNTRY_CITY_LIBRARY = Object.freeze({
    'سوريا':Object.freeze([
      'دمشق',
      'ريف دمشق',
      'حلب',
      'حمص',
      'حماة',
      'اللاذقية',
      'طرطوس',
      'إدلب',
      'درعا',
      'السويداء',
      'دير الزور',
      'الرقة',
      'الحسكة',
      'القنيطرة'
    ]),
    'تركيا':Object.freeze([
      'أضنة',
      'أديامان',
      'أفيون قره حصار',
      'أغري',
      'أماسيا',
      'أنقرة',
      'أنطاليا',
      'أرتفين',
      'أيدن',
      'باليكسير',
      'بيلجيك',
      'بينغول',
      'بدليس',
      'بولو',
      'بوردور',
      'بورصة',
      'جناق قلعة',
      'تشانكيري',
      'جوروم',
      'دنيزلي',
      'ديار بكر',
      'أدرنة',
      'إلازيغ',
      'أرزينجان',
      'أرضروم',
      'إسكي شهير',
      'غازي عنتاب',
      'غيرسون',
      'غوموش خانة',
      'هكاري',
      'هاتاي',
      'إسبارطة',
      'مرسين',
      'إسطنبول',
      'إزمير',
      'قارص',
      'كاستامونو',
      'قيصري',
      'قرقلر إيلي',
      'قرشهير',
      'كوجالي',
      'قونية',
      'كوتاهية',
      'ملاطية',
      'مانيسا',
      'كهرمان مرعش',
      'ماردين',
      'موغلا',
      'موش',
      'نوشهير',
      'نيغدة',
      'أوردو',
      'ريزا',
      'صقاريا',
      'سامسون',
      'سيرت',
      'سينوب',
      'سيواس',
      'تكيرداغ',
      'توقات',
      'طرابزون',
      'تونجلي',
      'شانلي أورفا',
      'أوشاك',
      'فان',
      'يوزغات',
      'زونغولداك',
      'أكسراي',
      'بايبورت',
      'قرمان',
      'قرق قلعة',
      'باتمان',
      'شرناق',
      'بارتين',
      'أردهان',
      'إغدير',
      'يالوفا',
      'قرة بوك',
      'كيليس',
      'عثمانية',
      'دوزجة'
    ])
  });

  const CENTER_NAME_MAX_LENGTH = 120;
  const CENTER_ACCOUNT_MIN_LENGTH = 3;
  const CENTER_ACCOUNT_MAX_LENGTH = 5;
  const CENTER_PHONE_MIN_DIGITS = 7;
  const CENTER_PHONE_MAX_DIGITS = 15;
  const CENTER_PHONE_MAX_LENGTH = 24;
  const CENTER_ADDRESS_MAX_LENGTH = 220;
  const CENTER_CURRENCIES_MAX_LENGTH = 120;
  const CENTER_CURRENCY_MODE_ALL = 'all';
  const CENTER_CURRENCY_MODE_CUSTOM = 'custom';
  const CENTER_CURRENCIES_ALL_LABEL = 'كافة العملات';
  const CENTER_CURRENCIES_PARTIAL_LABEL = 'عملات محددة';
  const CENTER_CURRENCIES_EMPTY_LABEL = 'اختر العملات';
  const CENTER_IMAGE_OUTPUT_SIZE = 512;
  const CENTER_IMAGE_OUTPUT_TYPE = 'image/png';

  const sharedState = TAIF.chartOfAccounts && TAIF.chartOfAccounts.state
    ? TAIF.chartOfAccounts.state
    : { selectedId:null, dataset:null };

  const runtime = api.runtime && typeof api.runtime === 'object'
    ? api.runtime
    : { panel:null };
  api.state = sharedState;
  api.runtime = runtime;
  runtime.modalLayer = runtime.modalLayer && runtime.modalLayer.isConnected ? runtime.modalLayer : null;
  runtime.filter = typeof runtime.filter === 'string' ? runtime.filter : '';
  runtime.modalStack = Array.isArray(runtime.modalStack) ? runtime.modalStack : [];
  runtime.modalZIndex = Number(runtime.modalZIndex) || 2398;
  runtime.modalSequence = Number(runtime.modalSequence) || 0;
  runtime.modalCascadeSlots = Number(runtime.modalCascadeSlots) || 6;

  function collapseWhitespace(value){
    return toText(value).replace(/\s+/g, ' ');
  }

  function normalizeDigits(value){
    return String(value == null ? '' : value)
      .replace(/[٠-٩]/g, (digit) => String(digit.charCodeAt(0) - 0x0660))
      .replace(/[۰-۹]/g, (digit) => String(digit.charCodeAt(0) - 0x06F0));
  }

  function countDigits(value){
    const matches = normalizeDigits(value).match(/\d/g);
    return matches ? matches.length : 0;
  }

  function containsLetter(value){
    const normalized = collapseWhitespace(value);
    if(!normalized) return false;

    try {
      return /\p{L}/u.test(normalized);
    } catch{
      return /[A-Za-zء-يٮ-ۓۺ-ۿ]/.test(normalized);
    }
  }

  function normalizeFreeTextValue(value, maxLength = 0){
    const normalized = collapseWhitespace(value);
    return maxLength > 0 ? normalized.slice(0, maxLength) : normalized;
  }

  function normalizeCenterNameValue(value){
    return normalizeFreeTextValue(value, CENTER_NAME_MAX_LENGTH);
  }

  function normalizeAccountNumberValue(value){
    return normalizeDigits(value).replace(/\D+/g, '').slice(0, CENTER_ACCOUNT_MAX_LENGTH);
  }

  function finalizeAccountNumberValue(value){
    const normalized = normalizeAccountNumberValue(value);
    if(!normalized) return '';
    return normalized.length < CENTER_ACCOUNT_MIN_LENGTH
      ? normalized.padStart(CENTER_ACCOUNT_MIN_LENGTH, '0')
      : normalized;
  }

  function normalizePhoneValue(value){
    const source = normalizeDigits(value);
    const hasLeadingPlus = /^\s*\+/.test(source);
    const withoutPlus = source.replace(/\+/g, '');
    const cleaned = withoutPlus
      .replace(/[^\d\s()\-]/g, '')
      .replace(/\s+/g, ' ')
      .replace(/^[\s()\-]+/, '')
      .replace(/[\s()\-]+$/, '');
    const normalized = `${hasLeadingPlus ? '+' : ''}${cleaned}`.trim();
    return normalized.slice(0, CENTER_PHONE_MAX_LENGTH);
  }

  function normalizeCurrencyCodeValue(value){
    return toText(value).trim().toUpperCase();
  }

  function readCenterCurrencyCatalog(){
    const seen = new Set();
    let source = [];
    const currencyDomain = TAIF.currencyDomain || TAIF.currencyManagement || {};

    try {
      if(typeof currencyDomain.readState === 'function'){
        const state = currencyDomain.readState();
        source = Array.isArray(state && state.currencies) ? state.currencies : [];
      }
    } catch{}

    if(!source.length){
      const feature = TAIF.currencyManagementFeature || {};
      source = Array.isArray(feature.DEFAULT_CURRENCIES) ? feature.DEFAULT_CURRENCIES : [];
    }

    if(!source.length){
      source = [{ code:'USD', name:'الدولار الأمريكي' }];
    }

    return source
      .map((currency) => {
        const code = normalizeCurrencyCodeValue(currency && currency.code);
        if(!code || seen.has(code)) return null;
        seen.add(code);
        const label = normalizeFreeTextValue(currency && currency.name || code, 80) || code;
        const flag = toText(currency && currency.flag);
        return { code, value:code, label, flag, richType:'currency-with-flag' };
      })
      .filter(Boolean);
  }

  function normalizeCenterCurrencyCodes(rawCodes, catalog = readCenterCurrencyCatalog()){
    const catalogList = Array.isArray(catalog) ? catalog : [];
    const catalogValues = new Set(catalogList.map((option) => normalizeCurrencyCodeValue(option && (option.code || option.value))).filter(Boolean));
    const catalogLabels = new Map(catalogList.map((option) => [normalizeFreeTextValue(option && option.label).toLocaleLowerCase('ar'), normalizeCurrencyCodeValue(option && (option.code || option.value))]));
    let sourceList = [];

    if(Array.isArray(rawCodes)){
      sourceList = rawCodes.slice();
    } else {
      const safeText = toText(rawCodes).trim();
      if(!safeText) return [];
      if(safeText.startsWith('[') && safeText.endsWith(']')){
        try {
          const parsed = JSON.parse(safeText);
          if(Array.isArray(parsed)) sourceList = parsed;
        } catch{}
      }
      if(!sourceList.length){
        sourceList = safeText.split(/[،,|]/).map((item) => item.trim()).filter(Boolean);
      }
    }

    const seen = new Set();
    return sourceList
      .map((entry) => {
        const normalizedCode = normalizeCurrencyCodeValue(entry);
        if(normalizedCode && catalogValues.has(normalizedCode)) return normalizedCode;
        const byLabel = catalogLabels.get(normalizeFreeTextValue(entry).toLocaleLowerCase('ar'));
        return byLabel || '';
      })
      .filter((code) => {
        if(!code || seen.has(code)) return false;
        seen.add(code);
        return true;
      });
  }

  function resolveCenterCurrencyCodesFromLegacyText(rawText, catalog = readCenterCurrencyCatalog()){
    const safeText = normalizeFreeTextValue(rawText, CENTER_CURRENCIES_MAX_LENGTH);
    if(!safeText || safeText === CENTER_CURRENCIES_ALL_LABEL) return [];
    return normalizeCenterCurrencyCodes(safeText, catalog);
  }

  function resolveCenterCurrencyLabel(code, catalog = readCenterCurrencyCatalog()){
    const safeCode = normalizeCurrencyCodeValue(code);
    if(!safeCode) return '';
    const match = (Array.isArray(catalog) ? catalog : []).find((option) => normalizeCurrencyCodeValue(option && (option.code || option.value)) === safeCode);
    return match && match.label ? match.label : safeCode;
  }

  function formatCenterCurrenciesSummary(mode, codes, catalog = readCenterCurrencyCatalog()){
    const normalizedMode = toText(mode) === CENTER_CURRENCY_MODE_CUSTOM ? CENTER_CURRENCY_MODE_CUSTOM : CENTER_CURRENCY_MODE_ALL;
    if(normalizedMode === CENTER_CURRENCY_MODE_ALL) return CENTER_CURRENCIES_ALL_LABEL;

    const safeCodes = normalizeCenterCurrencyCodes(codes, catalog);
    if(!safeCodes.length) return '';
    return safeCodes.map((code) => resolveCenterCurrencyLabel(code, catalog)).join('، ');
  }

  function resolveCenterCurrenciesTriggerLabel(mode, codes, catalog = readCenterCurrencyCatalog()){
    const normalizedMode = toText(mode) === CENTER_CURRENCY_MODE_CUSTOM ? CENTER_CURRENCY_MODE_CUSTOM : CENTER_CURRENCY_MODE_ALL;
    if(normalizedMode === CENTER_CURRENCY_MODE_ALL) return CENTER_CURRENCIES_ALL_LABEL;
    return normalizeCenterCurrencyCodes(codes, catalog).length ? CENTER_CURRENCIES_PARTIAL_LABEL : CENTER_CURRENCIES_EMPTY_LABEL;
  }

  function normalizeCenterCurrencySelection(source, catalog = readCenterCurrencyCatalog()){
    const explicitMode = toText(source && source.currencySelectionMode);
    let normalizedMode = explicitMode === CENTER_CURRENCY_MODE_CUSTOM ? CENTER_CURRENCY_MODE_CUSTOM : CENTER_CURRENCY_MODE_ALL;
    let currencyCodes = normalizeCenterCurrencyCodes(source && source.currencyCodes, catalog);

    if(!explicitMode){
      const legacyText = normalizeFreeTextValue(source && source.currencies, CENTER_CURRENCIES_MAX_LENGTH);
      if(!legacyText || legacyText === CENTER_CURRENCIES_ALL_LABEL){
        normalizedMode = CENTER_CURRENCY_MODE_ALL;
        currencyCodes = [];
      } else {
        normalizedMode = CENTER_CURRENCY_MODE_CUSTOM;
        currencyCodes = resolveCenterCurrencyCodesFromLegacyText(legacyText, catalog);
      }
    }

    if(normalizedMode === CENTER_CURRENCY_MODE_CUSTOM && catalog.length && currencyCodes.length >= catalog.length){
      normalizedMode = CENTER_CURRENCY_MODE_ALL;
      currencyCodes = [];
    }

    return {
      currencySelectionMode: normalizedMode,
      currencyCodes: normalizedMode === CENTER_CURRENCY_MODE_ALL ? [] : currencyCodes,
      currencies: formatCenterCurrenciesSummary(normalizedMode, currencyCodes, catalog)
    };
  }

  function shouldPersistMainCenterTypeLock(source){
    if(!source || typeof source !== 'object') return false;
    if(source.centerTypeLocked === true) return true;

    const centerId = toText(source.id);
    if(centerId && Object.prototype.hasOwnProperty.call(DEFAULT_CENTER_ACCOUNT_BY_ID, centerId)) return true;

    return normalizeType(source.centerType) === 'main';
  }

  function isCenterTypeChangeLocked(center){
    return shouldPersistMainCenterTypeLock(center);
  }

  function resolveNormalizedCenterType(source){
    return shouldPersistMainCenterTypeLock(source) ? 'main' : normalizeType(source && source.centerType);
  }

  function createNormalizedCenterFields(source){
    const normalizedCountry = normalizeCountryValue(source && source.country);
    const normalizedCurrencySelection = normalizeCenterCurrencySelection(source);
    const centerId = toText(source && source.id);
    const canonicalDefaultAccountNo = DEFAULT_CENTER_ACCOUNT_BY_ID[centerId] || '';
    const canonicalDefaultName = DEFAULT_CENTER_NAME_BY_ID[centerId] || '';
    const centerTypeLocked = shouldPersistMainCenterTypeLock(source);
    return {
      name:canonicalDefaultName || normalizeCenterNameValue(source && source.name),
      accountNo:canonicalDefaultAccountNo || finalizeAccountNumberValue(source && source.accountNo),
      centerType:centerTypeLocked ? 'main' : resolveNormalizedCenterType(source),
      centerTypeLocked,
      country:normalizedCountry,
      city:normalizeCityValue(normalizedCountry, source && source.city),
      phone:normalizePhoneValue(source && source.phone),
      currencies:normalizedCurrencySelection.currencies,
      currencySelectionMode:normalizedCurrencySelection.currencySelectionMode,
      currencyCodes:normalizedCurrencySelection.currencyCodes,
      address:normalizeFreeTextValue(source && source.address, CENTER_ADDRESS_MAX_LENGTH),
      imageDataUrl:toText(source && source.imageDataUrl)
    };
  }

  function normalizeCenterDraftFields(draft){
    if(!draft || typeof draft !== 'object') return draft;
    Object.assign(draft, createNormalizedCenterFields(draft));
    return draft;
  }

  function normalizeType(value){
    if(value === 'main') return 'main';
    if(value === 'box') return 'box';
    return 'client';
  }

  function isPrimaryCashBoxCenter(center){
    const safeCenter = center && typeof center === 'object' ? center : null;
    if(!safeCenter) return false;

    const centerId = toText(safeCenter.id);
    if(centerId === 'coa-default-001') return true;

    const accountNo = finalizeAccountNumberValue(safeCenter.accountNo);
    const name = normalizeCenterNameValue(safeCenter.name);
    return normalizeType(safeCenter.centerType) === 'main'
      && accountNo === DEFAULT_CENTER_ACCOUNT_BY_ID['coa-default-001']
      && name === DEFAULT_CENTER_NAME_BY_ID['coa-default-001'];
  }

  function makeId(){
    return `ctr_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
  }

  function isCanonicalDefaultCenterId(centerId){
    return Object.prototype.hasOwnProperty.call(DEFAULT_CENTER_ACCOUNT_BY_ID, toText(centerId));
  }

  function readAccountSequenceCounter(){
    const storedValue = readJsonStorage(AUTO_SEQUENCE_STORAGE_KEY, 0);
    const numericValue = Number(storedValue);
    if(!Number.isFinite(numericValue) || numericValue < 0) return 0;
    return Math.floor(numericValue);
  }

  function writeAccountSequenceCounter(value){
    const normalizedValue = Math.max(0, Math.floor(Number(value) || 0));
    runtime.accountSequenceCounter = normalizedValue;
    storageSet(AUTO_SEQUENCE_STORAGE_KEY, JSON.stringify(normalizedValue));
    return normalizedValue;
  }

  function inferAccountSequenceCounter(list){
    const customCentersCount = (Array.isArray(list) ? list : []).reduce((count, center) => (
      isCanonicalDefaultCenterId(center && center.id) ? count : count + 1
    ), 0);

    return DEFAULT_CENTER_SEEDS.length + customCentersCount;
  }

  function syncAccountSequenceCounter(list){
    const safeList = Array.isArray(list)
      ? list
      : (Array.isArray(sharedState.dataset) ? sharedState.dataset : []);
    const inferredValue = inferAccountSequenceCounter(safeList);
    const storedValue = readAccountSequenceCounter();
    const nextValue = Math.max(inferredValue, storedValue);

    if(runtime.accountSequenceCounter !== nextValue || storedValue !== nextValue){
      return writeAccountSequenceCounter(nextValue);
    }

    runtime.accountSequenceCounter = nextValue;
    return nextValue;
  }

  function isAccountNumberUsedByAnyCenter(accountNo, ignoreId = null){
    const value = finalizeAccountNumberValue(accountNo);
    if(!value) return false;

    return getCenters().some((item) => item.id !== ignoreId && item.accountNo === value);
  }

  function getNextSuggestedAccountNumber(){
    const centers = readCenters();
    let nextNumericValue = syncAccountSequenceCounter(centers) + 1;

    while(nextNumericValue > 0){
      const rawAccountNo = String(nextNumericValue);
      if(rawAccountNo.length > CENTER_ACCOUNT_MAX_LENGTH) return '';

      const finalizedAccountNo = finalizeAccountNumberValue(rawAccountNo);
      if(!isAccountNumberUsedByAnyCenter(finalizedAccountNo)){
        return finalizedAccountNo;
      }

      nextNumericValue += 1;
    }

    return '';
  }

  function createEmptyCenterDraft(timestamp = Date.now()){
    return normalizeCenter({
      id:makeId(),
      ...EMPTY_CENTER_TEMPLATE,
      accountNo:getNextSuggestedAccountNumber(),
      createdAt:timestamp,
      updatedAt:timestamp
    });
  }

  const DEFAULT_CENTER_AVATAR_SRC = 'assets/icons/chart-of-accounts-default-avatar.png';

  function hasCustomCenterImage(center){
    return !!toText(center && center.imageDataUrl);
  }

  function getCenterImageSrc(value){
    return toText(value) || DEFAULT_CENTER_AVATAR_SRC;
  }

  function readFileAsDataUrl(file){
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(toText(reader.result));
      reader.onerror = () => reject(new Error('file-read-failed'));
      reader.readAsDataURL(file);
    });
  }

  function loadImageElement(source){
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.decoding = 'async';
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error('image-load-failed'));
      image.src = source;
    });
  }

  function renderCenterImageToSquareDataUrl(image){
    const naturalWidth = Number(image && (image.naturalWidth || image.width) || 0);
    const naturalHeight = Number(image && (image.naturalHeight || image.height) || 0);
    if(!(naturalWidth > 0) || !(naturalHeight > 0)){
      throw new Error('invalid-image-dimensions');
    }

    const canvas = document.createElement('canvas');
    canvas.width = CENTER_IMAGE_OUTPUT_SIZE;
    canvas.height = CENTER_IMAGE_OUTPUT_SIZE;
    const context = canvas.getContext('2d');
    if(!context){
      throw new Error('canvas-unavailable');
    }

    const sourceSize = Math.min(naturalWidth, naturalHeight);
    const sourceX = Math.max(0, (naturalWidth - sourceSize) / 2);
    const sourceY = Math.max(0, (naturalHeight - sourceSize) / 2);

    context.clearRect(0, 0, CENTER_IMAGE_OUTPUT_SIZE, CENTER_IMAGE_OUTPUT_SIZE);
    context.imageSmoothingEnabled = true;
    if('imageSmoothingQuality' in context){
      context.imageSmoothingQuality = 'high';
    }
    context.drawImage(
      image,
      sourceX,
      sourceY,
      sourceSize,
      sourceSize,
      0,
      0,
      CENTER_IMAGE_OUTPUT_SIZE,
      CENTER_IMAGE_OUTPUT_SIZE
    );

    return canvas.toDataURL(CENTER_IMAGE_OUTPUT_TYPE);
  }

  async function normalizeCenterImageFile(file){
    const imageSource = await readFileAsDataUrl(file);
    const image = await loadImageElement(imageSource);
    return renderCenterImageToSquareDataUrl(image);
  }

  function typeLabel(centerOrType){
    const center = centerOrType && typeof centerOrType === 'object' ? centerOrType : null;
    const type = normalizeType(center ? center.centerType : centerOrType);
    if(center && isPrimaryCashBoxCenter(center)) return 'أساسي / صندوق';
    if(type === 'main') return 'أساسي';
    if(type === 'box') return 'صندوق';
    return 'عميل';
  }

  function isCenterDeletionLocked(center){
    return isCenterTypeChangeLocked(center);
  }

  function getCenterDeletionBlockedMessage(center){
    return isCenterDeletionLocked(center)
      ? MAIN_CENTER_DELETION_BLOCK_MESSAGE
      : 'لا يمكن حذف هذا المركز.';
  }

  function createCoaPickerIconMarkup(type){
    if(type === 'check'){
      return '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4.5 10.5l3.2 3.2 7.8-7.8"></path></svg>';
    }

    return '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 7.5l5 5 5-5"></path></svg>';
  }

  function normalizeCoaChoiceOptions(options){
    const seen = new Set();
    return (Array.isArray(options) ? options : [])
      .map((option) => {
        const value = toText(option && option.value);
        if(!value) return null;
        const label = toText(option && option.label, value) || value;
        const flag = toText(option && option.flag);
        const richType = toText(option && option.richType);
        return { value, label, flag, richType };
      })
      .filter((option) => {
        if(!option || seen.has(option.value)) return false;
        seen.add(option.value);
        return true;
      });
  }

  function resolveCoaChoiceFallbackValue(options, fallbackValue){
    const safeOptions = normalizeCoaChoiceOptions(options);
    if(fallbackValue == null){
      return safeOptions[0] ? safeOptions[0].value : '';
    }

    const normalizedFallback = toText(fallbackValue);
    if(!normalizedFallback) return '';
    return safeOptions.some((option) => option.value === normalizedFallback) ? normalizedFallback : '';
  }

  function resolveCoaChoiceValue(options, value, fallbackValue){
    const safeOptions = normalizeCoaChoiceOptions(options);
    const normalizedValue = toText(value);
    if(normalizedValue && safeOptions.some((option) => option.value === normalizedValue)){
      return normalizedValue;
    }
    return resolveCoaChoiceFallbackValue(safeOptions, fallbackValue);
  }

  function createChoiceOptionsFromLabels(values){
    return normalizeCoaChoiceOptions((Array.isArray(values) ? values : []).map((value) => ({ value, label:value })));
  }

  function normalizeCountryValue(value){
    const normalizedCountry = toText(value);
    return COUNTRY_OPTIONS.some((option) => option.value === normalizedCountry) ? normalizedCountry : '';
  }

  function normalizeCityValue(country, value){
    const normalizedCountry = normalizeCountryValue(country);
    const normalizedCity = toText(value);
    if(!normalizedCountry || !normalizedCity) return '';

    const countryCities = COUNTRY_CITY_LIBRARY[normalizedCountry] || [];
    return countryCities.includes(normalizedCity) ? normalizedCity : '';
  }

  function buildCountryChoiceOptions(){
    return normalizeCoaChoiceOptions(COUNTRY_OPTIONS);
  }

  function buildCityChoiceOptions(country){
    const normalizedCountry = normalizeCountryValue(country);
    return createChoiceOptionsFromLabels(COUNTRY_CITY_LIBRARY[normalizedCountry] || []);
  }

  function buildCenterTypeOptions(center = null){
    return normalizeCoaChoiceOptions(CENTER_TYPE_OPTIONS.map((option) => (
      option && option.value === 'main' && isPrimaryCashBoxCenter(center)
        ? { ...option, label:'أساسي / صندوق' }
        : option
    )));
  }

  function createCoaChoicePickerMarkup({ pickerDataAttribute = '', triggerId, inputId, fieldName, valueDataAttribute = '', value, options, placeholder = '', fallbackValue, disabled = false }){
    const safeOptions = normalizeCoaChoiceOptions(options);
    const normalizedValue = resolveCoaChoiceValue(safeOptions, value, fallbackValue);
    const activeOption = safeOptions.find((option) => option.value === normalizedValue) || null;
    const displayText = activeOption && activeOption.label ? activeOption.label : toText(placeholder);
    const valueClassName = activeOption ? 'coa-choice-picker__value' : 'coa-choice-picker__value is-placeholder';

    return `
      <div class="coa-choice-picker${disabled ? ' is-disabled' : ''}" data-taif-inline-picker-host="true" ${pickerDataAttribute}>
        <button id="${escapeHtml(triggerId)}" class="coa-choice-picker__trigger" type="button" aria-haspopup="listbox" aria-expanded="false" aria-disabled="${disabled ? 'true' : 'false'}" data-coa-choice-trigger data-taif-picker-trigger="true" ${disabled ? 'disabled' : ''}>
          <span class="${valueClassName}" ${valueDataAttribute}>${escapeHtml(displayText)}</span>
          <span class="coa-choice-picker__icon">${createCoaPickerIconMarkup('chevronDown')}</span>
        </button>
        <input id="${escapeHtml(inputId)}" type="hidden" value="${escapeHtml(normalizedValue)}" data-coa-field="${escapeHtml(fieldName)}">
      </div>
    `;
  }


  function createCoaCurrencyFlagMarkup(option, { className = 'coa-choice-popover__flag-image' } = {}){
    const safeCode = normalizeCurrencyCodeValue(option && (option.code || option.value));
    if(!safeCode) return '';

    const currencyDomain = TAIF.currencyDomain || TAIF.currencyManagement || {};
    const createFlagImageMarkup = currencyDomain && typeof currencyDomain.createFlagImageMarkup === 'function'
      ? currencyDomain.createFlagImageMarkup
      : null;

    if(typeof createFlagImageMarkup === 'function'){
      const markup = createFlagImageMarkup({ code:safeCode, flag:toText(option && option.flag) }, { className, decorative:true });
      if(toText(markup)) return markup;
    }

    const flags = TAIF && TAIF.assets && TAIF.assets.flags;
    const asset = flags && typeof flags.resolveFlagAsset === 'function'
      ? flags.resolveFlagAsset(toText(option && option.flag) || safeCode, 'circle')
      : null;
    const src = asset && asset.src ? asset.src : `assets/flags/circle/${String(toText(option && option.flag) || safeCode).trim().toLowerCase().replace(/[^a-z]/g, '') || 'xx'}.png`;
    const alt = normalizeFreeTextValue(option && option.label || safeCode, 80) || safeCode;
    return `<img class="${escapeHtml(className)}" src="${escapeHtml(src)}" alt="${escapeHtml(alt)}">`;
  }

  function createCoaMultiChoicePickerMarkup({ pickerDataAttribute = '', triggerId, valueDataAttribute = '', summaryInputId, modeInputId, codesInputId, fieldName = 'currencies', selection = null, disabled = false }){
    const normalizedSelection = normalizeCenterCurrencySelection(selection || {});
    const triggerLabel = resolveCenterCurrenciesTriggerLabel(normalizedSelection.currencySelectionMode, normalizedSelection.currencyCodes);
    const summaryText = formatCenterCurrenciesSummary(normalizedSelection.currencySelectionMode, normalizedSelection.currencyCodes);
    const valueClassName = triggerLabel === CENTER_CURRENCIES_EMPTY_LABEL ? 'coa-choice-picker__value is-placeholder' : 'coa-choice-picker__value';

    return `
      <div class="coa-choice-picker coa-choice-picker--multi${disabled ? ' is-disabled' : ''}" data-taif-inline-picker-host="true" ${pickerDataAttribute}>
        <button id="${escapeHtml(triggerId)}" class="coa-choice-picker__trigger" type="button" aria-haspopup="listbox" aria-expanded="false" aria-disabled="${disabled ? 'true' : 'false'}" data-coa-choice-trigger data-taif-picker-trigger="true" ${disabled ? 'disabled' : ''}>
          <span class="${valueClassName}" ${valueDataAttribute}>${escapeHtml(triggerLabel)}</span>
          <span class="coa-choice-picker__icon">${createCoaPickerIconMarkup('chevronDown')}</span>
        </button>
        <input id="${escapeHtml(summaryInputId)}" type="hidden" value="${escapeHtml(summaryText)}" data-coa-field="${escapeHtml(fieldName)}">
        <input id="${escapeHtml(modeInputId)}" type="hidden" value="${escapeHtml(normalizedSelection.currencySelectionMode)}" data-coa-center-currencies-mode>
        <input id="${escapeHtml(codesInputId)}" type="hidden" value="${escapeHtml(normalizedSelection.currencyCodes.join(','))}" data-coa-center-currencies-codes>
      </div>
    `;
  }

  function setCoaChoicePopoverState({ picker = null, popover = null, trigger = null, isOpen = false } = {}){
    if(typeof setDisclosureOpenState === 'function'){
      setDisclosureOpenState({ root: picker, popup: popover, trigger, isOpen });
      return;
    }
    const open = !!isOpen;
    if(picker) picker.classList.toggle('is-open', open);
    if(popover){
      popover.hidden = !open;
      popover.classList.toggle('is-open', open);
    }
    if(trigger) trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
  }

  function createCoaInlinePickerCommitController(trigger){
    return createSharedInlinePickerCommitController({
      trigger,
      selectionDatasetKey:'taifCoaPickerSelectionCommitted'
    });
  }

  function registerCoaInlinePickerApi({ picker, trigger = null, getPopover = null, api: pickerApi, clearCommittedSelection = null, registerCleanup = null } = {}){
    registerSharedInlinePickerApi({
      picker,
      trigger,
      getPopover,
      api:pickerApi,
      clearCommittedSelection,
      registerCleanup
    });
  }

  function updateTextInputValue(input, nextValue){
    if(!(input instanceof HTMLInputElement)) return;

    const next = String(nextValue == null ? '' : nextValue);
    if(input.value === next) return;

    const previousValue = input.value;
    const previousStart = Number.isInteger(input.selectionStart) ? input.selectionStart : previousValue.length;
    const previousEnd = Number.isInteger(input.selectionEnd) ? input.selectionEnd : previousValue.length;
    const nextCursor = Math.max(0, Math.min(next.length, previousStart + (next.length - previousValue.length)));

    input.value = next;

    try {
      if(previousStart === previousEnd){
        input.setSelectionRange(nextCursor, nextCursor);
      } else {
        input.setSelectionRange(next.length, next.length);
      }
    } catch{}
  }

  function bindNormalizedInput(input, normalize, registerCleanup = null, options = null){
    if(!(input instanceof HTMLInputElement) || typeof normalize !== 'function') return;

    const config = options && typeof options === 'object' ? options : null;
    const normalizeOnInput = config?.normalizeOnInput !== false;
    const normalizeOnBlur = config?.normalizeOnBlur !== false;

    const syncValue = () => {
      if(!normalizeOnInput) return;
      updateTextInputValue(input, normalize(input.value));
    };

    const finalizeValue = () => {
      if(!normalizeOnBlur) return;
      const nextValue = normalize(input.value);
      if(input.value !== nextValue) input.value = nextValue;
    };

    input.addEventListener('input', syncValue);
    input.addEventListener('blur', finalizeValue);

    if(typeof registerCleanup === 'function'){
      registerCleanup(() => {
        input.removeEventListener('input', syncValue);
        input.removeEventListener('blur', finalizeValue);
      });
    }

    if(normalizeOnInput){
      syncValue();
    } else if(normalizeOnBlur){
      finalizeValue();
    }
  }

  function focusElementSafely(element){
    if(!(element instanceof HTMLElement)) return false;
    try {
      element.focus({ preventScroll:true });
    } catch{
      try { element.focus(); } catch{}
    }
    return document.activeElement === element;
  }

  function resolveCenterFieldControl(modal, fieldName){
    if(!(modal instanceof Element)) return null;

    const field = modal.querySelector(`[data-coa-field="${fieldName}"]`);
    if(!field) return null;

    if(field instanceof HTMLInputElement && field.type === 'hidden'){
      return field.closest('.coa-choice-picker')?.querySelector('[data-coa-choice-trigger]') || field;
    }

    return field;
  }

  function clearCenterFieldValidationState(modal, fieldName){
    const control = resolveCenterFieldControl(modal, fieldName);
    if(!control) return;
    control.classList.remove('is-invalid');
    control.removeAttribute('aria-invalid');
  }

  function clearCenterValidationState(modal){
    if(!(modal instanceof Element)) return;
    modal.querySelectorAll('.is-invalid').forEach((node) => {
      node.classList.remove('is-invalid');
      node.removeAttribute('aria-invalid');
    });
  }

  function showCenterFieldValidationError(modal, fieldName, message){
    clearCenterValidationState(modal);

    const control = resolveCenterFieldControl(modal, fieldName);
    if(control){
      control.classList.add('is-invalid');
      control.setAttribute('aria-invalid', 'true');
      focusElementSafely(control);
      if(typeof control.scrollIntoView === 'function'){
        try {
          control.scrollIntoView({ block:'center', inline:'nearest', behavior:'smooth' });
        } catch{}
      }
    }

    showToast(message);
    return false;
  }

  function validateCenterDraft(modal, draft, ignoreId = null){
    if(!draft || typeof draft !== 'object'){
      showToast('تعذر قراءة بيانات المركز.');
      return false;
    }

    if(!draft.name){
      return showCenterFieldValidationError(modal, 'name', 'اسم المركز مطلوب.');
    }

    if(draft.name.replace(/\s+/g, '').length < 2){
      return showCenterFieldValidationError(modal, 'name', 'اسم المركز قصير جدًا.');
    }

    if(!containsLetter(draft.name)){
      return showCenterFieldValidationError(modal, 'name', 'اسم المركز يجب أن يحتوي على أحرف فعلية.');
    }

    if(!draft.accountNo){
      return showCenterFieldValidationError(modal, 'accountNo', 'رقم حساب المركز مطلوب.');
    }

    if(!/^\d+$/.test(draft.accountNo)){
      return showCenterFieldValidationError(modal, 'accountNo', 'رقم حساب المركز يجب أن يحتوي على أرقام فقط.');
    }

    if(draft.accountNo.length < CENTER_ACCOUNT_MIN_LENGTH){
      return showCenterFieldValidationError(modal, 'accountNo', `رقم حساب المركز يجب أن يتكون من ${CENTER_ACCOUNT_MIN_LENGTH} أرقام على الأقل.`);
    }

    if(draft.accountNo.length > CENTER_ACCOUNT_MAX_LENGTH){
      return showCenterFieldValidationError(modal, 'accountNo', `رقم حساب المركز يجب ألا يتجاوز ${CENTER_ACCOUNT_MAX_LENGTH} أرقام.`);
    }

    if(accountExists(draft.accountNo, ignoreId)){
      return showCenterFieldValidationError(modal, 'accountNo', 'رقم حساب المركز مستخدم بالفعل.');
    }

    if(draft.phone){
      const digitsCount = countDigits(draft.phone);
      if(digitsCount < CENTER_PHONE_MIN_DIGITS || digitsCount > CENTER_PHONE_MAX_DIGITS){
        return showCenterFieldValidationError(modal, 'phone', `رقم الهاتف يجب أن يحتوي بين ${CENTER_PHONE_MIN_DIGITS} و${CENTER_PHONE_MAX_DIGITS} رقمًا.`);
      }
    }

    if(draft.country && !draft.city){
      return showCenterFieldValidationError(modal, 'city', 'اختر مدينة تابعة للدولة المحددة.');
    }

    clearCenterValidationState(modal);
    return true;
  }

  function formatDateTime(timestamp){
    if(!timestamp) return '—';

    try {
      const date = new Date(timestamp);
      return `${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}/${date.getFullYear()} — ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
    } catch{
      return '—';
    }
  }

  function normalizeCenter(center){
    const createdAt = Number(center && center.createdAt) || Date.now();

    return {
      id:toText(center && center.id, makeId()),
      ...EMPTY_CENTER_TEMPLATE,
      ...createNormalizedCenterFields(center),
      deleted:!!(center && center.deleted),
      deletedAt:Number(center && center.deletedAt) || 0,
      createdAt,
      updatedAt:Number(center && center.updatedAt) || createdAt
    };
  }

  function shouldStripRetiredDefaultCenter(center){
    return RETIRED_DEFAULT_CENTER_IDS.has(toText(center && center.id));
  }

  function normalizeDataset(list){
    return (Array.isArray(list) ? list : [])
      .filter((center) => !shouldStripRetiredDefaultCenter(center))
      .map(normalizeCenter)
      .sort((a, b) => (
        a.deleted !== b.deleted
          ? (a.deleted ? 1 : -1)
          : (a.createdAt - b.createdAt)
      ));
  }

  function notifyCentersChange(nextState){
    const detail = { state: clone(nextState) };
    const events = TAIF.core && TAIF.core.events;
    if(events && typeof events.emitDomainUpdate === 'function'){
      events.emitDomainUpdate('accounts', detail, { source:'chart-of-accounts-core' });
      return;
    }
    try{
      window.dispatchEvent(new CustomEvent('taif:chart-of-accounts-updated', { detail }));
    }catch{}
  }

  function persistCenters(list, { notify = false } = {}){
    sharedState.dataset = normalizeDataset(list);
    syncAccountSequenceCounter(sharedState.dataset);
    storageSet(STORAGE_KEY, JSON.stringify(sharedState.dataset));
    if(notify) notifyCentersChange(sharedState.dataset);
    return sharedState.dataset;
  }

  function readCenters(){
    if(Array.isArray(sharedState.dataset)) return sharedState.dataset;

    const parsed = readJsonStorage(STORAGE_KEY, null);
    const source = Array.isArray(parsed) ? parsed : DEFAULT_CENTERS;
    return persistCenters(source);
  }

  function writeCenters(next){
    return persistCenters(next, { notify:true });
  }

  function getCenters(activeOnly){
    const all = readCenters();
    if(activeOnly === true) return all.filter((item) => !item.deleted);
    if(activeOnly === false) return all.filter((item) => item.deleted);
    return all.slice();
  }

  function updateCenters(projector){
    return writeCenters(projector(getCenters()));
  }

  function replaceCenter(centerId, updater){
    return updateCenters((items) => items.map((item) => (
      item.id === centerId ? updater(item) : item
    )));
  }
  function removeCenter(centerId){
    const center = findCenter(centerId);
    if(isCenterDeletionLocked(center)) return getCenters();
    return updateCenters((items) => items.filter((item) => item.id !== centerId));
  }

  function findCenter(id){
    return readCenters().find((item) => item.id === id) || null;
  }

  function getSelectedCenter(){
    const selected = sharedState.selectedId ? findCenter(sharedState.selectedId) : null;
    return selected && !selected.deleted ? selected : null;
  }

  function setSelected(id){
    const active = getCenters(true);
    sharedState.selectedId = active.some((item) => item.id === id) ? id : null;
  }


  function normalizeSearchValue(value){
    return collapseWhitespace(normalizeDigits(value)).toLocaleLowerCase('ar');
  }

  function getCenterFilterText(){
    return normalizeSearchValue(runtime.filter || '');
  }

  function centerMatchesFilter(center, filterText = getCenterFilterText()){
    const needle = normalizeSearchValue(filterText);
    if(!needle) return true;

    const haystack = normalizeSearchValue([
      center && center.accountNo,
      center && center.name,
      center && center.country,
      center && center.city,
      center && center.phone,
      center && center.currencies,
      center && center.address,
      typeLabel(center)
    ].filter(Boolean).join(' '));

    return haystack.includes(needle);
  }

  function filterActiveCenters(activeCenters, filterText = getCenterFilterText()){
    const needle = normalizeSearchValue(filterText);
    if(!needle) return activeCenters.slice();
    return activeCenters.filter((center) => centerMatchesFilter(center, needle));
  }

  function accountExists(accountNo, ignoreId){
    const value = finalizeAccountNumberValue(accountNo);
    return !!value && readCenters().some((item) => (
      !item.deleted && item.id !== ignoreId && item.accountNo === value
    ));
  }

  function showToast(message){
    const existing = document.querySelector('.coa-toast');
    if(existing) existing.remove();

    const node = document.createElement('div');
    node.className = 'coa-toast';
    node.textContent = message;
    node.style.cssText = 'position:fixed;top:18px;left:50%;transform:translateX(-50%);z-index:2602;background:rgba(15,23,42,.96);color:#fff;padding:10px 16px;border-radius:8px;font:700 13.8px/1.24 var(--taif-font-family);box-shadow:0 18px 36px rgba(15,23,42,.18)';
    TAIF?.core?.utils?.markOwnedNode?.(node, 'chart-of-accounts');
    document.body.appendChild(node);

    setTimeout(() => {
      node.style.opacity = '0';
      node.style.transition = 'opacity .35s ease';
    }, 1400);

    setTimeout(() => {
      node.remove();
    }, 1900);
  }


  function prepareCenterImageElement(image){
    if(!(image instanceof HTMLImageElement)) return null;

    image.dataset.coaCenterImage = 'true';
    image.dataset.coaFallbackSrc = DEFAULT_CENTER_AVATAR_SRC;
    image.dataset.coaFallbackApplied = image.dataset.coaFallbackApplied === 'true' ? 'true' : 'false';
    image.alt = '';
    image.loading = 'eager';
    image.decoding = 'async';
    image.draggable = false;
    return image;
  }

  function applyCenterImageSource(image, value){
    const target = prepareCenterImageElement(image);
    if(!target) return;
    target.dataset.coaFallbackApplied = 'false';
    target.src = getCenterImageSrc(value);
  }

  function handleCenterImageLoadError(event){
    const image = prepareCenterImageElement(event && event.target);
    if(!image) return;

    if(image.dataset.coaFallbackApplied === 'true') return;
    image.dataset.coaFallbackApplied = 'true';
    image.src = image.dataset.coaFallbackSrc || DEFAULT_CENTER_AVATAR_SRC;
  }

  function hydrateCenterImages(root){
    if(!(root instanceof Element)) return;
    root.querySelectorAll('img[data-coa-center-image]').forEach((image) => {
      prepareCenterImageElement(image);
      if(image.complete && !image.naturalWidth){
        handleCenterImageLoadError({ target:image });
      }
    });
  }

  function ensureCenterImageFallbackHandling(root){
    if(!(root instanceof Element) || root.__coaCenterImageFallbackBound) return;
    root.__coaCenterImageFallbackBound = true;
    root.addEventListener('error', handleCenterImageLoadError, true);
  }

  Object.assign(internal, {
    STORAGE_KEY,
    EMPTY_CENTER_TEMPLATE,
    DEFAULT_CENTERS,
    CENTER_TYPE_OPTIONS,
    COUNTRY_OPTIONS,
    COUNTRY_CITY_LIBRARY,
    CENTER_NAME_MAX_LENGTH,
    CENTER_ACCOUNT_MIN_LENGTH,
    CENTER_ACCOUNT_MAX_LENGTH,
    CENTER_PHONE_MIN_DIGITS,
    CENTER_PHONE_MAX_DIGITS,
    CENTER_PHONE_MAX_LENGTH,
    CENTER_ADDRESS_MAX_LENGTH,
    CENTER_CURRENCIES_MAX_LENGTH,
    CENTER_CURRENCY_MODE_ALL,
    CENTER_CURRENCY_MODE_CUSTOM,
    CENTER_CURRENCIES_ALL_LABEL,
    CENTER_CURRENCIES_PARTIAL_LABEL,
    CENTER_CURRENCIES_EMPTY_LABEL,
    CENTER_IMAGE_OUTPUT_SIZE,
    CENTER_IMAGE_OUTPUT_TYPE,    DEFAULT_CENTER_AVATAR_SRC,
    MAIN_CENTER_DELETION_POLICY_NOTE,
    MAIN_CENTER_TYPE_LOCK_NOTE,
    MAIN_CENTER_DELETION_BLOCK_MESSAGE,
    sharedState,
    runtime,
    toText,
    collapseWhitespace,
    normalizeDigits,
    countDigits,
    clampNumber,
    containsLetter,
    normalizeFreeTextValue,
    normalizeCenterNameValue,
    normalizeAccountNumberValue,
    finalizeAccountNumberValue,
    normalizePhoneValue,
    normalizeCurrencyCodeValue,
    readCenterCurrencyCatalog,
    normalizeCenterCurrencyCodes,
    resolveCenterCurrencyCodesFromLegacyText,
    resolveCenterCurrencyLabel,
    formatCenterCurrenciesSummary,
    resolveCenterCurrenciesTriggerLabel,
    normalizeCenterCurrencySelection,
    normalizeCenterDraftFields,
    normalizeType,
    isPrimaryCashBoxCenter,
    makeId,
    createEmptyCenterDraft,
    hasCustomCenterImage,
    getCenterImageSrc,
    readFileAsDataUrl,
    loadImageElement,
    renderCenterImageToSquareDataUrl,    normalizeCenterImageFile,
    typeLabel,
    isCenterTypeChangeLocked,
    isCenterDeletionLocked,
    getCenterDeletionBlockedMessage,
    createCoaPickerIconMarkup,
    normalizeCoaChoiceOptions,
    resolveCoaChoiceFallbackValue,
    resolveCoaChoiceValue,
    createChoiceOptionsFromLabels,
    normalizeCountryValue,
    normalizeCityValue,
    buildCountryChoiceOptions,
    buildCityChoiceOptions,
    buildCenterTypeOptions,
    createCoaChoicePickerMarkup,
    createCoaCurrencyFlagMarkup,
    createCoaMultiChoicePickerMarkup,
    setCoaChoicePopoverState,
    createCoaInlinePickerCommitController,
    registerCoaInlinePickerApi,
    updateTextInputValue,
    bindNormalizedInput,
    focusElementSafely,
    resolveCenterFieldControl,
    clearCenterFieldValidationState,
    clearCenterValidationState,
    showCenterFieldValidationError,
    validateCenterDraft,
    formatDateTime,
    normalizeCenter,
    normalizeDataset,
    readCenters,
    writeCenters,
    getCenters,
    updateCenters,
    replaceCenter,
    removeCenter,
    findCenter,
    getSelectedCenter,
    setSelected,
    normalizeSearchValue,
    getCenterFilterText,
    centerMatchesFilter,
    filterActiveCenters,
    accountExists,
    showToast,
    prepareCenterImageElement,
    applyCenterImageSource,
    handleCenterImageLoadError,
    hydrateCenterImages,
    ensureCenterImageFallbackHandling
  });
})();
