(() => {
  const TAIF = window.TAIF;
  const api = TAIF.chartOfAccounts = TAIF.chartOfAccounts || {};
  const internal = api.internal && typeof api.internal === 'object' ? api.internal : {};
  api.internal = internal;
  const { runtime, sharedState, detachSelectionDismiss, dismissOverlays, readCenters, getSelectedCenter, renderShell, writeCenters } = internal;

  function cleanupView(){
    detachSelectionDismiss();
    if(typeof runtime.toolbarCleanup === 'function') {
      try{ runtime.toolbarCleanup(); }catch{}
      runtime.toolbarCleanup = null;
    }
    sharedState.selectedId = null;
    dismissOverlays();
    const toast = document.querySelector('.coa-toast');
    if(toast) toast.remove();
    runtime.panel = null;
  }

  api.readState = readCenters;
  api.writeState = writeCenters;
  api.dismissOverlays = dismissOverlays;
  api.cleanup = cleanupView;

  TAIF.registerViewCleanup('chart-of-accounts', cleanupView);
  TAIF.registerViewRenderer('chart-of-accounts', ({ panel }) => {
    dismissOverlays();
    readCenters();
    if(sharedState.selectedId && !getSelectedCenter()) sharedState.selectedId = null;
    renderShell(panel);
  });
})();
