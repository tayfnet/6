(() => {
  const TAIF = window.TAIF;
  const { escapeHtml, createTypeaheadNavigator, createAnimationFrameScheduler } = TAIF.core.utils;
  const api = TAIF.chartOfAccounts = TAIF.chartOfAccounts || {};
  const internal = api.internal && typeof api.internal === 'object' ? api.internal : {};
  api.internal = internal;
  const {
    toText,
    clampNumber,
    normalizeCoaChoiceOptions,
    resolveCoaChoiceValue,
    setCoaChoicePopoverState,
    createCoaPickerIconMarkup,
    createCoaInlinePickerCommitController,
    registerCoaInlinePickerApi,
    createCoaCurrencyFlagMarkup,
    focusElementSafely,
    normalizeCenterCurrencyCodes,
    resolveCenterCurrenciesTriggerLabel,
    formatCenterCurrenciesSummary,
    CENTER_CURRENCY_MODE_ALL,
    CENTER_CURRENCY_MODE_CUSTOM,
    CENTER_CURRENCIES_ALL_LABEL,
    CENTER_CURRENCIES_EMPTY_LABEL
  } = internal;

  function focusChoiceTarget(element){
    const focusFn = internal && typeof internal.focusCoaModalTarget === 'function' ? internal.focusCoaModalTarget : null;
    if(focusFn) return focusFn(element);
    if(typeof focusElementSafely === 'function') return focusElementSafely(element);
    if(!(element instanceof HTMLElement)) return false;
    try{ element.focus({ preventScroll:true }); }catch{ try{ element.focus(); }catch{} }
    return document.activeElement === element;
  }

  function createChoicePickerBaseApi({
    trigger,
    isOpen,
    openForKeyboard,
    closePopover,
    focusActiveOption,
    stepChoiceSelection,
    commitController
  }){
    return {
      type: 'choice',
      getTrigger(){
        return trigger;
      },
      isOpen,
      openForKeyboard,
      close: closePopover,
      focusActiveOption(){
        return focusActiveOption('current');
      },
      stepValue(step){
        return stepChoiceSelection(step);
      },
      prepareKeyboardSelection: commitController.prepareKeyboardSelection,
      markCommittedSelection: commitController.markCommittedSelection,
      consumeCommittedSelection: commitController.consumeCommittedSelection,
      clearCommittedSelection: commitController.clearCommittedSelection
    };
  }

  function mountCoaChoicePicker({
    modal,
    scrollArea,
    pickerSelector,
    triggerSelector,
    inputSelector,
    valueSelector,
    options,
    ariaLabel,
    registerCleanup = null,
    maxPopoverHeight = 196,
    placeholder = '',
    fallbackValue,
    disabled = false
  }){
    const picker = modal.querySelector(pickerSelector);
    const trigger = modal.querySelector(triggerSelector);
    const input = modal.querySelector(inputSelector);
    const valueNode = modal.querySelector(valueSelector);
    const panel = scrollArea instanceof HTMLElement ? scrollArea : null;
    const overlayHost = (panel && panel.closest('.coa-form')) || modal.querySelector('.coa-form') || panel;
    if(!picker || !trigger || !input || !valueNode || !panel || !overlayHost){
      return {
        close(){},
        getTrigger(){
          return null;
        },
        isOpen(){
          return false;
        },
        openForKeyboard(){},
        focusActiveOption(){
          return false;
        },
        stepValue(){
          return false;
        },
        prepareKeyboardSelection(){},
        markCommittedSelection(){},
        consumeCommittedSelection(){
          return false;
        },
        clearCommittedSelection(){},
        getValue(){
          return '';
        },
        setValue(){},
        setOptions(){},
        setPlaceholder(){},
        setDisabled(){}
      };
    }

    const commitController = createCoaInlinePickerCommitController(trigger);
    let popover = null;
    let pickerApi = null;
    const popoverPositionScheduler = typeof createAnimationFrameScheduler === 'function'
      ? createAnimationFrameScheduler(positionPopover)
      : null;
    let currentOptions = normalizeCoaChoiceOptions(options);
    let placeholderText = toText(placeholder);
    let currentFallbackValue = fallbackValue;
    let isDisabled = !!disabled;
    let currentValue = resolveCoaChoiceValue(currentOptions, input.value, currentFallbackValue);

    const typeahead = typeof createTypeaheadNavigator === 'function'
      ? createTypeaheadNavigator({
          getItems: () => currentOptions,
          getCurrentIndex: () => currentOptions.findIndex((option) => option.value === currentValue),
          resolveLabel: (option) => option && option.label,
          onMatch: (option, index) => {
            if(!option || !option.value) return;
            if(isPopoverOpen()){
              focusOption(index, { scrollBehavior:'auto', scrollBlock:'start' });
              return;
            }
            syncChoiceState(option.value);
            if(commitController && typeof commitController.markCommittedSelection === 'function'){
              commitController.markCommittedSelection();
            }
          }
        })
      : { reset(){}, handleKey(){ return false; } };

    function getOptionData(nextValue){
      return currentOptions.find((option) => option.value === nextValue) || null;
    }

    function getOptionButtons(){
      if(!popover) return [];
      return Array.from(popover.querySelectorAll('[data-coa-choice-option]')).filter((node) => node instanceof HTMLButtonElement && !node.disabled);
    }

    function syncChoiceValueNode(option){
      const hasOption = !!(option && option.label);
      valueNode.textContent = hasOption ? option.label : placeholderText;
      valueNode.classList.toggle('is-placeholder', !hasOption);
    }

    function syncRenderedOptionState(){
      if(!popover) return;
      popover.querySelectorAll('[data-coa-choice-option]').forEach((optionNode) => {
        const isActive = optionNode.dataset.coaChoiceOption === currentValue;
        optionNode.classList.toggle('is-active', isActive);
        optionNode.setAttribute('aria-selected', isActive ? 'true' : 'false');
      });
    }

    function syncChoiceState(nextValue, { dispatch = true } = {}){
      const previousValue = input.value;
      currentValue = resolveCoaChoiceValue(currentOptions, nextValue, currentFallbackValue);
      input.value = currentValue;
      syncChoiceValueNode(getOptionData(currentValue));
      syncRenderedOptionState();

      if(dispatch && previousValue !== currentValue){
        try{ input.dispatchEvent(new Event('input', { bubbles:true })); }catch{}
        try{ input.dispatchEvent(new Event('change', { bubbles:true })); }catch{}
      }
    }

    function isPopoverOpen(){
      return !!(popover && !popover.hidden);
    }

    function updateTriggerDisabledState(){
      const shouldDisable = !!isDisabled || !currentOptions.length;
      if(shouldDisable && isPopoverOpen()) closePopover();
      trigger.disabled = shouldDisable;
      trigger.setAttribute('aria-disabled', shouldDisable ? 'true' : 'false');
      picker.classList.toggle('is-disabled', shouldDisable);
    }

    function renderPopoverOptions(){
      if(!popover) return;

      if(!currentOptions.length){
        popover.innerHTML = '<div class="coa-choice-popover__empty">لا توجد خيارات متاحة</div>';
        return;
      }

      popover.innerHTML = currentOptions.map((option) => `
        <button class="coa-choice-popover__option" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-taif-inline-picker-option="true" role="option" data-coa-choice-option="${escapeHtml(option.value)}" aria-selected="false">
          <span class="coa-choice-popover__label" data-taif-dropdown-label="true">${escapeHtml(option.label)}</span>
          <span class="coa-choice-popover__check">${createCoaPickerIconMarkup('check')}</span>
        </button>
      `).join('');
      syncRenderedOptionState();
      if(pickerApi) popover.__taifInlinePickerApi = pickerApi;
    }

    function positionPopover(){
      if(!popover || popover.hidden) return;

      const overlayRect = overlayHost.getBoundingClientRect();
      const triggerRect = trigger.getBoundingClientRect();
      const gap = 6;
      const edgePadding = 8;
      const width = Math.max(180, Math.round(triggerRect.width));
      const availableBelow = Math.max(0, Math.floor(overlayRect.bottom - edgePadding - triggerRect.bottom - gap));

      popover.style.width = `${width}px`;
      popover.style.maxHeight = 'none';
      popover.style.visibility = 'hidden';

      const naturalHeight = Math.max(popover.scrollHeight, 72);
      const resolvedMaxHeight = Math.max(72, Number(maxPopoverHeight) || 196);
      const maxHeight = Math.max(72, Math.min(naturalHeight, availableBelow || naturalHeight, resolvedMaxHeight));
      const rawLeft = triggerRect.left - overlayRect.left;
      const minLeft = edgePadding;
      const maxLeft = overlayHost.clientWidth - width - edgePadding;
      const left = clampNumber(rawLeft, minLeft, Math.max(minLeft, maxLeft));
      const top = Math.max(edgePadding, triggerRect.bottom - overlayRect.top + gap);

      popover.dataset.openDirection = 'down';
      popover.style.left = `${left}px`;
      popover.style.top = `${top}px`;
      popover.style.maxHeight = `${maxHeight}px`;
      popover.style.visibility = '';
    }

    const schedulePositionPopover = popoverPositionScheduler
      ? popoverPositionScheduler.schedule.bind(popoverPositionScheduler)
      : (() => {
          requestAnimationFrame(() => {
            positionPopover();
          });
        });

    function closePopover({ restoreFocus = false } = {}){
      typeahead.reset();
      if(popoverPositionScheduler) popoverPositionScheduler.cancel();

      if(popover) popover.style.visibility = '';
      setCoaChoicePopoverState({ picker, popover, trigger, isOpen:false });
      if(restoreFocus) requestAnimationFrame(() => focusChoiceTarget(trigger));
    }

    function focusOption(targetIndex, { scrollBehavior = 'auto', scrollBlock = 'nearest' } = {}){
      const optionButtons = getOptionButtons();
      if(!optionButtons.length) return false;
      const normalizedIndex = clampNumber(Number(targetIndex) || 0, 0, optionButtons.length - 1);
      const targetButton = optionButtons[normalizedIndex];
      const focused = focusChoiceTarget(targetButton);
      if(targetButton && typeof targetButton.scrollIntoView === 'function'){
        try{
          targetButton.scrollIntoView({ block:scrollBlock, inline:'nearest', behavior:scrollBehavior });
        }catch{}
      }
      return focused;
    }

    function focusActiveOption(direction = 'current'){
      const optionButtons = getOptionButtons();
      if(!optionButtons.length) return false;
      const activeIndex = optionButtons.findIndex((button) => button.dataset.coaChoiceOption === currentValue);
      if(direction === 'last') return focusOption(optionButtons.length - 1);
      return focusOption(activeIndex >= 0 ? activeIndex : 0);
    }

    function stepChoiceSelection(step){
      const safeOptions = currentOptions.filter((option) => option && option.value);
      if(!safeOptions.length) return false;
      const normalizedStep = Number(step) >= 0 ? 1 : -1;
      const currentIndex = safeOptions.findIndex((option) => option.value === currentValue);
      const startIndex = currentIndex >= 0 ? currentIndex : (normalizedStep < 0 ? safeOptions.length : -1);
      const nextIndex = clampNumber(startIndex + normalizedStep, 0, safeOptions.length - 1);
      if(nextIndex === startIndex) return false;
      syncChoiceState(safeOptions[nextIndex].value);
      return true;
    }

    function handleOptionCommit(nextValue){
      const shouldRestoreTriggerFocus = commitController.shouldRestoreTriggerFocusAfterSelection();
      syncChoiceState(nextValue);
      if(shouldRestoreTriggerFocus) commitController.markCommittedSelection();
      else commitController.clearCommittedSelection();
      closePopover({ restoreFocus: shouldRestoreTriggerFocus });
    }

    function ensurePopover(){
      if(popover) return;

      popover = document.createElement('div');
      popover.className = 'coa-choice-popover';
      popover.dataset.taifDropdownPopup = 'true';
      popover.dataset.taifDropdownLayout = 'list';
      popover.dataset.taifInlinePicker = 'true';
      popover.setAttribute('role', 'listbox');
      popover.setAttribute('aria-label', ariaLabel);
      popover.hidden = true;
      popover.addEventListener('keydown', onPopoverKeyDown);
      popover.addEventListener('click', onPopoverClick);
      overlayHost.appendChild(popover);
      if(pickerApi) popover.__taifInlinePickerApi = pickerApi;
      renderPopoverOptions();
    }

    function openPopover({ focusDirection = 'current' } = {}){
      if(trigger.disabled || !currentOptions.length) return;
      typeahead.reset();
      commitController.clearCommittedSelection();
      ensurePopover();
      syncChoiceState(currentValue, { dispatch:false });
      setCoaChoicePopoverState({ picker, popover, trigger, isOpen:true });
      positionPopover();
      requestAnimationFrame(() => {
        focusActiveOption(focusDirection);
      });
    }

    function openForKeyboard(){
      if(!isPopoverOpen()) openPopover();
      requestAnimationFrame(() => {
        focusActiveOption('current');
      });
    }

    function togglePopover(){
      if(trigger.disabled || !currentOptions.length) return;
      if(isPopoverOpen()){
        closePopover();
        return;
      }
      openPopover();
    }

    function onTriggerClick(event){
      event.preventDefault();
      togglePopover();
    }

    function onTriggerKeyDown(event){
      if(event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey || trigger.disabled) return;

      if(event.key === 'ArrowDown' || event.key === 'ArrowUp'){
        event.preventDefault();
        if(!isPopoverOpen()) openPopover({ focusDirection:event.key === 'ArrowUp' ? 'last' : 'current' });
        else focusActiveOption(event.key === 'ArrowUp' ? 'last' : 'current');
        return;
      }

      if(event.key === ' ' || event.key === 'Spacebar'){
        event.preventDefault();
        togglePopover();
        return;
      }

      if(typeahead.handleKey(event.key)){
        event.preventDefault();
      }
    }

    function onPopoverClick(event){
      const target = event.target instanceof Element ? event.target.closest('[data-coa-choice-option]') : null;
      if(!(target instanceof HTMLButtonElement)) return;
      handleOptionCommit(target.dataset.coaChoiceOption);
    }

    function onPopoverKeyDown(event){
      if(event.defaultPrevented) return;
      const optionButtons = getOptionButtons();
      const activeElement = event.target instanceof Element ? event.target.closest('[data-coa-choice-option]') : null;
      if(!optionButtons.length || !(activeElement instanceof HTMLButtonElement)) return;
      const currentIndex = optionButtons.indexOf(activeElement);
      if(currentIndex === -1) return;

      if(event.key === 'ArrowDown'){
        event.preventDefault();
        focusOption(Math.min(optionButtons.length - 1, currentIndex + 1));
        return;
      }

      if(event.key === 'ArrowUp'){
        event.preventDefault();
        focusOption(Math.max(0, currentIndex - 1));
        return;
      }

      if(event.key === 'Home'){
        event.preventDefault();
        focusOption(0);
        return;
      }

      if(event.key === 'End'){
        event.preventDefault();
        focusOption(optionButtons.length - 1);
        return;
      }

      if(typeahead.handleKey(event.key, { currentIndex })){
        event.preventDefault();
        return;
      }

      if(event.key === 'Enter' || event.key === 'NumpadEnter' || event.key === ' ' || event.key === 'Spacebar'){
        event.preventDefault();
        activeElement.click();
        return;
      }

      if(event.key === 'Tab'){
        closePopover();
      }
    }

    function onPointerDown(event){
      if(!isPopoverOpen()) return;
      const target = event.target;
      if(!(target instanceof Element)) return;
      if(picker.contains(target)) return;
      if(popover && popover.contains(target)) return;
      closePopover();
    }

    function onModalKeyDownCapture(event){
      if(!isPopoverOpen()) return;
      if(event.key !== 'Escape') return;
      event.preventDefault();
      event.stopPropagation();
      closePopover({ restoreFocus:true });
    }

    function setOptions(nextOptions, { preserveValue = true, fallbackValue:nextFallbackValue } = {}){
      typeahead.reset();
      currentOptions = normalizeCoaChoiceOptions(nextOptions);
      if(nextFallbackValue !== undefined) currentFallbackValue = nextFallbackValue;
      const desiredValue = preserveValue ? input.value : '';
      if(popover) renderPopoverOptions();
      syncChoiceState(desiredValue, { dispatch:true });
      updateTriggerDisabledState();
      if(isPopoverOpen()) schedulePositionPopover();
    }

    function setPlaceholder(nextPlaceholder){
      placeholderText = toText(nextPlaceholder);
      syncChoiceValueNode(getOptionData(currentValue));
      if(isPopoverOpen()) schedulePositionPopover();
    }

    function setDisabled(nextDisabled){
      isDisabled = !!nextDisabled;
      updateTriggerDisabledState();
    }

    function setValue(nextValue, { dispatch = true } = {}){
      syncChoiceState(nextValue, { dispatch });
      if(isPopoverOpen()) schedulePositionPopover();
    }

    syncChoiceState(currentValue, { dispatch:false });
    updateTriggerDisabledState();

    pickerApi = createChoicePickerBaseApi({
      trigger,
      isOpen: isPopoverOpen,
      openForKeyboard,
      closePopover,
      focusActiveOption,
      stepChoiceSelection,
      commitController
    });
    Object.assign(pickerApi, {
      getValue(){
        return currentValue;
      },
      setValue,
      setOptions,
      setPlaceholder,
      setDisabled
    });
    registerCoaInlinePickerApi({
      picker,
      trigger,
      getPopover: () => popover,
      api: pickerApi,
      clearCommittedSelection: commitController.clearCommittedSelection,
      registerCleanup
    });

    trigger.addEventListener('click', onTriggerClick);
    trigger.addEventListener('keydown', onTriggerKeyDown);
    panel.addEventListener('scroll', schedulePositionPopover, { passive:true });
    document.addEventListener('pointerdown', onPointerDown, true);
    modal.addEventListener('keydown', onModalKeyDownCapture, true);
    window.addEventListener('resize', schedulePositionPopover, { passive:true });

    const cleanup = () => {
      if(popoverPositionScheduler) popoverPositionScheduler.cancel();

      trigger.removeEventListener('click', onTriggerClick);
      trigger.removeEventListener('keydown', onTriggerKeyDown);
      panel.removeEventListener('scroll', schedulePositionPopover, { passive:true });
      document.removeEventListener('pointerdown', onPointerDown, true);
      modal.removeEventListener('keydown', onModalKeyDownCapture, true);
      window.removeEventListener('resize', schedulePositionPopover, { passive:true });
      if(popover){
        popover.removeEventListener('keydown', onPopoverKeyDown);
        popover.removeEventListener('click', onPopoverClick);
        popover.remove();
      }
      popover = null;
    };

    if(typeof registerCleanup === 'function') registerCleanup(cleanup);

    return pickerApi;
  }

  function mountCoaMultiChoicePicker({
    modal,
    scrollArea,
    pickerSelector,
    triggerSelector,
    valueSelector,
    summaryInputSelector,
    modeInputSelector,
    codesInputSelector,
    options,
    ariaLabel,
    registerCleanup = null,
    maxPopoverHeight = 232,
    disabled = false
  }){
    const picker = modal.querySelector(pickerSelector);
    const trigger = modal.querySelector(triggerSelector);
    const valueNode = modal.querySelector(valueSelector);
    const summaryInput = modal.querySelector(summaryInputSelector);
    const modeInput = modal.querySelector(modeInputSelector);
    const codesInput = modal.querySelector(codesInputSelector);
    const panel = scrollArea instanceof HTMLElement ? scrollArea : null;
    const overlayHost = (panel && panel.closest('.coa-form')) || modal.querySelector('.coa-form') || panel;
    if(!picker || !trigger || !valueNode || !summaryInput || !modeInput || !codesInput || !panel || !overlayHost){
      return {
        close(){},
        getTrigger(){ return null; },
        isOpen(){ return false; },
        openForKeyboard(){},
        focusActiveOption(){ return false; },
        stepValue(){ return false; },
        prepareKeyboardSelection(){},
        markCommittedSelection(){},
        consumeCommittedSelection(){ return false; },
        clearCommittedSelection(){},
        readDraftInto(){},
        getSelection(){ return { currencySelectionMode:CENTER_CURRENCY_MODE_ALL, currencyCodes:[], currencies:CENTER_CURRENCIES_ALL_LABEL }; },
        setOptions(){},
        setSelection(){},
        setDisabled(){}
      };
    }

    const commitController = createCoaInlinePickerCommitController(trigger);
    const MULTI_ALL_VALUE = '__all__';
    let popover = null;
    let pickerApi = null;
    const popoverPositionScheduler = typeof createAnimationFrameScheduler === 'function'
      ? createAnimationFrameScheduler(positionPopover)
      : null;
    let currentOptions = normalizeCoaChoiceOptions(options);
    let isDisabled = !!disabled;
    let currentMode = toText(modeInput.value) === CENTER_CURRENCY_MODE_CUSTOM ? CENTER_CURRENCY_MODE_CUSTOM : CENTER_CURRENCY_MODE_ALL;
    let currentCodes = normalizeCenterCurrencyCodes(codesInput.value, currentOptions.map((option) => ({ code:option.value, label:option.label })));

    function getCatalog(){
      return currentOptions.map((option) => ({ code:option.value, label:option.label }));
    }

    function getEffectiveSelectedCodes(){
      if(currentMode === CENTER_CURRENCY_MODE_ALL){
        return currentOptions.map((option) => option.value);
      }
      return normalizeCenterCurrencyCodes(Array.from(currentCodes), getCatalog());
    }

    function areAllSelected(){
      return currentOptions.length > 0 && getEffectiveSelectedCodes().length === currentOptions.length;
    }

    function isPopoverOpen(){
      return !!(popover && !popover.hidden);
    }

    function isValueSelected(value){
      if(value === MULTI_ALL_VALUE) return areAllSelected();
      return getEffectiveSelectedCodes().includes(value);
    }

    function normalizeSelectionState(mode, codes){
      let nextMode = toText(mode) === CENTER_CURRENCY_MODE_CUSTOM ? CENTER_CURRENCY_MODE_CUSTOM : CENTER_CURRENCY_MODE_ALL;
      let nextCodes = normalizeCenterCurrencyCodes(codes, getCatalog());

      if(!currentOptions.length){
        nextMode = CENTER_CURRENCY_MODE_CUSTOM;
        nextCodes = [];
      } else if(nextMode === CENTER_CURRENCY_MODE_ALL){
        nextCodes = [];
      } else if(nextCodes.length >= currentOptions.length){
        nextMode = CENTER_CURRENCY_MODE_ALL;
        nextCodes = [];
      }

      return { mode:nextMode, codes:nextCodes };
    }

    function dispatchHiddenInputEvents(input){
      if(!(input instanceof HTMLInputElement)) return;
      try{ input.dispatchEvent(new Event('input', { bubbles:true })); }catch{}
      try{ input.dispatchEvent(new Event('change', { bubbles:true })); }catch{}
    }

    function syncValueNode(){
      const triggerText = resolveCenterCurrenciesTriggerLabel(currentMode, Array.from(currentCodes), getCatalog());
      valueNode.textContent = triggerText;
      valueNode.classList.toggle('is-placeholder', triggerText === CENTER_CURRENCIES_EMPTY_LABEL);
    }

    function syncRenderedOptionState(){
      if(!popover) return;
      popover.querySelectorAll('[data-coa-choice-option]').forEach((optionNode) => {
        const isActive = isValueSelected(optionNode.dataset.coaChoiceOption);
        optionNode.classList.toggle('is-active', isActive);
        optionNode.setAttribute('aria-selected', isActive ? 'true' : 'false');
      });
    }

    function syncSelectionState(mode, codes, { dispatch = true } = {}){
      const normalized = normalizeSelectionState(mode, codes);
      currentMode = normalized.mode;
      currentCodes = new Set(normalized.codes);
      summaryInput.value = formatCenterCurrenciesSummary(currentMode, Array.from(currentCodes), getCatalog());
      modeInput.value = currentMode;
      codesInput.value = currentMode === CENTER_CURRENCY_MODE_ALL ? '' : Array.from(currentCodes).join(',');
      syncValueNode();
      syncRenderedOptionState();
      if(dispatch){
        dispatchHiddenInputEvents(summaryInput);
        dispatchHiddenInputEvents(modeInput);
        dispatchHiddenInputEvents(codesInput);
      }
    }

    function updateTriggerDisabledState(){
      const shouldDisable = !!isDisabled || !currentOptions.length;
      if(shouldDisable && isPopoverOpen()) closePopover();
      trigger.disabled = shouldDisable;
      trigger.setAttribute('aria-disabled', shouldDisable ? 'true' : 'false');
      picker.classList.toggle('is-disabled', shouldDisable);
    }

    function renderPopoverOptions(){
      if(!popover) return;
      if(!currentOptions.length){
        popover.innerHTML = '<div class="coa-choice-popover__empty">لا توجد عملات متاحة</div>';
        return;
      }
      const renderedOptions = [{ value:MULTI_ALL_VALUE, label:CENTER_CURRENCIES_ALL_LABEL }].concat(currentOptions);
      popover.innerHTML = renderedOptions.map((option) => {
        const isActive = isValueSelected(option.value);
        const optionKind = option && option.value === MULTI_ALL_VALUE ? 'all' : 'currency';
        const flagMarkup = option && option.value !== MULTI_ALL_VALUE && typeof createCoaCurrencyFlagMarkup === 'function'
          ? createCoaCurrencyFlagMarkup(option, { className:'coa-choice-popover__flag-image' })
          : '';
        return `
          <button class="coa-choice-popover__option coa-choice-popover__option--multi${isActive ? ' is-active' : ''}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-taif-inline-picker-option="true" role="option" data-coa-choice-option="${escapeHtml(option.value)}" data-coa-center-currency-kind="${optionKind}" aria-selected="${isActive ? 'true' : 'false'}">
            <span class="coa-choice-popover__meta">
              ${flagMarkup ? `<span class="coa-choice-popover__flag" aria-hidden="true">${flagMarkup}</span>` : ''}
              <span class="coa-choice-popover__label" data-taif-dropdown-label="true">${escapeHtml(option.label)}</span>
            </span>
            <span class="coa-choice-popover__box" aria-hidden="true">${createCoaPickerIconMarkup('check')}</span>
          </button>
        `;
      }).join('');
      if(pickerApi) popover.__taifInlinePickerApi = pickerApi;
    }

    function positionPopover(){
      if(!popover || popover.hidden) return;
      const overlayRect = overlayHost.getBoundingClientRect();
      const triggerRect = trigger.getBoundingClientRect();
      const gap = 6;
      const edgePadding = 8;
      const width = Math.max(220, Math.round(triggerRect.width));
      const availableBelow = Math.max(0, Math.floor(overlayRect.bottom - edgePadding - triggerRect.bottom - gap));

      popover.style.width = `${width}px`;
      popover.style.maxHeight = 'none';
      popover.style.visibility = 'hidden';

      const naturalHeight = Math.max(popover.scrollHeight, 96);
      const resolvedMaxHeight = Math.max(96, Number(maxPopoverHeight) || 232);
      const maxHeight = Math.max(96, Math.min(naturalHeight, availableBelow || naturalHeight, resolvedMaxHeight));
      const rawLeft = triggerRect.left - overlayRect.left;
      const minLeft = edgePadding;
      const maxLeft = overlayHost.clientWidth - width - edgePadding;
      const left = clampNumber(rawLeft, minLeft, Math.max(minLeft, maxLeft));
      const top = Math.max(edgePadding, triggerRect.bottom - overlayRect.top + gap);

      popover.dataset.openDirection = 'down';
      popover.style.left = `${left}px`;
      popover.style.top = `${top}px`;
      popover.style.maxHeight = `${maxHeight}px`;
      popover.style.visibility = '';
    }

    const schedulePositionPopover = popoverPositionScheduler
      ? popoverPositionScheduler.schedule.bind(popoverPositionScheduler)
      : (() => {
          requestAnimationFrame(() => {
            positionPopover();
          });
        });

    function closePopover({ restoreFocus = false } = {}){
      if(popoverPositionScheduler) popoverPositionScheduler.cancel();
      if(popover) popover.style.visibility = '';
      setCoaChoicePopoverState({ picker, popover, trigger, isOpen:false });
      if(restoreFocus) requestAnimationFrame(() => focusChoiceTarget(trigger));
    }

    function getOptionButtons(){
      if(!popover) return [];
      return Array.from(popover.querySelectorAll('[data-coa-choice-option]')).filter((node) => node instanceof HTMLButtonElement && !node.disabled);
    }

    function resolvePreferredFocusIndex(){
      const optionButtons = getOptionButtons();
      if(!optionButtons.length) return -1;
      if(areAllSelected()) return 0;
      const effectiveCodes = getEffectiveSelectedCodes();
      const firstSelected = effectiveCodes[0];
      if(firstSelected){
        const selectedIndex = optionButtons.findIndex((button) => button.dataset.coaChoiceOption === firstSelected);
        if(selectedIndex >= 0) return selectedIndex;
      }
      return 0;
    }

    function focusOption(targetIndex, { scrollBehavior = 'auto', scrollBlock = 'nearest' } = {}){
      const optionButtons = getOptionButtons();
      if(!optionButtons.length) return false;
      const normalizedIndex = clampNumber(Number(targetIndex) || 0, 0, optionButtons.length - 1);
      const targetButton = optionButtons[normalizedIndex];
      const focused = focusChoiceTarget(targetButton);
      if(targetButton && typeof targetButton.scrollIntoView === 'function'){
        try {
          targetButton.scrollIntoView({ block:scrollBlock, inline:'nearest', behavior:scrollBehavior });
        } catch{}
      }
      return focused;
    }

    function focusActiveOption(){
      const preferredIndex = resolvePreferredFocusIndex();
      if(preferredIndex < 0) return false;
      return focusOption(preferredIndex);
    }

    function stepChoiceSelection(){
      return false;
    }

    function ensurePopover(){
      if(popover) return;
      popover = document.createElement('div');
      popover.className = 'coa-choice-popover coa-choice-popover--multi coa-choice-popover--center-currencies';
      popover.dataset.taifDropdownPopup = 'true';
      popover.dataset.taifDropdownLayout = 'list';
      popover.dataset.taifInlinePicker = 'true';
      popover.dataset.coaPickerKind = 'center-currencies';
      popover.setAttribute('role', 'listbox');
      popover.setAttribute('aria-multiselectable', 'true');
      popover.setAttribute('aria-label', ariaLabel);
      popover.hidden = true;
      popover.addEventListener('keydown', onPopoverKeyDown);
      popover.addEventListener('click', onPopoverClick);
      overlayHost.appendChild(popover);
      if(pickerApi) popover.__taifInlinePickerApi = pickerApi;
      renderPopoverOptions();
    }

    function openPopover(){
      if(trigger.disabled || !currentOptions.length) return;
      commitController.clearCommittedSelection();
      ensurePopover();
      syncSelectionState(currentMode, Array.from(currentCodes), { dispatch:false });
      setCoaChoicePopoverState({ picker, popover, trigger, isOpen:true });
      positionPopover();
      requestAnimationFrame(() => {
        focusActiveOption();
      });
    }

    function openForKeyboard(){
      if(!isPopoverOpen()) openPopover();
      requestAnimationFrame(() => {
        focusActiveOption();
      });
    }

    function togglePopover(){
      if(trigger.disabled || !currentOptions.length) return;
      if(isPopoverOpen()){
        closePopover();
        return;
      }
      openPopover();
    }

    function toggleChoiceValue(value){
      if(value === MULTI_ALL_VALUE){
        syncSelectionState(areAllSelected() ? CENTER_CURRENCY_MODE_CUSTOM : CENTER_CURRENCY_MODE_ALL, []);
        return;
      }
      const nextCodes = new Set(getEffectiveSelectedCodes());
      if(nextCodes.has(value)) nextCodes.delete(value);
      else nextCodes.add(value);
      syncSelectionState(CENTER_CURRENCY_MODE_CUSTOM, Array.from(nextCodes));
    }

    function onTriggerClick(event){
      event.preventDefault();
      togglePopover();
    }

    function onTriggerKeyDown(event){
      if(event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey || trigger.disabled) return;
      if(event.key === 'ArrowDown' || event.key === 'ArrowUp' || event.key === ' ' || event.key === 'Spacebar' || event.key === 'Enter' || event.key === 'NumpadEnter'){
        event.preventDefault();
        openPopover();
      }
    }

    function onPopoverClick(event){
      const target = event.target instanceof Element ? event.target.closest('[data-coa-choice-option]') : null;
      if(!(target instanceof HTMLButtonElement)) return;
      toggleChoiceValue(target.dataset.coaChoiceOption);
      requestAnimationFrame(() => {
        focusChoiceTarget(target);
      });
    }

    function onPopoverKeyDown(event){
      if(event.defaultPrevented) return;
      const optionButtons = getOptionButtons();
      const activeElement = event.target instanceof Element ? event.target.closest('[data-coa-choice-option]') : null;
      if(!optionButtons.length || !(activeElement instanceof HTMLButtonElement)) return;
      const currentIndex = optionButtons.indexOf(activeElement);
      if(currentIndex === -1) return;

      if(event.key === 'ArrowDown'){
        event.preventDefault();
        focusOption(Math.min(optionButtons.length - 1, currentIndex + 1));
        return;
      }
      if(event.key === 'ArrowUp'){
        event.preventDefault();
        focusOption(Math.max(0, currentIndex - 1));
        return;
      }
      if(event.key === 'Home'){
        event.preventDefault();
        focusOption(0);
        return;
      }
      if(event.key === 'End'){
        event.preventDefault();
        focusOption(optionButtons.length - 1);
        return;
      }
      if(event.key === 'Enter' || event.key === 'NumpadEnter' || event.key === ' ' || event.key === 'Spacebar'){
        event.preventDefault();
        toggleChoiceValue(activeElement.dataset.coaChoiceOption);
        requestAnimationFrame(() => {
          focusChoiceTarget(activeElement);
        });
        return;
      }
      if(event.key === 'Escape'){
        event.preventDefault();
        event.stopPropagation();
        closePopover({ restoreFocus:true });
        return;
      }
      if(event.key === 'Tab'){
        closePopover();
      }
    }

    function onPointerDown(event){
      if(!isPopoverOpen()) return;
      const target = event.target;
      if(!(target instanceof Element)) return;
      if(picker.contains(target)) return;
      if(popover && popover.contains(target)) return;
      closePopover();
    }

    function onModalKeyDownCapture(event){
      if(!isPopoverOpen()) return;
      if(event.key !== 'Escape') return;
      event.preventDefault();
      event.stopPropagation();
      closePopover({ restoreFocus:true });
    }

    function setOptions(nextOptions){
      currentOptions = normalizeCoaChoiceOptions(nextOptions);
      renderPopoverOptions();
      syncSelectionState(currentMode, Array.from(currentCodes), { dispatch:true });
      updateTriggerDisabledState();
      if(isPopoverOpen()) schedulePositionPopover();
    }

    function setSelection(selection, { dispatch = true } = {}){
      const nextMode = selection && selection.currencySelectionMode;
      const nextCodes = selection && selection.currencyCodes;
      syncSelectionState(nextMode, nextCodes, { dispatch });
      if(isPopoverOpen()) schedulePositionPopover();
    }

    function setDisabled(nextDisabled){
      isDisabled = !!nextDisabled;
      updateTriggerDisabledState();
    }

    function readDraftInto(draft){
      if(!draft || typeof draft !== 'object') return;
      draft.currencies = summaryInput.value;
      draft.currencySelectionMode = modeInput.value;
      draft.currencyCodes = normalizeCenterCurrencyCodes(codesInput.value, getCatalog());
    }

    syncSelectionState(currentMode, Array.from(currentCodes), { dispatch:false });
    updateTriggerDisabledState();

    pickerApi = createChoicePickerBaseApi({
      trigger,
      isOpen: isPopoverOpen,
      openForKeyboard,
      closePopover,
      focusActiveOption,
      stepChoiceSelection,
      commitController
    });
    Object.assign(pickerApi, {
      getSelection(){
        return {
          currencySelectionMode: modeInput.value,
          currencyCodes: normalizeCenterCurrencyCodes(codesInput.value, getCatalog()),
          currencies: summaryInput.value
        };
      },
      readDraftInto,
      setOptions,
      setSelection,
      setDisabled
    });

    registerCoaInlinePickerApi({
      picker,
      trigger,
      getPopover: () => popover,
      api:pickerApi,
      clearCommittedSelection: commitController.clearCommittedSelection,
      registerCleanup
    });

    trigger.addEventListener('click', onTriggerClick);
    trigger.addEventListener('keydown', onTriggerKeyDown);
    panel.addEventListener('scroll', schedulePositionPopover, { passive:true });
    document.addEventListener('pointerdown', onPointerDown, true);
    modal.addEventListener('keydown', onModalKeyDownCapture, true);
    window.addEventListener('resize', schedulePositionPopover, { passive:true });

    const cleanup = () => {
      if(popoverPositionScheduler) popoverPositionScheduler.cancel();
      trigger.removeEventListener('click', onTriggerClick);
      trigger.removeEventListener('keydown', onTriggerKeyDown);
      panel.removeEventListener('scroll', schedulePositionPopover, { passive:true });
      document.removeEventListener('pointerdown', onPointerDown, true);
      modal.removeEventListener('keydown', onModalKeyDownCapture, true);
      window.removeEventListener('resize', schedulePositionPopover, { passive:true });
      if(popover){
        popover.removeEventListener('keydown', onPopoverKeyDown);
        popover.removeEventListener('click', onPopoverClick);
        popover.remove();
      }
      popover = null;
    };

    if(typeof registerCleanup === 'function') registerCleanup(cleanup);
    return pickerApi;
  }


  Object.assign(internal, {
    mountCoaChoicePicker,
    mountCoaMultiChoicePicker
  });
})();
