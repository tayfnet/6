(() => {
  const TAIF = window.TAIF;
  const { escapeHtml, pushCleanupCallback, runCleanupCallbacks, isEditableFormControl } = TAIF.core.utils;
  const windowChrome = TAIF.ui.windowChrome || {};
  const getWindowChromeIcon = (type) => (
    typeof windowChrome.getIconMarkup === 'function'
      ? windowChrome.getIconMarkup(type)
      : ''
  );
  const isWindowChromeElementVisible = typeof windowChrome.isElementVisible === 'function'
    ? windowChrome.isElementVisible.bind(windowChrome)
    : null;
  const focusWindowChromeElement = typeof windowChrome.focusElement === 'function'
    ? windowChrome.focusElement.bind(windowChrome)
    : null;
  const findWindowChromeDirectionalTarget = typeof windowChrome.findDirectionalTarget === 'function'
    ? windowChrome.findDirectionalTarget.bind(windowChrome)
    : null;
  const triggerWindowChromeElementPress = typeof windowChrome.triggerElementPress === 'function'
    ? windowChrome.triggerElementPress.bind(windowChrome)
    : null;
  const api = TAIF.chartOfAccounts = TAIF.chartOfAccounts || {};
  const internal = api.internal && typeof api.internal === 'object' ? api.internal : {};
  api.internal = internal;
  const {
    runtime,
    ensureCenterImageFallbackHandling,
    hydrateCenterImages,
    clampNumber
  } = internal;

  const {
    dismissOverlays,
    ensureModalLayer,
    cleanupModalRegistry,
    readModalWindowSlot,
    assignModalWindowSlot,
    releaseModalWindowSlot,
    registerModalWindow,
    unregisterModalWindow,
    activateModalWindow,
    isTopmostModal,
    getModalViewportBoundsForSize,
    getModalViewportBounds,
    applyModalPosition,
    positionModalAtCascade,
    getPrimaryWorkspaceRect,
    getModalMaximizedFrame,
    applyModalMaximizedFrame,
    clearModalMaximizedFrame,
    maximizeModalWindow,
    restoreModalWindow,
    syncModalWithinViewport,
    bindModalDragging
  } = windowChrome.createModalWindowManager({
    runtime,
    layerSelector: '.coa-window-layer',
    layerClassName: 'coa-window-layer',
    backdropSelector: '.coa-modal-backdrop',
    modalSelector: '.coa-modal',
    dragHandleSelector: '.coa-modal__head',
    dragBlockSelectors: '.coa-window-actions, button, input, textarea, select, option, a, [data-coa-action], [data-coa-choice-trigger], .coa-choice-popover',
    bodyDraggingClass: 'chart-accounts--dragging-window',
    clamp: clampNumber,
    getWorkspace: () => ((runtime.panel && runtime.panel.isConnected) ? runtime.panel : null),
    getCascadeSlotLimit: () => Number(runtime.modalCascadeSlots) || 6,
    ownerView: 'chart-of-accounts'
  });

  function closeModalBackdrop(backdrop, event){
    if(!backdrop || backdrop.dataset.closing === 'true') return;
    if(event){
      event.preventDefault();
      event.stopPropagation();
    }

    backdrop.dataset.closing = 'true';
    backdrop.classList.add('is-closing');
    unregisterModalWindow(backdrop);
    const cleanup = backdrop.__cleanup;
    backdrop.__cleanup = null;
    if(typeof cleanup === 'function') cleanup();
    window.setTimeout(() => {
      backdrop.remove();
      cleanupModalRegistry();
    }, 120);
  }

  function isVisibleCoaElement(element){
    return typeof isWindowChromeElementVisible === 'function'
      ? isWindowChromeElementVisible(element)
      : false;
  }

  function uniqueCoaElements(elements){
    const seen = new Set();
    return elements.filter((element) => {
      if(!(element instanceof HTMLElement) || !isVisibleCoaElement(element)) return false;
      if(seen.has(element)) return false;
      seen.add(element);
      return true;
    });
  }

  function collectCoaModalElements(root, selector, { excludeSelector = '' } = {}){
    if(!(root instanceof Element) || !selector) return [];
    return uniqueCoaElements(Array.from(root.querySelectorAll(selector)).filter((element) => {
      if(!(element instanceof HTMLElement)) return false;
      if(excludeSelector && element.matches(excludeSelector)) return false;
      if(excludeSelector && element.closest(excludeSelector)) return false;
      return true;
    }));
  }

  function isCoaFieldTriggerButton(element){
    return element instanceof HTMLButtonElement && element.matches('[data-coa-choice-trigger]');
  }

  function getCoaInlinePickerHost(element){
    if(!(element instanceof Element)) return null;
    const host = element.closest('.coa-choice-picker, .coa-choice-popover');
    return host instanceof HTMLElement ? host : null;
  }

  function getCoaInlinePickerApi(element){
    const host = getCoaInlinePickerHost(element);
    return host && host.__taifInlinePickerApi ? host.__taifInlinePickerApi : null;
  }

  function isCoaInlinePickerTrigger(element){
    return isCoaFieldTriggerButton(element) && !!getCoaInlinePickerApi(element);
  }

  function isCoaInlinePickerOption(element){
    if(!(element instanceof HTMLElement)) return false;
    if(element.matches('[data-coa-choice-option]')) return true;
    if(element.getAttribute('role') !== 'option') return false;
    return Boolean(element.closest('.coa-choice-popover'));
  }

  function isCoaInlinePickerPopoverControl(element){
    return element instanceof HTMLElement && Boolean(element.closest('.coa-choice-popover'));
  }

  function resolveCoaFooterActionSignature(element){
    if(!(element instanceof HTMLElement)) return '';
    const dataset = element.dataset || {};
    const parts = [
      dataset.coaAction,
      dataset.coaConfirm,
      dataset.coaRestore,
      dataset.coaHardDelete,
      element.getAttribute('aria-label'),
      element.getAttribute('title'),
      element.textContent
    ].filter(Boolean);
    return parts.join(' ').trim().toLowerCase();
  }

  function resolveCoaFooterFlowPriority(element){
    if(!(element instanceof HTMLElement)) return 3;
    const signature = resolveCoaFooterActionSignature(element);
    const isPrimaryClass = element.classList.contains('coa-btn--success')
      || element.classList.contains('coa-btn--primary');
    const isCancelLike = /(^|\s)(cancel|close|dismiss|back|ignore)(\s|$)/.test(signature)
      || /إلغاء|إغلاق|رجوع|عودة|تجاهل/.test(signature);
    const isCommitLike = /(^|\s)(save|confirm|submit|create|add|apply|update|delete|remove|restore)(\s|$)/.test(signature)
      || /حفظ|تأكيد|إضافة|إنشاء|تطبيق|تحديث|حذف|استعادة/.test(signature);

    if(isPrimaryClass || (isCommitLike && !isCancelLike)) return 0;
    if(isCancelLike) return 2;
    return 1;
  }

  function sortCoaFooterFlowTargets(elements){
    if(!Array.isArray(elements) || !elements.length) return [];
    return elements
      .map((element, index) => ({ element, index, priority: resolveCoaFooterFlowPriority(element) }))
      .sort((left, right) => {
        if(left.priority !== right.priority) return left.priority - right.priority;
        return left.index - right.index;
      })
      .map((entry) => entry.element);
  }

  function collectCoaModalFlowTargets(root, { footerOrder = 'priority' } = {}){
    if(!(root instanceof Element)) return [];

    const excludeSelector = '.coa-window-actions, .coa-form__media-actions';
    const footerElements = collectCoaModalElements(root, '.coa-form__actions button:not([disabled])', {
      excludeSelector: '.coa-window-actions'
    });
    const footerButtons = footerOrder === 'dom' ? footerElements : sortCoaFooterFlowTargets(footerElements);
    const primaryFields = collectCoaModalElements(root, [
      '[data-taif-initial-focus="true"]',
      'input:not([type="hidden"]):not([type="file"]):not([disabled]):not([readonly])',
      'textarea:not([disabled]):not([readonly])',
      'select:not([disabled])',
      '[data-coa-choice-trigger]:not([disabled])'
    ].join(', '), { excludeSelector });
    if(primaryFields.length) return uniqueCoaElements(primaryFields.concat(footerButtons));

    const fallbackButtons = collectCoaModalElements(root, [
      '[data-coa-restore]:not([disabled])',
      '[data-coa-hard-delete]:not([disabled])',
      'button:not([disabled])'
    ].join(', '), { excludeSelector });
    const nonFooterFallbackButtons = fallbackButtons.filter((element) => !element.matches('.coa-form__actions button'));
    if(nonFooterFallbackButtons.length) return uniqueCoaElements(nonFooterFallbackButtons.concat(footerButtons));
    if(footerButtons.length) return footerButtons;
    return fallbackButtons;
  }

  function focusCoaModalTarget(element){
    return typeof focusWindowChromeElement === 'function'
      ? focusWindowChromeElement(element)
      : false;
  }

  function findCoaFlowInsertionIndex(targets, reference){
    if(!(reference instanceof Node)) return targets.length;
    for(let index = 0; index < targets.length; index += 1){
      const candidate = targets[index];
      if(candidate === reference) return index;
      const relation = reference.compareDocumentPosition(candidate);
      if(relation & Node.DOCUMENT_POSITION_FOLLOWING) return index;
    }
    return targets.length;
  }

  function resolveRelativeCoaModalTarget(root, anchor, step, { footerOrder = 'priority', clamp = false, referenceElement = null } = {}){
    const targets = collectCoaModalFlowTargets(root, { footerOrder });
    if(!targets.length) return null;

    const normalizedStep = step < 0 ? -1 : 1;
    const reference = referenceElement instanceof HTMLElement && root.contains(referenceElement)
      ? referenceElement
      : (anchor instanceof HTMLElement && root.contains(anchor) ? anchor : null);
    const currentIndex = reference ? targets.indexOf(reference) : -1;
    let nextIndex = -1;

    if(currentIndex !== -1){
      nextIndex = currentIndex + normalizedStep;
    }else{
      const insertionIndex = findCoaFlowInsertionIndex(targets, reference || anchor);
      nextIndex = normalizedStep < 0 ? insertionIndex - 1 : insertionIndex;
    }

    if(clamp){
      nextIndex = Math.max(0, Math.min(targets.length - 1, nextIndex));
    }

    if(nextIndex < 0 || nextIndex >= targets.length) return null;
    return targets[nextIndex] || null;
  }

  function resolvePreferredCoaFooterEntryTarget(root, nextTarget, referenceElement){
    if(!(root instanceof Element)) return nextTarget;
    if(!(nextTarget instanceof HTMLElement) || !nextTarget.matches('.coa-form__actions button')) return nextTarget;
    if(referenceElement instanceof HTMLElement && referenceElement.matches('.coa-form__actions button')) return nextTarget;

    const preferredFooterTarget = sortCoaFooterFlowTargets(collectCoaModalElements(root, '.coa-form__actions button:not([disabled])', {
      excludeSelector: '.coa-window-actions'
    }))[0] || null;

    if(preferredFooterTarget instanceof HTMLElement && isVisibleCoaElement(preferredFooterTarget)){
      return preferredFooterTarget;
    }

    return nextTarget;
  }

  function focusRelativeCoaModalTarget(root, anchor, step, options = {}){
    const nextTarget = resolveRelativeCoaModalTarget(root, anchor, step, options);
    const referenceElement = options && options.referenceElement instanceof HTMLElement ? options.referenceElement : null;
    const resolvedTarget = step > 0
      ? resolvePreferredCoaFooterEntryTarget(root, nextTarget, referenceElement)
      : nextTarget;
    return resolvedTarget ? focusCoaModalTarget(resolvedTarget) : false;
  }

  function queueRelativeCoaModalTarget(root, anchor, step){
    if(!(root instanceof Element)) return;
    const safeStep = step < 0 ? -1 : 1;
    let attemptsLeft = 3;

    function tryFocus(){
      const candidateAnchor = anchor instanceof HTMLElement && root.contains(anchor)
        ? anchor
        : (document.activeElement instanceof HTMLElement && root.contains(document.activeElement) ? document.activeElement : null);
      if(focusRelativeCoaModalTarget(root, candidateAnchor, safeStep)) return;
      attemptsLeft -= 1;
      if(attemptsLeft > 0) requestAnimationFrame(tryFocus);
    }

    requestAnimationFrame(tryFocus);
  }

  function resolveCoaArrowGroup(element, root, key){
    if(!(element instanceof HTMLElement) || !(root instanceof Element)) return null;
    if(key === 'ArrowUp' || key === 'ArrowDown'){
      const verticalGroup = element.closest('.coa-choice-popover, .coa-deleted-list');
      if(verticalGroup && root.contains(verticalGroup)) return verticalGroup;
    }
    const horizontalGroup = element.closest('.coa-form__media-actions, .coa-form__actions, .coa-form__actions-group, .coa-window-actions');
    if(horizontalGroup && root.contains(horizontalGroup)) return horizontalGroup;
    const fallbackVerticalGroup = element.closest('.coa-choice-popover, .coa-deleted-list');
    if(fallbackVerticalGroup && root.contains(fallbackVerticalGroup)) return fallbackVerticalGroup;
    return null;
  }

  function collectCoaArrowTargets(group){
    if(!(group instanceof Element)) return [];
    return uniqueCoaElements(Array.from(group.querySelectorAll('button:not([disabled]), [role="option"]:not([disabled]), [data-coa-restore]:not([disabled]), [data-coa-hard-delete]:not([disabled])')));
  }

  function findCoaDirectionalTarget(current, candidates, key){
    return typeof findWindowChromeDirectionalTarget === 'function'
      ? findWindowChromeDirectionalTarget(current, candidates, key)
      : null;
  }

  function resolveCoaInteractiveElement(target, root){
    if(!(root instanceof Element) || !(target instanceof Element)) return null;
    const control = target.closest('input, textarea, select, button, [role="option"], [data-coa-restore], [data-coa-hard-delete]');
    if(!(control instanceof HTMLElement) || !root.contains(control)) return null;
    return control;
  }

  function triggerCoaControlPress(element){
    return typeof triggerWindowChromeElementPress === 'function'
      ? triggerWindowChromeElementPress(element)
      : false;
  }

  function isCoaEnterFlowTarget(element){
    if(!(element instanceof HTMLElement)) return false;
    if(element.closest('.coa-choice-popover')) return false;
    if(isCoaFieldTriggerButton(element)) return true;
    return typeof isEditableFormControl === 'function'
      ? isEditableFormControl(element)
      : false;
  }

  function bindCoaModalNavigation({ root, autoFocus = true } = {}){
    if(!(root instanceof Element)){
      const noop = () => {};
      noop.focusInitialTarget = () => false;
      noop.focusTarget = () => false;
      return noop;
    }

    let activeFocusedControl = null;
    let initialFocusFrame = 0;

    function updateFocusedControl(nextControl){
      if(activeFocusedControl && activeFocusedControl !== nextControl && activeFocusedControl.removeAttribute){
        activeFocusedControl.removeAttribute('data-coa-focused');
      }
      activeFocusedControl = nextControl instanceof HTMLElement ? nextControl : null;
      if(activeFocusedControl) activeFocusedControl.setAttribute('data-coa-focused', 'true');
    }

    function focusInitialTarget(){
      const targets = collectCoaModalFlowTargets(root);
      return targets.length ? focusCoaModalTarget(targets[0]) : false;
    }

    function onFocusIn(event){
      const target = resolveCoaInteractiveElement(event.target, root);
      if(!(target instanceof HTMLElement)) return;
      updateFocusedControl(target);
    }

    function onFocusOut(event){
      const target = resolveCoaInteractiveElement(event.target, root);
      if(!(target instanceof HTMLElement) || target !== activeFocusedControl) return;
      requestAnimationFrame(() => {
        if(document.activeElement === target) return;
        if(activeFocusedControl === target){
          activeFocusedControl.removeAttribute('data-coa-focused');
          activeFocusedControl = null;
        }
      });
    }

    function onKeyDown(event){
      if(event.defaultPrevented || event.isComposing || event.altKey || event.ctrlKey || event.metaKey) return;
      const target = resolveCoaInteractiveElement(event.target, root);
      if(!(target instanceof HTMLElement)) return;
      const pickerApi = getCoaInlinePickerApi(target);

      if(event.key === 'Tab'){
        const step = event.shiftKey ? -1 : 1;
        const isPopoverControl = isCoaInlinePickerPopoverControl(target);
        const pickerTrigger = pickerApi && typeof pickerApi.getTrigger === 'function' ? pickerApi.getTrigger() : null;
        const shouldClosePicker = Boolean(pickerApi && typeof pickerApi.close === 'function' && (
          isPopoverControl
          || (isCoaInlinePickerTrigger(target) && typeof pickerApi.isOpen === 'function' && pickerApi.isOpen())
        ));
        const referenceElement = pickerTrigger instanceof HTMLElement && root.contains(pickerTrigger)
          ? pickerTrigger
          : target;
        const focusNextTabTarget = () => {
          if(focusRelativeCoaModalTarget(root, target, step, {
            footerOrder: 'dom',
            clamp: true,
            referenceElement
          })) return;
          focusCoaModalTarget(referenceElement);
        };

        event.preventDefault();
        event.stopPropagation();

        if(shouldClosePicker){
          pickerApi.close();
          requestAnimationFrame(focusNextTabTarget);
          return;
        }

        focusNextTabTarget();
        return;
      }

      if(event.key === 'Enter' || event.key === 'NumpadEnter'){
        if(isCoaInlinePickerOption(target)){
          event.preventDefault();
          const step = event.shiftKey ? -1 : 1;
          if(pickerApi && typeof pickerApi.prepareKeyboardSelection === 'function'){
            pickerApi.prepareKeyboardSelection(step);
          }
          const anchor = pickerApi && typeof pickerApi.getTrigger === 'function' ? pickerApi.getTrigger() : target;
          triggerCoaControlPress(target);
          queueRelativeCoaModalTarget(root, anchor, step);
          return;
        }

        if(isCoaInlinePickerTrigger(target)){
          if(event.shiftKey){
            event.preventDefault();
            if(pickerApi && typeof pickerApi.clearCommittedSelection === 'function'){
              pickerApi.clearCommittedSelection();
            }
            focusRelativeCoaModalTarget(root, target, -1);
            return;
          }
          if(pickerApi && typeof pickerApi.consumeCommittedSelection === 'function' && pickerApi.consumeCommittedSelection()){
            event.preventDefault();
            focusRelativeCoaModalTarget(root, target, 1);
            return;
          }
          if(pickerApi && typeof pickerApi.openForKeyboard === 'function'){
            event.preventDefault();
            pickerApi.openForKeyboard();
            return;
          }
        }

        if(isCoaEnterFlowTarget(target)){
          event.preventDefault();
          focusRelativeCoaModalTarget(root, target, event.shiftKey ? -1 : 1);
          return;
        }
      }

      if(!event.shiftKey && (event.key === 'ArrowLeft' || event.key === 'ArrowRight') && isCoaInlinePickerTrigger(target) && pickerApi && typeof pickerApi.stepValue === 'function'){
        if(typeof pickerApi.isOpen !== 'function' || !pickerApi.isOpen()){
          event.preventDefault();
          const didStepValue = pickerApi.stepValue(event.key === 'ArrowRight' ? 1 : -1);
          if(didStepValue && typeof pickerApi.markCommittedSelection === 'function') pickerApi.markCommittedSelection();
          else if(typeof pickerApi.clearCommittedSelection === 'function') pickerApi.clearCommittedSelection();
          return;
        }
      }

      if(event.shiftKey) return;
      if(!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) return;
      if(!(target instanceof HTMLButtonElement) && target.getAttribute('role') !== 'option') return;

      const group = resolveCoaArrowGroup(target, root, event.key);
      if(!group) return;
      const candidates = collectCoaArrowTargets(group);
      if(candidates.length < 2) return;
      const nextTarget = findCoaDirectionalTarget(target, candidates, event.key);
      if(!nextTarget) return;

      event.preventDefault();
      focusCoaModalTarget(nextTarget);
    }

    root.addEventListener('focusin', onFocusIn);
    root.addEventListener('focusout', onFocusOut);
    root.addEventListener('keydown', onKeyDown, true);

    if(autoFocus){
      initialFocusFrame = requestAnimationFrame(() => {
        initialFocusFrame = 0;
        focusInitialTarget();
      });
    }

    const cleanup = () => {
      if(initialFocusFrame){
        cancelAnimationFrame(initialFocusFrame);
        initialFocusFrame = 0;
      }
      root.removeEventListener('focusin', onFocusIn);
      root.removeEventListener('focusout', onFocusOut);
      root.removeEventListener('keydown', onKeyDown, true);
      if(activeFocusedControl && activeFocusedControl.removeAttribute){
        activeFocusedControl.removeAttribute('data-coa-focused');
      }
      activeFocusedControl = null;
    };

    cleanup.focusInitialTarget = focusInitialTarget;
    cleanup.focusTarget = focusCoaModalTarget;
    return cleanup;
  }

  function openModalWindow({ title, bodyHtml, size = 'md', modalClass = '', bodyClass = '', showExpand = true, dismissExisting = false, closeOnBackdrop = false, initialFocus = 'flow', onMount }){
    if(dismissExisting) dismissOverlays();

    const resolvedSize = size === 'sm' ? 'sm' : size === 'lg' ? 'lg' : 'md';
    const sizeClass = resolvedSize === 'lg' ? ' coa-modal--size-lg' : resolvedSize === 'sm' ? ' coa-modal--size-sm' : ' coa-modal--size-md';
    const extraModalClass = modalClass ? ` ${String(modalClass).trim()}` : '';
    const extraBodyClass = bodyClass ? ` ${String(bodyClass).trim()}` : '';
    const windowId = `taif-coa-window-${++runtime.modalSequence}`;

    const backdrop = document.createElement('div');
    backdrop.className = 'coa-modal-backdrop';
    backdrop.dataset.windowId = windowId;
    backdrop.innerHTML = `
      <div class="coa-modal coa-modal--grand${sizeClass}${extraModalClass}" role="dialog" aria-modal="false" aria-label="${escapeHtml(title)}" data-modal-size="${escapeHtml(resolvedSize)}" data-window-id="${escapeHtml(windowId)}" tabindex="-1">
        <div class="coa-modal__head">
          <div class="coa-modal__heading coa-modal__heading--centered">
            <h3 class="coa-modal__title" data-taif-detail-title="true">${escapeHtml(title)}</h3>
          </div>
          <div class="coa-window-actions" data-taif-window-actions="true">
            ${showExpand ? `<button class="coa-window-btn coa-window-btn--expand" type="button" data-coa-expand aria-label="تكبير النافذة" title="تكبير النافذة">${getWindowChromeIcon('expand')}</button>` : ''}
            <button class="coa-close-btn" type="button" data-coa-close aria-label="إغلاق" title="إغلاق">${getWindowChromeIcon('close')}</button>
          </div>
        </div>
        <div class="coa-modal__body${extraBodyClass}">${bodyHtml}</div>
      </div>
    `;

    const modal = backdrop.querySelector('.coa-modal');
    const body = backdrop.querySelector('.coa-modal__body');
    const closeButton = backdrop.querySelector('[data-coa-close]');
    const expandButton = backdrop.querySelector('[data-coa-expand]');
    const modalLayer = ensureModalLayer();
    const cleanupCallbacks = [];

    const registerCleanup = typeof pushCleanupCallback === 'function'
      ? pushCleanupCallback.bind(null, cleanupCallbacks)
      : ((cleanup) => cleanup);

    function syncExpandButton(){
      if(!expandButton) return;
      const expanded = modal.classList.contains('is-maximized');
      if(typeof windowChrome.syncExpandButton === 'function'){
        windowChrome.syncExpandButton(expandButton, expanded);
        return;
      }
      expandButton.innerHTML = getWindowChromeIcon(expanded ? 'collapse' : 'expand');
      expandButton.setAttribute('aria-label', expanded ? 'استعادة الحجم المرجعي' : 'تكبير النافذة');
      expandButton.setAttribute('title', expanded ? 'استعادة الحجم المرجعي' : 'تكبير النافذة');
      expandButton.setAttribute('aria-pressed', expanded ? 'true' : 'false');
    }

    const toggleExpand = windowChrome.createToggleExpandHandler({
      modal,
      expandButton,
      maximizeModalWindow,
      restoreModalWindow,
      syncExpandButton,
      activateModalWindow: () => activateModalWindow(backdrop)
    });

    function close(event){
      closeModalBackdrop(backdrop, event);
    }

    function onKeyDown(event){
      if(!isTopmostModal(backdrop)) return;
      if(event.key === 'Escape') close(event);
      if((event.key === 'F11' || (event.altKey && event.key === 'Enter')) && expandButton){
        event.preventDefault();
        toggleExpand();
      }
    }

    function onResize(){
      syncModalWithinViewport(modal);
    }

    function onActivate(){
      activateModalWindow(backdrop);
    }

    const resizeObserverTarget = (runtime.panel && runtime.panel.isConnected)
      ? (runtime.panel.querySelector('.chart-accounts') || runtime.panel)
      : null;
    let resizeObserver = null;

    cleanupCallbacks.push(bindModalDragging({ backdrop, modal }));

    backdrop.__cleanup = () => {
      if(typeof runCleanupCallbacks === 'function'){
        runCleanupCallbacks(cleanupCallbacks, { clearSource:true });
      } else {
        cleanupCallbacks.forEach((cleanup) => {
          if(typeof cleanup === 'function') cleanup();
        });
        cleanupCallbacks.length = 0;
      }
      document.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('resize', onResize);
      modal.removeEventListener('pointerdown', onActivate, true);
      backdrop.__cleanup = null;
    };

    closeButton?.addEventListener('click', close);
    closeButton?.addEventListener('pointerdown', (event) => {
      event.stopPropagation();
    }, true);
    expandButton?.addEventListener('click', toggleExpand);
    expandButton?.addEventListener('pointerdown', (event) => {
      event.stopPropagation();
    }, true);
    modal.addEventListener('pointerdown', onActivate, true);
    backdrop.addEventListener('click', (event) => {
      if(event.target !== backdrop) return;
      if(!isTopmostModal(backdrop)) return;
      if(closeOnBackdrop) close(event);
    });
    document.addEventListener('keydown', onKeyDown);
    window.addEventListener('resize', onResize, { passive:true });

    if(typeof ResizeObserver === 'function' && resizeObserverTarget instanceof HTMLElement){
      resizeObserver = new ResizeObserver(() => {
        syncModalWithinViewport(modal);
      });
      resizeObserver.observe(resizeObserverTarget);
      registerCleanup(() => resizeObserver?.disconnect());
    }

    modalLayer.appendChild(backdrop);
    registerModalWindow(backdrop);
    ensureCenterImageFallbackHandling(backdrop);
    hydrateCenterImages(backdrop);
    syncExpandButton();

    const formNavigationCleanup = bindCoaModalNavigation({ root:modal, autoFocus:false });
    registerCleanup(formNavigationCleanup);

    if(typeof onMount === 'function'){
      onMount({ backdrop, modal, body, close, toggleExpand, registerCleanup });
    }

    requestAnimationFrame(() => {
      syncModalWithinViewport(modal);
      activateModalWindow(backdrop);

      if(initialFocus !== 'modal'
        && formNavigationCleanup
        && typeof formNavigationCleanup.focusInitialTarget === 'function'
        && formNavigationCleanup.focusInitialTarget()){
        return;
      }

      modal.focus({ preventScroll:true });
    });

    return { backdrop, modal, body, close, toggleExpand, registerCleanup };
  }

  Object.assign(internal, {
    dismissOverlays,
    ensureModalLayer,
    cleanupModalRegistry,
    readModalWindowSlot,
    assignModalWindowSlot,
    releaseModalWindowSlot,
    registerModalWindow,
    unregisterModalWindow,
    activateModalWindow,
    isTopmostModal,
    clamp: clampNumber,
    getModalViewportBoundsForSize,
    getModalViewportBounds,
    applyModalPosition,
    positionModalAtCascade,
    getPrimaryWorkspaceRect,
    getModalMaximizedFrame,
    applyModalMaximizedFrame,
    clearModalMaximizedFrame,
    maximizeModalWindow,
    restoreModalWindow,
    syncModalWithinViewport,
    bindModalDragging,
    closeModalBackdrop,
    isVisibleCoaElement,
    uniqueCoaElements,
    collectCoaModalElements,
    isCoaFieldTriggerButton,
    getCoaInlinePickerHost,
    getCoaInlinePickerApi,
    isCoaInlinePickerTrigger,
    isCoaInlinePickerOption,
    resolveCoaFooterActionSignature,
    resolveCoaFooterFlowPriority,
    sortCoaFooterFlowTargets,
    collectCoaModalFlowTargets,
    focusCoaModalTarget,
    focusRelativeCoaModalTarget,
    queueRelativeCoaModalTarget,
    resolveCoaArrowGroup,
    collectCoaArrowTargets,
    findCoaDirectionalTarget,
    resolveCoaInteractiveElement,
    triggerCoaControlPress,
    isCoaEnterFlowTarget,
    bindCoaModalNavigation,
    openModalWindow
  });
})();
