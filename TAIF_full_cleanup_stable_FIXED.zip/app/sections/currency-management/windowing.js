(()=>{
  /*
   * TAIF Currency feature windowing.
   * Centralized overlay stack, modal dragging, viewport sync, and toast behavior.
   */
  const TAIF = window.TAIF;
  const { clearTimerSlot } = TAIF.core.utils;
  const windowChrome = TAIF.ui && TAIF.ui.windowChrome ? TAIF.ui.windowChrome : {};
  const feature = TAIF.currencyManagementFeature || (TAIF.currencyManagementFeature = {});
  const { runtime } = feature;

  const {
    dismissOverlays,
    ensureModalLayer,
    cleanupModalRegistry,
    readModalWindowSlot,
    assignModalWindowSlot,
    releaseModalWindowSlot,
    registerModalWindow,
    unregisterModalWindow,
    activateModalWindow,
    isTopmostModal,
    clamp,
    getModalViewportBoundsForSize,
    getModalViewportBounds,
    applyModalPosition,
    positionModalAtCascade,
    getPrimaryWorkspaceRect,
    getModalMaximizedFrame,
    applyModalMaximizedFrame,
    clearModalMaximizedFrame,
    maximizeModalWindow,
    restoreModalWindow,
    syncModalWithinViewport,
    bindModalDragging
  } = windowChrome.createModalWindowManager({
    runtime,
    layerSelector: '.taif-currency-management-window-layer',
    layerClassName: 'taif-currency-management-window-layer',
    backdropSelector: '.taif-currency-management-modal-backdrop',
    modalSelector: '.taif-currency-management-modal',
    dragHandleSelector: '.taif-currency-management-modal__head',
    dragBlockSelectors: '.taif-currency-management-modal__window-actions, button, input, textarea, select, option, a, [data-currency-management-action], [data-currency-management-method-picker], .currency-management-method-popover',
    bodyDraggingClass: 'taif-currency-management--dragging-window',
    getWorkspace: () => ((runtime.panel && runtime.panel.isConnected) ? runtime.panel : null),
    getCascadeSlotLimit: () => Number(runtime.modalCascadeSlots) || 6,
    ownerView: 'currency-management'
  });

  function showToast(message, tone = 'default'){
    let toast = document.querySelector('.currency-management-toast');
    if(!toast){
      toast = document.createElement('div');
      toast.className = 'currency-management-toast';
      TAIF?.core?.utils?.markOwnedNode?.(toast, 'currency-management');
      document.body.appendChild(toast);
    }

    toast.className = 'currency-management-toast';
    TAIF?.core?.utils?.markOwnedNode?.(toast, 'currency-management');
    if(tone === 'success') toast.classList.add('currency-management-toast--success');
    if(tone === 'danger') toast.classList.add('currency-management-toast--danger');
    if(tone === 'info') toast.classList.add('currency-management-toast--info');
    toast.textContent = message;

    requestAnimationFrame(() => {
      toast.classList.add('is-visible');
    });

    clearTimerSlot(runtime, 'toastTimer');
    runtime.toastTimer = window.setTimeout(() => {
      toast.classList.remove('is-visible');
    }, 2200);
  }
  Object.assign(feature, {
    dismissOverlays, ensureModalLayer, cleanupModalRegistry, readModalWindowSlot, assignModalWindowSlot, releaseModalWindowSlot, registerModalWindow, unregisterModalWindow, activateModalWindow, isTopmostModal, clamp, getModalViewportBoundsForSize, getModalViewportBounds, applyModalPosition, positionModalAtCascade, getPrimaryWorkspaceRect, getModalMaximizedFrame, applyModalMaximizedFrame, clearModalMaximizedFrame, maximizeModalWindow, restoreModalWindow, syncModalWithinViewport, bindModalDragging, showToast
  });
})();
