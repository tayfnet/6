(()=>{
  /*
   * TAIF Currency feature modal UI.
   * Toolbar composition, modal shell construction, inline pickers, and flag popovers.
   */
  const TAIF = window.TAIF;
  const { escapeHtml, runCleanupSlot, wrapControlTextMarkup, createTypeaheadNavigator, createInlinePickerCommitController: createSharedInlinePickerCommitController, registerInlinePickerApi: registerSharedInlinePickerApi, pushCleanupCallback, createAnimationFrameScheduler, mountAdaptiveToolbarFit, normalizeTypeaheadText, runCleanupCallbacks, setDisclosureOpenState } = TAIF.core.utils;
  const feature = TAIF.currencyManagementFeature || (TAIF.currencyManagementFeature = {});
  const { runtime, TOOLBAR_BUTTONS, normalizeCode, resolveEventElement, clearBrowserTextSelection, bindTextSelectionGuard, resolveCounterpartCode, getCounterpartCurrencyFromState, getCounterpartOptions, sanitizeState, readState, writeState, resolveStoredFlagCode, getFlagCatalog, getFlagPickerDisplay, createFlagImageMarkup } = feature;
  const { ensureModalLayer, cleanupModalRegistry, registerModalWindow, unregisterModalWindow, activateModalWindow, isTopmostModal, maximizeModalWindow, restoreModalWindow, syncModalWithinViewport, bindModalDragging, showToast } = feature;
  const windowChrome = TAIF.ui && TAIF.ui.windowChrome ? TAIF.ui.windowChrome : null;

  // ---------------------------------------------------------------------------
  // Markup helpers
  // ---------------------------------------------------------------------------
  function createButtonIcon(type){
    const sharedWindowChromeIcon = ['close', 'expand', 'collapse'].includes(type)
      && windowChrome && typeof windowChrome.getIconMarkup === 'function'
      ? windowChrome.getIconMarkup(type)
      : '';
    if(sharedWindowChromeIcon) return sharedWindowChromeIcon;

    const icons = {
      plus: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M12 5v14M5 12h14"></path></svg>',
      dollar: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M12 2v20M16.5 6.5c0-1.933-2.015-3.5-4.5-3.5s-4.5 1.567-4.5 3.5S9.515 10 12 10s4.5 1.567 4.5 3.5-2.015 3.5-4.5 3.5-4.5-1.567-4.5-3.5"></path></svg>',
      compare: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M7 7h11M11 3l-4 4 4 4M17 17H6M13 13l4 4-4 4"></path></svg>',
      edit: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M12 20h9"></path><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5Z"></path></svg>',
      trash: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M3 6h18"></path><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M8 6V4h8v2"></path><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M19 6l-1 14H6L5 6"></path><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M10 11v6M14 11v6"></path></svg>',
      settings: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M12 15.5A3.5 3.5 0 1 0 12 8.5a3.5 3.5 0 0 0 0 7Z"></path><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06A1.65 1.65 0 0 0 15 19.4a1.65 1.65 0 0 0-1 .6 1.65 1.65 0 0 0-.33 1V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1-.6 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-.6-1 1.65 1.65 0 0 0-1-.33H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0 .33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-.6 1.65 1.65 0 0 0 .33-1V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 .6 1 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9c.36.22.64.56.79.96.14.4.12.84-.05 1.22A1.65 1.65 0 0 0 21 12c.42 0 .82.16 1.11.45.29.29.45.69.45 1.11s-.16.82-.45 1.11c-.29.29-.69.45-1.11.45h-.09c-.41 0-.8.15-1.11.41-.31.26-.52.63-.6 1.03Z"></path></svg>',
      search: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="2"></circle><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="m20 20-3.5-3.5"></path></svg>',
      up: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M12 5v14"></path><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="m18 11-6-6-6 6"></path></svg>',
      down: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M12 5v14"></path><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="m6 13 6 6 6-6"></path></svg>',
      grid: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M4 6h16"></path><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M4 12h16"></path><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M4 18h16"></path></svg>',
      chevronDown: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="m6 9 6 6 6-6"></path></svg>',
      check: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="m5 13 4 4L19 7"></path></svg>'
    };
    return icons[type] || '';
  }

  function createSingleLineHeaderLabel(text, { className = '', min = 9.8, max = 13.2, step = .2, minScale = .92 } = {}){
    return `<span class="taif-singleline-fit${className ? ` ${className}` : ''}" data-fit-min="${String(min)}" data-fit-max="${String(max)}" data-fit-step="${String(step)}" data-fit-min-scale="${String(minScale)}">${escapeHtml(text)}</span>`;
  }

  function cleanupCounterpartToolbarPicker(){
    runCleanupSlot(runtime, 'counterpartPickerCleanup');
  }

  function cleanupTopbarAdaptiveFit(){
    runCleanupSlot(runtime, 'topbarFitCleanup');
  }

  function createInlinePickerCommitController(trigger){
    return createSharedInlinePickerCommitController({
      trigger,
      selectionDatasetKey:'taifPickerSelectionCommitted'
    });
  }

  function registerInlinePickerApi({ picker, trigger = null, getPopover = null, api, clearCommittedSelection = null, registerCleanup = null } = {}){
    registerSharedInlinePickerApi({
      picker,
      trigger,
      getPopover,
      api,
      clearCommittedSelection,
      registerCleanup
    });
  }

  function createCounterpartToolbarMarkup(stateInput){
    const state = sanitizeState(stateInput);
    const counterpart = getCounterpartCurrencyFromState(state);
    const options = getCounterpartOptions(state);
    const optionsMarkup = options.map((currency) => {
      const isActive = currency.code === counterpart.code;
      return `
      <button class="currency-management-counterpart-popover__option${isActive ? ' is-active' : ''}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-currency-management-counterpart-option="${escapeHtml(currency.code)}" aria-pressed="${isActive ? 'true' : 'false'}">
        <span class="currency-management-counterpart-popover__option-flag" aria-hidden="true">${createFlagImageMarkup(currency, { className: 'currency-management-counterpart-popover__option-flag-image' })}</span>
        <span class="currency-management-counterpart-popover__option-name" data-taif-dropdown-label="true">${escapeHtml(currency.name)}</span>
        ${isActive ? `<span class="currency-management-counterpart-popover__option-check" aria-hidden="true">${createButtonIcon('check')}</span>` : ''}
      </button>
    `;
    }).join('');

    return `
      <div class="currency-management-toolbar-counterpart" data-currency-management-counterpart-picker>
        <button class="currency-management-btn currency-management-btn--counterpart" type="button" data-currency-management-counterpart-trigger aria-haspopup="dialog" aria-expanded="false">
          ${createButtonIcon('compare')}
          <span class="taif-control-text">${escapeHtml('عملة التسعير المتقاطع')}</span>
          <span class="currency-management-counterpart-trigger__meta">
            <span class="currency-management-counterpart-trigger__code">${wrapControlTextMarkup(escapeHtml(counterpart.code), 'taif-control-text--ltr')}</span>
            <span class="currency-management-counterpart-trigger__flag" aria-hidden="true">${createFlagImageMarkup(counterpart, { className: 'currency-management-counterpart-trigger__flag-image' })}</span>
          </span>
        </button>
        <div class="currency-management-counterpart-popover" data-taif-dropdown-popup="true" data-taif-dropdown-layout="list" hidden data-currency-management-counterpart-popover>
          <div class="currency-management-counterpart-popover__head">اختر عملة التسعير المتقاطع لاشتقاق الأزواج المعروضة</div>
          <div class="currency-management-counterpart-popover__list">
            ${optionsMarkup}
          </div>
        </div>
      </div>
    `;
  }

  function buildToolbarButtonsMarkup(stateInput){
    return TOOLBAR_BUTTONS.map((button) => {
      if(button.action === 'bulk'){
        return `${createCounterpartToolbarMarkup(stateInput)}${buttonMarkup(button)}`;
      }
      return buttonMarkup(button);
    }).join('');
  }

  function mountSingleLineTextFit(root, selector, options = {}){
    if(!root || typeof root.querySelectorAll !== 'function' || !selector) return () => {};

    let rafId = 0;
    let disposed = false;
    let resizeObserver = null;

    const resolveTargets = () => Array.from(root.querySelectorAll(selector)).filter((node) => node && typeof node.getBoundingClientRect === 'function');

    const resetTarget = (node) => {
      if(!node) return;
      node.style.fontSize = '';
      node.style.transform = '';
      node.style.transformOrigin = '';
    };

    const fitTarget = (node) => {
      if(!node || !node.isConnected) return;

      const maxFontSize = Number(node.dataset.fitMax || options.maxFontSize || 0) || 12;
      const minFontSize = Number(node.dataset.fitMin || options.minFontSize || 0) || 8;
      const step = Math.max(.1, Number(node.dataset.fitStep || options.step || .2));
      const minScale = Math.min(1, Math.max(.82, Number(node.dataset.fitMinScale || options.minScale || .88)));

      resetTarget(node);
      node.style.fontSize = `${maxFontSize}px`;
      node.style.transformOrigin = 'center center';

      let nextFontSize = maxFontSize;
      while(nextFontSize > minFontSize && node.scrollWidth > (node.clientWidth + 1)){
        nextFontSize = Math.max(minFontSize, Number((nextFontSize - step).toFixed(2)));
        node.style.fontSize = `${nextFontSize}px`;
      }

      const availableWidth = node.clientWidth;
      const requiredWidth = node.scrollWidth;
      if(availableWidth > 0 && requiredWidth > (availableWidth + 1)){
        const scale = Math.max(minScale, availableWidth / requiredWidth);
        if(scale < .999){
          node.style.transform = `scale(${scale})`;
        }
      }
    };

    const applyFit = () => {
      if(disposed) return;
      resolveTargets().forEach(fitTarget);
    };

    const queueFit = () => {
      if(disposed) return;
      if(rafId) window.cancelAnimationFrame(rafId);
      rafId = window.requestAnimationFrame(() => {
        rafId = 0;
        applyFit();
      });
    };

    queueFit();

    if(typeof ResizeObserver === 'function'){
      resizeObserver = new ResizeObserver(() => {
        queueFit();
      });
      resizeObserver.observe(root);
      resolveTargets().forEach((node) => resizeObserver.observe(node));
    }

    window.addEventListener('resize', queueFit, { passive: true });

    return () => {
      disposed = true;
      if(rafId) window.cancelAnimationFrame(rafId);
      if(resizeObserver) resizeObserver.disconnect();
      window.removeEventListener('resize', queueFit);
      resolveTargets().forEach(resetTarget);
    };
  }

  function mountTopbarAdaptiveFit(panel){
    return typeof mountAdaptiveToolbarFit === 'function'
      ? mountAdaptiveToolbarFit({
          panel,
          topbarSelector: '.currency-management-topbar',
          toolsSelector: '.currency-management-topbar-tools',
          searchSelector: '.currency-management-topbar-search'
        })
      : () => {};
  }

  function mountCounterpartToolbarPicker(panel){
    const wrapper = panel.querySelector('[data-currency-management-counterpart-picker]');
    const trigger = wrapper && wrapper.querySelector('[data-currency-management-counterpart-trigger]');
    const popover = wrapper && wrapper.querySelector('[data-currency-management-counterpart-popover]');
    const scrollRoot = panel.querySelector('.currency-management-scroll');
    const toolbarStrip = panel.querySelector('.currency-management-topbar-tools');
    if(!wrapper || !trigger || !popover) return () => {};

    document.body.appendChild(popover);
    TAIF?.core?.utils?.markOwnedNode?.(popover, 'currency-management');
    popover.hidden = true;

    const setOpen = (nextOpen) => {
      const isOpen = Boolean(nextOpen);
      if(isOpen){
        popover.hidden = false;
        popover.classList.add('is-open');
        const triggerRect = trigger.getBoundingClientRect();
        const viewportPadding = 12;
        const maxWidth = Math.max(220, window.innerWidth - (viewportPadding * 2));
        const popoverWidth = Math.max(220, Math.min(Math.round(triggerRect.width), maxWidth));
        const maxLeft = Math.max(viewportPadding, window.innerWidth - popoverWidth - viewportPadding);
        const left = Math.max(viewportPadding, Math.min(Math.round(triggerRect.left), maxLeft));
        popover.style.position = 'fixed';
        popover.style.top = `${Math.round(triggerRect.bottom + 8)}px`;
        popover.style.left = `${left}px`;
        popover.style.right = 'auto';
        popover.style.width = `${popoverWidth}px`;
        popover.style.minWidth = `${popoverWidth}px`;
        popover.style.maxWidth = `${popoverWidth}px`;
        popover.style.visibility = '';
      }else{
        popover.hidden = true;
        popover.classList.remove('is-open');
        popover.style.visibility = '';
        popover.style.width = '';
        popover.style.minWidth = '';
        popover.style.maxWidth = '';
      }
      if(typeof setDisclosureOpenState === 'function'){
        setDisclosureOpenState({ root: wrapper, popup: popover, trigger, isOpen });
      }else{
        trigger.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        wrapper.classList.toggle('is-open', isOpen);
      }
    };

    const close = () => setOpen(false);
    const toggle = () => setOpen(popover.hidden);

    const onTriggerClick = (event) => {
      event.preventDefault();
      event.stopPropagation();
      toggle();
    };

    const onOptionClick = (event) => {
      const option = event.target.closest('[data-currency-management-counterpart-option]');
      if(!option) return;
      event.preventDefault();
      const nextCode = normalizeCode(option.dataset.currencyManagementCounterpartOption);
      close();
      const currentState = readState();
      if(resolveCounterpartCode(currentState.counterpartCode, currentState.currencies) === nextCode) return;
      writeState({ ...currentState, counterpartCode: nextCode });
      refreshView();
      showToast('تم تحديث عملة التسعير المتقاطع.', 'success');
    };

    const onDocumentPointerDown = (event) => {
      if(popover.hidden) return;
      const target = resolveEventElement(event.target);
      if(target && (wrapper.contains(target) || popover.contains(target))) return;
      close();
    };

    const onDocumentKeyDown = (event) => {
      if(event.key !== 'Escape' || popover.hidden) return;
      event.preventDefault();
      event.stopPropagation();
      close();
      trigger.focus({ preventScroll: true });
    };

    const onAnyScroll = () => {
      if(popover.hidden) return;
      close();
    };

    trigger.addEventListener('click', onTriggerClick);
    popover.addEventListener('click', onOptionClick);
    document.addEventListener('pointerdown', onDocumentPointerDown, true);
    document.addEventListener('keydown', onDocumentKeyDown, true);
    window.addEventListener('resize', onAnyScroll, { passive: true });
    if(scrollRoot) scrollRoot.addEventListener('scroll', onAnyScroll, { passive: true });
    if(toolbarStrip) toolbarStrip.addEventListener('scroll', onAnyScroll, { passive: true });

    return () => {
      trigger.removeEventListener('click', onTriggerClick);
      popover.removeEventListener('click', onOptionClick);
      document.removeEventListener('pointerdown', onDocumentPointerDown, true);
      document.removeEventListener('keydown', onDocumentKeyDown, true);
      window.removeEventListener('resize', onAnyScroll);
      if(scrollRoot) scrollRoot.removeEventListener('scroll', onAnyScroll);
      if(toolbarStrip) toolbarStrip.removeEventListener('scroll', onAnyScroll);
      if(popover.isConnected) popover.remove();
    };
  }

  function getSelectedRow(rows){
    if(!runtime.selectedCode) return null;
    return rows.find((row) => row.code === runtime.selectedCode) || null;
  }

  function getMainFilterText(){
    return String(runtime.filter || '').trim().toUpperCase();
  }

  function rowMatchesMainFilter(row, filterText = getMainFilterText()){
    if(!filterText) return true;
    return row.code.includes(filterText) || row.name.toUpperCase().includes(filterText);
  }


  function suppressRowInteractions(duration = 520){
    const until = Date.now() + Math.max(0, Number(duration) || 0);
    runtime.rowInteractionGuardUntil = Math.max(runtime.rowInteractionGuardUntil, until);
  }

  function hasActiveCurrencyModal(){
    return Boolean(document.querySelector('.taif-currency-management-modal-backdrop'));
  }

  function isRowInteractionSuppressed(){
    return Date.now() < runtime.rowInteractionGuardUntil;
  }

  function openEditorForCode(code){
    if(!code) return;

    runtime.selectedCode = code;
    updateSelectionUi();

    const usdEditor = feature.openUsdEditor || TAIF.currencyManagement?.openUsdEditor;
    const currencyEditor = feature.openCurrencyEditor || TAIF.currencyManagement?.openCurrencyEditor;

    if(code === 'USD'){
      if(typeof usdEditor === 'function') usdEditor();
      else showToast('تعذر فتح نافذة الدولار حاليًا.', 'danger');
      return;
    }

    if(typeof currencyEditor === 'function') currencyEditor(code);
    else showToast('تعذر فتح نافذة تعديل العملة حاليًا.', 'danger');
  }

  function updateSelectionUi(panel = runtime.panel){
    if(!panel) return;

    panel.querySelectorAll('.currency-management-row').forEach((rowElement) => {
      const isSelected = Boolean(runtime.selectedCode) && rowElement.dataset.code === runtime.selectedCode;
      rowElement.classList.toggle('currency-management-row--selected', isSelected);
      rowElement.querySelector('.currency-management-state-dot')?.classList.toggle('is-active', isSelected);
    });
  }

  function clearSelection({ rerender = false } = {}){
    runtime.selectedCode = null;
    if(rerender){
      refreshView();
      return;
    }
    updateSelectionUi();
  }

  let externalSelectionClearBound = false;
  function bindExternalSelectionClear(){
    if(externalSelectionClearBound) return;
    externalSelectionClearBound = true;

    document.addEventListener('pointerdown', (event) => {
      if(!runtime.selectedCode) return;
      const panel = runtime.panel;
      if(!panel || !panel.isConnected || panel.dataset.view !== 'currency-management') return;
      const target = resolveEventElement(event.target);
      if(!target) return;
      if(target.closest('.currency-management-row')) return;
      clearSelection();
    }, true);
  }

  function applyMainSearchFilter(panel){
    if(!panel) return;

    const filterText = getMainFilterText();

    panel.querySelectorAll('.currency-management-row').forEach((rowElement) => {
      const haystack = String(rowElement.dataset.search || '').toUpperCase();
      const matches = !filterText || haystack.includes(filterText);
      rowElement.classList.toggle('currency-management-row--hidden', !matches);
      if(!matches && runtime.selectedCode === rowElement.dataset.code){
        runtime.selectedCode = null;
        rowElement.classList.remove('currency-management-row--selected');
        rowElement.querySelector('.currency-management-state-dot')?.classList.remove('is-active');
      }
    });

    updateSelectionUi(panel);

    const clearButton = panel.querySelector('#currency-management-search-clear');
    if(clearButton){
      clearButton.hidden = !runtime.filter;
    }
  }

  function refreshView(){
    if(!(runtime.panel && runtime.panel.dataset.view === 'currency-management')) return;

    const renderer = feature.renderCurrencyManagement || TAIF.currencyManagement?.render;
    if(typeof renderer === 'function'){
      renderer(runtime.panel);
      return;
    }

    showToast('تعذر تحديث واجهة إدارة العملات حاليًا.', 'danger');
  }

  function openModal({ title, subtitle = '', bodyHtml, wide = false, size = '', variant = 'default', modalClass = '', bodyClass = '', showExpand = null, onMount }){
    bindTextSelectionGuard();
    clearSelection();
    clearBrowserTextSelection();

    const resolvedSize = size || (wide ? 'lg' : 'md');
    const sizeClass = resolvedSize === 'lg' ? ' taif-currency-management-modal--size-lg' : resolvedSize === 'sm' ? ' taif-currency-management-modal--size-sm' : ' taif-currency-management-modal--size-md';
    const variantClass = variant === 'grand' ? ' taif-currency-management-modal--grand' : '';
    const extraModalClass = modalClass ? ` ${String(modalClass).trim()}` : '';
    const extraBodyClass = bodyClass ? ` ${String(bodyClass).trim()}` : '';
    const shouldShowExpand = typeof showExpand === 'boolean' ? showExpand : variant === 'grand';
    const windowId = `taif-currency-window-${++runtime.modalSequence}`;
    const actionsMarkup = variant === 'grand'
      ? `
          <div class="taif-currency-management-modal__window-actions" data-taif-window-actions="true">
            ${shouldShowExpand ? `<button class="taif-currency-management-modal__chrome-btn taif-currency-management-modal__expand" type="button" aria-label="تكبير النافذة" title="تكبير النافذة">${createButtonIcon('expand')}</button>` : ''}
            <button class="taif-currency-management-modal__chrome-btn taif-currency-management-modal__close" type="button" aria-label="إغلاق" title="إغلاق">${createButtonIcon('close')}</button>
          </div>
        `
      : `<button class="taif-currency-management-modal__close" type="button" aria-label="إغلاق" title="إغلاق">${createButtonIcon('close')}</button>`;

    const backdrop = document.createElement('div');
    backdrop.className = 'taif-currency-management-modal-backdrop';
    backdrop.dataset.windowId = windowId;
    const grandHeadingMarkup = `
          <div class="taif-currency-management-modal__heading taif-currency-management-modal__heading--centered">
            <h3 class="taif-currency-management-modal__title" data-taif-detail-title="true">${escapeHtml(title)}</h3>
          </div>
        `;
    const defaultHeadingMarkup = `
          <div class="taif-currency-management-modal__heading">
            <div class="taif-currency-management-modal__eyebrow">TAIF WINDOW</div>
            <h3 class="taif-currency-management-modal__title" data-taif-detail-title="true">${escapeHtml(title)}</h3>
            ${subtitle ? `<p class="taif-currency-management-modal__subtitle">${escapeHtml(subtitle)}</p>` : ''}
          </div>
        `;

    backdrop.innerHTML = `
      <div class="taif-currency-management-modal${sizeClass}${variantClass}${wide ? ' taif-currency-management-modal--wide' : ''}${extraModalClass}" role="dialog" aria-modal="false" aria-label="${escapeHtml(title)}" data-modal-size="${escapeHtml(resolvedSize)}" data-modal-variant="${escapeHtml(variant)}" data-window-id="${escapeHtml(windowId)}" tabindex="-1">
        <div class="taif-currency-management-modal__head">
          ${variant === 'grand' ? grandHeadingMarkup : defaultHeadingMarkup}
          ${actionsMarkup}
        </div>
        <div class="taif-currency-management-modal__body${extraBodyClass}">${bodyHtml}</div>
      </div>
    `;

    const modal = backdrop.querySelector('.taif-currency-management-modal');
    const body = backdrop.querySelector('.taif-currency-management-modal__body');
    const closeButton = backdrop.querySelector('.taif-currency-management-modal__close');
    const expandButton = backdrop.querySelector('.taif-currency-management-modal__expand');
    const modalLayer = ensureModalLayer();
    const cleanupCallbacks = [];

    const registerCleanup = typeof pushCleanupCallback === 'function'
      ? pushCleanupCallback.bind(null, cleanupCallbacks)
      : ((cleanup) => cleanup);

    function syncExpandButton(){
      if(!expandButton) return;
      const expanded = modal.classList.contains('is-maximized');
      if(windowChrome && typeof windowChrome.syncExpandButton === 'function'){
        windowChrome.syncExpandButton(expandButton, expanded);
        return;
      }
      expandButton.innerHTML = createButtonIcon(expanded ? 'collapse' : 'expand');
      expandButton.setAttribute('aria-label', expanded ? 'استعادة الحجم المرجعي' : 'تكبير النافذة');
      expandButton.setAttribute('title', expanded ? 'استعادة الحجم المرجعي' : 'تكبير النافذة');
      expandButton.setAttribute('aria-pressed', expanded ? 'true' : 'false');
    }

    const toggleExpand = windowChrome.createToggleExpandHandler({
      modal,
      expandButton,
      maximizeModalWindow,
      restoreModalWindow,
      syncExpandButton,
      activateModalWindow: () => activateModalWindow(backdrop)
    });

    function close(event){
      if(backdrop.dataset.closing === 'true') return;
      if(event){
        event.preventDefault();
        event.stopPropagation();
      }
      backdrop.dataset.closing = 'true';
      suppressRowInteractions(650);
      backdrop.classList.add('is-closing');
      unregisterModalWindow(backdrop);
      const cleanup = backdrop.__cleanup;
      backdrop.__cleanup = null;
      if(typeof cleanup === 'function') cleanup();
      window.setTimeout(() => {
        backdrop.remove();
        cleanupModalRegistry();
      }, 120);
    }

    function onKeyDown(event){
      if(!isTopmostModal(backdrop)) return;
      if(event.key === 'Escape') close();
      if((event.key === 'F11' || (event.altKey && event.key === 'Enter')) && expandButton){
        event.preventDefault();
        toggleExpand();
      }
    }

    function onResize(){
      syncModalWithinViewport(modal);
    }

    function onActivate(){
      activateModalWindow(backdrop);
    }

    const resizeObserverTarget = (runtime.panel && runtime.panel.isConnected)
      ? (runtime.panel.querySelector('.currency-management-shell') || runtime.panel)
      : null;
    let resizeObserver = null;

    cleanupCallbacks.push(bindModalDragging({ backdrop, modal }));

    backdrop.__cleanup = () => {
      if(typeof runCleanupCallbacks === 'function'){
        runCleanupCallbacks(cleanupCallbacks, { clearSource:true });
      } else {
        cleanupCallbacks.forEach((cleanup) => {
          if(typeof cleanup === 'function') cleanup();
        });
        cleanupCallbacks.length = 0;
      }
      document.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('resize', onResize);
      modal.removeEventListener('pointerdown', onActivate, true);
      backdrop.__cleanup = null;
    };

    closeButton?.addEventListener('click', close);
    closeButton?.addEventListener('pointerdown', (event) => {
      event.stopPropagation();
    }, true);
    expandButton?.addEventListener('click', toggleExpand);
    expandButton?.addEventListener('pointerdown', (event) => {
      event.stopPropagation();
    }, true);
    modal.addEventListener('pointerdown', onActivate, true);
    backdrop.addEventListener('click', (event) => {
      if(event.target !== backdrop) return;
      if(!isTopmostModal(backdrop)) return;
      close(event);
    });
    document.addEventListener('keydown', onKeyDown);
    window.addEventListener('resize', onResize, { passive: true });

    if(typeof ResizeObserver === 'function' && resizeObserverTarget instanceof HTMLElement){
      resizeObserver = new ResizeObserver(() => {
        syncModalWithinViewport(modal);
      });
      resizeObserver.observe(resizeObserverTarget);
      registerCleanup(() => resizeObserver?.disconnect());
    }

    modalLayer.appendChild(backdrop);
    registerModalWindow(backdrop);
    syncExpandButton();

    let formNavigationCleanup = null;
    const bindFormNavigation = TAIF?.ui?.windowChrome?.bindFormNavigation;
    if(typeof bindFormNavigation === 'function'){
      formNavigationCleanup = bindFormNavigation({ root: modal, autoFocus: false });
      registerCleanup(formNavigationCleanup);
    }

    if(typeof onMount === 'function'){
      onMount({ backdrop, modal, body, close, toggleExpand, registerCleanup });
    }

    requestAnimationFrame(() => {
      syncModalWithinViewport(modal);
      activateModalWindow(backdrop);
      if(formNavigationCleanup && typeof formNavigationCleanup.focusInitialTarget === 'function' && formNavigationCleanup.focusInitialTarget()) return;
      modal.focus({ preventScroll: true });
    });

    return { backdrop, modal, body, close, toggleExpand };
  }

  function buttonMarkup({ action, label, tone = 'ghost', icon, disabled = false }){
    const toneClass = tone === 'primary' ? ' currency-management-btn--primary' : tone === 'danger' ? ' currency-management-btn--danger' : tone === 'dark' ? ' currency-management-btn--dark' : '';
    const toneAttribute = tone === 'primary' || tone === 'danger' || tone === 'dark' ? ` data-taif-action-tone="${escapeHtml(tone)}"` : '';
    const normalizedAction = String(action || '').trim().toLowerCase();
    const role = /cancel|close|dismiss|back/.test(normalizedAction)
      ? 'cancel'
      : (/save|confirm|submit|create|add|apply|update|delete|remove|restore/.test(normalizedAction) ? 'commit' : '');
    const roleAttribute = role ? ` data-taif-action-role="${role}"` : '';
    return `
      <button class="currency-management-btn${toneClass}" type="button" data-currency-management-action="${action}"${toneAttribute}${roleAttribute} ${disabled ? 'disabled' : ''}>
        ${icon ? createButtonIcon(icon) : ''}
        <span class="taif-control-text">${escapeHtml(label)}</span>
      </button>
    `;
  }

  function iconButtonMarkup({ action, title, icon, danger = false, move = false, disabled = false }){
    return `
      <button class="currency-management-iconbtn${danger ? ' currency-management-iconbtn--danger' : ''}${move ? ' currency-management-iconbtn--move' : ''}${disabled ? ' is-disabled' : ''}" type="button" data-row-action="${action}" title="${escapeHtml(title)}" ${disabled ? 'disabled' : ''}>
        ${createButtonIcon(icon)}
      </button>
    `;
  }

  function bindModalActionButtons(scope, action, handler){
    if(!scope || typeof handler !== 'function') return;
    scope.querySelectorAll(`[data-currency-management-action="${action}"]`).forEach((button) => button.addEventListener('click', handler));
  }

  function bindModalCloseButtons(scope, close){
    bindModalActionButtons(scope, 'cancel', close);
  }

  function setInlinePopoverState({ picker = null, popover = null, trigger = null, isOpen = false } = {}){
    if(typeof setDisclosureOpenState === 'function'){
      setDisclosureOpenState({ root: picker, popup: popover, trigger, isOpen });
      return;
    }
    if(popover) popover.hidden = !isOpen;
    if(popover) popover.classList.toggle('is-open', Boolean(isOpen));
    if(trigger) trigger.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    if(picker) picker.classList.toggle('is-open', Boolean(isOpen));
  }

  function bindInlinePopoverDismiss({ modal, picker = null, trigger = null, isOpen, closePopover, scrollTargets = [], registerCleanup = null, isInsidePopoverTarget = null } = {}){
    if(!modal || typeof closePopover !== 'function' || typeof isOpen !== 'function') return () => {};

    const normalizedScrollTargets = (Array.isArray(scrollTargets) ? scrollTargets : [scrollTargets]).filter(Boolean);

    function onPointerDownCapture(event){
      if(!isOpen()) return;
      const target = resolveEventElement(event.target);
      if(!target) return;
      if(picker && picker.contains(target)) return;
      if(typeof isInsidePopoverTarget === 'function' && isInsidePopoverTarget(target)) return;
      closePopover();
    }

    function onKeyDownCapture(event){
      if(event.key !== 'Escape' || !isOpen()) return;
      event.preventDefault();
      event.stopPropagation();
      closePopover();
      if(trigger && typeof trigger.focus === 'function'){
        requestAnimationFrame(() => trigger.focus({ preventScroll: true }));
      }
    }

    function onScroll(){
      if(!isOpen()) return;
      closePopover();
    }

    modal.addEventListener('pointerdown', onPointerDownCapture, true);
    modal.addEventListener('keydown', onKeyDownCapture, true);
    normalizedScrollTargets.forEach((target) => target.addEventListener('scroll', onScroll, { passive: true }));

    const cleanup = () => {
      modal.removeEventListener('pointerdown', onPointerDownCapture, true);
      modal.removeEventListener('keydown', onKeyDownCapture, true);
      normalizedScrollTargets.forEach((target) => target.removeEventListener('scroll', onScroll));
    };

    if(typeof registerCleanup === 'function') registerCleanup(cleanup);
    return cleanup;
  }

  function createFlagPickerMarkup(fieldPrefix, currencyCode, storedFlagCode){
    const resolvedFlagCode = resolveStoredFlagCode(storedFlagCode || '', currencyCode || '');
    const { displayCode, displayLabel, isPlaceholder } = getFlagPickerDisplay(resolvedFlagCode);

    return `
      <div class="currency-management-flag-picker" data-currency-management-flag-picker data-taif-inline-picker-host="true">
        <button id="${escapeHtml(fieldPrefix)}-flag-trigger" class="currency-management-input currency-management-flag-picker__trigger${isPlaceholder ? ' is-empty' : ''}" type="button" aria-haspopup="dialog" aria-expanded="false" data-taif-picker-trigger="true">
          <span class="currency-management-flag-picker__preview" aria-hidden="true">${createFlagImageMarkup({ code: currencyCode, flag: resolvedFlagCode }, { className: 'currency-management-flag-picker__preview-image' })}</span>
          <span class="currency-management-flag-picker__text">
            <span class="currency-management-flag-picker__code${isPlaceholder ? ' is-placeholder' : ''}" data-currency-management-flag-code>${escapeHtml(displayCode)}</span>
            <span class="currency-management-flag-picker__label" data-currency-management-flag-label>${escapeHtml(displayLabel)}</span>
          </span>
          <span class="currency-management-flag-picker__icon">${createButtonIcon('chevronDown')}</span>
        </button>
        <input id="${escapeHtml(fieldPrefix)}-flag" type="hidden" value="${escapeHtml(resolvedFlagCode)}">
      </div>
    `;
  }


  function renderChoiceOptionLabelMarkup(option){
    const safeLabel = escapeHtml(option && option.label ? option.label : '');
    const safeMethodTag = escapeHtml(option && option.methodTag ? option.methodTag : '');
    if(option && option.richType === 'currency-with-flag' && option.value){
      const flagMarkup = createFlagImageMarkup({ code: option.value, flag: option.flag }, { className: 'currency-management-linked-source-option__flag-image' });
      return `
        <span class="currency-management-linked-source-option">
          <span class="currency-management-linked-source-option__flag" aria-hidden="true">${flagMarkup}</span>
          <span class="currency-management-linked-source-option__name">${safeLabel}</span>
        </span>
      `;
    }
    if(!safeMethodTag) return safeLabel;
    return `
      <span class="currency-management-method-picker__value-layout">
        <span class="currency-management-method-picker__formula" dir="ltr">${safeLabel}</span>
        <span class="currency-management-method-picker__method-tag">${safeMethodTag}</span>
      </span>
    `;
  }

  function syncChoiceValueNodeContent(node, option){
    if(!node) return;
    if(option && (option.methodTag || (option.richType === 'currency-with-flag' && option.value))){
      node.classList.toggle('has-method-tag', !!option.methodTag);
      node.innerHTML = renderChoiceOptionLabelMarkup(option);
      return;
    }
    node.classList.remove('has-method-tag');
    node.textContent = option && option.label ? option.label : '';
  }

  function createChoicePickerMarkup({ pickerDataAttribute, triggerId, inputId, valueDataAttribute, value, options }){
    const safeOptions = Array.isArray(options) && options.length ? options : [{ value: '', label: '' }];
    const normalizedValue = safeOptions.some((option) => option.value === value) ? value : safeOptions[0].value;
    const activeOption = safeOptions.find((option) => option.value === normalizedValue) || safeOptions[0];
    return `
      <div class="currency-management-method-picker" data-taif-inline-picker-host="true" ${pickerDataAttribute}>
        <button id="${escapeHtml(triggerId)}" class="currency-management-input currency-management-method-picker__trigger" type="button" aria-haspopup="listbox" aria-expanded="false" data-taif-picker-trigger="true">
          <span class="currency-management-method-picker__value${activeOption && activeOption.methodTag ? ' has-method-tag' : ''}" ${valueDataAttribute}>${renderChoiceOptionLabelMarkup(activeOption)}</span>
          <span class="currency-management-method-picker__icon">${createButtonIcon('chevronDown')}</span>
        </button>
        <input id="${escapeHtml(inputId)}" type="hidden" value="${escapeHtml(normalizedValue)}">
      </div>
    `;
  }

  function mountChoicePicker({
    modal,
    scrollArea,
    pickerSelector,
    triggerSelector,
    inputSelector,
    valueSelector,
    options,
    ariaLabel,
    registerCleanup = null,
    preferredOpenDirection = 'auto',
    maxPopoverHeight = 196,
    viewportBoundary = 'scroll'
  }){
    const picker = modal.querySelector(pickerSelector);
    const trigger = modal.querySelector(triggerSelector);
    const input = modal.querySelector(inputSelector);
    const valueNode = modal.querySelector(valueSelector);
    const panel = trigger?.closest('.currency-management-single-editor-panel') || modal.querySelector('.currency-management-single-editor-panel') || modal;
    let currentOptions = Array.isArray(options) && options.length ? options : [{ value: '', label: '' }];
    if(!picker || !trigger || !input || !valueNode || !scrollArea || !panel) return { close(){}, getValue(){ return currentOptions[0].value; }, setValue(){ return false; }, setOptions(){ return currentOptions; } };

    let popover = null;
    let currentValue = currentOptions.some((option) => option.value === input.value) ? input.value : currentOptions[0].value;
    const popoverPositionScheduler = typeof createAnimationFrameScheduler === 'function'
      ? createAnimationFrameScheduler(positionPopover)
      : null;
    let pickerApi = null;
    const commitController = createInlinePickerCommitController(trigger);

    function focusChoiceTarget(element){
      if(!(element instanceof HTMLElement)) return false;
      try{ element.focus({ preventScroll: true }); }catch{ try{ element.focus(); }catch{} }
      return document.activeElement === element;
    }

    const typeahead = typeof createTypeaheadNavigator === 'function'
      ? createTypeaheadNavigator({
          getItems: () => currentOptions,
          getCurrentIndex: () => currentOptions.findIndex((option) => option.value === currentValue),
          resolveLabel: (option) => [option && option.label, option && option.methodTag, option && option.formula].filter(Boolean).join(' '),
          onMatch: (option, index) => {
            if(!option || !option.value) return;
            if(isPopoverOpen()){
              focusChoiceIndex(index, { scrollBehavior:'auto', scrollBlock:'start' });
              return;
            }
            syncChoiceState(option.value);
            if(commitController && typeof commitController.markCommittedSelection === 'function'){
              commitController.markCommittedSelection();
            }
          }
        })
      : { reset(){}, handleKey(){ return false; } };

    function getOptionData(nextValue){
      return currentOptions.find((option) => option.value === nextValue) || currentOptions[0];
    }

    function getOptionButtons(){
      if(!popover) return [];
      return Array.from(popover.querySelectorAll('[data-currency-management-choice-option]')).filter((node) => node instanceof HTMLButtonElement && !node.disabled);
    }

    function syncChoiceState(nextValue, { dispatchEvents = true } = {}){
      const previousValue = input.value;
      currentValue = currentOptions.some((option) => option.value === nextValue) ? nextValue : currentOptions[0].value;
      input.value = currentValue;
      syncChoiceValueNodeContent(valueNode, getOptionData(currentValue));
      if(popover){
        popover.querySelectorAll('[data-currency-management-choice-option]').forEach((option) => {
          const isActive = option.dataset.currencyManagementChoiceOption === currentValue;
          option.classList.toggle('is-active', isActive);
          option.setAttribute('aria-selected', isActive ? 'true' : 'false');
        });
      }
      if(dispatchEvents && previousValue !== currentValue){
        try{ input.dispatchEvent(new Event('input', { bubbles: true })); }catch{}
        try{ input.dispatchEvent(new Event('change', { bubbles: true })); }catch{}
      }
    }

    function isPopoverOpen(){
      return Boolean(popover && !popover.hidden);
    }

    function positionPopover(){
      if(!popover || popover.hidden) return;
      const panelRect = panel.getBoundingClientRect();
      const triggerRect = trigger.getBoundingClientRect();
      const scrollRect = scrollArea.getBoundingClientRect();
      const modalRect = modal.getBoundingClientRect();
      const gap = 6;
      const usePanelBoundary = viewportBoundary === 'panel';
      const useModalBoundary = viewportBoundary === 'modal';
      const viewportTop = useModalBoundary
        ? Math.max(panelRect.top, modalRect.top + 10)
        : (usePanelBoundary ? panelRect.top : Math.max(panelRect.top, scrollRect.top));
      const viewportBottom = useModalBoundary
        ? Math.max(viewportTop + 72, modalRect.bottom - 12)
        : (usePanelBoundary ? (panelRect.bottom - 10) : Math.min(panelRect.bottom, scrollRect.bottom));
      const left = Math.max(0, triggerRect.left - panelRect.left);
      const width = Math.max(180, triggerRect.width);
      const availableBelow = Math.max(0, Math.floor(viewportBottom - triggerRect.bottom - gap));
      const availableAbove = Math.max(0, Math.floor(triggerRect.top - viewportTop - gap));

      popover.style.left = `${left}px`;
      popover.style.right = 'auto';
      popover.style.width = `${width}px`;
      popover.style.maxHeight = 'none';
      popover.style.visibility = 'hidden';

      const naturalHeight = Math.max(popover.scrollHeight, 72);
      const resolvedMaxPopoverHeight = Math.max(72, Number(maxPopoverHeight) || 196);
      const requiredHeight = Math.min(naturalHeight, resolvedMaxPopoverHeight);
      const forceUp = preferredOpenDirection === 'up';
      const forceDown = preferredOpenDirection === 'down';
      const shouldOpenUp = forceUp ? true : (forceDown ? false : (availableBelow < requiredHeight && availableAbove > availableBelow));
      const maxHeight = Math.max(72, Math.min(shouldOpenUp ? availableAbove : availableBelow, resolvedMaxPopoverHeight));

      popover.dataset.openDirection = shouldOpenUp ? 'up' : 'down';
      popover.style.maxHeight = `${maxHeight}px`;
      const renderedHeight = Math.min(popover.scrollHeight, maxHeight);
      const top = shouldOpenUp
        ? Math.max(0, triggerRect.top - panelRect.top - renderedHeight - gap)
        : Math.max(0, triggerRect.bottom - panelRect.top + gap);

      popover.style.top = `${top}px`;
      popover.style.visibility = '';
    }

    const schedulePositionPopover = popoverPositionScheduler
      ? popoverPositionScheduler.schedule.bind(popoverPositionScheduler)
      : (() => {
          requestAnimationFrame(() => {
            positionPopover();
          });
        });

    function closePopover(){
      typeahead.reset();
      if(popoverPositionScheduler) popoverPositionScheduler.cancel();
      if(popover) popover.style.visibility = '';
      setInlinePopoverState({
        picker,
        popover,
        trigger,
        isOpen: false
      });
    }

    function renderPopoverOptions(){
      if(!popover) return;
      popover.innerHTML = currentOptions.map((option) => `
        <button class="currency-management-method-popover__option" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-taif-inline-picker-option="true" role="option" data-currency-management-choice-option="${escapeHtml(option.value)}">
          <span class="currency-management-method-popover__label${option && option.methodTag ? ' has-method-tag' : ''}" data-taif-dropdown-label="true">${renderChoiceOptionLabelMarkup(option)}</span>
          <span class="currency-management-method-popover__check">${createButtonIcon('check')}</span>
        </button>
      `).join('');
      popover.querySelectorAll('[data-currency-management-choice-option]').forEach((optionButton) => {
        optionButton.addEventListener('click', () => {
          const shouldRestoreTriggerFocus = commitController.shouldRestoreTriggerFocusAfterSelection();
          syncChoiceState(optionButton.dataset.currencyManagementChoiceOption);
          if(shouldRestoreTriggerFocus) commitController.markCommittedSelection();
          else commitController.clearCommittedSelection();
          closePopover();
          if(shouldRestoreTriggerFocus){
            requestAnimationFrame(() => focusChoiceTarget(trigger));
          }
        });
      });
    }

    function ensurePopover(){
      if(popover) return;
      popover = document.createElement('div');
      popover.className = 'currency-management-method-popover';
      popover.dataset.taifDropdownPopup = 'true';
      popover.dataset.taifDropdownLayout = 'list';
      popover.dataset.taifInlinePicker = 'true';
      popover.setAttribute('role', 'listbox');
      popover.setAttribute('aria-label', ariaLabel);
      popover.hidden = true;
      popover.addEventListener('keydown', onPopoverKeyDown);
      panel.appendChild(popover);
      if(pickerApi) popover.__taifInlinePickerApi = pickerApi;
      renderPopoverOptions();
    }

    function focusChoiceIndex(targetIndex = 0, { scrollBehavior = 'auto', scrollBlock = 'nearest' } = {}){
      const optionsNodes = getOptionButtons();
      if(!optionsNodes.length) return false;
      const normalizedIndex = Math.max(0, Math.min(optionsNodes.length - 1, Number(targetIndex) || 0));
      const targetOption = optionsNodes[normalizedIndex];
      if(!focusChoiceTarget(targetOption)) return false;
      if(typeof targetOption.scrollIntoView === 'function'){
        try{
          targetOption.scrollIntoView({ block:scrollBlock, inline:'nearest', behavior:scrollBehavior });
        }catch{}
      }
      return true;
    }

    function focusChoiceOption(direction = 'current'){
      const optionsNodes = getOptionButtons();
      if(!optionsNodes.length) return false;
      const activeIndex = optionsNodes.findIndex((node) => node.dataset.currencyManagementChoiceOption === currentValue);
      if(direction === 'last') return focusChoiceIndex(optionsNodes.length - 1);
      return focusChoiceIndex(activeIndex >= 0 ? activeIndex : 0);
    }

    function stepChoiceSelection(step = 0){
      if(!currentOptions.length) return false;
      const currentIndex = currentOptions.findIndex((option) => option.value === currentValue);
      const normalizedStep = step < 0 ? -1 : 1;
      const startIndex = currentIndex === -1 ? 0 : currentIndex;
      const nextIndex = Math.max(0, Math.min(currentOptions.length - 1, startIndex + normalizedStep));
      if(nextIndex === startIndex) return false;
      syncChoiceState(currentOptions[nextIndex].value);
      return true;
    }

    function openPopover(){
      typeahead.reset();
      commitController.clearCommittedSelection();
      ensurePopover();
      syncChoiceState(currentValue, { dispatchEvents:false });
      if(popover) popover.style.visibility = 'hidden';
      setInlinePopoverState({
        picker,
        popover,
        trigger,
        isOpen: true
      });
      positionPopover();
      schedulePositionPopover();
    }

    function onPopoverKeyDown(event){
      if(event.defaultPrevented) return;
      const optionButtons = getOptionButtons();
      const activeElement = event.target instanceof Element ? event.target.closest('[data-currency-management-choice-option]') : null;
      if(!optionButtons.length || !(activeElement instanceof HTMLButtonElement)) return;
      const currentIndex = optionButtons.indexOf(activeElement);
      if(currentIndex === -1) return;

      if(event.key === 'ArrowDown'){
        event.preventDefault();
        focusChoiceIndex(Math.min(optionButtons.length - 1, currentIndex + 1));
        return;
      }

      if(event.key === 'ArrowUp'){
        event.preventDefault();
        focusChoiceIndex(Math.max(0, currentIndex - 1));
        return;
      }

      if(event.key === 'Home'){
        event.preventDefault();
        focusChoiceIndex(0);
        return;
      }

      if(event.key === 'End'){
        event.preventDefault();
        focusChoiceIndex(optionButtons.length - 1);
        return;
      }

      if(typeahead.handleKey(event.key, { currentIndex })){
        event.preventDefault();
        return;
      }

      if(event.key === 'Enter' || event.key === 'NumpadEnter' || event.key === ' ' || event.key === 'Spacebar'){
        event.preventDefault();
        activeElement.click();
        return;
      }

      if(event.key === 'Tab'){
        closePopover();
      }
    }

    function setChoiceValue(nextValue, { dispatchEvents = true } = {}){
      syncChoiceState(nextValue, { dispatchEvents });
      return currentValue;
    }

    function setChoiceOptions(nextOptions, { preserveValue = true, preferredValue = null, dispatchEvents = false } = {}){
      currentOptions = Array.isArray(nextOptions) && nextOptions.length ? nextOptions : [{ value: '', label: '' }];
      const targetValue = preserveValue && currentOptions.some((option) => option.value === currentValue)
        ? currentValue
        : ((preferredValue != null && currentOptions.some((option) => option.value === preferredValue)) ? preferredValue : currentOptions[0].value);
      if(popover){
        renderPopoverOptions();
        if(isPopoverOpen()){
          schedulePositionPopover();
        }
      }
      syncChoiceState(targetValue, { dispatchEvents });
      return currentOptions;
    }

    function openForKeyboard(){
      if(!isPopoverOpen()) openPopover();
      requestAnimationFrame(() => {
        focusChoiceOption('current');
      });
    }

    bindInlinePopoverDismiss({
      modal,
      picker,
      trigger,
      isOpen: isPopoverOpen,
      closePopover,
      scrollTargets: [scrollArea],
      registerCleanup,
      isInsidePopoverTarget: (target) => {
        const element = resolveEventElement(target);
        return Boolean(popover && element && popover.contains(element));
      }
    });

    const onWindowResize = () => {
      if(!isPopoverOpen()) return;
      schedulePositionPopover();
    };
    window.addEventListener('resize', onWindowResize);
    if(typeof registerCleanup === 'function'){
      registerCleanup(() => {
        window.removeEventListener('resize', onWindowResize);
        if(popoverPositionScheduler) popoverPositionScheduler.cancel();
        if(popover) popover.removeEventListener('keydown', onPopoverKeyDown);
      });
    }

    syncChoiceState(currentValue);

    pickerApi = {
      type: 'choice',
      getTrigger(){
        return trigger;
      },
      isOpen: isPopoverOpen,
      openForKeyboard,
      close: closePopover,
      focusActiveOption(){
        return focusChoiceOption('current');
      },
      stepValue(step){
        return stepChoiceSelection(step);
      },
      setValue(nextValue, options = {}){
        return setChoiceValue(nextValue, options);
      },
      setOptions(nextOptions, options = {}){
        return setChoiceOptions(nextOptions, options);
      },
      prepareKeyboardSelection: commitController.prepareKeyboardSelection,
      markCommittedSelection: commitController.markCommittedSelection,
      consumeCommittedSelection: commitController.consumeCommittedSelection,
      clearCommittedSelection: commitController.clearCommittedSelection
    };
    registerInlinePickerApi({
      picker,
      trigger,
      getPopover: () => popover,
      api: pickerApi,
      clearCommittedSelection: commitController.clearCommittedSelection,
      registerCleanup
    });

    trigger.addEventListener('click', (event) => {
      event.preventDefault();
      if(isPopoverOpen()) closePopover();
      else openPopover();
    });
    trigger.addEventListener('keydown', (event) => {
      if(event.defaultPrevented || event.isComposing || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
      if(event.key === 'ArrowDown' || event.key === 'ArrowUp'){
        event.preventDefault();
        if(!isPopoverOpen()) openPopover();
        requestAnimationFrame(() => {
          focusChoiceOption(event.key === 'ArrowUp' ? 'last' : 'current');
        });
        return;
      }
      if(event.key === ' ' || event.key === 'Spacebar'){
        event.preventDefault();
        if(isPopoverOpen()) closePopover();
        else openPopover();
        return;
      }
      if(typeahead.handleKey(event.key)){
        event.preventDefault();
      }
    });

    return {
      close: closePopover,
      getValue(){
        return currentValue;
      },
      openForKeyboard,
      isOpen: isPopoverOpen,
      getTrigger(){
        return trigger;
      },
      focusActiveOption(){
        return focusChoiceOption('current');
      },
      stepValue(step){
        return stepChoiceSelection(step);
      },
      setValue(nextValue, options = {}){
        return setChoiceValue(nextValue, options);
      },
      setOptions(nextOptions, options = {}){
        return setChoiceOptions(nextOptions, options);
      }
    };
  }

  function mountFlagPicker({ modal, scrollArea, fieldPrefix, currencyCodeInput = null, currencyNameInput = null, fallbackCurrencyCode = '', registerCleanup = null }){
    const flagPicker = modal.querySelector('[data-currency-management-flag-picker]');
    const flagInput = modal.querySelector(`#${fieldPrefix}-flag`);
    const flagTrigger = modal.querySelector(`#${fieldPrefix}-flag-trigger`);
    const flagLabelNode = modal.querySelector('[data-currency-management-flag-label]');
    const flagCodeNode = modal.querySelector('[data-currency-management-flag-code]');
    const flagPreviewNode = modal.querySelector('.currency-management-flag-picker__preview');
    const panel = modal.querySelector('.currency-management-single-editor-panel');
    if(!flagPicker || !flagInput || !flagTrigger || !scrollArea || !panel) return { close(){} };

    let flagPopover = null;
    let searchInput = null;
    let gridContainer = null;
    let manualSelection = false;
    let suppressTriggerToggleUntil = 0;
    let pickerApi = null;
    let visibleGridItems = [];
    const commitController = createInlinePickerCommitController(flagTrigger);

    function focusFlagTarget(element){
      if(!(element instanceof HTMLElement)) return false;
      try{ element.focus({ preventScroll: true }); }catch{ try{ element.focus(); }catch{} }
      return document.activeElement === element;
    }

    function getSortedFlagCatalog(){
      return getFlagCatalog('circle', { includePlaceholder: true }).sort((a, b) => {
        if(a.code === 'xx') return -1;
        if(b.code === 'xx') return 1;
        return 0;
      });
    }

    function resolveFlagTypeaheadLabel(item){
      if(!item) return '';
      return [item.countryCode, item.currencyName, item.code, item.searchText].filter(Boolean).join(' ');
    }

    const typeahead = typeof createTypeaheadNavigator === 'function'
      ? createTypeaheadNavigator({
          getItems: () => {
            if(isFlagPopoverOpen()) return visibleGridItems;
            return getSortedFlagCatalog();
          },
          getCurrentIndex: () => {
            const selectedCode = getSelectedFlagCode();
            const sourceItems = isFlagPopoverOpen() ? visibleGridItems : getSortedFlagCatalog();
            return sourceItems.findIndex((item) => item && item.code === selectedCode);
          },
          resolveLabel: resolveFlagTypeaheadLabel,
          onMatch: (item, index) => {
            if(!item || !item.code) return;
            if(isFlagPopoverOpen()){
              focusFlagOptionIndex(index, { scrollBehavior:'auto', scrollBlock:'start' });
              return;
            }
            manualSelection = true;
            syncTrigger(item.code);
            commitController.markCommittedSelection();
          }
        })
      : { reset(){}, handleKey(){ return false; } };

    function getCurrentCurrencyCode(){
      if(currencyCodeInput) return normalizeCode(currencyCodeInput.value || fallbackCurrencyCode || '');
      return normalizeCode(fallbackCurrencyCode || '');
    }

    function getCurrentCurrencyName(){
      if(currencyNameInput) return String(currencyNameInput.value || '').trim();
      return '';
    }

    function getNameBasedFlagCode(){
      const flags = TAIF && TAIF.assets && TAIF.assets.flags;
      if(!flags || typeof flags.resolveCountryCodeForCurrencyName !== 'function') return 'xx';
      return flags.resolveCountryCodeForCurrencyName(getCurrentCurrencyName()) || 'xx';
    }

    function getAutoFlagCode(){
      const codeBasedFlagCode = resolveStoredFlagCode('', getCurrentCurrencyCode());
      if(codeBasedFlagCode && codeBasedFlagCode !== 'xx') return codeBasedFlagCode;
      const nameBasedFlagCode = getNameBasedFlagCode();
      if(nameBasedFlagCode && nameBasedFlagCode !== 'xx') return nameBasedFlagCode;
      return codeBasedFlagCode || 'xx';
    }

    function getSelectedFlagCode(){
      return resolveStoredFlagCode(flagInput.value || '', getCurrentCurrencyCode());
    }

    function syncTrigger(nextFlagCode){
      const resolvedFlagCode = resolveStoredFlagCode(nextFlagCode || '', getCurrentCurrencyCode());
      const { displayCode, displayLabel, isPlaceholder } = getFlagPickerDisplay(resolvedFlagCode);
      flagInput.value = resolvedFlagCode;
      flagTrigger.classList.toggle('is-empty', isPlaceholder);
      flagCodeNode.textContent = displayCode;
      flagCodeNode.classList.toggle('is-placeholder', isPlaceholder);
      flagLabelNode.textContent = displayLabel;
      flagPreviewNode.innerHTML = createFlagImageMarkup({ code: getCurrentCurrencyCode(), flag: resolvedFlagCode }, { className: 'currency-management-flag-picker__preview-image' });
      if(flagPopover){
        flagPopover.querySelectorAll('[data-currency-management-flag-option]').forEach((option) => {
          const isActive = option.dataset.currencyManagementFlagOption === resolvedFlagCode;
          option.classList.toggle('is-active', isActive);
          option.setAttribute('aria-selected', isActive ? 'true' : 'false');
        });
      }
    }

    function filterCatalogItems(query){
      const normalizedQuery = typeof normalizeTypeaheadText === 'function'
        ? normalizeTypeaheadText(query)
        : String(query || '').trim().toLowerCase();
      const catalog = getSortedFlagCatalog();
      if(!normalizedQuery) return catalog;
      return catalog.filter((item) => {
        const searchableText = typeof normalizeTypeaheadText === 'function'
          ? normalizeTypeaheadText(resolveFlagTypeaheadLabel(item))
          : String(item.searchText || '').toLowerCase();
        if(!searchableText) return false;
        if(searchableText.startsWith(normalizedQuery)) return true;
        return searchableText.split(' ').some((part) => part && part.startsWith(normalizedQuery));
      });
    }

    function renderGrid(query = ''){
      if(!gridContainer) return;
      const items = filterCatalogItems(query);
      visibleGridItems = Array.isArray(items) ? items : [];
      const activeCode = getSelectedFlagCode();
      if(!visibleGridItems.length){
        gridContainer.innerHTML = '';
        return;
      }
      gridContainer.innerHTML = visibleGridItems.map((item) => `
        <button class="currency-management-flag-popover__card${item.code === activeCode ? ' is-active' : ''}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="grid" data-taif-inline-picker-option="true" role="option" aria-selected="${item.code === activeCode ? 'true' : 'false'}" data-currency-management-flag-option="${escapeHtml(item.code)}">
          <span class="currency-management-flag-popover__card-flag" aria-hidden="true">
            <img class="currency-management-flag-popover__card-image" src="${escapeHtml(item.src)}" alt="" draggable="false" loading="eager" decoding="async" width="512" height="512">
          </span>
          <span class="currency-management-flag-popover__card-code">${escapeHtml(item.countryCode)}</span>
          <span class="currency-management-flag-popover__card-currency" data-taif-dropdown-label="true">${escapeHtml(item.currencyName)}</span>
        </button>
      `).join('');
    }

    function positionFlagPopover(){
      if(!flagPopover) return;
      const panelRect = panel.getBoundingClientRect();
      const triggerRect = flagTrigger.getBoundingClientRect();
      const panelStyle = window.getComputedStyle(panel);
      const panelPaddingBottom = parseFloat(panelStyle.paddingBottom || '0') || 0;
      const top = Math.max(0, triggerRect.top - panelRect.top - 1);
      const left = Math.max(0, triggerRect.left - panelRect.left - 1);
      const width = Math.max(180, triggerRect.width + 2);
      const bottomInset = Math.max(0, panelPaddingBottom);
      flagPopover.style.top = `${top}px`;
      flagPopover.style.left = `${left}px`;
      flagPopover.style.width = `${width}px`;
      flagPopover.style.right = 'auto';
      flagPopover.style.bottom = `${bottomInset}px`;
      flagPopover.style.height = 'auto';
      flagPopover.style.maxHeight = 'none';
    }

    function applyFlagSelection(nextFlagCode, { restoreTriggerFocus = true } = {}){
      manualSelection = true;
      syncTrigger(nextFlagCode);
      if(restoreTriggerFocus) commitController.markCommittedSelection();
      else commitController.clearCommittedSelection();
      suppressTriggerToggleUntil = Date.now() + 250;
      closeFlagPopover();
      if(restoreTriggerFocus){
        setTimeout(() => focusFlagTarget(flagTrigger), 0);
      }
    }

    function ensureFlagPopover(){
      if(flagPopover) return;
      flagPopover = document.createElement('div');
      flagPopover.className = 'currency-management-flag-popover';
      flagPopover.dataset.taifDropdownPopup = 'true';
      flagPopover.dataset.taifDropdownLayout = 'grid';
      flagPopover.dataset.taifInlinePicker = 'true';
      flagPopover.setAttribute('role', 'listbox');
      flagPopover.setAttribute('aria-label', 'اختيار العلم');
      flagPopover.hidden = true;
      flagPopover.innerHTML = `
        <div class="currency-management-flag-popover__search-shell">
          <div class="currency-management-search-wrap currency-management-flag-popover__search-wrap">
            <input class="currency-management-search-input currency-management-flag-popover__search-input" type="text" placeholder="ابحث بالكود أو اسم العملة" autocomplete="off" spellcheck="false">
            <button class="currency-management-search-clear currency-management-flag-popover__search-clear" type="button" data-taif-clear-control="true" aria-label="إغلاق أو مسح البحث">${createButtonIcon('close')}</button>
          </div>
        </div>
        <div class="currency-management-flag-popover__body">
          <div class="currency-management-flag-popover__grid"></div>
        </div>
      `;
      panel.appendChild(flagPopover);
      if(pickerApi) flagPopover.__taifInlinePickerApi = pickerApi;
      searchInput = flagPopover.querySelector('.currency-management-flag-popover__search-input');
      gridContainer = flagPopover.querySelector('.currency-management-flag-popover__grid');
      const clearSearchButton = flagPopover.querySelector('.currency-management-flag-popover__search-clear');
      const bodyScroller = flagPopover.querySelector('.currency-management-flag-popover__body');
      searchInput.addEventListener('input', () => {
        typeahead.reset();
        renderGrid(searchInput.value);
        if(bodyScroller) bodyScroller.scrollTop = 0;
      });
      searchInput.addEventListener('keydown', (event) => {
        if(event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
        if(event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return;
        event.preventDefault();
        focusFlagOption(event.key === 'ArrowUp' ? 'last' : 'first');
      });
      clearSearchButton.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        if(searchInput.value){
          searchInput.value = '';
          renderGrid('');
          if(bodyScroller) bodyScroller.scrollTop = 0;
          focusFlagTarget(searchInput);
          return;
        }
        closeFlagPopover();
      });
      gridContainer.addEventListener('mousedown', (event) => {
        const option = event.target.closest('[data-currency-management-flag-option]');
        if(option) event.preventDefault();
      });
      gridContainer.addEventListener('click', (event) => {
        const option = event.target.closest('[data-currency-management-flag-option]');
        if(!option) return;
        event.preventDefault();
        event.stopPropagation();
        applyFlagSelection(option.dataset.currencyManagementFlagOption, {
          restoreTriggerFocus: commitController.shouldRestoreTriggerFocusAfterSelection()
        });
      });
      gridContainer.addEventListener('keydown', (event) => {
        if(event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey) return;
        const activeOption = event.target instanceof Element ? event.target.closest('[data-currency-management-flag-option]') : null;
        if(!(activeOption instanceof HTMLButtonElement)) return;
        const optionButtons = getFlagOptionButtons();
        const currentIndex = optionButtons.indexOf(activeOption);
        if(currentIndex === -1) return;
        if(typeahead.handleKey(event.key, { currentIndex })){
          event.preventDefault();
        }
      });
    }

    function isFlagPopoverOpen(){
      return Boolean(flagPopover && !flagPopover.hidden);
    }

    function closeFlagPopover(){
      typeahead.reset();
      setInlinePopoverState({
        picker: flagPicker,
        popover: flagPopover,
        trigger: flagTrigger,
        isOpen: false
      });
    }

    function getFlagOptionButtons(){
      if(!gridContainer) return [];
      return Array.from(gridContainer.querySelectorAll('[data-currency-management-flag-option]')).filter((node) => node instanceof HTMLButtonElement && !node.disabled);
    }

    function focusFlagOptionIndex(targetIndex = 0, { scrollBehavior = 'auto', scrollBlock = 'nearest' } = {}){
      const optionsNodes = getFlagOptionButtons();
      if(!optionsNodes.length) return false;
      const normalizedIndex = Math.max(0, Math.min(optionsNodes.length - 1, Number(targetIndex) || 0));
      const targetOption = optionsNodes[normalizedIndex];
      if(!focusFlagTarget(targetOption)) return false;
      if(typeof targetOption.scrollIntoView === 'function'){
        try{
          targetOption.scrollIntoView({ block:scrollBlock, inline:'nearest', behavior:scrollBehavior });
        }catch{}
      }
      return true;
    }

    function focusFlagOption(direction = 'first'){
      const optionsNodes = getFlagOptionButtons();
      if(!optionsNodes.length) return false;
      const activeCode = getSelectedFlagCode();
      const activeIndex = optionsNodes.findIndex((node) => node.dataset.currencyManagementFlagOption === activeCode);
      if(direction === 'last') return focusFlagOptionIndex(optionsNodes.length - 1);
      if(direction === 'current') return focusFlagOptionIndex(activeIndex >= 0 ? activeIndex : 0);
      return focusFlagOptionIndex(0);
    }

    function openFlagPopover({ focusSearch = true } = {}){
      typeahead.reset();
      commitController.clearCommittedSelection();
      ensureFlagPopover();
      positionFlagPopover();
      setInlinePopoverState({
        picker: flagPicker,
        popover: flagPopover,
        trigger: flagTrigger,
        isOpen: true
      });
      if(searchInput) searchInput.value = '';
      renderGrid('');
      const bodyScroller = flagPopover.querySelector('.currency-management-flag-popover__body');
      if(bodyScroller) bodyScroller.scrollTop = 0;
      requestAnimationFrame(() => {
        if(!focusSearch && focusFlagOption('current')) return;
        focusFlagTarget(searchInput);
      });
    }

    function openForKeyboard(){
      openFlagPopover({ focusSearch: false });
      requestAnimationFrame(() => {
        focusFlagOption('current');
      });
    }

    bindInlinePopoverDismiss({
      modal,
      picker: flagPicker,
      trigger: flagTrigger,
      isOpen: isFlagPopoverOpen,
      closePopover: closeFlagPopover,
      scrollTargets: [scrollArea],
      registerCleanup,
      isInsidePopoverTarget: (target) => Boolean(target.closest('.currency-management-flag-popover'))
    });

    const onWindowResize = () => {
      if(!isFlagPopoverOpen()) return;
      positionFlagPopover();
    };
    window.addEventListener('resize', onWindowResize);
    if(typeof registerCleanup === 'function'){
      registerCleanup(() => window.removeEventListener('resize', onWindowResize));
    }

    const initialAutoCode = getAutoFlagCode();
    manualSelection = resolveStoredFlagCode(flagInput.value || '', getCurrentCurrencyCode()) !== initialAutoCode;
    syncTrigger(flagInput.value || initialAutoCode);

    flagTrigger.addEventListener('click', (event) => {
      event.preventDefault();
      if(Date.now() < suppressTriggerToggleUntil){
        event.stopPropagation();
        return;
      }
      if(isFlagPopoverOpen()) closeFlagPopover();
      else openFlagPopover();
    });
    flagTrigger.addEventListener('keydown', (event) => {
      if(event.defaultPrevented || event.isComposing || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
      if(Date.now() < suppressTriggerToggleUntil) return;
      if(event.key === 'ArrowDown' || event.key === 'ArrowUp'){
        event.preventDefault();
        if(!isFlagPopoverOpen()) openFlagPopover({ focusSearch: false });
        else requestAnimationFrame(() => focusFlagOption(event.key === 'ArrowUp' ? 'last' : 'first'));
        return;
      }
      if(event.key === ' ' || event.key === 'Spacebar'){
        event.preventDefault();
        if(isFlagPopoverOpen()) closeFlagPopover();
        else openFlagPopover();
        return;
      }
      if(typeahead.handleKey(event.key)){
        event.preventDefault();
      }
    });

    function bindAutoFlagSync(inputElement){
      if(!inputElement) return;
      const onAutoFlagSyncInput = () => {
        if(manualSelection) return;
        syncTrigger(getAutoFlagCode());
      };
      inputElement.addEventListener('input', onAutoFlagSyncInput);
      if(typeof registerCleanup === 'function'){
        registerCleanup(() => inputElement.removeEventListener('input', onAutoFlagSyncInput));
      }
    }

    bindAutoFlagSync(currencyCodeInput);
    bindAutoFlagSync(currencyNameInput);

    function setFlagValue(nextFlagCode, { manual = true, dispatchEvents = true } = {}){
      const previousValue = flagInput.value;
      manualSelection = Boolean(manual);
      syncTrigger(nextFlagCode);
      if(dispatchEvents && previousValue !== flagInput.value){
        try{ flagInput.dispatchEvent(new Event('input', { bubbles: true })); }catch{}
        try{ flagInput.dispatchEvent(new Event('change', { bubbles: true })); }catch{}
      }
      return flagInput.value;
    }

    pickerApi = {
      type: 'flag',
      getTrigger(){
        return flagTrigger;
      },
      isOpen: isFlagPopoverOpen,
      openForKeyboard,
      close: closeFlagPopover,
      focusActiveOption(){
        return focusFlagOption('current');
      },
      setValue(nextFlagCode, options = {}){
        return setFlagValue(nextFlagCode, options);
      },
      prepareKeyboardSelection: commitController.prepareKeyboardSelection,
      consumeCommittedSelection: commitController.consumeCommittedSelection,
      clearCommittedSelection: commitController.clearCommittedSelection
    };
    registerInlinePickerApi({
      picker: flagPicker,
      trigger: flagTrigger,
      getPopover: () => flagPopover,
      api: pickerApi,
      clearCommittedSelection: commitController.clearCommittedSelection,
      registerCleanup
    });

    return {
      close: closeFlagPopover,
      openForKeyboard,
      isOpen: isFlagPopoverOpen,
      getTrigger(){
        return flagTrigger;
      },
      focusActiveOption(){
        return focusFlagOption('current');
      },
      setValue(nextFlagCode, options = {}){
        return setFlagValue(nextFlagCode, options);
      }
    };
  }


  Object.assign(feature, {
    createButtonIcon, createSingleLineHeaderLabel, cleanupCounterpartToolbarPicker, cleanupTopbarAdaptiveFit, createCounterpartToolbarMarkup, buildToolbarButtonsMarkup, mountSingleLineTextFit, mountTopbarAdaptiveFit, mountCounterpartToolbarPicker, getSelectedRow, getMainFilterText, rowMatchesMainFilter, suppressRowInteractions, hasActiveCurrencyModal, isRowInteractionSuppressed, openEditorForCode, updateSelectionUi, clearSelection, bindExternalSelectionClear, applyMainSearchFilter, refreshView, openModal, buttonMarkup, iconButtonMarkup, bindModalActionButtons, bindModalCloseButtons, setInlinePopoverState, bindInlinePopoverDismiss, createFlagPickerMarkup, createChoicePickerMarkup, mountChoicePicker, mountFlagPicker
  });
})();
