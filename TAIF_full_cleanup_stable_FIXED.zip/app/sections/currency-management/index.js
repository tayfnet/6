(()=>{
  /*
   * TAIF Currency feature view controller.
   * Main grid rendering, single/bulk editors, and the stable public API for dependent sections.
   */
  const TAIF = window.TAIF;
  const { escapeHtml, runCleanupSlot, clearTimerSlot, wrapControlTextMarkup, normalizeLookupText } = TAIF.core.utils;
  const feature = TAIF.currencyManagementFeature || (TAIF.currencyManagementFeature = {});
  const { runtime, PRICE_UPDATE_MODE_OPTIONS, DECIMAL_PLACES_OPTIONS, SINGLE_CURRENCY_FORM_PICKERS, SINGLE_EDITOR_MODAL_OPTIONS, BULK_EDITOR_TITLE, LEGACY_ZERO_DROP_MODE = 'legacy-zero-drop', LEGACY_ZERO_DROP_SHIFT = 2, createDefaultState, toNumber, getPositiveRate, clampDecimals, normalizeCode, fallbackFlag, clearBrowserTextSelection, bindTextSelectionGuard, sanitizeCurrency, normalizeStoredNumericText, formatCurrencyNumericDisplay, getCounterpartCurrencyFromState, getCounterpartCurrency, getCounterpartDisplayName, getCounterpartHeaderText, getCounterpartRatioHeaderText, getDollarHeaderText, sanitizeState, readState, writeState, resetState, formatDynamic, formatManagementCellValue, resolveStoredFlagCode, createFlagImageMarkup, computeRows, renderPairBadgeMarkup, getUsdPairDirectionOptions, getCalculationMethodOptions, getUsdPairFieldLabel, getDerivedPairFieldLabel, getUsdAgainstCounterpartQuote, setUsdAgainstCounterpartQuote, setCounterpartCrossQuote, auditState, mountSmartNumericInputs, applySmartNumericFormatting } = feature;
  const { dismissOverlays, showToast } = feature;
  const { createButtonIcon, cleanupCounterpartToolbarPicker, cleanupTopbarAdaptiveFit, buildToolbarButtonsMarkup, mountSingleLineTextFit, mountTopbarAdaptiveFit, mountCounterpartToolbarPicker, getSelectedRow, getMainFilterText, rowMatchesMainFilter, hasActiveCurrencyModal, isRowInteractionSuppressed, openEditorForCode, updateSelectionUi, clearSelection, bindExternalSelectionClear, applyMainSearchFilter, refreshView, openModal, buttonMarkup, iconButtonMarkup, bindModalActionButtons, bindModalCloseButtons, createFlagPickerMarkup, createChoicePickerMarkup, mountChoicePicker, mountFlagPicker, createSingleLineHeaderLabel } = feature;
  function cleanupMainHeaderFit(){
    runCleanupSlot(runtime, 'mainHeaderFitCleanup');
  }

  function cleanupBulkHeaderFit(){
    runCleanupSlot(runtime, 'bulkHeaderFitCleanup');
  }

  function getMoveAvailability(state, code){
    const currencies = sanitizeState(state).currencies;
    const index = currencies.findIndex((currency) => currency.code === code);
    if(index <= 0 || code === 'USD') return { canMoveUp: false, canMoveDown: false };

    const previousNonUsd = currencies.slice(0, index).reverse().find((currency) => currency.code !== 'USD');
    const nextNonUsd = currencies.slice(index + 1).find((currency) => currency.code !== 'USD');

    return {
      canMoveUp: Boolean(previousNonUsd),
      canMoveDown: Boolean(nextNonUsd)
    };
  }

  function resolveUsdConventionValue(currency = null){
    if(currency && currency.usdConvention && currency.usdConvention !== 'identity') return currency.usdConvention === 'usd-base' ? 'usd-base' : 'currency-base';
    return currency && currency.method === 'divide' ? 'usd-base' : 'currency-base';
  }

  function resolveCurrencyMethodPickerValue(currency = null){
    return currency && currency.rateMode === LEGACY_ZERO_DROP_MODE
      ? LEGACY_ZERO_DROP_MODE
      : resolveUsdConventionValue(currency);
  }

  function getCurrencyMethodPickerOptions(currencyCode = '', { allowLegacyZeroDropOption = true } = {}){
    if(typeof getCalculationMethodOptions === 'function'){
      return getCalculationMethodOptions(currencyCode, { includeLegacyZeroDrop: allowLegacyZeroDropOption });
    }
    const options = [
      ...getUsdPairDirectionOptions(currencyCode)
    ];
    if(allowLegacyZeroDropOption){
      options.push({ value: LEGACY_ZERO_DROP_MODE, label: 'حذف اصفار عملة قديمة' });
    }
    return options;
  }

  function formatCurrencyRateInputValue(value, rawText = '', decimals = 0){
    const normalizedRawText = normalizeStoredNumericText(rawText, { allowDecimal: true, allowNegative: true });
    const numericValue = toNumber(value, Number.NaN);
    const configuredDecimals = clampDecimals(decimals);
    const hasFraction = Number.isFinite(numericValue) && Math.abs(numericValue - Math.trunc(numericValue)) > 0.0000005;
    const rawNumericValue = normalizedRawText ? toNumber(normalizedRawText, Number.NaN) : Number.NaN;
    const rawMismatchesValue = normalizedRawText && Number.isFinite(rawNumericValue) && Number.isFinite(numericValue)
      ? Math.abs(rawNumericValue - numericValue) > 0.0000005
      : false;
    const shouldRelaxConfiguredDecimals = configuredDecimals === 0 && hasFraction && !normalizedRawText;
    const shouldDropStaleRawText = rawMismatchesValue;
    const displayRawText = shouldDropStaleRawText ? '' : normalizedRawText;
    const respectConfiguredDecimals = !(shouldRelaxConfiguredDecimals || shouldDropStaleRawText);

    if(typeof formatCurrencyNumericDisplay === 'function'){
      return formatCurrencyNumericDisplay(numericValue, {
        rawText: displayRawText,
        decimals: configuredDecimals,
        maxAutoDecimals: 6,
        mode: 'rate',
        fallback: '',
        respectConfiguredDecimals
      });
    }
    return displayRawText || formatDynamic(numericValue, 6);
  }

  function getLegacySourceCurrencies(stateInput, { currentCode = '' } = {}){
    const safeCurrentCode = normalizeCode(currentCode);
    return sanitizeState(stateInput).currencies.filter((currency) => {
      const code = normalizeCode(currency && currency.code);
      if(!code || code === safeCurrentCode || code === 'USD') return false;
      return currency.rateMode !== LEGACY_ZERO_DROP_MODE;
    });
  }

  function buildLegacySourceOptions(stateInput, { currentCode = '' } = {}){
    const options = getLegacySourceCurrencies(stateInput, { currentCode }).map((currency) => ({
      value: currency.code,
      label: currency.name,
      flag: resolveStoredFlagCode(currency?.flag, currency?.code) || fallbackFlag(currency?.code),
      richType: 'currency-with-flag'
    }));
    return options.length ? options : [{ value: '', label: 'لا توجد عملة قديمة متاحة' }];
  }

  function resolveLegacySourceCode(stateInput, currency = null, { currentCode = '' } = {}){
    const options = buildLegacySourceOptions(stateInput, { currentCode });
    const requestedCode = normalizeCode(currency && currency.legacySourceCode);
    if(options.some((option) => option.value === requestedCode)) return requestedCode;
    return options[0] && options[0].value ? options[0].value : '';
  }

  function getLegacySourceCurrency(stateInput, sourceCode = ''){
    const safeCode = normalizeCode(sourceCode);
    if(!safeCode) return null;
    return sanitizeState(stateInput).currencies.find((currency) => currency.code === safeCode) || null;
  }

  function buildLegacyZeroDropNote(sourceCurrency = null){
    const divisor = 10 ** LEGACY_ZERO_DROP_SHIFT;
    if(!sourceCurrency){
      return `اختر العملة القديمة التي سيتم ربط هذه العملة بها، وسيتم حذف ${LEGACY_ZERO_DROP_SHIFT} أصفار من أسعار الشراء والمبيع مع تثبيت السعر المباشر بين العملتين بلا فرق شراء/مبيع وفق معامل 1 جديد = ${divisor} قديم.`;
    }
    const sourceLabel = `${sourceCurrency.name} (${sourceCurrency.code})`;
    return `سيتم ربط هذه العملة بالعملة ${sourceLabel} مع حذف ${LEGACY_ZERO_DROP_SHIFT} أصفار من أسعار الشراء والمبيع. السعر المباشر بين العملتين سيبقى ثابتًا بلا فرق شراء/مبيع وفق معامل 1 جديد = ${divisor} قديم، وأي تعديل سعري في أحد الطرفين سينعكس تلقائيًا على الطرف الآخر.`;
  }

  function applyLegacySourceQuotePreview(modal, sourceCurrency, { overwrite = false } = {}){
    if(!(modal instanceof HTMLElement) || !sourceCurrency) return;
    const ratioBuyInput = modal.querySelector('#currency-management-currency-ratio-buy');
    const ratioSellInput = modal.querySelector('#currency-management-currency-ratio-sell');
    const decimals = clampDecimals(modal.querySelector('#currency-management-currency-decimals')?.value || sourceCurrency.decimals || 0);
    const divisor = 10 ** LEGACY_ZERO_DROP_SHIFT;
    const nextBuy = getPositiveRate(sourceCurrency.ratioBuy, 1) / divisor;
    const nextSell = getPositiveRate(sourceCurrency.ratioSell, nextBuy) / divisor;

    if(ratioBuyInput instanceof HTMLInputElement){
      const currentText = normalizeStoredNumericText(ratioBuyInput.value);
      if(overwrite || !currentText){
        ratioBuyInput.value = formatCurrencyRateInputValue(nextBuy, '', decimals);
      }
    }
    if(ratioSellInput instanceof HTMLInputElement){
      const currentText = normalizeStoredNumericText(ratioSellInput.value);
      if(overwrite || !currentText){
        ratioSellInput.value = formatCurrencyRateInputValue(nextSell, '', decimals);
      }
    }
  }

  function refreshLegacyLinkSection(modal, { overwritePreview = false } = {}){
    if(!(modal instanceof HTMLElement)) return;
    const methodInput = modal.querySelector('#currency-management-currency-method');
    const legacyRows = Array.from(modal.querySelectorAll('[data-currency-management-legacy-link-row]'));
    const legacyCompactWrap = modal.querySelector('[data-currency-management-method-legacy-compact]');
    const legacySourceInput = modal.querySelector('#currency-management-currency-legacy-source');
    const legacyNote = modal.querySelector('[data-currency-management-legacy-note]');
    const isLegacyMode = methodInput instanceof HTMLInputElement && methodInput.value === LEGACY_ZERO_DROP_MODE;

    legacyRows.forEach((row) => {
      if(!(row instanceof HTMLElement)) return;
      row.hidden = !isLegacyMode;
      row.style.display = isLegacyMode ? '' : 'none';
      row.setAttribute('aria-hidden', isLegacyMode ? 'false' : 'true');
    });

    if(legacyCompactWrap) legacyCompactWrap.classList.toggle('is-legacy-mode', Boolean(isLegacyMode));
    if(!isLegacyMode) return;

    const sourceCurrency = getLegacySourceCurrency(readState(), legacySourceInput?.value || '');
    if(legacyNote) legacyNote.textContent = buildLegacyZeroDropNote(sourceCurrency);
    if(sourceCurrency) applyLegacySourceQuotePreview(modal, sourceCurrency, { overwrite: overwritePreview });
  }

  const CURRENCY_NAME_LIBRARY_ALIASES = Object.freeze({
    USD:'الدولار الامريكي دولار امريكي امريكا الولايات المتحده',
    EUR:'اليورو يورو العمله الاوروبيه الاتحاد الاوروبي',
    TRY:'الليرة التركية الليره التركيه الليرة التركي الليره التركي ليرة تركية ليره تركيه',
    SAR:'الريال السعودي ريال سعودي',
    AED:'الدرهم الاماراتي درهم اماراتي إماراتي اماراتي',
    JOD:'الدينار الاردني دينار اردني',
    GBP:'الجنيه البريطاني الجنيه الاسترليني الجنيه الإسترليني جنيه استرليني جنيه إسترليني',
    CHF:'الفرنك السويسري فرنك سويسري',
    EGP:'الجنيه المصري جنيه مصري',
    KWD:'الدينار الكويتي دينار كويتي',
    QAR:'الريال القطري ريال قطري',
    IQD:'الدينار العراقي دينار عراقي',
    SYP:'الليرة السورية الليره السوريه الليرة السوري الليره السوري ليرة سورية',
    LBP:'الليرة اللبنانية الليره اللبنانيه ليرة لبنانية',
    KRW:'الوون الكوري وون كوري كوريا الجنوبية',
    XOF:'فرنك غرب افريقيا cfa غرب افريقيا',
    XAF:'فرنك وسط افريقيا cfa وسط افريقيا',
    MAD:'الدرهم المغربي درهم مغربي',
    TND:'الدينار التونسي دينار تونسي',
    DZD:'الدينار الجزائري دينار جزائري',
    LYD:'الدينار الليبي دينار ليبي',
    OMR:'الريال العماني ريال عماني',
    BHD:'الدينار البحريني دينار بحريني',
    YER:'الريال اليمني ريال يمني',
    SDG:'الجنيه السوداني جنيه سوداني',
    RUB:'الروبل الروسي روبل روسي',
    CNY:'اليوان الصيني يوان صيني',
    JPY:'الين الياباني ين ياباني',
    CAD:'الدولار الكندي دولار كندي',
    AUD:'الدولار الاسترالي دولار استرالي',
    NZD:'الدولار النيوزيلندي دولار نيوزيلندي'
  });

  const CURRENCY_NAME_LIBRARY_CURRENCY_BASE_CODES = Object.freeze([
    'EUR',
    'GBP',
    'AUD',
    'NZD',
    'JOD',
    'KWD',
    'BHD',
    'OMR'
  ]);

  function getCurrencyLibraryUsdConvention(code = ''){
    const safeCode = normalizeCode(code);
    if(!safeCode || safeCode === 'USD') return 'identity';
    return CURRENCY_NAME_LIBRARY_CURRENCY_BASE_CODES.includes(safeCode) ? 'currency-base' : 'usd-base';
  }

  function normalizeCurrencyLibraryQuote(rawBuy, rawSell, fallback = 1){
    const bid = getPositiveRate(rawBuy, fallback);
    const ask = getPositiveRate(rawSell, bid);
    return bid <= ask
      ? { bid, ask }
      : { bid: ask, ask: bid };
  }

  function convertCurrencyLibraryQuote(rawBuy, rawSell, sourceConvention, targetConvention, fallback = 1){
    const safeSource = sourceConvention === 'usd-base' ? 'usd-base' : 'currency-base';
    const safeTarget = targetConvention === 'usd-base' ? 'usd-base' : 'currency-base';
    const normalizedSource = normalizeCurrencyLibraryQuote(rawBuy, rawSell, fallback);
    if(safeSource === safeTarget) return normalizedSource;
    return normalizeCurrencyLibraryQuote(
      1 / getPositiveRate(normalizedSource.ask, fallback),
      1 / getPositiveRate(normalizedSource.bid, fallback),
      fallback
    );
  }


  function normalizeCurrencyLookupText(value){
    return typeof normalizeLookupText === 'function'
      ? normalizeLookupText(value)
      : String(value ?? '').trim().toLowerCase();
  }


  function buildCurrencyNameLibrary(stateInput = readState()){
    const flagsAsset = TAIF && TAIF.assets && TAIF.assets.flags;
    const currencyToFlagCode = flagsAsset && flagsAsset.currencyToFlagCode && typeof flagsAsset.currencyToFlagCode === 'object'
      ? flagsAsset.currencyToFlagCode
      : {};

    const stateCurrencyMap = new Map(
      sanitizeState(stateInput).currencies
        .map((currency, index) => sanitizeCurrency(currency, index))
        .filter(Boolean)
        .map((currency) => [normalizeCode(currency.code), currency])
    );

    const defaultState = createDefaultState();
    const defaultCurrencyMap = new Map(
      ((defaultState && Array.isArray(defaultState.currencies)) ? defaultState.currencies : [])
        .map((currency, index) => sanitizeCurrency(currency, index))
        .filter(Boolean)
        .map((currency) => [normalizeCode(currency.code), currency])
    );

    return Object.keys(currencyToFlagCode)
      .map((rawCode) => normalizeCode(rawCode))
      .filter(Boolean)
      .sort((a, b) => a.localeCompare(b, 'en'))
      .map((code) => {
        const currentCurrency = stateCurrencyMap.get(code) || null;
        const defaultCurrency = defaultCurrencyMap.get(code) || null;
        const templateCurrency = currentCurrency || defaultCurrency || null;
        const flagCode = resolveStoredFlagCode(currencyToFlagCode[code] || templateCurrency?.flag || '', code);
        const flagMeta = flagsAsset && typeof flagsAsset.getFlagMeta === 'function'
          ? flagsAsset.getFlagMeta(flagCode)
          : null;
        const officialName = String(flagMeta && flagMeta.currencyName || currentCurrency && currentCurrency.name || defaultCurrency && defaultCurrency.name || code).trim() || code;
        const aliasText = String(CURRENCY_NAME_LIBRARY_ALIASES[code] || '').trim();
        const targetUsdConvention = getCurrencyLibraryUsdConvention(code);
        const sourceUsdConvention = templateCurrency ? resolveUsdConventionValue(templateCurrency) : targetUsdConvention;
        const methodValue = targetUsdConvention === 'usd-base' ? 'usd-base' : 'currency-base';
        const decimals = clampDecimals((currentCurrency && currentCurrency.decimals) ?? (defaultCurrency && defaultCurrency.decimals) ?? 0);
        const resolvedQuote = code === 'USD'
          ? { bid: 1, ask: 1 }
          : convertCurrencyLibraryQuote(
              templateCurrency && templateCurrency.ratioBuy,
              templateCurrency && templateCurrency.ratioSell,
              sourceUsdConvention,
              targetUsdConvention,
              1
            );
        const ratioBuy = resolvedQuote.bid;
        const ratioSell = resolvedQuote.ask;
        const priceUpdateMode = (currentCurrency && currentCurrency.priceUpdateMode) === 'internet'
          || (defaultCurrency && defaultCurrency.priceUpdateMode) === 'internet'
          ? 'internet'
          : 'manual';
        const codeCountry = String(flagMeta && flagMeta.countryCode || code.slice(0, 2)).trim().toUpperCase();
        const searchText = normalizeCurrencyLookupText([
          code,
          officialName,
          currentCurrency && currentCurrency.name,
          defaultCurrency && defaultCurrency.name,
          codeCountry,
          aliasText
        ].filter(Boolean).join(' '));
        return Object.freeze({
          code,
          flag: flagCode,
          countryCode: codeCountry,
          name: officialName,
          methodValue,
          priceUpdateMode,
          decimals,
          ratioBuy,
          ratioSell,
          ratioBuyText: formatCurrencyRateInputValue(ratioBuy, '', decimals),
          ratioSellText: formatCurrencyRateInputValue(ratioSell, '', decimals),
          methodPreview: methodValue === 'usd-base' ? `USD/${code}` : `${code}/USD`,
          methodTag: methodValue === 'usd-base' ? 'تقسيم' : 'ضرب',
          searchText,
          nameNormalized: normalizeCurrencyLookupText(officialName)
        });
      });
  }

  function scoreCurrencyNameLibraryEntry(entry, normalizedQuery){
    if(!entry || !normalizedQuery) return 0;
    if(entry.code === normalizedQuery.toUpperCase()) return 14000;

    let score = 0;
    if(entry.nameNormalized === normalizedQuery) score = Math.max(score, 12000);
    if(entry.searchText === normalizedQuery) score = Math.max(score, 11000);
    if(entry.nameNormalized.startsWith(normalizedQuery)) score = Math.max(score, 9800);
    if(entry.searchText.startsWith(normalizedQuery)) score = Math.max(score, 9200);
    if(entry.nameNormalized.includes(normalizedQuery)) score = Math.max(score, 8600);
    if(entry.searchText.includes(normalizedQuery)) score = Math.max(score, 7600);

    const queryTokens = normalizedQuery.split(' ').filter(Boolean);
    const searchTokens = entry.searchText.split(' ').filter(Boolean);
    let directMatches = 0;
    let softMatches = 0;

    queryTokens.forEach((token) => {
      if(searchTokens.includes(token)){
        directMatches += 1;
        return;
      }
      if(token.length >= 3 && searchTokens.some((part) => part.includes(token) || token.includes(part))){
        softMatches += 1;
      }
    });

    score += directMatches * 260;
    score += softMatches * 140;
    if(queryTokens.length && directMatches === queryTokens.length) score += 650;
    if(queryTokens.length && (directMatches + softMatches) === queryTokens.length) score += 220;
    return score;
  }

  function searchCurrencyNameLibrary(query, library){
    const normalizedQuery = normalizeCurrencyLookupText(query);
    if(!normalizedQuery) return [];
    return (Array.isArray(library) ? library : [])
      .map((entry, index) => ({ entry, index, score: scoreCurrencyNameLibraryEntry(entry, normalizedQuery) }))
      .filter((item) => item.score > 0)
      .sort((a, b) => b.score - a.score || a.index - b.index)
      .slice(0, 8)
      .map((item) => item.entry);
  }

  function createCurrencyNameSuggestionMarkup(entry, index, { active = false } = {}){
    if(!entry) return '';
    return `
      <button class="currency-management-name-autocomplete__option${active ? ' is-active' : ''}" type="button" data-currency-management-name-suggestion-index="${String(index)}" data-currency-management-name-suggestion-code="${escapeHtml(entry.code)}">
        <span class="currency-management-name-autocomplete__option-flag" aria-hidden="true">${createFlagImageMarkup({ code: entry.code, flag: entry.flag }, { className: 'currency-management-name-autocomplete__option-flag-image' })}</span>
        <span class="currency-management-name-autocomplete__option-text">
          <span class="currency-management-name-autocomplete__option-head">
            <strong class="currency-management-name-autocomplete__option-name">${escapeHtml(entry.name)}</strong>
            <span class="currency-management-name-autocomplete__option-code">${escapeHtml(entry.code)}</span>
          </span>
          <span class="currency-management-name-autocomplete__option-meta">${escapeHtml(entry.methodPreview)} • ${escapeHtml(entry.methodTag)}</span>
        </span>
      </button>
    `;
  }

  function mountCurrencyNameLibraryAutocomplete({ modal, registerCleanup = null, allowLegacyZeroDropOption = true, enabled = false } = {}){
    if(!enabled) return { close(){} };
    if(!(modal instanceof HTMLElement)) return { close(){} };

    const host = modal.querySelector('[data-currency-management-name-autocomplete]');
    const popover = modal.querySelector('[data-currency-management-name-autocomplete-popover]');
    const nameInput = modal.querySelector('#currency-management-currency-name');
    const codeInput = modal.querySelector('#currency-management-currency-code');
    const ratioBuyInput = modal.querySelector('#currency-management-currency-ratio-buy');
    const ratioSellInput = modal.querySelector('#currency-management-currency-ratio-sell');
    const flagPicker = modal.querySelector('[data-currency-management-flag-picker]');
    const methodPicker = modal.querySelector('[data-currency-management-method-picker]');
    const priceModePicker = modal.querySelector('[data-currency-management-price-update-mode-picker]');
    const decimalsPicker = modal.querySelector('[data-currency-management-decimals-picker]');
    if(!(host instanceof HTMLElement) || !(popover instanceof HTMLElement) || !(nameInput instanceof HTMLInputElement) || !(codeInput instanceof HTMLInputElement)){
      return { close(){} };
    }

    const library = buildCurrencyNameLibrary(readState());
    let visibleItems = [];
    let activeIndex = -1;
    let blurTimer = 0;

    function getInlinePickerApi(element){
      return element && element.__taifInlinePickerApi && typeof element.__taifInlinePickerApi === 'object'
        ? element.__taifInlinePickerApi
        : null;
    }

    function isOpen(){
      return !popover.hidden;
    }

    function closePopover(){
      popover.hidden = true;
      popover.innerHTML = '';
      host.classList.remove('is-open');
      visibleItems = [];
      activeIndex = -1;
    }

    function renderVisibleItems(){
      if(!visibleItems.length){
        closePopover();
        return;
      }
      popover.innerHTML = visibleItems.map((entry, index) => createCurrencyNameSuggestionMarkup(entry, index, { active: index === activeIndex })).join('');
      popover.hidden = false;
      host.classList.add('is-open');
    }

    function openWithResults(items){
      visibleItems = Array.isArray(items) ? items : [];
      activeIndex = visibleItems.length ? 0 : -1;
      renderVisibleItems();
    }

    function updateResults(){
      const nextResults = searchCurrencyNameLibrary(nameInput.value, library);
      if(!nextResults.length){
        closePopover();
        return;
      }
      openWithResults(nextResults);
    }

    function syncActiveOption(nextIndex){
      if(!visibleItems.length) return;
      activeIndex = Math.max(0, Math.min(visibleItems.length - 1, Number(nextIndex) || 0));
      renderVisibleItems();
      const activeButton = popover.querySelector(`[data-currency-management-name-suggestion-index="${String(activeIndex)}"]`);
      if(activeButton && typeof activeButton.scrollIntoView === 'function'){
        try{ activeButton.scrollIntoView({ block:'nearest', inline:'nearest', behavior:'auto' }); }catch{}
      }
    }

    function applyRateTemplate(input, valueText){
      if(!(input instanceof HTMLInputElement)) return;
      input.value = valueText;
      if(typeof applySmartNumericFormatting === 'function'){
        applySmartNumericFormatting(input, {
          preserveCaret: false,
          preserveTrailingDecimal: false,
          allowDecimal: true,
          allowNegative: false
        });
      }
      try{ input.dispatchEvent(new Event('input', { bubbles: true })); }catch{}
      try{ input.dispatchEvent(new Event('change', { bubbles: true })); }catch{}
    }

    function applySelection(entry){
      if(!entry) return;
      nameInput.value = entry.name;
      try{ nameInput.dispatchEvent(new Event('input', { bubbles: true })); }catch{}
      try{ nameInput.dispatchEvent(new Event('change', { bubbles: true })); }catch{}

      if(!codeInput.disabled){
        codeInput.value = entry.code;
        try{ codeInput.dispatchEvent(new Event('input', { bubbles: true })); }catch{}
        try{ codeInput.dispatchEvent(new Event('change', { bubbles: true })); }catch{}
      }

      const flagApi = getInlinePickerApi(flagPicker);
      if(flagApi && typeof flagApi.setValue === 'function'){
        flagApi.setValue(entry.flag, { manual:true, dispatchEvents:false });
      }

      const methodApi = getInlinePickerApi(methodPicker);
      const methodOptions = getCurrencyMethodPickerOptions(entry.code, { allowLegacyZeroDropOption });
      if(methodApi && typeof methodApi.setOptions === 'function'){
        methodApi.setOptions(methodOptions, {
          preserveValue: false,
          preferredValue: entry.methodValue,
          dispatchEvents: true
        });
      }else if(methodApi && typeof methodApi.setValue === 'function'){
        methodApi.setValue(entry.methodValue, { dispatchEvents:true });
      }

      const priceModeApi = getInlinePickerApi(priceModePicker);
      if(priceModeApi && typeof priceModeApi.setValue === 'function'){
        priceModeApi.setValue(entry.priceUpdateMode, { dispatchEvents:true });
      }

      const decimalsApi = getInlinePickerApi(decimalsPicker);
      if(decimalsApi && typeof decimalsApi.setValue === 'function'){
        decimalsApi.setValue(String(entry.decimals), { dispatchEvents:true });
      }

      applyRateTemplate(ratioBuyInput, entry.ratioBuyText);
      applyRateTemplate(ratioSellInput, entry.ratioSellText);
      refreshSingleCurrencyNumericInputs(modal);
      refreshLegacyLinkSection(modal, { overwritePreview:false });
      closePopover();
      try{ nameInput.focus({ preventScroll:true }); }catch{}
    }

    const handleInput = () => {
      if(blurTimer){
        clearTimeout(blurTimer);
        blurTimer = 0;
      }
      updateResults();
    };

    const handleFocus = () => {
      if(nameInput.value.trim()) updateResults();
    };

    const handleBlur = () => {
      blurTimer = window.setTimeout(() => {
        closePopover();
      }, 120);
    };

    const handleKeyDown = (event) => {
      if(event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey) return;
      if((event.key === 'ArrowDown' || event.key === 'ArrowUp') && !isOpen()){
        updateResults();
      }
      if(!isOpen() || !visibleItems.length) return;
      if(event.key === 'ArrowDown'){
        event.preventDefault();
        syncActiveOption(activeIndex + 1);
        return;
      }
      if(event.key === 'ArrowUp'){
        event.preventDefault();
        syncActiveOption(activeIndex - 1);
        return;
      }
      if(event.key === 'Enter' || event.key === 'NumpadEnter'){
        event.preventDefault();
        applySelection(visibleItems[Math.max(0, activeIndex)] || visibleItems[0]);
        return;
      }
      if(event.key === 'Escape'){
        event.preventDefault();
        closePopover();
      }
    };

    const handlePopoverPointerDown = (event) => {
      const option = event.target instanceof Element ? event.target.closest('[data-currency-management-name-suggestion-index]') : null;
      if(option) event.preventDefault();
    };

    const handlePopoverClick = (event) => {
      const option = event.target instanceof Element ? event.target.closest('[data-currency-management-name-suggestion-index]') : null;
      if(!option) return;
      event.preventDefault();
      const index = Number(option.dataset.currencyManagementNameSuggestionIndex);
      if(Number.isFinite(index) && visibleItems[index]) applySelection(visibleItems[index]);
    };

    const handleModalPointerDownCapture = (event) => {
      const target = event.target instanceof Element ? event.target : null;
      if(!target) return;
      if(target === nameInput || host.contains(target)) return;
      closePopover();
    };

    nameInput.addEventListener('input', handleInput);
    nameInput.addEventListener('focus', handleFocus);
    nameInput.addEventListener('blur', handleBlur);
    nameInput.addEventListener('keydown', handleKeyDown);
    popover.addEventListener('mousedown', handlePopoverPointerDown);
    popover.addEventListener('click', handlePopoverClick);
    modal.addEventListener('pointerdown', handleModalPointerDownCapture, true);

    if(typeof registerCleanup === 'function'){
      registerCleanup(() => {
        if(blurTimer){
          clearTimeout(blurTimer);
          blurTimer = 0;
        }
        nameInput.removeEventListener('input', handleInput);
        nameInput.removeEventListener('focus', handleFocus);
        nameInput.removeEventListener('blur', handleBlur);
        nameInput.removeEventListener('keydown', handleKeyDown);
        popover.removeEventListener('mousedown', handlePopoverPointerDown);
        popover.removeEventListener('click', handlePopoverClick);
        modal.removeEventListener('pointerdown', handleModalPointerDownCapture, true);
      });
    }

    return {
      close: closePopover
    };
  }

  // ---------------------------------------------------------------------------
  // Main render
  // ---------------------------------------------------------------------------
  function renderCurrencyManagement(panel){
    runtime.panel = panel;
    bindTextSelectionGuard();
    clearBrowserTextSelection();
    bindExternalSelectionClear();
    cleanupCounterpartToolbarPicker();
    cleanupTopbarAdaptiveFit();
    cleanupMainHeaderFit();
    const state = readState();
    const rows = computeRows(state);
    const counterpart = getCounterpartCurrencyFromState(state);
    const counterpartHeaderBuyLabel = createSingleLineHeaderLabel(getCounterpartHeaderText(counterpart, 'buy'), { className: 'taif-singleline-fit--management', min: 10.2, max: 13.2, step: .2, minScale: .94 });
    const counterpartHeaderSellLabel = createSingleLineHeaderLabel(getCounterpartHeaderText(counterpart, 'sell'), { className: 'taif-singleline-fit--management', min: 10.2, max: 13.2, step: .2, minScale: .94 });
    const dollarHeaderBuyLabel = createSingleLineHeaderLabel(getDollarHeaderText('buy'), { className: 'taif-singleline-fit--management', min: 10.2, max: 13.2, step: .2, minScale: .94 });
    const dollarHeaderSellLabel = createSingleLineHeaderLabel(getDollarHeaderText('sell'), { className: 'taif-singleline-fit--management', min: 10.2, max: 13.2, step: .2, minScale: .94 });
    const selectedRow = getSelectedRow(rows);
    const filterText = getMainFilterText();
    const hasSelectedRowVisible = selectedRow && rowMatchesMainFilter(selectedRow, filterText);

    if(selectedRow && !hasSelectedRowVisible){
      runtime.selectedCode = null;
    }

    panel.innerHTML = `
      <div class="currency-management-shell">
        <section class="currency-management-layout" aria-label="جدول العملات">
          <div class="currency-management-topbar" aria-label="شريط أدوات إدارة العملات">
            <div class="currency-management-topbar-search">
              <div class="currency-management-search-wrap">
                <input id="currency-management-search-input" class="currency-management-search-input" type="text" placeholder="ابحث بالكود أو اسم العملة" value="${escapeHtml(runtime.filter || '')}">
                <button id="currency-management-search-clear" class="currency-management-search-clear" type="button" data-taif-clear-control="true" aria-label="مسح البحث" ${runtime.filter ? '' : 'hidden'}>${createButtonIcon('close')}</button>
              </div>
            </div>
            <div class="currency-management-topbar-tools currency-management-toolbar" role="toolbar" aria-label="أدوات إدارة العملات">
              ${buildToolbarButtonsMarkup(state)}
            </div>
          </div>


          <div class="currency-management-table currency-management-table--split-scroll">
            <div class="currency-management-headrow currency-management-headrow--split-scroll" aria-hidden="true">
              <div></div>
              <div>${createSingleLineHeaderLabel('العلم', { className: 'taif-singleline-fit--management-simple', min: 11.2, max: 13.2, step: .2, minScale: .96 })}</div>
              <div>${createSingleLineHeaderLabel('الكود', { className: 'taif-singleline-fit--management-simple', min: 11.2, max: 13.2, step: .2, minScale: .96 })}</div>
              <div>${createSingleLineHeaderLabel('اسم العملة', { className: 'taif-singleline-fit--management-simple', min: 11, max: 13.2, step: .2, minScale: .95 })}</div>
              <div>${createSingleLineHeaderLabel('أزواج العملات', { className: 'taif-singleline-fit--management-simple', min: 10.8, max: 13.2, step: .2, minScale: .94 })}</div>
              <div>${counterpartHeaderBuyLabel}</div>
              <div>${counterpartHeaderSellLabel}</div>
              <div>${createSingleLineHeaderLabel('السعر الوسطي', { className: 'taif-singleline-fit--management-mid', min: 11, max: 13.2, step: .2, minScale: .95 })}</div>
              <div>${dollarHeaderBuyLabel}</div>
              <div>${dollarHeaderSellLabel}</div>
              <div>${createSingleLineHeaderLabel('إجراءات', { className: 'taif-singleline-fit--management-simple', min: 11, max: 13.2, step: .2, minScale: .96 })}</div>
            </div>
            <div class="currency-management-scroll currency-management-scroll--split-scroll">
              <div class="currency-management-scroll-inner currency-management-scroll-inner--split-scroll">
                ${rows.map((row) => {
                  const move = getMoveAvailability(state, row.code);
                  const isSelected = runtime.selectedCode === row.code;
                  const isVisible = rowMatchesMainFilter(row, filterText);
                  const searchText = `${row.code} ${row.name} ${row.usdPairLabel || row.usdPairId || ''}`.toUpperCase();
                  return `
                    <div class="currency-management-row${row.isUsd ? ' currency-management-row--usd' : ''}${isSelected ? ' currency-management-row--selected' : ''}${isVisible ? '' : ' currency-management-row--hidden'}" data-code="${row.code}" data-search="${escapeHtml(searchText)}">
                      <div class="currency-management-state-slot" aria-hidden="true"><span class="currency-management-state-dot${row.isUsd ? ' is-reference' : ''}${isSelected ? ' is-active' : ''}"></span></div>
                      <div class="currency-management-flag" title="${escapeHtml(row.code)}" aria-hidden="true">${createFlagImageMarkup(row, { className: 'currency-management-flag-image' })}</div>
                      <div class="currency-management-code-pill">${wrapControlTextMarkup(escapeHtml(row.code), 'taif-control-text--ltr')}</div>
                      <div class="currency-management-name-col">
                        <div class="currency-management-name">${escapeHtml(row.name)}</div>
                      </div>
                      <div class="currency-management-pair-col">
                        <span class="currency-management-pair-badge" dir="ltr">${wrapControlTextMarkup(renderPairBadgeMarkup(row.usdPairLabel || row.usdPairId || 'USD/USD'), 'taif-control-text--ltr taif-control-text--pair')}</span>
                      </div>
                      <div class="currency-management-num-pill currency-management-num-pill--buy">${wrapControlTextMarkup(formatManagementCellValue(row, 'buy', 6), 'taif-control-text--ltr')}</div>
                      <div class="currency-management-num-pill currency-management-num-pill--sell">${wrapControlTextMarkup(formatManagementCellValue(row, 'sell', 6), 'taif-control-text--ltr')}</div>
                      <div class="currency-management-num-pill currency-management-num-pill--mid">${wrapControlTextMarkup(formatManagementCellValue(row, 'middle', 6), 'taif-control-text--ltr')}</div>
                      <div class="currency-management-num-pill currency-management-num-pill--ratio-buy">${wrapControlTextMarkup(formatManagementCellValue(row, 'dollarBuy', 6), 'taif-control-text--ltr')}</div>
                      <div class="currency-management-num-pill currency-management-num-pill--ratio-sell">${wrapControlTextMarkup(formatManagementCellValue(row, 'dollarSell', 6), 'taif-control-text--ltr')}</div>
                      <div class="currency-management-actions">
                        ${iconButtonMarkup({ action: 'edit', title: row.isUsd ? 'تعديل الدولار' : 'تعديل عملة فردي', icon: 'edit' })}
                        ${iconButtonMarkup({ action: 'delete', title: row.isUsd ? 'الدولار لا يُحذف' : 'حذف عملة', icon: 'trash', danger: true, disabled: row.isUsd })}
                        ${iconButtonMarkup({ action: 'move-up', title: 'رفع العملة للأعلى', icon: 'up', move: true, disabled: !move.canMoveUp })}
                        ${iconButtonMarkup({ action: 'move-down', title: 'تنزيل العملة للأسفل', icon: 'down', move: true, disabled: !move.canMoveDown })}
                      </div>
                    </div>
                  `;
                }).join('')}
              </div>
            </div>
          </div>

        </section>
      </div>
    `;

    const searchInput = panel.querySelector('#currency-management-search-input');
    const clearButton = panel.querySelector('#currency-management-search-clear');

    searchInput.addEventListener('input', (event) => {
      runtime.filter = event.target.value || '';
      applyMainSearchFilter(panel);
    });

    clearButton?.addEventListener('click', () => {
      runtime.filter = '';
      searchInput.value = '';
      applyMainSearchFilter(panel);
      searchInput.focus({ preventScroll: true });
    });

    const toolbar = panel.querySelector('.currency-management-topbar-tools');
    toolbar?.addEventListener('click', (event) => {
      const actionButton = event.target.closest('[data-currency-management-action]');
      if(!actionButton || !toolbar.contains(actionButton)) return;
      handleToolbarAction(actionButton.dataset.currencyManagementAction);
    });

    runtime.counterpartPickerCleanup = mountCounterpartToolbarPicker(panel);
    runtime.topbarFitCleanup = mountTopbarAdaptiveFit(panel);
    runtime.mainHeaderFitCleanup = typeof mountSingleLineTextFit === 'function'
      ? mountSingleLineTextFit(panel, '.taif-singleline-fit')
      : null;

    panel.querySelectorAll('.currency-management-row').forEach((rowElement) => {
      rowElement.addEventListener('click', (event) => {
        const code = rowElement.dataset.code;
        const actionButton = event.target.closest('[data-row-action]');
        if(actionButton){
          if(hasActiveCurrencyModal() || isRowInteractionSuppressed()) return;
          handleRowAction(code, actionButton.dataset.rowAction);
          return;
        }

        if(!code) return;
        if(hasActiveCurrencyModal() || isRowInteractionSuppressed()) return;

        if(runtime.selectedCode === code){
          clearSelection();
          return;
        }

        runtime.selectedCode = code;
        updateSelectionUi(panel);
      });
    });

    updateSelectionUi(panel);
  }

  function handleToolbarAction(action){
    switch(action){
      case 'usd':
        openUsdEditor();
        return;
      case 'add':
        openCurrencyEditor();
        return;
      case 'bulk':
        openBulkEditor();
        return;
      case 'edit-single':
        openSingleCurrencyPicker();
        return;
      case 'delete-currency':
        openDeleteCurrencyPicker();
        return;
      default:
        return;
    }
  }

  function handleRowAction(code, action){
    if(!code) return;
    if(hasActiveCurrencyModal() || isRowInteractionSuppressed()) return;
    runtime.selectedCode = code;
    updateSelectionUi(runtime.panel);
    const actionRow = runtime.panel instanceof Element
      ? runtime.panel.querySelector(`.currency-management-row[data-code="${code}"]`)
      : null;
    if(actionRow && typeof actionRow.scrollIntoView === 'function'){
      actionRow.scrollIntoView({ block:'nearest', inline:'nearest' });
    }

    if(action === 'edit'){
      openEditorForCode(code);
      return;
    }

    if(action === 'delete'){
      if(code === 'USD'){
        showToast('لا يمكن حذف الدولار لأنه العملة المرجعية الأساسية.', 'danger');
        return;
      }
      openDeleteConfirm(code);
      return;
    }

    if(action === 'move-up'){
      moveCurrency(code, -1);
      return;
    }

    if(action === 'move-down'){
      moveCurrency(code, 1);
    }
  }

  function moveCurrency(code, direction){
    const state = readState();
    const currencies = [...state.currencies];
    const index = currencies.findIndex((currency) => currency.code === code);
    if(index < 0 || code === 'USD') return;

    let targetIndex = index + direction;
    while(targetIndex >= 0 && targetIndex < currencies.length && currencies[targetIndex].code === 'USD'){
      targetIndex += direction;
    }

    if(targetIndex < 0 || targetIndex >= currencies.length) return;

    const temp = currencies[index];
    currencies[index] = currencies[targetIndex];
    currencies[targetIndex] = temp;

    runtime.selectedCode = code;
    commitCurrencyManagementState(
      { ...state, currencies },
      { successMessage: direction < 0 ? 'تم رفع العملة للأعلى.' : 'تم تنزيل العملة للأسفل.' }
    );
  }

  function createCurrencyFormBody(currency, { editing = false, isUsd = false, counterpart = null } = {}){
    const state = readState();
    const code = currency?.code || '';
    const name = currency?.name || '';
    const flag = currency?.flag || fallbackFlag(code);
    const ratioBuy = currency?.ratioBuy ?? 1;
    const ratioSell = currency?.ratioSell ?? 1;
    const ratioBuyText = formatCurrencyRateInputValue(ratioBuy, currency?.ratioBuyText, currency?.decimals);
    const ratioSellText = formatCurrencyRateInputValue(ratioSell, currency?.ratioSellText, currency?.decimals);
    const buy = currency?.buy ?? 1;
    const sell = currency?.sell ?? 1;
    const buyText = formatCurrencyRateInputValue(buy, currency?.buyText, currency?.decimals);
    const sellText = formatCurrencyRateInputValue(sell, currency?.sellText, currency?.decimals);
    const usdConvention = resolveUsdConventionValue(currency);
    const allowLegacyZeroDropOption = !isUsd && (!editing || Boolean(currency?.legacyZeroDropAllowed || currency?.rateMode === LEGACY_ZERO_DROP_MODE));
    const methodPickerValue = resolveCurrencyMethodPickerValue(currency);
    const pairDirectionOptions = getCurrencyMethodPickerOptions(code, { allowLegacyZeroDropOption });
    const priceUpdateMode = currency?.priceUpdateMode === 'internet' ? 'internet' : 'manual';
    const decimals = currency?.decimals ?? 0;
    const legacySourceCode = resolveLegacySourceCode(state, currency, { currentCode: code });
    const legacySourceOptions = buildLegacySourceOptions(state, { currentCode: code });
    const addCurrencyRatioBuyLabel = getUsdPairFieldLabel(code, usdConvention, 'buy');
    const addCurrencyRatioSellLabel = getUsdPairFieldLabel(code, usdConvention, 'sell');
    const methodPickerMarkup = createChoicePickerMarkup({
      pickerDataAttribute: 'data-currency-management-method-picker',
      triggerId: 'currency-management-currency-method-trigger',
      inputId: 'currency-management-currency-method',
      valueDataAttribute: 'data-currency-management-method-value',
      value: methodPickerValue,
      options: pairDirectionOptions
    });
    const legacySourcePickerMarkup = createChoicePickerMarkup({
      pickerDataAttribute: 'data-currency-management-legacy-source-picker',
      triggerId: 'currency-management-currency-legacy-source-trigger',
      inputId: 'currency-management-currency-legacy-source',
      valueDataAttribute: 'data-currency-management-legacy-source-value',
      value: legacySourceCode,
      options: legacySourceOptions
    });
    const compactMethodAndLegacyMarkup = `
              <div class="currency-management-form-grid currency-management-form-grid--method-legacy-compact${methodPickerValue === LEGACY_ZERO_DROP_MODE ? ' is-legacy-mode' : ''}" data-currency-management-method-legacy-compact>
                <div class="currency-management-field currency-management-field--single-editor-method">
                  <span class="currency-management-field__caption">طريقة الحساب</span>
                  ${methodPickerMarkup}
                </div>
                <div class="currency-management-field currency-management-field--single-editor-method currency-management-field--single-editor-legacy-source" data-currency-management-legacy-link-row ${methodPickerValue === LEGACY_ZERO_DROP_MODE ? '' : 'hidden'} style="${methodPickerValue === LEGACY_ZERO_DROP_MODE ? '' : 'display:none;'}">
                  <span class="currency-management-field__caption">العملة القديمة المرتبطة</span>
                  ${legacySourcePickerMarkup}
                </div>
              </div>
    `;
    const legacySourceStandaloneRow = '';

    const nonUsdSection = !isUsd ? `
              <div class="currency-management-form-grid currency-management-form-grid--two">
                <div class="currency-management-field currency-management-field--single-editor-terminal-rate">
                  <label for="currency-management-currency-ratio-buy" data-currency-management-anchor-buy-label>${addCurrencyRatioBuyLabel}</label>
                  <input id="currency-management-currency-ratio-buy" class="currency-management-input" type="text" inputmode="decimal" data-smart-number-input="true" value="${escapeHtml(ratioBuyText)}">
                </div>
                <div class="currency-management-field currency-management-field--single-editor-terminal-rate">
                  <label for="currency-management-currency-ratio-sell" data-currency-management-anchor-sell-label>${addCurrencyRatioSellLabel}</label>
                  <input id="currency-management-currency-ratio-sell" class="currency-management-input" type="text" inputmode="decimal" data-smart-number-input="true" value="${escapeHtml(ratioSellText)}">
                </div>
              </div>
    ` : '';

    const usdSection = isUsd ? `
              <div class="currency-management-form-grid currency-management-form-grid--two">
                <div class="currency-management-field currency-management-field--single-editor-terminal-rate">
                  <label for="currency-management-usd-buy">${getDerivedPairFieldLabel('USD', counterpart?.code || 'USD', 'buy')}</label>
                  <input id="currency-management-usd-buy" class="currency-management-input" type="text" inputmode="decimal" data-smart-number-input="true" value="${escapeHtml(buyText)}">
                </div>
                <div class="currency-management-field currency-management-field--single-editor-terminal-rate">
                  <label for="currency-management-usd-sell">${getDerivedPairFieldLabel('USD', counterpart?.code || 'USD', 'sell')}</label>
                  <input id="currency-management-usd-sell" class="currency-management-input" type="text" inputmode="decimal" data-smart-number-input="true" value="${escapeHtml(sellText)}">
                </div>
              </div>
    ` : '';

    return `
      <div class="currency-management-single-editor-panel">
        <div class="currency-management-single-editor-scroll">
          <div class="currency-management-form-grid currency-management-form-grid--single-editor-shell">
            <div class="currency-management-form-grid currency-management-form-grid--two">
              <div class="currency-management-field currency-management-field--single-editor-identity currency-management-field--single-editor-name">
                <label for="currency-management-currency-name">اسم العملة</label>
                <div class="currency-management-name-autocomplete" data-currency-management-name-autocomplete>
                  <input id="currency-management-currency-name" class="currency-management-input" type="text" value="${escapeHtml(name)}" autocomplete="off" spellcheck="false">
                  <div class="currency-management-name-autocomplete__popover" data-currency-management-name-autocomplete-popover hidden></div>
                </div>
              </div>
              <div class="currency-management-field currency-management-field--single-editor-identity">
                <label for="currency-management-currency-code">كود العملة</label>
                <input id="currency-management-currency-code" class="currency-management-input" type="text" value="${escapeHtml(code)}" ${editing ? 'disabled' : ''}>
              </div>
            </div>
            <div class="currency-management-form-grid currency-management-form-grid--two">
              <div class="currency-management-field currency-management-field--single-editor-flag">
                <span class="currency-management-field__caption">العلم</span>
                ${createFlagPickerMarkup('currency-management-currency', code, flag)}
              </div>
              <div class="currency-management-field currency-management-field--single-editor-price-mode">
                <span class="currency-management-field__caption">طريقة تعديل الأسعار (يدوي / عبر الانترنت)</span>
                ${createChoicePickerMarkup({
                  pickerDataAttribute: 'data-currency-management-price-update-mode-picker',
                  triggerId: 'currency-management-currency-price-update-mode-trigger',
                  inputId: 'currency-management-currency-price-update-mode',
                  valueDataAttribute: 'data-currency-management-price-update-mode-value',
                  value: priceUpdateMode,
                  options: PRICE_UPDATE_MODE_OPTIONS
                })}
              </div>
            </div>
            <div class="currency-management-form-grid currency-management-form-grid--two">
              <div class="currency-management-field currency-management-field--single-editor-decimals">
                <span class="currency-management-field__caption">عداد المنازل العشرية</span>
                ${createChoicePickerMarkup({
                  pickerDataAttribute: 'data-currency-management-decimals-picker',
                  triggerId: 'currency-management-currency-decimals-trigger',
                  inputId: 'currency-management-currency-decimals',
                  valueDataAttribute: 'data-currency-management-decimals-value',
                  value: String(clampDecimals(decimals)),
                  options: DECIMAL_PLACES_OPTIONS
                })}
              </div>
              ${compactMethodAndLegacyMarkup}
            </div>
            ${legacySourceStandaloneRow}
            ${nonUsdSection}
            ${usdSection}
          </div>
        </div>
        <div class="currency-management-modal-actions currency-management-modal-actions--grand currency-management-modal-actions--dock currency-management-modal-actions--single-editor" data-taif-footer-actions="true">
          ${buttonMarkup({ action: 'cancel', label: 'إلغاء', tone: 'ghost', icon: 'close' })}
          ${buttonMarkup({ action: 'save', label: isUsd ? 'حفظ الدولار' : editing ? 'حفظ التعديل' : 'إضافة العملة', tone: 'primary', icon: isUsd ? 'dollar' : editing ? 'edit' : 'plus' })}
        </div>
      </div>
    `;
  }

  function mountSingleCurrencyFormControls({ modal, scrollArea, codeInput, nameInput, fallbackCurrencyCode = '', allowLegacyZeroDropOption = true, registerCleanup = null }){
    mountFlagPicker({
      modal,
      scrollArea,
      fieldPrefix: 'currency-management-currency',
      currencyCodeInput: codeInput,
      currencyNameInput: nameInput,
      fallbackCurrencyCode,
      registerCleanup
    });

    mountChoicePicker({
      modal,
      scrollArea,
      registerCleanup,
      pickerSelector: '[data-currency-management-method-picker]',
      triggerSelector: '#currency-management-currency-method-trigger',
      inputSelector: '#currency-management-currency-method',
      valueSelector: '[data-currency-management-method-value]',
      options: getCurrencyMethodPickerOptions(codeInput?.value || fallbackCurrencyCode || '', { allowLegacyZeroDropOption }),
      ariaLabel: 'طريقة الحساب',
      preferredOpenDirection: 'down',
      viewportBoundary: 'modal'
    });

    mountChoicePicker({
      modal,
      scrollArea,
      registerCleanup,
      pickerSelector: '[data-currency-management-legacy-source-picker]',
      triggerSelector: '#currency-management-currency-legacy-source-trigger',
      inputSelector: '#currency-management-currency-legacy-source',
      valueSelector: '[data-currency-management-legacy-source-value]',
      options: buildLegacySourceOptions(readState(), { currentCode: codeInput?.value || fallbackCurrencyCode || '' }),
      ariaLabel: 'العملة القديمة المرتبطة',
      preferredOpenDirection: 'down',
      viewportBoundary: 'modal'
    });

    SINGLE_CURRENCY_FORM_PICKERS.filter((pickerConfig) => pickerConfig.pickerSelector !== '[data-currency-management-method-picker]').forEach((pickerConfig) => {
      mountChoicePicker({
        modal,
        scrollArea,
        registerCleanup,
        ...pickerConfig
      });
    });

    const methodInput = modal.querySelector('#currency-management-currency-method');
    const legacySourceInput = modal.querySelector('#currency-management-currency-legacy-source');
    const handleLegacyUiRefresh = (event) => {
      refreshLegacyLinkSection(modal, { overwritePreview: event?.target === methodInput || event?.target === legacySourceInput });
    };
    methodInput?.addEventListener('input', handleLegacyUiRefresh);
    methodInput?.addEventListener('change', handleLegacyUiRefresh);
    legacySourceInput?.addEventListener('input', handleLegacyUiRefresh);
    legacySourceInput?.addEventListener('change', handleLegacyUiRefresh);
    refreshLegacyLinkSection(modal, { overwritePreview: false });

    if(typeof registerCleanup === 'function'){
      registerCleanup(() => {
        methodInput?.removeEventListener('input', handleLegacyUiRefresh);
        methodInput?.removeEventListener('change', handleLegacyUiRefresh);
        legacySourceInput?.removeEventListener('input', handleLegacyUiRefresh);
        legacySourceInput?.removeEventListener('change', handleLegacyUiRefresh);
      });
    }
  }


  function refreshSingleCurrencyNumericInputs(modal){
    if(!(modal instanceof HTMLElement) || typeof formatCurrencyNumericDisplay !== 'function') return;
    const decimalsInput = modal.querySelector('#currency-management-currency-decimals');
    const decimals = clampDecimals(decimalsInput ? decimalsInput.value : 0);
    const numericInputIds = [
      'currency-management-currency-ratio-buy',
      'currency-management-currency-ratio-sell',
      'currency-management-usd-buy',
      'currency-management-usd-sell'
    ];

    numericInputIds.forEach((inputId) => {
      const input = modal.querySelector(`#${inputId}`);
      if(!(input instanceof HTMLInputElement)) return;
      const normalizedText = normalizeStoredNumericText(input.value);
      if(!normalizedText){
        input.value = '';
        return;
      }
      input.value = formatCurrencyRateInputValue(normalizedText, normalizedText, decimals);
      if(typeof applySmartNumericFormatting === 'function'){
        applySmartNumericFormatting(input, {
          preserveCaret: false,
          preserveTrailingDecimal: false,
          allowDecimal: true,
          allowNegative: false
        });
      }
    });
  }

  function openSingleEditorModal({ title, subtitle, bodyHtml, fallbackCurrencyCode = '', allowLegacyZeroDropOption = true, enableNameLibraryAutocomplete = false, validationContext = null, onSave }){
    openModal({
      title,
      subtitle,
      bodyHtml,
      ...SINGLE_EDITOR_MODAL_OPTIONS,
      onMount({ modal, close, registerCleanup }){
        const scrollArea = modal.querySelector('.currency-management-single-editor-scroll');
        const codeInput = modal.querySelector('#currency-management-currency-code');
        const nameInput = modal.querySelector('#currency-management-currency-name');

        mountSingleCurrencyFormControls({
          modal,
          scrollArea,
          codeInput,
          nameInput,
          fallbackCurrencyCode,
          allowLegacyZeroDropOption,
          registerCleanup
        });
        mountCurrencyNameLibraryAutocomplete({
          modal,
          registerCleanup,
          allowLegacyZeroDropOption,
          enabled: Boolean(enableNameLibraryAutocomplete)
        });
        bindCurrencyModalValidationAutoClear(modal, registerCleanup, validationContext);
        mountSmartNumericInputs(modal, { registerCleanup });
        refreshSingleCurrencyNumericInputs(modal);

        const decimalsInput = modal.querySelector('#currency-management-currency-decimals');
        if(decimalsInput instanceof HTMLInputElement){
          const handleDecimalsChange = () => {
            refreshSingleCurrencyNumericInputs(modal);
          };
          decimalsInput.addEventListener('input', handleDecimalsChange);
          decimalsInput.addEventListener('change', handleDecimalsChange);
          if(typeof registerCleanup === 'function'){
            registerCleanup(() => {
              decimalsInput.removeEventListener('input', handleDecimalsChange);
              decimalsInput.removeEventListener('change', handleDecimalsChange);
            });
          }
        }

        if(codeInput instanceof HTMLInputElement && !codeInput.disabled){
          const handleCodeInputRefresh = () => {
            const methodPickerApi = modal.querySelector('[data-currency-management-method-picker]')?.__taifInlinePickerApi;
            if(methodPickerApi && typeof methodPickerApi.setOptions === 'function'){
              const currentMethodValue = modal.querySelector('#currency-management-currency-method')?.value || 'currency-base';
              methodPickerApi.setOptions(
                getCurrencyMethodPickerOptions(codeInput.value, { allowLegacyZeroDropOption }),
                {
                  preserveValue: true,
                  preferredValue: currentMethodValue,
                  dispatchEvents: false
                }
              );
            }
          };
          codeInput.addEventListener('input', handleCodeInputRefresh);
          codeInput.addEventListener('change', handleCodeInputRefresh);
          if(typeof registerCleanup === 'function'){
            registerCleanup(() => {
              codeInput.removeEventListener('input', handleCodeInputRefresh);
              codeInput.removeEventListener('change', handleCodeInputRefresh);
            });
          }
        }

        bindModalCloseButtons(modal, close);
        bindModalActionButtons(modal, 'save', () => {
          if(typeof onSave !== 'function') return;
          onSave({ modal, close, registerCleanup, scrollArea, codeInput });
        });
      }
    });
  }

  function readSingleCurrencyFormValues(modal, { editing = false, currentCode = '', currentCurrency = null } = {}){
    const nextCode = editing ? currentCode : normalizeCode(modal.querySelector('#currency-management-currency-code').value);
    const nextName = modal.querySelector('#currency-management-currency-name').value.trim();
    const nextFlag = resolveStoredFlagCode(modal.querySelector('#currency-management-currency-flag').value.trim(), nextCode);
    const methodValue = modal.querySelector('#currency-management-currency-method').value;
    const rateMode = methodValue === LEGACY_ZERO_DROP_MODE ? LEGACY_ZERO_DROP_MODE : 'manual';
    const linkedSourceCode = rateMode === LEGACY_ZERO_DROP_MODE
      ? normalizeCode(modal.querySelector('#currency-management-currency-legacy-source')?.value || '')
      : '';
    const sourceCurrency = rateMode === LEGACY_ZERO_DROP_MODE ? getLegacySourceCurrency(readState(), linkedSourceCode) : null;
    const usdConvention = rateMode === LEGACY_ZERO_DROP_MODE
      ? resolveUsdConventionValue(sourceCurrency)
      : (methodValue === 'usd-base' ? 'usd-base' : 'currency-base');
    const method = usdConvention === 'usd-base' ? 'divide' : 'multiply';
    const priceUpdateMode = modal.querySelector('#currency-management-currency-price-update-mode').value === 'internet' ? 'internet' : 'manual';
    const ratioBuyInput = modal.querySelector('#currency-management-currency-ratio-buy');
    const ratioSellInput = modal.querySelector('#currency-management-currency-ratio-sell');
    const ratioBuyText = ratioBuyInput ? normalizeStoredNumericText(ratioBuyInput.value) : '';
    const ratioSellText = ratioSellInput ? normalizeStoredNumericText(ratioSellInput.value) : '';
    const ratioBuy = ratioBuyInput ? Math.max(toNumber(ratioBuyText || ratioBuyInput.value, 0), 0) : 1;
    const ratioSell = ratioSellInput ? Math.max(toNumber(ratioSellText || ratioSellInput.value, 0), 0) : 1;
    const decimals = clampDecimals(modal.querySelector('#currency-management-currency-decimals').value);
    const legacyZeroDropAllowed = rateMode === LEGACY_ZERO_DROP_MODE
      || Boolean(currentCurrency && (currentCurrency.legacyZeroDropAllowed || currentCurrency.rateMode === LEGACY_ZERO_DROP_MODE));

    return {
      nextCode,
      nextName,
      nextFlag,
      method,
      usdConvention,
      priceUpdateMode,
      ratioBuy,
      ratioSell,
      ratioBuyText,
      ratioSellText,
      decimals,
      rateMode,
      legacySourceCode: linkedSourceCode,
      legacyZeroShift: rateMode === LEGACY_ZERO_DROP_MODE ? LEGACY_ZERO_DROP_SHIFT : 0,
      legacyZeroDropAllowed,
      rateEditedAt: Date.now()
    };
  }


  const CURRENCY_FIELD_CONTROL_SELECTORS = Object.freeze({
    name:'#currency-management-currency-name',
    code:'#currency-management-currency-code',
    flag:Object.freeze(['#currency-management-currency-flag-trigger', '.currency-management-flag-picker__trigger']),
    priceUpdateMode:'#currency-management-currency-price-update-mode-trigger',
    decimals:'#currency-management-currency-decimals-trigger',
    method:'#currency-management-currency-method-trigger',
    legacySource:'#currency-management-currency-legacy-source-trigger',
    ratioBuy:'#currency-management-currency-ratio-buy',
    ratioSell:'#currency-management-currency-ratio-sell',
    usdBuy:'#currency-management-usd-buy',
    usdSell:'#currency-management-usd-sell'
  });

  const CURRENCY_VALIDATION_FIELD_BY_CONTROL_ID = Object.freeze({
    'currency-management-currency-name':'name',
    'currency-management-currency-code':'code',
    'currency-management-currency-flag':'flag',
    'currency-management-currency-flag-trigger':'flag',
    'currency-management-currency-price-update-mode':'priceUpdateMode',
    'currency-management-currency-price-update-mode-trigger':'priceUpdateMode',
    'currency-management-currency-decimals':'decimals',
    'currency-management-currency-decimals-trigger':'decimals',
    'currency-management-currency-method':'method',
    'currency-management-currency-method-trigger':'method',
    'currency-management-currency-legacy-source':'legacySource',
    'currency-management-currency-legacy-source-trigger':'legacySource',
    'currency-management-currency-ratio-buy':'ratioBuy',
    'currency-management-currency-ratio-sell':'ratioSell',
    'currency-management-usd-buy':'usdBuy',
    'currency-management-usd-sell':'usdSell'
  });

  function buildSingleCurrencyPayload({
    nextCode,
    nextName,
    nextFlag,
    method,
    usdConvention,
    priceUpdateMode,
    ratioBuy,
    ratioSell,
    ratioBuyText,
    ratioSellText,
    decimals,
    rateMode,
    legacySourceCode,
    legacyZeroShift,
    legacyZeroDropAllowed,
    rateEditedAt
  }){
    return {
      code: nextCode,
      name: nextName,
      flag: nextFlag,
      ratioBuy,
      ratioSell,
      ratioBuyText,
      ratioSellText,
      method,
      usdConvention,
      decimals,
      priceUpdateMode,
      rateMode,
      legacySourceCode,
      legacyZeroShift,
      legacyZeroDropAllowed,
      rateEditedAt
    };
  }

  function resolveCurrencyFieldControl(modal, fieldName){
    if(!(modal instanceof HTMLElement)) return null;

    const selectorEntry = CURRENCY_FIELD_CONTROL_SELECTORS[String(fieldName || '')];
    if(!selectorEntry) return null;

    if(Array.isArray(selectorEntry)){
      for(const selector of selectorEntry){
        const control = modal.querySelector(selector);
        if(control) return control;
      }
      return null;
    }

    return modal.querySelector(selectorEntry);
  }

  function clearCurrencyFieldValidationState(modal, fieldName){
    const control = resolveCurrencyFieldControl(modal, fieldName);
    if(!control) return;
    control.classList.remove('is-invalid');
    control.removeAttribute('aria-invalid');
  }

  function clearCurrencyValidationState(modal){
    if(!(modal instanceof HTMLElement)) return;
    modal.querySelectorAll('.is-invalid').forEach((node) => {
      node.classList.remove('is-invalid');
      node.removeAttribute('aria-invalid');
    });
  }

  function focusCurrencyValidationControl(control){
    if(!(control instanceof HTMLElement)) return;
    try {
      control.focus({ preventScroll:true });
    } catch{
      try { control.focus(); } catch{}
    }
    if(typeof control.scrollIntoView === 'function'){
      try {
        control.scrollIntoView({ block:'center', inline:'nearest', behavior:'smooth' });
      } catch{}
    }
  }

  const CURRENCY_MODAL_PRICE_FIELD_GROUPS = Object.freeze({
    ratioBuy: ['ratioBuy', 'ratioSell'],
    ratioSell: ['ratioBuy', 'ratioSell'],
    usdBuy: ['usdBuy', 'usdSell'],
    usdSell: ['usdBuy', 'usdSell']
  });

  const BULK_PRICE_FIELD_GROUPS = Object.freeze({
    buy: ['buy', 'sell'],
    sell: ['buy', 'sell'],
    ratioBuy: ['ratioBuy', 'ratioSell'],
    ratioSell: ['ratioBuy', 'ratioSell']
  });

  function setCurrencyFieldValidationState(modal, fieldName, isInvalid){
    const control = resolveCurrencyFieldControl(modal, fieldName);
    if(!(control instanceof HTMLElement)) return null;
    control.classList.toggle('is-invalid', Boolean(isInvalid));
    if(isInvalid) control.setAttribute('aria-invalid', 'true');
    else control.removeAttribute('aria-invalid');
    return control;
  }

  function showCurrencyFieldsValidationError(modal, fieldNames, message){
    clearCurrencyValidationState(modal);
    let focusTarget = null;
    (Array.isArray(fieldNames) ? fieldNames : [fieldNames]).forEach((fieldName) => {
      const control = setCurrencyFieldValidationState(modal, fieldName, true);
      if(!focusTarget && control) focusTarget = control;
    });
    if(focusTarget) focusCurrencyValidationControl(focusTarget);
    showToast(message, 'danger');
    return false;
  }

  function showCurrencyFieldValidationError(modal, fieldName, message){
    return showCurrencyFieldsValidationError(modal, [fieldName], message);
  }

  function resolveCurrencyValidationFieldFromTarget(target){
    if(!(target instanceof HTMLElement)) return '';
    return CURRENCY_VALIDATION_FIELD_BY_CONTROL_ID[target.id] || '';
  }

  function collectCurrencyModalValidationFlags(modal, context = null){
    const flags = {
      name: true,
      code: true,
      legacySource: true,
      ratioBuy: true,
      ratioSell: true,
      usdBuy: true,
      usdSell: true
    };
    if(!(modal instanceof HTMLElement)) return flags;

    const resolvedContext = context && typeof context === 'object' ? context : {};
    const nameValue = String(modal.querySelector('#currency-management-currency-name')?.value || '').trim();
    flags.name = Boolean(nameValue);

    if(resolvedContext.mode === 'usd'){
      const usdBuyInput = modal.querySelector('#currency-management-usd-buy');
      const usdSellInput = modal.querySelector('#currency-management-usd-sell');
      const usdBuyText = usdBuyInput ? normalizeStoredNumericText(usdBuyInput.value) : '';
      const usdSellText = usdSellInput ? normalizeStoredNumericText(usdSellInput.value) : '';
      const usdBuy = usdBuyInput ? getPositiveRate(usdBuyText || usdBuyInput.value, 0) : 0;
      const usdSell = usdSellInput ? getPositiveRate(usdSellText || usdSellInput.value, 0) : 0;
      const counterpartCode = String(resolvedContext.counterpartCode || '');

      flags.usdBuy = usdBuy > 0;
      flags.usdSell = usdSell > 0;

      if(counterpartCode === 'USD'){
        const identityValid = Math.abs(usdBuy - 1) <= 0.000001 && Math.abs(usdSell - 1) <= 0.000001;
        flags.usdBuy = identityValid;
        flags.usdSell = identityValid;
        return flags;
      }

      if(flags.usdBuy && flags.usdSell && usdBuy > usdSell){
        flags.usdBuy = false;
        flags.usdSell = false;
      }
      return flags;
    }

    const editing = Boolean(resolvedContext.editing);
    const currentCode = String(resolvedContext.currentCode || '');
    const rawCode = modal.querySelector('#currency-management-currency-code')?.value || '';
    const nextCode = editing ? currentCode : normalizeCode(rawCode);
    const duplicate = readState().currencies.find((currency) => currency.code === nextCode && currency.code !== currentCode);
    flags.code = Boolean(nextCode && nextCode.length >= 2 && nextCode.length <= 5 && nextCode !== 'USD' && !duplicate);

    const methodValue = modal.querySelector('#currency-management-currency-method')?.value || 'currency-base';
    if(methodValue === LEGACY_ZERO_DROP_MODE){
      const sourceCode = normalizeCode(modal.querySelector('#currency-management-currency-legacy-source')?.value || '');
      const sourceCurrency = getLegacySourceCurrency(readState(), sourceCode);
      flags.legacySource = Boolean(sourceCode && sourceCode !== 'USD' && sourceCurrency && sourceCode !== nextCode && sourceCurrency.rateMode !== LEGACY_ZERO_DROP_MODE);
    }

    const ratioBuyInput = modal.querySelector('#currency-management-currency-ratio-buy');
    const ratioSellInput = modal.querySelector('#currency-management-currency-ratio-sell');
    const ratioBuyText = ratioBuyInput ? normalizeStoredNumericText(ratioBuyInput.value) : '';
    const ratioSellText = ratioSellInput ? normalizeStoredNumericText(ratioSellInput.value) : '';
    const ratioBuy = ratioBuyInput ? Math.max(toNumber(ratioBuyText || ratioBuyInput.value, 0), 0) : 0;
    const ratioSell = ratioSellInput ? Math.max(toNumber(ratioSellText || ratioSellInput.value, 0), 0) : 0;

    flags.ratioBuy = ratioBuy > 0;
    flags.ratioSell = ratioSell > 0;
    if(flags.ratioBuy && flags.ratioSell && ratioBuy > ratioSell){
      flags.ratioBuy = false;
      flags.ratioSell = false;
    }
    return flags;
  }

  function refreshCurrencyValidationState(modal, context = null, { triggerField = '' } = {}){
    if(!(modal instanceof HTMLElement)) return;
    const flags = collectCurrencyModalValidationFlags(modal, context);
    const relatedFields = CURRENCY_MODAL_PRICE_FIELD_GROUPS[String(triggerField || '')] || (triggerField ? [triggerField] : []);
    Object.keys(flags).forEach((fieldName) => {
      if(flags[fieldName]){
        clearCurrencyFieldValidationState(modal, fieldName);
        return;
      }
      const control = resolveCurrencyFieldControl(modal, fieldName);
      if(!(control instanceof HTMLElement)) return;
      const shouldMark = relatedFields.includes(fieldName)
        || control.classList.contains('is-invalid')
        || control.getAttribute('aria-invalid') === 'true';
      if(shouldMark) setCurrencyFieldValidationState(modal, fieldName, true);
    });
  }

  function bindCurrencyModalValidationAutoClear(modal, registerCleanup = null, context = null){
    if(!(modal instanceof HTMLElement)) return;

    const handleInteraction = (event) => {
      const fieldName = resolveCurrencyValidationFieldFromTarget(event.target);
      if(!fieldName) return;
      refreshCurrencyValidationState(modal, context, { triggerField: fieldName });
    };

    modal.addEventListener('input', handleInteraction, true);
    modal.addEventListener('change', handleInteraction, true);

    if(typeof registerCleanup === 'function'){
      registerCleanup(() => {
        modal.removeEventListener('input', handleInteraction, true);
        modal.removeEventListener('change', handleInteraction, true);
      });
    }
  }

  function resolveBulkValidationFieldSelector(code, fieldName){
    const safeCode = String(code || '').replace(/"/g, '\"');
    return `.currency-management-bulk-input[data-code="${safeCode}"][data-bulk-field="${fieldName}"]`;
  }

  function setBulkFieldValidationState(container, code, fieldName, isInvalid){
    if(!(container instanceof HTMLElement)) return null;
    const input = container.querySelector(resolveBulkValidationFieldSelector(code, fieldName));
    if(!(input instanceof HTMLElement)) return null;
    input.classList.toggle('is-invalid', Boolean(isInvalid));
    if(isInvalid) input.setAttribute('aria-invalid', 'true');
    else input.removeAttribute('aria-invalid');
    return input;
  }

  function clearBulkValidationState(container){
    if(!(container instanceof HTMLElement)) return;
    container.querySelectorAll('.currency-management-bulk-input.is-invalid, .currency-management-bulk-input[aria-invalid="true"]').forEach((node) => {
      node.classList.remove('is-invalid');
      node.removeAttribute('aria-invalid');
    });
  }

  function clearBulkFieldValidationState(container, code, fieldName){
    setBulkFieldValidationState(container, code, fieldName, false);
  }

  function readBulkFieldState(container, code, fieldName){
    const input = container instanceof HTMLElement
      ? container.querySelector(resolveBulkValidationFieldSelector(code, fieldName))
      : null;
    const rawValue = input instanceof HTMLInputElement ? String(input.value || '') : '';
    const numericText = input instanceof HTMLInputElement ? normalizeStoredNumericText(rawValue) : '';
    const numericValue = input instanceof HTMLInputElement ? getPositiveRate(numericText || rawValue, 0) : 0;
    return {
      input,
      rawValue,
      numericText,
      numericValue,
      isPositive: numericValue > 0
    };
  }

  function collectBulkRowValidationFlags(container, code){
    const flags = { buy: true, sell: true, ratioBuy: true, ratioSell: true };
    if(!(container instanceof HTMLElement) || !code) return flags;

    const buyState = readBulkFieldState(container, code, 'buy');
    const sellState = readBulkFieldState(container, code, 'sell');
    const ratioBuyState = readBulkFieldState(container, code, 'ratioBuy');
    const ratioSellState = readBulkFieldState(container, code, 'ratioSell');

    if(buyState.input instanceof HTMLInputElement && sellState.input instanceof HTMLInputElement){
      flags.buy = buyState.isPositive;
      flags.sell = sellState.isPositive;
      if(flags.buy && flags.sell && buyState.numericValue > sellState.numericValue){
        flags.buy = false;
        flags.sell = false;
      }
    }

    if(ratioBuyState.input instanceof HTMLInputElement && ratioSellState.input instanceof HTMLInputElement){
      flags.ratioBuy = ratioBuyState.isPositive;
      flags.ratioSell = ratioSellState.isPositive;
      if(flags.ratioBuy && flags.ratioSell && ratioBuyState.numericValue > ratioSellState.numericValue){
        flags.ratioBuy = false;
        flags.ratioSell = false;
      }
    }

    return flags;
  }

  function resolveBulkCurrencyLabel(workingStateInput, code){
    const state = sanitizeState(workingStateInput);
    const currency = state.currencies.find((item) => item.code === code);
    if(!currency) return String(code || '').trim();
    const codeText = String(currency.code || '').trim();
    const nameText = String(currency.name || '').trim();
    if(nameText && codeText) return `${nameText} (${codeText})`;
    return nameText || codeText || String(code || '').trim();
  }

  function getFirstBulkValidationIssue(container, workingStateInput){
    if(!(container instanceof HTMLElement)) return null;
    const counterpartDisplayName = getCounterpartDisplayName(getCounterpartCurrencyFromState(sanitizeState(workingStateInput)));
    const codes = Array.from(new Set(Array.from(container.querySelectorAll('.currency-management-bulk-input[data-code]')).map((node) => String(node.getAttribute('data-code') || '').trim()).filter(Boolean)));

    for(const code of codes){
      const currencyLabel = resolveBulkCurrencyLabel(workingStateInput, code);
      const buyState = readBulkFieldState(container, code, 'buy');
      const sellState = readBulkFieldState(container, code, 'sell');
      const ratioBuyState = readBulkFieldState(container, code, 'ratioBuy');
      const ratioSellState = readBulkFieldState(container, code, 'ratioSell');

      if(buyState.input instanceof HTMLInputElement && sellState.input instanceof HTMLInputElement){
        if(!buyState.isPositive){
          return { code, fields: ['buy'], message: `أدخل سعر شراء صحيحًا مقابل ${counterpartDisplayName} للعملة ${currencyLabel}.` };
        }
        if(!sellState.isPositive){
          return { code, fields: ['sell'], message: `أدخل سعر مبيع صحيحًا مقابل ${counterpartDisplayName} للعملة ${currencyLabel}.` };
        }
        if(buyState.numericValue > sellState.numericValue){
          return { code, fields: ['buy', 'sell'], message: `سعر الشراء مقابل ${counterpartDisplayName} لا يجوز أن يكون أكبر من سعر المبيع للعملة ${currencyLabel}.` };
        }
      }

      if(ratioBuyState.input instanceof HTMLInputElement && ratioSellState.input instanceof HTMLInputElement){
        if(!ratioBuyState.isPositive){
          return { code, fields: ['ratioBuy'], message: `أدخل سعر شراء صحيحًا مقابل الدولار للعملة ${currencyLabel}.` };
        }
        if(!ratioSellState.isPositive){
          return { code, fields: ['ratioSell'], message: `أدخل سعر مبيع صحيحًا مقابل الدولار للعملة ${currencyLabel}.` };
        }
        if(ratioBuyState.numericValue > ratioSellState.numericValue){
          return { code, fields: ['ratioBuy', 'ratioSell'], message: `سعر الشراء مقابل الدولار لا يجوز أن يكون أكبر من سعر المبيع للعملة ${currencyLabel}.` };
        }
      }
    }

    return null;
  }

  function refreshBulkValidationState(container, { triggerCode = '', triggerField = '' } = {}){
    if(!(container instanceof HTMLElement)) return;
    const codes = Array.from(new Set(Array.from(container.querySelectorAll('.currency-management-bulk-input[data-code]')).map((node) => String(node.getAttribute('data-code') || '').trim()).filter(Boolean)));
    const relatedFields = BULK_PRICE_FIELD_GROUPS[String(triggerField || '')] || (triggerField ? [triggerField] : []);

    codes.forEach((code) => {
      const flags = collectBulkRowValidationFlags(container, code);
      Object.keys(flags).forEach((fieldName) => {
        const input = container.querySelector(resolveBulkValidationFieldSelector(code, fieldName));
        if(!(input instanceof HTMLElement)) return;
        if(flags[fieldName]){
          clearBulkFieldValidationState(container, code, fieldName);
          return;
        }
        const shouldMark = (triggerCode && code === triggerCode && relatedFields.includes(fieldName))
          || input.classList.contains('is-invalid')
          || input.getAttribute('aria-invalid') === 'true';
        if(shouldMark) setBulkFieldValidationState(container, code, fieldName, true);
      });
    });
  }

  function showBulkFieldsValidationError(container, code, fieldNames, message){
    clearBulkValidationState(container);
    let focusTarget = null;
    (Array.isArray(fieldNames) ? fieldNames : [fieldNames]).forEach((fieldName) => {
      const input = setBulkFieldValidationState(container, code, fieldName, true);
      if(!focusTarget && input) focusTarget = input;
    });
    if(focusTarget) focusCurrencyValidationControl(focusTarget);
    showToast(message, 'danger');
    return false;
  }

  function commitCurrencyManagementState(nextStateInput, { close = null, successMessage = '' } = {}){
    const nextState = sanitizeState(nextStateInput);
    const audit = typeof auditState === 'function' ? auditState(nextState) : { errors: [] };
    if(audit.errors && audit.errors.length){
      showToast(audit.errors[0], 'danger');
      return false;
    }

    writeState(nextState);
    refreshView();
    if(typeof close === 'function') close();
    if(successMessage) showToast(successMessage, 'success');
    return true;
  }

  function openUsdEditor(){
    const state = readState();
    const counterpart = getCounterpartCurrencyFromState(state);
    const usd = state.currencies.find((currency) => currency.code === 'USD') || sanitizeCurrency(createDefaultState().currencies[0], 0);
    const usdQuote = typeof getUsdAgainstCounterpartQuote === 'function'
      ? getUsdAgainstCounterpartQuote(state)
      : { bid: 1, ask: 1 };
    const usdBuy = usdQuote && usdQuote.bid ? usdQuote.bid : 1;
    const usdSell = usdQuote && usdQuote.ask ? usdQuote.ask : 1;

    openSingleEditorModal({
      title: 'تعديل الدولار',
      subtitle: `الدولار الأمريكي مقابل ${escapeHtml(counterpart.name || counterpart.code || 'USD')}`,
      bodyHtml: createCurrencyFormBody({ ...usd, buy: usdBuy, sell: usdSell, buyText: normalizeStoredNumericText(usdQuote.bidText), sellText: normalizeStoredNumericText(usdQuote.askText) }, { editing: true, isUsd: true, counterpart }),
      fallbackCurrencyCode: usd?.code || 'USD',
      allowLegacyZeroDropOption: false,
      validationContext: { mode: 'usd', counterpartCode: counterpart.code || '' },
      onSave({ modal, close }){
        const {
          nextCode,
          nextName,
          nextFlag,
          priceUpdateMode,
          decimals
        } = readSingleCurrencyFormValues(modal, { editing: true, currentCode: usd.code });
        const buyText = normalizeStoredNumericText(modal.querySelector('#currency-management-usd-buy').value);
        const sellText = normalizeStoredNumericText(modal.querySelector('#currency-management-usd-sell').value);
        const buy = getPositiveRate(buyText || modal.querySelector('#currency-management-usd-buy').value, 0);
        const sell = getPositiveRate(sellText || modal.querySelector('#currency-management-usd-sell').value, 0);

        clearCurrencyValidationState(modal);

        if(!String(nextName || '').trim()){
          return showCurrencyFieldValidationError(modal, 'name', 'اكتب اسم العملة.');
        }

        const counterpartDisplayName = getCounterpartDisplayName(counterpart);

        if(!(buy > 0)){
          return showCurrencyFieldValidationError(modal, 'usdBuy', `أدخل سعر شراء صحيحًا مقابل ${counterpartDisplayName}.`);
        }

        if(!(sell > 0)){
          return showCurrencyFieldValidationError(modal, 'usdSell', `أدخل سعر مبيع صحيحًا مقابل ${counterpartDisplayName}.`);
        }

        if(counterpart.code === 'USD' && (Math.abs(buy - 1) > 0.000001 || Math.abs(sell - 1) > 0.000001)){
          return showCurrencyFieldsValidationError(modal, ['usdBuy', 'usdSell'], 'عند اختيار الدولار كعملة مقابلة تبقى قيمة الدولار 1 / 1.');
        }

        if(buy > sell){
          return showCurrencyFieldsValidationError(modal, ['usdBuy', 'usdSell'], `سعر الشراء مقابل ${counterpartDisplayName} لا يجوز أن يكون أكبر من سعر المبيع.`);
        }

        let nextState = typeof setUsdAgainstCounterpartQuote === 'function'
          ? setUsdAgainstCounterpartQuote(state, { buy, sell, buyText, sellText })
          : state;

        nextState = {
          ...nextState,
          currencies: nextState.currencies.map((currency) => {
            if(currency.code !== 'USD') return currency;
            return sanitizeCurrency({
              ...currency,
              code: nextCode,
              name: nextName,
              flag: nextFlag,
              ratioBuy: 1,
              ratioSell: 1,
              method: 'multiply',
              decimals,
              priceUpdateMode,
              buy,
              sell,
              buyText,
              sellText
            }, 0);
          })
        };

        commitCurrencyManagementState(nextState, {
          close,
          successMessage: 'تم تحديث الدولار بنجاح.'
        });
      }
    });
  }

  function openCurrencyEditor(code){
    const state = readState();
    const editing = Boolean(code);
    const currentCurrency = editing ? state.currencies.find((currency) => currency.code === code) : sanitizeCurrency({ code: '', name: '', flag: '', ratioBuy: 1, ratioSell: 1, method: 'multiply', decimals: 0, priceUpdateMode: 'manual' }, 1);

    if(editing && !currentCurrency){
      showToast('تعذر العثور على هذه العملة.', 'danger');
      return;
    }

    const allowLegacyZeroDropOption = !editing || Boolean(currentCurrency?.legacyZeroDropAllowed || currentCurrency?.rateMode === LEGACY_ZERO_DROP_MODE);

    openSingleEditorModal({
      title: editing ? 'تعديل عملة فردي' : 'إضافة عملة جديدة',
      subtitle: editing ? `${currentCurrency.name} — ${currentCurrency.code}` : 'إدراج عملة جديدة داخل إدارة العملات',
      bodyHtml: createCurrencyFormBody(currentCurrency, { editing }),
      fallbackCurrencyCode: currentCurrency?.code || '',
      allowLegacyZeroDropOption,
      enableNameLibraryAutocomplete: !editing,
      validationContext: { mode: 'currency', editing, currentCode: currentCurrency?.code || '' },
      onSave({ modal, close }){
        const {
          nextCode,
          nextName,
          nextFlag,
          method,
          usdConvention,
          priceUpdateMode,
          ratioBuy,
          ratioSell,
          ratioBuyText,
          ratioSellText,
          decimals,
          rateMode,
          legacySourceCode,
          legacyZeroShift,
          legacyZeroDropAllowed,
          rateEditedAt
        } = readSingleCurrencyFormValues(modal, { editing, currentCode: currentCurrency?.code || '', currentCurrency });

        clearCurrencyValidationState(modal);

        if(!String(nextName || '').trim()){
          return showCurrencyFieldValidationError(modal, 'name', 'اكتب اسم العملة.');
        }

        if(!nextCode || nextCode.length < 2 || nextCode.length > 5){
          return showCurrencyFieldValidationError(modal, 'code', 'اكتب كودًا صحيحًا للعملة من 2 إلى 5 أحرف.');
        }

        if(nextCode === 'USD'){
          return showCurrencyFieldValidationError(modal, 'code', 'تعديل الدولار يتم من زر الدولار المخصص.');
        }

        if(!(ratioBuy > 0)){
          return showCurrencyFieldValidationError(modal, 'ratioBuy', 'أدخل سعر شراء صحيحًا مقابل الدولار.');
        }

        if(!(ratioSell > 0)){
          return showCurrencyFieldValidationError(modal, 'ratioSell', 'أدخل سعر مبيع صحيحًا مقابل الدولار.');
        }

        if(ratioBuy > ratioSell){
          return showCurrencyFieldsValidationError(modal, ['ratioBuy', 'ratioSell'], 'سعر الشراء مقابل الدولار لا يجوز أن يكون أكبر من سعر المبيع.');
        }

        const duplicate = state.currencies.find((currency) => currency.code === nextCode && currency.code !== currentCurrency?.code);
        if(duplicate){
          return showCurrencyFieldValidationError(modal, 'code', 'هذا الكود مستخدم سابقًا داخل إدارة العملات.');
        }

        if(rateMode === LEGACY_ZERO_DROP_MODE){
          if(!legacySourceCode){
            return showCurrencyFieldValidationError(modal, 'legacySource', 'اختر العملة القديمة التي سيتم ربط هذه العملة بها.');
          }
          if(legacySourceCode === nextCode){
            return showCurrencyFieldValidationError(modal, 'legacySource', 'لا يمكن ربط العملة بنفسها داخل وضع حذف الأصفار.');
          }
          const sourceCurrency = state.currencies.find((currency) => currency.code === legacySourceCode);
          if(!sourceCurrency){
            return showCurrencyFieldValidationError(modal, 'legacySource', 'العملة القديمة المحددة غير موجودة داخل إدارة العملات.');
          }
          if(sourceCurrency.code === 'USD'){
            return showCurrencyFieldValidationError(modal, 'legacySource', 'اختر عملة قديمة فعلية من العملات المعرفة، ولا تربط هذه العملية بالدولار المرجعي.');
          }
          if(sourceCurrency.rateMode === LEGACY_ZERO_DROP_MODE){
            return showCurrencyFieldValidationError(modal, 'legacySource', 'اختر عملة أصلية مباشرة، ولا تربط هذه العملة بعملة مشتقة أخرى.');
          }
        }

        const nextCurrency = sanitizeCurrency(buildSingleCurrencyPayload({
          nextCode,
          nextName,
          nextFlag,
          ratioBuy,
          ratioSell,
          ratioBuyText,
          ratioSellText,
          method,
          usdConvention,
          decimals,
          priceUpdateMode,
          rateMode,
          legacySourceCode,
          legacyZeroShift,
          legacyZeroDropAllowed,
          rateEditedAt
        }));

        const nextCurrencies = editing
          ? state.currencies.map((currency) => currency.code === currentCurrency.code ? nextCurrency : currency)
          : [...state.currencies, nextCurrency];

        commitCurrencyManagementState(
          { ...state, currencies: nextCurrencies },
          {
            close,
            successMessage: editing ? 'تم حفظ تعديل العملة.' : 'تمت إضافة العملة الجديدة.'
          }
        );
      }
    });
  }

  function createCurrencyPickerCardMarkup(currency, { mode }){
    const isDelete = mode === 'delete';
    const isLocked = isDelete && currency.code === 'USD';
    const actionLabel = isDelete ? (isLocked ? 'عملة محمية' : 'اختيار للحذف') : 'اختيار للتعديل';
    const actionIcon = createButtonIcon(isDelete ? 'trash' : 'edit');

    return `
      <button class="currency-management-picker-card currency-management-picker-card--${mode}${isLocked ? ' is-locked' : ''}" type="button" data-picker-code="${currency.code}" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" ${isLocked ? 'disabled' : ''}>
        <span class="currency-management-picker-card__identity">
          <span class="currency-management-picker-card__flag" aria-hidden="true">${createFlagImageMarkup(currency, { className: 'currency-management-picker-card__flag-image' })}</span>
          <span class="currency-management-picker-card__text">
            <span class="currency-management-picker-card__head">
              <span class="currency-management-picker-card__code">${escapeHtml(currency.code)}</span>
              <strong class="currency-management-picker-card__name">${escapeHtml(currency.name)}</strong>
            </span>
          </span>
        </span>
        <span class="currency-management-picker-card__action">
          ${actionIcon}
          <span>${escapeHtml(actionLabel)}</span>
        </span>
      </button>
    `;
  }

  function createCurrencyPickerBody({ mode }){
    const state = readState();
    const currencies = state.currencies;
    const cardsMarkup = currencies.length
      ? currencies.map((currency) => createCurrencyPickerCardMarkup(currency, { mode })).join('')
      : `<div class="currency-management-empty currency-management-empty--picker">لا توجد عملات متاحة داخل هذه القائمة.</div>`;

    return `
      <div class="currency-management-picker-panel currency-management-picker-panel--${mode}">
        <div class="currency-management-picker-list" role="list" data-taif-arrow-group="vertical">
          ${cardsMarkup}
        </div>
      </div>
    `;
  }

  function mountCurrencyPicker(body, { mode, onChoose }){
    body.innerHTML = createCurrencyPickerBody({ mode });

    const list = body.querySelector('.currency-management-picker-list');
    if(!list || typeof onChoose !== 'function') return;

    list.addEventListener('click', (event) => {
      const button = event.target.closest('[data-picker-code]');
      if(!button || !list.contains(button)) return;
      const code = button.dataset.pickerCode;
      if(!code) return;
      onChoose(code);
    });
  }

  function replaceModalWindow(closeCurrent, openNext, delay = 150){
    if(typeof openNext !== 'function') return;

    if(typeof closeCurrent !== 'function'){
      openNext();
      return;
    }

    closeCurrent();
    window.setTimeout(() => {
      openNext();
    }, Math.max(0, Number(delay) || 0));
  }

  function openCurrencyPickerModal({ title, subtitle, mode, modalClass, onChoose }){
    openModal({
      title,
      subtitle,
      bodyHtml: createCurrencyPickerBody({ mode }),
      size: 'md',
      variant: 'grand',
      modalClass,
      bodyClass: 'taif-currency-management-modal__body--picker',
      showExpand: true,
      onMount({ body, close }){
        mountCurrencyPicker(body, {
          mode,
          onChoose(code){
            if(typeof onChoose !== 'function') return;
            onChoose(code, close);
          }
        });
      }
    });
  }

  function openSingleCurrencyPicker(){
    openCurrencyPickerModal({
      title: 'تعديل عملة فردي',
      subtitle: 'اختر عملة واحدة لفتح نافذة التعديل الخاصة بها',
      mode: 'edit',
      modalClass: 'taif-currency-management-modal--currency-picker taif-currency-management-modal--single-picker',
      onChoose(code, close){
        replaceModalWindow(close, () => {
          openEditorForCode(code);
        });
      }
    });
  }

  function openDeleteCurrencyPicker(){
    openCurrencyPickerModal({
      title: 'حذف عملة',
      subtitle: 'اختر عملة واحدة لفتح نافذة تأكيد الحذف الخاصة بها',
      mode: 'delete',
      modalClass: 'taif-currency-management-modal--currency-picker taif-currency-management-modal--delete-picker',
      onChoose(code, close){
        replaceModalWindow(close, () => {
          openDeleteConfirm(code);
        });
      }
    });
  }

  function openDeleteConfirm(code){
    const state = readState();
    const currency = state.currencies.find((item) => item.code === code);
    if(!currency || currency.code === 'USD'){
      showToast('لا يمكن حذف هذه العملة.', 'danger');
      return;
    }

    const questionDialog = TAIF?.ui?.questionDialog;
    const flagMarkup = createFlagImageMarkup(currency, { className: 'taif-question-dialog__card-flag-image' });
    const cardHtml = questionDialog && typeof questionDialog.createCardMarkup === 'function'
      ? questionDialog.createCardMarkup({
          title:currency.name,
          subtitle:currency.code,
          meta:['إدارة العملات'],
          avatarHtml:flagMarkup,
          tone:'danger',
          className:'taif-question-dialog__card--currency'
        })
      : `
        <div class="taif-question-dialog__card taif-question-dialog__card--currency" data-taif-question-card="true">
          <span class="taif-question-dialog__card-avatar taif-question-dialog__card-avatar--danger" aria-hidden="true">${flagMarkup}</span>
          <div class="taif-question-dialog__card-text">
            <strong>${escapeHtml(currency.name)}</strong>
            <span>${escapeHtml(currency.code)}</span>
          </div>
        </div>
      `;

    if(questionDialog && typeof questionDialog.open === 'function'){
      questionDialog.open({
        owner:'currency-management',
        title:'حذف عملة',
        cardHtml,
        message:'هل أنت متأكد من حذف هذه العملة؟ عند التأكيد سيتم حذفها من إدارة العملات الحالية ولن تبقى ظاهرة في القوائم حتى تعيد إضافتها من جديد.',
        confirmLabel:'تأكيد',
        confirmTone:'danger',
        confirmIcon:'trash',
        className:'taif-question-dialog--currency-management',
        onConfirm(){
          const nextCurrencies = state.currencies.filter((item) => item.code !== currency.code);
          commitCurrencyManagementState(
            { ...state, currencies: nextCurrencies },
            { successMessage: 'تم حذف العملة من إدارة العملات.' }
          );
        }
      });
      return;
    }

    // Official question-dialog is required for destructive confirmations.
    // If it is unavailable, fail closed instead of falling back to a native browser dialog.
    return;
  }

  function bulkBodyMarkup(workingState){
    const rows = computeRows(workingState);
    const bulkRows = rows.filter((row) => !row.isCounterpart);
    const filterText = String(runtime.bulkFilter || '').trim().toUpperCase();
    const visibleRows = bulkRows.filter((row) => {
      if(!filterText) return true;
      return row.code.includes(filterText) || row.name.toUpperCase().includes(filterText);
    });
    function summaryPill(text, modifier = ''){
      return `<span class="currency-management-bulk-toolbar__pill${modifier ? ` ${modifier}` : ''}">${wrapControlTextMarkup(escapeHtml(text))}</span>`;
    }

    function numberInputMarkup({ field, code, label, value, extraClass = '', readOnly = false, locked = false, initialFocus = false }){
      const stateClass = locked
        ? ' currency-management-bulk-input--locked'
        : (readOnly ? ' currency-management-bulk-input--readonly' : '');
      const stateAttributes = locked
        ? 'disabled aria-disabled="true" tabindex="-1"'
        : (readOnly ? 'readonly aria-readonly="true" tabindex="-1"' : '');
      return `
        <div class="currency-management-bulk-card__cell currency-management-bulk-card__cell--input${extraClass ? ` ${extraClass}` : ''}">
          <input
            class="currency-management-bulk-input${stateClass}"
            data-bulk-field="${field}"
            data-code="${code}"
            type="text"
            inputmode="decimal"
            aria-label="${escapeHtml(label)}"
            title="${escapeHtml(label)}"
            data-smart-number-input="true"
            ${initialFocus ? 'data-taif-initial-focus="true"' : ''}
            value="${escapeHtml(String(value))}"
            ${stateAttributes}
          >
        </div>
      `;
    }

    function bulkHeaderCellMarkup({ text = '', extraClass = '', isSpacer = false, fit = {} }){
      const content = isSpacer
        ? '<span class="currency-management-bulk-grid-head__spacer" aria-hidden="true"></span>'
        : createSingleLineHeaderLabel(text, {
            className: 'taif-singleline-fit--bulk',
            min: fit.min ?? 8.1,
            max: fit.max ?? 10.05,
            step: fit.step ?? .15,
            minScale: fit.minScale ?? .88
          });
      return `
        <span class="currency-management-bulk-grid-head__cell${extraClass ? ` ${extraClass}` : ''}">
          ${content}
        </span>
      `;
    }

    const counterpart = getCounterpartCurrencyFromState(sanitizeState(workingState));
    const counterpartDisplayName = getCounterpartDisplayName(counterpart);
    const counterpartBuyLabel = getCounterpartHeaderText(counterpart, 'buy');
    const counterpartSellLabel = getCounterpartHeaderText(counterpart, 'sell');
    const counterpartRatioBuyLabel = getCounterpartRatioHeaderText(counterpart, 'buy');
    const counterpartRatioSellLabel = getCounterpartRatioHeaderText(counterpart, 'sell');
    const baseCurrencyDisplayName = (rows.find((row) => row.isUsd) || {}).name || 'الدولار الأمريكي';
    const bulkHeaderMarkup = visibleRows.length
      ? `
          <div class="currency-management-bulk-grid-head" aria-hidden="true">
            ${bulkHeaderCellMarkup({ text: 'العلم', extraClass: 'currency-management-bulk-grid-head__cell--flag', fit: { min: 10, max: 11.6, minScale: .96 } })}
            ${bulkHeaderCellMarkup({ text: 'الكود', extraClass: 'currency-management-bulk-grid-head__cell--code', fit: { min: 10, max: 11.6, minScale: .96 } })}
            ${bulkHeaderCellMarkup({ text: 'اسم العملة', extraClass: 'currency-management-bulk-grid-head__cell--name', fit: { min: 9.9, max: 11.6, minScale: .95 } })}
            ${bulkHeaderCellMarkup({ text: 'أزواج العملات', extraClass: 'currency-management-bulk-grid-head__cell--pair', fit: { min: 9.5, max: 11.4, minScale: .93 } })}
            ${bulkHeaderCellMarkup({ text: counterpartBuyLabel, extraClass: 'currency-management-bulk-grid-head__cell--buy', fit: { min: 9.3, max: 11.3, minScale: .92 } })}
            ${bulkHeaderCellMarkup({ text: counterpartSellLabel, extraClass: 'currency-management-bulk-grid-head__cell--sell', fit: { min: 9.3, max: 11.3, minScale: .92 } })}
            ${bulkHeaderCellMarkup({ text: counterpartRatioBuyLabel, extraClass: 'currency-management-bulk-grid-head__cell--ratio-buy', fit: { min: 9.4, max: 11.3, minScale: .92 } })}
            ${bulkHeaderCellMarkup({ text: counterpartRatioSellLabel, extraClass: 'currency-management-bulk-grid-head__cell--ratio-sell', fit: { min: 9.4, max: 11.3, minScale: .92 } })}
          </div>
        `
      : '';

    const cardsMarkup = visibleRows.length
      ? visibleRows.map((row, index) => {
          const buyValue = formatCurrencyRateInputValue(row.displayBuy ?? row.buy, row.displayBuyText, row.fieldDecimals?.buy ?? row.counterpartDecimals ?? row.decimals);
          const sellValue = formatCurrencyRateInputValue(row.displaySell ?? row.sell, row.displaySellText, row.fieldDecimals?.sell ?? row.counterpartDecimals ?? row.decimals);
          const buySellReadOnly = row.isCounterpart || row.counterpartPricingLocked;
          const ratioBuyValue = formatCurrencyRateInputValue(row.ratioBuy, row.ratioBuyText, row.fieldDecimals?.ratioBuy ?? row.currencyDecimals ?? row.decimals);
          const ratioSellValue = formatCurrencyRateInputValue(row.ratioSell, row.ratioSellText, row.fieldDecimals?.ratioSell ?? row.currencyDecimals ?? row.decimals);
          const ratioBuyInput = numberInputMarkup({ field: 'ratioBuy', code: row.code, label: getUsdPairFieldLabel(row.code, row.usdConvention, 'buy'), value: ratioBuyValue, extraClass: 'currency-management-bulk-card__cell--ratio currency-management-bulk-card__cell--ratio-buy', locked: row.isUsd });
          const ratioSellInput = numberInputMarkup({ field: 'ratioSell', code: row.code, label: getUsdPairFieldLabel(row.code, row.usdConvention, 'sell'), value: ratioSellValue, extraClass: 'currency-management-bulk-card__cell--ratio currency-management-bulk-card__cell--ratio-sell', locked: row.isUsd });

          return `
            <article class="currency-management-bulk-card${row.isUsd ? ' currency-management-bulk-card--usd' : ''}" data-code="${row.code}">
              <div class="currency-management-bulk-card__row">
                <div class="currency-management-bulk-card__cell currency-management-bulk-card__cell--flag">
                  <span class="currency-management-bulk-card__flag" aria-hidden="true">${createFlagImageMarkup(row, { className: 'currency-management-bulk-card__flag-image' })}</span>
                </div>
                <div class="currency-management-bulk-card__cell currency-management-bulk-card__cell--code">
                  <span class="currency-management-bulk-card__code">${wrapControlTextMarkup(escapeHtml(row.code), 'taif-control-text--ltr')}</span>
                </div>
                <div class="currency-management-bulk-card__cell currency-management-bulk-card__cell--name">
                  <div class="currency-management-bulk-card__name-wrap">
                    <span class="currency-management-bulk-card__name">${escapeHtml(row.name)}</span>
                  </div>
                </div>
                <div class="currency-management-bulk-card__cell currency-management-bulk-card__cell--pair">
                  <span class="currency-management-bulk-card__pair-badge" dir="ltr">${wrapControlTextMarkup(renderPairBadgeMarkup(row.usdPairLabel || row.usdPairId || 'USD/USD'), 'taif-control-text--ltr taif-control-text--pair')}</span>
                </div>
                ${numberInputMarkup({ field: 'buy', code: row.code, label: getDerivedPairFieldLabel(row.code, counterpart.code, 'buy'), value: buyValue, extraClass: 'currency-management-bulk-card__cell--buy', readOnly: buySellReadOnly, initialFocus: index === 0 })}
                ${numberInputMarkup({ field: 'sell', code: row.code, label: getDerivedPairFieldLabel(row.code, counterpart.code, 'sell'), value: sellValue, extraClass: 'currency-management-bulk-card__cell--sell', readOnly: buySellReadOnly })}
                ${ratioBuyInput}
                ${ratioSellInput}
              </div>
            </article>
          `;
        }).join('')
      : `<div class="currency-management-empty currency-management-empty--bulk">لا توجد نتائج مطابقة داخل نافذة تعديل كافة العملات.</div>`;

    return `
      <div class="currency-management-bulk-panel">
        <div class="currency-management-bulk-scrollarea">
          <div class="currency-management-bulk-sticky-stack">
            <div class="currency-management-bulk-toolbar">
              <div class="currency-management-search-wrap currency-management-search-wrap--grand currency-management-bulk-toolbar__search">
                <span class="currency-management-search-icon">${createButtonIcon('search')}</span>
                <input id="currency-management-bulk-search" class="currency-management-search-input currency-management-search-input--grand" type="text" placeholder="ابحث بالكود أو الاسم" value="${escapeHtml(runtime.bulkFilter || '')}">
                <button id="currency-management-bulk-search-clear" class="currency-management-search-clear currency-management-search-clear--grand" type="button" data-taif-clear-control="true" aria-label="مسح البحث" ${runtime.bulkFilter ? '' : 'hidden'}>${createButtonIcon('close')}</button>
              </div>
              <div class="currency-management-bulk-toolbar__summary">
                ${summaryPill(`عملة التسعير المتقاطع: ${counterpartDisplayName}`, 'currency-management-bulk-toolbar__pill--usd')}
                ${summaryPill(`العملة المحورية: ${baseCurrencyDisplayName}`, 'currency-management-bulk-toolbar__pill--base')}
              </div>
            </div>
            ${bulkHeaderMarkup}
          </div>

          <div class="currency-management-bulk-list" role="list">
            ${cardsMarkup}
          </div>
        </div>

        <div class="currency-management-modal-actions currency-management-modal-actions--grand currency-management-modal-actions--dock" data-taif-footer-actions="true">
          ${buttonMarkup({ action: 'cancel', label: 'إغلاق', tone: 'ghost', icon: 'close' })}
          ${buttonMarkup({ action: 'save-bulk', label: 'حفظ كل التعديلات', tone: 'primary', icon: 'settings' })}
        </div>
      </div>
    `;
  }

  function openBulkEditor(){
    let workingState = readState();
    cleanupBulkHeaderFit();

    openModal({
      title: BULK_EDITOR_TITLE,
      subtitle: 'منصة تحرير جماعي دقيقة وحديثة لأسعار ونسب العملات',
      bodyHtml: bulkBodyMarkup(workingState),
      size: 'lg',
      variant: 'grand',
      onMount({ modal, body, close, registerCleanup }){
        modal.classList.add('taif-currency-management-modal--bulk-editor');
        modal.dataset.cascadeTopShift = '0';
        registerCleanup(() => cleanupBulkHeaderFit());

        function renderBulk(){
          cleanupBulkHeaderFit();
          const previousScrollRoot = body.querySelector('.currency-management-bulk-list') || body.querySelector('.currency-management-bulk-scrollarea') || body;
          const scrollTop = previousScrollRoot ? previousScrollRoot.scrollTop : 0;
          const activeElement = body.contains(document.activeElement) ? document.activeElement : null;
          let focusTarget = null;
          let selectionStart = null;
          let selectionEnd = null;

          if(activeElement){
            if(activeElement.id){
              focusTarget = { type: 'id', id: activeElement.id };
            }else if(activeElement.dataset && activeElement.dataset.bulkField && activeElement.dataset.code){
              focusTarget = { type: 'field', code: activeElement.dataset.code, field: activeElement.dataset.bulkField };
            }

            if(typeof activeElement.selectionStart === 'number'){
              selectionStart = activeElement.selectionStart;
              selectionEnd = activeElement.selectionEnd;
            }
          }

          body.innerHTML = bulkBodyMarkup(workingState);
          mountSmartNumericInputs(body);
          runtime.bulkHeaderFitCleanup = typeof mountSingleLineTextFit === 'function'
            ? mountSingleLineTextFit(body, '.taif-singleline-fit--bulk')
            : null;

          requestAnimationFrame(() => {
            const nextScrollRoot = body.querySelector('.currency-management-bulk-list') || body.querySelector('.currency-management-bulk-scrollarea') || body;
            if(nextScrollRoot){
              nextScrollRoot.scrollTop = scrollTop;
            }
            if(!focusTarget) return;

            let nextActive = null;
            if(focusTarget.type === 'id'){
              nextActive = body.querySelector(`#${focusTarget.id}`);
            }else if(focusTarget.type === 'field'){
              nextActive = body.querySelector(`[data-code="${focusTarget.code}"][data-bulk-field="${focusTarget.field}"]`);
            }

            if(nextActive){
              nextActive.focus({ preventScroll: true });
              if(typeof selectionStart === 'number' && typeof nextActive.setSelectionRange === 'function'){
                const end = typeof selectionEnd === 'number' ? selectionEnd : selectionStart;
                nextActive.setSelectionRange(selectionStart, end);
              }
            }
          });

          const searchInput = body.querySelector('#currency-management-bulk-search');
          const clearButton = body.querySelector('#currency-management-bulk-search-clear');
          const handleBulkSearchChange = (nextFilter) => {
            const pendingIssue = getFirstBulkValidationIssue(body, workingState);
            if(pendingIssue){
              if(searchInput instanceof HTMLInputElement){
                searchInput.value = runtime.bulkFilter || '';
              }
              showBulkFieldsValidationError(body, pendingIssue.code, pendingIssue.fields, pendingIssue.message);
              return;
            }
            runtime.bulkFilter = String(nextFilter || '');
            renderBulk();
          };
          searchInput?.addEventListener('input', (event) => {
            handleBulkSearchChange(event.target.value || '');
          });
          clearButton?.addEventListener('click', () => {
            handleBulkSearchChange('');
          });

          body.querySelector('[data-currency-management-action="cancel"]').addEventListener('click', close);
          body.querySelector('[data-currency-management-action="save-bulk"]').addEventListener('click', () => {
            const issue = getFirstBulkValidationIssue(body, workingState);
            if(issue){
              showBulkFieldsValidationError(body, issue.code, issue.fields, issue.message);
              return;
            }

            const nextState = sanitizeState(workingState);
            commitCurrencyManagementState(nextState, {
              close,
              successMessage: 'تم حفظ جميع تعديلات إدارة العملات.'
            });
          });

          body.querySelectorAll('[data-bulk-field]').forEach((input) => {
            function syncBulkFieldValue(){
              const code = input.dataset.code || '';
              const field = input.dataset.bulkField || '';
              const currency = workingState.currencies.find((item) => item.code === code);
              if(!currency) return;

              if(field === 'ratioBuy' || field === 'ratioSell'){
                const ratioBuyState = readBulkFieldState(body, code, 'ratioBuy');
                const ratioSellState = readBulkFieldState(body, code, 'ratioSell');
                if(ratioBuyState.isPositive && ratioSellState.isPositive && ratioBuyState.numericValue <= ratioSellState.numericValue){
                  currency.ratioBuy = ratioBuyState.numericValue;
                  currency.ratioSell = ratioSellState.numericValue;
                  currency.ratioBuyText = ratioBuyState.numericText;
                  currency.ratioSellText = ratioSellState.numericText;
                  currency.rateEditedAt = Date.now();
                }
                return;
              }

              if(field === 'buy' || field === 'sell'){
                const buyState = readBulkFieldState(body, code, 'buy');
                const sellState = readBulkFieldState(body, code, 'sell');
                if(buyState.isPositive && sellState.isPositive && buyState.numericValue <= sellState.numericValue && typeof setCounterpartCrossQuote === 'function'){
                  workingState = setCounterpartCrossQuote(workingState, code, {
                    buy: buyState.numericValue,
                    sell: sellState.numericValue,
                    buyText: buyState.numericText,
                    sellText: sellState.numericText
                  });
                  const updatedCurrency = workingState.currencies.find((item) => item.code === code);
                  if(updatedCurrency) updatedCurrency.rateEditedAt = Date.now();
                }
              }
            }

            function rowHasValidationIssue(){
              const code = input.dataset.code || '';
              const flags = collectBulkRowValidationFlags(body, code);
              return Object.values(flags).some((flag) => !flag);
            }

            input.addEventListener('input', () => {
              syncBulkFieldValue();
              refreshBulkValidationState(body, {
                triggerCode: input.dataset.code || '',
                triggerField: input.dataset.bulkField || ''
              });
            });

            input.addEventListener('change', () => {
              syncBulkFieldValue();
              refreshBulkValidationState(body, {
                triggerCode: input.dataset.code || '',
                triggerField: input.dataset.bulkField || ''
              });
              if(!rowHasValidationIssue()){
                workingState = sanitizeState(workingState);
                renderBulk();
              }
            });
          });
        }

        renderBulk();
      }
    });
  }

  function cleanupView(){
    cleanupCounterpartToolbarPicker();
    cleanupTopbarAdaptiveFit();
    cleanupMainHeaderFit();
    cleanupBulkHeaderFit();
    dismissOverlays();
    clearSelection({ rerender: false });
    clearTimerSlot(runtime, 'toastTimer');
    const toast = document.querySelector('.currency-management-toast');
    if(toast) toast.remove();
    runtime.panel = null;
    runtime.filter = '';
    runtime.bulkFilter = '';
    runtime.selectedCode = null;
  }
  Object.assign(feature, {
    renderCurrencyManagement,
    openUsdEditor,
    openCurrencyEditor,
    openSingleCurrencyPicker,
    openDeleteCurrencyPicker,
    openDeleteConfirm,
    openBulkEditor
  });

  TAIF.currencyManagement = TAIF.currencyManagement || {};
  TAIF.currencyManagement.readState = readState;
  TAIF.currencyManagement.writeState = writeState;
  TAIF.currencyManagement.resetState = resetState;
  TAIF.currencyManagement.computeRows = computeRows;
  TAIF.currencyManagement.getCounterpartCurrency = getCounterpartCurrency;
  TAIF.currencyManagement.getCounterpartOptions = feature.getCounterpartOptions;
  TAIF.currencyManagement.auditState = feature.auditState;
  TAIF.currencyManagement.getUsdManualQuote = feature.getUsdManualQuote;
  TAIF.currencyManagement.dismissOverlays = dismissOverlays;
  TAIF.currencyManagement.clearSelection = clearSelection;
  TAIF.currencyManagement.refresh = refreshView;
  TAIF.currencyManagement.render = renderCurrencyManagement;
  TAIF.currencyManagement.openUsdEditor = openUsdEditor;
  TAIF.currencyManagement.openCurrencyEditor = openCurrencyEditor;
  TAIF.currencyManagement.openSingleCurrencyPicker = openSingleCurrencyPicker;
  TAIF.currencyManagement.openDeleteCurrencyPicker = openDeleteCurrencyPicker;
  TAIF.currencyManagement.openDeleteConfirm = openDeleteConfirm;
  TAIF.currencyManagement.openBulkEditor = openBulkEditor;
  TAIF.currencyManagement.cleanup = cleanupView;

  TAIF.registerViewCleanup('currency-management', cleanupView);
  TAIF.registerViewRenderer('currency-management', ({ panel }) => {
    renderCurrencyManagement(panel);
  });
})();
