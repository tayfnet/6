(()=>{
  /*
   * TAIF Entries & Vouchers navigator helpers.
   * Keeps voucher-window navigation state isolated from the main view controller.
   */
  const TAIF = window.TAIF;
  const cloneDraftValue = typeof TAIF?.core?.utils?.clone === 'function'
    ? TAIF.core.utils.clone
    : function(value){
      if(value == null) return value;
      try{
        return JSON.parse(JSON.stringify(value));
      }catch{
        return value;
      }
    };
  const feature = TAIF.entriesVouchersFeature || (TAIF.entriesVouchersFeature = {});
  const {
    getSheet,
    getVoucherRecordGroups,
    buildVoucherDraftFromRecordGroup,
    clearSheetValidationState
  } = feature;

  function ensureSheetNavigator(sheet){
    if(!sheet || typeof sheet !== 'object') return null;
    if(!sheet.navigator || typeof sheet.navigator !== 'object'){
      sheet.navigator = {
        lookupValue: '',
        currentGroupIndex: null,
        baselineDraft: cloneDraftValue(sheet.draft)
      };
    }
    if(typeof sheet.navigator.lookupValue !== 'string') sheet.navigator.lookupValue = '';
    if(!Object.prototype.hasOwnProperty.call(sheet.navigator, 'currentGroupIndex')){
      sheet.navigator.currentGroupIndex = null;
    }
    if(!sheet.navigator.baselineDraft){
      sheet.navigator.baselineDraft = cloneDraftValue(sheet.draft);
    }
    return sheet.navigator;
  }

  function syncSheetNavigatorBaseline(sheetId){
    const sheet = getSheet(sheetId);
    const navigator = ensureSheetNavigator(sheet);
    if(!sheet || !navigator || navigator.currentGroupIndex !== null) return;
    navigator.baselineDraft = cloneDraftValue(sheet.draft);
  }

  function restoreSheetNavigatorBaseline(sheetId){
    const sheet = getSheet(sheetId);
    const navigator = ensureSheetNavigator(sheet);
    if(!sheet || !navigator) return false;
    sheet.draft = cloneDraftValue(navigator.baselineDraft);
    navigator.currentGroupIndex = null;
    navigator.lookupValue = '';
    clearSheetValidationState(sheetId);
    return true;
  }

  function normalizeVoucherLookupDigits(value){
    return String(value || '')
      .replace(/[٠-٩]/g, (digit) => String(digit.charCodeAt(0) - 0x0660))
      .replace(/[۰-۹]/g, (digit) => String(digit.charCodeAt(0) - 0x06F0));
  }

  function normalizeVoucherPageLookup(value){
    return normalizeVoucherLookupDigits(value).replace(/\D+/g, '').trim();
  }

  function resolveVoucherGroupIndexFromLookup(sheet, lookupValue){
    if(!sheet) return -1;
    const groups = getVoucherRecordGroups(sheet.type);
    const normalizedLookup = normalizeVoucherPageLookup(lookupValue);
    if(!normalizedLookup) return -1;

    const lookupNumber = Number(normalizedLookup);
    if(!Number.isFinite(lookupNumber) || lookupNumber < 1 || lookupNumber > groups.length) return -1;
    return lookupNumber - 1;
  }

  function loadSheetVoucherGroup(sheetId, targetIndex){
    const sheet = getSheet(sheetId);
    if(!sheet) return false;
    const navigator = ensureSheetNavigator(sheet);
    const groups = getVoucherRecordGroups(sheet.type);

    if(targetIndex == null){
      return restoreSheetNavigatorBaseline(sheetId);
    }
    if(!Number.isInteger(targetIndex) || targetIndex < 0 || targetIndex >= groups.length) return false;

    const targetGroup = groups[targetIndex];
    sheet.draft = buildVoucherDraftFromRecordGroup(sheet.type, targetGroup);
    navigator.currentGroupIndex = targetIndex;
    navigator.lookupValue = String(targetIndex + 1);
    clearSheetValidationState(sheetId);
    return true;
  }

  function navigateSheetVoucher(sheetId, direction){
    const sheet = getSheet(sheetId);
    if(!sheet) return false;
    const navigator = ensureSheetNavigator(sheet);
    const groups = getVoucherRecordGroups(sheet.type);
    if(!groups.length) return false;

    if(direction === 'prev' || direction === 'prev10'){
      const step = direction === 'prev10' ? 10 : 1;
      const effectiveIndex = navigator.currentGroupIndex == null ? groups.length : navigator.currentGroupIndex;
      const targetIndex = Math.max(0, effectiveIndex - step);
      if(targetIndex === effectiveIndex) return false;
      return loadSheetVoucherGroup(sheetId, targetIndex);
    }

    if(direction === 'next'){
      if(navigator.currentGroupIndex == null) return false;
      if(navigator.currentGroupIndex >= groups.length - 1){
        return restoreSheetNavigatorBaseline(sheetId);
      }
      return loadSheetVoucherGroup(sheetId, navigator.currentGroupIndex + 1);
    }

    if(direction === 'next10'){
      if(navigator.currentGroupIndex == null) return false;
      const targetIndex = Math.min(groups.length - 1, navigator.currentGroupIndex + 10);
      if(targetIndex === navigator.currentGroupIndex) return false;
      return loadSheetVoucherGroup(sheetId, targetIndex);
    }

    return false;
  }

  function jumpSheetToVoucher(sheetId, lookupValue){
    const sheet = getSheet(sheetId);
    if(!sheet) return false;
    const navigator = ensureSheetNavigator(sheet);
    navigator.lookupValue = normalizeVoucherPageLookup(lookupValue);

    if(!navigator.lookupValue){
      return restoreSheetNavigatorBaseline(sheetId);
    }

    const targetIndex = resolveVoucherGroupIndexFromLookup(sheet, navigator.lookupValue);
    if(targetIndex < 0) return false;
    return loadSheetVoucherGroup(sheetId, targetIndex);
  }

  Object.assign(feature, {
  ensureSheetNavigator,
  syncSheetNavigatorBaseline,
  normalizeVoucherPageLookup,
  navigateSheetVoucher,
  jumpSheetToVoucher
});

})();
