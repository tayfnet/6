(()=>{
  /*
   * TAIF Entries & Vouchers interaction helpers.
   * DOM helpers, scroll snapshots, field restore, and account autocomplete plumbing.
   */
  const TAIF = window.TAIF;
  const { escapeSelectorValue, focusElementWithoutScroll, setDisclosureOpenState } = TAIF.core.utils;
  const feature = TAIF.entriesVouchersFeature || (TAIF.entriesVouchersFeature = {});
  const {
    runtime,
    getEntriesModalLayer,
    getSheet,
    getSheetIdFromNode,
    updateSheetMovementField,
    normalizeAccountLookupText,
    buildAccountLookupLabel,
    searchAccounts,
    readAccountCatalog,
    getOpeningBalanceAccountCatalog,
    findAccountByLookupQuery,
    syncSheetNavigatorBaseline
  } = feature;

  const SHEET_HOST_SELECTOR = '[data-entry-sheet-id]';
  const SHEET_FIELD_SELECTOR = '[data-field]';
  const SHEET_CANVAS_SELECTOR = '.entries-sheet__canvas[data-entry-sheet-canvas="true"]';

  function getModalLayer(){
    return getEntriesModalLayer(false);
  }

  function findSheetHost(scope, sheetId){
    if(!(scope instanceof HTMLElement) || !sheetId) return null;
    return scope.querySelector(`${SHEET_HOST_SELECTOR}[data-entry-sheet-id="${escapeSelectorValue(sheetId)}"]`);
  }

  function findSheetCanvas(scope, sheetId){
    if(!(scope instanceof HTMLElement) || !sheetId) return null;
    return scope.querySelector(`${SHEET_CANVAS_SELECTOR}[data-entry-sheet-id="${escapeSelectorValue(sheetId)}"]`)
      || scope.querySelector(`${SHEET_HOST_SELECTOR}[data-entry-sheet-id="${escapeSelectorValue(sheetId)}"] ${SHEET_CANVAS_SELECTOR}`);
  }

  function findSheetFieldControl(scope, sheetId, fieldName, movementId = ''){
    const host = findSheetHost(scope, sheetId);
    if(!(host instanceof HTMLElement) || !fieldName) return null;
    const movementSelector = movementId ? `[data-movement-id="${escapeSelectorValue(movementId)}"]` : ':not([data-movement-id])';
    return host.querySelector(`${SHEET_FIELD_SELECTOR}[data-field="${escapeSelectorValue(fieldName)}"]${movementSelector}`);
  }

  function snapshotModalCanvasPositions(){
    const snapshot = {};
    const layer = getModalLayer();
    layer?.querySelectorAll(SHEET_CANVAS_SELECTOR).forEach((canvas) => {
      const sheetId = getSheetIdFromNode(canvas);
      if(!sheetId || !(canvas instanceof HTMLElement)) return;
      snapshot[sheetId] = {
        scrollTop: canvas.scrollTop,
        scrollLeft: canvas.scrollLeft
      };
    });
    return snapshot;
  }

  function restoreModalCanvasPositions(snapshot = {}){
    const layer = getModalLayer();
    if(!(layer instanceof HTMLElement)) return;
    Object.entries(snapshot || {}).forEach(([sheetId, position]) => {
      const canvas = findSheetCanvas(layer, sheetId);
      if(!(canvas instanceof HTMLElement)) return;
      if(Number.isFinite(position?.scrollTop)) canvas.scrollTop = Number(position.scrollTop);
      if(Number.isFinite(position?.scrollLeft)) canvas.scrollLeft = Number(position.scrollLeft);
    });
  }

  function captureFieldSelection(control){
    if(!(control instanceof HTMLElement) || !control.hasAttribute('data-field')) return null;
    return {
      sheetId: getSheetIdFromNode(control),
      fieldName: String(control.getAttribute('data-field') || '').trim(),
      movementId: String(control.getAttribute('data-movement-id') || '').trim(),
      selectionStart: typeof control.selectionStart === 'number' ? control.selectionStart : null,
      selectionEnd: typeof control.selectionEnd === 'number' ? control.selectionEnd : null,
      scrollTop: typeof control.scrollTop === 'number' ? control.scrollTop : null
    };
  }

  function restoreFieldSelection(selection){
    if(!selection || !selection.sheetId || !selection.fieldName) return false;
    const layer = getModalLayer();
    if(!(layer instanceof HTMLElement)) return false;
    const control = findSheetFieldControl(layer, selection.sheetId, selection.fieldName, selection.movementId || '');
    if(!(control instanceof HTMLElement)) return false;

    if(selection.scrollIntoView){
      control.closest('[data-movement-id]')?.scrollIntoView?.({ block: 'nearest' });
    }
    focusElementWithoutScroll(control);

    if((control instanceof HTMLInputElement || control instanceof HTMLTextAreaElement) && typeof control.setSelectionRange === 'function' && typeof selection.selectionStart === 'number'){
      const end = typeof selection.selectionEnd === 'number' ? selection.selectionEnd : selection.selectionStart;
      try{ control.setSelectionRange(selection.selectionStart, end); }catch{}
    }

    if((control instanceof HTMLInputElement || control instanceof HTMLTextAreaElement) && Number.isFinite(selection.scrollTop)){
      control.scrollTop = Number(selection.scrollTop);
    }
    return true;
  }

  function getChoicePickerRoot(control){
    if(!(control instanceof HTMLElement)) return null;
    return control.closest('[data-entry-choice-picker="true"]');
  }

  function getChoicePickerHiddenInput(control){
    const root = getChoicePickerRoot(control);
    if(!(root instanceof HTMLElement)) return null;
    const input = root.querySelector('.entries-voucher-choice-picker__value-input');
    return input instanceof HTMLInputElement ? input : null;
  }

  function readFieldControlValue(control){
    if(control instanceof HTMLInputElement || control instanceof HTMLTextAreaElement){
      return control.value;
    }
    if(control instanceof HTMLButtonElement && control.matches('[data-entry-choice-trigger="true"][data-field]')){
      const hiddenInput = getChoicePickerHiddenInput(control);
      return hiddenInput instanceof HTMLInputElement ? hiddenInput.value : '';
    }
    return '';
  }

  function getAccountSearchState(){
    if(!runtime.accountSearch || typeof runtime.accountSearch !== 'object'){
      runtime.accountSearch = { sheetId: '', movementId: '' };
    }
    return runtime.accountSearch;
  }

  function setAccountSearchState(sheetId = '', movementId = ''){
    const state = getAccountSearchState();
    state.sheetId = String(sheetId || '');
    state.movementId = String(movementId || '');
  }

  function clearAccountSearchState(sheetId = '', movementId = ''){
    const state = getAccountSearchState();
    if(sheetId && state.sheetId && state.sheetId !== sheetId) return;
    if(movementId && state.movementId && state.movementId !== movementId) return;
    state.sheetId = '';
    state.movementId = '';
  }

  function getCounterpartAccountOptions(sheetId){
    const sheet = getSheet(sheetId);
    if(!sheet) return [];
    const sheetType = String(sheet?.type || '').trim();
    if(sheetType === 'settlement') return readAccountCatalog().filter(Boolean);
    if(sheetType === 'opening'){
      const openingCatalog = typeof getOpeningBalanceAccountCatalog === 'function'
        ? getOpeningBalanceAccountCatalog(readAccountCatalog())
        : readAccountCatalog();
      return openingCatalog.filter(Boolean);
    }
    const cashAccountNo = String(sheet?.draft?.cashAccountNo || '').trim();
    return readAccountCatalog().filter((account) => account && account.accountNo !== cashAccountNo);
  }

  function getAccountSearchRoot(control){
    if(!(control instanceof HTMLElement)) return null;
    return control.closest('[data-entry-account-search-root="true"]') || control.closest('.entries-account-search');
  }

  function resolveAccountSearchPopoverNode(root){
    if(!(root instanceof HTMLElement)) return null;
    const floatingPopover = root.__taifEntriesAccountSearchPopover;
    if(floatingPopover instanceof HTMLElement) return floatingPopover;
    const inlinePopover = root.querySelector('.entries-account-search__popover');
    if(inlinePopover instanceof HTMLElement){
      root.__taifEntriesAccountSearchPopover = inlinePopover;
      return inlinePopover;
    }
    return null;
  }

  function getAccountSearchList(controlOrRoot){
    const root = controlOrRoot instanceof HTMLElement && controlOrRoot.matches('[data-entry-account-search-root="true"]')
      ? controlOrRoot
      : getAccountSearchRoot(controlOrRoot);
    return resolveAccountSearchPopoverNode(root);
  }

  function clearFloatingAccountSearchBindings(root){
    if(!(root instanceof HTMLElement)) return;
    const cleanup = root.__taifEntriesAccountSearchFloatingCleanup;
    if(typeof cleanup === 'function'){
      try{ cleanup(); }catch{}
    }
    delete root.__taifEntriesAccountSearchFloatingCleanup;
  }

  function getAccountSearchFloatingHost(control){
    if(!(control instanceof HTMLElement)) return null;
    const directBackdrop = control.closest('.entries-modal-backdrop[data-entry-sheet-id]');
    if(directBackdrop instanceof HTMLElement) return directBackdrop;
    const sheetId = getSheetIdFromNode(control);
    const modalLayer = getModalLayer();
    if(!(modalLayer instanceof HTMLElement) || !sheetId) return null;
    return modalLayer.querySelector(`.entries-modal-backdrop[data-entry-sheet-id="${escapeSelectorValue(sheetId)}"]`);
  }

  function syncFloatingAccountSearchPopover(control){
    if(!(control instanceof HTMLInputElement)) return false;
    const root = getAccountSearchRoot(control);
    const list = resolveAccountSearchPopoverNode(root);
    const host = root instanceof HTMLElement ? root.__taifEntriesAccountSearchFloatingHost : null;
    if(!(root instanceof HTMLElement) || !(list instanceof HTMLElement) || !(host instanceof HTMLElement) || !list.classList.contains('entries-account-search__popover--floating')) return false;

    const controlRect = control.getBoundingClientRect();
    const rootRect = root.getBoundingClientRect();
    const hostRect = host.getBoundingClientRect();
    const availableWidth = Math.max(180, Math.round(hostRect.width) - 24);
    const desiredWidth = Math.max(Math.round(controlRect.width), Math.round(rootRect.width));
    const width = Math.max(180, Math.min(desiredWidth, availableWidth));
    const rawLeft = Math.round(controlRect.left - hostRect.left);
    const left = Math.max(12, Math.min(rawLeft, Math.round(hostRect.width - width - 12)));
    const top = Math.round(controlRect.bottom - hostRect.top + 3);
    const availableBelow = Math.max(112, Math.round(hostRect.bottom - controlRect.bottom - 12));

    list.style.left = `${left}px`;
    list.style.top = `${top}px`;
    list.style.width = `${width}px`;
    list.style.maxHeight = `${Math.min(240, availableBelow)}px`;
    return true;
  }

  function mountFloatingAccountSearchPopover(control){
    if(!(control instanceof HTMLInputElement)) return null;
    const root = getAccountSearchRoot(control);
    const list = resolveAccountSearchPopoverNode(root);
    const host = getAccountSearchFloatingHost(control);
    if(!(root instanceof HTMLElement) || !(list instanceof HTMLElement) || !(host instanceof HTMLElement)) return list;

    if(list.parentElement !== host){
      host.appendChild(list);
    }
    root.__taifEntriesAccountSearchPopover = list;
    root.__taifEntriesAccountSearchFloatingHost = host;
    list.classList.add('entries-account-search__popover--floating');
    list.hidden = false;

    clearFloatingAccountSearchBindings(root);
    const sheetId = getSheetIdFromNode(control);
    const canvas = findSheetCanvas(getModalLayer(), sheetId);
    const scheduleSync = () => {
      window.requestAnimationFrame(() => {
        if(!control.isConnected) return;
        syncFloatingAccountSearchPopover(control);
      });
    };
    canvas?.addEventListener('scroll', scheduleSync, { passive:true });
    window.addEventListener('resize', scheduleSync, { passive:true });
    root.__taifEntriesAccountSearchFloatingCleanup = () => {
      canvas?.removeEventListener('scroll', scheduleSync);
      window.removeEventListener('resize', scheduleSync);
    };

    syncFloatingAccountSearchPopover(control);
    return list;
  }

  function unmountFloatingAccountSearchPopover(controlOrRoot, { remove = false } = {}){
    const root = controlOrRoot instanceof HTMLElement && controlOrRoot.matches('[data-entry-account-search-root="true"]')
      ? controlOrRoot
      : getAccountSearchRoot(controlOrRoot);
    if(!(root instanceof HTMLElement)) return null;
    const list = resolveAccountSearchPopoverNode(root);

    clearFloatingAccountSearchBindings(root);
    delete root.__taifEntriesAccountSearchFloatingHost;

    if(!(list instanceof HTMLElement) || !list.classList.contains('entries-account-search__popover--floating')) return list instanceof HTMLElement ? list : null;

    list.classList.remove('entries-account-search__popover--floating');
    list.style.removeProperty('left');
    list.style.removeProperty('top');
    list.style.removeProperty('width');
    list.style.removeProperty('max-height');

    if(remove){
      list.remove();
      delete root.__taifEntriesAccountSearchPopover;
      return null;
    }

    if(list.parentElement !== root){
      root.appendChild(list);
    }
    root.__taifEntriesAccountSearchPopover = list;
    return list;
  }

  function cleanupFloatingAccountSearchPopovers(scope){
    const host = scope instanceof HTMLElement ? scope : getModalLayer();
    if(!(host instanceof HTMLElement)) return;
    host.querySelectorAll('[data-entry-account-search-root="true"]').forEach((root) => {
      if(!(root instanceof HTMLElement)) return;
      unmountFloatingAccountSearchPopover(root, { remove:true });
      delete root.__taifEntriesAccountSearchPopover;
    });
    host.querySelectorAll('.entries-account-search__popover--floating').forEach((popover) => {
      if(popover instanceof HTMLElement) popover.remove();
    });
  }

  function setAccountSearchExpanded(control, isExpanded){
    if(!(control instanceof HTMLInputElement)) return;
    const root = getAccountSearchRoot(control);
    const list = isExpanded ? mountFloatingAccountSearchPopover(control) : getAccountSearchList(control);
    if(typeof setDisclosureOpenState === 'function'){
      setDisclosureOpenState({ root, popup: list, trigger: control, isOpen: isExpanded });
    }else{
      if(root instanceof HTMLElement) root.classList.toggle('is-open', !!isExpanded);
      if(list instanceof HTMLElement) list.hidden = !isExpanded;
      control.setAttribute('aria-expanded', isExpanded ? 'true' : 'false');
    }
    if(isExpanded){
      syncFloatingAccountSearchPopover(control);
      return;
    }
    unmountFloatingAccountSearchPopover(control);
  }

  function createAccountSearchOptionNode(option, movementId){
    if(!option) return null;
    const button = document.createElement('button');
    button.className = 'entries-account-search__result';
    button.type = 'button';
    button.setAttribute('role', 'option');
    button.setAttribute('data-entry-account-option', 'select');
    button.setAttribute('data-movement-id', String(movementId || ''));
    button.setAttribute('data-entry-account-no', String(option.accountNo || ''));
    button.setAttribute('data-entry-account-label', buildAccountLookupLabel(option));
    button.setAttribute('aria-label', `اختيار الحساب ${buildAccountLookupLabel(option)}`);

    const copy = document.createElement('span');
    copy.className = 'entries-account-search__result-copy';

    const name = document.createElement('span');
    name.className = 'entries-account-search__result-name';
    name.textContent = String(option.name || '');

    const number = document.createElement('span');
    number.className = 'entries-account-search__result-no';
    number.dir = 'ltr';
    number.textContent = String(option.accountNo || '');

    copy.append(name, number);
    button.append(copy);
    return button;
  }

  function clearAccountSearchList(control){
    const list = getAccountSearchList(control);
    if(list instanceof HTMLElement) list.replaceChildren();
    return list instanceof HTMLElement ? list : null;
  }

  function fillAccountSearchList(control, results, movementId){
    const list = clearAccountSearchList(control);
    if(!(list instanceof HTMLElement)) return;

    if(Array.isArray(results) && results.length){
      results.forEach((option) => {
        const node = createAccountSearchOptionNode(option, movementId);
        if(node) list.appendChild(node);
      });
      return;
    }

    const empty = document.createElement('div');
    empty.className = 'entries-account-search__empty';
    empty.textContent = 'لا يوجد حساب مطابق لما كتبته.';
    list.appendChild(empty);
  }

  function getAccountSearchOptionButtons(control){
    const list = getAccountSearchList(control);
    return list instanceof HTMLElement
      ? Array.from(list.querySelectorAll('[data-entry-account-option="select"]'))
      : [];
  }

  function moveAccountSearchOptionFocus(control, direction = 1){
    const buttons = getAccountSearchOptionButtons(control);
    if(!buttons.length) return false;
    const activeElement = document.activeElement;
    const currentIndex = buttons.findIndex((button) => button === activeElement);
    const nextIndex = currentIndex < 0
      ? (direction > 0 ? 0 : buttons.length - 1)
      : (currentIndex + direction + buttons.length) % buttons.length;
    buttons[nextIndex]?.focus();
    return true;
  }

  function commitAccountSearchInput(control){
    if(!(control instanceof HTMLInputElement)) return false;
    const sheetId = getSheetIdFromNode(control);
    const movementId = String(control.getAttribute('data-movement-id') || '').trim();
    if(!sheetId || !movementId) return false;

    const queryValue = control.value || '';
    const selectedAccountNo = String(control.getAttribute('data-selected-account-no') || '').trim();
    const selectedAccountLabel = String(control.getAttribute('data-selected-account-label') || '').trim();
    const keepSelection = !!selectedAccountNo && normalizeAccountLookupText(queryValue) === normalizeAccountLookupText(selectedAccountLabel);
    const currentDraft = getSheet(sheetId)?.draft || null;
    const nextDraft = updateSheetMovementField(sheetId, movementId, {
      counterpartAccountQuery: queryValue,
      counterpartAccountNo: keepSelection ? selectedAccountNo : ''
    });
    const changed = !!nextDraft && nextDraft !== currentDraft;
    if(changed) syncSheetNavigatorBaseline(sheetId);
    return changed;
  }

  function refreshAccountSearchDropdown(control, { activate = false } = {}){
    if(!(control instanceof HTMLInputElement)) return null;
    const sheetId = getSheetIdFromNode(control);
    const movementId = String(control.getAttribute('data-movement-id') || '').trim();
    if(!sheetId || !movementId) return null;

    if(activate) setAccountSearchState(sheetId, movementId);
    commitAccountSearchInput(control);

    const queryValue = String(control.value || '').trim();
    const selectedAccountNo = String(control.getAttribute('data-selected-account-no') || '').trim();
    const selectedAccountLabel = String(control.getAttribute('data-selected-account-label') || '').trim();
    const isSettled = !!selectedAccountNo && normalizeAccountLookupText(queryValue) === normalizeAccountLookupText(selectedAccountLabel);
    const state = getAccountSearchState();
    const isActive = state.sheetId === sheetId && state.movementId === movementId;
    const options = getCounterpartAccountOptions(sheetId);
    const results = queryValue ? searchAccounts(queryValue, options, [], 8) : [];
    const exactMatch = queryValue ? findAccountByLookupQuery(queryValue, options) : null;
    const shouldOpen = !!queryValue && isActive && !isSettled;

    if(shouldOpen){
      fillAccountSearchList(control, results, movementId);
      setAccountSearchExpanded(control, true);
    }else{
      setAccountSearchExpanded(control, false);
      clearAccountSearchList(control);
      if(!queryValue || isSettled) clearAccountSearchState(sheetId, movementId);
    }

    return {
      sheetId,
      movementId,
      queryValue,
      results,
      options,
      exactMatch,
      isSettled
    };
  }

  function closeAccountSearchDropdown(control, { clearState = true } = {}){
    if(!(control instanceof HTMLInputElement)) return;
    setAccountSearchExpanded(control, false);
    clearAccountSearchList(control);
    if(clearState){
      clearAccountSearchState(
        getSheetIdFromNode(control),
        String(control.getAttribute('data-movement-id') || '').trim()
      );
    }
  }

  function finalizeAccountSearch(control){
    if(!(control instanceof HTMLInputElement)) return;
    commitAccountSearchInput(control);
    closeAccountSearchDropdown(control);
  }

  Object.assign(feature, {
  SHEET_FIELD_SELECTOR,
  getModalLayer,
  snapshotModalCanvasPositions,
  restoreModalCanvasPositions,
  captureFieldSelection,
  restoreFieldSelection,
  getChoicePickerHiddenInput,
  readFieldControlValue,
  clearAccountSearchState,
  getCounterpartAccountOptions,
  getAccountSearchList,
  moveAccountSearchOptionFocus,
  refreshAccountSearchDropdown,
  closeAccountSearchDropdown,
  finalizeAccountSearch,
  cleanupFloatingAccountSearchPopovers
});

})();
