(()=>{
  /*
   * TAIF Entries & Vouchers state helpers.
   * Persists records, repairs state integrity, and manages live sheet mutations/window bookkeeping.
   */
  const TAIF = window.TAIF;
  const { clone, readJsonStorage, createStateWriter, storageGet } = TAIF.core.utils;
  const feature = TAIF.entriesVouchersFeature || (TAIF.entriesVouchersFeature = {});
  const {
    STORAGE_KEY,
    VOUCHERS,
    VOUCHER_COUNTER_PREFIXES,
    runtime,
    toText,
    toNumber,
    createDefaultState,
    normalizeAmountInputText,
    normalizeCommissionCode,
    resolveCommissionOption,
    isInteractiveVoucherType,
    createVoucherDraft,
    normalizeVoucherDraft,
    resolveVoucherType,
    createVoucherMovement,
    buildVoucherContext,
    finalizeSettlementDraft,
    readVoucherCatalogs,
    findAccountByNo,
    buildAccountLookupLabel,
    normalizeAccountLookupText
  } = feature;

  function parseVoucherNumberIndex(number, expectedPrefix = ''){
    const safeNumber = toText(number).toUpperCase();
    const safePrefix = toText(expectedPrefix).toUpperCase();
    const match = safeNumber.match(/([A-Z]+)-(\d+)$/);
    if(!match) return Number.NaN;
    if(safePrefix && match[1] !== safePrefix) return Number.NaN;
    return Number(match[2]);
  }

  function isSalesPurchaseGeneratedRecord(record){
    const safeRecord = record && typeof record === 'object' ? record : {};
    const safeId = toText(safeRecord.id);
    if(safeId.startsWith('entry-record-sales-purchase-')) return true;
    if(toText(safeRecord.sourceSalesPurchaseRecordId)) return true;
    if(toText(safeRecord.sourceSalesPurchaseNumber)) return true;
    return false;
  }

  function isVoucherRecordLockedForMutation(record){
    return isSalesPurchaseGeneratedRecord(record);
  }

  function normalizeLines(lines){
    if(!Array.isArray(lines)) return [];
    return lines.map((line) => {
      const item = line && typeof line === 'object' ? line : {};
      return {
        lineNo: Math.max(1, Number(item.lineNo) || 1),
        roleKey: toText(item.roleKey),
        roleLabel: toText(item.roleLabel),
        accountNo: toText(item.accountNo),
        accountName: toText(item.accountName),
        description: toText(item.description),
        debit: toNumber(item.debit, 0),
        credit: toNumber(item.credit, 0),
        side: item.side === 'credit' ? 'credit' : 'debit',
        amount: toNumber(item.amount, 0)
      };
    });
  }

  function normalizeRecordStatus(value){
    const safeValue = String(value || '').trim();
    if(safeValue === 'reversed') return 'reversed';
    return safeValue === 'posted' ? 'posted' : 'draft';
  }

  function getRecordCounterpartName(record){
    const item = record && typeof record === 'object' ? record : {};
    return toText(item.counterpartAccountName || item.counterpartName);
  }

  function getRecordBeneficiaryName(record){
    const item = record && typeof record === 'object' ? record : {};
    return toText(item.partyName || item.beneficiaryName);
  }

  function getRecordPrimaryAmount(record){
    const directAmount = Number(record?.amount) || 0;
    if(directAmount > 0) return directAmount;
    return Array.isArray(record?.lines)
      ? record.lines.reduce((sum, line) => sum + (Number(line?.debit) || 0), 0)
      : 0;
  }

  function getRecordLine(record, matcher){
    const lines = Array.isArray(record?.lines) ? record.lines : [];
    if(typeof matcher !== 'function') return null;
    return lines.find((line) => line && matcher(line)) || null;
  }

  function getRecordPrimaryLine(record){
    const primaryAccountNo = toText(record?.cashAccountNo);
    return getRecordLine(record, (line) => {
      const lineAccountNo = toText(line?.accountNo);
      const roleKey = toText(line?.roleKey);
      if(primaryAccountNo && lineAccountNo === primaryAccountNo) return true;
      return roleKey === 'cash' || roleKey === 'primary';
    });
  }

  function getRecordCounterpartLine(record){
    const counterpartAccountNo = toText(record?.counterpartAccountNo);
    return getRecordLine(record, (line) => {
      const lineAccountNo = toText(line?.accountNo);
      const roleKey = toText(line?.roleKey);
      if(counterpartAccountNo && lineAccountNo === counterpartAccountNo) return true;
      return roleKey === 'counterpart';
    });
  }

  function getRecordDebitLine(record){
    return getRecordLine(record, (line) => line?.side !== 'credit' && (Number(line?.debit) || Number(line?.amount) || 0) > 0);
  }

  function getRecordCreditLine(record){
    return getRecordLine(record, (line) => line?.side === 'credit' || (Number(line?.credit) || 0) > 0);
  }

  function inferRecordPrimarySide(record){
    const primaryLine = getRecordPrimaryLine(record);
    if(primaryLine) return primaryLine.side === 'credit' ? 'credit' : 'debit';
    const type = resolveVoucherType(record?.type);
    if(type === 'payment') return 'credit';
    if(type === 'receipt') return 'debit';
    return 'debit';
  }

  function buildRecordAccountDescriptor(accountNo = '', accountName = ''){
    return {
      accountNo: toText(accountNo),
      accountName: toText(accountName)
    };
  }
  function buildRecordNotes(record){
    const description = toText(record?.description);
    const sourceNumber = toText(record?.sourceSalesPurchaseNumber).toUpperCase();
    const secondary = sourceNumber
      ? `مرتبط بفاتورة شراء/مبيع ${sourceNumber}`
      : '';
    return {
      primary: description || '—',
      secondary
    };
  }

  function getOpeningRecordLines(record){
    return Array.isArray(record?.lines) ? record.lines : [];
  }


  function buildOpeningAggregateAccountDescriptor(lines, side = 'debit'){
    const safeLines = (Array.isArray(lines) ? lines : []).filter((line) => {
      const debit = Number(line?.debit) || 0;
      const credit = Number(line?.credit) || 0;
      return side === 'credit' ? credit > 0 : debit > 0;
    });
    if(!safeLines.length) return buildRecordAccountDescriptor('', '');
    const firstLine = safeLines[0];
    const extraCount = Math.max(0, safeLines.length - 1);
    const accountName = extraCount > 0
      ? `${toText(firstLine?.accountName || firstLine?.accountNo)} +${extraCount}`
      : toText(firstLine?.accountName || firstLine?.accountNo);
    return buildRecordAccountDescriptor(firstLine?.accountNo, accountName);
  }


  function buildOpeningRecordNotes(record, lines){
    const description = toText(record?.description);
    if(description){
      return {
        primary: description,
        secondary: lines.length > 1 ? `عدد السطور: ${lines.length}` : ''
      };
    }
    return {
      primary: lines.length > 1 ? `أرصدة افتتاحية بعدد ${lines.length} سطور` : 'رصيد افتتاحي',
      secondary: ''
    };
  }

  function buildRecordPresentation(record){
    const safeType = resolveVoucherType(record?.type);
    const counterpartName = getRecordCounterpartName(record);

    if(safeType === 'opening'){
      const lines = getOpeningRecordLines(record);
      const debitTotal = lines.reduce((sum, line) => sum + (Number(line?.debit) || 0), 0);
      const creditTotal = lines.reduce((sum, line) => sum + (Number(line?.credit) || 0), 0);
      return {
        noticeNo: toText(record?.number),
        type: safeType,
        typeLabel: toText((VOUCHERS[record?.type] && VOUCHERS[record.type].label) || record?.type),
        date: toText(record?.date),
        collectedAmount: debitTotal,
        owedAmount: creditTotal,
        fromAccount: buildOpeningAggregateAccountDescriptor(lines, 'debit'),
        beneficiaryName: '—',
        toAccount: buildOpeningAggregateAccountDescriptor(lines, 'credit'),
        notes: buildOpeningRecordNotes(record, lines),
        status: normalizeRecordStatus(record?.status),
        currency: toText(record?.currency, 'USD') || 'USD',
        createdAt: Number(record?.createdAt) || 0,
        description: toText(record?.description),
        primarySide: 'debit',
        primaryLine: getRecordDebitLine(record),
        counterpartLine: getRecordCreditLine(record)
      };
    }

    if(safeType === 'settlement'){
      const amount = getRecordPrimaryAmount(record);
      const debitLine = getRecordDebitLine(record);
      const creditLine = getRecordCreditLine(record);
      return {
        noticeNo: toText(record?.number),
        type: safeType,
        typeLabel: toText((VOUCHERS[record?.type] && VOUCHERS[record.type].label) || record?.type),
        date: toText(record?.date),
        collectedAmount: amount,
        owedAmount: 0,
        fromAccount: creditLine
          ? buildRecordAccountDescriptor(creditLine.accountNo, creditLine.accountName)
          : buildRecordAccountDescriptor(record?.counterpartAccountNo, counterpartName),
        beneficiaryName: getRecordBeneficiaryName(record),
        toAccount: debitLine
          ? buildRecordAccountDescriptor(debitLine.accountNo, debitLine.accountName)
          : buildRecordAccountDescriptor(record?.cashAccountNo, record?.cashAccountName),
        notes: buildRecordNotes(record),
        status: normalizeRecordStatus(record?.status),
        currency: toText(record?.currency, 'USD') || 'USD',
        createdAt: Number(record?.createdAt) || 0,
        description: toText(record?.description),
        primarySide: 'debit',
        primaryLine: debitLine,
        counterpartLine: creditLine
      };
    }

    const amount = getRecordPrimaryAmount(record);
    const primarySide = inferRecordPrimarySide(record);
    const debitLine = getRecordDebitLine(record);
    const creditLine = getRecordCreditLine(record);
    const primaryLine = getRecordPrimaryLine(record);
    const counterpartLine = getRecordCounterpartLine(record);

    return {
      noticeNo: toText(record?.number),
      type: safeType,
      typeLabel: toText((VOUCHERS[record?.type] && VOUCHERS[record.type].label) || record?.type),
      date: toText(record?.date),
      collectedAmount: primarySide === 'debit' ? amount : 0,
      owedAmount: primarySide === 'credit' ? amount : 0,
      fromAccount: debitLine
        ? buildRecordAccountDescriptor(debitLine.accountNo, debitLine.accountName)
        : buildRecordAccountDescriptor(
            primarySide === 'debit' ? record?.cashAccountNo : record?.counterpartAccountNo,
            primarySide === 'debit' ? record?.cashAccountName : counterpartName
          ),
      beneficiaryName: getRecordBeneficiaryName(record),
      toAccount: creditLine
        ? buildRecordAccountDescriptor(creditLine.accountNo, creditLine.accountName)
        : buildRecordAccountDescriptor(
            primarySide === 'credit' ? record?.cashAccountNo : record?.counterpartAccountNo,
            primarySide === 'credit' ? record?.cashAccountName : counterpartName
          ),
      notes: buildRecordNotes(record),
      status: normalizeRecordStatus(record?.status),
      currency: toText(record?.currency, 'USD') || 'USD',
      createdAt: Number(record?.createdAt) || 0,
      description: toText(record?.description),
      primarySide,
      primaryLine,
      counterpartLine
    };
  }

  function buildRecordFallbackId(record, index = 0){
    const stableOrdinal = Math.max(1, Number(index) + 1 || 1);
    return [
      'entry-record-repaired',
      toText(record.type, 'journal') || 'journal',
      toText(record.number, 'x') || 'x',
      Number(record.createdAt) > 0 ? Number(record.createdAt) : stableOrdinal,
      stableOrdinal
    ].join('-');
  }

  function buildRecordIdentity(record){
    const normalizedId = toText(record.id);
    if(normalizedId) return `id:${normalizedId}`;
    return [
      'sig',
      toText(record.type),
      toText(record.number),
      toText(record.date),
      toText(record.description),
      getRecordCounterpartName(record),
      getRecordBeneficiaryName(record),
      toText(record.cashAccountNo),
      toText(record.counterpartAccountNo),
      String(toNumber(record.grossAmount, 0)),
      String(toNumber(record.netAmount, 0)),
      String(toNumber(record.receiptAmount, 0)),
      String(toNumber(record.paymentAmount, 0)),
      String(Number(record.createdAt) || 0)
    ].join('|');
  }

  function normalizeRecord(raw, index = 0){
    const item = raw && typeof raw === 'object' ? raw : {};
    const type = resolveVoucherType(item.type);
    const commissionCode = normalizeCommissionCode(item.commissionCode || item.commissionLabel);
    const defaultCommissionLabel = commissionCode === 'mixed'
      ? 'متعددة'
      : resolveCommissionOption(commissionCode).label;
    const counterpartAccountName = getRecordCounterpartName(item);
    const beneficiaryName = getRecordBeneficiaryName(item);
    const counterpartAccountNo = toText(item.counterpartAccountNo);
    const cashAccountNo = toText(item.cashAccountNo);
    const cashAccountName = toText(item.cashAccountName);
    const createdAt = Number(item.createdAt) > 0 ? Number(item.createdAt) : Math.max(1, index + 1);
    const updatedAt = Number(item.updatedAt) > 0 ? Number(item.updatedAt) : createdAt;
    const number = toText(item.number).toUpperCase();
    const lines = normalizeLines(item.lines);
    const sourceAmount = toNumber(item.amount, 0);
    const sourceGrossAmount = toNumber(item.grossAmount, 0);
    const sourceNetAmount = toNumber(item.netAmount, 0);
    const primaryRecord = {
      type,
      amount: sourceAmount,
      cashAccountNo,
      counterpartAccountNo,
      lines
    };
    const inferredPrimaryAmount = getRecordPrimaryAmount(primaryRecord);
    const inferredPrimarySide = inferRecordPrimarySide(primaryRecord);
    const amount = sourceAmount > 0 ? sourceAmount : inferredPrimaryAmount;
    const grossAmount = sourceGrossAmount > 0 ? sourceGrossAmount : amount;
    const netAmount = sourceNetAmount > 0 ? sourceNetAmount : amount;
    const receiptAmount = type === 'journal'
      ? toNumber(item.receiptAmount, inferredPrimarySide === 'debit' ? amount : 0)
      : 0;
    const paymentAmount = type === 'journal'
      ? toNumber(item.paymentAmount, inferredPrimarySide === 'credit' ? amount : 0)
      : 0;

    const normalized = {
      id: toText(item.id) || buildRecordFallbackId({ type, number, createdAt }, index),
      type,
      number,
      status: normalizeRecordStatus(item.status),
      date: toText(item.date),
      description: toText(item.description),
      summary: toText(item.summary),
      counterpartAccountNo,
      counterpartAccountName,
      partyName: beneficiaryName,
      currency: toText(item.currency, 'USD') || 'USD',
      amount,
      grossAmount,
      netAmount,
      cashAccountNo,
      cashAccountName,
      lines,
      createdAt,
      updatedAt,
      sourceSalesPurchaseRecordId: toText(item.sourceSalesPurchaseRecordId),
      sourceSalesPurchaseNumber: toText(item.sourceSalesPurchaseNumber).toUpperCase(),
      ...(type === 'journal'
        ? {
            receiptAmount,
            paymentAmount,
            cashMotionPickerCode: toText(item.cashMotionPickerCode)
          }
        : {
            commissionCode,
            commissionLabel: toText(item.commissionLabel, defaultCommissionLabel) || defaultCommissionLabel,
            commissionFeeText: normalizeAmountInputText(item.commissionFeeText || item.commissionFeeAmount || item.commissionAmount)
          })
    };

    if(type === 'settlement' && Array.isArray(item.settlementMovements)){
      normalized.settlementMovements = item.settlementMovements.slice(0, 2).map((movement, movementIndex) => ({
        id: toText(movement?.id) || `entry-movement-settlement-slot-${String(movementIndex + 1).padStart(3, '0')}`,
        role: movementIndex === 1 ? 'credit' : 'debit',
        date: toText(movement?.date, normalized.date),
        currencyCode: toText(movement?.currencyCode, normalized.currency) || normalized.currency,
        counterpartAccountNo: toText(movement?.counterpartAccountNo || movement?.accountNo),
        counterpartAccountQuery: toText(movement?.counterpartAccountQuery || movement?.accountQuery),
        beneficiaryName: toText(movement?.beneficiaryName || movement?.partyName),
        statement: toText(movement?.statement),
        summary: toText(movement?.summary),
        grossAmountText: normalizeAmountInputText(movement?.grossAmountText || movement?.grossAmount || movement?.amount || normalized.grossAmount),
        commissionCode: normalizeCommissionCode(movement?.commissionCode),
        commissionFeeText: normalizeAmountInputText(movement?.commissionFeeText || movement?.commissionFeeAmount || movement?.commissionAmount)
      }));
    }

    return normalized;
  }

  function dedupeRecords(records){
    const unique = [];
    const seen = new Set();
    records
      .slice()
      .sort((left, right) => {
        const createdDelta = (Number(right.createdAt) || 0) - (Number(left.createdAt) || 0);
        if(createdDelta) return createdDelta;
        return (Number(right.updatedAt) || 0) - (Number(left.updatedAt) || 0);
      })
      .forEach((record, index) => {
        const repaired = record && record.id ? record : { ...record, id: buildRecordFallbackId(record || {}, index) };
        const key = buildRecordIdentity(repaired);
        if(seen.has(key)) return;
        seen.add(key);
        unique.push(repaired);
      });
    return unique;
  }

  function resolveCounterFloorMap(records){
    const floors = VOUCHER_COUNTER_PREFIXES.reduce((accumulator, prefix) => {
      accumulator[prefix] = 1;
      return accumulator;
    }, {});

    (Array.isArray(records) ? records : []).forEach((record) => {
      const meta = VOUCHERS[resolveVoucherType(record?.type)] || null;
      const prefix = toText(meta?.prefix).toUpperCase();
      if(!prefix || !Object.prototype.hasOwnProperty.call(floors, prefix)) return;
      const numberIndex = parseVoucherNumberIndex(record?.number, prefix);
      if(!Number.isFinite(numberIndex)) return;
      floors[prefix] = Math.max(floors[prefix], numberIndex + 1);
    });

    return floors;
  }

  function normalizeCounters(sourceCounters, records = []){
    const counters = sourceCounters && typeof sourceCounters === 'object' ? sourceCounters : {};
    const floors = resolveCounterFloorMap(records);
    return VOUCHER_COUNTER_PREFIXES.reduce((normalized, prefix) => {
      normalized[prefix] = Math.max(1, Number(counters[prefix]) || 1, Number(floors[prefix]) || 1);
      return normalized;
    }, {});
  }

  function normalizeState(raw){
    const source = raw && typeof raw === 'object' ? raw : {};
    const normalizedRecords = Array.isArray(source.records)
      ? source.records.map((record, index) => normalizeRecord(record, index))
      : [];
    const records = dedupeRecords(normalizedRecords);
    const updatedAt = Math.max(
      Number(source.updatedAt) || 0,
      ...records.map((record) => Number(record.updatedAt) || 0),
      0
    );

    return {
      version: 1,
      updatedAt,
      counters: normalizeCounters(source.counters, records),
      records
    };
  }

  const persistState = createStateWriter(STORAGE_KEY, normalizeState);
  let cachedStateRaw = '';
  let cachedComparableStateRaw = '';
  let cachedStateValue = null;

  function serializeEntriesState(value){
    try{
      return JSON.stringify(value);
    }catch{
      return '';
    }
  }

  function serializeComparableEntriesState(value){
    const normalized = normalizeState(value);
    return serializeEntriesState({
      version: normalized.version,
      counters: normalized.counters,
      records: normalized.records
    });
  }

  function cacheEntriesState(nextState){
    cachedStateValue = nextState && typeof nextState === 'object' ? nextState : normalizeState(createDefaultState());
    cachedStateRaw = serializeEntriesState(cachedStateValue);
    cachedComparableStateRaw = serializeComparableEntriesState(cachedStateValue);
    return cachedStateValue;
  }

  function notifyEntriesStateChange(nextState){
    const detail = { state: clone(nextState) };
    const events = TAIF.core && TAIF.core.events;
    if(events && typeof events.emitDomainUpdate === 'function'){
      events.emitDomainUpdate('entries', detail, { source:'entries-records' });
      return;
    }
    try{
      window.dispatchEvent(new CustomEvent('taif:entries-vouchers-updated', { detail }));
    }catch{}
  }

  function writeState(value){
    const normalizedInput = normalizeState(value);
    const comparableRaw = serializeComparableEntriesState(normalizedInput);
    if(comparableRaw && cachedStateValue && comparableRaw === cachedComparableStateRaw){
      return cachedStateValue;
    }

    const nextState = cacheEntriesState(persistState(normalizedInput));
    notifyEntriesStateChange(nextState);
    return nextState;
  }

  function readState(){
    const storedRaw = typeof storageGet === 'function' ? storageGet(STORAGE_KEY, '') : '';
    if(storedRaw && cachedStateValue && storedRaw === cachedStateRaw) return cachedStateValue;

    const stored = storedRaw ? readJsonStorage(STORAGE_KEY, null) : null;
    if(!stored){
      const initialState = normalizeState(createDefaultState());
      return writeState(initialState);
    }

    const normalized = normalizeState(stored);
    if(serializeEntriesState(stored) !== serializeEntriesState(normalized)) return writeState(normalized);
    return cacheEntriesState(normalized);
  }

  function createSheetState(type){
    const safeType = resolveVoucherType(type);
    return {
      id: `entry-sheet-${++runtime.sheetSequence}`,
      type: safeType,
      focus: null,
      needsInitialFocus: true,
      window: {},
      ui: {},
      draft: isInteractiveVoucherType(safeType) ? createVoucherDraft(safeType, readVoucherCatalogs()) : null,
      validationIssues: []
    };
  }

  function getSheetIndex(sheetId){
    return runtime.sheets.findIndex((sheet) => sheet && sheet.id === sheetId);
  }

  function getSheet(sheetId){
    const index = getSheetIndex(sheetId);
    return index >= 0 ? runtime.sheets[index] : null;
  }

  function syncWindowOrder(){
    const liveIds = runtime.sheets.map((sheet) => sheet.id);
    runtime.windowOrder = runtime.windowOrder.filter((sheetId) => liveIds.includes(sheetId));
    liveIds.forEach((sheetId) => {
      if(!runtime.windowOrder.includes(sheetId)) runtime.windowOrder.push(sheetId);
    });
  }

  function getTopSheetId(){
    syncWindowOrder();
    return runtime.windowOrder[runtime.windowOrder.length - 1] || '';
  }

  function isTopmostSheet(sheetId){
    return !!sheetId && getTopSheetId() === sheetId;
  }

  function getSheetIdFromNode(node){
    if(!(node instanceof Element)) return '';
    const host = node.closest('[data-entry-sheet-id]');
    return host ? String(host.getAttribute('data-entry-sheet-id') || '') : '';
  }

  function setSheetWindowState(sheetId, patch = {}){
    const sheet = getSheet(sheetId);
    if(!sheet) return;
    sheet.window = sheet.window && typeof sheet.window === 'object' ? sheet.window : {};
    Object.assign(sheet.window, patch);
  }

  function rememberWindowGeometry(modal, patch = {}){
    const sheetId = getSheetIdFromNode(modal);
    if(!sheetId) return;
    setSheetWindowState(sheetId, patch);
  }

  function clearSheetValidationState(sheetId){
    const sheet = getSheet(sheetId);
    if(!sheet) return;
    sheet.validationIssues = [];
  }

  function setSheetValidationState(sheetId, issues = []){
    const sheet = getSheet(sheetId);
    if(!sheet) return;
    sheet.validationIssues = Array.from(new Set((Array.isArray(issues) ? issues : []).filter(Boolean)));
  }

  function normalizeSheetDraftForEditing(sheet, catalogs = null){
    if(!sheet || !isInteractiveVoucherType(sheet.type)) return null;
    const safeCatalogs = catalogs || readVoucherCatalogs();
    return normalizeVoucherDraft(sheet.draft || createVoucherDraft(sheet.type, safeCatalogs), sheet.type, safeCatalogs);
  }

  function draftsAreEqual(leftDraft, rightDraft){
    return JSON.stringify(leftDraft) === JSON.stringify(rightDraft);
  }

  function mutateInteractiveSheetDraft(sheetId, mutator, fallbackResult = null){
    const sheet = getSheet(sheetId);
    if(!sheet || !isInteractiveVoucherType(sheet.type)){
      return { sheet: null, draft: null, changed: false, result: fallbackResult };
    }

    const catalogs = readVoucherCatalogs();
    const currentDraft = normalizeSheetDraftForEditing(sheet, catalogs);
    const mutation = typeof mutator === 'function'
      ? (mutator({ sheet, catalogs, currentDraft, movements: Array.isArray(currentDraft.movements) ? currentDraft.movements : [] }) || null)
      : null;

    if(!mutation){
      clearSheetValidationState(sheetId);
      return { sheet, draft: currentDraft, changed: false, result: fallbackResult };
    }

    if(mutation.cancelled){
      clearSheetValidationState(sheetId);
      return {
        sheet,
        draft: currentDraft,
        changed: false,
        result: Object.prototype.hasOwnProperty.call(mutation, 'result') ? mutation.result : fallbackResult
      };
    }

    const draftSource = Object.prototype.hasOwnProperty.call(mutation, 'draftSource') ? mutation.draftSource : mutation;
    const nextDraft = normalizeVoucherDraft(draftSource, sheet.type, catalogs);
    const changed = !draftsAreEqual(nextDraft, currentDraft);
    if(changed){
      sheet.draft = nextDraft;
    }
    clearSheetValidationState(sheetId);
    return {
      sheet,
      draft: changed ? nextDraft : currentDraft,
      changed,
      result: Object.prototype.hasOwnProperty.call(mutation, 'result') ? mutation.result : fallbackResult
    };
  }

  function updateSheetDraft(sheetId, patch = {}){
    const mutation = mutateInteractiveSheetDraft(sheetId, ({ currentDraft }) => ({
      draftSource: { ...currentDraft, ...(patch || {}) }
    }));
    return mutation.draft;
  }

  function updateSheetMovementField(sheetId, movementId, patch = {}){
    const mutation = mutateInteractiveSheetDraft(sheetId, ({ currentDraft, movements, catalogs }) => {
      const movementIndex = movements.findIndex((movement) => movement.id === movementId);
      if(!movementId || movementIndex < 0){
        return { cancelled: true, result: currentDraft };
      }

      const nextDraftSource = {
        ...currentDraft,
        movements: movements.map((movement) => movement.id === movementId ? { ...movement, ...(patch || {}) } : movement)
      };

      return {
        draftSource: resolveVoucherType(currentDraft?.type) === 'settlement' && typeof finalizeSettlementDraft === 'function'
          ? finalizeSettlementDraft(nextDraftSource, catalogs, {
              sourceIndex: movementIndex,
              changedFields: Object.keys(patch || {})
            })
          : nextDraftSource
      };
    });
    return mutation.draft;
  }

  function appendSheetMovement(sheetId, afterMovementId = ''){
    const sheet = getSheet(sheetId);
    if(sheet && resolveVoucherType(sheet.type) === 'journal'){
      const draft = normalizeSheetDraftForEditing(sheet);
      clearSheetValidationState(sheetId);
      return {
        draft,
        movementId: ''
      };
    }

    const mutation = mutateInteractiveSheetDraft(sheetId, ({ currentDraft, catalogs, movements }) => {
      const newMovement = createVoucherMovement({}, catalogs, currentDraft.cashAccountNo, currentDraft.type, currentDraft.cashMotionCode);
      const targetIndex = afterMovementId ? movements.findIndex((movement) => movement.id === afterMovementId) : -1;
      const insertIndex = targetIndex >= 0 ? (targetIndex + 1) : movements.length;
      return {
        draftSource: {
          ...currentDraft,
          movements: [
            ...movements.slice(0, insertIndex),
            newMovement,
            ...movements.slice(insertIndex)
          ]
        },
        result: { movementId: newMovement.id }
      };
    }, { movementId: '' });

    return {
      draft: mutation.draft,
      movementId: mutation.result?.movementId || ''
    };
  }

  function removeSheetMovement(sheetId, movementId){
    const sheet = getSheet(sheetId);
    if(sheet && resolveVoucherType(sheet.type) === 'journal'){
      const draft = normalizeSheetDraftForEditing(sheet);
      clearSheetValidationState(sheetId);
      return {
        draft,
        removed: false,
        focusMovementId: Array.isArray(draft?.movements) && draft.movements[0] ? draft.movements[0].id : ''
      };
    }

    const mutation = mutateInteractiveSheetDraft(sheetId, ({ currentDraft, movements }) => {
      if(!movementId || movements.length <= 1){
        return {
          cancelled: true,
          result: {
            removed: false,
            focusMovementId: movements[0] ? movements[0].id : ''
          }
        };
      }

      const targetIndex = movements.findIndex((movement) => movement.id === movementId);
      if(targetIndex < 0){
        return {
          cancelled: true,
          result: {
            removed: false,
            focusMovementId: ''
          }
        };
      }

      const nextMovements = movements.filter((movement) => movement.id !== movementId);
      const focusMovement = nextMovements[Math.min(targetIndex, nextMovements.length - 1)] || nextMovements[nextMovements.length - 1] || null;
      return {
        draftSource: {
          ...currentDraft,
          movements: nextMovements
        },
        result: {
          removed: true,
          focusMovementId: focusMovement ? focusMovement.id : ''
        }
      };
    }, { removed: false, focusMovementId: '' });

    return {
      draft: mutation.draft,
      removed: !!mutation.result?.removed,
      focusMovementId: mutation.result?.focusMovementId || ''
    };
  }

  function buildRecordSearchText(record){
    const lineSearchText = Array.isArray(record?.lines)
      ? record.lines.map((line) => [line?.accountNo, line?.accountName, line?.description, line?.roleLabel].join(' ')).join(' ')
      : '';
    const view = buildRecordPresentation(record);

    return normalizeAccountLookupText([
      record?.number,
      record?.description,
      getRecordCounterpartName(record),
      record?.cashAccountNo,
      record?.cashAccountName,
      record?.counterpartAccountNo,
      record?.counterpartAccountName,
      record?.partyName,
      record?.commissionLabel,
      record?.commissionCode,
      record?.receiptAmount,
      record?.paymentAmount,
      record?.currency,
      (VOUCHERS[record?.type] && VOUCHERS[record.type].label) || record?.type,
      view?.fromAccount?.accountNo,
      view?.fromAccount?.accountName,
      view?.toAccount?.accountNo,
      view?.toAccount?.accountName,
      view?.beneficiaryName,
      String(view?.collectedAmount || 0),
      String(view?.owedAmount || 0),
      view?.notes?.primary,
      view?.notes?.secondary,
      lineSearchText
    ].join(' '));
  }

  function getVisibleRecords(state = readState(), filterQuery = runtime.filter){
    const records = Array.isArray(state?.records) ? state.records : [];
    const query = normalizeAccountLookupText(filterQuery);
    return records
      .filter((record) => !isSalesPurchaseGeneratedRecord(record))
      .filter((record) => !query || buildRecordSearchText(record).includes(query));
  }

  function findRecordById(recordId, state = readState()){
    const targetId = toText(recordId);
    if(!targetId) return null;
    const records = Array.isArray(state?.records) ? state.records : [];
    return records.find((record) => toText(record?.id) === targetId) || null;
  }

  function getVoucherDeletionScope(recordId, state = readState()){
    const record = findRecordById(recordId, state);
    if(!record){
      return {
        record: null,
        records: [],
        ids: [],
        count: 0,
        number: '',
        type: 'journal',
        lockedForMutation: false
      };
    }

    const safeType = resolveVoucherType(record.type);
    const safeNumber = toText(record.number);
    const records = (Array.isArray(state?.records) ? state.records : []).filter((candidate) => (
      resolveVoucherType(candidate?.type) === safeType
      && toText(candidate?.number) === safeNumber
    ));
    const lockedForMutation = records.some((candidate) => isVoucherRecordLockedForMutation(candidate));

    return {
      record,
      records,
      ids: records.map((candidate) => toText(candidate?.id)).filter(Boolean),
      count: records.length,
      number: safeNumber,
      type: safeType,
      lockedForMutation
    };
  }


  function deleteVoucherByRecordId(recordId){
    const state = readState();
    const scope = getVoucherDeletionScope(recordId, state);
    if(!scope.record || !scope.ids.length){
      return { ok: false, issues: ['تعذر العثور على السند المحدد للحذف.'], scope };
    }
    if(scope.lockedForMutation){
      return { ok: false, issues: ['هذا القيد مرتبط مباشرة بفاتورة شراء/مبيع ويجب حذفه أو عكسه من نافذة الشراء/المبيع نفسها.'], scope };
    }

    const deletedIdSet = new Set(scope.ids);
    const nextRecords = (Array.isArray(state.records) ? state.records : []).filter((record) => !deletedIdSet.has(toText(record?.id)));
    if(nextRecords.length === (Array.isArray(state.records) ? state.records.length : 0)){
      return { ok: false, issues: ['لم يتم العثور على عناصر قابلة للحذف ضمن هذا السند.'], scope };
    }

    const nextState = normalizeState({
      ...state,
      updatedAt: Date.now(),
      records: nextRecords
    });

    writeState(nextState);
    return {
      ok: true,
      scope,
      nextState,
      deletedCount: scope.count,
      deletedIds: Array.from(deletedIdSet)
    };
  }

  function getVoucherRecordGroups(type, records = null){
    const safeType = resolveVoucherType(type);
    const safeRecords = (Array.isArray(records) ? records : readState().records).filter((record) => !isVoucherRecordLockedForMutation(record));
    const meta = VOUCHERS[safeType] || VOUCHERS.journal;
    const grouped = new Map();

    safeRecords.forEach((record) => {
      if(!record || record.type !== safeType) return;
      const key = toText(record.number);
      if(!key) return;
      if(!grouped.has(key)){
        grouped.set(key, {
          number: key,
          type: safeType,
          records: [],
          createdAt: Number(record.createdAt) || 0,
          updatedAt: Number(record.updatedAt) || 0,
          sequenceIndex: parseVoucherNumberIndex(key, meta.prefix)
        });
      }
      const group = grouped.get(key);
      group.records.push(record);
      group.createdAt = Math.max(group.createdAt, Number(record.createdAt) || 0);
      group.updatedAt = Math.max(group.updatedAt, Number(record.updatedAt) || 0);
    });

    return Array.from(grouped.values())
      .map((group) => ({
        ...group,
        records: group.records.slice().sort((left, right) => (Number(right.createdAt) || 0) - (Number(left.createdAt) || 0))
      }))
      .sort((left, right) => {
        const leftSequence = Number.isFinite(left.sequenceIndex) ? left.sequenceIndex : Number.NaN;
        const rightSequence = Number.isFinite(right.sequenceIndex) ? right.sequenceIndex : Number.NaN;
        if(Number.isFinite(leftSequence) && Number.isFinite(rightSequence) && leftSequence !== rightSequence){
          return leftSequence - rightSequence;
        }
        if((left.createdAt || 0) !== (right.createdAt || 0)){
          return (left.createdAt || 0) - (right.createdAt || 0);
        }
        return left.number.localeCompare(right.number, 'en');
      });
  }

  function buildVoucherDraftFromRecordGroup(type, group, catalogs = null){
    const safeType = resolveVoucherType(type);
    const safeCatalogs = catalogs || readVoucherCatalogs();
    if(!isInteractiveVoucherType(safeType)) return null;
    const safeGroup = group && typeof group === 'object' ? group : null;
    const safeRecords = Array.isArray(safeGroup?.records) ? safeGroup.records : [];
    if(!safeRecords.length) return createVoucherDraft(safeType, safeCatalogs);

    const primaryRecord = safeRecords[0];

    if(safeType === 'opening'){
      const openingCurrencyCode = toText(primaryRecord?.currency, 'USD') || 'USD';
      const movementDrafts = safeRecords
        .slice()
        .sort((left, right) => (Number(left?.createdAt) || 0) - (Number(right?.createdAt) || 0))
        .flatMap((record) => {
          const recordLines = Array.isArray(record?.lines) ? record.lines.slice().sort((left, right) => (Number(left?.lineNo) || 0) - (Number(right?.lineNo) || 0)) : [];
          return recordLines.map((line) => {
            const account = line?.accountNo ? findAccountByNo(line.accountNo, safeCatalogs.accounts) : null;
            const debitAmount = toNumber(line?.debit, 0);
            const creditAmount = toNumber(line?.credit, 0);
            const statement = toText(line?.description || record?.description).replace(/^رصيد افتتاحي\s+(?:مدين|دائن)\s*[—-]\s*/u, '').trim();
            return {
              counterpartAccountNo: toText(line?.accountNo),
              counterpartAccountQuery: account ? buildAccountLookupLabel(account) : `${toText(line?.accountNo)} — ${toText(line?.accountName)}`.trim(),
              debitAmountText: debitAmount > 0 ? normalizeAmountInputText(debitAmount) : '',
              creditAmountText: creditAmount > 0 ? normalizeAmountInputText(creditAmount) : '',
              currencyCode: openingCurrencyCode,
              statement
            };
          });
        })
        .filter((movement) => toText(movement?.counterpartAccountNo) || toText(movement?.debitAmountText) || toText(movement?.creditAmountText));

      return normalizeVoucherDraft({
        date: toText(primaryRecord?.date),
        currencyCode: openingCurrencyCode,
        movements: movementDrafts
      }, safeType, safeCatalogs);
    }

    if(safeType === 'settlement'){
      const settlementCurrencyCode = toText(primaryRecord?.currency, 'USD') || 'USD';
      const storedMovements = Array.isArray(primaryRecord?.settlementMovements) ? primaryRecord.settlementMovements : [];
      let movementDrafts = [];

      if(storedMovements.length){
        movementDrafts = storedMovements.slice(0, 2).map((movement) => {
          const accountNo = toText(movement?.counterpartAccountNo || movement?.accountNo);
          const account = accountNo ? findAccountByNo(accountNo, safeCatalogs.accounts) : null;
          return {
            date: toText(movement?.date, primaryRecord?.date),
            currencyCode: settlementCurrencyCode,
            counterpartAccountNo: accountNo,
            counterpartAccountQuery: account ? buildAccountLookupLabel(account) : toText(movement?.counterpartAccountQuery || movement?.accountQuery),
            beneficiaryName: toText(movement?.beneficiaryName || movement?.partyName),
            statement: toText(movement?.statement),
            summary: toText(movement?.summary),
            grossAmountText: normalizeAmountInputText(movement?.grossAmountText || movement?.grossAmount || movement?.amount || primaryRecord?.grossAmount),
            commissionCode: normalizeCommissionCode(movement?.commissionCode),
            commissionFeeText: normalizeAmountInputText(movement?.commissionFeeText || movement?.commissionFeeAmount || movement?.commissionAmount)
          };
        });
      }else{
        const debitLine = getRecordDebitLine(primaryRecord);
        const creditLine = getRecordCreditLine(primaryRecord);
        const settlementAmountText = normalizeAmountInputText(
          primaryRecord?.grossAmount
          || primaryRecord?.amount
          || debitLine?.debit
          || creditLine?.credit
          || 0
        );
        movementDrafts = [debitLine, creditLine].map((line) => {
          const accountNo = toText(line?.accountNo);
          const account = accountNo ? findAccountByNo(accountNo, safeCatalogs.accounts) : null;
          return {
            date: toText(primaryRecord?.date),
            currencyCode: settlementCurrencyCode,
            counterpartAccountNo: accountNo,
            counterpartAccountQuery: account ? buildAccountLookupLabel(account) : `${toText(line?.accountNo)} — ${toText(line?.accountName)}`.trim(),
            beneficiaryName: '',
            statement: '',
            summary: '',
            grossAmountText: settlementAmountText,
            commissionCode: normalizeCommissionCode(primaryRecord?.commissionCode),
            commissionFeeText: normalizeAmountInputText(primaryRecord?.commissionFeeText || primaryRecord?.commissionFeeAmount || primaryRecord?.commissionAmount)
          };
        });
      }

      return normalizeVoucherDraft({
        date: toText(primaryRecord?.date),
        currencyCode: settlementCurrencyCode,
        movements: movementDrafts
      }, safeType, safeCatalogs);
    }

    const movementDrafts = safeRecords.map((record) => {
      const counterpartAccount = record?.counterpartAccountNo ? findAccountByNo(record.counterpartAccountNo, safeCatalogs.accounts) : null;
      if(safeType === 'journal'){
        const primarySide = inferRecordPrimarySide(record);
        const primaryAmount = getRecordPrimaryAmount(record);
        const receiptAmount = toNumber(record?.receiptAmount, primarySide === 'debit' ? primaryAmount : 0);
        const paymentAmount = toNumber(record?.paymentAmount, primarySide === 'credit' ? primaryAmount : 0);
        return {
          counterpartAccountNo: toText(record?.counterpartAccountNo),
          counterpartAccountQuery: counterpartAccount ? buildAccountLookupLabel(counterpartAccount) : getRecordCounterpartName(record),
          beneficiaryName: getRecordBeneficiaryName(record),
          statement: toText(record?.description),
          receiptAmountText: receiptAmount > 0 ? normalizeAmountInputText(receiptAmount) : '',
          paymentAmountText: paymentAmount > 0 ? normalizeAmountInputText(paymentAmount) : ''
        };
      }
      return {
        date: toText(record?.date),
        counterpartAccountNo: toText(record?.counterpartAccountNo),
        counterpartAccountQuery: counterpartAccount ? buildAccountLookupLabel(counterpartAccount) : getRecordCounterpartName(record),
        beneficiaryName: getRecordBeneficiaryName(record),
        statement: toText(record?.description),
        summary: toText(record?.summary),
        grossAmountText: normalizeAmountInputText(record?.grossAmount || record?.amount || 0),
        commissionCode: normalizeCommissionCode(record?.commissionCode),
        commissionFeeText: normalizeAmountInputText(record?.commissionFeeText || record?.commissionFeeAmount || record?.commissionAmount)
      };
    });

    return normalizeVoucherDraft({
      date: toText(primaryRecord?.date),
      currencyCode: toText(primaryRecord?.currency),
      cashAccountNo: toText(primaryRecord?.cashAccountNo),
      cashMotionPickerCode: toText(primaryRecord?.cashMotionPickerCode),
      movements: movementDrafts
    }, safeType, safeCatalogs);
  }

  function buildVoucherRecord(sheet, status = 'posted'){
    if(!sheet || !isInteractiveVoucherType(sheet.type)) return { ok: false, issues: ['هذا السند غير مجهز للحفظ بعد.'] };
    const context = buildVoucherContext(sheet.type, sheet.draft);
    if(context.validationIssues.length){
      return { ok: false, issues: context.validationIssues, context };
    }

    const safeStatus = status === 'draft' ? 'draft' : 'posted';
    const state = readState();
    const meta = VOUCHERS[sheet.type] || VOUCHERS.journal;
    const nextCounter = Math.max(1, Number(state.counters && state.counters[meta.prefix]) || 1);
    const recordNumber = `${meta.prefix}-${String(nextCounter).padStart(5, '0')}`;
    const now = Date.now();
    const batchToken = Math.random().toString(36).slice(2, 8);
    const cashAccountNo = context.cashAccount ? context.cashAccount.accountNo : '';
    const cashAccountName = context.cashAccount ? context.cashAccount.name : '';

    const recordableMovements = Array.isArray(context.persistedMovements)
      ? context.persistedMovements
      : [];

    const records = sheet.type === 'opening'
      ? Array.from(recordableMovements.reduce((groups, movement) => {
          const currencyCode = toText(movement?.draft?.currencyCode, 'USD').toUpperCase() || 'USD';
          if(!groups.has(currencyCode)) groups.set(currencyCode, []);
          groups.get(currencyCode).push(movement);
          return groups;
        }, new Map()).entries()).map(([currencyCode, movements], index) => {
          const recordLines = [];
          movements.forEach((movement) => {
            (Array.isArray(movement?.lines) ? movement.lines : []).forEach((line) => {
              recordLines.push({ ...line, lineNo: recordLines.length + 1 });
            });
          });
          const debitLead = recordLines.find((line) => (Number(line?.debit) || 0) > 0) || null;
          const creditLead = recordLines.find((line) => (Number(line?.credit) || 0) > 0) || null;
          const debitTotal = recordLines.reduce((sum, line) => sum + (Number(line?.debit) || 0), 0);
          const creditTotal = recordLines.reduce((sum, line) => sum + (Number(line?.credit) || 0), 0);
          const description = Array.from(new Set(movements.map((movement) => toText(movement?.statementText || movement?.draft?.statement)).filter(Boolean))).join(' | ')
            || `أرصدة افتتاحية ${currencyCode}`;
          const movementCreatedAt = now - index;
          return normalizeRecord({
            id: `entry-record-${movementCreatedAt}-${batchToken}-${index + 1}`,
            type: sheet.type,
            number: recordNumber,
            status: safeStatus,
            date: toText(context?.draft?.date),
            description,
            counterpartAccountNo: toText(creditLead?.accountNo),
            counterpartAccountName: toText(creditLead?.accountName),
            partyName: '',
            currency: currencyCode,
            amount: Math.max(debitTotal, creditTotal),
            grossAmount: debitTotal,
            netAmount: creditTotal,
            cashAccountNo: toText(debitLead?.accountNo),
            cashAccountName: toText(debitLead?.accountName),
            lines: recordLines,
            createdAt: movementCreatedAt,
            updatedAt: movementCreatedAt
          }, index);
        })
      : sheet.type === 'settlement'
        ? (() => {
            const settlementAmount = Math.max(Number(context?.grossAmount) || 0, Number(context?.netAmount) || 0);
            const settlementDate = toText(context?.settlementDate || context?.draft?.date);
            const settlementCurrencyCode = toText(context?.currency?.code, context?.draft?.currencyCode || 'USD') || 'USD';
            const debitMovement = context?.settlementDebitMovement || recordableMovements[0] || null;
            const creditMovement = context?.settlementCreditMovement || recordableMovements[1] || null;
            const debitAccount = context?.settlementDebitAccount || debitMovement?.counterpartAccount || null;
            const creditAccount = context?.settlementCreditAccount || creditMovement?.counterpartAccount || null;
            const recordLines = Array.isArray(context?.lines)
              ? context.lines.map((line, lineIndex) => ({ ...line, lineNo: lineIndex + 1 }))
              : [];
            const settlementSummaryParts = [
              toText(debitMovement?.draft?.summary),
              toText(creditMovement?.draft?.summary)
            ].filter(Boolean);
            const settlementSummary = Array.from(new Set(settlementSummaryParts)).join(' | ');
            const statementParts = [
              toText(debitMovement?.draft?.statement),
              toText(creditMovement?.draft?.statement)
            ].filter(Boolean);
            const settlementDescription = Array.from(new Set([...statementParts, ...settlementSummaryParts])).join(' | ')
              || 'تسوية بين حسابين';
            const beneficiarySummary = Array.from(new Set([
              toText(debitMovement?.draft?.beneficiaryName),
              toText(creditMovement?.draft?.beneficiaryName)
            ].filter(Boolean))).join(' / ');
            const settlementMovements = [
              debitMovement ? { role: 'debit', ...debitMovement.draft } : null,
              creditMovement ? { role: 'credit', ...creditMovement.draft } : null
            ].filter(Boolean);
            const movementCreatedAt = now;
            return [normalizeRecord({
              id: `entry-record-${movementCreatedAt}-${batchToken}-1`,
              type: sheet.type,
              number: recordNumber,
              status: safeStatus,
              date: settlementDate,
              description: settlementDescription,
              summary: settlementSummary,
              counterpartAccountNo: toText(creditAccount?.accountNo),
              counterpartAccountName: toText(creditAccount?.name),
              partyName: beneficiarySummary,
              currency: settlementCurrencyCode,
              amount: settlementAmount,
              grossAmount: settlementAmount,
              netAmount: settlementAmount,
              cashAccountNo: toText(debitAccount?.accountNo),
              cashAccountName: toText(debitAccount?.name),
              lines: recordLines,
              createdAt: movementCreatedAt,
              updatedAt: movementCreatedAt,
              commissionCode: toText(context?.commissionSummary?.value, 'none'),
              commissionLabel: toText(context?.commissionSummary?.label, 'بدون عمولة'),
              settlementMovements
            }, 0)];
          })()
        : recordableMovements.map((movement, index) => {
            const counterpartAccount = movement && movement.counterpartAccount ? movement.counterpartAccount : null;
            const movementCreatedAt = now - index;
            const counterpartAccountName = counterpartAccount ? counterpartAccount.name : '';
            const baseRecord = {
              id: `entry-record-${movementCreatedAt}-${batchToken}-${index + 1}`,
              type: sheet.type,
              number: recordNumber,
              status: safeStatus,
              date: toText(movement?.draft?.date, context.draft.date),
              description: toText(movement?.draft?.statement),
              summary: toText(movement?.draft?.summary),
              counterpartAccountNo: counterpartAccount ? counterpartAccount.accountNo : '',
              counterpartAccountName,
              partyName: toText(movement?.draft?.beneficiaryName),
              currency: context.currency.code,
              amount: movement?.netAmount || 0,
              grossAmount: movement?.grossAmount || 0,
              netAmount: movement?.netAmount || 0,
              cashAccountNo,
              cashAccountName,
              lines: Array.isArray(movement?.lines) ? movement.lines : [],
              createdAt: movementCreatedAt,
              updatedAt: movementCreatedAt
            };

            if(sheet.type === 'journal'){
              baseRecord.receiptAmount = movement?.receiptAmount || 0;
              baseRecord.paymentAmount = movement?.paymentAmount || 0;
              baseRecord.cashMotionPickerCode = toText(context?.draft?.cashMotionPickerCode);
            }else{
              const commission = movement && movement.commission ? movement.commission : resolveCommissionOption('none');
              baseRecord.commissionCode = commission.value;
              baseRecord.commissionLabel = commission.label;
              baseRecord.commissionFeeText = normalizeAmountInputText(movement?.draft?.commissionFeeText);
              baseRecord.commissionFeeAmount = toNumber(movement?.draft?.commissionFeeText, 0);
            }

            return normalizeRecord(baseRecord, index);
          });

    if(!records.length){
      return { ok: false, issues: ['لا توجد بطاقات صالحة للحفظ داخل هذا السند.'], context };
    }

    const nextState = normalizeState({
      ...state,
      updatedAt: now,
      counters: {
        ...state.counters,
        [meta.prefix]: nextCounter + 1
      },
      records: [...records, ...state.records]
    });

    writeState(nextState);
    return { ok: true, record: records[0], records, context };
  }

  function saveSheetAsRecord(sheetId, status = 'posted'){
    const sheet = getSheet(sheetId);
    if(!sheet) return { ok: false, issues: ['تعذر العثور على السند النشط.'] };
    const result = buildVoucherRecord(sheet, status);
    if(!result.ok){
      setSheetValidationState(sheetId, result.issues || []);
      return result;
    }
    clearSheetValidationState(sheetId);
    return result;
  }

  Object.assign(feature, {
  readState,
  writeState,
  buildRecordPresentation,
  createSheetState,
  getSheetIndex,
  getSheet,
  syncWindowOrder,
  getTopSheetId,
  isTopmostSheet,
  getSheetIdFromNode,
  rememberWindowGeometry,
  clearSheetValidationState,
  updateSheetDraft,
  updateSheetMovementField,
  appendSheetMovement,
  removeSheetMovement,
  getVisibleRecords,
  findRecordById,
  isVoucherRecordLockedForMutation,
  getVoucherDeletionScope,
  getVoucherRecordGroups,
  buildVoucherDraftFromRecordGroup,
  deleteVoucherByRecordId,
  saveSheetAsRecord
});

})();
