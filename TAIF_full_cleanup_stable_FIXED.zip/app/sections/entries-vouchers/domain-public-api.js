(()=>{
  /*
   * TAIF Entries & Vouchers domain public API.
   * Exposes storage/state access without loading the Entries view renderer or UI controllers.
   */
  const TAIF = window.TAIF || (window.TAIF = {});
  const utils = TAIF.core && TAIF.core.utils ? TAIF.core.utils : {};
  const readJsonStorage = typeof utils.readJsonStorage === 'function' ? utils.readJsonStorage : null;
  const persistJsonState = typeof utils.persistJsonState === 'function' ? utils.persistJsonState : null;
  const parseNumericInput = typeof utils.parseNumericInput === 'function'
    ? utils.parseNumericInput
    : ((value, fallback = 0) => {
        const numeric = Number(String(value ?? '').replace(/,/g, '').trim());
        return Number.isFinite(numeric) ? numeric : Number(fallback) || 0;
      });

  const storageKeys = TAIF?.core?.storageKeys || {};
  const STORAGE_KEY = storageKeys.entriesVouchers || 'taif-entries-vouchers-module-v1';
  const domain = TAIF.entriesVouchersDomain || (TAIF.entriesVouchersDomain = {});

  const DEFAULT_COUNTERS = Object.freeze({ PV:1, RV:1, JV:1, SV:1, OV:1 });

  function toText(value){
    return String(value ?? '').trim();
  }

  function toNumber(value, fallback = 0){
    return parseNumericInput(value, fallback);
  }

  function isSalesPurchaseGeneratedRecord(record){
    const safeRecord = record && typeof record === 'object' ? record : {};
    const safeId = toText(safeRecord.id);
    if(safeId.startsWith('entry-record-sales-purchase-')) return true;
    if(toText(safeRecord.sourceSalesPurchaseRecordId)) return true;
    if(toText(safeRecord.sourceSalesPurchaseNumber)) return true;
    return false;
  }

  function createDefaultState(){
    return {
      version: 1,
      updatedAt: Date.now(),
      counters: { ...DEFAULT_COUNTERS },
      records: []
    };
  }

  function parseVoucherNumberIndex(number, expectedPrefix = ''){
    const safeNumber = toText(number).toUpperCase();
    const safePrefix = toText(expectedPrefix).toUpperCase();
    const match = safeNumber.match(/^([A-Z]+)-(\d+)$/);
    if(!match) return Number.NaN;
    if(safePrefix && match[1] !== safePrefix) return Number.NaN;
    return Number(match[2]);
  }

  function normalizeLine(line, index = 0){
    const raw = line && typeof line === 'object' ? line : {};
    const debit = Math.max(0, toNumber(raw.debit, 0));
    const credit = Math.max(0, toNumber(raw.credit, 0));
    return {
      ...raw,
      lineNo: Math.max(1, Number(raw.lineNo) || index + 1),
      roleKey: toText(raw.roleKey),
      roleLabel: toText(raw.roleLabel),
      accountNo: toText(raw.accountNo),
      accountName: toText(raw.accountName),
      description: toText(raw.description),
      debit,
      credit,
      side: raw.side === 'credit' ? 'credit' : 'debit',
      amount: Math.max(0, toNumber(raw.amount, Math.max(debit, credit)))
    };
  }

  function normalizeRecord(record, index = 0){
    const raw = record && typeof record === 'object' ? record : {};
    const createdAt = Number(raw.createdAt) > 0 ? Number(raw.createdAt) : (Date.now() + index);
    const lines = Array.isArray(raw.lines)
      ? raw.lines.map((line, lineIndex) => normalizeLine(line, lineIndex)).filter((line) => line.accountNo)
      : [];
    const amount = Math.max(0, toNumber(raw.amount, 0));
    const grossAmount = Math.max(0, toNumber(raw.grossAmount, amount));
    const netAmount = Math.max(0, toNumber(raw.netAmount, amount));
    return {
      ...raw,
      id: toText(raw.id) || `entry-record-${createdAt}-${index + 1}`,
      type: toText(raw.type) || 'journal',
      number: toText(raw.number).toUpperCase(),
      status: raw.status === 'reversed' ? 'reversed' : (raw.status === 'draft' ? 'draft' : 'posted'),
      date: toText(raw.date),
      description: toText(raw.description),
      summary: toText(raw.summary),
      counterpartAccountNo: toText(raw.counterpartAccountNo),
      counterpartAccountName: toText(raw.counterpartAccountName),
      beneficiaryName: toText(raw.beneficiaryName),
      partyName: toText(raw.partyName),
      currency: toText(raw.currency).toUpperCase() || 'USD',
      amount,
      grossAmount,
      netAmount,
      cashAccountNo: toText(raw.cashAccountNo),
      cashAccountName: toText(raw.cashAccountName),
      lines,
      createdAt,
      updatedAt: Number(raw.updatedAt) > 0 ? Number(raw.updatedAt) : createdAt,
      sourceSalesPurchaseRecordId: toText(raw.sourceSalesPurchaseRecordId),
      sourceSalesPurchaseNumber: toText(raw.sourceSalesPurchaseNumber).toUpperCase(),
      receiptAmount: Math.max(0, toNumber(raw.receiptAmount, 0)),
      paymentAmount: Math.max(0, toNumber(raw.paymentAmount, 0)),
      cashMotionPickerCode: toText(raw.cashMotionPickerCode),
      commissionCode: toText(raw.commissionCode),
      commissionLabel: toText(raw.commissionLabel),
      commissionFeeText: toText(raw.commissionFeeText),
      commissionFeeAmount: Math.max(0, toNumber(raw.commissionFeeAmount, 0))
    };
  }

  function normalizeCounters(sourceCounters, records = []){
    const safeCounters = sourceCounters && typeof sourceCounters === 'object' ? sourceCounters : {};
    const floors = Object.keys(DEFAULT_COUNTERS).reduce((accumulator, prefix) => {
      accumulator[prefix] = DEFAULT_COUNTERS[prefix];
      return accumulator;
    }, {});

    (Array.isArray(records) ? records : []).forEach((record) => {
      const recordNumber = toText(record?.number).toUpperCase();
      if(!recordNumber) return;
      Object.keys(DEFAULT_COUNTERS).forEach((prefix) => {
        const parsedIndex = parseVoucherNumberIndex(recordNumber, prefix);
        if(Number.isFinite(parsedIndex)){
          floors[prefix] = Math.max(floors[prefix], parsedIndex + 1);
        }
      });
    });

    return Object.keys(DEFAULT_COUNTERS).reduce((normalized, prefix) => {
      normalized[prefix] = Math.max(
        DEFAULT_COUNTERS[prefix],
        Number(safeCounters[prefix]) || DEFAULT_COUNTERS[prefix],
        Number(floors[prefix]) || DEFAULT_COUNTERS[prefix]
      );
      return normalized;
    }, {});
  }

  function normalizeState(input){
    const fallback = createDefaultState();
    const raw = input && typeof input === 'object' ? input : fallback;
    const records = (Array.isArray(raw.records) ? raw.records : [])
      .map((record, index) => normalizeRecord(record, index))
      .sort((left, right) => {
        const createdDelta = (Number(right.createdAt) || 0) - (Number(left.createdAt) || 0);
        if(createdDelta) return createdDelta;
        const updatedDelta = (Number(right.updatedAt) || 0) - (Number(left.updatedAt) || 0);
        if(updatedDelta) return updatedDelta;
        return toText(right.number).localeCompare(toText(left.number), 'en');
      });

    return {
      version: 1,
      updatedAt: Number(raw.updatedAt) > 0 ? Number(raw.updatedAt) : Date.now(),
      counters: normalizeCounters(raw.counters, records),
      records
    };
  }

  function fallbackReadState(){
    const stored = readJsonStorage ? readJsonStorage(STORAGE_KEY, null) : null;
    if(!stored) return createDefaultState();
    return normalizeState(stored);
  }

  function fallbackWriteState(nextState, { notify = true } = {}){
    const normalized = normalizeState(nextState);
    const persisted = persistJsonState
      ? persistJsonState(STORAGE_KEY, normalized, normalizeState)
      : normalized;
    const safeState = normalizeState(persisted);
    if(notify){
      const events = TAIF.core && TAIF.core.events;
      if(events && typeof events.emitDomainUpdate === 'function'){
        events.emitDomainUpdate('entries', { state: safeState }, { source:'entries-domain-public-api' });
      }else if(typeof window !== 'undefined' && typeof window.dispatchEvent === 'function'){
        try{
          window.dispatchEvent(new CustomEvent('taif:entries-vouchers-updated', { detail: { state: safeState } }));
        }catch{}
      }
    }
    return safeState;
  }

  domain.createDefaultState = createDefaultState;
  domain.normalizeState = normalizeState;
  domain.readState = function(){
    const feature = TAIF.entriesVouchersFeature || {};
    if(typeof feature.readState === 'function') return feature.readState();
    return fallbackReadState();
  };
  domain.writeState = function(nextState, options = {}){
    const feature = TAIF.entriesVouchersFeature || {};
    if(typeof feature.writeState === 'function') return feature.writeState(nextState, options);
    return fallbackWriteState(nextState, options);
  };
  domain.getRecords = function(){
    const state = domain.readState();
    return Array.isArray(state?.records) ? state.records : [];
  };
})();
