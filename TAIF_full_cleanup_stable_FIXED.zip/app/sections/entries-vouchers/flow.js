(()=>{
  /*
   * TAIF Entries & Vouchers render flow helpers.
   * Centralizes rerender/snapshot/focus work so controllers stay small and consistent.
   */
  const TAIF = window.TAIF;
  const { escapeSelectorValue, focusElementWithoutScroll } = TAIF.core.utils;
  const feature = TAIF.entriesVouchersFeature || (TAIF.entriesVouchersFeature = {});
  const {
    runtime,
    getModalLayer,
    snapshotModalCanvasPositions,
    restoreModalCanvasPositions,
    restoreFieldSelection,
    renderEntriesModalLayer,
    renderShellMarkup
  } = feature;

  function renderEntriesBoard({ canvasSnapshot = null, afterRender = null } = {}){
    if(!runtime.panel || !document.body.contains(runtime.panel)) return;
    const snapshot = canvasSnapshot || snapshotModalCanvasPositions();
    runtime.panel.innerHTML = renderShellMarkup();
    renderEntriesModalLayer();
    if(typeof feature.bindEntriesViewEvents === 'function'){
      feature.bindEntriesViewEvents();
    }
    requestAnimationFrame(() => {
      restoreModalCanvasPositions(snapshot);
      if(typeof afterRender === 'function') afterRender();
    });
  }

  function renderEntriesFromSnapshot(snapshot, afterRender = null){
    renderEntriesBoard({
      canvasSnapshot: snapshot,
      afterRender
    });
  }


  function refreshEntriesModalLayer({ snapshot = null, afterRender = null } = {}){
    if(!runtime.panel || !document.body.contains(runtime.panel)){
      renderEntriesBoard({ canvasSnapshot: snapshot, afterRender });
      return;
    }
    const safeSnapshot = snapshot || snapshotModalCanvasPositions();
    renderEntriesModalLayer();
    if(typeof feature.bindEntriesViewEvents === 'function'){
      feature.bindEntriesViewEvents();
    }
    requestAnimationFrame(() => {
      restoreModalCanvasPositions(safeSnapshot);
      if(typeof afterRender === 'function') afterRender();
    });
  }


  function renderEntriesWithSelectionRestore(selection){
    renderEntriesFromSnapshot(snapshotModalCanvasPositions(), () => {
      if(selection) restoreFieldSelection(selection);
    });
  }

  function restoreMovementFieldFocus(sheetId, movementId, fieldName = 'debitAmountText', selectionStart = 0, selectionEnd = 0){
    if(!sheetId || !movementId) return;
    const layer = getModalLayer();
    const preferredFields = Array.from(new Set([
      String(fieldName || '').trim(),
      'debitAmountText',
      'creditAmountText',
      'grossAmountText',
      'receiptAmountText',
      'paymentAmountText',
      'counterpartAccountQuery',
      'beneficiaryName',
      'statement'
    ].filter(Boolean)));
    const resolvedFieldName = preferredFields.find((candidate) => layer?.querySelector(
      `[data-entry-sheet-id="${escapeSelectorValue(sheetId)}"] [data-movement-id="${escapeSelectorValue(movementId)}"][data-field="${escapeSelectorValue(candidate)}"]`
    )) || preferredFields[0];

    restoreFieldSelection({
      sheetId,
      fieldName: resolvedFieldName,
      movementId,
      selectionStart,
      selectionEnd,
      scrollTop: 0,
      scrollIntoView: true
    });
  }

  function restoreLookupFieldFocus(sheetId){
    const layer = getModalLayer();
    const input = layer?.querySelector(
      `[data-entry-sheet-id="${escapeSelectorValue(sheetId)}"] [data-entry-voucher-nav="lookup"]`
    );
    if(!(input instanceof HTMLInputElement)) return;
    focusElementWithoutScroll(input);
    input.select();
  }

  function rerenderEntriesAfterMutation(mutate, {
    snapshot = null,
    afterRender = null,
    shouldRerender = (result) => !!result
  } = {}){
    const safeSnapshot = snapshot || snapshotModalCanvasPositions();
    const result = typeof mutate === 'function' ? mutate() : null;
    if(!shouldRerender(result)) return result;
    renderEntriesFromSnapshot(safeSnapshot, () => {
      if(typeof afterRender === 'function') afterRender(result);
    });
    return result;
  }

  Object.assign(feature, {
    renderEntriesBoard,
    renderEntriesFromSnapshot,
    refreshEntriesModalLayer,
    renderEntriesWithSelectionRestore,
    restoreMovementFieldFocus,
    restoreLookupFieldFocus,
    rerenderEntriesAfterMutation
  });
})();
