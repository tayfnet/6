(()=>{
  /*
   * TAIF Entries & Vouchers drafting helpers.
   * Owns voucher draft normalization and accounting-line construction.
   */
  const TAIF = window.TAIF;
  const feature = TAIF.entriesVouchersFeature || (TAIF.entriesVouchersFeature = {});
  const {
    COMMISSION_OPTIONS,
    clampPositiveAmount,
    normalizeAmountInputText,
    normalizeDateInputValue,
    resolveVoucherType,
    toText,
    todayInputValue,
    readCurrencyCatalog,
    readVoucherCatalogs,
    resolveVoucherCatalogs,
    findCurrencyByCode,
    findAccountByNo,
    findAccountByLookupQuery,
    buildAccountLookupLabel,
    isAccountLookupSettled,
    searchAccounts,
    getCashAccountCatalog,
    resolveDefaultCashAccount,
    getInteractiveVoucherDefinition,
    getCashMotionOptions,
    resolveCashMotionOption,
    isOpeningBalanceEligibleAccount,
    getOpeningBalanceAccountCatalog
  } = feature;

  function normalizeCommissionCode(value){
    const normalized = toText(value).toLowerCase().replace(/[_\s]+/g, '-');
    if(!normalized) return 'none';

    const aliasMap = new Map([
      ['none', 'none'],
      ['no-commission', 'none'],
      ['without-commission', 'none'],
      ['بدون-عمولة', 'none'],
      ['بدون عمولة', 'none'],
      ['debit-ours', 'debit-ours'],
      ['receivable', 'debit-ours'],
      ['commission-receivable', 'debit-ours'],
      ['مدين-لنا', 'debit-ours'],
      ['مدين لنا', 'debit-ours'],
      ['credit-ours', 'credit-ours'],
      ['payable', 'credit-ours'],
      ['commission-payable', 'credit-ours'],
      ['دائن-علينا', 'credit-ours'],
      ['دائن علينا', 'credit-ours'],
      ['mixed', 'mixed'],
      ['multiple', 'mixed'],
      ['متعددة', 'mixed']
    ]);

    return aliasMap.get(normalized) || 'none';
  }


  function resolveCommissionOption(value){
    const safeValue = normalizeCommissionCode(value);
    if(safeValue === 'mixed') return { value: 'mixed', label: 'متعددة' };
    return COMMISSION_OPTIONS.find((option) => option.value === safeValue) || COMMISSION_OPTIONS[0];
  }


  function buildCommissionNote(option){
    const safeOption = option && typeof option === 'object' ? option : resolveCommissionOption(option);
    return safeOption && safeOption.value !== 'none' ? ` / عمولة ${safeOption.label}` : '';
  }


  function createVoucherMovementId(){
    return `entry-movement-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  }


  function isJournalVoucherType(type){
    return resolveVoucherType(type) === 'journal';
  }


  function isSettlementVoucherType(type){
    return resolveVoucherType(type) === 'settlement';
  }


  function isOpeningVoucherType(type){
    return resolveVoucherType(type) === 'opening';
  }


  function resolveOpeningBalanceSide(value){
    return toText(value).toLowerCase() === 'credit' ? 'credit' : 'debit';
  }


  function isOpeningMovementBlank(movement){
    const source = movement && typeof movement === 'object' ? movement : {};
    const debitAmount = clampPositiveAmount(source.debitAmountText ?? source.debitAmount ?? source.debit);
    const creditAmount = clampPositiveAmount(source.creditAmountText ?? source.creditAmount ?? source.credit);
    const legacyAmount = clampPositiveAmount(source.grossAmountText ?? source.amount);
    return !(
      debitAmount > 0
      || creditAmount > 0
      || legacyAmount > 0
      || toText(source.counterpartAccountNo || source.accountNo)
      || toText(source.counterpartAccountQuery)
      || toText(source.statement)
    );
  }


  const JOURNAL_FIXED_MOVEMENT_COUNT = 500;
  const SETTLEMENT_FIXED_MOVEMENT_COUNT = 2;
  const JOURNAL_INITIAL_RENDER_COUNT = 60;
  const JOURNAL_RENDER_CHUNK_SIZE = 60;
  const JOURNAL_RENDER_ACTIVE_BUFFER = 12;


  function buildJournalMovementSlotId(index = 0){
    return `entry-movement-journal-slot-${String(Math.max(0, Number(index) || 0) + 1).padStart(3, '0')}`;
  }


  function buildSettlementMovementSlotId(index = 0){
    return `entry-movement-settlement-slot-${String(Math.max(0, Number(index) || 0) + 1).padStart(3, '0')}`;
  }


  function isJournalMovementBlank(movement){
    const source = movement && typeof movement === 'object' ? movement : {};
    const receiptAmount = clampPositiveAmount(source.receiptAmountText ?? source.receiptAmount);
    const paymentAmount = clampPositiveAmount(source.paymentAmountText ?? source.paymentAmount);
    return !(
      receiptAmount > 0
      || paymentAmount > 0
      || toText(source.counterpartAccountNo)
      || toText(source.counterpartAccountQuery)
      || toText(source.beneficiaryName || source.partyName)
      || toText(source.statement)
    );
  }


  function resolveJournalVisibleMovementCount(movements, preferredCount = 0){
    const safeMovements = Array.isArray(movements) ? movements : [];
    const requestedCount = Math.max(0, Number(preferredCount) || 0);
    const lastActiveIndex = safeMovements.reduce((activeIndex, movement, index) => (
      isJournalMovementBlank(movement) ? activeIndex : index
    ), -1);
    const activeCount = lastActiveIndex >= 0 ? (lastActiveIndex + 1 + JOURNAL_RENDER_ACTIVE_BUFFER) : 0;
    const baseCount = Math.max(JOURNAL_INITIAL_RENDER_COUNT, JOURNAL_RENDER_CHUNK_SIZE, requestedCount, activeCount, 1);
    return Math.max(1, Math.min(safeMovements.length || JOURNAL_FIXED_MOVEMENT_COUNT, baseCount));
  }


  function ensureJournalFixedMovements(rawMovements, catalogs = null, cashAccountNo = '', cashMotionCode = '', draftCurrencyCode = ''){
    const normalized = (Array.isArray(rawMovements) ? rawMovements : [])
      .map((movement) => normalizeVoucherMovement({
        ...(movement && typeof movement === 'object' ? movement : {}),
        currencyCode: draftCurrencyCode
      }, catalogs, cashAccountNo, 'journal', cashMotionCode))
      .filter(Boolean);
    const targetCount = Math.max(JOURNAL_FIXED_MOVEMENT_COUNT, normalized.length || 0, 1);
    const padded = normalized.slice(0, targetCount);

    for(let index = padded.length; index < targetCount; index += 1){
      padded.push(createVoucherMovement({
        id: buildJournalMovementSlotId(index),
        currencyCode: draftCurrencyCode
      }, catalogs, cashAccountNo, 'journal', cashMotionCode));
    }

    return padded.map((movement, index) => ({
      ...movement,
      id: buildJournalMovementSlotId(index),
      currencyCode: draftCurrencyCode
    }));
  }


  function ensureSettlementFixedMovements(rawMovements, catalogs = null, cashAccountNo = '', cashMotionCode = '', draftCurrencyCode = '', draftDate = ''){
    const normalized = (Array.isArray(rawMovements) ? rawMovements : [])
      .slice(0, SETTLEMENT_FIXED_MOVEMENT_COUNT)
      .map((movement, index) => normalizeVoucherMovement({
        ...movement,
        id: toText(movement?.id) || buildSettlementMovementSlotId(index),
        currencyCode: toText(movement?.currencyCode, draftCurrencyCode),
        date: toText(movement?.date, draftDate)
      }, catalogs, cashAccountNo, 'settlement', cashMotionCode))
      .filter(Boolean);
    const padded = normalized.slice(0, SETTLEMENT_FIXED_MOVEMENT_COUNT);

    for(let index = padded.length; index < SETTLEMENT_FIXED_MOVEMENT_COUNT; index += 1){
      padded.push(createVoucherMovement({
        id: buildSettlementMovementSlotId(index),
        currencyCode: draftCurrencyCode,
        date: draftDate
      }, catalogs, cashAccountNo, 'settlement', cashMotionCode));
    }

    return padded.map((movement, index) => ({
      ...movement,
      id: buildSettlementMovementSlotId(index),
      currencyCode: toText(movement?.currencyCode, draftCurrencyCode),
      date: normalizeDateInputValue(toText(movement?.date, draftDate))
    }));
  }


  function formatSettlementAmountLabel(amountText, currency){
    const amount = clampPositiveAmount(amountText);
    if(!(amount > 0)) return '';
    const safeCurrency = currency && typeof currency === 'object' ? currency : null;
    const currencyCode = toText(safeCurrency?.code, 'USD').toUpperCase() || 'USD';
    const currencyName = toText(safeCurrency?.name, currencyCode) || currencyCode;
    const decimals = Number.isFinite(Number(safeCurrency?.decimals))
      ? Math.max(0, Number(safeCurrency.decimals))
      : 2;
    const formattedAmount = amount.toLocaleString('en-US', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    });
    return `${formattedAmount} ${currencyName}`;
  }


  function buildSettlementAutoSummaries({ debitAccount = null, creditAccount = null, currency = null, amountText = '' } = {}){
    if(!debitAccount || !creditAccount) return { debitSummary: '', creditSummary: '' };
    const debitAccountName = toText(debitAccount?.name, debitAccount?.accountNo);
    const creditAccountName = toText(creditAccount?.name, creditAccount?.accountNo);
    const amountLabel = formatSettlementAmountLabel(amountText, currency);
    if(!debitAccountName || !creditAccountName || !amountLabel){
      return { debitSummary: '', creditSummary: '' };
    }

    return {
      debitSummary: `إيداع داخلي وارد إلى حساب ${debitAccountName} بمبلغ ${amountLabel} من حساب ${creditAccountName}.`,
      creditSummary: `تحويل داخلي صادر من حساب ${creditAccountName} إلى حساب ${debitAccountName} بمبلغ ${amountLabel}.`
    };
  }


  function finalizeSettlementDraft(rawDraft, catalogs = null, options = {}){
    const safeDraft = rawDraft && typeof rawDraft === 'object' ? rawDraft : {};
    const safeCatalogs = resolveVoucherCatalogs(catalogs);
    const sourceIndex = Math.max(0, Math.min(SETTLEMENT_FIXED_MOVEMENT_COUNT - 1, Number(options?.sourceIndex) || 0));
    const changedFields = new Set((Array.isArray(options?.changedFields) ? options.changedFields : [])
      .map((field) => String(field || '').trim())
      .filter(Boolean));
    const draftDate = normalizeDateInputValue(toText(safeDraft?.date));
    const draftCurrencyCode = toText(safeDraft?.currencyCode, 'USD').toUpperCase() || 'USD';
    const safeMovements = ensureSettlementFixedMovements(
      Array.isArray(safeDraft?.movements) ? safeDraft.movements : [],
      safeCatalogs,
      toText(safeDraft?.cashAccountNo),
      toText(safeDraft?.cashMotionCode, 'settlement-balance'),
      draftCurrencyCode,
      draftDate
    );
    const sourceMovement = safeMovements[sourceIndex] || safeMovements[0] || null;
    const sharedDate = normalizeDateInputValue(
      changedFields.has('date')
        ? toText(sourceMovement?.date, safeDraft?.date || todayInputValue())
        : toText(safeMovements[0]?.date || safeMovements[1]?.date || safeDraft?.date, todayInputValue())
    );
    const sharedCurrencyCode = findCurrencyByCode(
      changedFields.has('currencyCode')
        ? toText(sourceMovement?.currencyCode, draftCurrencyCode)
        : toText(safeMovements[0]?.currencyCode || safeMovements[1]?.currencyCode || draftCurrencyCode),
      safeCatalogs.currencies
    ).code;
    const sharedAmountText = changedFields.has('grossAmountText')
      ? normalizeAmountInputText(sourceMovement?.grossAmountText)
      : normalizeAmountInputText(safeMovements[0]?.grossAmountText || safeMovements[1]?.grossAmountText);
    const syncedMovements = safeMovements.map((movement) => ({
      ...movement,
      date: sharedDate,
      currencyCode: sharedCurrencyCode,
      grossAmountText: sharedAmountText
    }));
    const debitAccount = findAccountByNo(toText(syncedMovements[0]?.counterpartAccountNo), safeCatalogs.accounts);
    const creditAccount = findAccountByNo(toText(syncedMovements[1]?.counterpartAccountNo), safeCatalogs.accounts);
    const sharedCurrency = findCurrencyByCode(sharedCurrencyCode, safeCatalogs.currencies);
    const { debitSummary, creditSummary } = buildSettlementAutoSummaries({
      debitAccount,
      creditAccount,
      currency: sharedCurrency,
      amountText: sharedAmountText
    });

    return {
      ...safeDraft,
      date: sharedDate,
      currencyCode: sharedCurrencyCode,
      movements: syncedMovements.map((movement, index) => ({
        ...movement,
        summary: index === 0 ? debitSummary : creditSummary
      }))
    };
  }

  function resolveJournalMovementAmounts(source, cashMotionCode = ''){
    const hasReceiptField = Object.prototype.hasOwnProperty.call(source, 'receiptAmountText') || Object.prototype.hasOwnProperty.call(source, 'receiptAmount');
    const hasPaymentField = Object.prototype.hasOwnProperty.call(source, 'paymentAmountText') || Object.prototype.hasOwnProperty.call(source, 'paymentAmount');
    let receiptAmountText = hasReceiptField
      ? normalizeAmountInputText(source.receiptAmountText ?? source.receiptAmount)
      : '';
    let paymentAmountText = hasPaymentField
      ? normalizeAmountInputText(source.paymentAmountText ?? source.paymentAmount)
      : '';

    if(!receiptAmountText && !paymentAmountText){
      const hasLegacyAmount = Object.prototype.hasOwnProperty.call(source, 'grossAmountText')
        || Object.prototype.hasOwnProperty.call(source, 'grossAmount')
        || Object.prototype.hasOwnProperty.call(source, 'amount');
      const legacyAmountText = hasLegacyAmount
        ? normalizeAmountInputText(source.grossAmountText ?? source.grossAmount ?? source.amount)
        : '';
      if(legacyAmountText){
        const legacyMotionCode = toText(source.cashMotionCode || cashMotionCode);
        if(legacyMotionCode === 'primary-credit'){
          paymentAmountText = legacyAmountText;
        }else{
          receiptAmountText = legacyAmountText;
        }
      }
    }

    return {
      receiptAmountText,
      paymentAmountText
    };
  }


  function normalizeVoucherMovement(raw, catalogs = null, cashAccountNo = '', type = '', cashMotionCode = ''){
    const source = raw && typeof raw === 'object' ? raw : {};
    const safeType = resolveVoucherType(type);
    const { accounts, currencies } = resolveVoucherCatalogs(catalogs);
    const commission = resolveCommissionOption(source.commissionCode);
    const requestedCounterpartAccountNo = toText(source.counterpartAccountNo || source.accountNo);
    const requestedCounterpartAccountQuery = toText(source.counterpartAccountQuery || source.accountQuery);
    const counterpartAccount = requestedCounterpartAccountNo
      ? findAccountByNo(requestedCounterpartAccountNo, accounts)
      : (requestedCounterpartAccountQuery ? findAccountByLookupQuery(requestedCounterpartAccountQuery, accounts) : null);
    const hasConflictingCounterpart = !isSettlementVoucherType(safeType)
      && !!(cashAccountNo && counterpartAccount && counterpartAccount.accountNo === cashAccountNo);
    const counterpartAccountLookupLabel = counterpartAccount ? buildAccountLookupLabel(counterpartAccount) : '';
    const movementCurrency = findCurrencyByCode(toText(source.currencyCode), currencies);
    const baseMovement = {
      id: toText(source.id) || createVoucherMovementId(),
      date: normalizeDateInputValue(source.date),
      currencyCode: movementCurrency.code,
      counterpartAccountNo: hasConflictingCounterpart ? '' : (counterpartAccount ? counterpartAccount.accountNo : ''),
      counterpartAccountQuery: requestedCounterpartAccountQuery || counterpartAccountLookupLabel,
      beneficiaryName: toText(source.beneficiaryName || source.partyName),
      statement: toText(source.statement),
      summary: toText(source.summary)
    };

    if(isJournalVoucherType(safeType)){
      return {
        ...baseMovement,
        ...resolveJournalMovementAmounts(source, cashMotionCode)
      };
    }

    if(isOpeningVoucherType(safeType)){
      const explicitDebitText = normalizeAmountInputText(source.debitAmountText ?? source.debitAmount ?? source.debit);
      const explicitCreditText = normalizeAmountInputText(source.creditAmountText ?? source.creditAmount ?? source.credit);
      const legacySide = resolveOpeningBalanceSide(source.balanceSideCode || source.side);
      const legacyAmountText = normalizeAmountInputText(source.grossAmountText ?? source.amount);
      const debitAmountText = explicitDebitText || ((!explicitCreditText && legacySide !== 'credit') ? legacyAmountText : '');
      const creditAmountText = explicitCreditText || ((!explicitDebitText && legacySide === 'credit') ? legacyAmountText : '');
      return {
        ...baseMovement,
        debitAmountText,
        creditAmountText,
        balanceSideCode: explicitCreditText && !explicitDebitText ? 'credit' : 'debit',
        grossAmountText: normalizeAmountInputText(source.grossAmountText ?? source.amount)
      };
    }

    return {
      ...baseMovement,
      commissionCode: commission.value,
      commissionFeeText: normalizeAmountInputText(source.commissionFeeText),
      grossAmountText: normalizeAmountInputText(source.grossAmountText)
    };
  }


  function createVoucherMovement(raw = {}, catalogs = null, cashAccountNo = '', type = '', cashMotionCode = ''){
    return normalizeVoucherMovement(raw, catalogs, cashAccountNo, type, cashMotionCode);
  }


  function canReuseVoucherDraft(rawDraft, safeType){
    const source = rawDraft && typeof rawDraft === 'object' ? rawDraft : null;
    if(!source || !Array.isArray(source.movements)) return false;
    const resolvedType = resolveVoucherType(source.type || safeType);
    if(resolvedType !== safeType) return false;
    if(isJournalVoucherType(safeType) && source.movements.length !== JOURNAL_FIXED_MOVEMENT_COUNT) return false;
    if(isSettlementVoucherType(safeType) && source.movements.length !== SETTLEMENT_FIXED_MOVEMENT_COUNT) return false;
    return true;
  }


  function normalizeVoucherDraft(raw, type, catalogs = null){
    const safeType = resolveVoucherType(type);
    const { accounts, currencies } = resolveVoucherCatalogs(catalogs);
    const source = raw && typeof raw === 'object' ? raw : {};

    if(isOpeningVoucherType(safeType)){
      const hasExplicitOpeningMovements = Array.isArray(source.movements) && source.movements.length > 0;
      const hasOpeningSeedValues = !!(
        toText(source.counterpartAccountNo)
        || toText(source.counterpartAccountQuery)
        || toText(source.debitAmountText)
        || toText(source.creditAmountText)
        || toText(source.statement)
      );
      const rawMovements = hasExplicitOpeningMovements
        ? source.movements
        : (hasOpeningSeedValues ? [source] : [{}, {}]);
      const openingCurrency = findCurrencyByCode(
        toText(source.currencyCode, toText(rawMovements.find((movement) => toText(movement?.currencyCode))?.currencyCode)),
        currencies
      );
      const movements = rawMovements
        .map((movement) => normalizeVoucherMovement({
          ...(movement && typeof movement === 'object' ? movement : {}),
          currencyCode: openingCurrency.code
        }, catalogs, '', safeType, 'opening-balance'))
        .filter(Boolean);
      return {
        type: safeType,
        currencyCode: openingCurrency.code,
        cashMotionCode: 'opening-balance',
        cashMotionPickerCode: '',
        date: normalizeDateInputValue(source.date),
        cashAccountNo: '',
        movements: movements.length
          ? movements
          : [
              createVoucherMovement({ currencyCode: openingCurrency.code }, catalogs, '', safeType, 'opening-balance'),
              createVoucherMovement({ currencyCode: openingCurrency.code }, catalogs, '', safeType, 'opening-balance')
            ]
      };
    }

    const definition = getInteractiveVoucherDefinition(safeType);
    const usesCashBoxPrimaryAccount = !isSettlementVoucherType(safeType);
    const cashAccountOptions = usesCashBoxPrimaryAccount && typeof getCashAccountCatalog === 'function'
      ? getCashAccountCatalog(accounts)
      : accounts.filter(Boolean);
    const defaultCash = resolveDefaultCashAccount(accounts);
    const requestedCashAccountNo = toText(source.cashAccountNo, defaultCash && defaultCash.accountNo);
    const cashAccount = findAccountByNo(requestedCashAccountNo, cashAccountOptions) || defaultCash;
    const currency = findCurrencyByCode(toText(source.currencyCode), currencies);
    const cashMotion = resolveCashMotionOption(safeType, source.cashMotionCode);
    const cashMotionPickerOptions = Array.isArray(definition?.cashMotionPickerOptions)
      ? definition.cashMotionPickerOptions
        .map((option) => {
          const value = toText(option?.value || option?.code || option?.label);
          const label = toText(option?.label, value);
          return value && label ? { value, label } : null;
        })
        .filter(Boolean)
      : [];
    const requestedCashMotionPickerCode = toText(source.cashMotionPickerCode);
    const cashMotionPickerCode = (cashMotionPickerOptions.find((option) => option.value === requestedCashMotionPickerCode) || cashMotionPickerOptions[0] || { value: '' }).value;
    const rawMovements = Array.isArray(source.movements) && source.movements.length ? source.movements : [source];
    const cashAccountNo = cashAccount ? cashAccount.accountNo : '';
    const draftCurrencyCode = currency.code;
    const movements = isJournalVoucherType(safeType)
      ? ensureJournalFixedMovements(rawMovements, catalogs, cashAccountNo, cashMotion.value, draftCurrencyCode)
      : isSettlementVoucherType(safeType)
        ? ensureSettlementFixedMovements(rawMovements, catalogs, cashAccountNo, cashMotion.value, draftCurrencyCode, normalizeDateInputValue(source.date))
        : rawMovements
          .map((movement) => normalizeVoucherMovement({
            ...(movement && typeof movement === 'object' ? movement : {}),
            currencyCode: draftCurrencyCode
          }, catalogs, cashAccountNo, safeType, cashMotion.value))
          .filter(Boolean);

    const normalizedDraft = {
      type: safeType,
      currencyCode: currency.code,
      cashMotionCode: cashMotion.value,
      cashMotionPickerCode,
      date: normalizeDateInputValue(source.date),
      cashAccountNo,
      movements: movements.length ? movements : [createVoucherMovement({}, catalogs, cashAccountNo, safeType, cashMotion.value)]
    };

    if(isSettlementVoucherType(safeType)){
      return finalizeSettlementDraft(normalizedDraft, catalogs);
    }

    return normalizedDraft;
  }


  function createVoucherDraft(type, catalogs = null){
    return normalizeVoucherDraft({}, type, catalogs);
  }


  function buildStatementSuggestion(type, cashAccount, counterpartAccount, commissionCode = 'none', cashMotionCode = '', movementDraft = null){
    const safeType = resolveVoucherType(type);
    const definition = getInteractiveVoucherDefinition(safeType);
    const targetName = counterpartAccount ? counterpartAccount.name : 'الحساب المقابل';
    const primaryAccountLabel = toText(definition?.primaryAccountLabel, 'الحساب الأساسي') || 'الحساب الأساسي';
    const primaryAccountName = cashAccount ? cashAccount.name : primaryAccountLabel;

    if(isOpeningVoucherType(safeType)){
      return `رصيد افتتاحي لحساب ${targetName}`;
    }

    if(isJournalVoucherType(safeType)){
      const receiptAmount = clampPositiveAmount(movementDraft?.receiptAmountText);
      const paymentAmount = clampPositiveAmount(movementDraft?.paymentAmountText);
      const hasReceipt = receiptAmount > 0;
      const hasPayment = paymentAmount > 0;
      const fallbackMotion = resolveCashMotionOption(safeType, cashMotionCode).value;
      const directionLabel = hasPayment && !hasReceipt
        ? 'دفع إلى'
        : hasReceipt && !hasPayment
          ? 'قبض من'
          : (fallbackMotion === 'primary-credit' ? 'دفع إلى' : 'قبض من');
      return `${directionLabel} ${targetName} عبر ${primaryAccountName}`;
    }

    const statementDirection = toText(definition?.statementDirection, 'قيد مع') || 'قيد مع';
    const resolvedCashMotion = resolveCashMotionOption(safeType, cashMotionCode);
    const motionHint = toText(resolvedCashMotion?.label);
    const commissionPart = buildCommissionNote(commissionCode);
    const motionPart = motionHint && motionHint !== statementDirection ? ` / ${motionHint}` : '';
    return `${statementDirection} ${targetName} عبر ${primaryAccountName}${motionPart}${commissionPart}`;
  }


  function resolveVoucherLineBlueprints(type, cashMotionCode = ''){
    const definition = getInteractiveVoucherDefinition(type);
    const resolvedCashMotion = resolveCashMotionOption(type, cashMotionCode);
    const lineBlueprintsByMotion = definition && typeof definition.lineBlueprintsByMotion === 'object'
      ? definition.lineBlueprintsByMotion
      : null;
    const motionBlueprints = lineBlueprintsByMotion && Array.isArray(lineBlueprintsByMotion[resolvedCashMotion.value])
      ? lineBlueprintsByMotion[resolvedCashMotion.value]
      : null;
    if(Array.isArray(motionBlueprints) && motionBlueprints.length) return motionBlueprints;
    return Array.isArray(definition?.lineBlueprints) ? definition.lineBlueprints : [];
  }


  function buildVoucherLineDescription(roleLabel, baseStatement){
    return `${roleLabel} — ${baseStatement}`;
  }


  function createVoucherLine(lineNo, blueprint, account, statementText, amount){
    if(!blueprint || !account || amount <= 0) return null;
    const isDebit = blueprint.side === 'debit';
    return {
      lineNo,
      roleKey: blueprint.roleKey,
      roleLabel: blueprint.roleLabel,
      accountNo: account.accountNo,
      accountName: account.name,
      description: buildVoucherLineDescription(blueprint.roleLabel, statementText),
      debit: isDebit ? amount : 0,
      credit: isDebit ? 0 : amount,
      side: isDebit ? 'debit' : 'credit',
      amount
    };
  }


  function buildVoucherLines(type, amount, accountsByRole, statementText, cashMotionCode = ''){
    const blueprints = resolveVoucherLineBlueprints(type, cashMotionCode);
    return blueprints.reduce((lines, blueprint) => {
      const line = createVoucherLine(lines.length + 1, blueprint, accountsByRole[blueprint.accountKey], statementText, amount);
      if(line) lines.push(line);
      return lines;
    }, []);
  }


  function joinUniqueTexts(values, separator = ' / '){
    const unique = [];
    (Array.isArray(values) ? values : []).forEach((value) => {
      const text = toText(value);
      if(!text || unique.includes(text)) return;
      unique.push(text);
    });
    return unique.join(separator);
  }


  function summarizeVoucherCommission(movements){
    const codes = Array.from(new Set((Array.isArray(movements) ? movements : [])
      .map((movement) => normalizeCommissionCode(movement?.commission?.value || movement?.draft?.commissionCode))
      .filter(Boolean)));

    if(!codes.length || (codes.length === 1 && codes[0] === 'none')) return resolveCommissionOption('none');
    if(codes.length === 1) return resolveCommissionOption(codes[0]);
    return { value: 'mixed', label: 'متعددة' };
  }


  function buildVoucherMovementContext({ type, movementDraft, cashAccount, counterpartAccountOptions, accounts, currencies, cashMotionCode = '' }){
    const safeType = resolveVoucherType(type);
    const definition = getInteractiveVoucherDefinition(safeType);
    const primaryAccountLabel = toText(definition?.primaryAccountLabel, 'الحساب الأساسي') || 'الحساب الأساسي';
    const safeMovementDraft = normalizeVoucherMovement(
      movementDraft,
      { accounts, currencies: Array.isArray(currencies) ? currencies : readCurrencyCatalog() },
      cashAccount ? cashAccount.accountNo : '',
      safeType,
      cashMotionCode
    );
    const counterpartAccount = safeMovementDraft.counterpartAccountNo ? findAccountByNo(safeMovementDraft.counterpartAccountNo, accounts) : null;
    const counterpartAccountLookupLabel = counterpartAccount ? buildAccountLookupLabel(counterpartAccount) : '';
    const counterpartAccountQuery = toText(safeMovementDraft.counterpartAccountQuery, counterpartAccountLookupLabel);
    const counterpartAccountSearchResults = searchAccounts(counterpartAccountQuery, counterpartAccountOptions, [], 8);
    const counterpartAccountSearchSettled = isAccountLookupSettled(counterpartAccountQuery, counterpartAccount);
    const validationIssues = [];
    const hasConflictingCounterpartSelection = !!(safeMovementDraft.counterpartAccountNo && cashAccount && safeMovementDraft.counterpartAccountNo === cashAccount.accountNo);
    const isJournalVoucher = isJournalVoucherType(safeType);
    const isOpeningVoucher = isOpeningVoucherType(safeType);
    const isPlaceholder = isOpeningVoucher
      ? isOpeningMovementBlank(safeMovementDraft)
      : (isJournalVoucher && isJournalMovementBlank(safeMovementDraft));

    let commission = resolveCommissionOption(safeMovementDraft.commissionCode);
    let grossAmount = 0;
    let netAmount = 0;
    let receiptAmount = 0;
    let paymentAmount = 0;
    let debitAmount = 0;
    let creditAmount = 0;
    let resolvedCashMotionCode = cashMotionCode;
    let balanceSideCode = resolveOpeningBalanceSide(safeMovementDraft.balanceSideCode);

    if(isOpeningVoucher){
      debitAmount = clampPositiveAmount(safeMovementDraft.debitAmountText);
      creditAmount = clampPositiveAmount(safeMovementDraft.creditAmountText);
      grossAmount = Math.max(debitAmount, creditAmount);
      netAmount = grossAmount;
      balanceSideCode = creditAmount > 0 && debitAmount <= 0 ? 'credit' : 'debit';
      if(!isPlaceholder){
        if(!counterpartAccount){
          validationIssues.push('حدد الحساب الذي تريد افتتاح رصيده.');
        }
        if(counterpartAccount && typeof isOpeningBalanceEligibleAccount === 'function' && !isOpeningBalanceEligibleAccount(counterpartAccount)){
          validationIssues.push('هذا الحساب لا يُعتمد كرصيد افتتاحي لأنه يبدو حساب نتيجة أو تشغيل وليس من أرصدة الميزانية.');
        }
        if(debitAmount <= 0 && creditAmount <= 0){
          validationIssues.push('أدخل مبلغاً مديناً أو دائناً أكبر من صفر.');
        }
        if(debitAmount > 0 && creditAmount > 0){
          validationIssues.push('استخدم المدين أو الدائن في السطر نفسه، ولا تجمع الطرفين معاً في نفس البطاقة.');
        }
      }
      commission = resolveCommissionOption('none');
    }else if(isJournalVoucher){
      receiptAmount = clampPositiveAmount(safeMovementDraft.receiptAmountText);
      paymentAmount = clampPositiveAmount(safeMovementDraft.paymentAmountText);
      const hasReceiptAmount = receiptAmount > 0;
      const hasPaymentAmount = paymentAmount > 0;
      const hasConflictingAmounts = hasReceiptAmount && hasPaymentAmount;

      if(!isPlaceholder){
        if(!hasReceiptAmount && !hasPaymentAmount){
          validationIssues.push('أدخل مبلغ قبض أو دفع أكبر من صفر قبل اعتماد السند.');
        }
        if(hasConflictingAmounts){
          validationIssues.push('لا تجمع بين القبض والدفع في البطاقة نفسها.');
        }
      }

      if(hasReceiptAmount && !hasConflictingAmounts){
        grossAmount = receiptAmount;
        netAmount = receiptAmount;
        resolvedCashMotionCode = 'primary-debit';
      }else if(hasPaymentAmount && !hasConflictingAmounts){
        grossAmount = paymentAmount;
        netAmount = paymentAmount;
        resolvedCashMotionCode = 'primary-credit';
      }else{
        const fallbackMotion = resolveCashMotionOption(safeType, cashMotionCode).value;
        resolvedCashMotionCode = fallbackMotion === 'primary-credit' ? 'primary-credit' : 'primary-debit';
      }
    }else{
      grossAmount = clampPositiveAmount(safeMovementDraft.grossAmountText);
      netAmount = grossAmount;
      if(grossAmount <= 0) validationIssues.push('أدخل مبلغاً أكبر من صفر قبل اعتماد السند.');
    }

    const statementSuggestion = buildStatementSuggestion(
      safeType,
      cashAccount,
      counterpartAccount,
      (isJournalVoucher || isOpeningVoucher) ? 'none' : commission.value,
      resolvedCashMotionCode,
      safeMovementDraft
    );
    const statementText = safeMovementDraft.statement || statementSuggestion;

    if(!isOpeningVoucher){
      if(!isPlaceholder && !counterpartAccount) validationIssues.push('حدد الحساب المقابل الذي سيتم القيد معه.');
      if(!isPlaceholder && hasConflictingCounterpartSelection){
        validationIssues.push(`يجب أن يختلف الحساب المقابل عن ${primaryAccountLabel} حتى يكون القيد صحيحاً.`);
      }
    }

    const lines = isOpeningVoucher
      ? (((debitAmount > 0 || creditAmount > 0) && counterpartAccount) ? [{
          lineNo: 1,
          roleKey: 'opening-balance',
          roleLabel: creditAmount > 0 && debitAmount <= 0 ? 'رصيد افتتاحي دائن' : 'رصيد افتتاحي مدين',
          accountNo: counterpartAccount.accountNo,
          accountName: counterpartAccount.name,
          description: statementText,
          debit: debitAmount,
          credit: creditAmount,
          side: creditAmount > 0 && debitAmount <= 0 ? 'credit' : 'debit',
          amount: Math.max(debitAmount, creditAmount)
        }] : [])
      : (grossAmount > 0
        ? buildVoucherLines(safeType, grossAmount, { cashAccount, counterpartAccount }, statementText, resolvedCashMotionCode)
        : []);

    return {
      id: safeMovementDraft.id,
      isPlaceholder,
      draft: safeMovementDraft,
      commission,
      commissionOptions: isOpeningVoucher ? [resolveCommissionOption('none')] : COMMISSION_OPTIONS,
      counterpartAccount,
      counterpartAccountOptions,
      counterpartAccountLookupLabel,
      counterpartAccountQuery,
      counterpartAccountSearchResults,
      counterpartAccountSearchSettled,
      statementSuggestion,
      statementText,
      receiptAmount,
      paymentAmount,
      grossAmount,
      netAmount,
      debitAmount,
      creditAmount,
      cashMotionCode: resolvedCashMotionCode,
      balanceSideCode,
      lines,
      validationIssues
    };
  }


  function summarizeOpeningBalanceCurrencies(movements, currencies = []){
    const safeMovements = Array.isArray(movements) ? movements : [];
    const groups = new Map();

    safeMovements.forEach((movement) => {
      if(!movement || movement.isPlaceholder) return;
      const currencyCode = toText(movement?.draft?.currencyCode || movement?.currencyCode, 'USD').toUpperCase() || 'USD';
      const current = groups.get(currencyCode) || {
        code: currencyCode,
        currency: findCurrencyByCode(currencyCode, currencies),
        debitTotal: 0,
        creditTotal: 0,
        lineCount: 0
      };
      const debitAmount = clampPositiveAmount(movement?.debitAmount ?? movement?.draft?.debitAmountText ?? 0);
      const creditAmount = clampPositiveAmount(movement?.creditAmount ?? movement?.draft?.creditAmountText ?? 0);
      current.debitTotal += debitAmount;
      current.creditTotal += creditAmount;
      if(debitAmount > 0 || creditAmount > 0) current.lineCount += 1;
      groups.set(currencyCode, current);
    });

    return Array.from(groups.values())
      .map((entry) => {
        const difference = Math.abs(entry.debitTotal - entry.creditTotal);
        const balanced = entry.lineCount > 0
          && entry.debitTotal > 0
          && entry.creditTotal > 0
          && difference < 0.0001;
        return {
          ...entry,
          difference,
          balanced
        };
      })
      .sort((left, right) => left.code.localeCompare(right.code, 'en'));
  }


  function buildVoucherRenderContext(type, rawDraft, options = {}){
    const safeType = resolveVoucherType(type);
    const catalogs = readVoucherCatalogs();
    const { accounts, currencies } = catalogs;
    const draft = canReuseVoucherDraft(rawDraft, safeType)
      ? rawDraft
      : normalizeVoucherDraft(rawDraft, safeType, catalogs);
    const isOpeningVoucher = isOpeningVoucherType(safeType);
    const isSettlementVoucher = isSettlementVoucherType(safeType);
    const usesCashBoxPrimaryAccount = !isSettlementVoucher;
    const cashAccountOptions = isOpeningVoucher
      ? []
      : (usesCashBoxPrimaryAccount && typeof getCashAccountCatalog === 'function'
          ? getCashAccountCatalog(accounts)
          : accounts.filter(Boolean));
    const cashAccount = isOpeningVoucher ? null : findAccountByNo(draft.cashAccountNo, cashAccountOptions);
    const counterpartAccountOptions = isOpeningVoucher
      ? ((typeof getOpeningBalanceAccountCatalog === 'function' ? getOpeningBalanceAccountCatalog(accounts) : accounts.filter(Boolean)))
      : isSettlementVoucherType(safeType)
        ? accounts.filter(Boolean)
        : accounts.filter((account) => account && account.accountNo !== (cashAccount && cashAccount.accountNo));
    const currency = findCurrencyByCode(draft.currencyCode, currencies);
    const definition = getInteractiveVoucherDefinition(safeType);
    const cashMotionOptions = getCashMotionOptions(safeType);
    const cashMotionPickerOptions = Array.isArray(definition?.cashMotionPickerOptions)
      ? definition.cashMotionPickerOptions
        .map((option) => {
          const value = toText(option?.value || option?.code || option?.label);
          const label = toText(option?.label, value);
          return value && label ? { value, label } : null;
        })
        .filter(Boolean)
      : cashMotionOptions;
    const cashMotion = resolveCashMotionOption(safeType, draft.cashMotionCode);
    const primaryAccountLabel = toText(definition?.primaryAccountLabel, 'الحساب الأساسي') || 'الحساب الأساسي';
    const validationIssues = [];

    if(!draft.date) validationIssues.push('حدد تاريخ السند قبل المتابعة.');
    if(!isOpeningVoucher){
      if(!currency || !currency.code) validationIssues.push('اختر عملة صحيحة للسند.');
      if(!isSettlementVoucher && !cashAccount) validationIssues.push(`حدد ${primaryAccountLabel} قبل اعتماد السند.`);
    }

    const totalMovements = Array.isArray(draft.movements) ? draft.movements.length : 0;
    const isJournalVoucher = isJournalVoucherType(safeType);
    const visibleCount = isJournalVoucher
      ? resolveJournalVisibleMovementCount(draft.movements, options.visibleCount)
      : totalMovements;
    const movementDrafts = isJournalVoucher
      ? draft.movements.slice(0, visibleCount)
      : draft.movements;
    const movements = movementDrafts.map((movementDraft) => buildVoucherMovementContext({
      type: safeType,
      movementDraft,
      cashAccount,
      counterpartAccountOptions,
      accounts,
      currencies,
      cashMotionCode: draft.cashMotionCode
    }));
    const openingBalanceSummaries = isOpeningVoucher ? summarizeOpeningBalanceCurrencies(movements, currencies) : [];

    return {
      type: safeType,
      draft,
      copy: definition,
      accounts,
      cashAccountOptions,
      counterpartAccountOptions,
      currencies,
      cashMotionOptions,
      cashMotionPickerOptions,
      cashMotion,
      commissionOptions: COMMISSION_OPTIONS,
      currency,
      cashAccount,
      movements,
      validationIssues,
      openingBalanceSummaries,
      journalTotalMovements: totalMovements,
      journalRenderedCount: movements.length,
      journalHasMoreMovements: isJournalVoucher && movements.length < totalMovements
    };
  }


  function buildVoucherContext(type, rawDraft){
    const safeType = resolveVoucherType(type);
    const catalogs = readVoucherCatalogs();
    const { accounts, currencies } = catalogs;
    const draft = normalizeVoucherDraft(rawDraft, safeType, catalogs);
    const isOpeningVoucher = isOpeningVoucherType(safeType);
    const isSettlementVoucher = isSettlementVoucherType(safeType);
    const usesCashBoxPrimaryAccount = !isSettlementVoucher;
    const cashAccountOptions = isOpeningVoucher
      ? []
      : (usesCashBoxPrimaryAccount && typeof getCashAccountCatalog === 'function'
          ? getCashAccountCatalog(accounts)
          : accounts.filter(Boolean));
    const cashAccount = isOpeningVoucher ? null : findAccountByNo(draft.cashAccountNo, cashAccountOptions);
    const counterpartAccountOptions = isOpeningVoucher
      ? ((typeof getOpeningBalanceAccountCatalog === 'function' ? getOpeningBalanceAccountCatalog(accounts) : accounts.filter(Boolean)))
      : isSettlementVoucher
        ? accounts.filter(Boolean)
        : accounts.filter((account) => account && account.accountNo !== (cashAccount && cashAccount.accountNo));
    const currency = findCurrencyByCode(draft.currencyCode, currencies);
    const definition = getInteractiveVoucherDefinition(safeType);
    const cashMotionOptions = getCashMotionOptions(safeType);
    const cashMotionPickerOptions = Array.isArray(definition?.cashMotionPickerOptions)
      ? definition.cashMotionPickerOptions
        .map((option) => {
          const value = toText(option?.value || option?.code || option?.label);
          const label = toText(option?.label, value);
          return value && label ? { value, label } : null;
        })
        .filter(Boolean)
      : cashMotionOptions;
    const cashMotion = resolveCashMotionOption(safeType, draft.cashMotionCode);
    const primaryAccountLabel = toText(definition?.primaryAccountLabel, 'الحساب الأساسي') || 'الحساب الأساسي';
    const validationIssues = [];

    if(!draft.date) validationIssues.push('حدد تاريخ السند قبل المتابعة.');
    if(!isOpeningVoucher){
      if(!currency || !currency.code) validationIssues.push('اختر عملة صحيحة للسند.');
      if(!isSettlementVoucher && !cashAccount) validationIssues.push(`حدد ${primaryAccountLabel} قبل اعتماد السند.`);
    }

    const movements = draft.movements.map((movementDraft) => buildVoucherMovementContext({
      type: safeType,
      movementDraft,
      cashAccount,
      counterpartAccountOptions,
      accounts,
      currencies,
      cashMotionCode: draft.cashMotionCode
    }));

    if(isSettlementVoucher){
      const debitMovement = movements[0] || null;
      const creditMovement = movements[1] || null;
      const debitAccount = debitMovement?.counterpartAccount || null;
      const creditAccount = creditMovement?.counterpartAccount || null;
      const settlementDate = toText(debitMovement?.draft?.date || creditMovement?.draft?.date || draft?.date);
      const debitDate = toText(debitMovement?.draft?.date, settlementDate);
      const creditDate = toText(creditMovement?.draft?.date, settlementDate);
      const settlementCurrency = findCurrencyByCode(
        toText(debitMovement?.draft?.currencyCode || creditMovement?.draft?.currencyCode || draft?.currencyCode),
        currencies
      );
      const debitAmount = clampPositiveAmount(debitMovement?.draft?.grossAmountText);
      const creditAmount = clampPositiveAmount(creditMovement?.draft?.grossAmountText);
      const settlementAmount = Math.max(debitAmount, creditAmount);
      const debitStatement = toText(debitMovement?.draft?.statement);
      const creditStatement = toText(creditMovement?.draft?.statement);
      const debitSummary = toText(debitMovement?.draft?.summary);
      const creditSummary = toText(creditMovement?.draft?.summary);
      const settlementStatement = joinUniqueTexts([debitStatement, creditStatement], ' | ')
        || joinUniqueTexts([debitSummary, creditSummary], ' | ');
      const settlementBeneficiarySummary = joinUniqueTexts([debitMovement?.draft?.beneficiaryName, creditMovement?.draft?.beneficiaryName], ' / ');
      const settlementCounterpartSummary = joinUniqueTexts([creditAccount?.name, debitAccount?.name], ' / ');
      const commissionSummary = summarizeVoucherCommission([debitMovement, creditMovement]);
      const debitCommissionFee = clampPositiveAmount(debitMovement?.draft?.commissionFeeText);
      const creditCommissionFee = clampPositiveAmount(creditMovement?.draft?.commissionFeeText);
      const hasSettlementCommission = commissionSummary.value !== 'none' || debitCommissionFee > 0 || creditCommissionFee > 0;
      const persistedMovements = [debitMovement, creditMovement].filter((movement) => {
        if(!movement) return false;
        return !!(
          toText(movement?.draft?.counterpartAccountNo)
          || clampPositiveAmount(movement?.draft?.grossAmountText) > 0
          || toText(movement?.draft?.statement)
          || toText(movement?.draft?.beneficiaryName)
        );
      });

      if(!persistedMovements.length){
        validationIssues.push('أدخل طرفي التسوية قبل اعتماد السند.');
      }
      if(!debitAccount) validationIssues.push('حدد حساب المدين في الصندوق الأخضر.');
      if(!creditAccount) validationIssues.push('حدد حساب الدائن في الصندوق الأحمر.');
      if(debitAccount && creditAccount && debitAccount.accountNo === creditAccount.accountNo){
        validationIssues.push('يجب أن يختلف حساب المدين عن حساب الدائن في سند التسوية.');
      }
      if(!debitDate || !creditDate){
        validationIssues.push('حدد تاريخ العملية في طرفي التسوية.');
      }else if(debitDate !== creditDate){
        validationIssues.push('يجب أن يتطابق التاريخ في طرفي التسوية.');
      }
      if(!(settlementAmount > 0)){
        validationIssues.push('أدخل مبلغ التسوية بقيمة أكبر من صفر.');
      }
      if(!(debitAmount > 0) || !(creditAmount > 0)){
        validationIssues.push('يجب أن يحتوي طرفا التسوية على نفس المبلغ قبل الاعتماد.');
      }else if(Math.abs(debitAmount - creditAmount) >= 0.0001){
        validationIssues.push('يجب أن يتطابق مبلغ المدين مع مبلغ الدائن في سند التسوية.');
      }
      if(toText(debitMovement?.draft?.currencyCode).toUpperCase() !== toText(creditMovement?.draft?.currencyCode).toUpperCase()){
        validationIssues.push('يجب أن تتطابق العملة في طرفي التسوية.');
      }
      if(hasSettlementCommission){
        validationIssues.push('أجور العمولة في سند التسوية تحتاج حساب عمولة مستقل حتى تُرحَّل محاسبيًا بشكل صحيح. اترك العمولة بدون عمولة أو صفّر أجورها حالياً.');
      }

      const lines = (debitAccount && creditAccount && settlementAmount > 0)
        ? [
            {
              lineNo: 1,
              roleKey: 'settlement-debit',
              roleLabel: 'حساب التسوية المدين',
              accountNo: debitAccount.accountNo,
              accountName: debitAccount.name,
              description: debitSummary || debitStatement || settlementStatement,
              debit: settlementAmount,
              credit: 0,
              side: 'debit',
              amount: settlementAmount
            },
            {
              lineNo: 2,
              roleKey: 'settlement-credit',
              roleLabel: 'حساب التسوية الدائن',
              accountNo: creditAccount.accountNo,
              accountName: creditAccount.name,
              description: creditSummary || creditStatement || settlementStatement,
              debit: 0,
              credit: settlementAmount,
              side: 'credit',
              amount: settlementAmount
            }
          ]
        : [];
      const debitTotal = lines.reduce((sum, line) => sum + (Number(line.debit) || 0), 0);
      const creditTotal = lines.reduce((sum, line) => sum + (Number(line.credit) || 0), 0);
      const isBalanced = lines.length === 2 && Math.abs(debitTotal - creditTotal) < 0.0001 && !validationIssues.length;

      return {
        type: safeType,
        draft,
        copy: definition,
        accounts,
        cashAccountOptions,
        counterpartAccountOptions,
        currencies,
        cashMotionOptions,
        cashMotionPickerOptions,
        cashMotion,
        commissionOptions: COMMISSION_OPTIONS,
        currency: settlementCurrency,
        cashAccount,
        movements,
        persistedMovements,
        statementText: settlementStatement,
        beneficiarySummary: settlementBeneficiarySummary,
        counterpartNameSummary: settlementCounterpartSummary,
        partyNameSummary: settlementBeneficiarySummary,
        commissionSummary,
        counterpartAccountSummary: debitAccount || creditAccount || null,
        grossAmount: settlementAmount,
        netAmount: settlementAmount,
        lines,
        debitTotal,
        creditTotal,
        openingBalanceSummaries: [],
        isBalanced,
        validationIssues,
        settlementDebitMovement: debitMovement,
        settlementCreditMovement: creditMovement,
        settlementDebitAccount: debitAccount,
        settlementCreditAccount: creditAccount,
        settlementDate
      };
    }

    movements.forEach((movement, index) => {
      movement.validationIssues.forEach((issue) => validationIssues.push(`البطاقة ${index + 1}: ${issue}`));
    });
    const persistedMovements = movements.filter((movement) => !movement.isPlaceholder);

    const lines = [];
    persistedMovements.forEach((movement) => {
      movement.lines.forEach((line) => {
        lines.push({ ...line, lineNo: lines.length + 1 });
      });
    });

    const debitTotal = lines.reduce((sum, line) => sum + (Number(line.debit) || 0), 0);
    const creditTotal = lines.reduce((sum, line) => sum + (Number(line.credit) || 0), 0);
    const openingBalanceSummaries = isOpeningVoucher ? summarizeOpeningBalanceCurrencies(persistedMovements, currencies) : [];
    const isBalanced = isOpeningVoucher
      ? (openingBalanceSummaries.length > 0 && openingBalanceSummaries.every((summary) => summary.balanced))
      : (Math.abs(debitTotal - creditTotal) < 0.0001 && lines.length > 0);

    if(isOpeningVoucher){
      if(!persistedMovements.length){
        validationIssues.push('أضف سطراً افتتاحياً واحداً على الأقل قبل الاعتماد.');
      }
      openingBalanceSummaries.forEach((summary) => {
        if(summary.debitTotal <= 0 || summary.creditTotal <= 0){
          validationIssues.push(`عملة ${summary.code}: يجب أن تحتوي الأرصدة الافتتاحية على طرف مدين وطرف دائن داخل العملة نفسها.`);
          return;
        }
        if(!summary.balanced){
          validationIssues.push(`عملة ${summary.code}: إجمالي المدين ${summary.debitTotal} لا يساوي إجمالي الدائن ${summary.creditTotal}.`);
        }
      });
    }else if(lines.length > 0 && !isBalanced){
      validationIssues.push('الحركة المحاسبية غير متوازنة، راجع الحسابات والمبالغ قبل الاعتماد.');
    }

    const uniqueCounterpartAccounts = [];
    persistedMovements.forEach((movement) => {
      if(!movement.counterpartAccount) return;
      if(uniqueCounterpartAccounts.some((item) => item.accountNo === movement.counterpartAccount.accountNo)) return;
      uniqueCounterpartAccounts.push(movement.counterpartAccount);
    });

    const grossAmount = persistedMovements.reduce((sum, movement) => sum + movement.grossAmount, 0);
    const netAmount = persistedMovements.reduce((sum, movement) => sum + movement.netAmount, 0);
    const statementText = joinUniqueTexts(persistedMovements.map((movement) => movement.statementText), ' | ');
    const beneficiarySummary = joinUniqueTexts(persistedMovements.map((movement) => movement.draft.beneficiaryName), ' / ');
    const counterpartNameSummary = joinUniqueTexts(persistedMovements.map((movement) => movement.counterpartAccount ? movement.counterpartAccount.name : ''), ' / ');
    const commissionSummary = summarizeVoucherCommission(persistedMovements);

    return {
      type: safeType,
      draft,
      copy: definition,
      accounts,
      cashAccountOptions,
      counterpartAccountOptions,
      currencies,
      cashMotionOptions,
      cashMotionPickerOptions,
      cashMotion,
      commissionOptions: COMMISSION_OPTIONS,
      currency,
      cashAccount,
      movements,
      persistedMovements,
      statementText,
      beneficiarySummary,
      counterpartNameSummary,
      partyNameSummary: beneficiarySummary,
      commissionSummary,
      counterpartAccountSummary: uniqueCounterpartAccounts.length === 1 ? uniqueCounterpartAccounts[0] : null,
      grossAmount,
      netAmount,
      lines,
      debitTotal,
      creditTotal,
      openingBalanceSummaries,
      isBalanced,
      validationIssues
    };
  }


  Object.assign(feature, {
  normalizeCommissionCode,
  resolveCommissionOption,
  createVoucherMovement,
  normalizeVoucherDraft,
  createVoucherDraft,
  buildVoucherRenderContext,
  buildVoucherContext,
  buildSettlementAutoSummaries,
  finalizeSettlementDraft,
  resolveJournalVisibleMovementCount,
  JOURNAL_INITIAL_RENDER_COUNT,
  JOURNAL_RENDER_CHUNK_SIZE
});

})();
