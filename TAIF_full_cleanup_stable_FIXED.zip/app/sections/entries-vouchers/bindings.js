(()=>{
  /*
   * TAIF Entries & Vouchers bindings.
   * Uses delegated events so the board stays stable across rerenders and modal refreshes.
   */
  const TAIF = window.TAIF;
  const { runCleanupSlot, escapeSelectorValue, focusElementWithoutScroll, createAnimationFrameScheduler, setDisclosureOpenState } = TAIF.core.utils;
  const feature = TAIF.entriesVouchersFeature || (TAIF.entriesVouchersFeature = {});
  const {
    runtime,
    STORAGE_KEY,
    ACCOUNT_STORAGE_KEY,
    CURRENCY_STORAGE_KEY,
    CASH_BOX_STORAGE_KEY,
    getModalLayer,
    getSheet,
    getSheetIdFromNode,
    ensureSheetNavigator,
    normalizeVoucherPageLookup,
    mountTopbarAdaptiveFit,
    cleanupSheetChrome,
    bindEntriesSheetChrome,
    applySheetWindowStackState,
    runVoucherNavigatorAction,
    runSheetSave,
    runMovementCardAction,
    requestSelectedVoucherDeletion,
    commitSheetField,
    commitSheetFieldAndRender,
    selectAccountSearchOption,
    renderEntriesBoard,
    renderEntriesFromSnapshot,
    refreshEntriesModalLayer,
    snapshotModalCanvasPositions,
    todayInputValue,
    ensureChoicePickerState,
    setChoicePickerRuntimeState,
    clearChoicePickerRuntimeState,
    ensureDatePickerState,
    normalizeDatePickerMonthCursor,
    normalizeDatePickerView,
    shiftDatePickerMonthCursor,
    clearScheduledDatePickerOutsideClose,
    clearDatePickerRuntimeState,
    getChoicePickerHiddenInput,
    getAccountSearchList,
    moveAccountSearchOptionFocus,
    refreshAccountSearchDropdown,
    closeAccountSearchDropdown,
    finalizeAccountSearch,
    restoreSearchFocus,
    captureFieldSelection,
    restoreFieldSelection,
    JOURNAL_RENDER_CHUNK_SIZE,
    SHEET_FIELD_SELECTOR,
    updateRecordSelectionUi,
    normalizeAccountLookupText
  } = feature;

  function closestElement(target, selector){
    return target instanceof Element ? target.closest(selector) : null;
  }

  function isSheetField(control){
    return control instanceof HTMLElement && control.matches(SHEET_FIELD_SELECTOR);
  }

  function isAccountSearchField(control){
    return control instanceof HTMLInputElement
      && String(control.getAttribute('data-field') || '').trim() === 'counterpartAccountQuery';
  }

  function isChoicePickerTrigger(control){
    return control instanceof HTMLButtonElement && control.matches('[data-entry-choice-trigger="true"][data-field]');
  }

  function isDiscreteField(control){
    return isChoicePickerTrigger(control);
  }

  function isTextField(control){
    return control instanceof HTMLInputElement || control instanceof HTMLTextAreaElement;
  }

  function abortBindingSlot(slotName){
    const current = runtime[slotName];
    if(current?.controller){
      try{ current.controller.abort(); }catch{}
    }
    runtime[slotName] = null;
  }

  const boardSearchState = { selectionStart: 0, selectionEnd: 0 };
  const boardSearchRenderScheduler = typeof createAnimationFrameScheduler === 'function'
    ? createAnimationFrameScheduler(() => {
        renderEntriesBoard();
        window.requestAnimationFrame(() => {
          restoreSearchFocus(boardSearchState.selectionStart, boardSearchState.selectionEnd);
        });
      })
    : null;
  const EXTERNAL_SYNC_STORAGE_KEYS = new Set([
    STORAGE_KEY,
    ACCOUNT_STORAGE_KEY,
    CURRENCY_STORAGE_KEY,
    CASH_BOX_STORAGE_KEY
  ].map((key) => {
    const safeKey = String(key || '').trim();
    if(!safeKey) return '';
    return typeof TAIF?.core?.utils?.resolveStorageKey === 'function'
      ? TAIF.core.utils.resolveStorageKey(safeKey)
      : safeKey;
  }).filter(Boolean));
  const externalRefreshRuntime = { focusSnapshot: null };
  const externalViewRefreshScheduler = typeof createAnimationFrameScheduler === 'function'
    ? createAnimationFrameScheduler(() => {
        if(!(runtime.panel instanceof HTMLElement) || !runtime.panel.isConnected) return;
        const snapshot = snapshotModalCanvasPositions();
        const focusSnapshot = externalRefreshRuntime.focusSnapshot;
        externalRefreshRuntime.focusSnapshot = null;
        renderEntriesFromSnapshot(snapshot, () => {
          if(typeof updateRecordSelectionUi === 'function') updateRecordSelectionUi();
          restoreExternalRefreshFocus(focusSnapshot);
        });
      })
    : null;

  function scheduleBoardSearchRender(selectionStart = 0, selectionEnd = 0){
    boardSearchState.selectionStart = Number.isFinite(selectionStart) ? selectionStart : 0;
    boardSearchState.selectionEnd = Number.isFinite(selectionEnd) ? selectionEnd : boardSearchState.selectionStart;
    if(boardSearchRenderScheduler){
      boardSearchRenderScheduler.schedule();
      return;
    }
    renderEntriesBoard();
    window.requestAnimationFrame(() => {
      restoreSearchFocus(boardSearchState.selectionStart, boardSearchState.selectionEnd);
    });
  }

  function captureExternalRefreshFocus(){
    const activeElement = document.activeElement;
    if(activeElement instanceof HTMLInputElement && activeElement.matches('[data-entry-action="search"]') && runtime.panel?.contains(activeElement)){
      const selectionStart = typeof activeElement.selectionStart === 'number' ? activeElement.selectionStart : 0;
      const selectionEnd = typeof activeElement.selectionEnd === 'number' ? activeElement.selectionEnd : selectionStart;
      return { kind: 'board-search', selectionStart, selectionEnd };
    }

    if(activeElement instanceof HTMLElement && typeof captureFieldSelection === 'function'){
      const selection = captureFieldSelection(activeElement);
      if(selection) return { kind: 'sheet-field', selection };
    }

    return null;
  }

  function restoreExternalRefreshFocus(snapshot){
    if(!snapshot || typeof snapshot !== 'object') return;
    if(snapshot.kind === 'board-search'){
      restoreSearchFocus(snapshot.selectionStart, snapshot.selectionEnd);
      return;
    }
    if(snapshot.kind === 'sheet-field' && snapshot.selection && typeof restoreFieldSelection === 'function'){
      restoreFieldSelection(snapshot.selection);
    }
  }

  function ensureBindingSlot(slotName, node, binder){
    if(!(node instanceof EventTarget)){
      abortBindingSlot(slotName);
      return;
    }

    const current = runtime[slotName];
    if(current?.node === node && current?.controller && !current.controller.signal.aborted){
      return;
    }

    abortBindingSlot(slotName);
    const controller = new AbortController();
    runtime[slotName] = { node, controller };
    binder(node, controller.signal);
  }

  function scheduleExternalEntriesRefresh(){
    if(!(runtime.panel instanceof HTMLElement) || !runtime.panel.isConnected) return;
    const focusSnapshot = captureExternalRefreshFocus();
    if(externalViewRefreshScheduler){
      externalRefreshRuntime.focusSnapshot = focusSnapshot;
      externalViewRefreshScheduler.schedule();
      return;
    }
    const snapshot = snapshotModalCanvasPositions();
    renderEntriesFromSnapshot(snapshot, () => {
      if(typeof updateRecordSelectionUi === 'function') updateRecordSelectionUi();
      restoreExternalRefreshFocus(focusSnapshot);
    });
  }

  function cleanupEntriesViewBindings(){
    abortBindingSlot('panelBindings');
    abortBindingSlot('modalBindings');
    abortBindingSlot('documentBindings');
    abortBindingSlot('windowBindings');
    boardSearchRenderScheduler?.cancel?.();
    externalViewRefreshScheduler?.cancel?.();
  }

  function handleBoardSearchInput(input){
    const selectionStart = typeof input.selectionStart === 'number' ? input.selectionStart : 0;
    const selectionEnd = typeof input.selectionEnd === 'number' ? input.selectionEnd : selectionStart;
    runtime.filter = input.value || '';
    scheduleBoardSearchRender(selectionStart, selectionEnd);
  }

  function handleBoardSearchClear(){
    runtime.filter = '';
    scheduleBoardSearchRender(0, 0);
  }

  function rerenderModalSnapshot(afterRender = null){
    renderEntriesFromSnapshot(snapshotModalCanvasPositions(), afterRender);
  }

  function resolveChoicePickerTrigger(sheetId, field, movementId = ''){
    if(!sheetId || !field) return null;
    const layer = getModalLayer();
    const movementSelector = movementId ? `[data-movement-id="${escapeSelectorValue(movementId)}"]` : ':not([data-movement-id])';
    const trigger = layer?.querySelector(`[data-entry-sheet-id="${escapeSelectorValue(sheetId)}"] [data-entry-choice-trigger="true"][data-field="${escapeSelectorValue(field)}"]${movementSelector}`);
    return trigger instanceof HTMLElement ? trigger : null;
  }

  function focusChoicePickerTrigger(sheetId, field, movementId = ''){
    const trigger = resolveChoicePickerTrigger(sheetId, field, movementId);
    if(trigger instanceof HTMLElement){
      focusElementWithoutScroll(trigger);
    }
  }

  function focusRenderedChoicePickerActiveOption(sheetId, field, movementId = ''){
    const trigger = resolveChoicePickerTrigger(sheetId, field, movementId);
    return trigger ? focusChoicePickerActiveOption(trigger) : false;
  }

  function setChoicePickerDomOpenState(sheetId, field, movementId = '', isOpen = false){
    const trigger = resolveChoicePickerTrigger(sheetId, field, movementId);
    const root = trigger?.closest('[data-entry-choice-picker="true"]');
    const popover = root instanceof HTMLElement ? root.querySelector('.entries-voucher-choice-popover') : null;
    if(typeof setDisclosureOpenState === 'function'){
      setDisclosureOpenState({ root, popup: popover, trigger, isOpen });
      return;
    }
    if(root instanceof HTMLElement) root.classList.toggle('is-open', !!isOpen);
    if(popover instanceof HTMLElement) popover.hidden = !isOpen;
    if(trigger instanceof HTMLElement) trigger.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
  }

  function normalizeAccountLookupValue(value){
    if(typeof normalizeAccountLookupText === 'function') return normalizeAccountLookupText(value);
    return String(value == null ? '' : value).trim().toLowerCase();
  }

  function sanitizeChoicePickerDomState(modalLayer){
    if(!(modalLayer instanceof HTMLElement)) return;
    const state = ensureChoicePickerState();
    const activeSheetId = String(state.sheetId || '').trim();
    const activeField = String(state.field || '').trim();
    const activeMovementId = String(state.movementId || '').trim();

    modalLayer.querySelectorAll('[data-entry-choice-picker="true"]').forEach((root) => {
      if(!(root instanceof HTMLElement)) return;
      const trigger = root.querySelector('[data-entry-choice-trigger="true"][data-field]');
      const popover = root.querySelector('.entries-voucher-choice-popover');
      if(!(trigger instanceof HTMLButtonElement) || !(popover instanceof HTMLElement)) return;
      const sheetId = getSheetIdFromNode(trigger);
      const field = String(trigger.getAttribute('data-field') || '').trim();
      const movementId = String(trigger.getAttribute('data-movement-id') || '').trim();
      const shouldOpen = !!activeSheetId
        && sheetId === activeSheetId
        && field === activeField
        && movementId === activeMovementId;
      if(typeof setDisclosureOpenState === 'function'){
        setDisclosureOpenState({ root, popup: popover, trigger, isOpen: shouldOpen });
      }else{
        root.classList.toggle('is-open', shouldOpen);
        popover.hidden = !shouldOpen;
        trigger.setAttribute('aria-expanded', shouldOpen ? 'true' : 'false');
      }
    });
  }

  function sanitizeAccountSearchDomState(modalLayer){
    if(!(modalLayer instanceof HTMLElement)) return;
    const searchState = runtime.accountSearch && typeof runtime.accountSearch === 'object'
      ? runtime.accountSearch
      : { sheetId:'', movementId:'' };
    const activeSheetId = String(searchState.sheetId || '').trim();
    const activeMovementId = String(searchState.movementId || '').trim();

    modalLayer.querySelectorAll('[data-entry-account-search-root="true"]').forEach((root) => {
      if(!(root instanceof HTMLElement)) return;
      const control = root.querySelector('input[data-field="counterpartAccountQuery"]');
      const list = getAccountSearchList(root);
      if(!(control instanceof HTMLInputElement) || !(list instanceof HTMLElement)) return;
      const sheetId = getSheetIdFromNode(control);
      const movementId = String(control.getAttribute('data-movement-id') || '').trim();
      const queryValue = String(control.value || '').trim();
      const selectedAccountNo = String(control.getAttribute('data-selected-account-no') || '').trim();
      const selectedAccountLabel = String(control.getAttribute('data-selected-account-label') || '').trim();
      const isSettled = !!selectedAccountNo
        && !!normalizeAccountLookupValue(queryValue)
        && normalizeAccountLookupValue(queryValue) === normalizeAccountLookupValue(selectedAccountLabel);
      const shouldOpen = !!queryValue
        && !!activeSheetId
        && sheetId === activeSheetId
        && movementId === activeMovementId
        && !isSettled;
      if(typeof setDisclosureOpenState === 'function'){
        setDisclosureOpenState({ root, popup: list, trigger: control, isOpen: shouldOpen });
      }else{
        root.classList.toggle('is-open', shouldOpen);
        list.hidden = !shouldOpen;
        control.setAttribute('aria-expanded', shouldOpen ? 'true' : 'false');
      }
    });
  }

  function sanitizeTransientDropdownDomState(modalLayer){
    sanitizeChoicePickerDomState(modalLayer);
    sanitizeAccountSearchDomState(modalLayer);
  }

  const ENTRIES_TRANSIENT_POPOVER_SELECTOR = [
    '.entries-voucher-choice-popover',
    '.entries-account-search__popover',
    '.entries-voucher-date__popover'
  ].join(', ');
  const ENTRIES_TRANSIENT_POPOVER_INTERACTIVE_SELECTOR = [
    '.entries-voucher-choice-popover__option',
    '.entries-account-search__result',
    '.entries-voucher-date__nav',
    '.entries-voucher-date__heading-trigger',
    '.entries-voucher-date__footer-btn',
    '.entries-voucher-date__day',
    '.entries-voucher-date__month'
  ].join(', ');

  function resolveTransientPopover(scope){
    if(!(scope instanceof Element)) return null;

    const directPopover = scope.closest(ENTRIES_TRANSIENT_POPOVER_SELECTOR);
    if(directPopover instanceof HTMLElement) return directPopover;

    const choicePickerRoot = scope.closest('[data-entry-choice-picker="true"]');
    const choicePopover = choicePickerRoot?.querySelector('.entries-voucher-choice-popover');
    if(choicePopover instanceof HTMLElement) return choicePopover;

    const accountSearchRoot = scope.closest('[data-entry-account-search-root="true"]');
    const accountPopover = getAccountSearchList(accountSearchRoot);
    if(accountPopover instanceof HTMLElement) return accountPopover;

    const datePickerRoot = scope.closest('[data-entry-date-picker="true"]');
    const datePopover = datePickerRoot?.querySelector('.entries-voucher-date__popover');
    if(datePopover instanceof HTMLElement) return datePopover;

    return null;
  }

  function setTransientPopoverNavIntent(scope, intent = ''){
    const popover = resolveTransientPopover(scope);
    if(!(popover instanceof HTMLElement) || popover.hidden) return false;
    const safeIntent = String(intent || '').trim();
    if(safeIntent === 'keyboard' || safeIntent === 'pointer'){
      popover.setAttribute('data-entry-nav-intent', safeIntent);
      popover.setAttribute('data-taif-nav-intent', safeIntent);
      return true;
    }
    popover.removeAttribute('data-entry-nav-intent');
    popover.removeAttribute('data-taif-nav-intent');
    return true;
  }

  function markTransientPopoverKeyboardIntent(scope){
    return setTransientPopoverNavIntent(scope, 'keyboard');
  }

  function markTransientPopoverPointerIntentFromTarget(target){
    if(!(target instanceof Element)) return false;
    const interactiveTarget = target.closest(ENTRIES_TRANSIENT_POPOVER_INTERACTIVE_SELECTOR);
    if(!(interactiveTarget instanceof HTMLElement)) return false;
    return setTransientPopoverNavIntent(interactiveTarget, 'pointer');
  }

  function closeChoicePickerDomIfOpen(target = null){
    const state = ensureChoicePickerState();
    if(!String(state.sheetId || '').trim() || !String(state.field || '').trim()) return false;
    if(target && closestElement(target, '[data-entry-choice-picker="true"]')) return false;
    const sheetId = state.sheetId;
    const field = state.field;
    const movementId = state.movementId;
    clearChoicePickerRuntimeState(sheetId, field, movementId);
    setChoicePickerDomOpenState(sheetId, field, movementId, false);
    return true;
  }

  function getChoicePickerOptionButtons(scope){
    const root = closestElement(scope, '[data-entry-choice-picker="true"]');
    return root instanceof HTMLElement
      ? Array.from(root.querySelectorAll('[data-entry-choice-action="select"]')).filter((button) => button instanceof HTMLButtonElement)
      : [];
  }

  function focusChoicePickerOption(scope, index = 0){
    markTransientPopoverKeyboardIntent(scope);
    const buttons = getChoicePickerOptionButtons(scope);
    if(!buttons.length) return false;
    const normalizedIndex = Math.max(0, Math.min(buttons.length - 1, Number(index) || 0));
    const target = buttons[normalizedIndex];
    if(!(target instanceof HTMLElement)) return false;
    focusElementWithoutScroll(target);
    target.scrollIntoView?.({ block:'nearest', inline:'nearest' });
    return true;
  }

  function focusChoicePickerActiveOption(scope){
    const buttons = getChoicePickerOptionButtons(scope);
    if(!buttons.length) return false;
    const activeIndex = buttons.findIndex((button) => button.classList.contains('is-active'));
    return focusChoicePickerOption(scope, activeIndex >= 0 ? activeIndex : 0);
  }

  function moveChoicePickerOptionFocus(scope, direction = 1){
    const buttons = getChoicePickerOptionButtons(scope);
    if(!buttons.length) return false;
    const activeElement = document.activeElement;
    const currentIndex = buttons.findIndex((button) => button === activeElement);
    const nextIndex = currentIndex < 0
      ? (direction > 0 ? 0 : buttons.length - 1)
      : (currentIndex + direction + buttons.length) % buttons.length;
    return focusChoicePickerOption(scope, nextIndex);
  }

  const ENTRIES_MODAL_FLOW_SELECTOR = [
    '[data-entry-voucher-nav="lookup"]',
    '[data-entry-voucher-nav="prev"]:not([disabled])',
    '[data-entry-voucher-nav="prev10"]:not([disabled])',
    '[data-entry-voucher-nav="next"]:not([disabled])',
    '[data-entry-voucher-nav="next10"]:not([disabled])',
    '[data-entry-date-action="toggle"]',
    'button[data-entry-choice-trigger="true"][data-field]',
    'input[data-field]:not([type="hidden"])',
    'textarea[data-field]',
    '[data-entry-card-action][data-movement-id]:not([disabled])',
    '[data-entry-shell-action]:not([disabled])'
  ].join(', ');

  function resolveEntriesSheetScope(target){
    return target instanceof Element
      ? target.closest('.entries-modal-backdrop[data-entry-sheet-id], .entries-modal-window[data-entry-sheet-id]')
      : null;
  }

  function isEntriesFlowTargetVisible(target){
    if(!(target instanceof HTMLElement)) return false;
    if(target.hidden || target.getAttribute('aria-hidden') === 'true') return false;
    if(target.closest('[hidden], [aria-hidden="true"]')) return false;
    if(target.closest('.entries-voucher-choice-popover[hidden], .entries-account-search__popover[hidden], .entries-voucher-date__popover[hidden]')) return false;
    return target.getClientRects().length > 0;
  }

  function collectEntriesFlowTargets(scope){
    if(!(scope instanceof Element)) return [];
    return Array.from(scope.querySelectorAll(ENTRIES_MODAL_FLOW_SELECTOR)).filter((target) => {
      if(!(target instanceof HTMLElement)) return false;
      if(target.hasAttribute('disabled')) return false;
      return isEntriesFlowTargetVisible(target);
    });
  }

  function focusEntriesFlowTarget(target){
    if(!(target instanceof HTMLElement)) return false;
    focusElementWithoutScroll(target);
    if((target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) && !target.readOnly){
      const length = String(target.value || '').length;
      try{ target.setSelectionRange(length, length); }catch{}
    }
    target.scrollIntoView?.({ block:'nearest', inline:'nearest' });
    return true;
  }

  function focusRelativeEntriesFlowTarget(referenceElement, step = 1){
    if(!(referenceElement instanceof HTMLElement)) return false;
    const scope = resolveEntriesSheetScope(referenceElement);
    const targets = collectEntriesFlowTargets(scope);
    if(!targets.length) return false;
    const currentIndex = targets.findIndex((target) => target === referenceElement);
    if(currentIndex < 0) return focusEntriesFlowTarget(step < 0 ? targets[targets.length - 1] : targets[0]);
    const nextIndex = Math.max(0, Math.min(targets.length - 1, currentIndex + (step < 0 ? -1 : 1)));
    return focusEntriesFlowTarget(targets[nextIndex] || referenceElement);
  }

  function resolveSheetFieldAnchor(sheetId, fieldName, movementId = ''){
    if(!sheetId || !fieldName) return null;
    const layer = getModalLayer();
    const movementSelector = movementId
      ? `[data-movement-id="${escapeSelectorValue(movementId)}"]`
      : ':not([data-movement-id])';
    const target = layer?.querySelector(`[data-entry-sheet-id="${escapeSelectorValue(sheetId)}"] [data-field="${escapeSelectorValue(fieldName)}"]${movementSelector}`);
    return target instanceof HTMLElement ? target : null;
  }

  function resolveDatePickerMovementId(scope){
    if(!(scope instanceof HTMLElement)) return '';
    const pickerRoot = closestElement(scope, '[data-entry-date-picker="true"]');
    if(pickerRoot instanceof HTMLElement){
      return String(pickerRoot.getAttribute('data-movement-id') || '').trim();
    }
    return String(scope.getAttribute('data-movement-id') || '').trim();
  }

  function resolveDatePickerTrigger(sheetId, movementId = ''){
    if(!sheetId) return null;
    const layer = getModalLayer();
    const normalizedMovementId = String(movementId || '').trim();
    const movementSelector = normalizedMovementId
      ? `[data-movement-id="${escapeSelectorValue(normalizedMovementId)}"]`
      : ':not([data-movement-id])';
    const trigger = layer?.querySelector(`[data-entry-sheet-id="${escapeSelectorValue(sheetId)}"] [data-entry-date-action="toggle"]${movementSelector}`);
    return trigger instanceof HTMLElement ? trigger : null;
  }

  function focusRelativeEntriesFromField(sheetId, fieldName, movementId = '', step = 1){
    const anchor = resolveSheetFieldAnchor(sheetId, fieldName, movementId);
    return anchor ? focusRelativeEntriesFlowTarget(anchor, step) : false;
  }

  function focusRelativeEntriesFromChoicePicker(sheetId, field, movementId = '', step = 1){
    const anchor = resolveChoicePickerTrigger(sheetId, field, movementId);
    return anchor ? focusRelativeEntriesFlowTarget(anchor, step) : false;
  }

  function focusRelativeEntriesFromDatePicker(sheetId, movementId = '', step = 1){
    const anchor = resolveDatePickerTrigger(sheetId, movementId);
    return anchor ? focusRelativeEntriesFlowTarget(anchor, step) : false;
  }

  function getDatePickerFocusableButtons(scope){
    const root = closestElement(scope, '[data-entry-date-picker="true"]');
    const popover = root instanceof HTMLElement ? root.querySelector('.entries-voucher-date__popover:not([hidden])') : null;
    if(!(popover instanceof HTMLElement)) return [];
    return Array.from(popover.querySelectorAll('button:not([disabled])')).filter((button) => button instanceof HTMLButtonElement && isEntriesFlowTargetVisible(button));
  }

  function focusDatePickerActiveButton(scope, direction = 'current'){
    markTransientPopoverKeyboardIntent(scope);
    const buttons = getDatePickerFocusableButtons(scope);
    if(!buttons.length) return false;
    let target = buttons.find((button) => button.matches('.entries-voucher-date__day.is-selected, .entries-voucher-date__month.is-active'));
    if(direction === 'last') target = buttons[buttons.length - 1];
    if(!(target instanceof HTMLElement)) target = buttons[0];
    focusElementWithoutScroll(target);
    target.scrollIntoView?.({ block:'nearest', inline:'nearest' });
    return true;
  }

  function focusRenderedDatePickerActiveButton(sheetId, movementId = '', direction = 'current'){
    const trigger = resolveDatePickerTrigger(sheetId, movementId);
    return trigger ? focusDatePickerActiveButton(trigger, direction) : false;
  }

  function stepChoicePickerSelection(trigger, step = 1){
    if(!isChoicePickerTrigger(trigger)) return false;
    const hiddenInput = getChoicePickerHiddenInput(trigger);
    const options = getChoicePickerOptionButtons(trigger);
    if(!(hiddenInput instanceof HTMLInputElement) || !options.length) return false;
    const sheetId = getSheetIdFromNode(trigger);
    const field = String(trigger.getAttribute('data-field') || '').trim();
    const movementId = String(trigger.getAttribute('data-movement-id') || '').trim();
    const currentValue = String(hiddenInput.value || '');
    const currentIndex = options.findIndex((button) => String(button.getAttribute('data-entry-choice-value') || '') === currentValue);
    const normalizedStep = step < 0 ? -1 : 1;
    const nextIndex = currentIndex < 0
      ? (normalizedStep > 0 ? 0 : options.length - 1)
      : Math.max(0, Math.min(options.length - 1, currentIndex + normalizedStep));
    if(nextIndex === currentIndex || nextIndex < 0 || nextIndex >= options.length) return false;
    hiddenInput.value = String(options[nextIndex].getAttribute('data-entry-choice-value') || '');
    clearChoicePickerRuntimeState(sheetId, field, movementId);
    commitSheetField(trigger);
    rerenderModalSnapshot(() => focusChoicePickerTrigger(sheetId, field, movementId));
    return true;
  }

  function openChoicePickerForKeyboard(trigger, direction = 'current'){
    if(!isChoicePickerTrigger(trigger)) return false;
    const sheetId = getSheetIdFromNode(trigger);
    const field = String(trigger.getAttribute('data-field') || '').trim();
    const movementId = String(trigger.getAttribute('data-movement-id') || '').trim();
    const pickerState = ensureChoicePickerState();
    const isSamePicker = pickerState.sheetId === sheetId && pickerState.field === field && pickerState.movementId === movementId;
    if(isSamePicker){
      if(direction === 'last'){
        const triggerNode = resolveChoicePickerTrigger(sheetId, field, movementId);
        const buttons = getChoicePickerOptionButtons(triggerNode);
        return focusChoicePickerOption(triggerNode, buttons.length - 1);
      }
      return focusRenderedChoicePickerActiveOption(sheetId, field, movementId);
    }
    setChoicePickerRuntimeState(sheetId, field, movementId);
    rerenderModalSnapshot(() => {
      if(direction === 'last'){
        const triggerNode = resolveChoicePickerTrigger(sheetId, field, movementId);
        const buttons = getChoicePickerOptionButtons(triggerNode);
        focusChoicePickerOption(triggerNode, buttons.length - 1);
        return;
      }
      if(!focusRenderedChoicePickerActiveOption(sheetId, field, movementId)) focusChoicePickerTrigger(sheetId, field, movementId);
    });
    return true;
  }

  function openDatePickerForKeyboard(trigger, direction = 'current'){
    if(!(trigger instanceof HTMLButtonElement)) return false;
    const sheetId = getSheetIdFromNode(trigger);
    if(!sheetId) return false;
    const movementId = resolveDatePickerMovementId(trigger);
    const pickerState = ensureDatePickerState();
    if(String(pickerState.sheetId || '').trim() === sheetId && String(pickerState.movementId || '').trim() === movementId){
      return focusRenderedDatePickerActiveButton(sheetId, movementId, direction);
    }
    toggleDatePicker(trigger, () => {
      if(!focusRenderedDatePickerActiveButton(sheetId, movementId, direction)) focusDatePickerTrigger(sheetId, movementId);
    });
    return true;
  }


  function toggleChoicePicker(trigger){
    if(!isChoicePickerTrigger(trigger)) return;
    const sheetId = getSheetIdFromNode(trigger);
    const field = String(trigger.getAttribute('data-field') || '').trim();
    const movementId = String(trigger.getAttribute('data-movement-id') || '').trim();
    if(!sheetId || !field) return;
    const state = ensureChoicePickerState();
    const isSamePicker = state.sheetId === sheetId && state.field === field && state.movementId === movementId;
    if(isSamePicker){
      clearChoicePickerRuntimeState(sheetId, field, movementId);
      rerenderModalSnapshot(() => focusChoicePickerTrigger(sheetId, field, movementId));
      return;
    }
    setChoicePickerRuntimeState(sheetId, field, movementId);
    rerenderModalSnapshot(() => focusChoicePickerTrigger(sheetId, field, movementId));
  }

  function applyChoicePickerSelection(optionButton, { focusStep = 0 } = {}){
    if(!(optionButton instanceof HTMLButtonElement)) return;
    const field = String(optionButton.getAttribute('data-entry-choice-field') || '').trim();
    const movementId = String(optionButton.getAttribute('data-movement-id') || '').trim();
    const value = String(optionButton.getAttribute('data-entry-choice-value') || '');
    const root = closestElement(optionButton, '[data-entry-choice-picker="true"]');
    const trigger = root instanceof HTMLElement ? root.querySelector('[data-entry-choice-trigger="true"][data-field]') : null;
    const hiddenInput = getChoicePickerHiddenInput(optionButton);
    if(!(trigger instanceof HTMLButtonElement) || !(hiddenInput instanceof HTMLInputElement) || !field) return;
    const sheetId = getSheetIdFromNode(trigger);
    if(!sheetId) return;
    hiddenInput.value = value;
    clearChoicePickerRuntimeState(sheetId, field, movementId);
    commitSheetField(trigger);
    rerenderModalSnapshot(() => {
      if(focusStep){
        if(!focusRelativeEntriesFromChoicePicker(sheetId, field, movementId, focusStep)){
          focusChoicePickerTrigger(sheetId, field, movementId);
        }
        return;
      }
      focusChoicePickerTrigger(sheetId, field, movementId);
    });
  }


  function scheduleDatePickerOutsideClose(){
    const state = ensureDatePickerState();
    const activeSheetId = String(state.sheetId || '').trim();
    const activeMovementId = String(state.movementId || '').trim();
    if(!activeSheetId) return;
    clearScheduledDatePickerOutsideClose();
    runtime.datePickerOutsideCloseTimer = window.setTimeout(() => {
      runtime.datePickerOutsideCloseTimer = 0;
      const currentState = ensureDatePickerState();
      if(String(currentState.sheetId || '').trim() !== activeSheetId) return;
      if(String(currentState.movementId || '').trim() !== activeMovementId) return;
      clearDatePickerRuntimeState();
      rerenderModalSnapshot();
    }, 0);
  }

  function focusDatePickerTrigger(sheetId, movementId = ''){
    if(!sheetId) return;
    const trigger = resolveDatePickerTrigger(sheetId, movementId);
    if(trigger instanceof HTMLElement){
      focusElementWithoutScroll(trigger);
    }
  }

  function toggleDatePicker(trigger, afterRender = null){
    clearScheduledDatePickerOutsideClose();
    if(!(trigger instanceof HTMLElement)) return;
    const sheetId = getSheetIdFromNode(trigger);
    if(!sheetId) return;
    const movementId = resolveDatePickerMovementId(trigger);
    const state = ensureDatePickerState();
    if(state.sheetId === sheetId && String(state.movementId || '').trim() === movementId){
      clearDatePickerRuntimeState();
      rerenderModalSnapshot(() => {
        focusDatePickerTrigger(sheetId, movementId);
        if(typeof afterRender === 'function') afterRender(sheetId, movementId);
      });
      return;
    }
    state.sheetId = sheetId;
    state.movementId = movementId;
    state.monthCursor = normalizeDatePickerMonthCursor(trigger.getAttribute('data-entry-date-month'));
    state.view = 'days';
    rerenderModalSnapshot(() => {
      focusDatePickerTrigger(sheetId, movementId);
      if(typeof afterRender === 'function') afterRender(sheetId, movementId);
    });
  }

  function setDatePickerView(control, view = 'days'){
    clearScheduledDatePickerOutsideClose();
    if(!(control instanceof HTMLElement)) return;
    const sheetId = getSheetIdFromNode(control);
    if(!sheetId) return;
    const state = ensureDatePickerState();
    state.sheetId = sheetId;
    state.movementId = resolveDatePickerMovementId(control);
    state.monthCursor = normalizeDatePickerMonthCursor(control.getAttribute('data-entry-date-month'));
    state.view = normalizeDatePickerView(view);
    rerenderModalSnapshot();
  }

  function moveDatePickerMonth(control, offset = 0){
    clearScheduledDatePickerOutsideClose();
    if(!(control instanceof HTMLElement)) return;
    const sheetId = getSheetIdFromNode(control);
    if(!sheetId) return;
    const state = ensureDatePickerState();
    state.sheetId = sheetId;
    state.movementId = resolveDatePickerMovementId(control);
    state.monthCursor = shiftDatePickerMonthCursor(control.getAttribute('data-entry-date-month'), offset);
    state.view = normalizeDatePickerView(state.view);
    rerenderModalSnapshot();
  }

  function moveDatePickerYear(control, offset = 0){
    moveDatePickerMonth(control, Number(offset || 0) * 12);
  }

  function pickDatePickerMonth(control){
    clearScheduledDatePickerOutsideClose();
    if(!(control instanceof HTMLElement)) return;
    const sheetId = getSheetIdFromNode(control);
    if(!sheetId) return;
    const state = ensureDatePickerState();
    state.sheetId = sheetId;
    state.movementId = resolveDatePickerMovementId(control);
    state.monthCursor = normalizeDatePickerMonthCursor(control.getAttribute('data-entry-date-month'));
    state.view = 'days';
    rerenderModalSnapshot();
  }

  function resolveDatePickerHiddenField(control){
    if(!(control instanceof HTMLElement)) return null;
    const pickerRoot = control.closest('[data-entry-date-picker="true"]');
    if(!(pickerRoot instanceof HTMLElement)) return null;
    const hiddenField = pickerRoot.querySelector('.entries-voucher-date__native[data-field="date"]');
    return hiddenField instanceof HTMLInputElement ? hiddenField : null;
  }

  function applyDatePickerValue(control, value){
    clearScheduledDatePickerOutsideClose();
    const hiddenField = resolveDatePickerHiddenField(control);
    if(!(hiddenField instanceof HTMLInputElement)) return;
    const sheetId = getSheetIdFromNode(hiddenField);
    const movementId = resolveDatePickerMovementId(hiddenField);
    hiddenField.value = String(value || '');
    clearDatePickerRuntimeState();
    commitSheetField(hiddenField);
    rerenderModalSnapshot(() => focusDatePickerTrigger(sheetId, movementId));
  }

  function handlePanelClick(event){
    const openButton = closestElement(event.target, '[data-entry-action="open-form"]');
    if(openButton){
      feature.openSheet(openButton.getAttribute('data-entry-type'));
      return;
    }

    const clearButton = closestElement(event.target, '[data-entry-action="clear-search"]');
    if(clearButton){
      handleBoardSearchClear();
      return;
    }

    const deleteButton = closestElement(event.target, '[data-entry-action="delete-selected-record"]');
    if(deleteButton){
      requestSelectedVoucherDeletion();
      return;
    }

    const recordRow = closestElement(event.target, '.entries-record-row[data-entry-record-id]');
    if(recordRow){
      toggleBoardRecordSelection(recordRow);
      return;
    }

    clearBoardRecordSelection();
  }

  function handlePanelInput(event){
    const searchInput = closestElement(event.target, '[data-entry-action="search"]');
    if(searchInput instanceof HTMLInputElement){
      handleBoardSearchInput(searchInput);
    }
  }

  function applyBoardRecordSelection(recordId = ''){
    runtime.selectedRecordId = String(recordId || '').trim();
    if(typeof updateRecordSelectionUi === 'function'){
      updateRecordSelectionUi();
    }
  }

  function toggleBoardRecordSelection(row){
    if(!(row instanceof HTMLElement)) return;
    const recordId = String(row.getAttribute('data-entry-record-id') || '').trim();
    if(!recordId) return;
    applyBoardRecordSelection(runtime.selectedRecordId === recordId ? '' : recordId);
  }

  function clearBoardRecordSelection(){
    if(!runtime.selectedRecordId) return;
    applyBoardRecordSelection('');
  }

  function handleDocumentPointerDown(event){
    if(!runtime.selectedRecordId) return;
    if(!(runtime.panel instanceof Element) || !runtime.panel.isConnected) return;
    const target = event.target instanceof Element ? event.target : null;
    if(target && runtime.panel.contains(target)) return;
    clearBoardRecordSelection();
  }


  const JOURNAL_SCROLL_PREFETCH_DISTANCE = 720;

  function maybeExpandJournalCanvas(canvas){
    if(!(canvas instanceof HTMLElement)) return;
    const sheetId = getSheetIdFromNode(canvas);
    const sheet = getSheet(sheetId);
    if(!sheet || sheet.type !== 'journal') return;

    const draftMovements = Array.isArray(sheet.draft?.movements) ? sheet.draft.movements : [];
    const totalCount = draftMovements.length;
    if(totalCount <= 0) return;

    sheet.ui = sheet.ui && typeof sheet.ui === 'object' ? sheet.ui : {};
    if(sheet.ui.journalRenderRefreshPending) return;

    const currentCount = Math.max(0, Number(sheet.ui.journalVisibleCount) || 0);
    if(currentCount >= totalCount) return;

    const remainingDistance = canvas.scrollHeight - (canvas.scrollTop + canvas.clientHeight);
    if(Number.isFinite(remainingDistance) && remainingDistance > JOURNAL_SCROLL_PREFETCH_DISTANCE) return;

    sheet.ui.journalVisibleCount = Math.min(totalCount, Math.max(currentCount, JOURNAL_RENDER_CHUNK_SIZE) + JOURNAL_RENDER_CHUNK_SIZE);
    sheet.ui.journalRenderRefreshPending = true;
    const snapshot = snapshotModalCanvasPositions();
    refreshEntriesModalLayer({
      snapshot,
      afterRender: () => {
        sheet.ui.journalRenderRefreshPending = false;
        const layer = getModalLayer();
        const refreshedCanvas = layer?.querySelector(`.entries-sheet__canvas[data-entry-sheet-id="${escapeSelectorValue(sheetId)}"]`);
        if(refreshedCanvas instanceof HTMLElement){
          maybeExpandJournalCanvas(refreshedCanvas);
        }
      }
    });
  }

  function handleLookupInput(input){
    const sheetId = getSheetIdFromNode(input);
    const sheet = getSheet(sheetId);
    const navigator = ensureSheetNavigator(sheet);
    if(!navigator) return;
    const normalizedValue = normalizeVoucherPageLookup(input.value || '');
    navigator.lookupValue = normalizedValue;
    if(input.value !== normalizedValue){
      input.value = normalizedValue;
    }
  }

  function syncSettlementMirrorControls(sheetId){
    const safeSheetId = String(sheetId || '').trim();
    if(!safeSheetId) return;
    const sheet = getSheet(safeSheetId);
    if(!sheet || String(sheet?.type || '').trim() !== 'settlement') return;
    const layer = getModalLayer();
    if(!(layer instanceof HTMLElement)) return;
    const sheetRoot = layer.querySelector(`[data-entry-sheet-id="${escapeSelectorValue(safeSheetId)}"]`);
    if(!(sheetRoot instanceof HTMLElement)) return;
    const activeElement = document.activeElement;
    const movements = Array.isArray(sheet?.draft?.movements) ? sheet.draft.movements.slice(0, 2) : [];

    movements.forEach((movement) => {
      const movementId = String(movement?.id || '').trim();
      if(!movementId) return;
      const amountControl = sheetRoot.querySelector(`[data-movement-id="${escapeSelectorValue(movementId)}"][data-field="grossAmountText"]`);
      if(amountControl instanceof HTMLInputElement && amountControl !== activeElement){
        amountControl.value = String(movement?.grossAmountText || '');
      }
      const summaryControl = sheetRoot.querySelector(`[data-movement-id="${escapeSelectorValue(movementId)}"][data-field="summary"]`);
      if((summaryControl instanceof HTMLTextAreaElement || summaryControl instanceof HTMLInputElement) && summaryControl !== activeElement){
        summaryControl.value = String(movement?.summary || '');
      }
    });
  }

  function handleFieldInput(field){
    if(isAccountSearchField(field)){
      refreshAccountSearchDropdown(field, { activate: true });
      return;
    }

    if(isDiscreteField(field)) return;
    if(isTextField(field)){
      commitSheetField(field);
      if(String(field.getAttribute('data-field') || '').trim() === 'grossAmountText'){
        syncSettlementMirrorControls(getSheetIdFromNode(field));
      }
    }
  }

  function handleFieldChange(field){
    if(isAccountSearchField(field)) return;
    if(isDiscreteField(field)){
      commitSheetFieldAndRender(field, { restoreCursor: false });
      return;
    }
    if(isTextField(field)){
      commitSheetField(field);
      if(String(field.getAttribute('data-field') || '').trim() === 'grossAmountText'){
        syncSettlementMirrorControls(getSheetIdFromNode(field));
      }
    }
  }

  function handleAccountSearchKeydown(event, field){
    if(event.key === 'Escape'){
      event.preventDefault();
      closeAccountSearchDropdown(field);
      return;
    }

    if(event.key === 'ArrowDown'){
      markTransientPopoverKeyboardIntent(field);
      if(moveAccountSearchOptionFocus(field, 1)) event.preventDefault();
      return;
    }

    if(event.key === 'ArrowUp'){
      markTransientPopoverKeyboardIntent(field);
      if(moveAccountSearchOptionFocus(field, -1)) event.preventDefault();
      return;
    }

    if(event.key === 'Enter'){
      const searchState = refreshAccountSearchDropdown(field, { activate: true });
      if(!searchState) return;
      const targetAccount = searchState.exactMatch || (searchState.results.length === 1 ? searchState.results[0] : null);
      if(!targetAccount) return;
      event.preventDefault();
      feature.applyAccountSearchMatch(searchState.sheetId, searchState.movementId, targetAccount);
      window.requestAnimationFrame(() => {
        focusRelativeEntriesFromField(searchState.sheetId, 'counterpartAccountQuery', searchState.movementId, 1);
      });
    }
  }

  function handleModalPointerDown(event){
    markTransientPopoverPointerIntentFromTarget(event.target);
    closeChoicePickerDomIfOpen(event.target);

    const pickerState = ensureDatePickerState();
    if(String(pickerState.sheetId || '').trim()){
      const insideDatePicker = closestElement(event.target, '[data-entry-date-picker="true"]');
      if(insideDatePicker){
        clearScheduledDatePickerOutsideClose();
      }else{
        scheduleDatePickerOutsideClose();
      }
    }

    const choiceOptionButton = closestElement(event.target, '[data-entry-choice-action="select"]');
    if(choiceOptionButton){
      event.preventDefault();
      return;
    }

    const optionButton = closestElement(event.target, '[data-entry-account-option="select"][data-movement-id]');
    if(optionButton){
      event.preventDefault();
    }
  }

  function handleModalPointerMove(event){
    const pointerType = String(event?.pointerType || '').trim().toLowerCase();
    if(pointerType === 'touch') return;
    markTransientPopoverPointerIntentFromTarget(event.target);
  }

  function handleModalClick(event){
    const choiceToggleButton = closestElement(event.target, '[data-entry-choice-action="toggle"][data-entry-choice-trigger="true"]');
    if(choiceToggleButton){
      toggleChoicePicker(choiceToggleButton);
      return;
    }

    const choiceOptionButton = closestElement(event.target, '[data-entry-choice-action="select"]');
    if(choiceOptionButton){
      applyChoicePickerSelection(choiceOptionButton);
      return;
    }

    const dateToggleButton = closestElement(event.target, '[data-entry-date-action="toggle"]');
    if(dateToggleButton){
      toggleDatePicker(dateToggleButton);
      return;
    }

    const dateToggleViewButton = closestElement(event.target, '[data-entry-date-action="toggle-view"][data-entry-date-view]');
    if(dateToggleViewButton){
      setDatePickerView(dateToggleViewButton, String(dateToggleViewButton.getAttribute('data-entry-date-view') || 'days'));
      return;
    }

    const datePrevMonthButton = closestElement(event.target, '[data-entry-date-action="prev-month"]');
    if(datePrevMonthButton){
      moveDatePickerMonth(datePrevMonthButton, -1);
      return;
    }

    const dateNextMonthButton = closestElement(event.target, '[data-entry-date-action="next-month"]');
    if(dateNextMonthButton){
      moveDatePickerMonth(dateNextMonthButton, 1);
      return;
    }

    const datePrevYearButton = closestElement(event.target, '[data-entry-date-action="prev-year"]');
    if(datePrevYearButton){
      moveDatePickerYear(datePrevYearButton, -1);
      return;
    }

    const dateNextYearButton = closestElement(event.target, '[data-entry-date-action="next-year"]');
    if(dateNextYearButton){
      moveDatePickerYear(dateNextYearButton, 1);
      return;
    }

    const datePickMonthButton = closestElement(event.target, '[data-entry-date-action="pick-month"][data-entry-date-month]');
    if(datePickMonthButton){
      pickDatePickerMonth(datePickMonthButton);
      return;
    }

    const dateTodayButton = closestElement(event.target, '[data-entry-date-action="today"][data-entry-date-value]');
    if(dateTodayButton){
      applyDatePickerValue(dateTodayButton, String(dateTodayButton.getAttribute('data-entry-date-value') || todayInputValue()));
      return;
    }

    const dateClearButton = closestElement(event.target, '[data-entry-date-action="clear"]');
    if(dateClearButton){
      applyDatePickerValue(dateClearButton, '');
      return;
    }

    const dateSelectButton = closestElement(event.target, '[data-entry-date-action="select-day"][data-entry-date-value]');
    if(dateSelectButton){
      applyDatePickerValue(dateSelectButton, String(dateSelectButton.getAttribute('data-entry-date-value') || ''));
      return;
    }

    const dateCloseButton = closestElement(event.target, '[data-entry-date-action="close"]');
    if(dateCloseButton){
      const activeSheetId = getSheetIdFromNode(dateCloseButton);
      const activeMovementId = resolveDatePickerMovementId(dateCloseButton);
      clearDatePickerRuntimeState();
      rerenderModalSnapshot(() => focusDatePickerTrigger(activeSheetId, activeMovementId));
      return;
    }

    const sheetCloseButton = closestElement(event.target, '.entries-action-btn[data-entry-action="close-sheet"]');
    if(sheetCloseButton){
      feature.closeSheet(getSheetIdFromNode(sheetCloseButton));
      return;
    }

    const archiveButton = closestElement(event.target, '[data-entry-shell-action="archive"]:not([disabled])');
    if(archiveButton){
      runSheetSave(archiveButton, 'draft');
      return;
    }

    const addButton = closestElement(event.target, '[data-entry-shell-action="add"]:not([disabled])');
    if(addButton){
      runSheetSave(addButton, 'posted');
      return;
    }

    const movementButton = closestElement(event.target, '[data-entry-card-action][data-movement-id]');
    if(movementButton){
      runMovementCardAction(movementButton);
      return;
    }

    const optionButton = closestElement(event.target, '[data-entry-account-option="select"][data-movement-id]');
    if(optionButton){
      selectAccountSearchOption(optionButton);
      return;
    }

    const navButton = closestElement(event.target, '[data-entry-voucher-nav="prev"], [data-entry-voucher-nav="prev10"], [data-entry-voucher-nav="next"], [data-entry-voucher-nav="next10"]');
    if(navButton){
      runVoucherNavigatorAction(navButton, String(navButton.getAttribute('data-entry-voucher-nav') || ''));
    }
  }


  function handleModalScroll(event){
    const canvas = event.target instanceof HTMLElement && event.target.matches('.entries-sheet__canvas[data-entry-sheet-canvas="true"]')
      ? event.target
      : closestElement(event.target, '.entries-sheet__canvas[data-entry-sheet-canvas="true"]');
    if(canvas instanceof HTMLElement){
      maybeExpandJournalCanvas(canvas);
    }
  }

  function handleModalInput(event){
    const lookupInput = closestElement(event.target, '[data-entry-voucher-nav="lookup"]');
    if(lookupInput instanceof HTMLInputElement && lookupInput === event.target){
      handleLookupInput(lookupInput);
      return;
    }

    const field = isSheetField(event.target) ? event.target : closestElement(event.target, SHEET_FIELD_SELECTOR);
    if(field instanceof HTMLElement){
      handleFieldInput(field);
    }
  }

  function handleModalChange(event){
    const field = isSheetField(event.target) ? event.target : closestElement(event.target, SHEET_FIELD_SELECTOR);
    if(field instanceof HTMLElement){
      handleFieldChange(field);
    }
  }

  function handleModalFocusIn(event){
    const field = isSheetField(event.target) ? event.target : closestElement(event.target, SHEET_FIELD_SELECTOR);
    if(field instanceof HTMLInputElement && isAccountSearchField(field)){
      refreshAccountSearchDropdown(field, { activate: true });
    }
  }

  function handleModalFocusOut(event){
    const field = isSheetField(event.target) ? event.target : closestElement(event.target, SHEET_FIELD_SELECTOR);
    if(!(field instanceof HTMLInputElement) || !isAccountSearchField(field)) return;

    window.setTimeout(() => {
      const activeElement = document.activeElement;
      const accountPopover = getAccountSearchList(field);
      if(activeElement && (field.closest('.entries-account-search')?.contains(activeElement) || (accountPopover instanceof HTMLElement && accountPopover.contains(activeElement)))) return;
      finalizeAccountSearch(field);
    }, 0);
  }

  function handleModalKeydown(event){
    if(event.key === 'Escape'){
      const choiceState = ensureChoicePickerState();
      if(choiceState.sheetId && choiceState.field){
        event.preventDefault();
        const activeSheetId = choiceState.sheetId;
        const activeField = choiceState.field;
        const activeMovementId = choiceState.movementId;
        clearChoicePickerRuntimeState(activeSheetId, activeField, activeMovementId);
        rerenderModalSnapshot(() => focusChoicePickerTrigger(activeSheetId, activeField, activeMovementId));
        return;
      }

      const pickerState = ensureDatePickerState();
      if(pickerState.sheetId){
        event.preventDefault();
        const activeSheetId = pickerState.sheetId;
        const activeMovementId = String(pickerState.movementId || '').trim();
        clearDatePickerRuntimeState();
        rerenderModalSnapshot(() => focusDatePickerTrigger(activeSheetId, activeMovementId));
        return;
      }
    }

    const choiceTrigger = closestElement(event.target, '[data-entry-choice-action="toggle"][data-entry-choice-trigger="true"]');
    if(choiceTrigger instanceof HTMLButtonElement){
      const sheetId = getSheetIdFromNode(choiceTrigger);
      const field = String(choiceTrigger.getAttribute('data-field') || '').trim();
      const movementId = String(choiceTrigger.getAttribute('data-movement-id') || '').trim();
      const pickerState = ensureChoicePickerState();
      const isOpen = pickerState.sheetId === sheetId && pickerState.field === field && pickerState.movementId === movementId;

      if(event.key === 'Tab'){
        if(!isOpen) return;
        event.preventDefault();
        clearChoicePickerRuntimeState(sheetId, field, movementId);
        rerenderModalSnapshot(() => {
          if(!focusRelativeEntriesFromChoicePicker(sheetId, field, movementId, event.shiftKey ? -1 : 1)){
            focusChoicePickerTrigger(sheetId, field, movementId);
          }
        });
        return;
      }

      if(event.key === 'Enter' || event.key === 'NumpadEnter' || event.key === ' ' || event.key === 'Spacebar'){
        event.preventDefault();
        if(event.shiftKey){
          focusRelativeEntriesFlowTarget(choiceTrigger, -1);
          return;
        }
        openChoicePickerForKeyboard(choiceTrigger);
        return;
      }

      if(event.key === 'ArrowDown' || event.key === 'ArrowUp'){
        event.preventDefault();
        openChoicePickerForKeyboard(choiceTrigger, event.key === 'ArrowUp' ? 'last' : 'current');
        return;
      }

      if(!event.shiftKey && !isOpen && (event.key === 'ArrowRight' || event.key === 'ArrowLeft')){
        const didStep = stepChoicePickerSelection(choiceTrigger, event.key === 'ArrowRight' ? 1 : -1);
        if(didStep) event.preventDefault();
        return;
      }
    }

    const choiceOptionButton = closestElement(event.target, '[data-entry-choice-action="select"]');
    if(choiceOptionButton instanceof HTMLButtonElement){
      if(event.key === 'ArrowDown'){
        event.preventDefault();
        moveChoicePickerOptionFocus(choiceOptionButton, 1);
        return;
      }
      if(event.key === 'ArrowUp'){
        event.preventDefault();
        moveChoicePickerOptionFocus(choiceOptionButton, -1);
        return;
      }
      if(event.key === 'Home'){
        event.preventDefault();
        focusChoicePickerOption(choiceOptionButton, 0);
        return;
      }
      if(event.key === 'End'){
        event.preventDefault();
        const buttons = getChoicePickerOptionButtons(choiceOptionButton);
        focusChoicePickerOption(choiceOptionButton, buttons.length - 1);
        return;
      }
      if(event.key === 'Enter' || event.key === 'NumpadEnter' || event.key === ' ' || event.key === 'Spacebar'){
        event.preventDefault();
        applyChoicePickerSelection(choiceOptionButton, { focusStep: event.shiftKey ? -1 : 1 });
        return;
      }
      if(event.key === 'Tab'){
        event.preventDefault();
        const trigger = closestElement(choiceOptionButton, '[data-entry-choice-picker="true"]')?.querySelector('[data-entry-choice-trigger="true"][data-field]');
        const sheetId = trigger ? getSheetIdFromNode(trigger) : '';
        const field = trigger ? String(trigger.getAttribute('data-field') || '').trim() : '';
        const movementId = trigger ? String(trigger.getAttribute('data-movement-id') || '').trim() : '';
        clearChoicePickerRuntimeState(sheetId, field, movementId);
        rerenderModalSnapshot(() => {
          if(!focusRelativeEntriesFromChoicePicker(sheetId, field, movementId, event.shiftKey ? -1 : 1)){
            focusChoicePickerTrigger(sheetId, field, movementId);
          }
        });
        return;
      }
    }

    const dateTrigger = closestElement(event.target, '[data-entry-date-action="toggle"]');
    if(dateTrigger instanceof HTMLButtonElement){
      const sheetId = getSheetIdFromNode(dateTrigger);
      const movementId = resolveDatePickerMovementId(dateTrigger);
      const pickerState = ensureDatePickerState();
      const isOpen = String(pickerState.sheetId || '').trim() === sheetId && String(pickerState.movementId || '').trim() === movementId;

      if(event.key === 'Tab'){
        if(!isOpen) return;
        event.preventDefault();
        clearDatePickerRuntimeState();
        rerenderModalSnapshot(() => {
          if(!focusRelativeEntriesFromDatePicker(sheetId, movementId, event.shiftKey ? -1 : 1)){
            focusDatePickerTrigger(sheetId, movementId);
          }
        });
        return;
      }

      if(event.key === 'Enter' || event.key === 'NumpadEnter' || event.key === ' ' || event.key === 'Spacebar'){
        event.preventDefault();
        if(event.shiftKey){
          focusRelativeEntriesFlowTarget(dateTrigger, -1);
          return;
        }
        openDatePickerForKeyboard(dateTrigger);
        return;
      }

      if(event.key === 'ArrowDown' || event.key === 'ArrowUp'){
        event.preventDefault();
        openDatePickerForKeyboard(dateTrigger, event.key === 'ArrowUp' ? 'last' : 'current');
        return;
      }
    }

    const datePopoverButton = closestElement(event.target, '[data-entry-date-action]');
    if(datePopoverButton instanceof HTMLButtonElement && !datePopoverButton.matches('[data-entry-date-action="toggle"]')){
      if(event.key === 'Tab'){
        event.preventDefault();
        const sheetId = getSheetIdFromNode(datePopoverButton);
        const movementId = resolveDatePickerMovementId(datePopoverButton);
        clearDatePickerRuntimeState();
        rerenderModalSnapshot(() => {
          if(!focusRelativeEntriesFromDatePicker(sheetId, movementId, event.shiftKey ? -1 : 1)){
            focusDatePickerTrigger(sheetId, movementId);
          }
        });
        return;
      }
    }

    const optionButton = closestElement(event.target, '[data-entry-account-option="select"][data-movement-id]');
    if(optionButton instanceof HTMLButtonElement){
      const sheetId = getSheetIdFromNode(optionButton);
      const movementId = String(optionButton.getAttribute('data-movement-id') || '').trim();
      if(event.key === 'Enter' || event.key === 'NumpadEnter' || event.key === ' ' || event.key === 'Spacebar'){
        event.preventDefault();
        selectAccountSearchOption(optionButton);
        window.requestAnimationFrame(() => {
          focusRelativeEntriesFromField(sheetId, 'counterpartAccountQuery', movementId, event.shiftKey ? -1 : 1);
        });
        return;
      }
      if(event.key === 'Tab'){
        event.preventDefault();
        const accountInput = resolveSheetFieldAnchor(sheetId, 'counterpartAccountQuery', movementId);
        if(accountInput instanceof HTMLInputElement){
          closeAccountSearchDropdown(accountInput);
          focusRelativeEntriesFlowTarget(accountInput, event.shiftKey ? -1 : 1);
        }
        return;
      }
    }

    const lookupInput = closestElement(event.target, '[data-entry-voucher-nav="lookup"]');
    if(lookupInput instanceof HTMLInputElement && lookupInput === event.target && event.key === 'Enter'){
      event.preventDefault();
      runVoucherNavigatorAction(lookupInput, 'lookup');
      return;
    }

    const field = isSheetField(event.target) ? event.target : closestElement(event.target, SHEET_FIELD_SELECTOR);
    if(field instanceof HTMLInputElement && isAccountSearchField(field)){
      handleAccountSearchKeydown(event, field);
      return;
    }

    const modalFlowTarget = event.target instanceof HTMLElement ? event.target.closest(ENTRIES_MODAL_FLOW_SELECTOR) : null;
    if((event.key === 'Enter' || event.key === 'NumpadEnter') && modalFlowTarget instanceof HTMLElement){
      if(modalFlowTarget instanceof HTMLTextAreaElement && !event.shiftKey) return;
      if(modalFlowTarget instanceof HTMLButtonElement) return;
      event.preventDefault();
      focusRelativeEntriesFlowTarget(modalFlowTarget, event.shiftKey ? -1 : 1);
      return;
    }
  }

  function bindPanelDelegates(panel, signal){
    panel.addEventListener('click', handlePanelClick, { signal });
    panel.addEventListener('input', handlePanelInput, { signal });
  }

  function bindModalDelegates(modalLayer, signal){
    modalLayer.addEventListener('pointerdown', handleModalPointerDown, { signal });
    modalLayer.addEventListener('pointermove', handleModalPointerMove, { signal, passive: true });
    modalLayer.addEventListener('click', handleModalClick, { signal });
    modalLayer.addEventListener('scroll', handleModalScroll, { signal, capture: true });
    modalLayer.addEventListener('input', handleModalInput, { signal });
    modalLayer.addEventListener('change', handleModalChange, { signal });
    modalLayer.addEventListener('focusin', handleModalFocusIn, { signal });
    modalLayer.addEventListener('focusout', handleModalFocusOut, { signal });
    modalLayer.addEventListener('keydown', handleModalKeydown, { signal });
  }

  function bindDocumentDelegates(doc, signal){
    doc.addEventListener('pointerdown', handleDocumentPointerDown, { signal, capture: true });
  }

  function bindWindowDelegates(win, signal){
    const sync = () => scheduleExternalEntriesRefresh();
    const handleStorage = (event) => {
      const key = event && typeof event.key === 'string' ? event.key.trim() : '';
      if(!key || !EXTERNAL_SYNC_STORAGE_KEYS.has(key)) return;
      scheduleExternalEntriesRefresh();
    };

    const events = TAIF.core && TAIF.core.events;
    if(events && typeof events.onMany === 'function'){
      events.onMany([
        events.EVENT_NAMES.CHART_OF_ACCOUNTS_UPDATED,
        events.EVENT_NAMES.CURRENCY_UPDATED,
        events.EVENT_NAMES.CASH_BOXES_UPDATED
      ], sync, { signal });
    }else{
      win.addEventListener('taif:chart-of-accounts-updated', sync, { signal });
      win.addEventListener('taif:currency-domain-updated', sync, { signal });
      win.addEventListener('taif:cash-boxes-updated', sync, { signal });
    }
    win.addEventListener('storage', handleStorage, { signal });
  }

  function bindEntriesViewEvents(){
    if(!runtime.panel) return;

    cleanupSheetChrome();
    runCleanupSlot(runtime, 'topbarFitCleanup');
    runtime.topbarFitCleanup = mountTopbarAdaptiveFit(runtime.panel);

    ensureBindingSlot('panelBindings', runtime.panel, bindPanelDelegates);

    const modalLayer = getModalLayer();
    ensureBindingSlot('modalBindings', modalLayer, bindModalDelegates);
    ensureBindingSlot('documentBindings', document, bindDocumentDelegates);
    ensureBindingSlot('windowBindings', window, bindWindowDelegates);

    modalLayer?.querySelectorAll('.entries-modal-backdrop[data-entry-sheet-id]').forEach((backdrop) => {
      const sheetId = String(backdrop.getAttribute('data-entry-sheet-id') || '');
      const modalWindow = backdrop.querySelector('.entries-modal-window');
      const expandButton = backdrop.querySelector('[data-entry-action="expand-sheet"]');
      const closeButton = backdrop.querySelector('.entries-sheet__window-actions [data-entry-action="close-sheet"]');
      runtime.sheetChromeCleanups.push(
        bindEntriesSheetChrome({ panel: runtime.panel, backdrop, modalWindow, expandButton, closeButton, sheetId })
      );
    });

    sanitizeTransientDropdownDomState(modalLayer);
    applySheetWindowStackState();
  }

  Object.assign(feature, {
    bindEntriesViewEvents,
    cleanupEntriesViewBindings
  });
})();
