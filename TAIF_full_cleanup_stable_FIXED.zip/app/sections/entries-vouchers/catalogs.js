(()=>{
  /*
   * TAIF Entries & Vouchers catalog helpers.
   * Normalizes storage-backed accounts/currencies and lookup behavior.
   */
  const TAIF = window.TAIF;
  const { readJsonStorage, normalizeAccountCatalog, readChartAccountCatalogSource, resolveCurrencyDecimals } = TAIF.core.utils;
  const feature = TAIF.entriesVouchersFeature || (TAIF.entriesVouchersFeature = {});
  const {
    ACCOUNT_STORAGE_KEY,
    CASH_BOX_STORAGE_KEY,
    CURRENCY_STORAGE_KEY,
    FALLBACK_CURRENCY,
    toText,
    resolveVoucherType,
    getInteractiveVoucherDefinition
  } = feature;

  function ensureCurrencyCatalog(source){
    const safeSource = Array.isArray(source) ? source : [];
    const normalized = safeSource.map((item) => {
      const sourceItem = item && typeof item === 'object' ? item : {};
      const code = toText(sourceItem.code).toUpperCase().replace(/[^A-Z]/g, '').slice(0, 5);
      if(!code) return null;
      return {
        code,
        name: toText(sourceItem.name, code) || code,
        flag: toText(sourceItem.flag).toLowerCase(),
        decimals: resolveCurrencyDecimals(sourceItem.decimals, 2)
      };
    }).filter(Boolean);

    return normalized.length ? normalized : [FALLBACK_CURRENCY];
  }


  function ensureAccountCatalog(source){
    return typeof normalizeAccountCatalog === 'function'
      ? normalizeAccountCatalog(source, toText)
      : [];
  }


  function resolveVoucherCatalogs(catalogs = null){
    const source = catalogs && typeof catalogs === 'object' ? catalogs : readVoucherCatalogs();
    return {
      accounts: ensureAccountCatalog(source.accounts),
      currencies: ensureCurrencyCatalog(source.currencies)
    };
  }


  function resolveCurrencyCatalog(catalog = null){
    return Array.isArray(catalog) ? catalog : readCurrencyCatalog();
  }


  function resolveAccountCatalog(catalog = null){
    return Array.isArray(catalog) ? catalog : readAccountCatalog();
  }


  function readPrimaryCashBox(catalog = readAccountCatalog()){
    const safeCatalog = resolveAccountCatalog(catalog);
    const cashBoxDomain = TAIF.cashBoxesDomain || {};
    const cashBoxApi = TAIF.cashBoxes || {};
    const state = typeof cashBoxDomain.readState === 'function'
      ? cashBoxDomain.readState()
      : (typeof cashBoxApi.readState === 'function'
          ? cashBoxApi.readState()
          : readJsonStorage(CASH_BOX_STORAGE_KEY, null));
    const mainBox = Array.isArray(state?.boxes) && state.boxes.length ? state.boxes[0] : null;
    return mainBox ? findAccountByNo(mainBox.linkedAccountNo, safeCatalog) : null;
  }


  function readCurrencyCatalog(){
    const currencyFeature = TAIF.currencyDomain || TAIF.currencyManagementFeature || {};
    const currencyApi = TAIF.currencyDomain || TAIF.currencyManagement || {};
    const defaultCurrencies = Array.isArray(currencyFeature.DEFAULT_CURRENCIES) && currencyFeature.DEFAULT_CURRENCIES.length
      ? currencyFeature.DEFAULT_CURRENCIES
      : [FALLBACK_CURRENCY];

    let source = [];
    if(typeof currencyApi.readState === 'function'){
      const state = currencyApi.readState();
      source = Array.isArray(state?.currencies) ? state.currencies : (Array.isArray(state) ? state : []);
    }
    if(!source.length){
      const stored = readJsonStorage(CURRENCY_STORAGE_KEY, null);
      source = Array.isArray(stored?.currencies) ? stored.currencies : (Array.isArray(stored) ? stored : []);
    }
    if(!source.length) source = defaultCurrencies;

    return ensureCurrencyCatalog(source);
  }


  function readAccountCatalog(){
    if(typeof readChartAccountCatalogSource === 'function'){
      const source = readChartAccountCatalogSource(ACCOUNT_STORAGE_KEY, readJsonStorage);
      return ensureAccountCatalog(source);
    }

    const publicApi = TAIF.chartOfAccounts || {};
    const internalApi = publicApi.internal || {};
    let source = [];

    if(typeof publicApi.readState === 'function'){
      source = publicApi.readState();
    }else if(typeof internalApi.getCenters === 'function'){
      source = internalApi.getCenters(true);
    }else if(typeof internalApi.readCenters === 'function'){
      source = internalApi.readCenters();
    }else{
      const stored = readJsonStorage(ACCOUNT_STORAGE_KEY, null);
      source = Array.isArray(stored) ? stored : (Array.isArray(stored?.centers) ? stored.centers : []);
    }

    return ensureAccountCatalog(source);
  }


  function findCurrencyByCode(code, catalog = readCurrencyCatalog()){
    const safeCatalog = resolveCurrencyCatalog(catalog);
    const safeCode = toText(code).toUpperCase();
    return safeCatalog.find((item) => item.code === safeCode) || safeCatalog[0] || FALLBACK_CURRENCY;
  }


  function findAccountByNo(accountNo, catalog = readAccountCatalog()){
    const safeCatalog = resolveAccountCatalog(catalog);
    const safeAccountNo = toText(accountNo);
    return safeCatalog.find((item) => item.accountNo === safeAccountNo) || null;
  }


  function normalizeAccountClassificationText(value){
    return normalizeAccountLookupText(value).replace(/\s+/g, ' ').trim();
  }


  function accountNameHasKeyword(name, keyword){
    const safeName = normalizeAccountClassificationText(name);
    const safeKeyword = normalizeAccountClassificationText(keyword);
    return !!safeName && !!safeKeyword && safeName.includes(safeKeyword);
  }


  function isOpeningBalanceEligibleAccount(account){
    const safeAccount = account && typeof account === 'object' ? account : null;
    if(!safeAccount) return false;

    const accountNo = toText(safeAccount.accountNo);
    const name = normalizeAccountClassificationText(safeAccount.name);
    if(!accountNo || !name) return false;

    const hardBlockedPhrases = [
      'ارباح وخسائر',
      'ارباح وخساير',
      'الارباح والخسائر'
    ];
    if(hardBlockedPhrases.some((phrase) => accountNameHasKeyword(name, phrase))) return false;

    const allowKeywords = [
      'راس المال',
      'رأس المال',
      'راسمالي',
      'رأسمالي',
      'مدفوع',
      'صندوق',
      'بنك',
      'حسابات',
      'ذمم',
      'عميل',
      'مورد',
      'حوال',
      'قطع',
      'عملات',
      'مخزون',
      'اصل',
      'أصل',
      'التزام',
      'استثمار'
    ];
    const hasAllowKeyword = allowKeywords.some((keyword) => accountNameHasKeyword(name, keyword));

    const blockedKeywords = [
      'مصاريف',
      'مصروف',
      'ايراد',
      'إيراد',
      'ايرادات',
      'إيرادات',
      'مبيعات',
      'مشتريات',
      'تكاليف',
      'تكلفه',
      'تكلفة',
      'رواتب',
      'اجور',
      'أجور',
      'فوائد',
      'فائدة',
      'عمولة',
      'دخل',
      'اهلاك',
      'إهلاك',
      'استهلاك',
      'خسائر',
      'خساره',
      'خسارة',
      'ربح',
      'ارباح',
      'أرباح'
    ];
    const hasBlockedKeyword = blockedKeywords.some((keyword) => accountNameHasKeyword(name, keyword));
    if(hasBlockedKeyword && !hasAllowKeyword) return false;

    const leadingDigit = accountNo.charAt(0);
    if(/^[456789]$/.test(leadingDigit) && !hasAllowKeyword) return false;

    return true;
  }


  function getOpeningBalanceAccountCatalog(catalog = readAccountCatalog()){
    return resolveAccountCatalog(catalog).filter((account) => isOpeningBalanceEligibleAccount(account));
  }


  function normalizeAccountLookupText(value){
    return toText(value)
      .replace(/[٠-٩]/g, (digit) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)))
      .replace(/[أإآ]/g, 'ا')
      .replace(/ى/g, 'ي')
      .replace(/[ـ\-—–_/\:؛،,.]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }


  function buildAccountLookupLabel(account){
    if(!account) return '';
    return `${toText(account.accountNo)} — ${toText(account.name)}`.trim();
  }


  function isAccountLookupSettled(query, account){
    if(!account) return false;
    const normalizedQuery = normalizeAccountLookupText(query);
    if(!normalizedQuery) return false;
    return [
      account.accountNo,
      account.name,
      buildAccountLookupLabel(account)
    ]
      .map((value) => normalizeAccountLookupText(value))
      .filter(Boolean)
      .includes(normalizedQuery);
  }


  function scoreAccountLookupMatch(normalizedQuery, account){
    if(!normalizedQuery || !account) return -1;
    const accountNo = normalizeAccountLookupText(account.accountNo);
    const accountName = normalizeAccountLookupText(account.name);
    const accountLabel = normalizeAccountLookupText(buildAccountLookupLabel(account));
    const parts = normalizedQuery.split(' ').filter(Boolean);
    if(!parts.length) return -1;
    if(!parts.every((part) => accountNo.includes(part) || accountName.includes(part) || accountLabel.includes(part))) return -1;

    let score = 0;
    if(accountNo === normalizedQuery) score += 1500;
    else if(accountNo.startsWith(normalizedQuery)) score += 1000;
    else if(accountNo.includes(normalizedQuery)) score += 700;

    if(accountName === normalizedQuery) score += 1400;
    else if(accountName.startsWith(normalizedQuery)) score += 900;
    else if(accountName.includes(normalizedQuery)) score += 650;

    if(accountLabel.startsWith(normalizedQuery)) score += 320;
    else if(accountLabel.includes(normalizedQuery)) score += 180;

    parts.forEach((part, index) => {
      if(accountNo.startsWith(part)) score += 80 - index;
      else if(accountNo.includes(part)) score += 42 - index;
      if(accountName.startsWith(part)) score += 72 - index;
      else if(accountName.includes(part)) score += 36 - index;
    });

    return score;
  }


  function searchAccounts(query, catalog = readAccountCatalog(), exclude = [], limit = 8){
    const normalizedQuery = normalizeAccountLookupText(query);
    if(!normalizedQuery) return [];
    const safeCatalog = resolveAccountCatalog(catalog);
    const exclusions = new Set((Array.isArray(exclude) ? exclude : []).map((value) => toText(value)));
    return safeCatalog
      .map((account) => {
        if(!account || exclusions.has(account.accountNo)) return null;
        const score = scoreAccountLookupMatch(normalizedQuery, account);
        return score > -1 ? { account, score } : null;
      })
      .filter(Boolean)
      .sort((left, right) => {
        if(right.score !== left.score) return right.score - left.score;
        return String(left.account.accountNo).localeCompare(String(right.account.accountNo), 'en');
      })
      .slice(0, Math.max(1, Number(limit) || 8))
      .map((item) => item.account);
  }


  function findAccountByLookupQuery(query, catalog = readAccountCatalog(), exclude = []){
    const normalizedQuery = normalizeAccountLookupText(query);
    if(!normalizedQuery) return null;
    const safeCatalog = resolveAccountCatalog(catalog);
    const exclusions = new Set((Array.isArray(exclude) ? exclude : []).map((value) => toText(value)));
    return safeCatalog.find((account) => {
      if(!account || exclusions.has(account.accountNo)) return false;
      return [account.accountNo, account.name, buildAccountLookupLabel(account)]
        .map((value) => normalizeAccountLookupText(value))
        .filter(Boolean)
        .includes(normalizedQuery);
    }) || null;
  }


  function findFirstAccountByName(parts, catalog, exclude = []){
    const safeCatalog = resolveAccountCatalog(catalog);
    const exclusions = new Set((Array.isArray(exclude) ? exclude : []).map((value) => toText(value)));
    return safeCatalog.find((item) => {
      if(!item || exclusions.has(item.accountNo)) return false;
      const haystack = `${item.accountNo} ${item.name}`;
      return parts.every((part) => haystack.includes(part));
    }) || null;
  }


  function createCashAccountMatcher(catalog = readAccountCatalog()){
    const safeCatalog = resolveAccountCatalog(catalog);
    const primaryCashBox = readPrimaryCashBox(safeCatalog);
    const primaryCashAccountNo = toText(primaryCashBox && primaryCashBox.accountNo);

    return (account) => {
      const safeAccount = account && typeof account === 'object' ? account : null;
      if(!safeAccount) return false;

      const accountNo = toText(safeAccount.accountNo);
      if(!accountNo) return false;

      if(toText(safeAccount.centerType) === 'box') return true;
      return !!primaryCashAccountNo && accountNo === primaryCashAccountNo;
    };
  }


  function getCashAccountCatalog(catalog = readAccountCatalog()){
    const safeCatalog = resolveAccountCatalog(catalog);
    const isCashAccount = createCashAccountMatcher(safeCatalog);
    return safeCatalog.filter((account) => isCashAccount(account));
  }


  function resolveDefaultCashAccount(catalog = readAccountCatalog()){
    const safeCatalog = resolveAccountCatalog(catalog);
    const primaryCashBox = readPrimaryCashBox(safeCatalog);
    const cashCatalog = getCashAccountCatalog(safeCatalog);
    return (primaryCashBox && cashCatalog.find((item) => item.accountNo === primaryCashBox.accountNo))
      || findFirstAccountByName(['الصندوق'], cashCatalog)
      || cashCatalog.find((item) => item.accountNo === '001')
      || cashCatalog[0]
      || primaryCashBox
      || findFirstAccountByName(['الصندوق'], safeCatalog)
      || safeCatalog.find((item) => item.accountNo === '001')
      || safeCatalog[0]
      || null;
  }


  function getCashMotionOptions(type){
    const definition = getInteractiveVoucherDefinition(type);
    const options = Array.isArray(definition?.cashMotionOptions)
      ? definition.cashMotionOptions.map((option) => {
          const value = toText(option?.value || option?.code || option?.label);
          const label = toText(option?.label, value);
          return value && label ? { value, label } : null;
        }).filter(Boolean)
      : [];

    if(options.length) return options;

    const fallbackLabel = toText(definition?.cashMotionLabel);
    return fallbackLabel ? [{ value: resolveVoucherType(type), label: fallbackLabel }] : [];
  }


  function resolveCashMotionOption(type, requestedValue = ''){
    const options = getCashMotionOptions(type);
    const safeValue = toText(requestedValue);
    return options.find((option) => option.value === safeValue) || options[0] || { value: '', label: '' };
  }


  function readVoucherCatalogs(){
    return resolveVoucherCatalogs({
      accounts: readAccountCatalog(),
      currencies: readCurrencyCatalog()
    });
  }


  Object.assign(feature, {
  resolveVoucherCatalogs,
  readCurrencyCatalog,
  readAccountCatalog,
  findCurrencyByCode,
  findAccountByNo,
  isOpeningBalanceEligibleAccount,
  getOpeningBalanceAccountCatalog,
  normalizeAccountLookupText,
  buildAccountLookupLabel,
  isAccountLookupSettled,
  searchAccounts,
  findAccountByLookupQuery,
  getCashAccountCatalog,
  resolveDefaultCashAccount,
  getCashMotionOptions,
  resolveCashMotionOption,
  readVoucherCatalogs
});

})();
