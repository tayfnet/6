(()=>{
  /*
   * TAIF Entries & Vouchers controller helpers.
   * Owns sheet lifecycle plus save/navigation actions on top of the shared render flow.
   */
  const TAIF = window.TAIF;
  const { runCleanupSlot, focusElementWithoutScroll } = TAIF.core.utils;
  const feature = TAIF.entriesVouchersFeature || (TAIF.entriesVouchersFeature = {});
  const {
    runtime,
    getModalLayer,
    createSheetState,
    getSheet,
    getSheetIdFromNode,
    syncWindowOrder,
    getTopSheetId,
    activateSheetWindow,
    removeSheet,
    cleanupSheetChrome,
    updateSheetDraft,
    updateSheetMovementField,
    appendSheetMovement,
    removeSheetMovement,
    readState,
    getVisibleRecords,
    getVoucherRecordGroups,
    buildVoucherDraftFromRecordGroup,
    clearSheetValidationState,
    getVoucherDeletionScope,
    deleteVoucherByRecordId,
    saveSheetAsRecord,
    ensureSheetNavigator,
    syncSheetNavigatorBaseline,
    navigateSheetVoucher,
    jumpSheetToVoucher,
    snapshotModalCanvasPositions,
    renderEntriesBoard,
    renderEntriesFromSnapshot,
    refreshEntriesModalLayer,
    renderEntriesWithSelectionRestore,
    restoreMovementFieldFocus,
    restoreLookupFieldFocus,
    rerenderEntriesAfterMutation,
    createVoucherDeleteQuestionOptions,
    renderVoucherDeleteConfirmMarkup,
    clearChoicePickerRuntimeState,
    clearDatePickerRuntimeState,
    getCounterpartAccountOptions,
    buildAccountLookupLabel,
    clearAccountSearchState
  } = feature;

  function clearTransientUiState(sheetId = ''){
    clearAccountSearchState(sheetId);
    clearChoicePickerRuntimeState(sheetId);
    if(!sheetId || runtime.datePicker?.sheetId === sheetId){
      clearDatePickerRuntimeState();
    }
  }

  function closeDeleteConfirmDialog(){
    runCleanupSlot(runtime, 'deleteConfirmCleanup');
  }

  function getVisibleRecordId(record){
    return String(record?.id || '').trim();
  }

  function resolveNextSelectionAfterDeletion(state, deletedIds, selectedRecordId){
    const deletedIdSet = deletedIds instanceof Set ? deletedIds : new Set(Array.isArray(deletedIds) ? deletedIds : []);
    const visibleRecords = getVisibleRecords(state);
    if(!visibleRecords.length) return '';
    const selectedIndex = visibleRecords.findIndex((record) => getVisibleRecordId(record) === selectedRecordId);
    const remainingVisibleRecords = visibleRecords.filter((record) => !deletedIdSet.has(getVisibleRecordId(record)));
    if(!remainingVisibleRecords.length) return '';
    const fallbackIndex = selectedIndex >= 0 ? selectedIndex : 0;
    const nextIndex = Math.max(0, Math.min(remainingVisibleRecords.length - 1, fallbackIndex));
    return getVisibleRecordId(remainingVisibleRecords[nextIndex] || remainingVisibleRecords[remainingVisibleRecords.length - 1] || null);
  }

  function focusBoardSelectionTarget(){
    if(!(runtime.panel instanceof Element) || !runtime.panel.isConnected) return;
    const target = runtime.panel.querySelector('[data-entry-action="delete-selected-record"]:not([disabled])')
      || runtime.panel.querySelector('[data-entry-action="search"]');
    if(target instanceof HTMLElement) focusElementWithoutScroll(target);
  }

  function openDeleteConfirmDialog(scope, onConfirm){
    closeDeleteConfirmDialog();
    if(!(runtime.panel instanceof Element) || !runtime.panel.isConnected) return;

    const questionDialog = TAIF?.ui?.questionDialog;
    if(!questionDialog || typeof questionDialog.open !== 'function') return;

    const questionOptions = typeof createVoucherDeleteQuestionOptions === 'function'
      ? createVoucherDeleteQuestionOptions(scope)
      : {
          owner:'entries-vouchers',
          title:'حذف سند نهائي',
          confirmLabel:'حذف نهائي',
          confirmTone:'danger',
          warning:'هل أنت متأكد من حذف هذا السند؟ سيتم حذف السند وتأثيراته من السجل الحالي.'
        };

    let cleanup = null;
    const dialogApi = questionDialog.open({
      ...questionOptions,
      onConfirm(){
        if(typeof onConfirm === 'function') onConfirm();
      },
      onClose(){
        if(runtime.deleteConfirmCleanup === cleanup){
          runtime.deleteConfirmCleanup = null;
        }
      }
    });

    cleanup = () => {
      if(dialogApi && typeof dialogApi.close === 'function'){
        dialogApi.close(true);
      }
    };
    runtime.deleteConfirmCleanup = cleanup;
  }

  function deleteSelectedVoucherRecord(recordId = String(runtime.selectedRecordId || '').trim()){
    const targetRecordId = String(recordId || '').trim();
    if(!targetRecordId) return { ok: false, issues: ['حدد سنداً أولاً.'] };

    const state = readState();
    const scope = getVoucherDeletionScope(targetRecordId, state);
    if(!scope.record){
      runtime.selectedRecordId = '';
      renderEntriesBoard();
      return { ok: false, issues: ['تعذر العثور على السند المحدد.'] };
    }
    if(scope.lockedForMutation){
      return { ok: false, issues: ['هذا القيد مرتبط مباشرة بفاتورة شراء/مبيع ويجب حذفه من نافذة الشراء/المبيع نفسها.'], scope };
    }

    const deletedIds = new Set(scope.ids);
    const nextSelectedRecordId = resolveNextSelectionAfterDeletion(state, deletedIds, targetRecordId);
    const snapshot = snapshotModalCanvasPositions();
    const result = deleteVoucherByRecordId(targetRecordId);
    if(!result || !result.ok){
      runtime.selectedRecordId = '';
      renderEntriesFromSnapshot(snapshot);
      return result || { ok: false, issues: ['تعذر حذف السند المحدد.'] };
    }

    runtime.selectedRecordId = nextSelectedRecordId;
    renderEntriesFromSnapshot(snapshot, () => {
      if(typeof feature.updateRecordSelectionUi === 'function'){
        feature.updateRecordSelectionUi();
      }
      focusBoardSelectionTarget();
    });
    return result;
  }

  function requestSelectedVoucherDeletion(){
    const selectedRecordId = String(runtime.selectedRecordId || '').trim();
    if(!selectedRecordId) return;

    const state = readState();
    const scope = getVoucherDeletionScope(selectedRecordId, state);
    if(!scope.record){
      runtime.selectedRecordId = '';
      renderEntriesBoard();
      return;
    }
    if(scope.lockedForMutation){
      if(typeof feature.updateRecordSelectionUi === 'function'){
        feature.updateRecordSelectionUi();
      }
      return;
    }

    openDeleteConfirmDialog(scope, () => {
      deleteSelectedVoucherRecord(selectedRecordId);
    });
  }

  function normalizeSourceLookupText(value){
    return String(value ?? '').trim().toUpperCase();
  }

  function findVoucherSourceGroupIndex(type, options = {}){
    const groups = typeof getVoucherRecordGroups === 'function' ? getVoucherRecordGroups(type) : [];
    if(!Array.isArray(groups) || !groups.length) return -1;
    const recordId = String(options?.recordId || '').trim();
    const number = normalizeSourceLookupText(options?.number || options?.query || '');
    if(!recordId && !number) return -1;

    return groups.findIndex((group) => {
      const groupNumber = normalizeSourceLookupText(group?.number);
      if(number && groupNumber === number) return true;
      const records = Array.isArray(group?.records) ? group.records : [];
      return records.some((record) => {
        const safeRecordId = String(record?.id || '').trim();
        const safeNumber = normalizeSourceLookupText(record?.number);
        return (recordId && safeRecordId === recordId) || (number && safeNumber === number);
      });
    });
  }

  function loadSheetFromSourceTarget(sheet, options = {}){
    if(!sheet || typeof sheet !== 'object') return false;
    const targetIndex = findVoucherSourceGroupIndex(sheet.type, options);
    if(targetIndex < 0) return false;
    const groups = typeof getVoucherRecordGroups === 'function' ? getVoucherRecordGroups(sheet.type) : [];
    const targetGroup = groups[targetIndex];
    if(!targetGroup || typeof buildVoucherDraftFromRecordGroup !== 'function') return false;

    const nextDraft = buildVoucherDraftFromRecordGroup(sheet.type, targetGroup);
    if(!nextDraft) return false;

    sheet.draft = nextDraft;
    const navigator = ensureSheetNavigator(sheet);
    if(navigator){
      navigator.currentGroupIndex = targetIndex;
      navigator.lookupValue = String(targetIndex + 1);
    }
    sheet.validationIssues = [];
    if(typeof clearSheetValidationState === 'function') clearSheetValidationState(sheet.id);
    return true;
  }

  function openSheet(type, options = {}){
    clearTransientUiState();
    const requestedType = options && typeof options === 'object' && options.voucherType ? options.voucherType : type;
    const sheet = createSheetState(requestedType);
    ensureSheetNavigator(sheet);
    loadSheetFromSourceTarget(sheet, options);
    runtime.sheets.push(sheet);
    syncWindowOrder();
    activateSheetWindow(sheet.id);
    if(runtime.panel && document.body.contains(runtime.panel)){
      refreshEntriesModalLayer();
      return sheet;
    }
    renderEntriesBoard();
    return sheet;
  }

  function closeSheet(sheetId = '', { refreshBoard = false, afterRender = null } = {}){
    const targetSheetId = sheetId || getTopSheetId();
    if(!targetSheetId) return;
    clearTransientUiState(targetSheetId);
    const snapshot = snapshotModalCanvasPositions();
    cleanupSheetChrome();
    removeSheet(targetSheetId);
    delete snapshot[targetSheetId];
    if(refreshBoard || !(runtime.panel && document.body.contains(runtime.panel))){
      renderEntriesFromSnapshot(snapshot, afterRender);
      return;
    }
    refreshEntriesModalLayer({ snapshot, afterRender });
  }

  function applyAccountSearchMatch(sheetId, movementId, account){
    if(!sheetId || !movementId || !account) return;
    const accountLabel = buildAccountLookupLabel(account);

    rerenderEntriesAfterMutation(() => {
      const currentDraft = getSheet(sheetId)?.draft || null;
      const nextDraft = updateSheetMovementField(sheetId, movementId, {
        counterpartAccountNo: String(account.accountNo || '').trim(),
        counterpartAccountQuery: accountLabel
      });
      clearAccountSearchState(sheetId, movementId);
      if(!nextDraft || nextDraft === currentDraft) return null;
      syncSheetNavigatorBaseline(sheetId);
      return accountLabel;
    }, {
      afterRender: (resolvedLabel) => {
        const label = typeof resolvedLabel === 'string' ? resolvedLabel : accountLabel;
        restoreMovementFieldFocus(
          sheetId,
          movementId,
          'counterpartAccountQuery',
          label.length,
          label.length
        );
      }
    });
  }

  function selectAccountSearchOption(button){
    if(!(button instanceof HTMLElement)) return;
    const sheetId = getSheetIdFromNode(button);
    const movementId = String(button.getAttribute('data-movement-id') || '').trim();
    const accountNo = String(button.getAttribute('data-entry-account-no') || '').trim();
    if(!sheetId || !movementId || !accountNo) return;

    const options = getCounterpartAccountOptions(sheetId);
    const account = options.find((item) => item && item.accountNo === accountNo) || null;
    if(!account) return;

    applyAccountSearchMatch(sheetId, movementId, account);
  }

  function runVoucherNavigatorAction(control, action){
    const sheetId = getSheetIdFromNode(control);
    if(!sheetId) return;

    rerenderEntriesAfterMutation(() => {
      if(action === 'prev' || action === 'prev10' || action === 'next' || action === 'next10'){
        return navigateSheetVoucher(sheetId, action);
      }
      if(action === 'lookup'){
        return jumpSheetToVoucher(sheetId, control.value || '');
      }
      return false;
    }, {
      afterRender: () => {
        if(action === 'lookup') restoreLookupFieldFocus(sheetId);
      }
    });
  }

  function commitSheetField(control){
    if(!(control instanceof HTMLElement) || !control.hasAttribute('data-field')) return false;
    const sheetId = getSheetIdFromNode(control);
    const fieldName = String(control.getAttribute('data-field') || '').trim();
    const movementId = String(control.getAttribute('data-movement-id') || '').trim();
    if(!sheetId || !fieldName) return false;

    const currentDraft = getSheet(sheetId)?.draft || null;
    const value = feature.readFieldControlValue(control);
    const nextDraft = movementId
      ? updateSheetMovementField(sheetId, movementId, { [fieldName]: value })
      : updateSheetDraft(sheetId, { [fieldName]: value });

    const changed = !!nextDraft && nextDraft !== currentDraft;
    if(changed) syncSheetNavigatorBaseline(sheetId);
    return changed;
  }

  function commitSheetFieldAndRender(control, { restoreCursor = false } = {}){
    const selection = restoreCursor && typeof feature.captureFieldSelection === 'function'
      ? feature.captureFieldSelection(control)
      : null;
    if(!commitSheetField(control)) return;
    renderEntriesWithSelectionRestore(selection);
  }

  function runSheetSave(button, status){
    const sheetId = getSheetIdFromNode(button);
    if(!sheetId) return;

    const snapshot = snapshotModalCanvasPositions();
    const result = saveSheetAsRecord(sheetId, status);
    if(!result || !result.ok){
      renderEntriesFromSnapshot(snapshot);
      return;
    }

    runtime.selectedRecordId = String(result.record?.id || '').trim();
    closeSheet(sheetId, {
      refreshBoard: true,
      afterRender: () => {
        if(typeof feature.updateRecordSelectionUi === 'function'){
          feature.updateRecordSelectionUi();
        }
        focusBoardSelectionTarget();
      }
    });
  }

  function runMovementCardAction(button){
    const sheetId = getSheetIdFromNode(button);
    const movementId = String(button.getAttribute('data-movement-id') || '').trim();
    const action = String(button.getAttribute('data-entry-card-action') || '').trim();
    const sheet = sheetId ? getSheet(sheetId) : null;
    if(!sheetId || !movementId || !action || !sheet) return;
    if(sheet.type === 'journal') return;

    if(action === 'append-movement'){
      rerenderEntriesAfterMutation(() => {
        const result = appendSheetMovement(sheetId, movementId);
        if(!result?.movementId) return null;
        syncSheetNavigatorBaseline(sheetId);
        return result;
      }, {
        afterRender: (result) => {
          if(result?.movementId) restoreMovementFieldFocus(sheetId, result.movementId);
        }
      });
      return;
    }

    if(action === 'remove-movement'){
      rerenderEntriesAfterMutation(() => {
        const result = removeSheetMovement(sheetId, movementId);
        if(!result) return null;
        syncSheetNavigatorBaseline(sheetId);
        return result;
      }, {
        afterRender: (result) => {
          if(result?.focusMovementId) restoreMovementFieldFocus(sheetId, result.focusMovementId);
        }
      });
    }
  }

  function cleanupEntriesView(){
    closeDeleteConfirmDialog();
    cleanupSheetChrome();
    if(typeof feature.cleanupEntriesViewBindings === 'function'){
      feature.cleanupEntriesViewBindings();
    }
    runCleanupSlot(runtime, 'topbarFitCleanup');
    const modalLayer = getModalLayer();
    modalLayer?.remove();
    runtime.modalLayer = null;
    runtime.panel = null;
    runtime.sheets = [];
    runtime.sheetSequence = 0;
    runtime.windowOrder = [];
    runtime.filter = '';
    clearTransientUiState();
  }

  Object.assign(feature, {
    openSheet,
    closeSheet,
    applyAccountSearchMatch,
    selectAccountSearchOption,
    runVoucherNavigatorAction,
    commitSheetField,
    commitSheetFieldAndRender,
    runSheetSave,
    runMovementCardAction,
    requestSelectedVoucherDeletion,
    deleteSelectedVoucherRecord,
    cleanupEntriesView
  });
})();
