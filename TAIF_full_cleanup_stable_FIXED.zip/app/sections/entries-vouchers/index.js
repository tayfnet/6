(()=>{
  /*
   * TAIF Entries & Vouchers view bootstrap.
   * Registers the feature with the shell after feature modules are loaded.
   */
  const TAIF = window.TAIF;
  const feature = TAIF.entriesVouchersFeature || (TAIF.entriesVouchersFeature = {});
  const {
    runtime,
    readState,
    writeState,
    openSheet,
    closeSheet,
    cleanupEntriesView,
    renderEntriesBoard
  } = feature;

  TAIF.entriesVouchers = TAIF.entriesVouchers || {};
  TAIF.entriesVouchers.readState = readState;
  TAIF.entriesVouchers.writeState = writeState;
  TAIF.entriesVouchers.open = openSheet;
  TAIF.entriesVouchers.close = closeSheet;
  TAIF.entriesVouchers.cleanup = cleanupEntriesView;

  TAIF.registerViewCleanup('entries-vouchers', cleanupEntriesView);
  TAIF.registerViewRenderer('entries-vouchers', ({ panel }) => {
    runtime.panel = panel;
    const pendingSourceFocus = TAIF.generalLedger && typeof TAIF.generalLedger.consumePendingSourceFocus === 'function'
      ? TAIF.generalLedger.consumePendingSourceFocus()
      : null;
    const isDirectSourceFocus = pendingSourceFocus && pendingSourceFocus.sourceKind === 'entries-vouchers';
    const pendingQuery = pendingSourceFocus && typeof pendingSourceFocus.query === 'string'
      ? pendingSourceFocus.query.trim()
      : '';
    if(pendingQuery){
      runtime.filter = pendingQuery;
    }
    renderEntriesBoard();
    if(isDirectSourceFocus && typeof openSheet === 'function'){
      requestAnimationFrame(() => {
        openSheet(pendingSourceFocus.voucherType || 'journal', pendingSourceFocus);
      });
      return;
    }
    if(pendingSourceFocus && runtime.panel instanceof HTMLElement){
      requestAnimationFrame(() => {
        const searchInput = runtime.panel && runtime.panel.querySelector
          ? runtime.panel.querySelector('[data-entry-action="search"]')
          : null;
        if(!(searchInput instanceof HTMLInputElement)) return;
        try{ searchInput.focus({ preventScroll:true }); }catch{ try{ searchInput.focus(); }catch{} }
        try{ searchInput.select(); }catch{}
      });
    }
  });
})();
