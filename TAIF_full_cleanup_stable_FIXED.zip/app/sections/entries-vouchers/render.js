(()=>{
  /*
   * TAIF Entries & Vouchers feature rendering.
   * Board rendering plus isolated payment/receipt voucher editors.
   */
  const TAIF = window.TAIF;
  const dateSystem = TAIF.ui?.dateSystem || {};
  const datePickerMonthNames = TAIF.core?.constants?.datePickerMonthNames || [];
  const datePickerWeekdayLabels = TAIF.core?.constants?.datePickerWeekdayLabels || [];
  const { escapeHtml, wrapControlTextMarkup, renderToolbarChip, renderToolbarCommandButton } = TAIF.core.utils;
  const feature = TAIF.entriesVouchersFeature || (TAIF.entriesVouchersFeature = {});
  const {
    runtime,
    VOUCHERS,
    getWindowChromeIcon,
    money,
    formatDate,
    readState,
    isInteractiveVoucherType,
    buildVoucherRenderContext,
    getVoucherRecordGroups,
    buildRecordPresentation,
    getVisibleRecords,
    findRecordById,
    isVoucherRecordLockedForMutation,
    todayInputValue,
    parseDatePickerIsoDate,
    parseDatePickerMonthCursor,
    toDatePickerIsoDate,
    toDatePickerMonthCursor,
    ensureDatePickerState,
    normalizeDatePickerView
  } = feature;

  const ACTION_ICON_MARKUP = Object.freeze({
    opening: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5 19V7.8a1 1 0 0 1 .38-.78l6.6-5.1 6.64 5.1a1 1 0 0 1 .38.79V19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M9 19v-6h6v6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>',
    settlement: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4 7h11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path><path d="m12 3 4 4-4 4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M20 17H9" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path><path d="m12 13-4 4 4 4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>',
    journal: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 4h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z" fill="none" stroke="currentColor" stroke-width="2"></path><path d="M8 9h8M8 13h8M8 17h5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path></svg>',
    receipt: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 5v14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path><path d="m6 13 6 6 6-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M6 5h12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path></svg>',
    payment: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 5v14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path><path d="m18 11-6-6-6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M6 19h12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path></svg>'
  });

  const TOOLBAR_COMMAND_ICON_MARKUP = Object.freeze({
    delete: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M3 6h18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M8 6V4h8v2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M19 6l-1 14H6L5 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M10 11v6M14 11v6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>'
  });


  const DATE_PICKER_MONTH_NAMES = datePickerMonthNames;

  const DATE_PICKER_WEEKDAY_LABELS = datePickerWeekdayLabels;

  const DATE_PICKER_ICON_MARKUP = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M7 3v3M17 3v3M4 9h16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><rect x="4" y="5" width="16" height="15" rx="3" fill="none" stroke="currentColor" stroke-width="2"></rect></svg>';
  const DATE_PICKER_CHEVRON_PREV_MARKUP = '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m12.5 4.5-5 5 5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
  const DATE_PICKER_CHEVRON_NEXT_MARKUP = '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m7.5 4.5 5 5-5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
  const VOUCHER_NAV_ICON_MARKUP = Object.freeze({
    prev: '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m7 4.5 5 5-5 5" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"></path></svg>',
    next: '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m13 4.5-5 5 5 5" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"></path></svg>',
    prev10: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m6.5 6 6 6-6 6" fill="none" stroke="currentColor" stroke-width="2.15" stroke-linecap="round" stroke-linejoin="round"></path><path d="m12.5 6 6 6-6 6" fill="none" stroke="currentColor" stroke-width="2.15" stroke-linecap="round" stroke-linejoin="round"></path></svg>',
    next10: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m17.5 6-6 6 6 6" fill="none" stroke="currentColor" stroke-width="2.15" stroke-linecap="round" stroke-linejoin="round"></path><path d="m11.5 6-6 6 6 6" fill="none" stroke="currentColor" stroke-width="2.15" stroke-linecap="round" stroke-linejoin="round"></path></svg>'
  });

  function resolveDatePickerMonthCursor(sheetId, selectedValue, movementId = ''){
    const pickerState = ensureDatePickerState();
    const normalizedMovementId = String(movementId || '').trim();
    if(sheetId && pickerState.sheetId === sheetId && String(pickerState.movementId || '').trim() === normalizedMovementId){
      const activeCursor = parseDatePickerMonthCursor(pickerState.monthCursor);
      if(activeCursor) return pickerState.monthCursor;
    }
    const selectedDate = parseDatePickerIsoDate(selectedValue);
    return toDatePickerMonthCursor(selectedDate || new Date());
  }

  function resolveDatePickerView(sheetId, movementId = ''){
    const pickerState = ensureDatePickerState();
    const normalizedMovementId = String(movementId || '').trim();
    if(sheetId && pickerState.sheetId === sheetId && String(pickerState.movementId || '').trim() === normalizedMovementId){
      return normalizeDatePickerView(pickerState.view);
    }
    return 'days';
  }

  function getDatePickerDisplayParts(value){
    return typeof dateSystem.getDisplayParts === 'function'
      ? dateSystem.getDisplayParts(value)
      : Object.freeze({ day: '--', month: '--', year: '----' });
  }

  function formatDatePickerDisplay(value){
    const parts = getDatePickerDisplayParts(value);
    return `${parts.day}/${parts.month}/${parts.year}`;
  }

  function renderDatePickerTriggerValue(value){
    const parts = getDatePickerDisplayParts(value);
    return `
      <span class="entries-voucher-date__trigger-date" aria-hidden="true">
        <span class="entries-voucher-date__trigger-part entries-voucher-date__trigger-part--day">${escapeHtml(parts.day)}</span>
        <span class="entries-voucher-date__trigger-sep" aria-hidden="true">/</span>
        <span class="entries-voucher-date__trigger-part entries-voucher-date__trigger-part--month">${escapeHtml(parts.month)}</span>
        <span class="entries-voucher-date__trigger-sep" aria-hidden="true">/</span>
        <span class="entries-voucher-date__trigger-part entries-voucher-date__trigger-part--year">${escapeHtml(parts.year)}</span>
      </span>
    `;
  }

  function formatDatePickerMonthLabel(monthCursor){
    return typeof dateSystem.formatMonthLabel === 'function'
      ? dateSystem.formatMonthLabel(monthCursor, DATE_PICKER_MONTH_NAMES)
      : String(monthCursor || '').trim();
  }

  function buildDatePickerCells(monthCursor, selectedValue){
    return typeof dateSystem.buildCalendarCells === 'function' ? dateSystem.buildCalendarCells(monthCursor, selectedValue) : [];
  }

  function buildDatePickerMonthChoices(monthCursor){
    return typeof dateSystem.buildMonthChoices === 'function' ? dateSystem.buildMonthChoices(monthCursor, DATE_PICKER_MONTH_NAMES) : [];
  }

  function renderDatePickerDayButton(cell){
    const classes = [
      'entries-voucher-date__day',
      cell.outsideMonth ? 'is-outside' : '',
      cell.isToday ? 'is-today' : '',
      cell.isSelected ? 'is-selected' : ''
    ].filter(Boolean).join(' ');
    return `
      <button class="${classes}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="grid" data-entry-date-action="select-day" data-entry-date-value="${escapeHtml(cell.value)}" aria-pressed="${cell.isSelected ? 'true' : 'false'}" aria-label="اختيار التاريخ ${escapeHtml(formatDatePickerDisplay(cell.value))}">
        <span dir="ltr">${escapeHtml(cell.label)}</span>
      </button>
    `;
  }

  function renderDatePickerMonthButton(monthChoice){
    const classes = [
      'entries-voucher-date__month',
      monthChoice.isActive ? 'is-active' : ''
    ].filter(Boolean).join(' ');
    return `
      <button class="${classes}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="grid" data-entry-date-action="pick-month" data-entry-date-month="${escapeHtml(monthChoice.monthCursor)}" aria-pressed="${monthChoice.isActive ? 'true' : 'false'}" aria-label="اختيار شهر ${escapeHtml(monthChoice.label)}">
        <span>${escapeHtml(monthChoice.label)}</span>
      </button>
    `;
  }

  function renderDatePickerFieldMarkup({ sheetId = '', fieldConfig = {}, selectedValue = '', movementId = '', wrapperTag = 'div', wrapperClass = '', titleClass = '', triggerClass = '' } = {}){
    const normalizedSheetId = String(sheetId || '').trim();
    const normalizedMovementId = String(movementId || '').trim();
    const monthCursor = resolveDatePickerMonthCursor(normalizedSheetId, selectedValue, normalizedMovementId);
    const pickerState = ensureDatePickerState();
    const isOpen = !!normalizedSheetId
      && pickerState.sheetId === normalizedSheetId
      && String(pickerState.movementId || '').trim() === normalizedMovementId;
    const view = resolveDatePickerView(normalizedSheetId, normalizedMovementId);
    const isMonthYearView = view === 'month-year';
    const cells = buildDatePickerCells(monthCursor, selectedValue);
    const monthChoices = buildDatePickerMonthChoices(monthCursor);
    const todayValue = todayInputValue();
    const currentMonth = parseDatePickerMonthCursor(monthCursor) || parseDatePickerMonthCursor(toDatePickerMonthCursor(new Date()));
    const currentYearLabel = String(currentMonth?.year || new Date().getFullYear());
    const safeWrapperTag = String(wrapperTag || 'div').toLowerCase() === 'label' ? 'label' : 'div';
    const movementAttr = normalizedMovementId ? ` data-movement-id="${escapeHtml(normalizedMovementId)}"` : '';
    return `
      <${safeWrapperTag} class="${escapeHtml(wrapperClass)}">
        ${titleClass ? `<span class="${escapeHtml(titleClass)}">${escapeHtml(fieldConfig.label || '')}</span>` : ''}
        <div class="entries-voucher-date${isOpen ? ' is-open' : ''}" data-entry-date-picker="true" data-entry-sheet-id="${escapeHtml(normalizedSheetId)}"${movementAttr}>
          <input class="entries-voucher-date__native" type="hidden" value="${escapeHtml(selectedValue)}" data-field="${escapeHtml(fieldConfig.field || 'date')}"${movementAttr}>
          <button class="${escapeHtml(triggerClass)}" type="button" data-taif-picker-trigger="true" data-entry-date-action="toggle" data-entry-date-month="${escapeHtml(monthCursor)}"${movementAttr} aria-label="${escapeHtml(fieldConfig.label || '')}" aria-haspopup="dialog" aria-expanded="${isOpen ? 'true' : 'false'}">
            <span class="entries-voucher-date__trigger-value">${renderDatePickerTriggerValue(selectedValue)}</span>
            <span class="entries-voucher-date__trigger-icon" aria-hidden="true">${DATE_PICKER_ICON_MARKUP}</span>
          </button>
          ${isOpen ? `
            <div class="entries-voucher-date__popover" data-taif-dropdown-popup="true" data-taif-dropdown-layout="calendar" role="dialog" aria-label="اختيار التاريخ">
              ${isMonthYearView ? `
                <div class="entries-voucher-date__header entries-voucher-date__header--month-year">
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-entry-date-action="prev-year" data-entry-date-month="${escapeHtml(monthCursor)}" aria-label="السنة السابقة">${DATE_PICKER_CHEVRON_NEXT_MARKUP}</button>
                  <button class="entries-voucher-date__heading-trigger entries-voucher-date__heading-trigger--current" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-entry-date-action="toggle-view" data-entry-date-view="days" data-entry-date-month="${escapeHtml(monthCursor)}" aria-label="الرجوع إلى أيام الشهر">
                    <span dir="ltr">${escapeHtml(currentYearLabel)}</span>
                  </button>
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-entry-date-action="next-year" data-entry-date-month="${escapeHtml(monthCursor)}" aria-label="السنة التالية">${DATE_PICKER_CHEVRON_PREV_MARKUP}</button>
                </div>
                <div class="entries-voucher-date__month-panel">
                  <div class="entries-voucher-date__month-grid">
                    ${monthChoices.map((monthChoice) => renderDatePickerMonthButton(monthChoice)).join('')}
                  </div>
                </div>
                <div class="entries-voucher-date__footer">
                  <button class="entries-voucher-date__footer-btn" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-entry-date-action="toggle-view" data-entry-date-view="days" data-entry-date-month="${escapeHtml(monthCursor)}">رجوع للتقويم</button>
                  <button class="entries-voucher-date__footer-btn entries-voucher-date__footer-btn--ghost" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-entry-date-action="close">إغلاق</button>
                </div>
              ` : `
                <div class="entries-voucher-date__header">
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-entry-date-action="prev-month" data-entry-date-month="${escapeHtml(monthCursor)}" aria-label="الشهر السابق">${DATE_PICKER_CHEVRON_NEXT_MARKUP}</button>
                  <button class="entries-voucher-date__heading-trigger" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-entry-date-action="toggle-view" data-entry-date-view="month-year" data-entry-date-month="${escapeHtml(monthCursor)}" aria-label="تغيير الشهر أو السنة">${escapeHtml(formatDatePickerMonthLabel(monthCursor))}</button>
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-entry-date-action="next-month" data-entry-date-month="${escapeHtml(monthCursor)}" aria-label="الشهر التالي">${DATE_PICKER_CHEVRON_PREV_MARKUP}</button>
                </div>
                <div class="entries-voucher-date__weekdays" aria-hidden="true">
                  ${DATE_PICKER_WEEKDAY_LABELS.map((label) => `<span>${escapeHtml(label)}</span>`).join('')}
                </div>
                <div class="entries-voucher-date__grid">
                  ${cells.map((cell) => renderDatePickerDayButton(cell)).join('')}
                </div>
                <div class="entries-voucher-date__footer">
                  <button class="entries-voucher-date__footer-btn" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-entry-date-action="today" data-entry-date-value="${escapeHtml(todayValue)}">اليوم</button>
                  <button class="entries-voucher-date__footer-btn entries-voucher-date__footer-btn--ghost" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-entry-date-action="clear">مسح</button>
                  <button class="entries-voucher-date__footer-btn entries-voucher-date__footer-btn--ghost" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-entry-date-action="close">إغلاق</button>
                </div>
              `}
            </div>
          ` : ''}
        </div>
      </${safeWrapperTag}>
    `;
  }

  function renderVoucherDatePicker(sheet, fieldConfig, selectedValue){
    const cardClass = fieldConfig?.cardClass ? ` ${fieldConfig.cardClass}` : '';
    return renderDatePickerFieldMarkup({
      sheetId: sheet?.id || '',
      fieldConfig,
      selectedValue,
      movementId: '',
      wrapperTag: 'div',
      wrapperClass: `entries-voucher-rail__card entries-voucher-rail__card--date${cardClass}`,
      titleClass: 'entries-voucher-rail__title',
      triggerClass: 'entries-voucher-field__control entries-voucher-rail__control entries-voucher-date__trigger'
    });
  }

  function renderSettlementDatePicker(sheetId, fieldConfig, selectedValue, movementId = '', modifierClass = ''){
    const modifierSuffix = String(modifierClass || '').trim();
    const wrapperClass = [
      'entries-voucher-field',
      'entries-voucher-field--settlement-field',
      'entries-voucher-field--settlement-date',
      modifierSuffix
    ].filter(Boolean).join(' ');
    return renderDatePickerFieldMarkup({
      sheetId,
      fieldConfig,
      selectedValue,
      movementId,
      wrapperTag: 'label',
      wrapperClass,
      titleClass: 'entries-voucher-field__label',
      triggerClass: 'entries-voucher-field__control entries-voucher-date__trigger'
    });
  }

  function getVoucherTopDockFields(renderState){
    const copy = renderState?.context?.copy || {};
    const sheetType = String(renderState?.sheetType || '').trim();
    if(sheetType === 'opening'){
      return [
        Object.freeze({ kind: 'input', cardClass: 'entries-voucher-rail__card--date', label: copy.dateLabel || 'تاريخ الافتتاح', field: 'date', type: 'date' }),
        Object.freeze({ kind: 'select', cardClass: 'entries-voucher-rail__card--currency', label: 'العملة', field: 'currencyCode', optionsKey: 'currencies', optionRenderer: 'currency' })
      ];
    }

    const isJournalSheet = sheetType === 'journal';
    const fields = [
      Object.freeze({ kind: 'select', cardClass: 'entries-voucher-rail__card--currency', label: 'العملة', field: 'currencyCode', optionsKey: 'currencies', optionRenderer: 'currency' })
    ];

    if(isJournalSheet){
      fields.push(Object.freeze({ kind: 'select', cardClass: 'entries-voucher-rail__card--motion', label: copy.cashMotionLabel || 'الحركة النقدية', field: 'cashMotionPickerCode', optionsKey: 'cashMotionPickerOptions', optionRenderer: 'cashMotion' }));
    }else{
      fields.push(Object.freeze({ kind: 'select', cardClass: 'entries-voucher-rail__card--motion', label: copy.cashMotionLabel || 'الحركة', field: 'cashMotionCode', optionsKey: 'cashMotionOptions', optionRenderer: 'cashMotion' }));
    }

    fields.push(
      Object.freeze({ kind: 'select', cardClass: 'entries-voucher-rail__card--cash', label: copy.primaryAccountLabel || 'الحساب الأساسي', field: 'cashAccountNo', optionsKey: 'cashAccountOptions', optionRenderer: 'account' }),
      Object.freeze({ kind: 'input', cardClass: 'entries-voucher-rail__card--date', label: copy.dateLabel || 'تاريخ السند', field: 'date', type: 'date' })
    );

    return fields;
  }

  const MOVEMENT_ACCOUNT_PLACEHOLDER = 'اكتب اسم الحساب أو رقمه';
  const MOVEMENT_BENEFICIARY_PLACEHOLDER = 'اسم المستفيد';
  const MOVEMENT_STATEMENT_PLACEHOLDER = 'ملاحظة';

  const MOVEMENT_SHARED_FIELDS = Object.freeze([
    Object.freeze({ label: 'الحساب', field: 'counterpartAccountQuery', type: 'account-search', placeholder: MOVEMENT_ACCOUNT_PLACEHOLDER }),
    Object.freeze({ label: 'اسم المستفيد', field: 'beneficiaryName', type: 'input', placeholder: MOVEMENT_BENEFICIARY_PLACEHOLDER }),
    Object.freeze({ label: 'البيان', field: 'statement', type: 'input', placeholder: MOVEMENT_STATEMENT_PLACEHOLDER })
  ]);

  const DEFAULT_MOVEMENT_FIELDS = Object.freeze([
    Object.freeze({ label: 'المبلغ', field: 'grossAmountText', type: 'input', dir: 'rtl', inputMode: 'decimal' }),
    Object.freeze({ label: 'عمولة', field: 'commissionCode', type: 'select', optionsKey: 'commissionOptions', optionRenderer: 'commission' }),
    ...MOVEMENT_SHARED_FIELDS
  ]);

  const OPENING_MOVEMENT_FIELDS = Object.freeze([
    Object.freeze({ label: 'مدين', field: 'debitAmountText', type: 'input', dir: 'rtl', inputMode: 'decimal' }),
    Object.freeze({ label: 'دائن', field: 'creditAmountText', type: 'input', dir: 'rtl', inputMode: 'decimal' }),
    Object.freeze({ label: 'الحساب', field: 'counterpartAccountQuery', type: 'account-search', placeholder: MOVEMENT_ACCOUNT_PLACEHOLDER }),
    Object.freeze({ label: 'البيان', field: 'statement', type: 'input', placeholder: 'رصيد افتتاحي' })
  ]);

  const JOURNAL_MOVEMENT_FIELDS = Object.freeze([
    Object.freeze({ label: 'المبلغ / قبض', field: 'receiptAmountText', type: 'input', dir: 'rtl', inputMode: 'decimal' }),
    Object.freeze({ label: 'المبلغ / دفع', field: 'paymentAmountText', type: 'input', dir: 'rtl', inputMode: 'decimal' }),
    ...MOVEMENT_SHARED_FIELDS
  ]);

  const SETTLEMENT_FIELD_ACCOUNT = Object.freeze({ label: 'الحساب', field: 'counterpartAccountQuery', type: 'account-search', placeholder: MOVEMENT_ACCOUNT_PLACEHOLDER });
  const SETTLEMENT_FIELD_DATE = Object.freeze({ label: 'التاريخ', field: 'date', type: 'input', inputType: 'date', dir: 'ltr' });
  const SETTLEMENT_FIELD_CURRENCY = Object.freeze({ label: 'العملة', field: 'currencyCode', type: 'select', optionsKey: 'currencies', optionRenderer: 'currency' });
  const SETTLEMENT_FIELD_AMOUNT = Object.freeze({ label: 'المبلغ', field: 'grossAmountText', type: 'input', dir: 'rtl', inputMode: 'decimal' });
  const SETTLEMENT_FIELD_COMMISSION = Object.freeze({ label: 'العمولة', field: 'commissionCode', type: 'select', optionsKey: 'commissionOptions', optionRenderer: 'commission' });
  const SETTLEMENT_FIELD_COMMISSION_FEE = Object.freeze({ label: 'أجور العمولة', field: 'commissionFeeText', type: 'input', dir: 'rtl', inputMode: 'decimal' });
  const SETTLEMENT_FIELD_BENEFICIARY = Object.freeze({ label: 'اسم المستفيد', field: 'beneficiaryName', type: 'input', placeholder: MOVEMENT_BENEFICIARY_PLACEHOLDER });
  const SETTLEMENT_FIELD_STATEMENT = Object.freeze({ label: 'البيان', field: 'statement', type: 'input', placeholder: 'البيان' });
  const SETTLEMENT_FIELD_SUMMARY = Object.freeze({ label: 'الملخص', field: 'summary', type: 'textarea', placeholder: 'الملخص', rows: 3, wide: true });

  const SETTLEMENT_DEBIT_BOX_ROWS = Object.freeze([
    Object.freeze([SETTLEMENT_FIELD_ACCOUNT, SETTLEMENT_FIELD_DATE]),
    Object.freeze([SETTLEMENT_FIELD_CURRENCY, SETTLEMENT_FIELD_AMOUNT]),
    Object.freeze([SETTLEMENT_FIELD_COMMISSION, SETTLEMENT_FIELD_COMMISSION_FEE]),
    Object.freeze([SETTLEMENT_FIELD_BENEFICIARY, SETTLEMENT_FIELD_STATEMENT])
  ]);

  const SETTLEMENT_CREDIT_BOX_ROWS = Object.freeze([
    Object.freeze([SETTLEMENT_FIELD_ACCOUNT, SETTLEMENT_FIELD_DATE]),
    Object.freeze([SETTLEMENT_FIELD_COMMISSION, SETTLEMENT_FIELD_COMMISSION_FEE]),
    Object.freeze([SETTLEMENT_FIELD_BENEFICIARY, SETTLEMENT_FIELD_STATEMENT]),
    Object.freeze([SETTLEMENT_FIELD_SUMMARY])
  ]);

  function getMovementFields(renderState){
    const sheetType = String(renderState?.sheetType || '').trim();
    if(sheetType === 'journal') return JOURNAL_MOVEMENT_FIELDS;
    if(sheetType === 'opening') return OPENING_MOVEMENT_FIELDS;
    return DEFAULT_MOVEMENT_FIELDS;
  }

  const MOVEMENT_ACTION_ICON_MARKUP = Object.freeze({
    append: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 7v10M7 12h10" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"></path></svg>',
    remove: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M7 12h10" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"></path></svg>'
  });

  function statusLabel(status){
    if(status === 'reversed') return 'ملغى / معكوس';
    return status === 'posted' ? 'معتمد' : 'مسودة';
  }

  function badgeForType(type){
    const meta = VOUCHERS[type] || VOUCHERS.journal;
    return `<span class="entries-badge ${escapeHtml(meta.badgeClass)}">${wrapControlTextMarkup(escapeHtml(meta.label))}</span>`;
  }

  function renderToolbarActionButton(type, label, className = ''){
    return `
      <button class="entries-toolbar-btn${className ? ` ${className}` : ''}" type="button" data-entry-action="open-form" data-entry-type="${escapeHtml(type)}">
        <span class="entries-toolbar-btn__icon" aria-hidden="true">${ACTION_ICON_MARKUP[type] || ''}</span>
        <span class="entries-toolbar-btn__text taif-control-text">${escapeHtml(label)}</span>
      </button>
    `;
  }


  function renderToolbar({ draftCount = 0, postedCount = 0, totalCount = 0, hasSelection = false } = {}){
    return `
      <div class="entries-toolbar" aria-label="شريط أدوات القيود والسندات">
        <div class="entries-toolbar__search">
          <div class="entries-search">
            <input class="entries-search__input" type="text" value="${escapeHtml(runtime.filter)}" placeholder="ابحث برقم العملية أو الحساب أو الاسم أو الملاحظات" data-entry-action="search" autocomplete="off" spellcheck="false">
            <button class="entries-search__clear" type="button" data-entry-action="clear-search" data-taif-clear-control="true" aria-label="مسح البحث">${getWindowChromeIcon('close')}</button>
          </div>
        </div>
        <div class="entries-toolbar__group" role="toolbar" aria-label="أدوات القيود والسندات">
          <div class="entries-toolbar__actions">
            ${renderToolbarActionButton('settlement', 'سند تسوية', 'entries-toolbar-btn--journal')}
            ${renderToolbarActionButton('receipt', 'سند قبض', 'entries-toolbar-btn--success')}
            ${renderToolbarActionButton('payment', 'سند دفع', 'entries-toolbar-btn--danger')}
            ${renderToolbarActionButton('journal', 'سند يومي', 'entries-toolbar-btn--primary')}
            ${renderToolbarActionButton('opening', 'سند قيد افتتاحي', 'entries-toolbar-btn--violet')}
            ${renderToolbarCommandButton('delete-selected-record', 'حذف', 'entries-toolbar-btn--danger entries-toolbar-btn--delete', TOOLBAR_COMMAND_ICON_MARKUP.delete, { disabled: !hasSelection, title: hasSelection ? 'حذف السند المحدد نهائياً' : 'حدد سنداً أولاً' })}
          </div>
          <div class="entries-toolbar__stats" aria-label="ملخص السجلات">
            ${renderToolbarChip('draft', 'المسودات', draftCount)}
            ${renderToolbarChip('posted', 'المعتمد', postedCount)}
            ${renderToolbarChip('total', 'الإجمالي', totalCount)}
          </div>
        </div>
      </div>
    `;
  }

  const RECORD_COLUMNS = Object.freeze([
    Object.freeze({ key: 'notice', label: 'رقم العملية', className: 'entries-records__col--notice' }),
    Object.freeze({ key: 'date', label: 'التاريخ', className: 'entries-records__col--date' }),
    Object.freeze({ key: 'incoming', label: 'لنا / محصلة', className: 'entries-records__col--incoming' }),
    Object.freeze({ key: 'from', label: 'من الحساب', className: 'entries-records__col--from' }),
    Object.freeze({ key: 'beneficiary', label: 'اسم المستفيد', className: 'entries-records__col--beneficiary' }),
    Object.freeze({ key: 'outgoing', label: 'علينا', className: 'entries-records__col--outgoing' }),
    Object.freeze({ key: 'to', label: 'إلى حساب', className: 'entries-records__col--to' }),
    Object.freeze({ key: 'notes', label: 'ملاحظات', className: 'entries-records__col--notes' }),
    Object.freeze({ key: 'typeStatus', label: 'النوع / الحالة', className: 'entries-records__col--type-status' })
  ]);

  function renderRecordCell({ className = '', valueMarkup }){
    return `<div class="entries-record-cell${className ? ` ${className}` : ''}">${valueMarkup}</div>`;
  }

  function renderRecordTextValue(text, { mono = false, center = false, clamp = false } = {}){
    const safeText = String(text || '').trim();
    const classes = [
      'entries-record-cell__value',
      mono ? 'entries-record-cell__value--mono' : '',
      center ? 'entries-record-cell__value--center' : '',
      clamp ? 'entries-record-cell__value--clamp' : '',
      safeText ? '' : 'entries-record-cell__value--empty'
    ].filter(Boolean).join(' ');
    return `<div class="${classes}">${escapeHtml(safeText || '—')}</div>`;
  }

  function renderRecordAccountValue(account, { center = false } = {}){
    const accountName = String(account?.accountName || '').trim();
    const accountNo = String(account?.accountNo || '').trim();
    if(!accountName && !accountNo){
      return renderRecordTextValue('—', { center });
    }
    return `
      <div class="entries-record-cell__stack${center ? ' entries-record-cell__stack--center' : ''}">
        <div class="entries-record-cell__value entries-record-cell__value--clamp">${escapeHtml(accountName || accountNo)}</div>
        ${accountNo ? `<div class="entries-record-cell__meta entries-record-cell__meta--mono" dir="ltr">${escapeHtml(accountNo)}</div>` : ''}
      </div>
    `;
  }

  function renderRecordAmountValue(amount, currency, modifier = ''){
    if(!(Number(amount) > 0)) return renderRecordTextValue('—', { center: true });
    return `<div class="entries-record-cell__value entries-record-cell__value--amount entries-record-cell__value--center${modifier ? ` ${modifier}` : ''}" dir="ltr">${money(amount, 2)} ${escapeHtml(currency || 'USD')}</div>`;
  }

  function renderRecordTypeStatusValue(record, view){
    const safeView = view && typeof view === 'object' ? view : {};
    const safeRecord = record && typeof record === 'object' ? record : {};
    const isSalesPurchaseLinked = !!String(safeRecord.sourceSalesPurchaseRecordId || safeRecord.sourceSalesPurchaseNumber || '').trim();
    return `
      <div class="entries-record-cell__badges">
        ${badgeForType(safeView.type)}
        <span class="entries-badge entries-badge--${safeRecord.status === 'reversed' ? 'reversed' : (safeRecord.status === 'posted' ? 'posted' : 'draft')}">
          ${wrapControlTextMarkup(escapeHtml(statusLabel(safeRecord.status)))}
        </span>
        ${isSalesPurchaseLinked ? '<span class="entries-badge entries-badge--info">مرتبط بالصرف</span>' : ''}
      </div>
    `;
  }

  function renderRecordSelectionDot(isSelected = false){
    return `
      <span class="entries-record-row__state-slot" aria-hidden="true">
        <span class="entries-record-row__state-dot${isSelected ? ' is-active' : ''}"></span>
      </span>
    `;
  }

  function renderRecordNotesValue(view){
    const primary = String(view?.notes?.primary || '').trim();
    const secondary = String(view?.notes?.secondary || '').trim();
    return `
      <div class="entries-record-cell__stack entries-record-cell__stack--notes">
        ${renderRecordTextValue(primary || '—', { clamp: true })}
        ${secondary ? `<div class="entries-record-cell__meta entries-record-cell__meta--clamp">${escapeHtml(secondary)}</div>` : ''}
      </div>
    `;
  }

  function renderRecordsHead(){
    return `
      <div class="entries-records__grid entries-records__head entries-records__head--split-scroll" role="row">
        ${RECORD_COLUMNS.map((column) => `
          <div class="entries-records__head-cell ${escapeHtml(column.className)}" role="columnheader">${escapeHtml(column.label)}</div>
        `).join('')}
      </div>
    `;
  }

  function renderRecordRow(record){
    const view = buildRecordPresentation(record);
    const recordId = String(record?.id || '').trim();
    const isSelected = !!recordId && recordId === String(runtime.selectedRecordId || '').trim();
    return `
      <article class="entries-record-row${isSelected ? ' entries-record-row--selected' : ''}" role="row" data-entry-record-id="${escapeHtml(recordId)}" aria-selected="${isSelected ? 'true' : 'false'}">
        <div class="entries-records__grid entries-record-row__grid">
          ${renderRecordSelectionDot(isSelected)}
          ${renderRecordCell({ className: 'entries-records__col--notice', valueMarkup: renderRecordTextValue(view.noticeNo || '—', { mono: true, center: true }) })}
          ${renderRecordCell({ className: 'entries-records__col--date', valueMarkup: renderRecordTextValue(formatDate(view.date), { center: true }) })}
          ${renderRecordCell({ className: 'entries-records__col--incoming', valueMarkup: renderRecordAmountValue(view.collectedAmount, view.currency, 'entries-record-cell__value--positive') })}
          ${renderRecordCell({ className: 'entries-records__col--from', valueMarkup: renderRecordAccountValue(view.fromAccount) })}
          ${renderRecordCell({ className: 'entries-records__col--beneficiary', valueMarkup: renderRecordTextValue(view.beneficiaryName || '—', { center: true, clamp: true }) })}
          ${renderRecordCell({ className: 'entries-records__col--outgoing', valueMarkup: renderRecordAmountValue(view.owedAmount, view.currency, 'entries-record-cell__value--negative') })}
          ${renderRecordCell({ className: 'entries-records__col--to', valueMarkup: renderRecordAccountValue(view.toAccount) })}
          ${renderRecordCell({ className: 'entries-records__col--notes', valueMarkup: renderRecordNotesValue(view) })}
          ${renderRecordCell({ className: 'entries-records__col--type-status', valueMarkup: renderRecordTypeStatusValue(record, view) })}
        </div>
      </article>
    `;
  }

  function updateDeleteActionButtonUi(panel = runtime.panel){
    if(!(panel instanceof Element)) return;
    const deleteButton = panel.querySelector('[data-entry-action="delete-selected-record"]');
    if(!(deleteButton instanceof HTMLButtonElement)) return;
    const selectedRecordId = String(runtime.selectedRecordId || '').trim();
    const selectedRecord = selectedRecordId ? findRecordById(selectedRecordId) : null;
    const lockedForMutation = !!selectedRecord && isVoucherRecordLockedForMutation(selectedRecord);
    const hasSelection = !!selectedRecordId && !lockedForMutation;
    deleteButton.disabled = !hasSelection;
    deleteButton.setAttribute('aria-disabled', hasSelection ? 'false' : 'true');
    const title = !selectedRecordId
      ? 'حدد سنداً أولاً'
      : (lockedForMutation
          ? 'هذا القيد مرتبط بفاتورة شراء/مبيع، ويتم حذفه من نافذة الشراء/المبيع فقط'
          : 'حذف السند المحدد نهائياً');
    deleteButton.setAttribute('title', title);
    deleteButton.setAttribute('aria-label', title);
  }

  function createVoucherDeleteQuestionOptions(scope){
    const safeScope = scope && typeof scope === 'object' ? scope : {};
    const record = safeScope.record && typeof safeScope.record === 'object' ? safeScope.record : null;
    const view = record ? buildRecordPresentation(record) : {};
    const typeMeta = VOUCHERS[safeScope.type] || VOUCHERS[record?.type] || VOUCHERS.journal;
    const number = String(safeScope.number || record?.number || '—').trim() || '—';
    const typeLabel = String(typeMeta?.label || record?.type || 'سند').trim() || 'سند';
    const impactedCount = Math.max(1, Number(safeScope.count) || 1);
    const affectedText = impactedCount > 1
      ? `سيتم حذف هذا السند نهائياً مع ${impactedCount} بطاقات مرتبطة به من السجل الحالي.`
      : 'سيتم حذف هذا السند نهائياً من السجل الحالي.';
    const accountName = String(view?.fromAccount?.accountName || record?.cashAccountName || record?.counterpartAccountName || '').trim();
    const dateText = formatDate(record?.date || '—');
    const warningParts = [
      'هل أنت متأكد من حذف هذا السند؟',
      affectedText,
      'سيتم حذف تأثيراته من السجل، والتحديث سيصل تلقائياً إلى أي جزء يعتمد عليه داخل المرجع الحالي.'
    ];

    return {
      owner:'entries-vouchers',
      title:'حذف سند نهائي',
      confirmLabel:'حذف نهائي',
      confirmTone:'danger',
      confirmIcon:'trash',
      cardHtml:`
        <div class="taif-question-card taif-question-card--stacked taif-question-card--voucher" aria-hidden="true">
          <div class="taif-question-card__row">
            <span class="taif-question-card__badge">${escapeHtml(typeLabel)}</span>
            <span class="taif-question-card__badge taif-question-card__badge--mono" dir="ltr">${escapeHtml(number)}</span>
          </div>
          <div class="taif-question-card__meta">
            <span>التاريخ: ${escapeHtml(dateText)}</span>
            ${accountName ? `<span>${escapeHtml(accountName)}</span>` : ''}
          </div>
        </div>
      `,
      warning:warningParts.join(' ')
    };
  }

  function renderVoucherDeleteConfirmMarkup(scope){
    const options = createVoucherDeleteQuestionOptions(scope);
    return `
      ${options.cardHtml || ''}
      ${options.warning ? `<div class="taif-question-dialog__warning">${escapeHtml(options.warning)}</div>` : ''}
    `;
  }

  function updateRecordSelectionUi(panel = runtime.panel){
    if(!(panel instanceof Element)) return;
    const selectedRecordId = String(runtime.selectedRecordId || '').trim();
    panel.querySelectorAll('.entries-record-row[data-entry-record-id]').forEach((row) => {
      const rowId = String(row.getAttribute('data-entry-record-id') || '').trim();
      const isSelected = !!selectedRecordId && rowId === selectedRecordId;
      row.classList.toggle('entries-record-row--selected', isSelected);
      row.setAttribute('aria-selected', isSelected ? 'true' : 'false');
      row.querySelector('.entries-record-row__state-dot')?.classList.toggle('is-active', isSelected);
    });
    updateDeleteActionButtonUi(panel);
  }

  function renderRecordsTable(records){
    if(!records.length){
      return `
        <div class="entries-empty">
          <div class="entries-empty__box">
            <div class="entries-empty__title">سجلات القيود والسندات</div>
            <div class="entries-empty__text">ابدأ بإنشاء سند جديد من الشريط العلوي ليظهر هنا مباشرة ضمن السجل الموحد للقيود والسندات.</div>
          </div>
        </div>
      `;
    }

    return `
      <div class="entries-log__records entries-log__records--split-scroll" aria-label="سجل القيود والسندات">
        <div class="entries-records__viewport entries-records__viewport--split-scroll">
          ${renderRecordsHead()}
          <div class="entries-records__scroller entries-records__scroller--split-scroll">
            <div class="entries-records__body">
              ${records.map((record) => renderRecordRow(record)).join('')}
            </div>
          </div>
        </div>
      </div>
    `;
  }

  function renderMainArea(records){
    return `
      <section class="entries-log" aria-label="سجل القيود والسندات">
        ${renderRecordsTable(records)}
      </section>
    `;
  }

  function renderSheetFooter(sheet){
    const disabled = !sheet || !isInteractiveVoucherType(sheet.type);
    return `
      <div class="entries-actions entries-actions--shell" data-taif-footer-actions="true" aria-label="إجراءات السند">
        <div class="entries-actions__group entries-actions__group--primary-actions" data-taif-footer-group="true">
          <button class="entries-action-btn entries-action-btn--danger" type="button" data-entry-action="close-sheet" data-taif-action-role="cancel" data-taif-action-tone="danger"><span class="taif-control-text">إلغاء</span></button>
          <button class="entries-action-btn entries-action-btn--primary" type="button" data-entry-shell-action="archive" data-taif-action-role="commit" data-taif-action-tone="primary"${disabled ? ' disabled' : ''}><span class="taif-control-text">أرشفة</span></button>
          <button class="entries-action-btn entries-action-btn--success" type="button" data-entry-shell-action="add" data-taif-action-role="commit" data-taif-action-tone="success"${disabled ? ' disabled' : ''}><span class="taif-control-text">إضافة</span></button>
        </div>
      </div>
    `;
  }

  const VOUCHER_PICKER_ICON_MARKUP = Object.freeze({
    chevronDown: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>',
    check: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m5 13 4 4L19 7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>'
  });

  function createVoucherPickerIcon(type){
    return VOUCHER_PICKER_ICON_MARKUP[type] || '';
  }

  function resolveVoucherCurrencyFlagAsset(option){
    const flags = TAIF && TAIF.assets && TAIF.assets.flags;
    if(!flags || typeof flags.resolveFlagAsset !== 'function') return null;
    const flagValue = String(option?.flag || '').trim().toLowerCase();
    const currencyCode = String(option?.code || option?.value || '').trim().toUpperCase();
    const asset = flags.resolveFlagAsset(flagValue || currencyCode, 'circle');
    return asset && asset.src ? asset : null;
  }

  function renderVoucherCurrencyFlagMarkup(option){
    const asset = resolveVoucherCurrencyFlagAsset(option);
    if(!asset || !asset.src) return '';
    return `
      <span class="entries-voucher-choice-picker__flag" aria-hidden="true">
        <img class="entries-voucher-choice-picker__flag-image" src="${escapeHtml(asset.src)}" alt="" draggable="false" loading="eager" decoding="async" width="512" height="512">
      </span>
    `;
  }

  function normalizeChoicePickerOption(option, rendererKey = 'account'){
    if(!option || typeof option !== 'object') return null;

    if(rendererKey === 'account'){
      const value = String(option.accountNo || '').trim();
      const label = String(option.name || value).trim();
      if(!value && !label) return null;
      return {
        value,
        label,
        meta: value,
        ariaLabel: value ? `${label} ${value}` : label
      };
    }

    if(rendererKey === 'currency'){
      const value = String(option.code || '').trim();
      const label = String(option.name || value).trim();
      if(!value && !label) return null;
      return {
        value,
        label,
        meta: value,
        code: value,
        flag: String(option.flag || '').trim().toLowerCase(),
        visualKind: 'currency-flag',
        ariaLabel: value ? `${label} ${value}` : label
      };
    }

    const value = String(option.value || '').trim();
    const label = String(option.label || value).trim();
    if(!value && !label) return null;
    return {
      value,
      label,
      meta: '',
      ariaLabel: label || value
    };
  }

  function normalizeChoicePickerOptions(options, rendererKey = 'account'){
    return (Array.isArray(options) ? options : [])
      .map((option) => normalizeChoicePickerOption(option, rendererKey))
      .filter(Boolean);
  }

  function resolveChoicePickerData(options, selectedValue, rendererKey = 'account'){
    const normalizedOptions = normalizeChoicePickerOptions(options, rendererKey);
    const activeOption = normalizedOptions.find((option) => option.value === selectedValue) || normalizedOptions[0] || null;
    return {
      options: normalizedOptions,
      activeOption,
      resolvedValue: activeOption ? activeOption.value : ''
    };
  }

  function isChoicePickerOpen(sheetId, field, movementId = ''){
    const state = runtime.choicePicker && typeof runtime.choicePicker === 'object' ? runtime.choicePicker : null;
    return !!state
      && String(state.sheetId || '').trim() === String(sheetId || '').trim()
      && String(state.field || '').trim() === String(field || '').trim()
      && String(state.movementId || '').trim() === String(movementId || '').trim();
  }

  function renderChoicePickerValueMarkup(option, { placeholder = '' } = {}){
    if(!option){
      return `<span class="entries-voucher-choice-picker__placeholder">${escapeHtml(placeholder || '')}</span>`;
    }

    if(option.visualKind === 'currency-flag'){
      const flagMarkup = renderVoucherCurrencyFlagMarkup(option);
      return `
        <span class="entries-voucher-choice-picker__value-layout entries-voucher-choice-picker__value-layout--currency${flagMarkup ? ' entries-voucher-choice-picker__value-layout--with-flag' : ''}">
          ${flagMarkup}
          <span class="entries-voucher-choice-picker__text">${escapeHtml(option.label)}</span>
        </span>
      `;
    }

    if(option.meta){
      return `
        <span class="entries-voucher-choice-picker__value-layout">
          <span class="entries-voucher-choice-picker__text">${escapeHtml(option.label)}</span>
          <span class="entries-voucher-choice-picker__meta" dir="ltr">${escapeHtml(option.meta)}</span>
        </span>
      `;
    }

    return `<span class="entries-voucher-choice-picker__text">${escapeHtml(option.label)}</span>`;
  }

  function renderChoicePickerMarkup({ sheetId, label, field, options, selectedValue, rendererKey = 'account', placeholder = '', movementId = '', controlClass = '' }){
    const pickerData = resolveChoicePickerData(options, selectedValue, rendererKey);
    const { options: choiceOptions, activeOption, resolvedValue } = pickerData;
    const isOpen = isChoicePickerOpen(sheetId, field, movementId);
    const movementAttr = movementId ? ` data-movement-id="${escapeHtml(movementId)}"` : '';
    const listboxId = `entries-voucher-choice-${escapeHtml(String(sheetId || 'sheet'))}-${escapeHtml(String(field || 'field'))}${movementId ? `-${escapeHtml(String(movementId))}` : ''}`;
    const triggerClass = controlClass ? ` ${controlClass}` : '';
    const triggerValueClass = activeOption ? 'entries-voucher-choice-picker__value' : 'entries-voucher-choice-picker__value is-placeholder';
    const listContent = choiceOptions.length
      ? choiceOptions.map((option) => {
          const isActive = option.value === resolvedValue;
          return `
            <button class="entries-voucher-choice-popover__option${isActive ? ' is-active' : ''}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-taif-inline-picker-option="true" role="option" data-entry-choice-action="select" data-entry-choice-value="${escapeHtml(option.value)}" data-entry-choice-field="${escapeHtml(field)}"${movementAttr} aria-selected="${isActive ? 'true' : 'false'}" aria-label="اختيار ${escapeHtml(option.ariaLabel || option.label || '')}">
              <span class="entries-voucher-choice-popover__label${option.meta ? ' has-meta' : ''}" data-taif-dropdown-label="true">${renderChoicePickerValueMarkup(option)}</span>
            </button>
          `;
        }).join('')
      : '<div class="entries-voucher-choice-popover__empty">لا يوجد عناصر متاحة.</div>';

    return `
      <div class="entries-voucher-choice-picker${isOpen ? ' is-open' : ''}" data-entry-choice-picker="true" data-taif-inline-picker-host="true">
        <input class="entries-voucher-choice-picker__value-input" type="hidden" value="${escapeHtml(resolvedValue)}">
        <button class="entries-voucher-field__control entries-voucher-choice-picker__trigger${triggerClass}" type="button" data-taif-picker-trigger="true" data-entry-choice-trigger="true" data-entry-choice-action="toggle" data-field="${escapeHtml(field)}"${movementAttr} aria-label="${escapeHtml(label)}" aria-haspopup="listbox" aria-controls="${escapeHtml(listboxId)}" aria-expanded="${isOpen ? 'true' : 'false'}">
          <span class="${triggerValueClass}">${renderChoicePickerValueMarkup(activeOption, { placeholder })}</span>
          <span class="entries-voucher-choice-picker__icon" aria-hidden="true">${createVoucherPickerIcon('chevronDown')}</span>
        </button>
        <div class="entries-voucher-choice-popover" data-taif-dropdown-popup="true" data-taif-dropdown-layout="list" data-taif-inline-picker="true" id="${escapeHtml(listboxId)}" role="listbox" aria-label="${escapeHtml(label)}"${isOpen ? '' : ' hidden'}>${listContent}</div>
      </div>
    `;
  }

  function resolveMovementFieldValue(fieldConfig, movementContext){
    return movementContext?.draft?.[fieldConfig.field] || '';
  }

  function isolateAmountFieldLtrToken(value){
    const text = String(value || '').trim();
    return text ? `⁦${text}⁩` : '';
  }

  function resolveAmountFieldCurrencyCode(renderState, movementContext){
    const currencyCode = String(
      movementContext?.draft?.currencyCode
      || renderState?.context?.currency?.code
      || renderState?.context?.draft?.currencyCode
      || ''
    ).trim().toUpperCase();
    return currencyCode || 'USD';
  }

  function formatAmountFieldPlaceholder(basePlaceholder, currencyCode){
    const safeCurrencyCode = String(currencyCode || '').trim().toUpperCase() || 'USD';
    const normalizedPlaceholder = String(basePlaceholder || '').trim();
    const placeholderMatch = normalizedPlaceholder.match(/^(.+?)\s+([0-9][0-9.,]*)$/u);
    const actionLabel = String(placeholderMatch ? placeholderMatch[1] : normalizedPlaceholder).trim();
    const amountText = String(placeholderMatch ? placeholderMatch[2] : '0.00').trim() || '0.00';
    return [
      isolateAmountFieldLtrToken(safeCurrencyCode),
      isolateAmountFieldLtrToken(amountText),
      actionLabel
    ].filter(Boolean).join(' ');
  }

  function resolveMovementFieldPlaceholder(fieldConfig, movementContext, renderState){
    if(fieldConfig.field === 'grossAmountText'){
      const currencyCode = resolveAmountFieldCurrencyCode(renderState, movementContext);
      const amountPlaceholder = String(renderState?.context?.copy?.amountPlaceholder || '').trim();
      if(amountPlaceholder) return formatAmountFieldPlaceholder(amountPlaceholder, currencyCode);
      const sheetType = String(renderState?.sheetType || '').trim();
      if(sheetType === 'receipt') return formatAmountFieldPlaceholder('قبض 0.00', currencyCode);
      if(sheetType === 'payment') return formatAmountFieldPlaceholder('دفع 0.00', currencyCode);
      return formatAmountFieldPlaceholder('0.00', currencyCode);
    }
    if(fieldConfig.field === 'debitAmountText'){
      return formatAmountFieldPlaceholder('مدين 0.00', resolveAmountFieldCurrencyCode(renderState, movementContext));
    }
    if(fieldConfig.field === 'creditAmountText'){
      return formatAmountFieldPlaceholder('دائن 0.00', resolveAmountFieldCurrencyCode(renderState, movementContext));
    }
    if(fieldConfig.field === 'receiptAmountText'){
      return formatAmountFieldPlaceholder('قبض 0.00', resolveAmountFieldCurrencyCode(renderState, movementContext));
    }
    if(fieldConfig.field === 'paymentAmountText'){
      return formatAmountFieldPlaceholder('دفع 0.00', resolveAmountFieldCurrencyCode(renderState, movementContext));
    }
    return fieldConfig.placeholder || '';
  }

  function renderSelectField({ sheetId = '', label, field, options, selectedValue, rendererKey = 'account', placeholder = '', hideLabel = false, wrapperClass = '', controlClass = '', movementId = '' }){
    const fieldClass = wrapperClass ? ` entries-voucher-field--${wrapperClass}` : '';
    return `
      <label class="entries-voucher-field${fieldClass} entries-voucher-field--choice">
        ${hideLabel ? '' : `<span class="entries-voucher-field__label">${escapeHtml(label)}</span>`}
        ${renderChoicePickerMarkup({ sheetId, label, field, options, selectedValue, rendererKey, placeholder, movementId, controlClass })}
      </label>
    `;
  }

  function renderInputField({ label, field, value, type = 'text', placeholder = '', dir = '', inputMode = '', hideLabel = false, wrapperClass = '', controlClass = '', movementId = '', rows = 3 }){
    const fieldClass = wrapperClass ? ` entries-voucher-field--${wrapperClass}` : '';
    const inputClass = controlClass ? ` ${controlClass}` : '';
    const movementAttr = movementId ? ` data-movement-id="${escapeHtml(movementId)}"` : '';
    const normalizedControlType = String(type || 'text').trim().toLowerCase();
    const normalizedInputType = normalizedControlType === 'input' ? 'text' : (normalizedControlType || 'text');
    const commonAttrs = `${placeholder ? `placeholder="${escapeHtml(placeholder)}"` : ''} ${dir ? `dir="${escapeHtml(dir)}"` : ''} ${inputMode ? `inputmode="${escapeHtml(inputMode)}"` : ''} data-field="${escapeHtml(field)}"${movementAttr} aria-label="${escapeHtml(label)}" autocomplete="off" spellcheck="false"`;
    const controlMarkup = normalizedControlType === 'textarea'
      ? `<textarea class="entries-voucher-field__control${inputClass}" rows="${escapeHtml(String(Math.max(2, Number(rows) || 3)))}" ${commonAttrs}>${escapeHtml(value)}</textarea>`
      : `<input class="entries-voucher-field__control${inputClass}" type="${escapeHtml(normalizedInputType)}" value="${escapeHtml(value)}" ${commonAttrs}>`;
    return `
      <label class="entries-voucher-field${fieldClass}">
        ${hideLabel ? '' : `<span class="entries-voucher-field__label">${escapeHtml(label)}</span>`}
        ${controlMarkup}
      </label>
    `;
  }


  function renderAccountSearchOption(option, movementId){
    if(!option) return '';
    const accountLabel = `${option.accountNo} — ${option.name}`;
    return `
      <button class="entries-account-search__result" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" role="option" data-entry-account-option="select" data-movement-id="${escapeHtml(movementId)}" data-entry-account-no="${escapeHtml(option.accountNo)}" data-entry-account-label="${escapeHtml(accountLabel)}" aria-label="اختيار الحساب ${escapeHtml(accountLabel)}">
        <span class="entries-account-search__result-copy">
          <span class="entries-account-search__result-name" data-taif-dropdown-label="true">${escapeHtml(option.name)}</span>
          <span class="entries-account-search__result-no" dir="ltr">${escapeHtml(option.accountNo)}</span>
        </span>
      </button>
    `;
  }

  function renderAccountSearchField({ label, movementContext, movementId = '', hideLabel = false, wrapperClass = '', sheetId = '' }){
    const fieldClass = wrapperClass ? ` entries-voucher-field--${wrapperClass}` : '';
    const queryValue = movementContext?.counterpartAccountQuery || '';
    const selectedAccountNo = movementContext?.counterpartAccount?.accountNo || '';
    const selectedAccountLabel = movementContext?.counterpartAccountLookupLabel || '';
    const searchResults = Array.isArray(movementContext?.counterpartAccountSearchResults) ? movementContext.counterpartAccountSearchResults : [];
    const isSearchActive = !!(runtime.accountSearch && runtime.accountSearch.sheetId === sheetId && runtime.accountSearch.movementId === movementId);
    const shouldShowList = !!queryValue && isSearchActive && !movementContext?.counterpartAccountSearchSettled;
    const listId = movementId ? `entries-account-search-list-${movementId}` : '';
    const listContent = searchResults.length
      ? searchResults.map((option) => renderAccountSearchOption(option, movementId)).join('')
      : '<div class="entries-account-search__empty">لا يوجد حساب مطابق لما كتبته.</div>';

    return `
      <label class="entries-voucher-field${fieldClass} entries-voucher-field--account-search">
        ${hideLabel ? '' : `<span class="entries-voucher-field__label">${escapeHtml(label)}</span>`}
        <div class="entries-account-search${shouldShowList ? ' is-open' : ''}" data-entry-account-search-root="true">
          <input class="entries-voucher-field__control entries-voucher-field__control--account-search" type="text" value="${escapeHtml(queryValue)}" ${listId ? `aria-controls="${escapeHtml(listId)}"` : ''} aria-expanded="${shouldShowList ? 'true' : 'false'}" aria-autocomplete="list" role="combobox" placeholder="اكتب اسم الحساب أو رقمه" data-field="counterpartAccountQuery" data-movement-id="${escapeHtml(movementId)}" data-selected-account-no="${escapeHtml(selectedAccountNo)}" data-selected-account-label="${escapeHtml(selectedAccountLabel)}" aria-label="${escapeHtml(label)}" autocomplete="off" spellcheck="false">
          <div class="entries-account-search__popover" data-taif-dropdown-popup="true" data-taif-dropdown-layout="list" id="${escapeHtml(listId)}" role="listbox" aria-label="اقتراحات الحسابات"${shouldShowList ? '' : ' hidden'}>${shouldShowList ? listContent : ''}</div>
        </div>
      </label>
    `;
  }

  function renderVoucherAlert(issues){
    if(!Array.isArray(issues) || !issues.length) return '';
    return `
      <div class="entries-voucher-alert" role="alert" aria-live="polite">
        <div class="entries-voucher-alert__title">يوجد ما يحتاج مراجعة قبل اعتماد السند</div>
        <ul class="entries-voucher-alert__list">
          ${issues.map((issue) => `<li>${escapeHtml(issue)}</li>`).join('')}
        </ul>
      </div>
    `;
  }

  function buildVoucherRenderState(sheet){
    const preferredVisibleCount = Number(sheet?.ui?.journalVisibleCount) || 0;
    const context = buildVoucherRenderContext(sheet.type, sheet.draft || {}, {
      visibleCount: preferredVisibleCount
    });
    if(sheet && sheet.type === 'journal'){
      sheet.ui = sheet.ui && typeof sheet.ui === 'object' ? sheet.ui : {};
      sheet.ui.journalVisibleCount = Math.max(Number(sheet.ui.journalVisibleCount) || 0, Number(context?.journalRenderedCount) || 0);
    }
    return {
      sheetType: sheet.type,
      context,
      validationIssues: Array.isArray(sheet.validationIssues) && sheet.validationIssues.length ? sheet.validationIssues : []
    };
  }


  function getVoucherNavigatorRenderState(sheet){
    const groups = sheet ? getVoucherRecordGroups(sheet.type) : [];
    const navigator = sheet && sheet.navigator && typeof sheet.navigator === 'object' ? sheet.navigator : {};
    const currentIndex = Number.isInteger(navigator.currentGroupIndex) ? navigator.currentGroupIndex : null;
    return {
      groups,
      count: groups.length,
      lookupValue: String(navigator.lookupValue || ''),
      canPrev: !!groups.length && currentIndex !== 0,
      canNext: !!groups.length && currentIndex !== null,
      currentIndex
    };
  }


  function renderVoucherTopDockField(sheet, fieldConfig, renderState){
    const { context } = renderState;
    const cardClass = fieldConfig.cardClass ? ` ${fieldConfig.cardClass}` : '';
    const selectedValue = context.draft[fieldConfig.field] || '';
    if(fieldConfig.kind === 'select'){
      const options = context[fieldConfig.optionsKey];
      return `
        <label class="entries-voucher-rail__card${cardClass} entries-voucher-rail__card--choice">
          <span class="entries-voucher-rail__title">${escapeHtml(fieldConfig.label)}</span>
          ${renderChoicePickerMarkup({
            sheetId: sheet.id,
            label: fieldConfig.label,
            field: fieldConfig.field,
            options,
            selectedValue,
            rendererKey: fieldConfig.optionRenderer,
            controlClass: 'entries-voucher-rail__control'
          })}
        </label>
      `;
    }

    if(fieldConfig.type === 'date'){
      return renderVoucherDatePicker(sheet, fieldConfig, selectedValue);
    }

    return `
      <label class="entries-voucher-rail__card${cardClass}">
        <span class="entries-voucher-rail__title">${escapeHtml(fieldConfig.label)}</span>
        <input class="entries-voucher-field__control entries-voucher-rail__control" type="${escapeHtml(fieldConfig.type || 'text')}" value="${escapeHtml(selectedValue)}" data-field="${escapeHtml(fieldConfig.field)}">
      </label>
    `;
  }

  function renderVoucherTopDockNavStack({ title = '', stackClass = '', hiddenTitle = false, content = '' } = {}){
    const safeTitle = title ? escapeHtml(title) : '&nbsp;';
    const titleClass = ['entries-voucher-rail__title', 'entries-voucher-navstack__title', hiddenTitle ? 'entries-voucher-navstack__title--ghost' : ''].filter(Boolean).join(' ');
    const wrapperClass = ['entries-voucher-navstack', stackClass].filter(Boolean).join(' ');
    return `
      <div class="${wrapperClass}">
        <span class="${titleClass}"${hiddenTitle ? ' aria-hidden="true"' : ''}>${safeTitle}</span>
        ${content}
      </div>
    `;
  }

  function renderVoucherNavIconButton({ action = '', label = '', icon = '', jumpLabel = '', disabled = false } = {}){
    const classes = ['entries-voucher-navicon', jumpLabel ? 'entries-voucher-navicon--jump' : ''].filter(Boolean).join(' ');
    return `
      <button class="${classes}" type="button" data-entry-voucher-nav="${escapeHtml(action)}" aria-label="${escapeHtml(label)}" title="${escapeHtml(label)}" ${disabled ? 'disabled' : ''}>
        <span class="entries-voucher-navicon__glyph" aria-hidden="true">${icon}</span>
        ${jumpLabel ? `<span class="entries-voucher-navicon__badge" aria-hidden="true">${escapeHtml(jumpLabel)}</span>` : ''}
      </button>
    `;
  }

  function renderVoucherNavIconCluster({ direction = 'prev', canNavigate = false } = {}){
    const isPrev = direction === 'prev';
    const primaryAction = isPrev ? 'prev' : 'next';
    const jumpAction = isPrev ? 'prev10' : 'next10';
    const primaryLabel = isPrev ? 'السند السابق' : 'السند التالي';
    const jumpLabel = isPrev ? 'الرجوع 10 سندات' : 'الذهاب 10 سندات';
    const primaryIcon = isPrev ? VOUCHER_NAV_ICON_MARKUP.prev : VOUCHER_NAV_ICON_MARKUP.next;
    const jumpIcon = isPrev ? VOUCHER_NAV_ICON_MARKUP.prev10 : VOUCHER_NAV_ICON_MARKUP.next10;
    return `
      <div class="entries-voucher-navcluster entries-voucher-navcluster--${isPrev ? 'prev' : 'next'}" role="group" aria-label="${escapeHtml(isPrev ? 'السابق' : 'التالي')}">
        ${renderVoucherNavIconButton({
          action: primaryAction,
          label: primaryLabel,
          icon: primaryIcon,
          disabled: !canNavigate
        })}
        ${renderVoucherNavIconButton({
          action: jumpAction,
          label: jumpLabel,
          icon: jumpIcon,
          jumpLabel: 'x10',
          disabled: !canNavigate
        })}
      </div>
    `;
  }

  function renderOpeningVoucherTopDock(sheet, renderState){
    const navState = getVoucherNavigatorRenderState(sheet);
    const inlineFields = [
      Object.freeze({
        kind: 'select',
        cardClass: 'entries-voucher-rail__card--opening-inline entries-voucher-rail__card--opening-currency',
        label: 'العملة',
        field: 'currencyCode',
        optionsKey: 'currencies',
        optionRenderer: 'currency'
      }),
      Object.freeze({
        kind: 'input',
        cardClass: 'entries-voucher-rail__card--opening-inline entries-voucher-rail__card--opening-date',
        label: renderState?.context?.copy?.dateLabel || 'تاريخ الافتتاح',
        field: 'date',
        type: 'date'
      })
    ];
    return `
      <div class="entries-sheet__topdock" aria-label="الشريط العلوي الثابت للسند">
        <div class="entries-voucher-topdock-layout entries-voucher-topdock-layout--opening-inline">
          ${inlineFields.map((fieldConfig) => renderVoucherTopDockField(sheet, fieldConfig, renderState)).join('')}
          ${renderVoucherTopDockNavStack({
            title: 'السابق',
            stackClass: 'entries-voucher-navstack--opening-inline entries-voucher-navstack--opening-inline-prev',
            content: renderVoucherNavIconCluster({ direction: 'prev', canNavigate: navState.canPrev })
          })}
          ${renderVoucherTopDockNavStack({
            title: 'عدد',
            hiddenTitle: true,
            stackClass: 'entries-voucher-navstack--opening-inline entries-voucher-navstack--opening-inline-count',
            content: `<div class="entries-voucher-navbox__count entries-voucher-navbox__count--opening-inline" aria-live="polite"><strong>عدد: ${escapeHtml(String(navState.count))}</strong></div>`
          })}
          ${renderVoucherTopDockNavStack({
            title: '#',
            hiddenTitle: true,
            stackClass: 'entries-voucher-navstack--opening-inline entries-voucher-navstack--opening-inline-lookup',
            content: `<label class="entries-voucher-navbox__field entries-voucher-navbox__field--opening-inline" aria-label="الانتقال برقم القيد"><input class="entries-voucher-navbox__input" type="text" value="${escapeHtml(navState.lookupValue)}" placeholder="#" inputmode="numeric" data-entry-voucher-nav="lookup" autocomplete="off" spellcheck="false"></label>`
          })}
          ${renderVoucherTopDockNavStack({
            title: 'التالي',
            stackClass: 'entries-voucher-navstack--opening-inline entries-voucher-navstack--opening-inline-next',
            content: renderVoucherNavIconCluster({ direction: 'next', canNavigate: navState.canNext })
          })}
        </div>
      </div>
    `;
  }

  function decorateVoucherTopDockField(fieldConfig, extraClass = ''){
    const safeFieldConfig = fieldConfig && typeof fieldConfig === 'object' ? fieldConfig : {};
    const mergedCardClass = [safeFieldConfig.cardClass || '', extraClass || ''].filter(Boolean).join(' ').trim();
    return {
      ...safeFieldConfig,
      cardClass: mergedCardClass
    };
  }

  function renderStreamlinedVoucherTopDock(sheet, renderState){
    const navState = getVoucherNavigatorRenderState(sheet);
    const inlineFields = getVoucherTopDockFields(renderState).map((fieldConfig) => decorateVoucherTopDockField(fieldConfig, 'entries-voucher-rail__card--streamlined'));
    return `
      <div class="entries-sheet__topdock" aria-label="الشريط العلوي الثابت للسند">
        <div class="entries-voucher-topdock-layout entries-voucher-topdock-layout--streamlined">
          ${inlineFields.map((fieldConfig) => renderVoucherTopDockField(sheet, fieldConfig, renderState)).join('')}
          ${renderVoucherTopDockNavStack({
            title: 'السابق',
            stackClass: 'entries-voucher-navstack--streamlined entries-voucher-navstack--streamlined-prev',
            content: renderVoucherNavIconCluster({ direction: 'prev', canNavigate: navState.canPrev })
          })}
          ${renderVoucherTopDockNavStack({
            title: 'عدد',
            hiddenTitle: true,
            stackClass: 'entries-voucher-navstack--streamlined entries-voucher-navstack--streamlined-count',
            content: `<div class="entries-voucher-navbox__count entries-voucher-navbox__count--streamlined" aria-live="polite"><strong>عدد: ${escapeHtml(String(navState.count))}</strong></div>`
          })}
          ${renderVoucherTopDockNavStack({
            title: '#',
            hiddenTitle: true,
            stackClass: 'entries-voucher-navstack--streamlined entries-voucher-navstack--streamlined-lookup',
            content: `<label class="entries-voucher-navbox__field entries-voucher-navbox__field--streamlined" aria-label="الانتقال برقم السند"><input class="entries-voucher-navbox__input" type="text" value="${escapeHtml(navState.lookupValue)}" placeholder="#" inputmode="numeric" data-entry-voucher-nav="lookup" autocomplete="off" spellcheck="false"></label>`
          })}
          ${renderVoucherTopDockNavStack({
            title: 'التالي',
            stackClass: 'entries-voucher-navstack--streamlined entries-voucher-navstack--streamlined-next',
            content: renderVoucherNavIconCluster({ direction: 'next', canNavigate: navState.canNext })
          })}
        </div>
      </div>
    `;
  }

  function renderVoucherTopDock(sheet, renderState){
    if(String(renderState?.sheetType || '').trim() === 'opening'){
      return renderOpeningVoucherTopDock(sheet, renderState);
    }
    return renderStreamlinedVoucherTopDock(sheet, renderState);
  }

  function supportsMovementCardActions(renderState){
    return String(renderState?.sheetType || '').trim() !== 'journal';
  }

  function renderVoucherStageBar(renderState){
    const movementFields = getMovementFields(renderState);
    const hasCardActions = supportsMovementCardActions(renderState);
    return `
      <div class="entries-sheet__stagebar" aria-hidden="true">
        <div class="entries-voucher-stagebar">
          <div class="entries-voucher-stagebar__grid${hasCardActions ? '' : ' entries-voucher-stagebar__grid--no-actions'}">
            <span class="entries-voucher-stagebar__sequence">#</span>
            ${movementFields.map((fieldConfig) => `<span>${escapeHtml(fieldConfig.label)}</span>`).join('')}
            ${hasCardActions ? '<span class="entries-voucher-stagebar__actions"></span>' : ''}
          </div>
        </div>
      </div>
    `;
  }

  function resolveMovementFieldOptions(fieldConfig, renderState, movementContext){
    const context = renderState?.context && typeof renderState.context === 'object' ? renderState.context : {};
    const safeOptionsKey = String(fieldConfig?.optionsKey || '').trim();
    if(!safeOptionsKey){
      return Array.isArray(context.accounts) ? context.accounts : [];
    }

    const movementScopedOptions = movementContext && Array.isArray(movementContext[safeOptionsKey])
      ? movementContext[safeOptionsKey]
      : null;
    if(movementScopedOptions) return movementScopedOptions;

    const contextScopedOptions = Array.isArray(context[safeOptionsKey]) ? context[safeOptionsKey] : null;
    if(contextScopedOptions) return contextScopedOptions;

    if(safeOptionsKey === 'openingBalanceSideOptions'){
      return Array.isArray(feature.COMMISSION_OPTIONS) ? feature.COMMISSION_OPTIONS : [];
    }

    return Array.isArray(context.accounts) ? context.accounts : [];
  }

  function renderMovementField(fieldConfig, renderState, movementContext, sheetId = ''){
    if(fieldConfig.type === 'account-search'){
      return renderAccountSearchField({
        label: fieldConfig.label,
        movementContext,
        movementId: movementContext?.id || '',
        hideLabel: true,
        wrapperClass: 'compact',
        sheetId
      });
    }

    if(fieldConfig.type === 'select'){
      const selectedValue = movementContext?.draft?.[fieldConfig.field] || '';
      const options = resolveMovementFieldOptions(fieldConfig, renderState, movementContext);
      return renderSelectField({
        sheetId,
        label: fieldConfig.label,
        field: fieldConfig.field,
        movementId: movementContext?.id || '',
        placeholder: fieldConfig.placeholder,
        options,
        selectedValue,
        rendererKey: fieldConfig.optionRenderer || 'account',
        hideLabel: true,
        wrapperClass: 'compact'
      });
    }

    return renderInputField({
      label: fieldConfig.label,
      field: fieldConfig.field,
      movementId: movementContext?.id || '',
      value: resolveMovementFieldValue(fieldConfig, movementContext),
      type: fieldConfig.inputType || fieldConfig.type || 'text',
      placeholder: resolveMovementFieldPlaceholder(fieldConfig, movementContext, renderState),
      dir: fieldConfig.dir || '',
      inputMode: fieldConfig.inputMode || '',
      hideLabel: true,
      wrapperClass: 'compact'
    });
  }

  function renderVoucherCardAction(movementContext, movementIndex, movementCount){
    const isAppendAction = movementIndex === (movementCount - 1);
    const action = isAppendAction ? 'append-movement' : 'remove-movement';
    const title = isAppendAction ? 'إضافة بطاقة جديدة أسفل هذه البطاقة' : 'حذف هذه البطاقة';
    const iconMarkup = isAppendAction ? MOVEMENT_ACTION_ICON_MARKUP.append : MOVEMENT_ACTION_ICON_MARKUP.remove;
    return `
      <div class="entries-voucher-card-action" aria-label="إجراء البطاقة">
        <button class="entries-voucher-card-action__btn ${isAppendAction ? 'is-append' : 'is-remove'}" type="button" data-entry-card-action="${action}" data-movement-id="${escapeHtml(movementContext?.id || '')}" aria-label="${escapeHtml(title)}" title="${escapeHtml(title)}">
          <span class="entries-voucher-card-action__icon" aria-hidden="true">${iconMarkup}</span>
        </button>
      </div>
    `;
  }

  function renderOpeningBalanceSummary(renderState){
    const summaries = Array.isArray(renderState?.context?.openingBalanceSummaries) ? renderState.context.openingBalanceSummaries : [];
    if(!summaries.length) return '';
    return `
      <section class="entries-opening-summary" aria-label="ملخص التوازن حسب العملة">
        ${summaries.map((summary) => {
          const code = String(summary?.code || '').trim().toUpperCase() || 'USD';
          const name = String(summary?.currency?.name || code).trim() || code;
          const decimals = Number(summary?.currency?.decimals);
          const precision = Number.isFinite(decimals) ? Math.max(0, Math.min(4, decimals)) : 2;
          const debitText = `${money(summary?.debitTotal || 0, precision)} ${code}`;
          const creditText = `${money(summary?.creditTotal || 0, precision)} ${code}`;
          const differenceText = `${money(summary?.difference || 0, precision)} ${code}`;
          const statusClass = summary?.balanced ? 'is-balanced' : 'is-unbalanced';
          const statusText = summary?.balanced ? 'متوازن' : 'غير متوازن';
          return `
            <article class="entries-opening-summary__card ${statusClass}">
              <div class="entries-opening-summary__head">
                <strong>${escapeHtml(code)}</strong>
                <span>${escapeHtml(name)}</span>
                <em>${escapeHtml(statusText)}</em>
              </div>
              <div class="entries-opening-summary__metrics" dir="ltr">
                <span>مدين: ${escapeHtml(debitText)}</span>
                <span>دائن: ${escapeHtml(creditText)}</span>
                <span>فرق: ${escapeHtml(differenceText)}</span>
              </div>
            </article>
          `;
        }).join('')}
      </section>
    `;
  }

  function renderMovementCard(renderState, movementContext, movementIndex, movementCount, sheetId = ''){
    const movementFields = getMovementFields(renderState);
    const hasCardActions = supportsMovementCardActions(renderState);
    return `
      <section class="entries-voucher-card entries-voucher-card--movement entries-voucher-card--stage" data-movement-id="${escapeHtml(movementContext?.id || '')}" aria-label="بيانات البطاقة ${escapeHtml(String(movementIndex + 1))}">
        <div class="entries-voucher-grid entries-voucher-grid--body entries-voucher-grid--movement${hasCardActions ? '' : ' entries-voucher-grid--no-actions'}">
          <div class="entries-voucher-sequence" aria-label="رقم البطاقة"><span class="entries-voucher-sequence__badge" aria-hidden="true"></span></div>
          ${movementFields.map((fieldConfig) => renderMovementField(fieldConfig, renderState, movementContext, sheetId)).join('')}
          ${hasCardActions ? renderVoucherCardAction(movementContext, movementIndex, movementCount) : ''}
        </div>
      </section>
    `;
  }

  function renderVoucherEditorCanvas(sheet, renderState = null){
    const state = renderState || buildVoucherRenderState(sheet);
    const { validationIssues, context } = state;
    const movements = Array.isArray(context?.movements) && context.movements.length ? context.movements : [];
    const totalMovementCount = Number(context?.journalTotalMovements) || movements.length;
    const renderedMovementCount = Number(context?.journalRenderedCount) || movements.length;
    const journalAttrs = sheet.type === 'journal'
      ? ` data-entry-journal-rendered-count="${escapeHtml(String(renderedMovementCount))}" data-entry-journal-total-count="${escapeHtml(String(totalMovementCount))}"`
      : '';

    return `
      <div class="entries-voucher entries-voucher--${escapeHtml(sheet.type)}" data-entry-sheet-editor="${escapeHtml(sheet.type)}"${journalAttrs}>
        <div class="entries-voucher__inner">
          ${renderVoucherAlert(validationIssues)}
          ${sheet.type === 'opening' ? renderOpeningBalanceSummary(state) : ''}
          ${movements.map((movementContext, movementIndex) => renderMovementCard(state, movementContext, movementIndex, movements.length, sheet.id)).join('')}
        </div>
      </div>
    `;
  }

  function renderSettlementField(fieldConfig, renderState, movementContext, sheetId = ''){
    const { context } = renderState;
    const centeredFields = ['counterpartAccountQuery', 'grossAmountText', 'beneficiaryName', 'statement', 'summary', 'commissionFeeText'];
    const labelCenteredOnlyFields = ['date', 'currencyCode', 'commissionCode'];
    const modifierClass = [
      centeredFields.includes(fieldConfig.field) ? 'settlement-field--centered' : '',
      labelCenteredOnlyFields.includes(fieldConfig.field) ? 'settlement-field--label-centered' : '',
      fieldConfig.wide ? 'settlement-field--wide settlement-field--summary' : ''
    ].filter(Boolean).join(' ');
    const wrapperClass = ['settlement-field', modifierClass].filter(Boolean).join(' ');
    if(fieldConfig.type === 'account-search'){
      return renderAccountSearchField({
        label: fieldConfig.label,
        movementContext,
        movementId: movementContext?.id || '',
        hideLabel: false,
        wrapperClass,
        sheetId
      });
    }

    if(fieldConfig.type === 'select'){
      const selectedValue = movementContext?.draft?.[fieldConfig.field] || '';
      const options = fieldConfig.optionsKey
        ? (movementContext?.[fieldConfig.optionsKey] || context[fieldConfig.optionsKey] || context.accounts)
        : context.accounts;
      return renderSelectField({
        sheetId,
        label: fieldConfig.label,
        field: fieldConfig.field,
        movementId: movementContext?.id || '',
        placeholder: fieldConfig.placeholder,
        options,
        selectedValue,
        rendererKey: fieldConfig.optionRenderer || 'account',
        hideLabel: false,
        wrapperClass
      });
    }

    if((fieldConfig.inputType || fieldConfig.type) === 'date'){
      return renderSettlementDatePicker(
        sheetId,
        fieldConfig,
        resolveMovementFieldValue(fieldConfig, movementContext),
        movementContext?.id || '',
        modifierClass
      );
    }

    return renderInputField({
      label: fieldConfig.label,
      field: fieldConfig.field,
      movementId: movementContext?.id || '',
      value: resolveMovementFieldValue(fieldConfig, movementContext),
      type: fieldConfig.inputType || fieldConfig.type || 'text',
      placeholder: resolveMovementFieldPlaceholder(fieldConfig, movementContext, renderState),
      dir: fieldConfig.dir || '',
      inputMode: fieldConfig.inputMode || '',
      hideLabel: false,
      wrapperClass,
      rows: fieldConfig.rows || 3
    });
  }

  function renderSettlementBox(renderState, movementContext, boxClassName, ariaLabel, sheetId = '', sideConfig = null){
    const sideLabel = sideConfig && sideConfig.label ? String(sideConfig.label) : '';
    const sideClassName = sideConfig && sideConfig.className ? String(sideConfig.className) : '';
    const sideKey = sideConfig && sideConfig.key ? String(sideConfig.key) : '';
    const rowDefinitions = sideKey === 'credit' ? SETTLEMENT_CREDIT_BOX_ROWS : SETTLEMENT_DEBIT_BOX_ROWS;
    return `
      <section class="entries-settlement-shell__box ${escapeHtml(boxClassName)}" data-movement-id="${escapeHtml(movementContext?.id || '')}" aria-label="${escapeHtml(ariaLabel)}">
        <div class="entries-settlement-panel entries-settlement-panel--${escapeHtml(sideKey || 'default')}">
          ${sideLabel ? `
            <div class="entries-settlement-panel__meta">
              <span class="entries-settlement-panel__side ${escapeHtml(sideClassName)}">${escapeHtml(sideLabel)}</span>
            </div>
          ` : ''}
          ${rowDefinitions.map((row) => `
            <div class="entries-settlement-panel__row">
              ${row.map((fieldConfig) => renderSettlementField(fieldConfig, renderState, movementContext, sheetId)).join('')}
            </div>
          `).join('')}
        </div>
      </section>
    `;
  }

  function renderSettlementShell(sheet, renderState = null){
    const state = renderState || buildVoucherRenderState(sheet);
    const movements = Array.isArray(state?.context?.movements) ? state.context.movements.slice(0, 2) : [];
    const rightMovement = movements[0] || null;
    const leftMovement = movements[1] || rightMovement;
    const rightBox = rightMovement
      ? renderSettlementBox(state, rightMovement, 'entries-settlement-shell__box--right', 'الطرف المدين', sheet?.id || '', { key: 'debit', label: 'مدين', className: 'is-debit' })
      : '<section class="entries-settlement-shell__box entries-settlement-shell__box--right" aria-label="الطرف المدين"></section>';
    const leftBox = leftMovement
      ? renderSettlementBox(state, leftMovement, 'entries-settlement-shell__box--left', 'الطرف الدائن', sheet?.id || '', { key: 'credit', label: 'دائن', className: 'is-credit' })
      : '<section class="entries-settlement-shell__box entries-settlement-shell__box--left" aria-label="الطرف الدائن"></section>';

    return `
      <div class="entries-voucher entries-voucher--settlement" data-entry-sheet-editor="settlement">
        <div class="entries-voucher__inner">
          ${renderVoucherAlert(state.validationIssues)}
          <div class="entries-settlement-shell" aria-label="منطقة تصميم سند التسوية">
            ${rightBox}
            ${leftBox}
          </div>
        </div>
      </div>
    `;
  }

  function renderSheetCanvasMarkup(sheet, renderState = null){
    if(!sheet) return '';
    if(sheet.type === 'settlement') return renderSettlementShell(sheet, renderState);
    if(isInteractiveVoucherType(sheet.type)) return renderVoucherEditorCanvas(sheet, renderState);
    return '<div class="entries-sheet__blank"></div>';
  }

  function renderVoucherWorkspace(sheet, renderState){
    const safeSheetType = String(sheet?.type || '').trim();
    const hasReservedSubbar = ['opening', 'receipt', 'payment', 'journal'].includes(safeSheetType);
    return `
      <div class="entries-sheet__workspace entries-sheet__workspace--voucher">
        <div class="entries-voucher-panel">
          ${renderVoucherStageBar(renderState)}
          <div class="entries-sheet__canvas entries-sheet__canvas--voucher" data-entry-sheet-canvas="true" data-entry-sheet-id="${escapeHtml(sheet.id)}">
            ${renderSheetCanvasMarkup(sheet, renderState)}
          </div>
        </div>
        <div class="entries-voucher-subbar${hasReservedSubbar ? ' entries-voucher-subbar--reserved' : ''}"${hasReservedSubbar ? ' aria-label="مساحة محجوزة للتعديلات المستقبلية"' : ' aria-hidden="true"'}>${hasReservedSubbar ? '<span class="entries-voucher-subbar__text">محجوز ل تعديلات المستقبل</span>' : ''}</div>
      </div>
    `;
  }

  function renderSheetContent(sheet){
    if(!sheet) return '';
    const meta = VOUCHERS[sheet.type] || VOUCHERS.journal;
    const isSettlementSheet = sheet.type === 'settlement';
    const interactive = isInteractiveVoucherType(sheet.type) && !isSettlementSheet;
    const renderState = (interactive || isSettlementSheet) ? buildVoucherRenderState(sheet) : null;

    const modalWindowClasses = [
      'entries-modal-window',
      'entries-modal-window--grand',
      'entries-modal-window--size-lg'
    ];
    if(isSettlementSheet) modalWindowClasses.push('entries-modal-window--settlement-shell');
    if(interactive) modalWindowClasses.push('entries-modal-window--voucher-match-settlement-height');

    return `
      <div class="entries-modal-backdrop" data-entry-action="backdrop" data-entry-sheet-id="${escapeHtml(sheet.id)}" aria-hidden="false">
        <div class="${modalWindowClasses.join(' ')}" data-entry-sheet-id="${escapeHtml(sheet.id)}" role="dialog" aria-modal="false" aria-label="${escapeHtml(meta.label)}" tabindex="-1">
          <aside class="entries-sheet entries-sheet--${escapeHtml(sheet.type)}" data-entry-sheet-id="${escapeHtml(sheet.id)}">
            <div class="entries-sheet__head">
              <div class="entries-sheet__heading">
                <h2 class="entries-sheet__title" data-taif-detail-title="true"><span class="entries-sheet__title-text">${escapeHtml(meta.label)}</span>${ACTION_ICON_MARKUP[meta.key] ? `<span class="entries-sheet__title-icon" aria-hidden="true">${ACTION_ICON_MARKUP[meta.key]}</span>` : ""}</h2>
              </div>
              <div class="entries-sheet__window-actions" data-taif-window-actions="true">
                <button class="entries-sheet__chrome-btn entries-sheet__expand" type="button" data-entry-action="expand-sheet" aria-label="تكبير النافذة" title="تكبير النافذة">${getWindowChromeIcon('expand')}</button>
                <button class="entries-sheet__close" type="button" data-entry-action="close-sheet" aria-label="إغلاق" title="إغلاق">${getWindowChromeIcon('close')}</button>
              </div>
            </div>
            <div class="entries-sheet__body${interactive ? ' entries-sheet__body--voucher' : ''}${isSettlementSheet ? ' entries-sheet__body--settlement' : ''}">
              ${interactive ? renderVoucherTopDock(sheet, renderState) : ''}
              ${interactive ? renderVoucherWorkspace(sheet, renderState) : `<div class="entries-sheet__shell-space entries-sheet__shell-space--${escapeHtml(sheet.type)}">${renderSheetCanvasMarkup(sheet, renderState)}</div>`}
              ${renderSheetFooter(sheet)}
            </div>
          </aside>
        </div>
      </div>
    `;
  }

  function renderShellMarkup(){
    const state = readState();
    const records = getVisibleRecords(state);
    const allRecords = getVisibleRecords(state, '');
    const hasSelectedRecordVisible = records.some((record) => String(record?.id || '').trim() === String(runtime.selectedRecordId || '').trim());
    if(runtime.selectedRecordId && !hasSelectedRecordVisible){
      runtime.selectedRecordId = '';
    }
    const postedCount = allRecords.filter((record) => record.status === 'posted').length;
    const draftCount = allRecords.filter((record) => record.status !== 'posted').length;

    return `
      <div class="entries-workbench">
        ${renderToolbar({ draftCount, postedCount, totalCount: allRecords.length, hasSelection: hasSelectedRecordVisible })}
        ${renderMainArea(records)}
      </div>
    `;
  }

  Object.assign(feature, {
    renderSheetContent,
    renderShellMarkup,
    createVoucherDeleteQuestionOptions,
    renderVoucherDeleteConfirmMarkup,
    updateRecordSelectionUi
  });
})();
