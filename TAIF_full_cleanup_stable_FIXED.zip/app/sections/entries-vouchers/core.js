(()=>{
  /*
   * TAIF Entries & Vouchers feature core foundation.
   * Provides shared constants, runtime state, and low-level helpers.
   */
  const TAIF = window.TAIF;
  const { parseNumericInput, toText } = TAIF.core.utils;
  const feature = TAIF.entriesVouchersFeature || (TAIF.entriesVouchersFeature = {});
  const windowChrome = TAIF.ui.windowChrome || {};
  const dateSystem = TAIF.ui?.dateSystem || {};

  const storageKeys = TAIF?.core?.storageKeys || {};
  const STORAGE_KEY = storageKeys.entriesVouchers || 'taif-entries-vouchers-module-v1';
  const ACCOUNT_STORAGE_KEY = storageKeys.chartOfAccounts || 'taif-chart-of-accounts-centers-v3';
  const CURRENCY_STORAGE_KEY = storageKeys.currencyDomain || storageKeys.currencyManagement || 'taif-currency-management-module-v1';
  const CASH_BOX_STORAGE_KEY = storageKeys.cashBoxes || 'taif-cash-boxes-module-v1';

  const runtime = feature.runtime || (feature.runtime = {
    panel: null,
    filter: '',
    sheets: [],
    sheetSequence: 0,
    windowOrder: [],
    topbarFitCleanup: null,
    sheetChromeCleanups: [],
    modalLayer: null,
    panelBindings: null,
    modalBindings: null,
    documentBindings: null,
    windowBindings: null,
    deleteConfirmCleanup: null,
    selectedRecordId: '',
    accountSearch: {
      sheetId: '',
      movementId: ''
    },
    choicePicker: {
      sheetId: '',
      field: '',
      movementId: ''
    },
    datePicker: {
      sheetId: '',
      movementId: '',
      monthCursor: '',
      view: 'days'
    },
    datePickerOutsideCloseTimer: 0
  });

  const VOUCHERS = Object.freeze({
    payment: Object.freeze({
      key: 'payment',
      prefix: 'PV',
      label: 'سند دفع',
      badgeClass: 'entries-type--payment'
    }),
    receipt: Object.freeze({
      key: 'receipt',
      prefix: 'RV',
      label: 'سند قبض',
      badgeClass: 'entries-type--receipt'
    }),
    journal: Object.freeze({
      key: 'journal',
      prefix: 'JV',
      label: 'سند يومي',
      badgeClass: 'entries-type--journal'
    }),
    settlement: Object.freeze({
      key: 'settlement',
      prefix: 'SV',
      label: 'سند تسوية',
      badgeClass: 'entries-type--settlement'
    }),
    opening: Object.freeze({
      key: 'opening',
      prefix: 'OV',
      label: 'سند قيد افتتاحي',
      badgeClass: 'entries-type--opening'
    })
  });

  const INTERACTIVE_VOUCHER_DEFINITIONS = Object.freeze({
    receipt: Object.freeze({
      cashMotionLabel: 'الحركة النقدية',
      primaryAccountLabel: 'الحساب النقدي',
      amountPlaceholder: 'قبض 0.00',
      cashMotionOptions: Object.freeze([
        Object.freeze({ value: 'cash-in-box', label: 'نقداً إلى الصندوق' })
      ]),
      statementDirection: 'قبض من',
      lineBlueprintsByMotion: Object.freeze({
        'cash-in-box': Object.freeze([
          Object.freeze({ roleKey: 'cash', accountKey: 'cashAccount', side: 'debit', roleLabel: 'زيادة الصندوق النقدي' }),
          Object.freeze({ roleKey: 'counterpart', accountKey: 'counterpartAccount', side: 'credit', roleLabel: 'إثبات الحساب المقبوض منه' })
        ])
      })
    }),
    payment: Object.freeze({
      cashMotionLabel: 'الحركة النقدية',
      primaryAccountLabel: 'الحساب النقدي',
      amountPlaceholder: 'دفع 0.00',
      cashMotionOptions: Object.freeze([
        Object.freeze({ value: 'cash-out-box', label: 'نقداً من الصندوق' })
      ]),
      statementDirection: 'دفع إلى',
      lineBlueprintsByMotion: Object.freeze({
        'cash-out-box': Object.freeze([
          Object.freeze({ roleKey: 'counterpart', accountKey: 'counterpartAccount', side: 'debit', roleLabel: 'إثبات الحساب المدفوع إليه' }),
          Object.freeze({ roleKey: 'cash', accountKey: 'cashAccount', side: 'credit', roleLabel: 'تخفيض الصندوق النقدي' })
        ])
      })
    }),
    journal: Object.freeze({
      cashMotionLabel: 'الحركة النقدية',
      cashMotionPickerOptions: Object.freeze([
        Object.freeze({ value: 'cash-in-box', label: 'نقداً بالصندوق' })
      ]),
      primaryAccountLabel: 'الحساب الأساسي',
      amountPlaceholder: 'قيد 0.00',
      cashMotionOptions: Object.freeze([
        Object.freeze({ value: 'primary-debit', label: 'الحساب الأساسي مدين' }),
        Object.freeze({ value: 'primary-credit', label: 'الحساب الأساسي دائن' })
      ]),
      statementDirection: 'قيد مع',
      lineBlueprintsByMotion: Object.freeze({
        'primary-debit': Object.freeze([
          Object.freeze({ roleKey: 'primary', accountKey: 'cashAccount', side: 'debit', roleLabel: 'الحساب الأساسي مدين' }),
          Object.freeze({ roleKey: 'counterpart', accountKey: 'counterpartAccount', side: 'credit', roleLabel: 'الحساب المقابل دائن' })
        ]),
        'primary-credit': Object.freeze([
          Object.freeze({ roleKey: 'counterpart', accountKey: 'counterpartAccount', side: 'debit', roleLabel: 'الحساب المقابل مدين' }),
          Object.freeze({ roleKey: 'primary', accountKey: 'cashAccount', side: 'credit', roleLabel: 'الحساب الأساسي دائن' })
        ])
      })
    }),
    opening: Object.freeze({
      cashMotionLabel: 'طبيعة الافتتاح',
      primaryAccountLabel: 'حساب الرصيد الافتتاحي',
      amountPlaceholder: 'افتتاحي 0.00',
      cashMotionOptions: Object.freeze([
        Object.freeze({ value: 'opening-balance', label: 'أرصدة افتتاحية' })
      ]),
      statementDirection: 'رصيد افتتاحي لـ',
      lineBlueprints: Object.freeze([])
    }),
    settlement: Object.freeze({
      cashMotionLabel: 'نوع الحركة',
      primaryAccountLabel: 'الحساب المرجعي',
      amountPlaceholder: 'تسوية 0.00',
      cashMotionOptions: Object.freeze([
        Object.freeze({ value: 'settlement-balance', label: 'حركة تسوية' })
      ]),
      statementDirection: 'تسوية مع',
      lineBlueprints: Object.freeze([])
    })
  });

  const INTERACTIVE_VOUCHER_TYPES = Object.freeze(Object.keys(INTERACTIVE_VOUCHER_DEFINITIONS));
  const COMMISSION_OPTIONS = Object.freeze([
    Object.freeze({ value: 'none', label: 'بدون عمولة' }),
    Object.freeze({ value: 'debit-ours', label: 'مدين-لنا' }),
    Object.freeze({ value: 'credit-ours', label: 'دائن-علينا' })
  ]);
  const DEFAULT_COUNTERS = Object.freeze({ PV: 1, RV: 1, JV: 1, SV: 1, OV: 1 });
  const VOUCHER_COUNTER_PREFIXES = Object.freeze(Object.keys(DEFAULT_COUNTERS));

  function createDefaultState(){
    return {
      version: 1,
      updatedAt: Date.now(),
      counters: { ...DEFAULT_COUNTERS },
      records: []
    };
  }

  const FALLBACK_CURRENCY = Object.freeze({ code: 'USD', name: 'الدولار الأمريكي', flag: 'us', decimals: 2 });


  function getWindowChromeIcon(type){
    return typeof windowChrome.getIconMarkup === 'function' ? windowChrome.getIconMarkup(type) : '';
  }


  const toNumber = parseNumericInput;

  function money(value, decimals = 2){
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    }).format(toNumber(value, 0));
  }


  function formatDate(value){
    return toText(value) || '—';
  }


  function resolveVoucherType(type){
    return Object.prototype.hasOwnProperty.call(VOUCHERS, type) ? type : 'journal';
  }


  function isInteractiveVoucherType(type){
    return INTERACTIVE_VOUCHER_TYPES.includes(resolveVoucherType(type));
  }


  function clampPositiveAmount(value){
    return Math.max(0, toNumber(value, 0));
  }


  function todayInputValue(){
    return typeof dateSystem.todayIsoDate === 'function' ? dateSystem.todayIsoDate() : toDatePickerIsoDate(new Date());
  }


  function parseDatePickerIsoDate(value){
    if(typeof dateSystem.parseIsoDate === 'function') return dateSystem.parseIsoDate(value);
    const safeValue = toText(value);
    if(!/^\d{4}-\d{2}-\d{2}$/.test(safeValue)) return null;
    const [year, month, day] = safeValue.split('-').map((part) => Number(part));
    const date = new Date(year, month - 1, day);
    if(Number.isNaN(date.getTime())) return null;
    if(date.getFullYear() !== year || date.getMonth() !== (month - 1) || date.getDate() !== day) return null;
    return date;
  }


  function parseDatePickerMonthCursor(value){
    if(typeof dateSystem.parseMonthCursor === 'function') return dateSystem.parseMonthCursor(value);
    const safeValue = toText(value);
    if(!/^\d{4}-\d{2}$/.test(safeValue)) return null;
    const [year, month] = safeValue.split('-').map((part) => Number(part));
    if(!Number.isInteger(year) || !Number.isInteger(month) || month < 1 || month > 12) return null;
    return { year, monthIndex: month - 1 };
  }


  function toDatePickerIsoDate(date){
    if(typeof dateSystem.toIsoDate === 'function') return dateSystem.toIsoDate(date);
    if(!(date instanceof Date) || Number.isNaN(date.getTime())) return todayInputValue();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }


  function toDatePickerMonthCursor(date){
    if(typeof dateSystem.toMonthCursor === 'function') return dateSystem.toMonthCursor(date);
    if(!(date instanceof Date) || Number.isNaN(date.getTime())) return todayInputValue().slice(0, 7);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
  }


  function ensureDatePickerState(){
    if(!runtime.datePicker || typeof runtime.datePicker !== 'object'){
      runtime.datePicker = { sheetId: '', movementId: '', monthCursor: '', view: 'days' };
    }
    if(typeof runtime.datePicker.movementId !== 'string'){
      runtime.datePicker.movementId = '';
    }
    if(typeof runtime.datePicker.view !== 'string'){
      runtime.datePicker.view = 'days';
    }
    return runtime.datePicker;
  }


  function normalizeDatePickerView(value){
    return typeof dateSystem.normalizePickerView === 'function' ? dateSystem.normalizePickerView(value) : (toText(value) === 'month-year' ? 'month-year' : 'days');
  }


  function normalizeDatePickerMonthCursor(value){
    return typeof dateSystem.normalizeMonthCursor === 'function' ? dateSystem.normalizeMonthCursor(value) : (/^\d{4}-\d{2}$/.test(toText(value)) ? toText(value) : todayInputValue().slice(0, 7));
  }


  function shiftDatePickerMonthCursor(value, offset = 0){
    if(typeof dateSystem.shiftMonthCursor === 'function') return dateSystem.shiftMonthCursor(value, offset);
    const base = normalizeDatePickerMonthCursor(value);
    const [year, month] = base.split('-').map((part) => Number(part));
    const date = new Date(year, month - 1 + Number(offset || 0), 1);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
  }


  function clearScheduledDatePickerOutsideClose(){
    const timerId = Number(runtime.datePickerOutsideCloseTimer || 0);
    if(timerId > 0){
      window.clearTimeout(timerId);
    }
    runtime.datePickerOutsideCloseTimer = 0;
  }


  function clearDatePickerRuntimeState(){
    clearScheduledDatePickerOutsideClose();
    const state = ensureDatePickerState();
    state.sheetId = '';
    state.movementId = '';
    state.monthCursor = '';
    state.view = 'days';
  }

  function ensureChoicePickerState(){
    if(!runtime.choicePicker || typeof runtime.choicePicker !== 'object'){
      runtime.choicePicker = { sheetId: '', field: '', movementId: '' };
    }
    return runtime.choicePicker;
  }

  function setChoicePickerRuntimeState(sheetId = '', field = '', movementId = ''){
    const state = ensureChoicePickerState();
    state.sheetId = String(sheetId || '').trim();
    state.field = String(field || '').trim();
    state.movementId = String(movementId || '').trim();
    return state;
  }


  function clearChoicePickerRuntimeState(sheetId = '', field = '', movementId = ''){
    const state = ensureChoicePickerState();
    const targetSheetId = String(sheetId || '').trim();
    const targetField = String(field || '').trim();
    const targetMovementId = String(movementId || '').trim();
    if(targetSheetId && state.sheetId && state.sheetId !== targetSheetId) return false;
    if(targetField && state.field && state.field !== targetField) return false;
    if(targetMovementId && state.movementId && state.movementId !== targetMovementId) return false;
    state.sheetId = '';
    state.field = '';
    state.movementId = '';
    return true;
  }


  function normalizeDateInputValue(value){
    return typeof dateSystem.normalizeIsoDate === 'function' ? dateSystem.normalizeIsoDate(value) : (/^\d{4}-\d{2}-\d{2}$/.test(toText(value)) ? toText(value) : todayInputValue());
  }


  function normalizeAmountInputText(value){
    return String(value == null ? '' : value).trim().replace(/,/g, '');
  }


  function getInteractiveVoucherDefinition(type){
    const safeType = resolveVoucherType(type);
    return Object.prototype.hasOwnProperty.call(INTERACTIVE_VOUCHER_DEFINITIONS, safeType)
      ? INTERACTIVE_VOUCHER_DEFINITIONS[safeType]
      : null;
  }


  Object.assign(feature, {
  runtime,
  windowChrome,
  STORAGE_KEY,
  ACCOUNT_STORAGE_KEY,
  CURRENCY_STORAGE_KEY,
  CASH_BOX_STORAGE_KEY,
  VOUCHERS,
  COMMISSION_OPTIONS,
  VOUCHER_COUNTER_PREFIXES,
  createDefaultState,
  FALLBACK_CURRENCY,
  getWindowChromeIcon,
  toText,
  toNumber,
  money,
  formatDate,
  resolveVoucherType,
  isInteractiveVoucherType,
  clampPositiveAmount,
  todayInputValue,
  parseDatePickerIsoDate,
  parseDatePickerMonthCursor,
  toDatePickerIsoDate,
  toDatePickerMonthCursor,
  ensureDatePickerState,
  ensureChoicePickerState,
  setChoicePickerRuntimeState,
  normalizeDatePickerView,
  normalizeDatePickerMonthCursor,
  shiftDatePickerMonthCursor,
  clearChoicePickerRuntimeState,
  clearScheduledDatePickerOutsideClose,
  clearDatePickerRuntimeState,
  normalizeDateInputValue,
  normalizeAmountInputText,
  getInteractiveVoucherDefinition
});

})();
