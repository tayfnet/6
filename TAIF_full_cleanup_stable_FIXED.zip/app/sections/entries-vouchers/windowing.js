(()=>{
  /*
   * TAIF Entries & Vouchers feature windowing.
   * Modal layer mounting, stacking, dragging, maximizing, and focus restoration.
   */
  const TAIF = window.TAIF;
  const { mountAdaptiveToolbarFit, escapeSelectorValue, focusElementWithoutScroll, getViewportBoundsForSize, runCleanupCallbacks } = TAIF.core.utils;
  const feature = TAIF.entriesVouchersFeature || (TAIF.entriesVouchersFeature = {});
  const {
    runtime,
    windowChrome,
    getWindowChromeIcon,
    getSheet,
    getSheetIndex,
    getSheetIdFromNode,
    syncWindowOrder,
    getTopSheetId,
    isTopmostSheet,
    rememberWindowGeometry,
    renderSheetContent
  } = feature;

  function getEntriesModalLayer(createIfMissing = false){
    if(runtime.modalLayer && runtime.modalLayer.isConnected) return runtime.modalLayer;

    const existing = document.querySelector('.entries-window-layer[data-entries-layer="global"]');
    if(existing instanceof HTMLElement){
      TAIF?.core?.utils?.markOwnedNode?.(existing, 'entries-vouchers');
      TAIF?.ui?.windowSystem?.registerLayer?.(existing, { ownerView:'entries-vouchers', source:'entries-vouchers-windowing' });
      runtime.modalLayer = existing;
      return existing;
    }

    if(!createIfMissing) return null;

    const layer = document.createElement('div');
    layer.className = 'entries-window-layer';
    layer.dataset.entriesLayer = 'global';
    TAIF?.core?.utils?.markOwnedNode?.(layer, 'entries-vouchers');
    TAIF?.ui?.windowSystem?.registerLayer?.(layer, { ownerView:'entries-vouchers', source:'entries-vouchers-windowing' });
    layer.setAttribute('aria-hidden', runtime.sheets.length ? 'false' : 'true');
    document.body.appendChild(layer);
    runtime.modalLayer = layer;
    return layer;
  }

  function cleanupEntriesModalLayer(){
    const layer = getEntriesModalLayer(false);
    if(!(layer instanceof HTMLElement)) return;
    if(layer.childElementCount > 0) return;
    layer.remove();
    if(runtime.modalLayer === layer) runtime.modalLayer = null;
  }

  function renderEntriesModalLayer(){
    const layer = getEntriesModalLayer(runtime.sheets.length > 0);
    if(!(layer instanceof HTMLElement)){
      cleanupEntriesModalLayer();
      return null;
    }

    layer.setAttribute('aria-hidden', runtime.sheets.length ? 'false' : 'true');
    if(typeof feature.cleanupFloatingAccountSearchPopovers === 'function'){
      feature.cleanupFloatingAccountSearchPopovers(layer);
    }
    layer.innerHTML = runtime.sheets.map((sheet) => renderSheetContent(sheet)).join('');
    TAIF?.ui?.windowSystem?.normalizeRoot?.(layer, { ownerView:'entries-vouchers', source:'entries-vouchers-windowing' });

    if(!runtime.sheets.length){
      cleanupEntriesModalLayer();
      return null;
    }

    return layer;
  }

  function getEntriesPrimaryWorkspaceRect(){
    if(typeof windowChrome.getPrimaryWorkspaceRect === 'function'){
      return windowChrome.getPrimaryWorkspaceRect((runtime.panel && runtime.panel.isConnected) ? runtime.panel : null);
    }

    const workspace = (runtime.panel && runtime.panel.isConnected)
      ? runtime.panel
      : document.getElementById('panel') || document.querySelector('.content');

    if(!(workspace instanceof Element) || typeof workspace.getBoundingClientRect !== 'function') return null;

    const rect = workspace.getBoundingClientRect();
    const width = Math.round(rect.width);
    const height = Math.round(rect.height);
    if(width < 40 || height < 40) return null;

    return {
      left: Math.round(rect.left),
      top: Math.round(rect.top),
      width,
      height
    };
  }

  function applySheetWindowStackState(){
    syncWindowOrder();
    const layer = getEntriesModalLayer(false);
    if(!(layer instanceof HTMLElement)) return;
    const orderMap = new Map(runtime.windowOrder.map((sheetId, index) => [sheetId, index]));
    layer.querySelectorAll('.entries-modal-backdrop[data-entry-sheet-id]').forEach((backdrop) => {
      const sheetId = String(backdrop.getAttribute('data-entry-sheet-id') || '');
      const orderIndex = orderMap.has(sheetId) ? orderMap.get(sheetId) : 0;
      backdrop.style.zIndex = String(2400 + (orderIndex * 2));
      backdrop.classList.toggle('is-window-active', sheetId === getTopSheetId());
    });
  }

  function bringEntriesLayerToFront(){
    const layer = getEntriesModalLayer(false);
    if(!(layer instanceof HTMLElement) || layer.parentNode !== document.body) return;
    if(document.body.lastElementChild === layer) return;
    document.body.appendChild(layer);
  }

  function activateSheetWindow(sheetId){
    if(!sheetId) return;
    syncWindowOrder();
    runtime.windowOrder = runtime.windowOrder.filter((id) => id !== sheetId);
    runtime.windowOrder.push(sheetId);
    bringEntriesLayerToFront();
    applySheetWindowStackState();
  }

  function removeSheet(sheetId){
    const index = getSheetIndex(sheetId);
    if(index < 0) return;
    runtime.sheets.splice(index, 1);
    runtime.windowOrder = runtime.windowOrder.filter((id) => id !== sheetId);
    syncWindowOrder();
  }

  function syncEntriesExpandButton(button, isMaximized){
    if(!(button instanceof HTMLElement)) return;
    if(typeof windowChrome.syncExpandButton === 'function'){
      windowChrome.syncExpandButton(button, isMaximized);
      return;
    }

    button.innerHTML = getWindowChromeIcon(isMaximized ? 'collapse' : 'expand');
    button.setAttribute('aria-label', isMaximized ? 'استعادة الحجم المرجعي' : 'تكبير النافذة');
    button.setAttribute('title', isMaximized ? 'استعادة الحجم المرجعي' : 'تكبير النافذة');
    button.setAttribute('aria-pressed', isMaximized ? 'true' : 'false');
  }

  function clamp(value, min, max){
    if(max < min) return min;
    return Math.min(Math.max(value, min), max);
  }

  function readFiniteNumber(value){
    const numeric = Number(value);
    return Number.isFinite(numeric) ? numeric : null;
  }

  function getEntriesModalViewportBoundsForSize(width, height){
    if(typeof windowChrome.getModalViewportBoundsForSize === 'function'){
      return windowChrome.getModalViewportBoundsForSize(width, height);
    }
    if(typeof getViewportBoundsForSize === 'function'){
      return getViewportBoundsForSize(width, height, 12);
    }
    return { minLeft:12, maxLeft:12, minTop:12, maxTop:12 };
  }

  function getEntriesModalViewportBounds(modal){
    const rect = modal.getBoundingClientRect();
    return getEntriesModalViewportBoundsForSize(rect.width, rect.height);
  }

  function applyEntriesModalPosition(modal, left, top, presetBounds = null){
    if(!(modal instanceof HTMLElement)) return;
    const bounds = presetBounds || getEntriesModalViewportBounds(modal);
    const nextLeft = clamp(Number(left) || 0, bounds.minLeft, bounds.maxLeft);
    const nextTop = clamp(Number(top) || 0, bounds.minTop, bounds.maxTop);
    const roundedLeft = Math.round(nextLeft);
    const roundedTop = Math.round(nextTop);
    modal.style.left = `${roundedLeft}px`;
    modal.style.top = `${roundedTop}px`;
    modal.dataset.windowLeft = String(roundedLeft);
    modal.dataset.windowTop = String(roundedTop);
    modal.classList.add('is-positioned');
    rememberWindowGeometry(modal, { left: roundedLeft, top: roundedTop });
  }

  function getEntriesOpeningTopGuard(){
    if(!(runtime.panel instanceof Element)) return 0;
    const toolbar = runtime.panel.querySelector('.entries-toolbar');
    if(!(toolbar instanceof HTMLElement)) return 0;
    const rect = toolbar.getBoundingClientRect();
    if(!Number.isFinite(rect.bottom) || rect.bottom <= 0) return 0;
    return Math.round(rect.bottom + 10);
  }

  function positionEntriesModalAtCenter(modal){
    if(!(modal instanceof HTMLElement)) return;
    const rect = modal.getBoundingClientRect();
    const bounds = getEntriesModalViewportBoundsForSize(rect.width, rect.height);
    const sheetId = getSheetIdFromNode(modal);
    const orderIndex = Math.max(runtime.windowOrder.indexOf(sheetId), 0);
    const cascadeLeft = (orderIndex % 5) * 28;
    const cascadeTop = (orderIndex % 5) * 24;
    const centeredLeft = ((window.innerWidth - rect.width) / 2) + cascadeLeft;
    const centeredTop = Math.max(((window.innerHeight - rect.height) / 2) + cascadeTop, getEntriesOpeningTopGuard());
    applyEntriesModalPosition(modal, centeredLeft, centeredTop, bounds);
  }

  function clearEntriesModalMaximizedFrame(modal){
    if(!(modal instanceof HTMLElement)) return;
    modal.style.removeProperty('width');
    modal.style.removeProperty('max-width');
    modal.style.removeProperty('height');
    modal.style.removeProperty('max-height');
  }

  function getEntriesMaximizedFrame(){
    const workspaceRect = getEntriesPrimaryWorkspaceRect();
    if(workspaceRect) return workspaceRect;

    return {
      left: 12,
      top: 12,
      width: Math.max(320, Math.round(window.innerWidth - 24)),
      height: Math.max(220, Math.round(window.innerHeight - 24))
    };
  }

  function applyEntriesMaximizedFrame(modal){
    if(!(modal instanceof HTMLElement)) return;
    const frame = getEntriesMaximizedFrame();
    modal.style.width = `${frame.width}px`;
    modal.style.maxWidth = `${frame.width}px`;
    modal.style.height = `${frame.height}px`;
    modal.style.maxHeight = `${frame.height}px`;
    applyEntriesModalPosition(modal, frame.left, frame.top, {
      minLeft: frame.left,
      maxLeft: frame.left,
      minTop: frame.top,
      maxTop: frame.top
    });
  }

  function resolveStoredWindowPoint(modal, sheetWindowState = {}, options = {}){
    const { rect = null, allowRectFallback = false } = options || {};
    const storedLeft = readFiniteNumber(modal.dataset.windowLeft) ?? readFiniteNumber(sheetWindowState.left);
    const storedTop = readFiniteNumber(modal.dataset.windowTop) ?? readFiniteNumber(sheetWindowState.top);
    if(storedLeft != null && storedTop != null){
      return { left: storedLeft, top: storedTop };
    }

    if(!allowRectFallback) return { left: null, top: null };
    const sourceRect = rect || modal.getBoundingClientRect();
    return {
      left: Math.round(sourceRect.left),
      top: Math.round(sourceRect.top)
    };
  }

  function maximizeEntriesModalWindow(modal){
    if(!(modal instanceof HTMLElement)) return;
    const rect = modal.getBoundingClientRect();
    const sheetWindowState = getSheet(getSheetIdFromNode(modal))?.window || {};
    const currentPoint = resolveStoredWindowPoint(modal, sheetWindowState, { rect, allowRectFallback: true });

    modal.dataset.restoreLeft = String(currentPoint.left);
    modal.dataset.restoreTop = String(currentPoint.top);
    rememberWindowGeometry(modal, { restoreLeft: currentPoint.left, restoreTop: currentPoint.top, isMaximized: true });
    applyEntriesMaximizedFrame(modal);
    modal.classList.add('is-maximized');
  }

  function restoreEntriesModalWindow(modal){
    if(!(modal instanceof HTMLElement)) return;
    modal.classList.remove('is-maximized');
    clearEntriesModalMaximizedFrame(modal);
    void modal.offsetWidth;
    const sheetWindowState = getSheet(getSheetIdFromNode(modal))?.window || {};
    const restoreLeft = readFiniteNumber(modal.dataset.restoreLeft) ?? readFiniteNumber(sheetWindowState.restoreLeft);
    const restoreTop = readFiniteNumber(modal.dataset.restoreTop) ?? readFiniteNumber(sheetWindowState.restoreTop);
    rememberWindowGeometry(modal, { isMaximized: false });

    if(restoreLeft != null && restoreTop != null){
      applyEntriesModalPosition(modal, restoreLeft, restoreTop);
      return;
    }

    positionEntriesModalAtCenter(modal);
  }

  function syncEntriesModalWithinViewport(modal){
    if(!(modal instanceof HTMLElement)) return;
    const sheetWindowState = getSheet(getSheetIdFromNode(modal))?.window || {};
    if(modal.classList.contains('is-maximized') || sheetWindowState.isMaximized){
      modal.classList.add('is-maximized');
      applyEntriesMaximizedFrame(modal);
      return;
    }

    const currentPoint = resolveStoredWindowPoint(modal, sheetWindowState);
    if(currentPoint.left != null && currentPoint.top != null){
      applyEntriesModalPosition(modal, currentPoint.left, currentPoint.top);
      return;
    }

    positionEntriesModalAtCenter(modal);
  }

  function mountTopbarAdaptiveFit(panel){
    return typeof mountAdaptiveToolbarFit === 'function'
      ? mountAdaptiveToolbarFit({
          panel,
          topbarSelector: '.entries-toolbar',
          toolsSelector: '.entries-toolbar__group',
          searchSelector: '.entries-toolbar__search'
        })
      : () => {};
  }

  function isBlockedWindowDragTarget(target){
    return !!target.closest('.entries-sheet__window-actions, button, input, textarea, select, option, a, label, [data-field]');
  }

  function bindEntriesModalDragging({ backdrop, modal, sheetId = '' }){
    const handle = modal.querySelector('.entries-sheet__head');
    if(!(handle instanceof HTMLElement)) return () => {};

    let dragState = null;

    function releaseDragState(event){
      if(!dragState) return;
      if(event && typeof event.pointerId === 'number' && dragState.pointerId !== event.pointerId) return;

      handle.classList.remove('is-grabbing');
      backdrop.classList.remove('is-dragging');
      document.body.classList.remove('entries--dragging-window');
      document.removeEventListener('pointermove', onPointerMove, true);
      document.removeEventListener('pointerup', onPointerUp, true);
      document.removeEventListener('pointercancel', onPointerUp, true);

      try{
        handle.releasePointerCapture(dragState.pointerId);
      }catch{}

      dragState = null;
    }

    function onPointerMove(event){
      if(!dragState || dragState.pointerId !== event.pointerId) return;
      if(modal.classList.contains('is-maximized')){
        releaseDragState(event);
        return;
      }

      const coalescedEvents = typeof event.getCoalescedEvents === 'function' ? event.getCoalescedEvents() : null;
      const moveEvent = coalescedEvents && coalescedEvents.length ? coalescedEvents[coalescedEvents.length - 1] : event;
      const deltaX = moveEvent.clientX - dragState.startX;
      const deltaY = moveEvent.clientY - dragState.startY;
      if(!dragState.hasMoved && Math.hypot(deltaX, deltaY) < 2) return;

      if(!dragState.hasMoved){
        dragState.hasMoved = true;
        handle.classList.add('is-grabbing');
        backdrop.classList.add('is-dragging');
        document.body.classList.add('entries--dragging-window');
      }

      event.preventDefault();
      dragState.nextLeft = clamp(dragState.originLeft + deltaX, dragState.bounds.minLeft, dragState.bounds.maxLeft);
      dragState.nextTop = clamp(dragState.originTop + deltaY, dragState.bounds.minTop, dragState.bounds.maxTop);
      applyEntriesModalPosition(modal, dragState.nextLeft, dragState.nextTop, dragState.bounds);
    }

    function onPointerUp(event){
      releaseDragState(event);
    }

    function onPointerDown(event){
      if(event.button !== 0 || modal.classList.contains('is-maximized')) return;

      const target = event.target;
      if(!(target instanceof Element) || isBlockedWindowDragTarget(target)) return;

      activateSheetWindow(sheetId);
      const rect = modal.getBoundingClientRect();
      const sheetWindowState = getSheet(sheetId)?.window || {};
      const initialPoint = resolveStoredWindowPoint(modal, sheetWindowState, { rect, allowRectFallback: true });

      dragState = {
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        originLeft: initialPoint.left,
        originTop: initialPoint.top,
        nextLeft: initialPoint.left,
        nextTop: initialPoint.top,
        bounds: getEntriesModalViewportBoundsForSize(rect.width, rect.height),
        hasMoved: false
      };

      try{
        handle.setPointerCapture(event.pointerId);
      }catch{}

      event.preventDefault();
      document.removeEventListener('pointermove', onPointerMove, true);
      document.removeEventListener('pointerup', onPointerUp, true);
      document.removeEventListener('pointercancel', onPointerUp, true);
      document.addEventListener('pointermove', onPointerMove, true);
      document.addEventListener('pointerup', onPointerUp, true);
      document.addEventListener('pointercancel', onPointerUp, true);
    }

    handle.addEventListener('pointerdown', onPointerDown);

    return () => {
      handle.removeEventListener('pointerdown', onPointerDown);
      releaseDragState();
    };
  }

  function rememberSheetFocusTarget(target){
    const sheetId = getSheetIdFromNode(target);
    const sheet = getSheet(sheetId);
    if(!sheet || !(target instanceof Element)) return;
    const focusable = target.closest('[data-field], [data-entry-action]');
    if(!(focusable instanceof Element)) return;

    if(focusable.hasAttribute('data-field')){
      sheet.focus = {
        kind: 'field',
        field: focusable.getAttribute('data-field') || ''
      };
      return;
    }

    const action = focusable.getAttribute('data-entry-action');
    if(!action || action === 'expand-sheet' || action === 'close-sheet') return;
    sheet.focus = {
      kind: 'action',
      action
    };
  }

  function resolveSheetFocusElement(scope, sheet){
    if(!sheet || !sheet.focus || !(scope instanceof Element)) return null;
    if(sheet.focus.kind === 'field'){
      return scope.querySelector(`[data-field="${escapeSelectorValue(sheet.focus.field)}"]`);
    }
    if(sheet.focus.kind === 'action'){
      return scope.querySelector(`[data-entry-action="${escapeSelectorValue(sheet.focus.action)}"]`);
    }
    return null;
  }

  function restoreSearchFocus(selectionStart = null, selectionEnd = null){
    const input = runtime.panel?.querySelector?.('[data-entry-action="search"]');
    if(!(input instanceof HTMLInputElement)) return false;
    const focused = focusElementWithoutScroll(input);
    if(typeof input.setSelectionRange === 'function' && typeof selectionStart === 'number'){
      const end = typeof selectionEnd === 'number' ? selectionEnd : selectionStart;
      try{ input.setSelectionRange(selectionStart, end); }catch{}
    }
    return focused;
  }

  function restoreSheetFocus(scope, sheet, formNavigationCleanup = null){
    if(!sheet) return false;
    const target = resolveSheetFocusElement(scope, sheet);
    if(target instanceof HTMLElement){
      if(formNavigationCleanup && typeof formNavigationCleanup.focusTarget === 'function'){
        return formNavigationCleanup.focusTarget(target);
      }
      return focusElementWithoutScroll(target);
    }

    if(sheet.needsInitialFocus && formNavigationCleanup && typeof formNavigationCleanup.focusInitialTarget === 'function'){
      const focused = formNavigationCleanup.focusInitialTarget();
      sheet.needsInitialFocus = false;
      return focused;
    }

    sheet.needsInitialFocus = false;
    return false;
  }

  function bindEntriesSheetChrome({ panel, backdrop, modalWindow, expandButton, closeButton, sheetId = '' }){
    if(!(panel instanceof Element) || !(backdrop instanceof HTMLElement) || !(modalWindow instanceof HTMLElement)) return () => {};

    const sheet = getSheet(sheetId);
    if(!sheet) return () => {};

    const cleanupTasks = [];
    const workbench = panel.querySelector('.entries-workbench');
    let formNavigationCleanup = null;
    let resizeObserver = null;

    const onFocusIn = (event) => {
      rememberSheetFocusTarget(event.target);
      activateSheetWindow(sheetId);
    };
    modalWindow.addEventListener('focusin', onFocusIn, true);
    cleanupTasks.push(() => modalWindow.removeEventListener('focusin', onFocusIn, true));

    if(typeof windowChrome.primeCloseButton === 'function'){
      windowChrome.primeCloseButton(closeButton);
    }
    syncEntriesExpandButton(expandButton, !!sheet.window?.isMaximized || modalWindow.classList.contains('is-maximized'));

    if(typeof windowChrome.bindFormNavigation === 'function'){
      formNavigationCleanup = windowChrome.bindFormNavigation({ root: modalWindow, autoFocus: false });
      cleanupTasks.push(formNavigationCleanup);
    }

    const onClose = (event) => {
      if(event){
        event.preventDefault();
        event.stopPropagation();
      }
      if(typeof feature.closeSheet === 'function') feature.closeSheet(sheetId);
    };

    const toggleExpand = (event) => {
      if(event){
        event.preventDefault();
        event.stopPropagation();
      }
      if(modalWindow.classList.contains('is-maximized')) restoreEntriesModalWindow(modalWindow);
      else maximizeEntriesModalWindow(modalWindow);
      syncEntriesExpandButton(expandButton, modalWindow.classList.contains('is-maximized'));
      requestAnimationFrame(() => restoreSheetFocus(modalWindow, sheet, formNavigationCleanup));
    };

    const stopPointer = (event) => {
      event.stopPropagation();
    };

    const onKeyDown = (event) => {
      if(!isTopmostSheet(sheetId) || !modalWindow.isConnected) return;
      if(event.key === 'Escape'){
        event.preventDefault();
        if(typeof feature.closeSheet === 'function') feature.closeSheet(sheetId);
        return;
      }
      if((event.key === 'F11' || (event.altKey && event.key === 'Enter')) && expandButton){
        event.preventDefault();
        toggleExpand();
      }
    };

    const onResize = () => {
      syncEntriesModalWithinViewport(modalWindow);
    };

    const onActivate = () => {
      activateSheetWindow(sheetId);
    };

    closeButton?.addEventListener('click', onClose);
    closeButton?.addEventListener('pointerdown', stopPointer, true);
    expandButton?.addEventListener('click', toggleExpand);
    expandButton?.addEventListener('pointerdown', stopPointer, true);
    modalWindow.addEventListener('pointerdown', onActivate, true);
    document.addEventListener('keydown', onKeyDown);
    window.addEventListener('resize', onResize, { passive: true });

    cleanupTasks.push(() => closeButton?.removeEventListener('click', onClose));
    cleanupTasks.push(() => closeButton?.removeEventListener('pointerdown', stopPointer, true));
    cleanupTasks.push(() => expandButton?.removeEventListener('click', toggleExpand));
    cleanupTasks.push(() => expandButton?.removeEventListener('pointerdown', stopPointer, true));
    cleanupTasks.push(() => modalWindow.removeEventListener('pointerdown', onActivate, true));
    cleanupTasks.push(() => document.removeEventListener('keydown', onKeyDown));
    cleanupTasks.push(() => window.removeEventListener('resize', onResize));

    if(typeof ResizeObserver === 'function' && workbench instanceof HTMLElement){
      resizeObserver = new ResizeObserver(() => {
        syncEntriesModalWithinViewport(modalWindow);
      });
      resizeObserver.observe(workbench);
      cleanupTasks.push(() => resizeObserver?.disconnect());
    }

    cleanupTasks.push(bindEntriesModalDragging({ backdrop, modal: modalWindow, sheetId }));

    requestAnimationFrame(() => {
      syncEntriesModalWithinViewport(modalWindow);
      applySheetWindowStackState();
      if(!isTopmostSheet(sheetId)) return;
      if(restoreSheetFocus(modalWindow, sheet, formNavigationCleanup)) return;
      focusElementWithoutScroll(modalWindow);
    });

    return () => {
      if(typeof runCleanupCallbacks === 'function'){
        runCleanupCallbacks(cleanupTasks, { clearSource:true });
      } else {
        cleanupTasks.forEach((cleanup) => {
          if(typeof cleanup === 'function') cleanup();
        });
        cleanupTasks.length = 0;
      }
    };
  }

  function cleanupSheetChrome(){
    const cleanups = Array.isArray(runtime.sheetChromeCleanups) ? runtime.sheetChromeCleanups.slice() : [];
    runtime.sheetChromeCleanups = [];
    if(typeof runCleanupCallbacks === 'function'){
      runCleanupCallbacks(cleanups);
      return;
    }
    cleanups.forEach((cleanup) => {
      if(typeof cleanup === 'function') cleanup();
    });
    document.body.classList.remove('entries--dragging-window');
  }

  Object.assign(feature, {
    getEntriesModalLayer,
    renderEntriesModalLayer,
    applySheetWindowStackState,
    activateSheetWindow,
    removeSheet,
    mountTopbarAdaptiveFit,
    restoreSearchFocus,
    bindEntriesSheetChrome,
    cleanupSheetChrome
  });
})();
