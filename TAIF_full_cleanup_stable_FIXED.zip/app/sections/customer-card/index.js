(()=>{
  const TAIF = window.TAIF;
  const api = TAIF && TAIF.customerCard ? TAIF.customerCard : null;
  if(!TAIF || !api) return;

  const escapeHtml = typeof TAIF?.core?.utils?.escapeHtml === 'function'
    ? TAIF.core.utils.escapeHtml
    : (value) => String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');

  const escapeSelectorValue = typeof TAIF?.core?.utils?.escapeSelectorValue === 'function'
    ? TAIF.core.utils.escapeSelectorValue
    : (value) => String(value ?? '').replace(/\\/g, '\\\\').replace(/"/g, '\\"');

  const windowChrome = TAIF?.ui?.windowChrome || {};
  const dateSystem = TAIF?.ui?.dateSystem || {};
  const flowSystem = TAIF?.ui?.flow || {};
  const bindWindowChromeFormNavigation = typeof windowChrome.bindFormNavigation === 'function'
    ? windowChrome.bindFormNavigation
    : null;
  const focusWindowChromeElement = typeof windowChrome.focusElement === 'function'
    ? windowChrome.focusElement
    : null;
  const getPhoneCountryCatalog = typeof api.getPhoneCountryCatalog === 'function'
    ? api.getPhoneCountryCatalog
    : (() => []);
  const getPhoneCountryMeta = typeof api.getPhoneCountryMeta === 'function'
    ? api.getPhoneCountryMeta
    : (() => null);
  const composePhoneDisplay = typeof api.composePhoneDisplay === 'function'
    ? api.composePhoneDisplay
    : ((input) => String(input?.phone || '').trim());

  function normalizeCustomerCardFlow(root){
    if(root instanceof Element && typeof flowSystem.normalizeRoot === 'function'){
      try{ flowSystem.normalizeRoot(root); }catch{}
    }
  }

  const OPTION_FIELD_OPTION_KEYS = Object.freeze({
    gender:'genders',
    entityType:'entityTypes',
    idType:'idTypes'
  });

  const DATE_PICKER_MONTH_NAMES = Array.isArray(TAIF?.core?.constants?.datePickerMonthNames)
    ? TAIF.core.constants.datePickerMonthNames
    : ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];

  const DATE_PICKER_WEEKDAY_LABELS = Array.isArray(TAIF?.core?.constants?.datePickerWeekdayLabels)
    ? TAIF.core.constants.datePickerWeekdayLabels
    : ['ح', 'ن', 'ث', 'ر', 'خ', 'ج', 'س'];

  const runtime = {
    panel: null,
    state: api.readState(),
    records: api.readRecords(),
    detachPanelEvents: null,
    detachFormNavigation: null,
    deleteConfirmCleanup: null,
    lastAddedRecordId: '',
    searchQuery: '',
    selectedRecordId: '',
    editingRecordId: '',
    openChoiceField: '',
    phoneCountrySearchQuery: '',
    openDateField: '',
    datePickerMonthCursor: '',
    datePickerView: 'days',
    dateInputDrafts: Object.create(null),
    isFormDialogOpen: false,
    isDialogMaximized: false
  };

  const SEARCH_CLEAR_ICON = `
    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <path d="M18 6 6 18M6 6l12 12" fill="none" stroke="currentColor" stroke-width="2.35" stroke-linecap="round" stroke-linejoin="round"></path>
    </svg>
  `;

  const CHOICE_PICKER_CHEVRON_ICON = '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m5.25 7.5 4.75 5 4.75-5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
  const DATE_PICKER_ICON_MARKUP = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M7 3v3M17 3v3M4 9h16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><rect x="4" y="5" width="16" height="15" rx="3" fill="none" stroke="currentColor" stroke-width="2"></rect></svg>';
  const DATE_PICKER_CHEVRON_PREV_MARKUP = '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m12.5 4.5-5 5 5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
  const DATE_PICKER_CHEVRON_NEXT_MARKUP = '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m7.5 4.5 5 5-5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>';

  const FIELD_KEYS = (Array.isArray(api.groups) ? api.groups : []).flatMap((group) => Array.isArray(group.fields) ? group.fields.map((field) => String(field?.key || '').trim()).filter(Boolean) : []);
  const PHONE_COUNTRY_FIELD_KEY = 'phoneCountryCode';

  function getFieldRenderKey(fieldKey){
    const safeFieldKey = String(fieldKey || '').trim();
    return safeFieldKey === PHONE_COUNTRY_FIELD_KEY ? 'phone' : safeFieldKey;
  }

  function normalizePhoneCountrySearch(value){
    return String(value ?? '').toLowerCase().replace(/\s+/g, ' ').trim();
  }

  function getPhoneCountryOptions(){
    const query = normalizePhoneCountrySearch(runtime.phoneCountrySearchQuery);
    const catalog = Array.isArray(getPhoneCountryCatalog()) ? getPhoneCountryCatalog() : [];
    if(!query) return catalog;
    return catalog.filter((entry) => normalizePhoneCountrySearch(entry?.searchText || `${entry?.label || ''} ${entry?.dialCode || ''} ${entry?.englishLabel || ''} ${entry?.code || ''}`).includes(query));
  }

  function createPhoneCountryFlagMarkup(option){
    const code = String(option?.code || '').trim().toLowerCase();
    if(!code) return '<span class="customer-card-phone-country__flag customer-card-phone-country__flag--placeholder" aria-hidden="true">+</span>';
    return `<span class="customer-card-phone-country__flag" aria-hidden="true"><img class="customer-card-phone-country__flag-image" src="assets/flags/circle/${escapeHtml(code)}.png" alt="" draggable="false" loading="eager" decoding="async" width="18" height="18"></span>`;
  }

  function createPhoneCountryOptionMarkup(option, activeCountryCode){
    const safeCode = String(option?.code || '').trim();
    const isActive = safeCode === String(activeCountryCode || '').trim();
    const accessibleLabel = [option?.label || option?.englishLabel || option?.code || '', option?.dialCode || ''].filter(Boolean).join(' ');
    return `
      <button class="entries-voucher-choice-popover__option customer-card-phone-country__option${isActive ? ' is-active' : ''}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-taif-inline-picker-option="true" role="option" data-customer-card-choice-action="select" data-customer-card-choice-field="${PHONE_COUNTRY_FIELD_KEY}" data-customer-card-choice-value="${escapeHtml(option?.code || '')}" aria-selected="${isActive ? 'true' : 'false'}" aria-label="اختيار ${escapeHtml(accessibleLabel)}">
        <span class="customer-card-phone-country__option-leading">${createPhoneCountryFlagMarkup(option)}</span>
        <span class="customer-card-phone-country__option-code" dir="ltr">${escapeHtml(option?.dialCode || '')}</span>
      </button>
    `;
  }

  function renderPhoneCountryOptionsMarkup(activeCountryCode){
    const options = getPhoneCountryOptions();
    if(!options.length) return '<div class="entries-voucher-choice-popover__empty">لا توجد دول مطابقة للبحث الحالي.</div>';
    return options.map((option) => createPhoneCountryOptionMarkup(option, activeCountryCode)).join('');
  }

  function updatePhoneCountrySearchControls(){
    if(!(runtime.panel instanceof HTMLElement)) return;
    const input = runtime.panel.querySelector('[data-customer-card-phone-country-search="true"]');
    const clearButton = runtime.panel.querySelector('[data-customer-card-phone-country-search-action="clear"]');
    const searchValue = String(runtime.phoneCountrySearchQuery || '');
    if(input instanceof HTMLInputElement && input.value !== searchValue){
      input.value = searchValue;
    }
    if(clearButton instanceof HTMLButtonElement){
      clearButton.hidden = !searchValue;
      clearButton.setAttribute('aria-hidden', searchValue ? 'false' : 'true');
    }
  }

  function renderPhoneCountryTriggerValue(option){
    if(!option){
      return `
        <span class="customer-card-phone-country__trigger-content is-placeholder">
          <span class="customer-card-phone-country__trigger-label">النداء</span>
        </span>
      `;
    }
    return `
      <span class="customer-card-phone-country__trigger-content">
        ${createPhoneCountryFlagMarkup(option)}
        <span class="customer-card-phone-country__trigger-code" dir="ltr">${escapeHtml(option.dialCode || '')}</span>
      </span>
    `;
  }

  function safeOptions(optionsKey){
    const source = api.options && Object.prototype.hasOwnProperty.call(api.options, optionsKey)
      ? api.options[optionsKey]
      : [];
    return Array.isArray(source) ? source : [];
  }

  function safeGroups(){
    return Array.isArray(api.groups) ? api.groups : [];
  }

  function getFieldDefinition(fieldKey){
    const safeKey = String(fieldKey || '').trim();
    if(!safeKey) return null;
    for(const group of safeGroups()){
      const fields = Array.isArray(group.fields) ? group.fields : [];
      const field = fields.find((entry) => String(entry?.key || '').trim() === safeKey);
      if(field) return field;
    }
    return null;
  }

  function todayInputValue(){
    return typeof dateSystem.todayIsoDate === 'function' ? dateSystem.todayIsoDate() : toDatePickerIsoDate(new Date());
  }

  function parseDatePickerIsoDate(value){
    if(typeof dateSystem.parseIsoDate === 'function') return dateSystem.parseIsoDate(value);
    const safeValue = String(value || '').trim();
    if(!/^\d{4}-\d{2}-\d{2}$/.test(safeValue)) return null;
    const [year, month, day] = safeValue.split('-').map((part) => Number(part));
    const date = new Date(year, month - 1, day);
    if(Number.isNaN(date.getTime())) return null;
    if(date.getFullYear() !== year || date.getMonth() !== (month - 1) || date.getDate() !== day) return null;
    return date;
  }

  function parseDatePickerMonthCursor(value){
    if(typeof dateSystem.parseMonthCursor === 'function') return dateSystem.parseMonthCursor(value);
    const safeValue = String(value || '').trim();
    if(!/^\d{4}-\d{2}$/.test(safeValue)) return null;
    const [year, month] = safeValue.split('-').map((part) => Number(part));
    if(!Number.isInteger(year) || !Number.isInteger(month) || month < 1 || month > 12) return null;
    return { year, monthIndex: month - 1 };
  }

  function toDatePickerIsoDate(date){
    if(typeof dateSystem.toIsoDate === 'function') return dateSystem.toIsoDate(date);
    if(!(date instanceof Date) || Number.isNaN(date.getTime())) return todayInputValue();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function toDatePickerMonthCursor(date){
    if(typeof dateSystem.toMonthCursor === 'function') return dateSystem.toMonthCursor(date);
    if(!(date instanceof Date) || Number.isNaN(date.getTime())) return todayInputValue().slice(0, 7);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
  }

  function normalizeDatePickerView(value){
    return typeof dateSystem.normalizePickerView === 'function' ? dateSystem.normalizePickerView(value) : (String(value || '').trim() === 'month-year' ? 'month-year' : 'days');
  }

  function shiftDatePickerMonthCursor(value, offset = 0){
    if(typeof dateSystem.shiftMonthCursor === 'function') return dateSystem.shiftMonthCursor(value, offset);
    const parsed = parseDatePickerMonthCursor(value) || parseDatePickerMonthCursor(todayInputValue().slice(0, 7));
    const date = new Date(parsed.year, parsed.monthIndex + Number(offset || 0), 1);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
  }

  function resolveDatePickerMonthCursor(fieldKey, selectedValue){
    const safeFieldKey = String(fieldKey || '').trim();
    if(runtime.openDateField === safeFieldKey){
      const openCursor = parseDatePickerMonthCursor(runtime.datePickerMonthCursor);
      if(openCursor) return runtime.datePickerMonthCursor;
    }
    const selectedDate = parseDatePickerIsoDate(selectedValue);
    return toDatePickerMonthCursor(selectedDate || new Date());
  }

  function getDatePickerDisplayParts(value){
    return typeof dateSystem.getDisplayParts === 'function'
      ? dateSystem.getDisplayParts(value)
      : Object.freeze({ day: '--', month: '--', year: '----' });
  }

  function getDateInputDraft(fieldKey, value = ''){
    const safeFieldKey = String(fieldKey || '').trim();
    const stored = safeFieldKey ? runtime.dateInputDrafts[safeFieldKey] : null;
    if(stored && typeof stored === 'object'){
      return {
        day: String(stored.day || ''),
        month: String(stored.month || ''),
        year: String(stored.year || '')
      };
    }
    const parsed = parseDatePickerIsoDate(value);
    return {
      day: parsed ? String(parsed.getDate()).padStart(2, '0') : '',
      month: parsed ? String(parsed.getMonth() + 1).padStart(2, '0') : '',
      year: parsed ? String(parsed.getFullYear()) : ''
    };
  }

  function sanitizeDateInputPart(partKey, value){
    const digits = String(value || '').replace(/\D+/g, '');
    if(partKey === 'year') return digits.slice(0, 4);
    return digits.slice(0, 2);
  }

  function composeIsoDateFromDraft(draft){
    const day = String(draft?.day || '').trim();
    const month = String(draft?.month || '').trim();
    const year = String(draft?.year || '').trim();
    if(!day && !month && !year) return '';
    if(day.length !== 2 || month.length !== 2 || year.length !== 4) return null;
    const iso = `${year}-${month}-${day}`;
    return parseDatePickerIsoDate(iso) ? iso : null;
  }

  function setDateInputDraftValue(fieldKey, partKey, value){
    const safeFieldKey = String(fieldKey || '').trim();
    const safePartKey = String(partKey || '').trim();
    if(!safeFieldKey || !safePartKey) return;
    const draft = getDateInputDraft(safeFieldKey, runtime.state?.[safeFieldKey] || '');
    draft[safePartKey] = sanitizeDateInputPart(safePartKey, value);
    runtime.dateInputDrafts[safeFieldKey] = draft;

    const nextIso = composeIsoDateFromDraft(draft);
    if(nextIso === ''){
      delete runtime.dateInputDrafts[safeFieldKey];
      commitField(safeFieldKey, '');
      return;
    }
    if(nextIso){
      delete runtime.dateInputDrafts[safeFieldKey];
      commitField(safeFieldKey, nextIso);
      if(runtime.openDateField === safeFieldKey){
        runtime.datePickerMonthCursor = nextIso.slice(0, 7);
      }
    }
  }

  function renderDatePickerTriggerValue(value){
    const parts = getDatePickerDisplayParts(value);
    return `
      <span class="entries-voucher-date__trigger-date" aria-hidden="true">
        <span class="entries-voucher-date__trigger-part entries-voucher-date__trigger-part--day">${escapeHtml(parts.day)}</span>
        <span class="entries-voucher-date__trigger-sep" aria-hidden="true">/</span>
        <span class="entries-voucher-date__trigger-part entries-voucher-date__trigger-part--month">${escapeHtml(parts.month)}</span>
        <span class="entries-voucher-date__trigger-sep" aria-hidden="true">/</span>
        <span class="entries-voucher-date__trigger-part entries-voucher-date__trigger-part--year">${escapeHtml(parts.year)}</span>
      </span>
    `;
  }

  function formatDatePickerMonthLabel(monthCursor){
    return typeof dateSystem.formatMonthLabel === 'function'
      ? dateSystem.formatMonthLabel(monthCursor, DATE_PICKER_MONTH_NAMES)
      : String(monthCursor || '').trim();
  }

  function buildDatePickerCells(monthCursor, selectedValue){
    return typeof dateSystem.buildCalendarCells === 'function' ? dateSystem.buildCalendarCells(monthCursor, selectedValue) : [];
  }

  function buildDatePickerMonthChoices(monthCursor){
    return typeof dateSystem.buildMonthChoices === 'function' ? dateSystem.buildMonthChoices(monthCursor, DATE_PICKER_MONTH_NAMES) : [];
  }

  function isChoicePickerOpen(fieldKey){
    return String(runtime.openChoiceField || '').trim() === String(fieldKey || '').trim();
  }

  function isDatePickerOpen(fieldKey){
    return String(runtime.openDateField || '').trim() === String(fieldKey || '').trim();
  }

  function createSegmentedMarkup(field, value){
    const safeFieldKey = escapeHtml(field.key);
    const safeValue = String(value || '').trim();
    const options = safeOptions(field.optionsKey);
    const activeIndex = options.findIndex((option) => String(option?.value || '').trim() === safeValue);
    const focusIndex = activeIndex >= 0 ? activeIndex : 0;
    const optionsMarkup = options.map((option, index) => {
      const optionValue = String(option.value || '').trim();
      const isActive = optionValue === safeValue;
      const isTabStop = index === focusIndex;
      return `
        <button class="customer-card-segmented__option${isActive ? ' is-active' : ''}" type="button" role="radio" data-taif-flow-item="${isTabStop ? 'true' : 'false'}" data-customer-card-segment="${escapeHtml(optionValue)}" aria-checked="${isActive ? 'true' : 'false'}" tabindex="${isTabStop ? '0' : '-1'}">
          ${escapeHtml(option.label || optionValue || '—')}
        </button>
      `;
    }).join('');

    return `
      <div class="customer-card-segmented" data-customer-card-segmented-field="${safeFieldKey}" role="radiogroup" aria-label="${escapeHtml(field.label)}">
        ${optionsMarkup}
      </div>
    `;
  }

  function renderChoicePickerValueMarkup(option, { placeholder = '' } = {}){
    if(!option){
      return `<span class="entries-voucher-choice-picker__placeholder">${escapeHtml(placeholder || '')}</span>`;
    }
    return `<span class="entries-voucher-choice-picker__text">${escapeHtml(option.label || option.value || '')}</span>`;
  }

  function createChoicePickerMarkup(field, value){
    const safeFieldKey = String(field.key || '').trim();
    const safeValue = String(value || '').trim();
    const options = safeOptions(field.optionsKey).map((option) => ({
      value: String(option?.value || '').trim(),
      label: String(option?.label || option?.value || '').trim()
    }));
    const activeOption = options.find((option) => option.value === safeValue) || null;
    const isOpen = isChoicePickerOpen(safeFieldKey);
    const listboxId = `customer-card-choice-${escapeHtml(safeFieldKey)}`;
    const placeholder = String(field.placeholder || field.label || '').trim();
    const listContent = options.length
      ? options.map((option) => {
          const isActive = option.value === safeValue;
          return `
            <button class="entries-voucher-choice-popover__option${isActive ? ' is-active' : ''}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-taif-inline-picker-option="true" role="option" data-customer-card-choice-action="select" data-customer-card-choice-field="${escapeHtml(safeFieldKey)}" data-customer-card-choice-value="${escapeHtml(option.value)}" aria-selected="${isActive ? 'true' : 'false'}" aria-label="اختيار ${escapeHtml(option.label)}">
              <span class="entries-voucher-choice-popover__label" data-taif-dropdown-label="true">${renderChoicePickerValueMarkup(option)}</span>
            </button>
          `;
        }).join('')
      : '<div class="entries-voucher-choice-popover__empty">لا يوجد عناصر متاحة.</div>';

    return `
      <div class="customer-card-field__control-wrap customer-card-field__control-wrap--picker">
        <div class="entries-voucher-choice-picker${isOpen ? ' is-open' : ''}" data-customer-card-choice-picker="${escapeHtml(safeFieldKey)}" data-taif-inline-picker-host="true">
          <button class="customer-card-field__control customer-card-field__control--picker entries-voucher-choice-picker__trigger" type="button" data-taif-picker-trigger="true" data-taif-flow-item="true" data-customer-card-choice-trigger="true" data-customer-card-choice-field="${escapeHtml(safeFieldKey)}" aria-label="${escapeHtml(field.label)}" aria-haspopup="listbox" aria-controls="${listboxId}" aria-expanded="${isOpen ? 'true' : 'false'}">
            <span class="entries-voucher-choice-picker__value${activeOption ? '' : ' is-placeholder'}">${renderChoicePickerValueMarkup(activeOption, { placeholder })}</span>
            <span class="entries-voucher-choice-picker__icon" aria-hidden="true">${CHOICE_PICKER_CHEVRON_ICON}</span>
          </button>
          <div class="entries-voucher-choice-popover" data-taif-dropdown-popup="true" data-taif-dropdown-layout="list" id="${listboxId}" role="listbox" aria-label="${escapeHtml(field.label)}"${isOpen ? '' : ' hidden'}>${listContent}</div>
        </div>
      </div>
    `;
  }

  function renderDatePickerDayButton(fieldKey, cell){
    const classes = [
      'entries-voucher-date__day',
      cell.outsideMonth ? 'is-outside' : '',
      cell.isToday ? 'is-today' : '',
      cell.isSelected ? 'is-selected' : ''
    ].filter(Boolean).join(' ');
    return `
      <button class="${classes}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="grid" data-customer-card-date-action="select-day" data-customer-card-date-field="${escapeHtml(fieldKey)}" data-customer-card-date-value="${escapeHtml(cell.value)}" aria-pressed="${cell.isSelected ? 'true' : 'false'}" aria-label="اختيار التاريخ ${escapeHtml(cell.value)}">
        <span dir="ltr">${escapeHtml(cell.label)}</span>
      </button>
    `;
  }

  function renderDatePickerMonthButton(fieldKey, monthChoice){
    const classes = [
      'entries-voucher-date__month',
      monthChoice.isActive ? 'is-active' : ''
    ].filter(Boolean).join(' ');
    return `
      <button class="${classes}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="grid" data-customer-card-date-action="pick-month" data-customer-card-date-field="${escapeHtml(fieldKey)}" data-customer-card-date-month="${escapeHtml(monthChoice.monthCursor)}" aria-pressed="${monthChoice.isActive ? 'true' : 'false'}" aria-label="اختيار شهر ${escapeHtml(monthChoice.label)}">
        <span>${escapeHtml(monthChoice.label)}</span>
      </button>
    `;
  }

  function createDatePickerMarkup(field, value){
    const safeFieldKey = String(field.key || '').trim();
    const safeValue = String(value || '').trim();
    const isOpen = isDatePickerOpen(safeFieldKey);
    const monthCursor = resolveDatePickerMonthCursor(safeFieldKey, safeValue);
    const view = isOpen ? normalizeDatePickerView(runtime.datePickerView) : 'days';
    const isMonthYearView = view === 'month-year';
    const cells = buildDatePickerCells(monthCursor, safeValue);
    const monthChoices = buildDatePickerMonthChoices(monthCursor);
    const todayValue = todayInputValue();
    const currentMonth = parseDatePickerMonthCursor(monthCursor) || parseDatePickerMonthCursor(toDatePickerMonthCursor(new Date()));
    const currentYearLabel = String(currentMonth?.year || new Date().getFullYear());
    const dateDraft = getDateInputDraft(safeFieldKey, safeValue);

    return `
      <div class="customer-card-field__control-wrap customer-card-field__control-wrap--picker">
        <div class="entries-voucher-date${isOpen ? ' is-open' : ''}" data-customer-card-date-picker="${escapeHtml(safeFieldKey)}">
          <div class="customer-card-field__control customer-card-field__control--date-shell entries-voucher-date__trigger">
            <div class="entries-voucher-date__manual" data-customer-card-date-manual="true">
              <input class="entries-voucher-date__manual-input entries-voucher-date__manual-input--day" type="text" value="${escapeHtml(dateDraft.day)}" placeholder="يوم" inputmode="numeric" autocomplete="off" dir="ltr" data-taif-flow-item="true" data-customer-card-date-part="day" data-customer-card-date-field="${escapeHtml(safeFieldKey)}" aria-label="يوم ${escapeHtml(field.label)}">
              <span class="entries-voucher-date__manual-sep" aria-hidden="true">/</span>
              <input class="entries-voucher-date__manual-input entries-voucher-date__manual-input--month" type="text" value="${escapeHtml(dateDraft.month)}" placeholder="شهر" inputmode="numeric" autocomplete="off" dir="ltr" data-taif-flow-item="true" data-customer-card-date-part="month" data-customer-card-date-field="${escapeHtml(safeFieldKey)}" aria-label="شهر ${escapeHtml(field.label)}">
              <span class="entries-voucher-date__manual-sep" aria-hidden="true">/</span>
              <input class="entries-voucher-date__manual-input entries-voucher-date__manual-input--year" type="text" value="${escapeHtml(dateDraft.year)}" placeholder="سنة" inputmode="numeric" autocomplete="off" dir="ltr" data-taif-flow-item="true" data-customer-card-date-part="year" data-customer-card-date-field="${escapeHtml(safeFieldKey)}" aria-label="سنة ${escapeHtml(field.label)}">
            </div>
            <button class="entries-voucher-date__trigger-icon-btn" type="button" data-taif-picker-trigger="true" data-taif-flow-item="true" data-customer-card-date-trigger="true" data-customer-card-date-field="${escapeHtml(safeFieldKey)}" aria-label="فتح لوحة ${escapeHtml(field.label)}" aria-haspopup="dialog" aria-expanded="${isOpen ? 'true' : 'false'}">
              <span class="entries-voucher-date__trigger-icon" aria-hidden="true">${DATE_PICKER_ICON_MARKUP}</span>
            </button>
          </div>
          ${isOpen ? `
            <div class="entries-voucher-date__popover" data-taif-dropdown-popup="true" data-taif-dropdown-layout="calendar" role="dialog" aria-label="اختيار التاريخ">
              ${isMonthYearView ? `
                <div class="entries-voucher-date__header entries-voucher-date__header--month-year">
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-customer-card-date-action="prev-year" data-customer-card-date-field="${escapeHtml(safeFieldKey)}" aria-label="السنة السابقة">${DATE_PICKER_CHEVRON_NEXT_MARKUP}</button>
                  <button class="entries-voucher-date__heading-trigger entries-voucher-date__heading-trigger--current" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-customer-card-date-action="toggle-view" data-customer-card-date-field="${escapeHtml(safeFieldKey)}" data-customer-card-date-view="days" aria-label="الرجوع إلى أيام الشهر">
                    <span dir="ltr">${escapeHtml(currentYearLabel)}</span>
                  </button>
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-customer-card-date-action="next-year" data-customer-card-date-field="${escapeHtml(safeFieldKey)}" aria-label="السنة التالية">${DATE_PICKER_CHEVRON_PREV_MARKUP}</button>
                </div>
                <div class="entries-voucher-date__month-panel">
                  <div class="entries-voucher-date__month-grid">
                    ${monthChoices.map((monthChoice) => renderDatePickerMonthButton(safeFieldKey, monthChoice)).join('')}
                  </div>
                </div>
                <div class="entries-voucher-date__footer">
                  <button class="entries-voucher-date__footer-btn" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-customer-card-date-action="toggle-view" data-customer-card-date-field="${escapeHtml(safeFieldKey)}" data-customer-card-date-view="days">رجوع للتقويم</button>
                  <button class="entries-voucher-date__footer-btn entries-voucher-date__footer-btn--ghost" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-customer-card-date-action="close" data-customer-card-date-field="${escapeHtml(safeFieldKey)}">إغلاق</button>
                </div>
              ` : `
                <div class="entries-voucher-date__header">
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-customer-card-date-action="prev-month" data-customer-card-date-field="${escapeHtml(safeFieldKey)}" aria-label="الشهر السابق">${DATE_PICKER_CHEVRON_NEXT_MARKUP}</button>
                  <button class="entries-voucher-date__heading-trigger" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-customer-card-date-action="toggle-view" data-customer-card-date-field="${escapeHtml(safeFieldKey)}" data-customer-card-date-view="month-year" aria-label="تغيير الشهر أو السنة">${escapeHtml(formatDatePickerMonthLabel(monthCursor))}</button>
                  <button class="entries-voucher-date__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-customer-card-date-action="next-month" data-customer-card-date-field="${escapeHtml(safeFieldKey)}" aria-label="الشهر التالي">${DATE_PICKER_CHEVRON_PREV_MARKUP}</button>
                </div>
                <div class="entries-voucher-date__weekdays" aria-hidden="true">
                  ${DATE_PICKER_WEEKDAY_LABELS.map((label) => `<span>${escapeHtml(label)}</span>`).join('')}
                </div>
                <div class="entries-voucher-date__grid">
                  ${cells.map((cell) => renderDatePickerDayButton(safeFieldKey, cell)).join('')}
                </div>
                <div class="entries-voucher-date__footer">
                  <button class="entries-voucher-date__footer-btn" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-customer-card-date-action="today" data-customer-card-date-field="${escapeHtml(safeFieldKey)}" data-customer-card-date-value="${escapeHtml(todayValue)}">اليوم</button>
                  <button class="entries-voucher-date__footer-btn entries-voucher-date__footer-btn--ghost" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-customer-card-date-action="clear" data-customer-card-date-field="${escapeHtml(safeFieldKey)}">مسح</button>
                  <button class="entries-voucher-date__footer-btn entries-voucher-date__footer-btn--ghost" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-customer-card-date-action="close" data-customer-card-date-field="${escapeHtml(safeFieldKey)}">إغلاق</button>
                </div>
              `}
            </div>
          ` : ''}
        </div>
      </div>
    `;
  }

  function createPhoneFieldMarkup(field, state){
    const phoneValue = state && Object.prototype.hasOwnProperty.call(state, 'phone') ? String(state.phone || '') : '';
    const countryValue = state && Object.prototype.hasOwnProperty.call(state, PHONE_COUNTRY_FIELD_KEY) ? String(state[PHONE_COUNTRY_FIELD_KEY] || '') : '';
    const activeCountry = getPhoneCountryMeta(countryValue);
    const isOpen = isChoicePickerOpen(PHONE_COUNTRY_FIELD_KEY);
    const listboxId = 'customer-card-phone-country-listbox';
    const searchValue = String(runtime.phoneCountrySearchQuery || '');
    const optionsMarkup = renderPhoneCountryOptionsMarkup(countryValue);

    return `
      <div class="customer-card-phone-field" data-customer-card-phone-field="true">
        <div class="customer-card-phone-field__picker customer-card-field__control-wrap customer-card-field__control-wrap--picker">
          <div class="entries-voucher-choice-picker${isOpen ? ' is-open' : ''}" data-customer-card-choice-picker="${PHONE_COUNTRY_FIELD_KEY}" data-taif-inline-picker-host="true" data-taif-flow-skip="true">
            <button class="customer-card-field__control customer-card-field__control--picker customer-card-phone-country__trigger" type="button" data-taif-flow-skip="true" tabindex="-1" data-customer-card-choice-trigger="true" data-customer-card-choice-field="${PHONE_COUNTRY_FIELD_KEY}" aria-label="اختيار نداء الدولة" aria-haspopup="listbox" aria-controls="${listboxId}" aria-expanded="${isOpen ? 'true' : 'false'}">
              ${renderPhoneCountryTriggerValue(activeCountry)}
              <span class="entries-voucher-choice-picker__icon" aria-hidden="true">${CHOICE_PICKER_CHEVRON_ICON}</span>
            </button>
            <div class="entries-voucher-choice-popover customer-card-phone-country__popover" data-taif-dropdown-popup="true" data-taif-dropdown-layout="list"${isOpen ? '' : ' hidden'}>
              <div class="customer-card-phone-country__search-wrap">
                <input class="customer-card-phone-country__search${searchValue ? "" : " is-empty"}" type="text" value="${escapeHtml(searchValue)}" data-customer-card-phone-country-search="true" placeholder="دولة / النداء" autocomplete="off" autocapitalize="off" inputmode="search" enterkeyhint="search" dir="auto" spellcheck="false" aria-label="بحث نداء الدولة">
                <button class="entries-search__clear customer-card-phone-country__search-clear" type="button" data-customer-card-phone-country-search-action="clear" data-taif-clear-control="true" aria-label="مسح بحث نداء الدولة"${searchValue ? '' : ' hidden'}>${SEARCH_CLEAR_ICON}</button>
              </div>
              <div class="customer-card-phone-country__options" data-customer-card-phone-country-options="true" id="${listboxId}" role="listbox" aria-label="قائمة نداءات الدول">
                ${optionsMarkup}
              </div>
            </div>
          </div>
        </div>
        <input class="customer-card-field__control customer-card-phone-field__number" type="tel" value="${escapeHtml(phoneValue)}" data-customer-card-field="phone" aria-label="${escapeHtml(field.label)}" placeholder="${escapeHtml(field.placeholder || 'رقم الهاتف')}" autocomplete="tel" inputmode="tel" dir="ltr" spellcheck="false" maxlength="18">
      </div>
    `;
  }

  function createInputMarkup(field, value){
    const type = String(field.type || 'text').trim() || 'text';
    const safeValue = value == null ? '' : String(value);
    const safeLabel = escapeHtml(field.label);
    const inputMode = field.inputMode ? ` inputmode="${escapeHtml(field.inputMode)}"` : '';
    const dir = field.dir ? ` dir="${escapeHtml(field.dir)}"` : '';
    const autoComplete = field.autoComplete ? ` autocomplete="${escapeHtml(field.autoComplete)}"` : ' autocomplete="off"';
    const placeholder = field.placeholder ? ` placeholder="${escapeHtml(field.placeholder)}"` : '';

    if(field.control === 'textarea'){
      const rows = Math.max(3, Number(field.rows) || 4);
      return `
        <textarea class="customer-card-field__control customer-card-field__control--textarea" rows="${escapeHtml(String(rows))}" data-customer-card-field="${escapeHtml(field.key)}" aria-label="${safeLabel}"${placeholder}>${escapeHtml(safeValue)}</textarea>
      `;
    }

    const initialFocus = field.key === 'fullName' ? ' data-taif-initial-focus="true"' : '';

    return `
      <input class="customer-card-field__control" type="${escapeHtml(type)}" value="${escapeHtml(safeValue)}" data-customer-card-field="${escapeHtml(field.key)}" aria-label="${safeLabel}"${placeholder}${autoComplete}${inputMode}${dir}${initialFocus} spellcheck="false">
    `;
  }

  function createFieldMarkup(field, state){
    const value = state && Object.prototype.hasOwnProperty.call(state, field.key) ? state[field.key] : '';
    let controlMarkup = '';

    if(field.control === 'segmented') controlMarkup = createSegmentedMarkup(field, value);
    else if(field.control === 'phone') controlMarkup = createPhoneFieldMarkup(field, state);
    else if(field.control === 'select') controlMarkup = createChoicePickerMarkup(field, value);
    else if(String(field.type || '').trim() === 'date') controlMarkup = createDatePickerMarkup(field, value);
    else controlMarkup = createInputMarkup(field, value);

    return `
      <div class="customer-card-field${field.span === 'full' ? ' customer-card-field--full' : ''}" data-customer-card-field-wrap="${escapeHtml(field.key)}">
        <span class="customer-card-field__label">${escapeHtml(field.label)}</span>
        ${controlMarkup}
      </div>
    `;
  }

  function splitGroupFields(fields){
    const inlineRows = [];
    const inlineRowMap = new Map();
    const gridFields = [];

    fields.forEach((field) => {
      const rowKey = String(field?.row || '').trim();
      if(!rowKey){
        gridFields.push(field);
        return;
      }
      if(!inlineRowMap.has(rowKey)){
        const row = { key: rowKey, fields: [] };
        inlineRowMap.set(rowKey, row);
        inlineRows.push(row);
      }
      inlineRowMap.get(rowKey).fields.push(field);
    });

    return { inlineRows, gridFields };
  }

  function createInlineRowMarkup(row, state){
    const fields = Array.isArray(row?.fields) ? row.fields : [];
    if(!fields.length) return '';
    return `
      <div class="customer-card-group__row" data-customer-card-row="${escapeHtml(row.key || '')}">
        ${fields.map((field) => createFieldMarkup(field, state)).join('')}
      </div>
    `;
  }

  function createGroupMarkup(group, state){
    const fields = Array.isArray(group.fields) ? group.fields : [];
    const { inlineRows, gridFields } = splitGroupFields(fields);
    return `
      <section class="customer-card-group" aria-labelledby="customer-card-group-${escapeHtml(group.key)}">
        <div class="customer-card-group__head">
          <h2 id="customer-card-group-${escapeHtml(group.key)}" class="customer-card-group__title">${escapeHtml(group.title || '')}</h2>
        </div>
        ${inlineRows.map((row) => createInlineRowMarkup(row, state)).join('')}
        ${gridFields.length ? `<div class="customer-card-group__grid">${gridFields.map((field) => createFieldMarkup(field, state)).join('')}</div>` : ''}
      </section>
    `;
  }

  function resolveOptionLabel(fieldKey, value){
    const optionsKey = OPTION_FIELD_OPTION_KEYS[fieldKey] || '';
    return optionsKey ? (api.findOptionLabel(optionsKey, value) || '—') : (String(value || '').trim() || '—');
  }

  function joinDisplayParts(parts, separator = ' · '){
    return parts.map((part) => String(part || '').trim()).filter(Boolean).join(separator);
  }

  function resolveRecordDisplayName(record){
    const explicitName = String(record?.fullName || '').trim();
    if(explicitName) return explicitName;
    const idNumber = String(record?.idNumber || '').trim();
    if(idNumber) return `عميل ${idNumber}`;
    const phone = composePhoneDisplay(record);
    if(phone) return `عميل ${phone}`;
    return 'عميل جديد';
  }

  function formatIsoDate(value){
    return typeof dateSystem.formatSlashDate === 'function' ? dateSystem.formatSlashDate(value, '—') : '—';
  }

  function formatTimestamp(value){
    const timestamp = Number(value);
    if(!Number.isFinite(timestamp) || timestamp <= 0) return '—';
    try{
      return new Intl.DateTimeFormat('ar-EG', {
        year:'numeric',
        month:'2-digit',
        day:'2-digit',
        hour:'2-digit',
        minute:'2-digit'
      }).format(new Date(timestamp));
    }catch{
      return new Date(timestamp).toLocaleString();
    }
  }

  function composeIdentityText(record){
    const idLabel = resolveOptionLabel('idType', record?.idType || '');
    const idNumber = String(record?.idNumber || '').trim();
    if(idNumber) return `${idLabel} · ${idNumber}`;
    return idLabel !== '—' ? idLabel : 'غير محدد';
  }

  function composeAddressText(record){
    const parts = [record?.country, record?.city, record?.region, record?.district, record?.street].map((value) => String(value || '').trim()).filter(Boolean);
    if(parts.length) return parts.join('، ');
    return 'بدون عنوان مسجل';
  }

  function normalizeSearchText(value){
    return String(value ?? '')
      .toLowerCase()
      .replace(/\s+/g, ' ')
      .trim();
  }

  function buildRecordSearchText(record){
    const addressText = composeAddressText(record);
    const entityLabel = resolveOptionLabel('entityType', record?.entityType || '') || '';
    const genderLabel = resolveOptionLabel('gender', record?.gender || '') || '';
    const idLabel = resolveOptionLabel('idType', record?.idType || '') || '';
    const values = [
      resolveRecordDisplayName(record),
      record?.fullName,
      record?.latinName,
      composePhoneDisplay(record),
      getPhoneCountryMeta(record?.phoneCountryCode || '')?.dialCode,
      record?.phone,
      record?.nationality,
      record?.idNumber,
      record?.issuedBy,
      record?.birthPlace,
      record?.motherName,
      record?.country,
      record?.city,
      record?.region,
      record?.district,
      record?.street,
      record?.otherDetails,
      record?.incomeSource,
      addressText,
      entityLabel,
      genderLabel,
      idLabel,
      formatIsoDate(record?.issueDate || ''),
      formatIsoDate(record?.expiryDate || ''),
      formatIsoDate(record?.birthDate || '')
    ];
    return normalizeSearchText(values.filter(Boolean).join(' '));
  }

  function getFilteredRecords(){
    const records = Array.isArray(runtime.records) ? runtime.records : [];
    const query = normalizeSearchText(runtime.searchQuery);
    if(!query) return records;
    return records.filter((record) => buildRecordSearchText(record).includes(query));
  }

  function createSearchEmptyMarkup(){
    const query = String(runtime.searchQuery || '').trim();
    return `
      <div class="customer-card-records__empty customer-card-records__empty--search" data-customer-card-empty="search">
        <div class="customer-card-records__empty-badge">نتائج البحث</div>
        <h3 class="customer-card-records__empty-title">لا توجد بطاقات مطابقة للبحث الحالي</h3>
        <p class="customer-card-records__empty-text">جرّب اسم عميل آخر أو رقم هاتف أو رقم تعريف مختلف${query ? `: <strong>${escapeHtml(query)}</strong>` : ''}.</p>
      </div>
    `;
  }

  function createRecordRowMarkup(record, index){
    const entityLabel = resolveOptionLabel('entityType', record?.entityType || '') || '—';
    const genderLabel = resolveOptionLabel('gender', record?.gender || '') || '—';
    const idTypeLabel = resolveOptionLabel('idType', record?.idType || '') || '—';
    const safeRecordId = String(record?.id || '').trim();
    const isLatest = runtime.lastAddedRecordId && runtime.lastAddedRecordId === safeRecordId;
    const isSelected = safeRecordId && runtime.selectedRecordId === safeRecordId;
    const fullName = resolveRecordDisplayName(record);
    const latinName = String(record?.latinName || '').trim() || 'بدون اسم لاتيني';
    const incomeSource = String(record?.incomeSource || '').trim() || 'غير مسجل';
    const phone = composePhoneDisplay(record) || 'غير مسجل';
    const nationality = String(record?.nationality || '').trim() || 'غير محددة';
    const idNumber = String(record?.idNumber || '').trim() || 'غير مسجل';
    const issuedBy = String(record?.issuedBy || '').trim() || 'غير محدد';
    const issueDate = formatIsoDate(record?.issueDate || '');
    const expiryDate = formatIsoDate(record?.expiryDate || '');
    const birthPlace = String(record?.birthPlace || '').trim() || 'غير محدد';
    const birthDate = formatIsoDate(record?.birthDate || '');
    const motherName = String(record?.motherName || '').trim() || 'غير مسجلة';
    const country = String(record?.country || '').trim() || '—';
    const city = String(record?.city || '').trim() || '—';
    const region = String(record?.region || '').trim() || '—';
    const district = String(record?.district || '').trim() || '—';
    const street = String(record?.street || '').trim() || '—';
    const otherDetails = String(record?.otherDetails || '').trim() || 'لا توجد تفاصيل إضافية';

    const cells = [
      `<div class="customer-card-row__cell customer-card-row__cell--index customer-card-ledger__col--index"><div class="customer-card-row__stack customer-card-row__stack--index"><button class="customer-card-row__selector" type="button" data-customer-card-record-action="select" data-customer-card-record-id="${escapeHtml(safeRecordId)}" aria-pressed="${isSelected ? 'true' : 'false'}" aria-label="${isSelected ? 'إلغاء تحديد البطاقة' : 'تحديد البطاقة'} ${escapeHtml(fullName)}"><span class="customer-card-row__state-dot${isSelected ? ' is-active' : ''}"></span></button><span class="customer-card-row__index">${escapeHtml(String(index + 1).padStart(2, '0'))}</span></div></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--full-name"><strong class="customer-card-row__primary">${escapeHtml(fullName)}</strong></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--latin-name"><span class="customer-card-row__primary" dir="ltr">${escapeHtml(latinName)}</span></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--income-source"><span class="customer-card-row__primary">${escapeHtml(incomeSource)}</span></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--phone"><span class="customer-card-row__primary" dir="ltr">${escapeHtml(phone)}</span></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--nationality"><span class="customer-card-row__primary">${escapeHtml(nationality)}</span></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--gender"><span class="customer-card-row__primary">${escapeHtml(genderLabel)}</span></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--entity-type"><span class="customer-card-row__primary">${escapeHtml(entityLabel)}</span></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--id-type"><span class="customer-card-row__primary">${escapeHtml(idTypeLabel)}</span></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--id-number"><span class="customer-card-row__primary">${escapeHtml(idNumber)}</span></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--issued-by"><span class="customer-card-row__primary">${escapeHtml(issuedBy)}</span></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--issue-date"><span class="customer-card-row__primary">${escapeHtml(issueDate)}</span></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--expiry-date"><span class="customer-card-row__primary">${escapeHtml(expiryDate)}</span></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--birth-place"><span class="customer-card-row__primary">${escapeHtml(birthPlace)}</span></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--birth-date"><span class="customer-card-row__primary">${escapeHtml(birthDate)}</span></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--mother-name"><span class="customer-card-row__primary">${escapeHtml(motherName)}</span></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--country"><span class="customer-card-row__primary">${escapeHtml(country)}</span></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--city"><span class="customer-card-row__primary">${escapeHtml(city)}</span></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--region"><span class="customer-card-row__primary">${escapeHtml(region)}</span></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--district"><span class="customer-card-row__primary">${escapeHtml(district)}</span></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--street"><span class="customer-card-row__primary">${escapeHtml(street)}</span></div>`,
      `<div class="customer-card-row__cell customer-card-ledger__col--other-details"><span class="customer-card-row__primary">${escapeHtml(otherDetails)}</span></div>`
    ];

    return `
      <article class="customer-card-row${isLatest ? ' is-latest' : ''}${isSelected ? ' is-selected' : ''}" data-customer-card-record-id="${escapeHtml(safeRecordId)}" aria-selected="${isSelected ? 'true' : 'false'}" tabindex="0" role="button" aria-label="تحديد بطاقة ${escapeHtml(fullName)}">
        <div class="customer-card-ledger__grid customer-card-row__grid">
          ${cells.join('')}
        </div>
      </article>
    `;
  }

  function createRecordsEmptyMarkup(){
    return `
      <div class="customer-card-records__empty" data-customer-card-empty="true">
        <div class="customer-card-records__empty-badge">سجل هادئ وجاهز</div>
        <h3 class="customer-card-records__empty-title">لا توجد بطاقات عملاء مضافة بعد</h3>
        <p class="customer-card-records__empty-text">اضغط <strong>إضافة عميل</strong> ثم أدخل بيانات العميل ليظهر السجل هنا ضمن أعمدة منظمة وواضحة.</p>
      </div>
    `;
  }

  function createRecordsMarkup(){
    if(!Array.isArray(runtime.records) || !runtime.records.length) return createRecordsEmptyMarkup();
    const visibleRecords = getFilteredRecords();
    if(!visibleRecords.length) return createSearchEmptyMarkup();
    return `
      <div class="customer-card-ledger" data-customer-card-ledger="true">
        <div class="customer-card-ledger__head customer-card-ledger__grid">
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--index">#</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--full-name">الاسم الكامل</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--latin-name">الاسم اللاتيني</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--income-source">مصدر الدخل</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--phone">رقم الهاتف</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--nationality">الجنسية</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--gender">الجنس</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--entity-type">نوع العميل</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--id-type">نوع التعريف</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--id-number">رقم التعريف</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--issued-by">صادرة عن</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--issue-date">تاريخ المنح</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--expiry-date">تاريخ الصلاحية</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--birth-place">مكان الولادة</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--birth-date">تاريخ الولادة</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--mother-name">اسم الأم</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--country">البلد</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--city">المدينة</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--region">المنطقة</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--district">الحي</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--street">الشارع</div>
          <div class="customer-card-ledger__head-cell customer-card-ledger__col--other-details">تفاصيل أخرى</div>
        </div>
        <div class="customer-card-ledger__body">
          ${visibleRecords.map((record, index) => createRecordRowMarkup(record, index)).join('')}
        </div>
      </div>
    `;
  }

  function refreshFieldMarkup(fieldKey, { focusSelector = '' } = {}){
    if(!(runtime.panel instanceof HTMLElement)) return null;
    const renderKey = getFieldRenderKey(fieldKey);
    const definition = getFieldDefinition(renderKey);
    if(!definition) return null;
    const currentNode = runtime.panel.querySelector(`[data-customer-card-field-wrap="${escapeSelectorValue(renderKey)}"]`);
    if(!(currentNode instanceof HTMLElement) || !(currentNode.parentNode instanceof Node)) return null;
    const temp = document.createElement('div');
    temp.innerHTML = createFieldMarkup(definition, runtime.state).trim();
    const nextNode = temp.firstElementChild;
    if(!(nextNode instanceof HTMLElement)) return null;
    currentNode.parentNode.replaceChild(nextNode, currentNode);
    normalizeCustomerCardFlow(nextNode);
    if(focusSelector){
      const focusTarget = nextNode.querySelector(focusSelector);
      if(focusTarget instanceof HTMLElement){
        try{ focusTarget.focus({ preventScroll:true }); }catch{ focusTarget.focus(); }
      }
    }
    return nextNode;
  }


  function refreshPhoneCountryOptions(){
    if(!(runtime.panel instanceof HTMLElement) || !isChoicePickerOpen(PHONE_COUNTRY_FIELD_KEY)) return false;
    const optionsContainer = runtime.panel.querySelector('[data-customer-card-phone-country-options="true"]');
    if(!(optionsContainer instanceof HTMLElement)) return false;
    const countryValue = runtime.state && Object.prototype.hasOwnProperty.call(runtime.state, PHONE_COUNTRY_FIELD_KEY)
      ? String(runtime.state[PHONE_COUNTRY_FIELD_KEY] || '')
      : '';
    optionsContainer.innerHTML = renderPhoneCountryOptionsMarkup(countryValue);
    updatePhoneCountrySearchControls();
    return true;
  }

  function closeChoicePicker({ focus = false } = {}){
    const fieldKey = String(runtime.openChoiceField || '').trim();
    if(!fieldKey) return false;
    runtime.openChoiceField = '';
    if(fieldKey === PHONE_COUNTRY_FIELD_KEY) runtime.phoneCountrySearchQuery = '';
    refreshFieldMarkup(fieldKey, { focusSelector: focus ? (fieldKey === PHONE_COUNTRY_FIELD_KEY ? '[data-customer-card-field="phone"]' : '[data-customer-card-choice-trigger="true"]') : '' });
    return true;
  }

  function openChoicePicker(fieldKey, { focusSelector = '' } = {}){
    const safeFieldKey = String(fieldKey || '').trim();
    if(!safeFieldKey) return false;
    const previousChoiceField = String(runtime.openChoiceField || '').trim();
    const hadDateOpen = !!String(runtime.openDateField || '').trim();
    runtime.openDateField = '';
    runtime.datePickerView = 'days';
    runtime.openChoiceField = safeFieldKey;
    if(safeFieldKey === PHONE_COUNTRY_FIELD_KEY) runtime.phoneCountrySearchQuery = '';
    if(previousChoiceField && previousChoiceField !== safeFieldKey){
      refreshFieldMarkup(previousChoiceField);
    }
    if(hadDateOpen){
      syncFormUi();
      refreshFieldMarkup(safeFieldKey, { focusSelector });
      return true;
    }
    refreshFieldMarkup(safeFieldKey, { focusSelector });
    return true;
  }

  function toggleChoicePicker(fieldKey){
    const safeFieldKey = String(fieldKey || '').trim();
    if(!safeFieldKey) return false;
    if(isChoicePickerOpen(safeFieldKey)){
      return closeChoicePicker({ focus:true });
    }
    const focusSelector = safeFieldKey === PHONE_COUNTRY_FIELD_KEY
      ? '[data-customer-card-phone-country-search="true"], [data-customer-card-choice-action="select"]'
      : '[data-customer-card-choice-action="select"], [data-customer-card-choice-trigger="true"]';
    return openChoicePicker(safeFieldKey, { focusSelector });
  }

  function closeDatePicker({ focus = false } = {}){
    const fieldKey = String(runtime.openDateField || '').trim();
    if(!fieldKey) return false;
    runtime.openDateField = '';
    runtime.datePickerView = 'days';
    refreshFieldMarkup(fieldKey, { focusSelector: focus ? '[data-customer-card-date-trigger="true"]' : '' });
    return true;
  }

  function openDatePicker(fieldKey, { focusSelector = '' } = {}){
    const safeFieldKey = String(fieldKey || '').trim();
    if(!safeFieldKey) return false;
    const value = runtime.state && Object.prototype.hasOwnProperty.call(runtime.state, safeFieldKey) ? runtime.state[safeFieldKey] : '';
    const previousDateField = String(runtime.openDateField || '').trim();
    const previousChoiceField = String(runtime.openChoiceField || '').trim();
    runtime.openChoiceField = '';
    runtime.openDateField = safeFieldKey;
    runtime.datePickerMonthCursor = resolveDatePickerMonthCursor(safeFieldKey, value);
    runtime.datePickerView = 'days';
    if(previousChoiceField){
      refreshFieldMarkup(previousChoiceField);
    }
    if(previousDateField && previousDateField !== safeFieldKey){
      refreshFieldMarkup(previousDateField);
    }
    refreshFieldMarkup(safeFieldKey, { focusSelector });
    return true;
  }

  function toggleDatePicker(fieldKey){
    const safeFieldKey = String(fieldKey || '').trim();
    if(!safeFieldKey) return false;
    if(isDatePickerOpen(safeFieldKey)){
      return closeDatePicker({ focus:true });
    }
    return openDatePicker(safeFieldKey, { focusSelector:'[data-customer-card-date-action="today"], [data-customer-card-date-trigger="true"]' });
  }

  function closeAllPickers(){
    const affectedFields = [];
    const choiceField = String(runtime.openChoiceField || '').trim();
    const dateField = String(runtime.openDateField || '').trim();
    if(choiceField) affectedFields.push(choiceField);
    if(dateField && dateField !== choiceField) affectedFields.push(dateField);
    if(!affectedFields.length) return false;
    if(choiceField === PHONE_COUNTRY_FIELD_KEY) runtime.phoneCountrySearchQuery = '';
    runtime.openChoiceField = '';
    runtime.openDateField = '';
    runtime.datePickerView = 'days';
    affectedFields.forEach((fieldKey) => refreshFieldMarkup(fieldKey));
    return true;
  }

  function bindPanelEvents(panel){
    if(!(panel instanceof HTMLElement)) return;
    if(typeof runtime.detachPanelEvents === 'function'){
      try{ runtime.detachPanelEvents(); }catch{}
      runtime.detachPanelEvents = null;
    }

    const inputHandler = (event) => handleInputEvent(event);
    const changeHandler = (event) => handleInputEvent(event);
    const clickHandler = (event) => {
      if(handleDialogActionClick(event)) return;
      if(handleActionClick(event)) return;
      if(handleToolbarRecordActionClick(event)) return;
      if(handleSearchActionClick(event)) return;
      if(handlePhoneCountrySearchActionClick(event)) return;
      if(handleRecordRowActionClick(event)) return;
      if(handleChoicePickerClick(event)) return;
      if(handleDatePickerClick(event)) return;
      handleSegmentedClick(event);
    };
    const keydownHandler = (event) => {
      if(String(event.key || '') === 'Escape' && runtime.isFormDialogOpen && !runtime.openChoiceField && !runtime.openDateField){
        event.preventDefault();
        closeCustomerDialog({ keepSelection:true });
        return;
      }
      if(handleRecordRowKeydown(event)) return;
      if(handlePickerKeydown(event)) return;
      if(handleSegmentedKeydown(event)) return;
    };

    const outsidePointerHandler = (event) => {
      const target = event.target instanceof Element ? event.target : null;
      if(!target) return;
      if(target.closest('[data-customer-card-choice-picker], [data-customer-card-date-picker]')) return;
      if(!panel.contains(target)){
        closeAllPickers();
        return;
      }
      if(runtime.openChoiceField || runtime.openDateField){
        closeAllPickers();
      }
    };

    const formScroll = panel.querySelector('[data-customer-card-form-scroll="true"], .customer-card-workspace__form-scroll');
    const scrollHandler = () => {
      if(runtime.openChoiceField || runtime.openDateField){
        closeAllPickers();
      }
    };

    panel.addEventListener('input', inputHandler);
    panel.addEventListener('change', changeHandler);
    panel.addEventListener('click', clickHandler);
    panel.addEventListener('keydown', keydownHandler);
    document.addEventListener('pointerdown', outsidePointerHandler, true);
    if(formScroll instanceof HTMLElement){
      formScroll.addEventListener('scroll', scrollHandler, { passive:true });
    }

    runtime.detachPanelEvents = () => {
      panel.removeEventListener('input', inputHandler);
      panel.removeEventListener('change', changeHandler);
      panel.removeEventListener('click', clickHandler);
      panel.removeEventListener('keydown', keydownHandler);
      document.removeEventListener('pointerdown', outsidePointerHandler, true);
      if(formScroll instanceof HTMLElement){
        formScroll.removeEventListener('scroll', scrollHandler);
      }
    };
  }

  function bindFormNavigationInPanel(panel){
    if(typeof runtime.detachFormNavigation === 'function'){
      try{ runtime.detachFormNavigation(); }catch{}
      runtime.detachFormNavigation = null;
    }

    if(!(panel instanceof HTMLElement) || typeof bindWindowChromeFormNavigation !== 'function') return;
    const formPane = panel.querySelector('[data-customer-card-form-root="true"]');
    if(!(formPane instanceof HTMLElement)) return;

    const cleanup = bindWindowChromeFormNavigation({ root: formPane, autoFocus: false });
    runtime.detachFormNavigation = typeof cleanup === 'function' ? cleanup : null;
  }

  function createCustomerDialogMarkup(){
    if(!runtime.isFormDialogOpen) return '';
    const dialogTitle = runtime.editingRecordId ? 'تعديل بطاقة عميل' : 'إضافة عميل';
    const isMaximized = !!runtime.isDialogMaximized;
    const expandLabel = isMaximized ? 'استعادة الحجم المرجعي' : 'تكبير النافذة';
    const expandIcon = isMaximized
      ? '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M7 3H3v4M13 3h4v4M7 17H3v-4M13 17h4v-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M8 8 4 4M12 8l4-4M8 12l-4 4M12 12l4 4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path></svg>'
      : '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M4 8V4h4M12 4h4v4M8 16H4v-4M16 12v4h-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M4 4l5 5M16 4l-5 5M4 16l5-5M16 16l-5-5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
    return `
      <div class="customer-card-modal-backdrop" data-customer-card-dialog="true" data-customer-card-window-active="true" role="presentation">
        <article class="customer-card-modal-window customer-card-modal-window--customer${isMaximized ? ' is-maximized' : ''} is-positioned" role="dialog" aria-modal="true" aria-label="${escapeHtml(dialogTitle)}">
          <section class="customer-card-sheet">
            <header class="customer-card-sheet__head" aria-label="شريط نافذة بطاقة العميل">
              <div class="customer-card-sheet__heading">
                <h2 class="customer-card-sheet__title">
                  <span class="customer-card-sheet__title-icon" aria-hidden="true">
                    <svg viewBox="0 0 24 24" focusable="false"><path d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z" fill="none" stroke="currentColor" stroke-width="2"></path><path d="M4.5 21a7.5 7.5 0 0 1 15 0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path></svg>
                  </span>
                  <span class="customer-card-sheet__title-text">${escapeHtml(dialogTitle)}</span>
                </h2>
              </div>
              <div class="customer-card-sheet__window-actions" aria-label="إجراءات النافذة">
                <button class="customer-card-sheet__chrome-btn customer-card-sheet__expand" type="button" data-customer-card-dialog-action="toggle-size" aria-label="${escapeHtml(expandLabel)}" title="${escapeHtml(expandLabel)}" aria-pressed="${isMaximized ? 'true' : 'false'}">${expandIcon}</button>
                <button class="customer-card-sheet__close" type="button" data-customer-card-dialog-action="close" aria-label="إغلاق نافذة بطاقة العميل" title="إغلاق">
                  <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M18 6 6 18M6 6l12 12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"></path></svg>
                </button>
              </div>
            </header>
            <div class="customer-card-sheet__body" data-customer-card-form-root="true">
              <div class="customer-card-window-form" data-customer-card-form-scroll="true">
                ${safeGroups().map((group) => createGroupMarkup(group, runtime.state)).join('')}
              </div>
              <div class="customer-card-actions customer-card-actions--window" data-taif-footer-actions="true" aria-label="إجراءات بطاقة العميل">
                <div class="customer-card-actions__group" data-taif-footer-group="true">
                  <button class="customer-card-action-btn customer-card-action-btn--success" type="button" data-customer-card-action="create">
                    <span class="customer-card-action-btn__text" data-customer-card-create-text="true">إضافة عميل</span>
                  </button>
                  <button class="customer-card-action-btn customer-card-action-btn--danger" type="button" data-customer-card-action="clear">
                    <span class="customer-card-action-btn__text">إلغاء/مسح</span>
                  </button>
                </div>
              </div>
            </div>
          </section>
        </article>
      </div>
    `;
  }

  function ensureCustomerDialogHost(){
    if(!(runtime.panel instanceof HTMLElement)) return null;
    let host = runtime.panel.querySelector('[data-customer-card-dialog-host="true"]');
    if(host instanceof HTMLElement) return host;

    const root = runtime.panel.querySelector('.customer-card-view') || runtime.panel;
    if(!(root instanceof HTMLElement)) return null;

    host = document.createElement('div');
    host.className = 'customer-card-window-layer';
    host.setAttribute('data-customer-card-dialog-host', 'true');
    root.appendChild(host);
    return host;
  }

  function updateCustomerDialog({ focus = false } = {}){
    if(!(runtime.panel instanceof HTMLElement)) return;
    const host = ensureCustomerDialogHost();
    if(!(host instanceof HTMLElement)) return;

    const dialogMarkup = createCustomerDialogMarkup();
    host.innerHTML = dialogMarkup;
    host.classList.toggle('is-active', !!dialogMarkup);

    try{ normalizeCustomerCardFlow(host); }catch{}
    try{ bindFormNavigationInPanel(runtime.panel); }catch{}
    try{ updateActionButtons(); }catch{}
    if(focus && runtime.isFormDialogOpen){
      try{ focusPrimaryField(); }catch{}
    }
  }

  function renderCustomerCard(panel){
    runtime.panel = panel;
    runtime.state = api.readState();
    runtime.records = api.readRecords();

    panel.innerHTML = `
      <section class="customer-card-view customer-card-view--records-only" aria-label="بطاقة العميل">
        <div class="customer-card-workspace customer-card-workspace--records-only">
          <div class="customer-card-workspace__records-pane customer-card-workspace__records-pane--full" aria-label="سجل بطاقات العملاء">
            <div class="customer-card-records customer-card-records--full">
              <div class="customer-card-records__footer" aria-label="شريط سجل بطاقات العملاء">
                <div class="customer-card-records__footer-group customer-card-records__footer-group--controls">
                  <div class="customer-card-records__search" aria-label="بحث داخل سجل البطاقات">
                    <div class="entries-search">
                      <input class="entries-search__input" type="search" value="${escapeHtml(runtime.searchQuery)}" placeholder="ابحث باسم العميل أو الهاتف أو رقم التعريف" data-customer-card-search="true" autocomplete="off" spellcheck="false" aria-label="بحث داخل سجل البطاقات">
                      <button class="entries-search__clear" type="button" data-customer-card-search-action="clear" data-taif-clear-control="true" aria-label="مسح البحث">${SEARCH_CLEAR_ICON}</button>
                    </div>
                  </div>
                  <button class="customer-card-toolbar-btn customer-card-toolbar-btn--add" type="button" data-customer-card-toolbar-action="open-create-dialog">
                    <span class="customer-card-toolbar-btn__text">إضافة عميل</span>
                  </button>
                  <button class="customer-card-toolbar-btn customer-card-toolbar-btn--edit" type="button" data-customer-card-toolbar-action="edit-selected">
                    <span class="customer-card-toolbar-btn__text">تعديل</span>
                  </button>
                  <button class="customer-card-toolbar-btn customer-card-toolbar-btn--delete" type="button" data-customer-card-toolbar-action="delete-selected">
                    <span class="customer-card-toolbar-btn__text">حذف</span>
                  </button>
                </div>
                <div class="customer-card-records__footer-group customer-card-records__footer-group--meta">
                  <div class="customer-card-records__count customer-card-records__count--footer" data-customer-card-count-wrap="true">
                    <span class="customer-card-records__count-number" data-customer-card-count="true">0</span>
                    <span class="customer-card-records__count-label">عملاء</span>
                  </div>
                </div>
              </div>
              <div class="customer-card-records__scroll customer-card-records__scroll--full" data-customer-card-records="true">
                ${createRecordsMarkup()}
              </div>
            </div>
          </div>
        </div>
        <div class="customer-card-window-layer" data-customer-card-dialog-host="true">${createCustomerDialogMarkup()}</div>
      </section>
    `;

    normalizeCustomerCardFlow(panel);
    bindPanelEvents(panel);
    bindFormNavigationInPanel(panel);
    updateRecordsCount();
    updateSearchControls();
    updateActionButtons();
  }

  function syncSegmentedUi(fieldKey, value, { focus = false } = {}){
    if(!(runtime.panel instanceof HTMLElement)) return;
    const safeFieldKey = String(fieldKey || '').trim();
    const container = runtime.panel.querySelector(`[data-customer-card-segmented-field="${escapeSelectorValue(safeFieldKey)}"]`);
    if(!(container instanceof HTMLElement)) return;
    const safeValue = String(value || '').trim();
    const buttons = Array.from(container.querySelectorAll('[data-customer-card-segment]')).filter((button) => button instanceof HTMLButtonElement);
    let activeButton = null;

    buttons.forEach((button) => {
      const isActive = String(button.dataset.customerCardSegment || '').trim() === safeValue;
      button.classList.toggle('is-active', isActive);
      button.setAttribute('aria-checked', isActive ? 'true' : 'false');
      button.tabIndex = isActive ? 0 : -1;
      button.dataset.taifFlowItem = isActive ? 'true' : 'false';
      if(isActive) activeButton = button;
    });

    if(!(activeButton instanceof HTMLButtonElement) && buttons[0] instanceof HTMLButtonElement){
      activeButton = buttons[0];
      activeButton.tabIndex = 0;
    }

    if(focus && activeButton instanceof HTMLButtonElement){
      try{ activeButton.focus({ preventScroll:true }); }catch{ activeButton.focus(); }
    }
  }

  function syncFieldUi(fieldKey, value){
    if(!(runtime.panel instanceof HTMLElement)) return;
    const definition = getFieldDefinition(fieldKey);
    if(!definition) return;

    if(definition.control === 'segmented'){
      syncSegmentedUi(fieldKey, value);
      return;
    }

    if(definition.control === 'phone' || definition.control === 'select' || String(definition.type || '').trim() === 'date'){
      refreshFieldMarkup(fieldKey);
      return;
    }

    const control = runtime.panel.querySelector(`[data-customer-card-field="${escapeSelectorValue(fieldKey)}"]`);
    if(!(control instanceof HTMLInputElement) && !(control instanceof HTMLTextAreaElement)) return;
    const nextValue = value == null ? '' : String(value);
    if(control.value !== nextValue) control.value = nextValue;
  }

  function syncFormUi(){
    FIELD_KEYS.forEach((fieldKey) => {
      syncFieldUi(fieldKey, runtime.state[fieldKey] ?? '');
    });
  }

  function getRecordById(recordId){
    const safeId = String(recordId || '').trim();
    if(!safeId) return null;
    return Array.isArray(runtime.records)
      ? runtime.records.find((record) => String(record?.id || '').trim() === safeId) || null
      : null;
  }

  function hasSelectedRecord(){
    return !!getRecordById(runtime.selectedRecordId);
  }

  function normalizeSelectionState(){
    if(runtime.selectedRecordId && !getRecordById(runtime.selectedRecordId)){
      runtime.selectedRecordId = '';
    }
    if(runtime.editingRecordId && !getRecordById(runtime.editingRecordId)){
      runtime.editingRecordId = '';
    }
    if(runtime.editingRecordId && runtime.selectedRecordId !== runtime.editingRecordId){
      runtime.selectedRecordId = runtime.editingRecordId;
    }
  }

  function setSelectedRecord(recordId){
    const safeId = String(recordId || '').trim();
    const currentEditingId = String(runtime.editingRecordId || '').trim();
    if(currentEditingId && safeId && safeId !== currentEditingId){
      runtime.editingRecordId = '';
      runtime.state = api.writeState(api.createEmptyState());
      runtime.openChoiceField = '';
      runtime.openDateField = '';
      runtime.datePickerView = 'days';
      syncFormUi();
    }
    if(!safeId){
      runtime.selectedRecordId = '';
    } else if(runtime.selectedRecordId === safeId && !runtime.editingRecordId){
      runtime.selectedRecordId = '';
    } else {
      runtime.selectedRecordId = safeId;
    }
    normalizeSelectionState();
    updateRecordsList();
    updateActionButtons();
  }

  function updateRecordsCount(){
    if(!(runtime.panel instanceof HTMLElement)) return;
    const countNode = runtime.panel.querySelector('[data-customer-card-count="true"]');
    if(!(countNode instanceof HTMLElement)) return;
    countNode.textContent = String(Array.isArray(runtime.records) ? runtime.records.length : 0);
  }

  function updateSearchControls(){
    if(!(runtime.panel instanceof HTMLElement)) return;
    const input = runtime.panel.querySelector('[data-customer-card-search="true"]');
    const clearButton = runtime.panel.querySelector('[data-customer-card-search-action="clear"]');
    const searchValue = String(runtime.searchQuery || '');
    if(input instanceof HTMLInputElement && input.value !== searchValue){
      input.value = searchValue;
    }
    if(clearButton instanceof HTMLButtonElement){
      clearButton.hidden = false;
    }
  }

  function updateRecordsList({ scrollToTop = false } = {}){
    if(!(runtime.panel instanceof HTMLElement)) return;
    normalizeSelectionState();
    const host = runtime.panel.querySelector('[data-customer-card-records="true"]');
    if(!(host instanceof HTMLElement)) return;
    host.innerHTML = createRecordsMarkup();
    updateRecordsCount();
    updateSearchControls();
    updateActionButtons();
    if(scrollToTop){
      host.scrollTop = 0;
    }
  }

  function updateActionButtons(){
    if(!(runtime.panel instanceof HTMLElement)) return;
    normalizeSelectionState();
    const hasContent = !!api.hasMeaningfulContent(runtime.state);
    const isEditing = !!runtime.editingRecordId;
    const canClear = hasContent || isEditing;
    const hasSelection = hasSelectedRecord();

    runtime.panel.querySelectorAll('[data-customer-card-action]').forEach((node) => {
      if(!(node instanceof HTMLButtonElement)) return;
      const action = String(node.dataset.customerCardAction || '').trim();
      const shouldEnable = action === 'clear' ? canClear : hasContent;
      node.disabled = !shouldEnable;
      node.setAttribute('aria-disabled', shouldEnable ? 'false' : 'true');
    });

    runtime.panel.querySelectorAll('[data-customer-card-toolbar-action]').forEach((node) => {
      if(!(node instanceof HTMLButtonElement)) return;
      const action = String(node.dataset.customerCardToolbarAction || '').trim();
      const shouldEnable = action === 'open-create-dialog' ? true : hasSelection;
      node.disabled = !shouldEnable;
      node.setAttribute('aria-disabled', shouldEnable ? 'false' : 'true');
    });

    const createLabel = runtime.panel.querySelector('[data-customer-card-create-text="true"]');
    if(createLabel instanceof HTMLElement){
      createLabel.textContent = isEditing ? 'حفظ التعديل' : 'إضافة عميل';
    }
  }

  function collectFormFlowTargets(){
    if(!(runtime.panel instanceof HTMLElement)) return [];
    const formPane = runtime.panel.querySelector('[data-customer-card-form-root="true"]');
    if(!(formPane instanceof HTMLElement)) return [];

    const targets = [];
    formPane.querySelectorAll('.customer-card-field').forEach((fieldNode) => {
      if(!(fieldNode instanceof HTMLElement)) return;
      const segmentedContainer = fieldNode.querySelector('[data-customer-card-segmented-field]');
      if(segmentedContainer instanceof HTMLElement){
        const target = segmentedContainer.querySelector('[data-customer-card-segment].is-active')
          || segmentedContainer.querySelector('[data-customer-card-segment]');
        if(target instanceof HTMLButtonElement && !target.disabled){
          targets.push(target);
        }
        return;
      }

      const dateInput = fieldNode.querySelector('[data-customer-card-date-part="day"]');
      if(dateInput instanceof HTMLInputElement && !dateInput.disabled && !dateInput.readOnly){
        targets.push(dateInput);
        return;
      }

      const pickerTrigger = fieldNode.querySelector('[data-customer-card-choice-trigger], [data-customer-card-date-trigger]');
      if(pickerTrigger instanceof HTMLButtonElement && !pickerTrigger.disabled){
        targets.push(pickerTrigger);
        return;
      }

      const control = fieldNode.querySelector('[data-customer-card-field]');
      if(control instanceof HTMLInputElement || control instanceof HTMLTextAreaElement){
        if(control.disabled || control.readOnly) return;
        targets.push(control);
      }
    });

    formPane.querySelectorAll('[data-customer-card-action]').forEach((button) => {
      if(button instanceof HTMLButtonElement && !button.disabled){
        targets.push(button);
      }
    });

    return targets;
  }

  function focusFormFlowTarget(target){
    if(!(target instanceof HTMLElement)) return false;
    if(typeof focusWindowChromeElement === 'function'){
      return focusWindowChromeElement(target);
    }
    if(typeof target.scrollIntoView === 'function'){
      try{ target.scrollIntoView({ block:'nearest', inline:'nearest' }); }catch{}
    }
    try{ target.focus({ preventScroll:true }); }catch{
      try{ target.focus(); }catch{}
    }
    return document.activeElement === target;
  }

  function findFlowInsertionIndex(targets, reference){
    if(!(reference instanceof Node)) return targets.length;
    for(let index = 0; index < targets.length; index += 1){
      const candidate = targets[index];
      if(candidate === reference) return index;
      const relation = reference.compareDocumentPosition(candidate);
      if(relation & Node.DOCUMENT_POSITION_FOLLOWING) return index;
    }
    return targets.length;
  }

  function focusRelativeFormFlowTarget(anchor, step, { clamp = true } = {}){
    const targets = collectFormFlowTargets();
    if(!targets.length) return false;
    const normalizedStep = step < 0 ? -1 : 1;
    const reference = anchor instanceof HTMLElement ? anchor : null;
    const currentIndex = reference ? targets.indexOf(reference) : -1;
    let nextIndex = -1;

    if(currentIndex !== -1){
      nextIndex = currentIndex + normalizedStep;
    }else{
      const insertionIndex = findFlowInsertionIndex(targets, reference || anchor);
      nextIndex = normalizedStep < 0 ? insertionIndex - 1 : insertionIndex;
    }

    if(clamp){
      nextIndex = Math.max(0, Math.min(targets.length - 1, nextIndex));
    }

    const nextTarget = nextIndex >= 0 && nextIndex < targets.length ? targets[nextIndex] : null;
    return focusFormFlowTarget(nextTarget);
  }

  function focusPrimaryField(){
    if(!(runtime.panel instanceof HTMLElement) || !runtime.isFormDialogOpen) return;
    const control = runtime.panel.querySelector('[data-customer-card-dialog-host="true"] [data-customer-card-field="fullName"]');
    if(!(control instanceof HTMLElement)) return;
    try{ control.focus({ preventScroll:true }); }catch{ control.focus(); }
  }

  function clearDraft({ keepSelection = true, focus = true } = {}){
    runtime.editingRecordId = '';
    if(!keepSelection){
      runtime.selectedRecordId = '';
    }
    runtime.openChoiceField = '';
    runtime.openDateField = '';
    runtime.datePickerView = 'days';
    runtime.phoneCountrySearchQuery = '';
    runtime.dateInputDrafts = Object.create(null);
    runtime.state = api.writeState(api.createEmptyState());
    syncFormUi();
    updateActionButtons();
    updateRecordsList();
    if(focus){
      focusPrimaryField();
    }
  }

  function closeCustomerDialog({ keepSelection = true } = {}){
    runtime.isFormDialogOpen = false;
    runtime.isDialogMaximized = false;
    runtime.openChoiceField = '';
    runtime.openDateField = '';
    runtime.datePickerView = 'days';
    runtime.phoneCountrySearchQuery = '';
    runtime.editingRecordId = '';
    runtime.state = api.writeState(api.createEmptyState());
    if(!keepSelection){
      runtime.selectedRecordId = '';
    }
    updateCustomerDialog();
    updateRecordsList();
    updateActionButtons();
  }

  function openCreateCustomerDialog(){
    runtime.editingRecordId = '';
    runtime.openChoiceField = '';
    runtime.openDateField = '';
    runtime.datePickerView = 'days';
    runtime.phoneCountrySearchQuery = '';
    runtime.dateInputDrafts = Object.create(null);
    runtime.state = api.writeState(api.createEmptyState());
    runtime.isDialogMaximized = false;
    runtime.isFormDialogOpen = true;
    ensureCustomerDialogHost();
    updateCustomerDialog({ focus:true });
    updateRecordsList();
    return true;
  }

  function openEditCustomerDialog(recordId){
    const record = getRecordById(recordId);
    if(!record) return false;
    runtime.selectedRecordId = String(record.id || '').trim();
    runtime.editingRecordId = runtime.selectedRecordId;
    runtime.openChoiceField = '';
    runtime.openDateField = '';
    runtime.datePickerView = 'days';
    runtime.phoneCountrySearchQuery = '';
    runtime.dateInputDrafts = Object.create(null);
    runtime.state = api.writeState(record);
    runtime.isDialogMaximized = false;
    runtime.isFormDialogOpen = true;
    ensureCustomerDialogHost();
    updateCustomerDialog({ focus:true });
    updateRecordsList();
    updateActionButtons();
    return true;
  }

  function handleDialogActionClick(event){
    const button = event.target instanceof Element ? event.target.closest('[data-customer-card-dialog-action]') : null;
    if(!(button instanceof HTMLElement)) return false;
    const action = String(button.dataset.customerCardDialogAction || '').trim();
    if(action === 'toggle-size'){
      event.preventDefault();
      runtime.isDialogMaximized = !runtime.isDialogMaximized;
      updateCustomerDialog({ focus:false });
      return true;
    }
    if(action !== 'close') return false;
    event.preventDefault();
    closeCustomerDialog({ keepSelection:true });
    return true;
  }

  function enterEditMode(recordId){
    const record = getRecordById(recordId);
    if(!record) return false;
    runtime.selectedRecordId = String(record.id || '').trim();
    runtime.editingRecordId = runtime.selectedRecordId;
    runtime.openChoiceField = '';
    runtime.openDateField = '';
    runtime.datePickerView = 'days';
    runtime.state = api.writeState(record);
    syncFormUi();
    updateRecordsList();
    updateActionButtons();
    focusPrimaryField();
    return true;
  }

  function closeDeleteConfirmDialog(){
    if(typeof runtime.deleteConfirmCleanup !== 'function') return;
    const cleanup = runtime.deleteConfirmCleanup;
    runtime.deleteConfirmCleanup = null;
    try{ cleanup(); }catch{}
  }

  function createCustomerDeleteQuestionOptions(record){
    const name = resolveRecordDisplayName(record) || 'بطاقة عميل';
    const phone = composePhoneDisplay(record) || 'غير مسجل';
    const identity = composeIdentityText(record) || 'تعريف غير مسجل';
    const entityLabel = resolveOptionLabel('entityType', record?.entityType || '') || 'عميل';
    const nationality = String(record?.nationality || '').trim() || 'غير محددة';
    return {
      owner:'customer-card',
      title:'حذف بطاقة عميل',
      confirmLabel:'حذف نهائي',
      confirmTone:'danger',
      confirmIcon:'trash',
      cardHtml:`
        <div class="taif-question-card taif-question-card--stacked taif-question-card--customer" aria-hidden="true">
          <div class="taif-question-card__main">
            <strong>${escapeHtml(name)}</strong>
            <span dir="ltr">${escapeHtml(phone)}</span>
          </div>
          <div class="taif-question-card__meta">
            <span>${escapeHtml(identity)}</span>
            <span>${escapeHtml(entityLabel)}</span>
            <span>الجنسية: ${escapeHtml(nationality)}</span>
          </div>
        </div>
      `,
      warning:'هل أنت متأكد من حذف بطاقة العميل؟ سيتم حذفها من سجل بطاقة العميل الحالي، ولن تبقى ظاهرة في اقتراحات أسماء المستفيدين حتى تتم إضافتها من جديد.'
    };
  }

  function requestDeleteSelectedRecord(){
    const recordId = String(runtime.selectedRecordId || '').trim();
    if(!recordId) return false;
    const record = getRecordById(recordId);
    if(!record){
      runtime.selectedRecordId = '';
      updateRecordsList();
      updateActionButtons();
      return false;
    }
    closeAllPickers();
    closeDeleteConfirmDialog();

    const questionDialog = TAIF?.ui?.questionDialog;
    if(!questionDialog || typeof questionDialog.open !== 'function') return false;

    let cleanup = null;
    const dialogApi = questionDialog.open({
      ...createCustomerDeleteQuestionOptions(record),
      onConfirm(){
        deleteSelectedRecord();
      },
      onClose(){
        if(runtime.deleteConfirmCleanup === cleanup){
          runtime.deleteConfirmCleanup = null;
        }
      }
    });

    cleanup = () => {
      if(dialogApi && typeof dialogApi.close === 'function'){
        dialogApi.close(true);
      }
    };
    runtime.deleteConfirmCleanup = cleanup;
    return true;
  }

  function deleteSelectedRecord(){
    const recordId = String(runtime.selectedRecordId || '').trim();
    if(!recordId) return false;
    const result = typeof api.deleteRecord === 'function' ? api.deleteRecord(recordId) : null;
    runtime.records = Array.isArray(result?.records) ? result.records : api.readRecords();
    runtime.lastAddedRecordId = '';
    if(runtime.editingRecordId === recordId){
      runtime.editingRecordId = '';
      runtime.openChoiceField = '';
      runtime.openDateField = '';
      runtime.datePickerView = 'days';
      runtime.state = api.writeState(api.createEmptyState());
      syncFormUi();
    }
    runtime.selectedRecordId = '';
    updateRecordsList({ scrollToTop:true });
    updateActionButtons();
    focusPrimaryField();
    return true;
  }

  function saveCustomerRecord(){
    if(!api.hasMeaningfulContent(runtime.state)) return false;
    runtime.openChoiceField = '';
    runtime.openDateField = '';
    runtime.datePickerView = 'days';
    runtime.phoneCountrySearchQuery = '';
    runtime.dateInputDrafts = Object.create(null);
    if(runtime.editingRecordId && typeof api.updateRecordFromState === 'function'){
      const result = api.updateRecordFromState(runtime.editingRecordId, runtime.state);
      runtime.records = Array.isArray(result?.records) ? result.records : api.readRecords();
      runtime.lastAddedRecordId = '';
      runtime.selectedRecordId = String(result?.record?.id || runtime.editingRecordId || '').trim();
      runtime.editingRecordId = '';
      runtime.state = api.writeState(api.createEmptyState());
      runtime.dateInputDrafts = Object.create(null);
      runtime.isFormDialogOpen = false;
      runtime.isDialogMaximized = false;
      updateCustomerDialog();
      updateRecordsList({ scrollToTop:true });
      updateActionButtons();
      return true;
    }
    const result = api.addRecordFromState(runtime.state);
    runtime.records = Array.isArray(result?.records) ? result.records : api.readRecords();
    runtime.lastAddedRecordId = String(result?.record?.id || '').trim();
    runtime.selectedRecordId = '';
    runtime.editingRecordId = '';
    runtime.state = api.writeState(api.createEmptyState());
    runtime.dateInputDrafts = Object.create(null);
    runtime.isFormDialogOpen = false;
    runtime.isDialogMaximized = false;
    updateCustomerDialog();
    updateRecordsList({ scrollToTop:true });
    updateActionButtons();
    return true;
  }

  function commitField(fieldKey, nextValue){
    const safeFieldKey = String(fieldKey || '').trim();
    if(!safeFieldKey) return;
    runtime.state = api.writeState({ ...runtime.state, [safeFieldKey]: nextValue, updatedAt: Date.now() });
    updateActionButtons();
  }

  function handleInputEvent(event){
    const target = event.target;
    if(!(target instanceof HTMLElement)) return;

    if(target instanceof HTMLInputElement && target.dataset.customerCardSearch === 'true'){
      runtime.searchQuery = target.value || '';
      updateRecordsList({ scrollToTop:true });
      return;
    }

    if(target instanceof HTMLInputElement && target.dataset.customerCardPhoneCountrySearch === 'true'){
      runtime.phoneCountrySearchQuery = target.value || '';
      refreshPhoneCountryOptions();
      return;
    }

    if(target instanceof HTMLInputElement && target.dataset.customerCardDatePart){
      const fieldKey = String(target.dataset.customerCardDateField || '').trim();
      const partKey = String(target.dataset.customerCardDatePart || '').trim();
      if(!fieldKey || !partKey) return;
      const safeValue = sanitizeDateInputPart(partKey, target.value || '');
      if(target.value !== safeValue) target.value = safeValue;
      setDateInputDraftValue(fieldKey, partKey, safeValue);
      return;
    }

    const fieldKey = String(target.dataset.customerCardField || '').trim();
    if(!fieldKey) return;
    const definition = getFieldDefinition(fieldKey);
    if(!definition) return;
    const value = 'value' in target ? target.value : '';
    commitField(fieldKey, value);
  }

  function handleActionClick(event){
    const button = event.target instanceof Element ? event.target.closest('[data-customer-card-action]') : null;
    if(!(button instanceof HTMLButtonElement)) return false;
    const action = String(button.dataset.customerCardAction || '').trim();
    if(button.disabled) return true;
    event.preventDefault();
    if(action === 'clear'){
      clearDraft();
      return true;
    }
    if(action === 'create'){
      saveCustomerRecord();
      return true;
    }
    return false;
  }

  function handleToolbarRecordActionClick(event){
    const button = event.target instanceof Element ? event.target.closest('[data-customer-card-toolbar-action]') : null;
    if(!(button instanceof HTMLButtonElement)) return false;
    const action = String(button.dataset.customerCardToolbarAction || '').trim();
    if(button.disabled) return true;
    event.preventDefault();
    if(action === 'open-create-dialog'){
      return openCreateCustomerDialog();
    }
    if(action === 'edit-selected'){
      return openEditCustomerDialog(runtime.selectedRecordId);
    }
    if(action === 'delete-selected'){
      return requestDeleteSelectedRecord();
    }
    return false;
  }

  function handleRecordRowKeydown(event){
    const key = String(event.key || '').trim();
    if(key !== 'Enter' && key !== ' ' && key !== 'Spacebar') return false;
    const target = event.target instanceof Element ? event.target : null;
    const row = target ? target.closest('.customer-card-row[data-customer-card-record-id]') : null;
    if(!(row instanceof HTMLElement)) return false;
    event.preventDefault();
    const recordId = String(row.dataset.customerCardRecordId || '').trim();
    if(!recordId) return true;
    setSelectedRecord(recordId);
    return true;
  }

  function handleRecordRowActionClick(event){
    const target = event.target instanceof Element ? event.target : null;
    if(!target) return false;

    const button = target.closest('[data-customer-card-record-action="select"]');
    const row = target.closest('.customer-card-row[data-customer-card-record-id]');
    if(!(button instanceof HTMLButtonElement) && !(row instanceof HTMLElement)) return false;

    event.preventDefault();
    const source = button instanceof HTMLButtonElement ? button : row;
    const recordId = String(source.dataset.customerCardRecordId || '').trim();
    if(!recordId) return true;
    setSelectedRecord(recordId);
    return true;
  }

  function handleSearchActionClick(event){
    const button = event.target instanceof Element ? event.target.closest('[data-customer-card-search-action]') : null;
    if(!(button instanceof HTMLButtonElement)) return false;
    const action = String(button.dataset.customerCardSearchAction || '').trim();
    if(action !== 'clear') return false;
    event.preventDefault();
    runtime.searchQuery = '';
    updateSearchControls();
    updateRecordsList({ scrollToTop:true });
    const input = runtime.panel instanceof HTMLElement ? runtime.panel.querySelector('[data-customer-card-search="true"]') : null;
    if(input instanceof HTMLInputElement){
      try{ input.focus({ preventScroll:true }); }catch{ input.focus(); }
    }
    return true;
  }

  function handlePhoneCountrySearchActionClick(event){
    const button = event.target instanceof Element ? event.target.closest('[data-customer-card-phone-country-search-action]') : null;
    if(!(button instanceof HTMLButtonElement)) return false;
    const action = String(button.dataset.customerCardPhoneCountrySearchAction || '').trim();
    if(action !== 'clear') return false;
    event.preventDefault();
    runtime.phoneCountrySearchQuery = '';
    refreshPhoneCountryOptions();
    updatePhoneCountrySearchControls();
    const input = runtime.panel instanceof HTMLElement ? runtime.panel.querySelector('[data-customer-card-phone-country-search="true"]') : null;
    if(input instanceof HTMLInputElement){
      try{ input.focus({ preventScroll:true }); }catch{ input.focus(); }
    }
    return true;
  }

  function handleChoicePickerClick(event){
    const optionButton = event.target instanceof Element ? event.target.closest('[data-customer-card-choice-action="select"]') : null;
    if(optionButton instanceof HTMLButtonElement){
      event.preventDefault();
      const fieldKey = String(optionButton.dataset.customerCardChoiceField || '').trim();
      const value = String(optionButton.dataset.customerCardChoiceValue || '');
      if(!fieldKey) return true;
      commitField(fieldKey, value);
      runtime.openChoiceField = '';
      if(fieldKey === PHONE_COUNTRY_FIELD_KEY) runtime.phoneCountrySearchQuery = '';
      refreshFieldMarkup(fieldKey, { focusSelector: fieldKey === PHONE_COUNTRY_FIELD_KEY ? '[data-customer-card-field="phone"]' : '[data-customer-card-choice-trigger="true"]' });
      return true;
    }

    const triggerButton = event.target instanceof Element ? event.target.closest('[data-customer-card-choice-trigger="true"]') : null;
    if(!(triggerButton instanceof HTMLButtonElement)) return false;
    event.preventDefault();
    const fieldKey = String(triggerButton.dataset.customerCardChoiceField || '').trim();
    if(!fieldKey) return true;
    toggleChoicePicker(fieldKey);
    return true;
  }

  function handleDatePickerClick(event){
    const button = event.target instanceof Element ? event.target.closest('[data-customer-card-date-trigger="true"], [data-customer-card-date-action]') : null;
    if(!(button instanceof HTMLButtonElement)) return false;

    if(button.dataset.customerCardDateTrigger === 'true'){
      event.preventDefault();
      const fieldKey = String(button.dataset.customerCardDateField || '').trim();
      if(!fieldKey) return true;
      toggleDatePicker(fieldKey);
      return true;
    }

    const action = String(button.dataset.customerCardDateAction || '').trim();
    const fieldKey = String(button.dataset.customerCardDateField || '').trim();
    if(!action || !fieldKey) return false;
    event.preventDefault();

    if(action === 'close'){
      runtime.openDateField = fieldKey;
      closeDatePicker({ focus:true });
      return true;
    }

    if(action === 'today' || action === 'select-day'){
      const value = String(button.dataset.customerCardDateValue || '');
      delete runtime.dateInputDrafts[fieldKey];
      commitField(fieldKey, value);
      runtime.openDateField = '';
      runtime.datePickerMonthCursor = value ? String(value).slice(0, 7) : runtime.datePickerMonthCursor;
      runtime.datePickerView = 'days';
      refreshFieldMarkup(fieldKey, { focusSelector:'[data-customer-card-date-trigger="true"]' });
      return true;
    }

    if(action === 'clear'){
      delete runtime.dateInputDrafts[fieldKey];
      commitField(fieldKey, '');
      runtime.openDateField = '';
      runtime.datePickerView = 'days';
      refreshFieldMarkup(fieldKey, { focusSelector:'[data-customer-card-date-trigger="true"]' });
      return true;
    }

    if(action === 'prev-month'){
      runtime.openDateField = fieldKey;
      runtime.datePickerMonthCursor = shiftDatePickerMonthCursor(runtime.datePickerMonthCursor || resolveDatePickerMonthCursor(fieldKey, runtime.state[fieldKey] || ''), -1);
      refreshFieldMarkup(fieldKey, { focusSelector:'[data-customer-card-date-action="prev-month"]' });
      return true;
    }

    if(action === 'next-month'){
      runtime.openDateField = fieldKey;
      runtime.datePickerMonthCursor = shiftDatePickerMonthCursor(runtime.datePickerMonthCursor || resolveDatePickerMonthCursor(fieldKey, runtime.state[fieldKey] || ''), 1);
      refreshFieldMarkup(fieldKey, { focusSelector:'[data-customer-card-date-action="next-month"]' });
      return true;
    }

    if(action === 'prev-year'){
      runtime.openDateField = fieldKey;
      runtime.datePickerMonthCursor = shiftDatePickerMonthCursor(runtime.datePickerMonthCursor || resolveDatePickerMonthCursor(fieldKey, runtime.state[fieldKey] || ''), -12);
      refreshFieldMarkup(fieldKey, { focusSelector:'[data-customer-card-date-action="prev-year"]' });
      return true;
    }

    if(action === 'next-year'){
      runtime.openDateField = fieldKey;
      runtime.datePickerMonthCursor = shiftDatePickerMonthCursor(runtime.datePickerMonthCursor || resolveDatePickerMonthCursor(fieldKey, runtime.state[fieldKey] || ''), 12);
      refreshFieldMarkup(fieldKey, { focusSelector:'[data-customer-card-date-action="next-year"]' });
      return true;
    }

    if(action === 'toggle-view'){
      runtime.openDateField = fieldKey;
      runtime.datePickerView = normalizeDatePickerView(button.dataset.customerCardDateView || 'days');
      refreshFieldMarkup(fieldKey, { focusSelector:`[data-customer-card-date-action="toggle-view"]` });
      return true;
    }

    if(action === 'pick-month'){
      runtime.openDateField = fieldKey;
      runtime.datePickerMonthCursor = String(button.dataset.customerCardDateMonth || '').trim() || runtime.datePickerMonthCursor;
      runtime.datePickerView = 'days';
      refreshFieldMarkup(fieldKey, { focusSelector:'[data-customer-card-date-action="pick-month"][aria-pressed="true"], [data-customer-card-date-action="today"]' });
      return true;
    }

    return false;
  }

  function handleSegmentedClick(event){
    const button = event.target instanceof Element ? event.target.closest('[data-customer-card-segment]') : null;
    if(!(button instanceof HTMLButtonElement)) return;
    const container = button.closest('[data-customer-card-segmented-field]');
    if(!(container instanceof HTMLElement)) return;
    const fieldKey = String(container.dataset.customerCardSegmentedField || '').trim();
    if(!fieldKey) return;
    const value = String(button.dataset.customerCardSegment || '').trim();
    commitField(fieldKey, value);
    syncSegmentedUi(fieldKey, value);
  }

  function moveFocusInList(currentButton, direction){
    const list = currentButton.closest('[role="listbox"]');
    if(!(list instanceof HTMLElement)) return false;
    const buttons = Array.from(list.querySelectorAll('button[data-customer-card-choice-action="select"]')).filter((node) => node instanceof HTMLButtonElement);
    if(!buttons.length) return false;
    const currentIndex = buttons.indexOf(currentButton);
    if(currentIndex < 0) return false;
    let nextIndex = currentIndex;
    if(direction === 'next') nextIndex = (currentIndex + 1) % buttons.length;
    else if(direction === 'prev') nextIndex = (currentIndex - 1 + buttons.length) % buttons.length;
    else if(direction === 'first') nextIndex = 0;
    else if(direction === 'last') nextIndex = buttons.length - 1;
    const nextButton = buttons[nextIndex];
    if(!(nextButton instanceof HTMLButtonElement)) return true;
    try{ nextButton.focus({ preventScroll:true }); }catch{ nextButton.focus(); }
    return true;
  }

  function handlePickerKeydown(event){
    const key = String(event.key || '').trim();
    const target = event.target instanceof Element ? event.target : null;
    if(!target) return false;

    const choiceTrigger = target.closest('[data-customer-card-choice-trigger="true"]');
    if(choiceTrigger instanceof HTMLButtonElement){
      const fieldKey = String(choiceTrigger.dataset.customerCardChoiceField || '').trim();
      if((key === 'Enter' || key === ' ' || key === 'Spacebar' || key === 'ArrowDown' || key === 'ArrowUp') && fieldKey){
        event.preventDefault();
        openChoicePicker(fieldKey, { focusSelector:'[data-customer-card-choice-action="select"]' });
        return true;
      }
      if(key === 'Escape' && isChoicePickerOpen(fieldKey)){
        event.preventDefault();
        closeChoicePicker({ focus:true });
        return true;
      }
    }

    const phoneCountrySearch = target.closest('[data-customer-card-phone-country-search="true"]');
    if(phoneCountrySearch instanceof HTMLInputElement){
      if(key === 'ArrowDown'){
        event.preventDefault();
        const firstOption = runtime.panel?.querySelector('[data-customer-card-choice-field="phoneCountryCode"][data-customer-card-choice-action="select"]');
        if(firstOption instanceof HTMLButtonElement){
          try{ firstOption.focus({ preventScroll:true }); }catch{ firstOption.focus(); }
        }
        return true;
      }
      if(key === 'Escape'){
        event.preventDefault();
        closeChoicePicker({ focus:true });
        return true;
      }
    }

    const choiceOption = target.closest('[data-customer-card-choice-action="select"]');
    if(choiceOption instanceof HTMLButtonElement){
      if(key === 'ArrowDown'){
        event.preventDefault();
        return moveFocusInList(choiceOption, 'next');
      }
      if(key === 'ArrowUp'){
        event.preventDefault();
        return moveFocusInList(choiceOption, 'prev');
      }
      if(key === 'Home'){
        event.preventDefault();
        return moveFocusInList(choiceOption, 'first');
      }
      if(key === 'End'){
        event.preventDefault();
        return moveFocusInList(choiceOption, 'last');
      }
      if(key === 'Enter' || key === ' ' || key === 'Spacebar'){
        event.preventDefault();
        choiceOption.click();
        return true;
      }
      if(key === 'Escape'){
        event.preventDefault();
        closeChoicePicker({ focus:true });
        return true;
      }
    }

    const dateInput = target.closest('[data-customer-card-date-part]');
    if(dateInput instanceof HTMLInputElement){
      const fieldKey = String(dateInput.dataset.customerCardDateField || '').trim();
      if(key === 'ArrowDown' && fieldKey){
        event.preventDefault();
        openDatePicker(fieldKey, { focusSelector:'[data-customer-card-date-action="today"]' });
        return true;
      }
      if(key === 'Escape' && fieldKey && isDatePickerOpen(fieldKey)){
        event.preventDefault();
        closeDatePicker({ focus:true });
        return true;
      }
    }

    const dateTrigger = target.closest('[data-customer-card-date-trigger="true"]');
    if(dateTrigger instanceof HTMLButtonElement){
      const fieldKey = String(dateTrigger.dataset.customerCardDateField || '').trim();
      if((key === 'Enter' || key === ' ' || key === 'Spacebar' || key === 'ArrowDown' || key === 'ArrowUp') && fieldKey){
        event.preventDefault();
        openDatePicker(fieldKey, { focusSelector:'[data-customer-card-date-action="today"]' });
        return true;
      }
      if(key === 'Escape' && isDatePickerOpen(fieldKey)){
        event.preventDefault();
        closeDatePicker({ focus:true });
        return true;
      }
    }

    const dateControl = target.closest('[data-customer-card-date-action]');
    if(dateControl instanceof HTMLButtonElement && key === 'Escape'){
      event.preventDefault();
      closeDatePicker({ focus:true });
      return true;
    }

    return false;
  }

  function handleSegmentedKeydown(event){
    const button = event.target instanceof Element ? event.target.closest('[data-customer-card-segment]') : null;
    if(!(button instanceof HTMLButtonElement)) return false;
    const container = button.closest('[data-customer-card-segmented-field]');
    if(!(container instanceof HTMLElement)) return false;

    const buttons = Array.from(container.querySelectorAll('[data-customer-card-segment]')).filter((entry) => entry instanceof HTMLButtonElement);
    if(!buttons.length) return false;

    const currentIndex = buttons.indexOf(button);
    if(currentIndex < 0) return false;

    const key = String(event.key || '').trim();
    if(key === 'Enter' || key === 'NumpadEnter'){
      event.preventDefault();
      const fieldKey = String(container.dataset.customerCardSegmentedField || '').trim();
      if(!fieldKey) return true;
      const value = String(button.dataset.customerCardSegment || '').trim();
      commitField(fieldKey, value);
      syncSegmentedUi(fieldKey, value);
      focusRelativeFormFlowTarget(button, event.shiftKey ? -1 : 1, { clamp:true });
      return true;
    }

    if(buttons.length < 2) return false;

    let nextIndex = -1;
    if(key === 'ArrowRight' || key === 'ArrowDown') nextIndex = (currentIndex + 1) % buttons.length;
    else if(key === 'ArrowLeft' || key === 'ArrowUp') nextIndex = (currentIndex - 1 + buttons.length) % buttons.length;
    else if(key === 'Home') nextIndex = 0;
    else if(key === 'End') nextIndex = buttons.length - 1;
    else return false;

    event.preventDefault();
    const nextButton = buttons[nextIndex];
    if(!(nextButton instanceof HTMLButtonElement)) return true;
    const fieldKey = String(container.dataset.customerCardSegmentedField || '').trim();
    if(!fieldKey) return true;
    const value = String(nextButton.dataset.customerCardSegment || '').trim();
    commitField(fieldKey, value);
    syncSegmentedUi(fieldKey, value, { focus:true });
    return true;
  }

  function cleanupView(){
    closeDeleteConfirmDialog();
    if(typeof runtime.detachPanelEvents === 'function'){
      try{ runtime.detachPanelEvents(); }catch{}
      runtime.detachPanelEvents = null;
    }
    if(typeof runtime.detachFormNavigation === 'function'){
      try{ runtime.detachFormNavigation(); }catch{}
      runtime.detachFormNavigation = null;
    }
    runtime.panel = null;
    runtime.openChoiceField = '';
    runtime.phoneCountrySearchQuery = '';
    runtime.openDateField = '';
    runtime.datePickerMonthCursor = '';
    runtime.datePickerView = 'days';
  }

  TAIF.registerViewCleanup('customer-card', cleanupView);
  TAIF.registerViewRenderer('customer-card', ({ panel }) => {
    renderCustomerCard(panel);
  });
})();
