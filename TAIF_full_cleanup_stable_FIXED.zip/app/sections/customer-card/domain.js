(()=>{
  const TAIF = window.TAIF;
  if(!TAIF || !TAIF.core || !TAIF.core.utils) return;

  const utils = TAIF.core.utils;
  const clone = typeof utils.clone === 'function' ? utils.clone : (value) => JSON.parse(JSON.stringify(value));
  const readJsonStorage = typeof utils.readJsonStorage === 'function' ? utils.readJsonStorage : (() => null);
  const persistJsonState = typeof utils.persistJsonState === 'function' ? utils.persistJsonState : ((_, value) => value);
  const toText = typeof utils.toText === 'function' ? utils.toText : ((value) => String(value ?? '').trim());
  const storageKeys = TAIF?.core?.storageKeys || {};
  const STORAGE_KEY = storageKeys.customerCard || 'taif-customer-card-module-v1';
  const DOMAIN_VERSION = 2;

  const OPTION_SETS = Object.freeze({
    genders: Object.freeze([
      Object.freeze({ value:'male', label:'ذكر' }),
      Object.freeze({ value:'female', label:'أنثى' })
    ]),
    entityTypes: Object.freeze([
      Object.freeze({ value:'person', label:'شخصي' }),
      Object.freeze({ value:'company', label:'شركة' })
    ]),
    idTypes: Object.freeze([
      Object.freeze({ value:'', label:'اختر نوع التعريف' }),
      Object.freeze({ value:'national-id', label:'رقم وطني' }),
      Object.freeze({ value:'passport', label:'جواز سفر' }),
      Object.freeze({ value:'identity-card', label:'بطاقة شخصية' }),
      Object.freeze({ value:'residency', label:'إقامة' }),
      Object.freeze({ value:'driving-license', label:'رخصة قيادة' }),
      Object.freeze({ value:'commercial-register', label:'سجل تجاري' })
    ])
  });

  const PHONE_COUNTRY_CATALOG = Object.freeze([
    Object.freeze({"code":"sy","label":"سوريا","dialCode":"+963","englishLabel":"Syria","searchText":"سوريا Syria Syrian Arab Republic SY Al-Jumhūrīyah Al-ʻArabīyah As-Sūrīyah +963 SY"}),
    Object.freeze({"code":"tr","label":"تركيا","dialCode":"+90","englishLabel":"Türkiye","searchText":"تركيا Türkiye Republic of Türkiye TR Turkiye Republic of Turkey Türkiye Cumhuriyeti +90 TR"}),
    Object.freeze({"code":"sa","label":"المملكة العربية السعودية","dialCode":"+966","englishLabel":"Saudi Arabia","searchText":"المملكة العربية السعودية Saudi Arabia Kingdom of Saudi Arabia SA Al-Mamlakah al-‘Arabiyyah as-Su‘ūdiyyah +966 SA"}),
    Object.freeze({"code":"ae","label":"الإمارات العربية المتحدة","dialCode":"+971","englishLabel":"United Arab Emirates","searchText":"الإمارات العربية المتحدة United Arab Emirates AE UAE +971 AE"}),
    Object.freeze({"code":"jo","label":"الأردن","dialCode":"+962","englishLabel":"Jordan","searchText":"الأردن Jordan Hashemite Kingdom of Jordan JO al-Mamlakah al-Urdunīyah al-Hāshimīyah +962 JO"}),
    Object.freeze({"code":"lb","label":"لبنان","dialCode":"+961","englishLabel":"Lebanon","searchText":"لبنان Lebanon Lebanese Republic LB Al-Jumhūrīyah Al-Libnānīyah +961 LB"}),
    Object.freeze({"code":"iq","label":"العراق","dialCode":"+964","englishLabel":"Iraq","searchText":"العراق Iraq Republic of Iraq IQ Jumhūriyyat al-‘Irāq +964 IQ"}),
    Object.freeze({"code":"eg","label":"مصر","dialCode":"+20","englishLabel":"Egypt","searchText":"مصر Egypt Arab Republic of Egypt EG +20 EG"}),
    Object.freeze({"code":"ye","label":"اليمن","dialCode":"+967","englishLabel":"Yemen","searchText":"اليمن Yemen Republic of Yemen YE Yemeni Republic al-Jumhūriyyah al-Yamaniyyah +967 YE"}),
    Object.freeze({"code":"om","label":"عُمان","dialCode":"+968","englishLabel":"Oman","searchText":"عُمان Oman Sultanate of Oman OM Salṭanat ʻUmān +968 OM"}),
    Object.freeze({"code":"qa","label":"قطر","dialCode":"+974","englishLabel":"Qatar","searchText":"قطر Qatar State of Qatar QA Dawlat Qaṭar +974 QA"}),
    Object.freeze({"code":"kw","label":"الكويت","dialCode":"+965","englishLabel":"Kuwait","searchText":"الكويت Kuwait State of Kuwait KW Dawlat al-Kuwait +965 KW"}),
    Object.freeze({"code":"bh","label":"البحرين","dialCode":"+973","englishLabel":"Bahrain","searchText":"البحرين Bahrain Kingdom of Bahrain BH Mamlakat al-Baḥrayn +973 BH"}),
    Object.freeze({"code":"ps","label":"الأراضي الفلسطينية","dialCode":"+970","englishLabel":"Palestine, State of","searchText":"الأراضي الفلسطينية Palestine, State of the State of Palestine Palestine State of Palestine +970 PS"}),
    Object.freeze({"code":"tn","label":"تونس","dialCode":"+216","englishLabel":"Tunisia","searchText":"تونس Tunisia Republic of Tunisia TN al-Jumhūriyyah at-Tūnisiyyah +216 TN"}),
    Object.freeze({"code":"dz","label":"الجزائر","dialCode":"+213","englishLabel":"Algeria","searchText":"الجزائر Algeria People's Democratic Republic of Algeria DZ Dzayer Algérie +213 DZ"}),
    Object.freeze({"code":"ma","label":"المغرب","dialCode":"+212","englishLabel":"Morocco","searchText":"المغرب Morocco Kingdom of Morocco MA Al-Mamlakah al-Maġribiyah +212 MA"}),
    Object.freeze({"code":"ly","label":"ليبيا","dialCode":"+218","englishLabel":"Libya","searchText":"ليبيا Libya LY State of Libya Dawlat Libya +218 LY"}),
    Object.freeze({"code":"sd","label":"السودان","dialCode":"+249","englishLabel":"Sudan","searchText":"السودان Sudan Republic of the Sudan SD Jumhūrīyat as-Sūdān +249 SD"}),
    Object.freeze({"code":"gb","label":"المملكة المتحدة","dialCode":"+44","englishLabel":"United Kingdom","searchText":"المملكة المتحدة United Kingdom United Kingdom of Great Britain and Northern Ireland GB UK Great Britain +44 GB"}),
    Object.freeze({"code":"de","label":"ألمانيا","dialCode":"+49","englishLabel":"Germany","searchText":"ألمانيا Germany Federal Republic of Germany DE Bundesrepublik Deutschland +49 DE"}),
    Object.freeze({"code":"fr","label":"فرنسا","dialCode":"+33","englishLabel":"France","searchText":"فرنسا France French Republic FR République française +33 FR"}),
    Object.freeze({"code":"it","label":"إيطاليا","dialCode":"+39","englishLabel":"Italy","searchText":"إيطاليا Italy Italian Republic IT Repubblica italiana +39 IT"}),
    Object.freeze({"code":"es","label":"إسبانيا","dialCode":"+34","englishLabel":"Spain","searchText":"إسبانيا Spain Kingdom of Spain ES Reino de España +34 ES"}),
    Object.freeze({"code":"us","label":"الولايات المتحدة","dialCode":"+1","englishLabel":"United States","searchText":"الولايات المتحدة United States United States of America US USA +1 US"}),
    Object.freeze({"code":"az","label":"أذربيجان","dialCode":"+994","englishLabel":"Azerbaijan","searchText":"أذربيجان Azerbaijan Republic of Azerbaijan AZ Azərbaycan Respublikası +994 AZ"}),
    Object.freeze({"code":"am","label":"أرمينيا","dialCode":"+374","englishLabel":"Armenia","searchText":"أرمينيا Armenia Republic of Armenia AM Hayastan Հայաստանի Հանրապետություն +374 AM"}),
    Object.freeze({"code":"au","label":"أستراليا","dialCode":"+61","englishLabel":"Australia","searchText":"أستراليا Australia AU +61 AU"}),
    Object.freeze({"code":"af","label":"أفغانستان","dialCode":"+93","englishLabel":"Afghanistan","searchText":"أفغانستان Afghanistan Islamic Republic of Afghanistan AF Afġānistān +93 AF"}),
    Object.freeze({"code":"uz","label":"أوزبكستان","dialCode":"+998","englishLabel":"Uzbekistan","searchText":"أوزبكستان Uzbekistan Republic of Uzbekistan UZ O‘zbekiston Respublikasi Ўзбекистон Республикаси +998 UZ"}),
    Object.freeze({"code":"ug","label":"أوغندا","dialCode":"+256","englishLabel":"Uganda","searchText":"أوغندا Uganda Republic of Uganda UG Jamhuri ya Uganda +256 UG"}),
    Object.freeze({"code":"ua","label":"أوكرانيا","dialCode":"+380","englishLabel":"Ukraine","searchText":"أوكرانيا Ukraine UA Ukrayina +380 UA"}),
    Object.freeze({"code":"ie","label":"أيرلندا","dialCode":"+353","englishLabel":"Ireland","searchText":"أيرلندا Ireland IE Éire Republic of Ireland Poblacht na hÉireann +353 IE"}),
    Object.freeze({"code":"et","label":"إثيوبيا","dialCode":"+251","englishLabel":"Ethiopia","searchText":"إثيوبيا Ethiopia Federal Democratic Republic of Ethiopia ET ʾĪtyōṗṗyā የኢትዮጵያ ፌዴራላዊ ዲሞክራሲያዊ ሪፐብሊክ +251 ET"}),
    Object.freeze({"code":"er","label":"إريتريا","dialCode":"+291","englishLabel":"Eritrea","searchText":"إريتريا Eritrea the State of Eritrea ER State of Eritrea ሃገረ ኤርትራ Dawlat Iritriyá ʾErtrā Iritriyā +291 ER"}),
    Object.freeze({"code":"id","label":"إندونيسيا","dialCode":"+62","englishLabel":"Indonesia","searchText":"إندونيسيا Indonesia Republic of Indonesia ID Republik Indonesia +62 ID"}),
    Object.freeze({"code":"ir","label":"إيران","dialCode":"+98","englishLabel":"Iran","searchText":"إيران Iran Islamic Republic of Iran Iran, Islamic Republic of IR Jomhuri-ye Eslāmi-ye Irān +98 IR"}),
    Object.freeze({"code":"ar","label":"الأرجنتين","dialCode":"+54","englishLabel":"Argentina","searchText":"الأرجنتين Argentina Argentine Republic AR República Argentina +54 AR"}),
    Object.freeze({"code":"ec","label":"الإكوادور","dialCode":"+593","englishLabel":"Ecuador","searchText":"الإكوادور Ecuador Republic of Ecuador EC República del Ecuador +593 EC"}),
    Object.freeze({"code":"br","label":"البرازيل","dialCode":"+55","englishLabel":"Brazil","searchText":"البرازيل Brazil Federative Republic of Brazil BR Brasil República Federativa do Brasil +55 BR"}),
    Object.freeze({"code":"pt","label":"البرتغال","dialCode":"+351","englishLabel":"Portugal","searchText":"البرتغال Portugal Portuguese Republic PT Portuguesa República Portuguesa +351 PT"}),
    Object.freeze({"code":"cz","label":"التشيك","dialCode":"+420","englishLabel":"Czechia","searchText":"التشيك Czechia Czech Republic CZ Česká republika Česko +420 CZ"}),
    Object.freeze({"code":"dk","label":"الدانمرك","dialCode":"+45","englishLabel":"Denmark","searchText":"الدانمرك Denmark Kingdom of Denmark DK Danmark Kongeriget Danmark +45 DK"}),
    Object.freeze({"code":"sv","label":"السلفادور","dialCode":"+503","englishLabel":"El Salvador","searchText":"السلفادور El Salvador Republic of El Salvador SV República de El Salvador +503 SV"}),
    Object.freeze({"code":"sn","label":"السنغال","dialCode":"+221","englishLabel":"Senegal","searchText":"السنغال Senegal Republic of Senegal SN République du Sénégal +221 SN"}),
    Object.freeze({"code":"se","label":"السويد","dialCode":"+46","englishLabel":"Sweden","searchText":"السويد Sweden Kingdom of Sweden SE Konungariket Sverige +46 SE"}),
    Object.freeze({"code":"so","label":"الصومال","dialCode":"+252","englishLabel":"Somalia","searchText":"الصومال Somalia Federal Republic of Somalia SO aṣ-Ṣūmāl Jamhuuriyadda Federaalka Soomaaliya Jumhūriyyat aṣ-Ṣūmāl al-Fiderāliyya +252 SO"}),
    Object.freeze({"code":"cn","label":"الصين","dialCode":"+86","englishLabel":"China","searchText":"الصين China People's Republic of China CN Zhōngguó Zhongguo Zhonghua 中华人民共和国 Zhōnghuá Rénmín Gònghéguó +86 CN"}),
    Object.freeze({"code":"ph","label":"الفلبين","dialCode":"+63","englishLabel":"Philippines","searchText":"الفلبين Philippines Republic of the Philippines PH Repúblika ng Pilipinas +63 PH"}),
    Object.freeze({"code":"cm","label":"الكاميرون","dialCode":"+237","englishLabel":"Cameroon","searchText":"الكاميرون Cameroon Republic of Cameroon CM République du Cameroun +237 CM"}),
    Object.freeze({"code":"mx","label":"المكسيك","dialCode":"+52","englishLabel":"Mexico","searchText":"المكسيك Mexico United Mexican States MX Mexicanos Estados Unidos Mexicanos +52 MX"}),
    Object.freeze({"code":"no","label":"النرويج","dialCode":"+47","englishLabel":"Norway","searchText":"النرويج Norway Kingdom of Norway NO Norge Noreg Kongeriket Norge Kongeriket Noreg +47 NO"}),
    Object.freeze({"code":"at","label":"النمسا","dialCode":"+43","englishLabel":"Austria","searchText":"النمسا Austria Republic of Austria AT Österreich Osterreich Oesterreich +43 AT"}),
    Object.freeze({"code":"in","label":"الهند","dialCode":"+91","englishLabel":"India","searchText":"الهند India Republic of India IN Bhārat Bharat Ganrajya +91 IN"}),
    Object.freeze({"code":"jp","label":"اليابان","dialCode":"+81","englishLabel":"Japan","searchText":"اليابان Japan JP Nippon Nihon +81 JP"}),
    Object.freeze({"code":"gr","label":"اليونان","dialCode":"+30","englishLabel":"Greece","searchText":"اليونان Greece Hellenic Republic GR Elláda Ελληνική Δημοκρατία +30 GR"}),
    Object.freeze({"code":"pk","label":"باكستان","dialCode":"+92","englishLabel":"Pakistan","searchText":"باكستان Pakistan Islamic Republic of Pakistan PK Pākistān Islāmī Jumhūriya'eh Pākistān +92 PK"}),
    Object.freeze({"code":"be","label":"بلجيكا","dialCode":"+32","englishLabel":"Belgium","searchText":"بلجيكا Belgium Kingdom of Belgium BE België Belgie Belgien Belgique Koninkrijk België Royaume de Belgique Königreich Belgien +32 BE"}),
    Object.freeze({"code":"bd","label":"بنغلاديش","dialCode":"+880","englishLabel":"Bangladesh","searchText":"بنغلاديش Bangladesh People's Republic of Bangladesh BD Gônôprôjatôntri Bangladesh +880 BD"}),
    Object.freeze({"code":"pa","label":"بنما","dialCode":"+507","englishLabel":"Panama","searchText":"بنما Panama Republic of Panama PA República de Panamá +507 PA"}),
    Object.freeze({"code":"pl","label":"بولندا","dialCode":"+48","englishLabel":"Poland","searchText":"بولندا Poland Republic of Poland PL Rzeczpospolita Polska +48 PL"}),
    Object.freeze({"code":"pe","label":"بيرو","dialCode":"+51","englishLabel":"Peru","searchText":"بيرو Peru Republic of Peru PE República del Perú +51 PE"}),
    Object.freeze({"code":"by","label":"بيلاروس","dialCode":"+375","englishLabel":"Belarus","searchText":"بيلاروس Belarus Republic of Belarus BY Bielaruś Белоруссия Республика Беларусь Belorussiya Respublika Belarus’ +375 BY"}),
    Object.freeze({"code":"th","label":"تايلاند","dialCode":"+66","englishLabel":"Thailand","searchText":"تايلاند Thailand Kingdom of Thailand TH Prathet Thai ราชอาณาจักรไทย Ratcha Anachak Thai +66 TH"}),
    Object.freeze({"code":"cl","label":"تشيلي","dialCode":"+56","englishLabel":"Chile","searchText":"تشيلي Chile Republic of Chile CL República de Chile +56 CL"}),
    Object.freeze({"code":"tz","label":"تنزانيا","dialCode":"+255","englishLabel":"Tanzania","searchText":"تنزانيا Tanzania United Republic of Tanzania Tanzania, United Republic of TZ Jamhuri ya Muungano wa Tanzania +255 TZ"}),
    Object.freeze({"code":"km","label":"جزر القمر","dialCode":"+269","englishLabel":"Comoros","searchText":"جزر القمر Comoros Union of the Comoros KM Union des Comores Udzima wa Komori al-Ittiḥād al-Qumurī +269 KM"}),
    Object.freeze({"code":"do","label":"جمهورية الدومينيكان","dialCode":"+1809","englishLabel":"Dominican Republic","searchText":"جمهورية الدومينيكان Dominican Republic DO +1809 DO"}),
    Object.freeze({"code":"za","label":"جنوب أفريقيا","dialCode":"+27","englishLabel":"South Africa","searchText":"جنوب أفريقيا South Africa Republic of South Africa ZA RSA Suid-Afrika +27 ZA"}),
    Object.freeze({"code":"ge","label":"جورجيا","dialCode":"+995","englishLabel":"Georgia","searchText":"جورجيا Georgia GE Sakartvelo +995 GE"}),
    Object.freeze({"code":"dj","label":"جيبوتي","dialCode":"+253","englishLabel":"Djibouti","searchText":"جيبوتي Djibouti Republic of Djibouti DJ Jabuuti Gabuuti République de Djibouti Gabuutih Ummuuno Jamhuuriyadda Jabuuti +253 DJ"}),
    Object.freeze({"code":"rw","label":"رواندا","dialCode":"+250","englishLabel":"Rwanda","searchText":"رواندا Rwanda Rwandese Republic RW Republic of Rwanda Repubulika y'u Rwanda République du Rwanda +250 RW"}),
    Object.freeze({"code":"ru","label":"روسيا","dialCode":"+7","englishLabel":"Russian Federation","searchText":"روسيا Russian Federation RU Rossiya Российская Федерация Rossiyskaya Federatsiya +7 RU"}),
    Object.freeze({"code":"ro","label":"رومانيا","dialCode":"+40","englishLabel":"Romania","searchText":"رومانيا Romania RO Rumania Roumania România +40 RO"}),
    Object.freeze({"code":"zm","label":"زامبيا","dialCode":"+260","englishLabel":"Zambia","searchText":"زامبيا Zambia Republic of Zambia ZM +260 ZM"}),
    Object.freeze({"code":"zw","label":"زيمبابوي","dialCode":"+263","englishLabel":"Zimbabwe","searchText":"زيمبابوي Zimbabwe Republic of Zimbabwe ZW +263 ZW"}),
    Object.freeze({"code":"ci","label":"ساحل العاج","dialCode":"+225","englishLabel":"Côte d'Ivoire","searchText":"ساحل العاج Côte d'Ivoire Republic of Côte d'Ivoire CI Ivory Coast République de Côte d'Ivoire +225 CI"}),
    Object.freeze({"code":"lk","label":"سريلانكا","dialCode":"+94","englishLabel":"Sri Lanka","searchText":"سريلانكا Sri Lanka Democratic Socialist Republic of Sri Lanka LK ilaṅkai +94 LK"}),
    Object.freeze({"code":"sg","label":"سنغافورة","dialCode":"+65","englishLabel":"Singapore","searchText":"سنغافورة Singapore Republic of Singapore SG Singapura Republik Singapura 新加坡共和国 +65 SG"}),
    Object.freeze({"code":"ch","label":"سويسرا","dialCode":"+41","englishLabel":"Switzerland","searchText":"سويسرا Switzerland Swiss Confederation CH Schweiz Suisse Svizzera Svizra +41 CH"}),
    Object.freeze({"code":"tj","label":"طاجيكستان","dialCode":"+992","englishLabel":"Tajikistan","searchText":"طاجيكستان Tajikistan Republic of Tajikistan TJ Toçikiston Ҷумҳурии Тоҷикистон Çumhuriyi Toçikiston +992 TJ"}),
    Object.freeze({"code":"gh","label":"غانا","dialCode":"+233","englishLabel":"Ghana","searchText":"غانا Ghana Republic of Ghana GH +233 GH"}),
    Object.freeze({"code":"gt","label":"غواتيمالا","dialCode":"+502","englishLabel":"Guatemala","searchText":"غواتيمالا Guatemala Republic of Guatemala GT +502 GT"}),
    Object.freeze({"code":"vn","label":"فيتنام","dialCode":"+84","englishLabel":"Vietnam","searchText":"فيتنام Vietnam Socialist Republic of Viet Nam Viet Nam VN Socialist Republic of Vietnam Cộng hòa Xã hội chủ nghĩa Việt Nam +84 VN"}),
    Object.freeze({"code":"cy","label":"قبرص","dialCode":"+357","englishLabel":"Cyprus","searchText":"قبرص Cyprus Republic of Cyprus CY Kýpros Kıbrıs Κυπριακή Δημοκρατία Kıbrıs Cumhuriyeti +357 CY"}),
    Object.freeze({"code":"kg","label":"قيرغيزستان","dialCode":"+996","englishLabel":"Kyrgyzstan","searchText":"قيرغيزستان Kyrgyzstan Kyrgyz Republic KG Киргизия Кыргыз Республикасы Kyrgyz Respublikasy +996 KG"}),
    Object.freeze({"code":"kz","label":"كازاخستان","dialCode":"+76","englishLabel":"Kazakhstan","searchText":"كازاخستان Kazakhstan Republic of Kazakhstan KZ Qazaqstan Казахстан Қазақстан Республикасы Qazaqstan Respublïkası Республика Казахстан Respublika Kazakhstan +76 KZ"}),
    Object.freeze({"code":"kh","label":"كمبوديا","dialCode":"+855","englishLabel":"Cambodia","searchText":"كمبوديا Cambodia Kingdom of Cambodia KH +855 KH"}),
    Object.freeze({"code":"ca","label":"كندا","dialCode":"+1","englishLabel":"Canada","searchText":"كندا Canada CA +1 CA"}),
    Object.freeze({"code":"kr","label":"كوريا الجنوبية","dialCode":"+82","englishLabel":"South Korea","searchText":"كوريا الجنوبية South Korea Korea, Republic of KR Republic of Korea +82 KR"}),
    Object.freeze({"code":"cr","label":"كوستاريكا","dialCode":"+506","englishLabel":"Costa Rica","searchText":"كوستاريكا Costa Rica Republic of Costa Rica CR República de Costa Rica +506 CR"}),
    Object.freeze({"code":"co","label":"كولومبيا","dialCode":"+57","englishLabel":"Colombia","searchText":"كولومبيا Colombia Republic of Colombia CO República de Colombia +57 CO"}),
    Object.freeze({"code":"ke","label":"كينيا","dialCode":"+254","englishLabel":"Kenya","searchText":"كينيا Kenya Republic of Kenya KE Jamhuri ya Kenya +254 KE"}),
    Object.freeze({"code":"la","label":"لاوس","dialCode":"+856","englishLabel":"Laos","searchText":"لاوس Laos Lao People's Democratic Republic LA Lao Sathalanalat Paxathipatai Paxaxon Lao +856 LA"}),
    Object.freeze({"code":"my","label":"ماليزيا","dialCode":"+60","englishLabel":"Malaysia","searchText":"ماليزيا Malaysia MY +60 MY"}),
    Object.freeze({"code":"mr","label":"موريتانيا","dialCode":"+222","englishLabel":"Mauritania","searchText":"موريتانيا Mauritania Islamic Republic of Mauritania MR al-Jumhūriyyah al-ʾIslāmiyyah al-Mūrītāniyyah +222 MR"}),
    Object.freeze({"code":"mz","label":"موزمبيق","dialCode":"+258","englishLabel":"Mozambique","searchText":"موزمبيق Mozambique Republic of Mozambique MZ República de Moçambique +258 MZ"}),
    Object.freeze({"code":"md","label":"مولدوفا","dialCode":"+373","englishLabel":"Moldova","searchText":"مولدوفا Moldova Republic of Moldova Moldova, Republic of MD Republica Moldova +373 MD"}),
    Object.freeze({"code":"mm","label":"ميانمار (بورما)","dialCode":"+95","englishLabel":"Myanmar","searchText":"ميانمار (بورما) Myanmar Republic of Myanmar Burma +95 MM"}),
    Object.freeze({"code":"np","label":"نيبال","dialCode":"+977","englishLabel":"Nepal","searchText":"نيبال Nepal Federal Democratic Republic of Nepal NP Loktāntrik Ganatantra Nepāl +977 NP"}),
    Object.freeze({"code":"ng","label":"نيجيريا","dialCode":"+234","englishLabel":"Nigeria","searchText":"نيجيريا Nigeria Federal Republic of Nigeria NG Nijeriya Naíjíríà +234 NG"}),
    Object.freeze({"code":"ni","label":"نيكاراغوا","dialCode":"+505","englishLabel":"Nicaragua","searchText":"نيكاراغوا Nicaragua Republic of Nicaragua NI República de Nicaragua +505 NI"}),
    Object.freeze({"code":"nz","label":"نيوزيلندا","dialCode":"+64","englishLabel":"New Zealand","searchText":"نيوزيلندا New Zealand NZ Aotearoa +64 NZ"}),
    Object.freeze({"code":"hn","label":"هندوراس","dialCode":"+504","englishLabel":"Honduras","searchText":"هندوراس Honduras Republic of Honduras HN República de Honduras +504 HN"}),
    Object.freeze({"code":"hu","label":"هنغاريا","dialCode":"+36","englishLabel":"Hungary","searchText":"هنغاريا Hungary HU +36 HU"}),
    Object.freeze({"code":"nl","label":"هولندا","dialCode":"+31","englishLabel":"Netherlands","searchText":"هولندا Netherlands Kingdom of the Netherlands NL Holland Nederland +31 NL"}),
    Object.freeze({"code":"hk","label":"هونغ كونغ الصينية (منطقة إدارية خاصة)","dialCode":"+852","englishLabel":"Hong Kong","searchText":"هونغ كونغ الصينية (منطقة إدارية خاصة) Hong Kong Hong Kong Special Administrative Region of China HK 香港 +852 HK"})
  ]);
  const PHONE_COUNTRY_LOOKUP = Object.freeze(PHONE_COUNTRY_CATALOG.reduce((lookup, entry) => {
    lookup[entry.code] = entry;
    return lookup;
  }, {}));
  const PHONE_DIAL_MATCHERS = Object.freeze(PHONE_COUNTRY_CATALOG
    .filter((entry) => entry && entry.dialCode)
    .slice()
    .sort((left, right) => String(right?.dialCode || '').length - String(left?.dialCode || '').length));
  const PHONE_LOCAL_MAX_LENGTH = 18;

  const GROUPS = Object.freeze([
    Object.freeze({
      key:'identity',
      title:'البيانات الأساسية',
      fields:Object.freeze([
        Object.freeze({ key:'fullName', label:'الاسم الكامل', control:'input', type:'text', placeholder:'الاسم الكامل', row:'identity-main', autoComplete:'name' }),
        Object.freeze({ key:'latinName', label:'الاسم اللاتيني', control:'input', type:'text', placeholder:'Full Latin Name', row:'identity-main', dir:'ltr', autoComplete:'off' }),
        Object.freeze({ key:'incomeSource', label:'مصدر الدخل', control:'input', type:'text', placeholder:'مصدر الدخل', row:'identity-main' }),
        Object.freeze({ key:'phone', label:'رقم الهاتف', control:'phone', type:'tel', placeholder:'الرقم بدون صفر', dir:'ltr', inputMode:'tel', autoComplete:'tel', row:'identity-contact' }),
        Object.freeze({ key:'nationality', label:'الجنسية', control:'input', type:'text', placeholder:'الجنسية', row:'identity-contact' }),
        Object.freeze({ key:'gender', label:'الجنس', control:'segmented', optionsKey:'genders', row:'identity-contact' }),
        Object.freeze({ key:'entityType', label:'نوع العميل', control:'segmented', optionsKey:'entityTypes', row:'identity-identification' }),
        Object.freeze({ key:'idType', label:'نوع التعريف', control:'select', optionsKey:'idTypes', row:'identity-identification' }),
        Object.freeze({ key:'idNumber', label:'رقم التعريف', control:'input', type:'text', placeholder:'رقم التعريف', dir:'ltr', inputMode:'text', row:'identity-identification' }),
        Object.freeze({ key:'issuedBy', label:'صادرة عن', control:'input', type:'text', placeholder:'الجهة المصدرة', row:'identity-issued' }),
        Object.freeze({ key:'issueDate', label:'تاريخ المنح', control:'input', type:'date', row:'identity-issued' }),
        Object.freeze({ key:'expiryDate', label:'تاريخ الصلاحية', control:'input', type:'date', row:'identity-issued' }),
        Object.freeze({ key:'birthPlace', label:'مكان الولادة', control:'input', type:'text', placeholder:'مكان الولادة', row:'birth-main' }),
        Object.freeze({ key:'birthDate', label:'تاريخ الولادة', control:'input', type:'date', row:'birth-main' }),
        Object.freeze({ key:'motherName', label:'اسم الأم', control:'input', type:'text', placeholder:'اسم الأم', row:'birth-main' })
      ])
    }),
    Object.freeze({
      key:'address',
      title:'العنوان',
      fields:Object.freeze([
        Object.freeze({ key:'country', label:'البلد', control:'input', type:'text', placeholder:'البلد', row:'address-main' }),
        Object.freeze({ key:'city', label:'المدينة', control:'input', type:'text', placeholder:'المدينة', row:'address-main' }),
        Object.freeze({ key:'region', label:'المنطقة', control:'input', type:'text', placeholder:'المنطقة', row:'address-main' }),
        Object.freeze({ key:'district', label:'الحي', control:'input', type:'text', placeholder:'الحي', row:'address-detail' }),
        Object.freeze({ key:'street', label:'الشارع', control:'input', type:'text', placeholder:'الشارع', row:'address-detail' }),
        Object.freeze({ key:'otherDetails', label:'تفاصيل أخرى', control:'input', type:'text', placeholder:'تفاصيل إضافية', row:'address-detail' })
      ])
    })
  ]);

  const TEXT_FIELD_KEYS = Object.freeze([
    'fullName',
    'latinName',
    'phone',
    'nationality',
    'idNumber',
    'issuedBy',
    'birthPlace',
    'motherName',
    'country',
    'city',
    'region',
    'district',
    'street',
    'otherDetails',
    'incomeSource'
  ]);

  const DATE_FIELD_KEYS = Object.freeze(['issueDate', 'expiryDate', 'birthDate']);
  const OPTION_FIELD_KEYS = Object.freeze({
    gender: OPTION_SETS.genders.map((option) => option.value),
    entityType: OPTION_SETS.entityTypes.map((option) => option.value),
    idType: OPTION_SETS.idTypes.map((option) => option.value)
  });

  const DEFAULT_DRAFT = Object.freeze({
    version: 1,
    fullName: '',
    latinName: '',
    incomeSource: '',
    phone: '',
    phoneCountryCode: 'sy',
    nationality: '',
    gender: 'male',
    entityType: 'person',
    idType: '',
    idNumber: '',
    issuedBy: '',
    issueDate: '',
    expiryDate: '',
    birthPlace: '',
    birthDate: '',
    motherName: '',
    country: '',
    city: '',
    region: '',
    district: '',
    street: '',
    otherDetails: '',
    updatedAt: 0
  });

  function normalizePhoneDigits(value){
    return String(value ?? '')
      .replace(/[٠-٩]/g, (digit) => String(digit.charCodeAt(0) - 0x0660))
      .replace(/[۰-۹]/g, (digit) => String(digit.charCodeAt(0) - 0x06F0));
  }

  function normalizePhoneCountryCode(value){
    const safeValue = String(value ?? '').trim().toLowerCase().replace(/[^a-z]/g, '');
    return Object.prototype.hasOwnProperty.call(PHONE_COUNTRY_LOOKUP, safeValue) ? safeValue : '';
  }

  function getPhoneCountryCatalog(){
    return PHONE_COUNTRY_CATALOG.map((entry) => ({ ...entry }));
  }

  function getPhoneCountryMeta(value){
    const code = normalizePhoneCountryCode(value);
    return code ? PHONE_COUNTRY_LOOKUP[code] || null : null;
  }

  function parsePhoneValue(rawPhone, preferredCountryCode = ''){
    const normalizedCountry = normalizePhoneCountryCode(preferredCountryCode);
    const normalizedInput = normalizePhoneDigits(rawPhone).replace(/[^\d+]/g, '');
    if(!normalizedInput){
      return { countryCode: normalizedCountry, phone: '' };
    }

    let detectedCountry = normalizedCountry;
    let localPhone = normalizedInput.replace(/\+/g, '').replace(/\D/g, '').slice(0, PHONE_LOCAL_MAX_LENGTH);
    let comparisonValue = normalizedInput;
    if(comparisonValue.startsWith('00')) comparisonValue = `+${comparisonValue.slice(2)}`;

    if(comparisonValue.startsWith('+')){
      const matched = PHONE_DIAL_MATCHERS.find((entry) => comparisonValue.startsWith(String(entry.dialCode || '').trim()));
      if(matched){
        detectedCountry = matched.code;
        localPhone = comparisonValue.slice(String(matched.dialCode || '').length).replace(/\D/g, '').slice(0, PHONE_LOCAL_MAX_LENGTH);
      }
    }

    return {
      countryCode: detectedCountry,
      phone: localPhone
    };
  }

  function composePhoneDisplay(input){
    const localPhone = normalizePhoneDigits(input && input.phone).replace(/\D/g, '').slice(0, PHONE_LOCAL_MAX_LENGTH);
    const country = getPhoneCountryMeta(input && input.phoneCountryCode);
    if(country && localPhone) return `${country.dialCode} ${localPhone}`;
    if(country && !localPhone) return country.dialCode;
    return localPhone;
  }

  function createEmptyDomain(){
    return {
      version: DOMAIN_VERSION,
      draft: clone(DEFAULT_DRAFT),
      records: []
    };
  }

  function sanitizeText(value, { preserveNewLines = false } = {}){
    let safeValue = String(value ?? '');
    if(!preserveNewLines){
      safeValue = safeValue.replace(/\s+/g, ' ');
    } else {
      safeValue = safeValue
        .replace(/\r\n/g, '\n')
        .replace(/\r/g, '\n')
        .replace(/[\t\f\v]+/g, ' ')
        .replace(/\n{3,}/g, '\n\n');
    }
    return safeValue.trim();
  }

  function sanitizeDate(value){
    const safeValue = toText(value);
    return /^\d{4}-\d{2}-\d{2}$/.test(safeValue) ? safeValue : '';
  }

  function sanitizeOption(key, value){
    const allowed = OPTION_FIELD_KEYS[key] || [];
    const safeValue = toText(value);
    return allowed.includes(safeValue) ? safeValue : (DEFAULT_DRAFT[key] ?? '');
  }

  function normalizeTimestamp(value, fallback = 0){
    const numeric = Number(value);
    return Number.isFinite(numeric) && numeric > 0 ? numeric : fallback;
  }

  function createRecordId(seed = Date.now()){
    const base = Math.max(1, Number(seed) || Date.now()).toString(36);
    const random = Math.random().toString(36).slice(2, 8);
    return `customer-${base}-${random}`;
  }

  function normalizeDraft(input){
    const raw = input && typeof input === 'object' ? input : {};
    const normalized = { ...DEFAULT_DRAFT, version: 1 };

    TEXT_FIELD_KEYS.forEach((key) => {
      normalized[key] = sanitizeText(raw[key], { preserveNewLines: key === 'otherDetails' });
    });

    const preferredPhoneCountryCode = normalizePhoneCountryCode(raw.phoneCountryCode) || DEFAULT_DRAFT.phoneCountryCode;
    const normalizedPhone = parsePhoneValue(raw.phone, preferredPhoneCountryCode);
    normalized.phone = normalizedPhone.phone;
    normalized.phoneCountryCode = normalizedPhone.countryCode || DEFAULT_DRAFT.phoneCountryCode;

    DATE_FIELD_KEYS.forEach((key) => {
      normalized[key] = sanitizeDate(raw[key]);
    });

    Object.keys(OPTION_FIELD_KEYS).forEach((key) => {
      normalized[key] = sanitizeOption(key, raw[key]);
    });

    normalized.updatedAt = normalizeTimestamp(raw.updatedAt, 0);
    return normalized;
  }

  function normalizeRecord(input){
    const raw = input && typeof input === 'object' ? input : {};
    const draft = normalizeDraft(raw);
    const createdAt = normalizeTimestamp(raw.createdAt, Date.now());
    const updatedAt = normalizeTimestamp(raw.updatedAt, createdAt);
    const safeId = sanitizeText(raw.id) || createRecordId(createdAt);
    return {
      id: safeId,
      createdAt,
      updatedAt,
      ...draft
    };
  }

  function normalizeDomain(input){
    const raw = input && typeof input === 'object' ? input : {};
    const hasDomainShape = Object.prototype.hasOwnProperty.call(raw, 'draft') || Object.prototype.hasOwnProperty.call(raw, 'records');

    if(!hasDomainShape){
      return {
        version: DOMAIN_VERSION,
        draft: normalizeDraft(raw),
        records: []
      };
    }

    const seenIds = new Set();
    const records = (Array.isArray(raw.records) ? raw.records : [])
      .map((record) => normalizeRecord(record))
      .filter((record) => {
        if(!record.id || seenIds.has(record.id)) return false;
        seenIds.add(record.id);
        return true;
      })
      .sort((left, right) => (right.updatedAt || right.createdAt || 0) - (left.updatedAt || left.createdAt || 0));

    return {
      version: DOMAIN_VERSION,
      draft: normalizeDraft(raw.draft),
      records
    };
  }

  function readDomain(){
    return normalizeDomain(readJsonStorage(STORAGE_KEY, createEmptyDomain()));
  }

  function writeDomain(nextDomain){
    return persistJsonState(STORAGE_KEY, nextDomain, normalizeDomain);
  }

  function writeDraft(nextDraft){
    const domain = readDomain();
    const persisted = writeDomain({ ...domain, draft: normalizeDraft(nextDraft) });
    return persisted.draft;
  }

  function writeRecords(nextRecords){
    const domain = readDomain();
    const persisted = writeDomain({ ...domain, records: Array.isArray(nextRecords) ? nextRecords : domain.records });
    return Array.isArray(persisted.records) ? persisted.records : [];
  }

  function hasMeaningfulContent(input){
    const draft = normalizeDraft(input);
    const hasText = TEXT_FIELD_KEYS.some((key) => draft[key]);
    const hasDate = DATE_FIELD_KEYS.some((key) => draft[key]);
    const hasOptionChange = Object.keys(OPTION_FIELD_KEYS).some((key) => draft[key] !== DEFAULT_DRAFT[key]);
    return hasText || hasDate || hasOptionChange;
  }

  function createRecordFromState(input){
    const draft = normalizeDraft(input);
    const now = Date.now();
    return normalizeRecord({ ...draft, id: createRecordId(now), createdAt: now, updatedAt: now });
  }

  function addRecordFromState(input){
    const domain = readDomain();
    const record = createRecordFromState(input);
    const persisted = writeDomain({
      ...domain,
      records: [record, ...domain.records]
    });
    return {
      record,
      records: Array.isArray(persisted.records) ? persisted.records : []
    };
  }

  function findRecord(recordId){
    const safeId = sanitizeText(recordId);
    if(!safeId) return null;
    const domain = readDomain();
    return Array.isArray(domain.records)
      ? domain.records.find((record) => String(record?.id || '').trim() === safeId) || null
      : null;
  }

  function updateRecordFromState(recordId, input){
    const safeId = sanitizeText(recordId);
    const domain = readDomain();
    if(!safeId){
      return {
        record:null,
        records:Array.isArray(domain.records) ? domain.records : []
      };
    }

    let updatedRecord = null;
    const nextRecords = (Array.isArray(domain.records) ? domain.records : []).map((record) => {
      if(String(record?.id || '').trim() !== safeId) return record;
      const createdAt = normalizeTimestamp(record?.createdAt, Date.now());
      updatedRecord = normalizeRecord({
        ...record,
        ...normalizeDraft(input),
        id:safeId,
        createdAt,
        updatedAt:Date.now()
      });
      return updatedRecord;
    });

    if(!updatedRecord){
      return {
        record:null,
        records:Array.isArray(domain.records) ? domain.records : []
      };
    }

    const persisted = writeDomain({
      ...domain,
      records:nextRecords
    });

    return {
      record:Array.isArray(persisted.records) ? (persisted.records.find((record) => String(record?.id || '').trim() === safeId) || updatedRecord) : updatedRecord,
      records:Array.isArray(persisted.records) ? persisted.records : []
    };
  }

  function deleteRecord(recordId){
    const safeId = sanitizeText(recordId);
    const domain = readDomain();
    const records = Array.isArray(domain.records) ? domain.records : [];
    if(!safeId){
      return { record:null, records };
    }

    const removedRecord = records.find((record) => String(record?.id || '').trim() === safeId) || null;
    const nextRecords = records.filter((record) => String(record?.id || '').trim() !== safeId);

    if(nextRecords.length === records.length){
      return { record:null, records };
    }

    const persisted = writeDomain({
      ...domain,
      records:nextRecords
    });

    return {
      record:removedRecord,
      records:Array.isArray(persisted.records) ? persisted.records : []
    };
  }

  function findOptionLabel(optionsKey, value){
    const options = Object.prototype.hasOwnProperty.call(OPTION_SETS, optionsKey) ? OPTION_SETS[optionsKey] : [];
    const safeValue = sanitizeText(value);
    const match = Array.isArray(options) ? options.find((option) => sanitizeText(option?.value) === safeValue) : null;
    return sanitizeText(match?.label || safeValue || '');
  }

  const api = TAIF.customerCard = TAIF.customerCard || {};
  api.storageKey = STORAGE_KEY;
  api.options = OPTION_SETS;
  api.groups = GROUPS;
  api.createEmptyState = () => clone(DEFAULT_DRAFT);
  api.createEmptyDomain = createEmptyDomain;
  api.normalizeState = normalizeDraft;
  api.normalizeDraft = normalizeDraft;
  api.normalizeRecord = normalizeRecord;
  api.normalizeDomain = normalizeDomain;
  api.readState = () => readDomain().draft;
  api.writeState = (nextState) => writeDraft(nextState);
  api.readRecords = () => readDomain().records;
  api.writeRecords = (records) => writeRecords(records);
  api.readDomain = readDomain;
  api.writeDomain = writeDomain;
  api.hasMeaningfulContent = hasMeaningfulContent;
  api.createRecordFromState = createRecordFromState;
  api.addRecordFromState = addRecordFromState;
  api.findRecord = findRecord;
  api.updateRecordFromState = updateRecordFromState;
  api.deleteRecord = deleteRecord;
  api.findOptionLabel = findOptionLabel;
  api.getPhoneCountryCatalog = getPhoneCountryCatalog;
  api.getPhoneCountryMeta = getPhoneCountryMeta;
  api.normalizePhoneCountryCode = normalizePhoneCountryCode;
  api.parsePhoneValue = parsePhoneValue;
  api.composePhoneDisplay = composePhoneDisplay;
})();
