(()=>{

  const TAIF = window.TAIF;
  const { escapeHtml, runCleanupSlot, wrapControlTextMarkup, createAnimationFrameScheduler, resolveStorageKey } = TAIF.core.utils;
  const domain = TAIF.currencyDomain || {};
  const display = TAIF.currencyDisplay || {};
  const storageKeys = TAIF?.core?.storageKeys || {};
  const STORAGE_KEY = storageKeys.currencyDomain || storageKeys.currencyManagement || 'taif-currency-management-module-v1';
  const createSingleLineHeaderLabel = typeof display.createSingleLineHeaderLabel === 'function'
    ? display.createSingleLineHeaderLabel
    : (text) => `<span>${escapeHtml(text)}</span>`;
  const runtime = {
    panel: null,
    headerFitCleanup: null,
    listenersBound: false,
    storageHandler: null,
    refreshScheduler: null,
    scopedStorageKey: typeof resolveStorageKey === 'function' ? resolveStorageKey(STORAGE_KEY) : STORAGE_KEY
  };

  function readCurrencyManagementRows(){
    if(typeof domain.readState === 'function' && typeof domain.computeRows === 'function'){
      const state = domain.readState();
      const rows = domain.computeRows(state);
      const counterpart = typeof domain.getCounterpartCurrency === 'function'
        ? domain.getCounterpartCurrency(state)
        : { code: 'USD', name: 'الدولار الأمريكي' };
      return {
        state,
        counterpart,
        rows: Array.isArray(rows) ? rows : []
      };
    }

    return { state: { updatedAt: Date.now(), currencies: [] }, counterpart: { code: 'USD', name: 'الدولار الأمريكي' }, rows: [] };
  }

  function getVisibleRows(rows, counterpartCode = ''){
    const safeCounterpartCode = String(counterpartCode || '').trim().toUpperCase();
    if(!Array.isArray(rows)) return [];
    return rows.filter((row) => {
      if(!row || typeof row !== 'object') return false;
      if(row.isCounterpart) return false;
      if(safeCounterpartCode && String(row.code || '').trim().toUpperCase() === safeCounterpartCode) return false;
      return true;
    });
  }

  const resolveRowFlagAsset = typeof domain.resolveCurrencyFlagAsset === 'function'
    ? domain.resolveCurrencyFlagAsset
    : (rowOrCurrency, variant = 'circle') => {
      const flags = TAIF.assets && TAIF.assets.flags;
      const safeRow = rowOrCurrency && typeof rowOrCurrency === 'object' ? rowOrCurrency : {};
      const explicitFlag = String(safeRow.flag || '').trim();
      const fallbackCode = String(safeRow.code || '').trim();
      if(flags && typeof flags.resolveFlagAsset === 'function'){
        return flags.resolveFlagAsset(explicitFlag || fallbackCode || 'xx', variant);
      }
      return { src: 'assets/flags/circle/xx.png', countryCode: 'xx' };
    };

  const renderPairBadgeMarkup = typeof domain.renderPairBadgeMarkup === 'function'
    ? domain.renderPairBadgeMarkup
    : (pairLabel) => escapeHtml(String(pairLabel || 'USD/USD').trim() || 'USD/USD');


  function cleanupHeaderFit(){
    runCleanupSlot(runtime, 'headerFitCleanup');
  }

  function scheduleRefresh(){
    if(!(runtime.panel instanceof HTMLElement) || runtime.panel.dataset.view !== 'price-screen') return;
    if(typeof createAnimationFrameScheduler === 'function'){
      if(!runtime.refreshScheduler){
        runtime.refreshScheduler = createAnimationFrameScheduler(() => {
          if(runtime.panel && runtime.panel.dataset.view === 'price-screen') renderPriceScreen(runtime.panel);
        });
      }
      runtime.refreshScheduler.schedule();
      return;
    }
    renderPriceScreen(runtime.panel);
  }

  function formatRowCellValue(row, field, maxAutoDecimals = 6){
    if(typeof domain.formatManagementCellValue === 'function'){
      return domain.formatManagementCellValue(row, field, maxAutoDecimals);
    }
    const safeValue = row && Object.prototype.hasOwnProperty.call(row, field) ? row[field] : '';
    return escapeHtml(String(safeValue ?? '—'));
  }

  function rowMarkup(row, counterpart){
    const localFlag = resolveRowFlagAsset(row, 'circle');
    const counterpartFlag = resolveRowFlagAsset(counterpart, 'circle');
    const counterpartName = counterpart && (counterpart.name || counterpart.code)
      ? (counterpart.name || counterpart.code)
      : 'الدولار الأمريكي';
    const buySellFlag = row.isUsd ? counterpartFlag : localFlag;
    const buySellFlagTitle = row.isUsd ? counterpartName : (row.name || row.code);

    return `
      <div class="price-screen__row${row.isUsd ? ' price-screen__row--usd' : ''}" data-code="${escapeHtml(row.code)}">
        <div class="price-screen__code" dir="ltr">${wrapControlTextMarkup(escapeHtml(row.code), 'taif-control-text--ltr')}</div>
        <div class="price-screen__name">
          <div class="price-screen__name-main">${escapeHtml(row.name || row.code)}</div>
        </div>
        <div class="price-screen__pair-col">
          <div class="price-screen__pair-badge" dir="ltr">${wrapControlTextMarkup(renderPairBadgeMarkup(row.usdPairLabel || row.usdPairId || 'USD/USD'), 'taif-control-text--ltr taif-control-text--pair')}</div>
        </div>
        <div class="price-screen__num price-screen__num--buy">${wrapControlTextMarkup(formatRowCellValue(row, 'buy', 6), 'taif-control-text--ltr')}</div>
        <div class="price-screen__flag" title="${escapeHtml(buySellFlagTitle)}" aria-hidden="true">
          <img class="price-screen__flag-image" src="${escapeHtml(buySellFlag.src)}" alt="" draggable="false" loading="eager" decoding="async" width="512" height="512">
        </div>
        <div class="price-screen__num price-screen__num--sell">${wrapControlTextMarkup(formatRowCellValue(row, 'sell', 6), 'taif-control-text--ltr')}</div>
        <div class="price-screen__num price-screen__num--dollar-buy">${wrapControlTextMarkup(formatRowCellValue(row, 'dollarBuy', 6), 'taif-control-text--ltr')}</div>
        <div class="price-screen__usd-flag" title="${escapeHtml(row.name || row.code)}" aria-hidden="true">
          <img class="price-screen__flag-image" src="${escapeHtml(localFlag.src)}" alt="" draggable="false" loading="eager" decoding="async" width="512" height="512">
        </div>
        <div class="price-screen__num price-screen__num--dollar-sell">${wrapControlTextMarkup(formatRowCellValue(row, 'dollarSell', 6), 'taif-control-text--ltr')}</div>
      </div>
    `;
  }

  function renderPriceScreen(panel){
    cleanupHeaderFit();
    runtime.panel = panel;
    const source = readCurrencyManagementRows();
    const rows = Array.isArray(source.rows) ? source.rows : [];
    const visibleRows = getVisibleRows(rows, source.counterpart && source.counterpart.code);
    const counterpartName = source.counterpart && (source.counterpart.name || source.counterpart.code)
      ? (source.counterpart.name || source.counterpart.code)
      : 'الدولار الأمريكي';

    panel.innerHTML = `
      <section class="price-screen price-screen--display-only" aria-label="شاشة الأسعار">
        <div class="price-screen__board-head" aria-hidden="true">
          <div>${createSingleLineHeaderLabel('كود العملة', { className: 'taif-singleline-fit--price-head', min: 10.6, max: 13.4, minScale: .95 })}</div>
          <div class="price-screen__board-head-name">${createSingleLineHeaderLabel('اسم العملة', { className: 'taif-singleline-fit--price-head taif-singleline-fit--price-head-name', min: 10.8, max: 13.4, minScale: .95 })}</div>
          <div>${createSingleLineHeaderLabel('أزواج العملات', { className: 'taif-singleline-fit--price-head', min: 10.4, max: 13.4, minScale: .94 })}</div>
          <div>${createSingleLineHeaderLabel(`شراء / ${counterpartName}`, { className: 'taif-singleline-fit--price-head', min: 10.2, max: 13.4, minScale: .92 })}</div>
          <div>${createSingleLineHeaderLabel('العلم', { className: 'taif-singleline-fit--price-head', min: 10.8, max: 13.4, minScale: .96 })}</div>
          <div>${createSingleLineHeaderLabel(`مبيع / ${counterpartName}`, { className: 'taif-singleline-fit--price-head', min: 10.2, max: 13.4, minScale: .92 })}</div>
          <div>${createSingleLineHeaderLabel('شراء / الدولار الأمريكي', { className: 'taif-singleline-fit--price-head', min: 10.2, max: 13.4, minScale: .92 })}</div>
          <div>${createSingleLineHeaderLabel('العلم', { className: 'taif-singleline-fit--price-head', min: 10.8, max: 13.4, minScale: .96 })}</div>
          <div>${createSingleLineHeaderLabel('مبيع / الدولار الأمريكي', { className: 'taif-singleline-fit--price-head', min: 10.2, max: 13.4, minScale: .92 })}</div>
        </div>

        <div class="price-screen__board-body" aria-label="جدول الأسعار">
          ${visibleRows.length ? `<div class="price-screen__list">${visibleRows.map((row) => rowMarkup(row, source.counterpart)).join('')}</div>` : `<div class="price-screen__empty">لا توجد عملات متاحة للعرض حاليًا.</div>`}
        </div>
      </section>
    `;

    runtime.headerFitCleanup = typeof display.mountSingleLineTextFit === 'function'
      ? display.mountSingleLineTextFit(panel, '.taif-singleline-fit--price-head')
      : null;
  }

  function handleCurrencyManagementUpdate(){
    scheduleRefresh();
  }

  function bindGlobalListeners(){
    if(runtime.listenersBound) return;
    runtime.listenersBound = true;
    runtime.storageHandler = (event) => {
      const key = event && typeof event.key === 'string' ? event.key.trim() : '';
      if(!key || key !== runtime.scopedStorageKey) return;
      handleCurrencyManagementUpdate();
    };
    const events = TAIF.core && TAIF.core.events;
    runtime.currencyEventsCleanup = events && typeof events.on === 'function'
      ? events.on(events.EVENT_NAMES.CURRENCY_UPDATED, handleCurrencyManagementUpdate)
      : null;
    if(!runtime.currencyEventsCleanup){
      window.addEventListener('taif:currency-domain-updated', handleCurrencyManagementUpdate);
    }
    window.addEventListener('storage', runtime.storageHandler);
  }

  function unbindGlobalListeners(){
    if(!runtime.listenersBound) return;
    if(typeof runtime.currencyEventsCleanup === 'function'){
      runtime.currencyEventsCleanup();
      runtime.currencyEventsCleanup = null;
    }else{
      window.removeEventListener('taif:currency-domain-updated', handleCurrencyManagementUpdate);
    }
    if(typeof runtime.storageHandler === 'function'){
      window.removeEventListener('storage', runtime.storageHandler);
    }
    runtime.storageHandler = null;
    runtime.listenersBound = false;
  }

  function cleanupView(){
    cleanupHeaderFit();
    runtime.refreshScheduler?.cancel?.();
    runtime.refreshScheduler = null;
    runtime.panel = null;
    unbindGlobalListeners();
  }

  TAIF.registerViewCleanup('price-screen', cleanupView);
  TAIF.registerViewRenderer('price-screen', ({ panel }) => {
    bindGlobalListeners();
    renderPriceScreen(panel);
  });
})();
