(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  const utils = TAIF.core && TAIF.core.utils ? TAIF.core.utils : {};
  const toText = typeof utils.toText === 'function'
    ? utils.toText
    : ((value, fallback = '') => String(value == null ? fallback : value).trim());
  const normalizeLookupText = typeof utils.normalizeLookupText === 'function'
    ? utils.normalizeLookupText
    : ((value) => String(value ?? '').trim().toLowerCase());
  const readJsonStorage = typeof utils.readJsonStorage === 'function' ? utils.readJsonStorage : (() => null);
  const persistJsonState = typeof utils.persistJsonState === 'function' ? utils.persistJsonState : ((_, value) => value);

  const storageKeys = TAIF.core && TAIF.core.storageKeys ? TAIF.core.storageKeys : {};
  const ENTRIES_STORAGE_KEY = storageKeys.entriesVouchers || 'taif-entries-vouchers-module-v1';
  const SALES_PURCHASE_STORAGE_KEY = storageKeys.salesPurchaseInvoice || 'taif-sales-purchase-invoice-records-v1';
  const FILTER_STORAGE_KEY = 'taif-daily-journal-ui-v1';
  const EPSILON = 1e-9;

  function pad2(value){
    return String(value).padStart(2, '0');
  }

  function todayIso(){
    const date = new Date();
    return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
  }

  const TYPE_META = Object.freeze({
    opening: Object.freeze({ key:'opening', label:'قيد افتتاحي', tone:'violet' }),
    payment: Object.freeze({ key:'payment', label:'سند دفع', tone:'danger' }),
    receipt: Object.freeze({ key:'receipt', label:'سند قبض', tone:'success' }),
    journal: Object.freeze({ key:'journal', label:'سند يومي', tone:'primary' }),
    settlement: Object.freeze({ key:'settlement', label:'سند تسوية', tone:'warning' }),
    purchase: Object.freeze({ key:'purchase', label:'فاتورة شراء', tone:'warning' }),
    sale: Object.freeze({ key:'sale', label:'فاتورة مبيع', tone:'success' }),
    trade: Object.freeze({ key:'trade', label:'عملية صرف', tone:'primary' })
  });

  const OPERATION_OPTIONS = Object.freeze([
    Object.freeze({ value:'all', label:'كل العمليات' }),
    Object.freeze({ value:'opening', label:'قيد افتتاحي' }),
    Object.freeze({ value:'payment', label:'سند دفع' }),
    Object.freeze({ value:'receipt', label:'سند قبض' }),
    Object.freeze({ value:'journal', label:'سند يومي' }),
    Object.freeze({ value:'settlement', label:'سند تسوية' }),
    Object.freeze({ value:'purchase', label:'فاتورة شراء' }),
    Object.freeze({ value:'sale', label:'فاتورة مبيع' }),
    Object.freeze({ value:'trade', label:'عملية صرف' })
  ]);

  const ALL_OPERATION_FILTER_VALUES = Object.freeze(OPERATION_OPTIONS
    .filter((option) => option.value !== 'all')
    .map((option) => option.value));

  const DEFAULT_FILTERS = Object.freeze({
    dateFrom:'',
    dateTo:'',
    operationTypes:ALL_OPERATION_FILTER_VALUES.slice(),
    operationType:'all',
    search:''
  });

  function resolveDomainAdapter(name){
    const registry = TAIF.domain || {};
    if(typeof registry.resolve === 'function') return registry.resolve(name);
    return registry[name] || null;
  }

  function sanitizeDate(value){
    const safeValue = toText(value);
    return /^\d{4}-\d{2}-\d{2}$/.test(safeValue) ? safeValue : '';
  }

  function normalizeCurrencyCode(value){
    return String(value ?? '').trim().toUpperCase().replace(/[^A-Z]/g, '') || 'USD';
  }

  function toNumber(value, fallback = 0){
    const numeric = Number(String(value ?? '').replace(/,/g, '').trim());
    return Number.isFinite(numeric) ? numeric : (Number(fallback) || 0);
  }

  function sanitizeOperationTypes(value, { preserveEmptyArray = false } = {}){
    const sourceValues = Array.isArray(value)
      ? value
      : (toText(value) === 'all' || !toText(value) ? ALL_OPERATION_FILTER_VALUES : [value]);
    if(preserveEmptyArray && Array.isArray(value) && value.length === 0) return [];
    const allowed = new Set(ALL_OPERATION_FILTER_VALUES);
    const normalized = [];
    sourceValues.forEach((item) => {
      const safeItem = toText(item);
      if(safeItem === 'all'){
        ALL_OPERATION_FILTER_VALUES.forEach((operationType) => {
          if(!normalized.includes(operationType)) normalized.push(operationType);
        });
        return;
      }
      if(allowed.has(safeItem) && !normalized.includes(safeItem)) normalized.push(safeItem);
    });
    return normalized.length || preserveEmptyArray ? normalized : ALL_OPERATION_FILTER_VALUES.slice();
  }

  function deriveOperationType(operationTypes){
    const safeTypes = sanitizeOperationTypes(operationTypes, { preserveEmptyArray:Array.isArray(operationTypes) && operationTypes.length === 0 });
    if(safeTypes.length === ALL_OPERATION_FILTER_VALUES.length) return 'all';
    if(safeTypes.length === 1) return safeTypes[0];
    return safeTypes.length ? 'custom' : '';
  }

  function normalizeFilters(raw){
    const source = raw && typeof raw === 'object' ? raw : {};
    const hasOperationTypesArray = Array.isArray(source.operationTypes);
    const preserveEmptyOperationTypes = hasOperationTypesArray && source.operationTypes.length === 0;
    const operationTypes = sanitizeOperationTypes(
      hasOperationTypesArray ? source.operationTypes : (source.operationType || source.operation || DEFAULT_FILTERS.operationTypes),
      { preserveEmptyArray:preserveEmptyOperationTypes }
    );
    const todayValue = todayIso();
    const normalized = {
      dateFrom:sanitizeDate(source.dateFrom) || todayValue,
      dateTo:sanitizeDate(source.dateTo) || todayValue,
      operationTypes,
      operationType:deriveOperationType(operationTypes),
      search:toText(source.search)
    };
    if(normalized.dateFrom && normalized.dateTo && normalized.dateFrom > normalized.dateTo){
      return { ...normalized, dateFrom:normalized.dateTo, dateTo:normalized.dateFrom };
    }
    return normalized;
  }

  function readFilters(){
    return normalizeFilters(readJsonStorage(FILTER_STORAGE_KEY, null));
  }

  function writeFilters(filters){
    return normalizeFilters(persistJsonState(FILTER_STORAGE_KEY, normalizeFilters(filters), normalizeFilters));
  }

  function readEntriesState(){
    const domain = resolveDomainAdapter('entries');
    if(domain && typeof domain.readState === 'function'){
      try{ return domain.readState(); }catch{}
    }
    if(TAIF.entriesVouchers && typeof TAIF.entriesVouchers.readState === 'function'){
      try{ return TAIF.entriesVouchers.readState(); }catch{}
    }
    return readJsonStorage(ENTRIES_STORAGE_KEY, null) || { records:[] };
  }

  function readSalesPurchaseState(){
    const domain = resolveDomainAdapter('sales-purchase');
    if(domain && typeof domain.readState === 'function'){
      try{ return domain.readState(); }catch{}
    }
    return readJsonStorage(SALES_PURCHASE_STORAGE_KEY, null) || { records:[] };
  }

  function isSalesPurchaseGeneratedEntry(record){
    const domain = resolveDomainAdapter('entries');
    if(domain && typeof domain.isSalesPurchaseGeneratedRecord === 'function'){
      try{ return !!domain.isSalesPurchaseGeneratedRecord(record); }catch{}
    }
    const safeRecord = record && typeof record === 'object' ? record : {};
    const id = toText(safeRecord.id);
    return id.startsWith('entry-record-sales-purchase-')
      || !!toText(safeRecord.sourceSalesPurchaseRecordId)
      || !!toText(safeRecord.sourceSalesPurchaseNumber);
  }

  function getRecordType(record){
    const rawType = toText(record?.type);
    if(rawType === 'opening') return 'opening';
    if(rawType === 'payment') return 'payment';
    if(rawType === 'receipt') return 'receipt';
    if(rawType === 'settlement') return 'settlement';
    if(rawType === 'journal') return isSalesPurchaseGeneratedEntry(record) ? 'trade' : 'journal';
    return rawType || 'journal';
  }

  function resolveTypeMeta(type){
    return TYPE_META[type] || TYPE_META.journal;
  }

  function formatDate(value){
    const safeValue = sanitizeDate(value);
    if(!safeValue) return '—';
    const [year, month, day] = safeValue.split('-');
    return `${day}/${month}/${year}`;
  }

  function formatNumber(value){
    const numeric = Number(value);
    if(!Number.isFinite(numeric)) return '0';
    return new Intl.NumberFormat('en-US', { maximumFractionDigits:0 }).format(numeric);
  }

  function formatAmount(value, currency = 'USD'){
    const numeric = toNumber(value, 0);
    const formatter = new Intl.NumberFormat('en-US', {
      minimumFractionDigits: Math.abs(numeric % 1) > EPSILON ? 2 : 0,
      maximumFractionDigits: 2
    });
    return `${formatter.format(Math.abs(numeric))} ${normalizeCurrencyCode(currency)}`;
  }

  function createCurrencyTotalsMap(){
    return new Map();
  }

  function addCurrencyTotal(map, currency, amount){
    if(!(map instanceof Map)) return map;
    const numeric = toNumber(amount, 0);
    if(!(numeric > EPSILON)) return map;
    const safeCurrency = normalizeCurrencyCode(currency);
    const current = map.get(safeCurrency) || { currency:safeCurrency, amount:0 };
    current.amount += numeric;
    map.set(safeCurrency, current);
    return map;
  }

  function totalsMapToArray(map){
    return Array.from((map instanceof Map ? map : new Map()).values())
      .filter((item) => Number(item.amount) > EPSILON)
      .sort((left, right) => String(left.currency || '').localeCompare(String(right.currency || '')));
  }

  function summarizeLineTotals(lines, side){
    const safeSide = String(side || '').trim();
    const map = createCurrencyTotalsMap();
    (Array.isArray(lines) ? lines : []).forEach((line) => {
      if(!line || typeof line !== 'object') return;
      addCurrencyTotal(map, line.currency, line[safeSide]);
    });
    return totalsMapToArray(map);
  }

  function mergeSideTotals(map, totals){
    (Array.isArray(totals) ? totals : []).forEach((item) => {
      addCurrencyTotal(map, item?.currency, item?.amount);
    });
    return map;
  }

  function recordTimestamp(record){
    return Math.max(
      Number(record?.createdAt) || 0,
      Number(record?.updatedAt) || 0,
      Number(record?.reversedAt) || 0
    );
  }

  function groupKeyForEntry(record){
    const sourceId = toText(record?.sourceSalesPurchaseRecordId);
    const sourceNumber = toText(record?.sourceSalesPurchaseNumber).toUpperCase();
    if(sourceId || sourceNumber) return `sales:${sourceId || sourceNumber}`;
    return `entry:${getRecordType(record)}:${toText(record?.number).toUpperCase() || toText(record?.id)}`;
  }

  function lineText(line){
    return [
      line?.roleLabel,
      line?.accountNo,
      line?.accountName,
      line?.description,
      line?.side,
      line?.debit,
      line?.credit,
      line?.amount
    ].map((item) => toText(item)).filter(Boolean).join(' ');
  }

  function normalizeEntryLine(line, fallbackCurrency){
    const item = line && typeof line === 'object' ? line : {};
    const debit = toNumber(item.debit, item.side === 'debit' ? item.amount : 0);
    const credit = toNumber(item.credit, item.side === 'credit' ? item.amount : 0);
    return {
      lineNo: Math.max(1, Number(item.lineNo) || 1),
      roleLabel:toText(item.roleLabel || item.roleKey),
      accountNo:toText(item.accountNo),
      accountName:toText(item.accountName),
      description:toText(item.description),
      debit,
      credit,
      currency:normalizeCurrencyCode(item.currency || item.currencyCode || fallbackCurrency)
    };
  }

  function normalizeEntryRecord(record, ordinal = 0){
    const item = record && typeof record === 'object' ? record : {};
    const currency = normalizeCurrencyCode(item.currency);
    const rawLines = Array.isArray(item.lines) ? item.lines : [];
    const lines = rawLines.map((line) => normalizeEntryLine(line, currency));
    const debit = lines.reduce((sum, line) => sum + toNumber(line.debit, 0), 0);
    const credit = lines.reduce((sum, line) => sum + toNumber(line.credit, 0), 0);
    const primaryAmount = Math.max(debit, credit, toNumber(item.amount, 0), toNumber(item.grossAmount, 0), toNumber(item.netAmount, 0));
    return {
      kind:'entry',
      id:toText(item.id) || `daily-entry-${ordinal}`,
      number:toText(item.number).toUpperCase() || '—',
      date:sanitizeDate(item.date),
      type:getRecordType(item),
      status:toText(item.status) || 'posted',
      description:toText(item.description || item.summary),
      summary:toText(item.summary),
      currency,
      amount:primaryAmount,
      debit,
      credit,
      partyName:toText(item.partyName || item.beneficiaryName),
      sourceSalesPurchaseRecordId:toText(item.sourceSalesPurchaseRecordId),
      sourceSalesPurchaseNumber:toText(item.sourceSalesPurchaseNumber).toUpperCase(),
      lines,
      searchText:normalizeLookupText([
        item.id, item.number, item.date, item.type, item.status, item.description, item.summary,
        item.partyName, item.counterpartAccountNo, item.counterpartAccountName, item.cashAccountNo,
        item.cashAccountName, item.sourceSalesPurchaseRecordId, item.sourceSalesPurchaseNumber,
        lines.map(lineText).join(' ')
      ].join(' ')),
      timestamp:recordTimestamp(item) || ordinal
    };
  }

  function normalizeSalesPurchaseRecord(record, ordinal = 0){
    const item = record && typeof record === 'object' ? record : {};
    const action = toText(item.type || item.action || item.actionId).toLowerCase();
    const type = action === 'sale' || /sale|مبيع/i.test(action) ? 'sale' : 'purchase';
    const tradeCurrency = normalizeCurrencyCode(item.tradeCurrencyCode || item.buyCurrencyCode || item.currencyCode);
    const settlementCurrency = normalizeCurrencyCode(item.settlementCurrencyCode || item.sellCurrencyCode || item.counterpartCurrencyCode);
    const amount = toNumber(item.amountValue || item.amount || item.amountText, 0);
    const counterpartAmount = toNumber(item.counterpartAmountValue || item.counterpartAmount || item.counterpartAmountText, 0);
    const rate = toNumber(item.rateValue || item.rate || item.manualRateText, 0);
    const date = sanitizeDate(item.date || item.voucherDate);
    const number = toText(item.number || item.documentNumber || item.documentNo).toUpperCase() || '—';
    const lines = [
      {
        lineNo:1,
        roleLabel:type === 'sale' ? 'العملة المباعة' : 'العملة المشتراة',
        accountNo:toText(item.cashAccountNo || item.accountNo),
        accountName:toText(item.cashAccountName || item.accountName || 'الصندوق'),
        description:toText(item.invoiceSummary || item.summary || item.notes || 'حركة شراء/مبيع'),
        debit:type === 'purchase' ? amount : 0,
        credit:type === 'sale' ? amount : 0,
        currency:tradeCurrency
      },
      {
        lineNo:2,
        roleLabel:type === 'sale' ? 'المقابل المقبوض' : 'المقابل المدفوع',
        accountNo:toText(item.accountingBridgeAccountNo || item.bridgeAccountNo),
        accountName:toText(item.accountingBridgeAccountName || item.bridgeAccountName || 'حساب مقابل'),
        description:rate > 0 ? `سعر الصرف ${rate}` : '',
        debit:type === 'sale' ? counterpartAmount : 0,
        credit:type === 'purchase' ? counterpartAmount : 0,
        currency:settlementCurrency
      }
    ];
    return {
      kind:'sales-purchase',
      id:toText(item.id) || `daily-sales-${ordinal}`,
      number,
      date,
      type,
      status:toText(item.status || item.lifecycleStatus) || 'posted',
      description:toText(item.invoiceSummary || item.summary || item.notes || item.description),
      summary:toText(item.summary || item.notes),
      currency:tradeCurrency,
      amount:amount || counterpartAmount,
      counterpartAmount,
      debit:type === 'purchase' ? amount : counterpartAmount,
      credit:type === 'purchase' ? counterpartAmount : amount,
      partyName:toText(item.counterpartyName || item.partyName || item.beneficiaryName),
      rate,
      lines,
      searchText:normalizeLookupText([
        item.id, number, date, type, item.status, item.counterpartyName, item.invoiceSummary,
        item.summary, item.notes, tradeCurrency, settlementCurrency, amount, counterpartAmount, rate
      ].join(' ')),
      timestamp:recordTimestamp(item) || ordinal
    };
  }

  function createCardFromEntryGroup(group, salesRecordMap){
    const records = group.records.slice().sort((left, right) => (left.timestamp || 0) - (right.timestamp || 0));
    const first = records[0] || {};
    const allLines = records.flatMap((record) => Array.isArray(record.lines) ? record.lines : []);
    const debit = allLines.reduce((sum, line) => sum + toNumber(line.debit, 0), 0);
    const credit = allLines.reduce((sum, line) => sum + toNumber(line.credit, 0), 0);
    const debitTotals = summarizeLineTotals(allLines, 'debit');
    const creditTotals = summarizeLineTotals(allLines, 'credit');
    const amount = Math.max(debit, credit, ...records.map((record) => toNumber(record.amount, 0)));
    const sourceId = toText(first.sourceSalesPurchaseRecordId);
    const sourceNumber = toText(first.sourceSalesPurchaseNumber).toUpperCase();
    const linkedSales = (sourceId && salesRecordMap.byId.get(sourceId)) || (sourceNumber && salesRecordMap.byNumber.get(sourceNumber)) || null;
    const type = linkedSales?.type || first.type || 'journal';
    const number = sourceNumber || first.number || linkedSales?.number || '—';
    const date = first.date || linkedSales?.date || '';
    const searchText = normalizeLookupText([
      group.key, number, date, type, first.status, first.description, linkedSales?.description,
      linkedSales?.partyName, linkedSales?.searchText, records.map((record) => record.searchText).join(' ')
    ].join(' '));
    return {
      id:`card-${group.key}`,
      source:'entries',
      sourceKind: linkedSales ? 'sales-linked-entry' : 'entry',
      type,
      typeMeta:resolveTypeMeta(type),
      number,
      date,
      status:first.status || linkedSales?.status || 'posted',
      title:linkedSales ? `${resolveTypeMeta(type).label} مرتبطة` : resolveTypeMeta(type).label,
      description:first.description || linkedSales?.description || '—',
      partyName:first.partyName || linkedSales?.partyName || '',
      currency:first.currency || linkedSales?.currency || 'USD',
      amount,
      debit,
      credit,
      debitTotals,
      creditTotals,
      count:records.length,
      lineCount:allLines.length,
      timestamp:Math.max(...records.map((record) => record.timestamp || 0), linkedSales?.timestamp || 0),
      linkedSales,
      records,
      lines:allLines,
      searchText
    };
  }

  function createCardFromSalesRecord(record){
    const lines = Array.isArray(record?.lines) ? record.lines : [];
    const debitTotals = summarizeLineTotals(lines, 'debit');
    const creditTotals = summarizeLineTotals(lines, 'credit');
    return {
      id:`card-sales-only-${record.id}`,
      source:'sales-purchase',
      sourceKind:'sales-purchase',
      type:record.type,
      typeMeta:resolveTypeMeta(record.type),
      number:record.number,
      date:record.date,
      status:record.status || 'posted',
      title:resolveTypeMeta(record.type).label,
      description:record.description || '—',
      partyName:record.partyName || '',
      currency:record.currency,
      amount:record.amount,
      debit:record.debit,
      credit:record.credit,
      debitTotals,
      creditTotals,
      count:1,
      lineCount:lines.length,
      timestamp:record.timestamp || 0,
      linkedSales:record,
      records:[],
      lines,
      searchText:record.searchText
    };
  }

  function createSalesRecordMap(records){
    const byId = new Map();
    const byNumber = new Map();
    records.forEach((record) => {
      const id = toText(record.id);
      const number = toText(record.number).toUpperCase();
      if(id) byId.set(id, record);
      if(number && number !== '—') byNumber.set(number, record);
    });
    return { byId, byNumber };
  }

  function buildCards(){
    const entriesState = readEntriesState();
    const salesState = readSalesPurchaseState();
    const entryRecords = (Array.isArray(entriesState?.records) ? entriesState.records : []).map(normalizeEntryRecord);
    const salesRecords = (Array.isArray(salesState?.records) ? salesState.records : []).map(normalizeSalesPurchaseRecord);
    const salesMap = createSalesRecordMap(salesRecords);
    const groups = new Map();

    entryRecords.forEach((record) => {
      const key = groupKeyForEntry(record);
      if(!groups.has(key)) groups.set(key, { key, records:[] });
      groups.get(key).records.push(record);
    });

    const cards = Array.from(groups.values()).map((group) => createCardFromEntryGroup(group, salesMap));
    const cardSourceIds = new Set();
    cards.forEach((card) => {
      if(card.linkedSales?.id) cardSourceIds.add(card.linkedSales.id);
    });

    salesRecords.forEach((record) => {
      if(!record.id || cardSourceIds.has(record.id)) return;
      cards.push(createCardFromSalesRecord(record));
    });

    return cards.sort((left, right) => {
      const dateCompare = String(right.date || '').localeCompare(String(left.date || ''));
      if(dateCompare) return dateCompare;
      return (Number(right.timestamp) || 0) - (Number(left.timestamp) || 0);
    });
  }

  function cardMatchesFilters(card, filters){
    const safeFilters = normalizeFilters(filters);
    if(safeFilters.dateFrom && String(card.date || '') < safeFilters.dateFrom) return false;
    if(safeFilters.dateTo && String(card.date || '') > safeFilters.dateTo) return false;
    if(!safeFilters.operationTypes.length) return false;
    if(!safeFilters.operationTypes.includes(card.type)) return false;
    const search = normalizeLookupText(safeFilters.search);
    if(search && !String(card.searchText || '').includes(search)) return false;
    return true;
  }

  function buildSummary(cards){
    const visible = Array.isArray(cards) ? cards : [];
    const debitMap = createCurrencyTotalsMap();
    const creditMap = createCurrencyTotalsMap();

    visible.forEach((card) => {
      const debitTotals = Array.isArray(card?.debitTotals) && card.debitTotals.length
        ? card.debitTotals
        : (Number(card?.debit) > EPSILON ? [{ currency:card?.currency, amount:card.debit }] : []);
      const creditTotals = Array.isArray(card?.creditTotals) && card.creditTotals.length
        ? card.creditTotals
        : (Number(card?.credit) > EPSILON ? [{ currency:card?.currency, amount:card.credit }] : []);

      mergeSideTotals(debitMap, debitTotals);
      mergeSideTotals(creditMap, creditTotals);
    });

    const currencies = new Set([
      ...Array.from(debitMap.keys()),
      ...Array.from(creditMap.keys())
    ]);

    const totals = Array.from(currencies).sort((a, b) => a.localeCompare(b)).map((currency) => ({
      currency,
      debit: Number(debitMap.get(currency)?.amount) || 0,
      credit: Number(creditMap.get(currency)?.amount) || 0,
      count: visible.length
    }));

    return {
      cardCount:visible.length,
      lineCount:visible.reduce((sum, card) => sum + (Number(card.lineCount) || 0), 0),
      totals
    };
  }

  function buildModel(filters = readFilters()){
    const safeFilters = normalizeFilters(filters);
    const allCards = buildCards();
    const visibleCards = allCards.filter((card) => cardMatchesFilters(card, safeFilters));
    return {
      filters:safeFilters,
      operationOptions:OPERATION_OPTIONS,
      cards:visibleCards,
      allCards,
      summary:buildSummary(visibleCards),
      totalCount:allCards.length
    };
  }

  const api = TAIF.dailyJournal = TAIF.dailyJournal || {};
  api.normalizeFilters = normalizeFilters;
  api.readFilters = readFilters;
  api.writeFilters = writeFilters;
  api.readEntriesState = readEntriesState;
  api.readSalesPurchaseState = readSalesPurchaseState;
  api.isSalesPurchaseGeneratedEntry = isSalesPurchaseGeneratedEntry;
  api.buildModel = buildModel;
  api.formatDate = formatDate;
  api.formatNumber = formatNumber;
  api.formatAmount = formatAmount;
  api.todayIso = todayIso;
  api.resolveTypeMeta = resolveTypeMeta;
  api.operationOptions = OPERATION_OPTIONS;
  api.allOperationFilterValues = ALL_OPERATION_FILTER_VALUES;
})();
