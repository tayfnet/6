(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  const api = TAIF.dailyJournal;
  if(!api) return;

  const escapeHtml = typeof TAIF?.core?.utils?.escapeHtml === 'function'
    ? TAIF.core.utils.escapeHtml
    : ((value) => String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;'));

  const escapeSelectorValue = typeof TAIF?.core?.utils?.escapeSelectorValue === 'function'
    ? TAIF.core.utils.escapeSelectorValue
    : (value) => String(value ?? '').replace(/\\/g, '\\\\').replace(/"/g, '\\"');

  const DAILY_JOURNAL_FILTER_ICON = `
    <svg viewBox="0 0 24 24" focusable="false" aria-hidden="true">
      <path d="M4 6.25C4 5.56 4.56 5 5.25 5h13.5a1.25 1.25 0 0 1 .96 2.05l-5.21 6.25a1.25 1.25 0 0 0-.29.8v3.44a1.25 1.25 0 0 1-.55 1.04l-2 1.32A1.25 1.25 0 0 1 9.75 18.9v-4.8c0-.29-.1-.57-.29-.8L4.29 7.05A1.25 1.25 0 0 1 4 6.25Z" fill="currentColor"></path>
    </svg>`;

  const DAILY_JOURNAL_CALENDAR_ICON = `
    <svg viewBox="0 0 24 24" focusable="false" aria-hidden="true">
      <path d="M7 2.75a.75.75 0 0 1 .75.75V5h8.5V3.5a.75.75 0 0 1 1.5 0V5h.75A2.5 2.5 0 0 1 21 7.5v10A2.5 2.5 0 0 1 18.5 20h-13A2.5 2.5 0 0 1 3 17.5v-10A2.5 2.5 0 0 1 5.5 5h.75V3.5A.75.75 0 0 1 7 2.75Zm12.5 7.75h-15v7A1 1 0 0 0 5.5 18h13a1 1 0 0 0 1-1v-6.5Zm-14-3A1 1 0 0 0 4.5 8.5V9h15v-.5a1 1 0 0 0-1-1h-13Z" fill="currentColor"></path>
    </svg>`;

  const DAILY_JOURNAL_CHEVRON_ICON = `
    <svg viewBox="0 0 20 20" focusable="false" aria-hidden="true">
      <path d="M5.25 7.25 10 12l4.75-4.75" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path>
    </svg>`;

  const DAILY_JOURNAL_PICKER_CHECK_ICON = `
    <svg viewBox="0 0 20 20" focusable="false" aria-hidden="true">
      <path d="m4.25 10.25 3.25 3.25 8.25-8.25" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
    </svg>`;

  const DAILY_JOURNAL_DATE_PREV_ICON = '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m12.5 4.5-5 5 5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
  const DAILY_JOURNAL_DATE_NEXT_ICON = '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m7.5 4.5 5 5-5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>';

  const MONTH_LABELS = Object.freeze(Array.isArray(TAIF?.core?.constants?.datePickerMonthNames)
    ? TAIF.core.constants.datePickerMonthNames
    : ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر']);
  const WEEKDAY_LABELS = Object.freeze(Array.isArray(TAIF?.core?.constants?.datePickerWeekdayLabels)
    ? TAIF.core.constants.datePickerWeekdayLabels
    : ['ح','ن','ث','ر','خ','ج','س']);

  const DAILY_JOURNAL_RECORDS_DEFAULT_PAGE_SIZE = 10;
  const DAILY_JOURNAL_RECORDS_PAGE_SIZE_OPTIONS = Object.freeze([10, 20, 50]);
  const DAILY_JOURNAL_RECORDS_ALL_PAGE_SIZE = 'all';

  const runtime = {
    panel:null,
    model:api.buildModel(),
    pendingFilters:api.readFilters(),
    expandedCards:new Set(),
    detachPanelEvents:null,
    detachWindowEvents:[],
    sidebarOpen:false,
    openPicker:null,
    recordsPageSize:DAILY_JOURNAL_RECORDS_DEFAULT_PAGE_SIZE,
    recordsPageIndex:0,
    dateCursors:{},
    dateDrafts:{}
  };

  function safeArray(value){
    return Array.isArray(value) ? value : [];
  }

  function normalizeRecordsPageSize(value){
    if(String(value || '').trim().toLowerCase() === DAILY_JOURNAL_RECORDS_ALL_PAGE_SIZE) return DAILY_JOURNAL_RECORDS_ALL_PAGE_SIZE;
    const numericValue = Math.floor(Number(value));
    return DAILY_JOURNAL_RECORDS_PAGE_SIZE_OPTIONS.includes(numericValue)
      ? numericValue
      : DAILY_JOURNAL_RECORDS_DEFAULT_PAGE_SIZE;
  }

  function getRecordsPageSize(){
    const pageSize = normalizeRecordsPageSize(runtime.recordsPageSize);
    runtime.recordsPageSize = pageSize;
    return pageSize;
  }

  function getRecordsPageIndex(){
    const numericValue = Math.floor(Number(runtime.recordsPageIndex));
    const pageIndex = Number.isFinite(numericValue) && numericValue >= 0 ? numericValue : 0;
    runtime.recordsPageIndex = pageIndex;
    return pageIndex;
  }

  function resetRecordsPagination({ resetPageSize = false } = {}){
    if(resetPageSize) runtime.recordsPageSize = DAILY_JOURNAL_RECORDS_DEFAULT_PAGE_SIZE;
    runtime.recordsPageIndex = 0;
  }

  function resolveRecordsPagination(cards = []){
    const safeCards = safeArray(cards);
    const totalCount = safeCards.length;
    const pageSize = getRecordsPageSize();
    if(pageSize === DAILY_JOURNAL_RECORDS_ALL_PAGE_SIZE){
      runtime.recordsPageIndex = 0;
      return {
        cards:safeCards,
        pageSize,
        pageIndex:0,
        totalPages:1,
        totalCount,
        startIndex: totalCount ? 0 : -1,
        endIndex: totalCount,
        canPrev:false,
        canNext:false
      };
    }
    const safePageSize = Math.max(1, Number(pageSize) || DAILY_JOURNAL_RECORDS_DEFAULT_PAGE_SIZE);
    const totalPages = Math.max(1, Math.ceil(totalCount / safePageSize));
    const pageIndex = Math.max(0, Math.min(totalPages - 1, getRecordsPageIndex()));
    runtime.recordsPageIndex = pageIndex;
    const startIndex = totalCount ? pageIndex * safePageSize : -1;
    const endIndex = totalCount ? Math.min(totalCount, startIndex + safePageSize) : 0;
    return {
      cards: totalCount ? safeCards.slice(startIndex, endIndex) : [],
      pageSize:safePageSize,
      pageIndex,
      totalPages,
      totalCount,
      startIndex,
      endIndex,
      canPrev: totalCount > 0 && pageIndex > 0,
      canNext: totalCount > 0 && pageIndex < totalPages - 1
    };
  }

  function getTodayStartupFilters(){
    const todayValue = typeof api.todayIso === 'function' ? api.todayIso() : todayIso();
    return api.normalizeFilters({ ...api.readFilters(), dateFrom:todayValue, dateTo:todayValue });
  }

  function getPendingFilters(){
    return api.normalizeFilters(runtime.pendingFilters || api.readFilters());
  }

  function sanitizeDate(value){
    const safeValue = String(value ?? '').trim();
    return /^\d{4}-\d{2}-\d{2}$/.test(safeValue) ? safeValue : '';
  }

  function pad2(value){
    return String(value).padStart(2, '0');
  }

  function toIsoDate(date){
    if(!(date instanceof Date) || Number.isNaN(date.getTime())) return '';
    return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
  }

  function todayIso(){
    return toIsoDate(new Date());
  }

  function parseIsoDate(value){
    const safeValue = sanitizeDate(value);
    if(!safeValue) return null;
    const [year, month, day] = safeValue.split('-').map(Number);
    const date = new Date(year, month - 1, day);
    if(date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) return null;
    return date;
  }

  function clampMonthCursor(value){
    const parsed = parseIsoDate(value) || parseIsoDate(todayIso()) || new Date();
    return new Date(parsed.getFullYear(), parsed.getMonth(), 1);
  }

  function formatHeaderDate(value){
    const safeValue = sanitizeDate(value);
    if(!safeValue) return 'اختر التاريخ';
    const [year, month, day] = safeValue.split('-');
    return `${year} / ${month} / ${day}`;
  }

  function renderSegmentedDate(value){
    const safeValue = sanitizeDate(value);
    if(!safeValue) return '<span class="daily-journal-date-picker__placeholder">اختر التاريخ</span>';
    const [year, month, day] = safeValue.split('-');
    return `
      <span class="daily-journal-date-picker__trigger-date" aria-hidden="true">
        <span class="daily-journal-date-picker__trigger-part daily-journal-date-picker__trigger-part--year">${escapeHtml(year)}</span>
        <span class="daily-journal-date-picker__trigger-sep">/</span>
        <span class="daily-journal-date-picker__trigger-part">${escapeHtml(month)}</span>
        <span class="daily-journal-date-picker__trigger-sep">/</span>
        <span class="daily-journal-date-picker__trigger-part">${escapeHtml(day)}</span>
      </span>`;
  }

  function getManualDateParts(field, value){
    const safeField = String(field || '').trim();
    const draft = safeField ? runtime.dateDrafts[safeField] : null;
    if(draft && typeof draft === 'object'){
      return { day:String(draft.day || ''), month:String(draft.month || ''), year:String(draft.year || '') };
    }
    const parsed = parseIsoDate(value);
    return {
      day: parsed ? pad2(parsed.getDate()) : '',
      month: parsed ? pad2(parsed.getMonth() + 1) : '',
      year: parsed ? String(parsed.getFullYear()) : ''
    };
  }

  function sanitizeDatePart(partKey, value){
    const digits = String(value || '').replace(/\D+/g, '');
    return String(partKey || '').trim() === 'year' ? digits.slice(0, 4) : digits.slice(0, 2);
  }

  function composeIsoFromDateParts(parts){
    const day = String(parts?.day || '').trim();
    const month = String(parts?.month || '').trim();
    const year = String(parts?.year || '').trim();
    if(!day && !month && !year) return '';
    if(day.length !== 2 || month.length !== 2 || year.length !== 4) return null;
    const iso = `${year}-${month}-${day}`;
    return parseIsoDate(iso) ? iso : null;
  }

  function readManualDateParts(field){
    if(!(runtime.panel instanceof HTMLElement)) return null;
    const safeField = String(field || '').trim();
    if(!safeField) return null;
    const root = runtime.panel.querySelector(`[data-daily-journal-date-picker="true"][data-daily-journal-date-field="${escapeSelectorValue(safeField)}"]`);
    if(!(root instanceof HTMLElement)) return null;
    const read = (part) => {
      const input = root.querySelector(`[data-daily-journal-date-part="${part}"]`);
      return input instanceof HTMLInputElement ? String(input.value || '') : '';
    };
    return { day: read('day'), month: read('month'), year: read('year') };
  }

  function updateDatePart(field, part, value){
    const safeField = String(field || '').trim();
    const safePart = String(part || '').trim();
    if(!safeField || !safePart) return;
    const parts = readManualDateParts(safeField) || getManualDateParts(safeField, getPendingFilters()[safeField] || '');
    parts[safePart] = sanitizeDatePart(safePart, value);
    runtime.dateDrafts[safeField] = parts;
    const iso = composeIsoFromDateParts(parts);
    if(iso === ''){
      delete runtime.dateDrafts[safeField];
      updatePendingFilter(safeField, '');
      return;
    }
    if(iso){
      delete runtime.dateDrafts[safeField];
      updatePendingFilter(safeField, iso);
      runtime.dateCursors[safeField] = clampMonthCursor(iso);
    }
  }

  function getPickerKey(type, field){
    return `${String(type || '').trim()}:${String(field || '').trim()}`;
  }

  function isPickerOpen(type, field){
    return runtime.openPicker?.key === getPickerKey(type, field);
  }

  function hasOpenPicker(){
    return !!runtime.openPicker;
  }

  function closePicker(){
    runtime.openPicker = null;
  }

  function openPicker(type, field){
    const safeType = String(type || '').trim();
    const safeField = String(field || '').trim();
    if(!safeType || !safeField) return;
    runtime.openPicker = { key:getPickerKey(safeType, safeField), type:safeType, field:safeField };
    if(safeType === 'date'){
      const filters = getPendingFilters();
      runtime.dateCursors[safeField] = clampMonthCursor(filters[safeField] || todayIso());
    }
  }

  function togglePicker(type, field){
    if(isPickerOpen(type, field)) closePicker();
    else openPicker(type, field);
  }

  function updatePendingFilter(key, value){
    const current = { ...getPendingFilters() };
    current[key] = value;
    runtime.pendingFilters = api.normalizeFilters(current);
  }

  function getTotalText(summary, side){
    const totals = safeArray(summary?.totals).filter((item) => Number(item?.[side]) > 0);
    if(!totals.length) return '0 USD';
    return totals.map((item) => api.formatAmount(item[side], item.currency)).join(' / ');
  }

  function renderSummaryChip(label, value, modifier = ''){
    return `
      <span class="daily-journal-summary-chip ${modifier ? `daily-journal-summary-chip--${escapeHtml(modifier)}` : ''}">
        <span class="daily-journal-summary-chip__label">${escapeHtml(label)}</span>
        <strong class="daily-journal-summary-chip__value" dir="ltr">${escapeHtml(value)}</strong>
      </span>`;
  }

  function renderTopbar(){
    const summary = runtime.model?.summary || {};
    const toggleLabel = runtime.sidebarOpen ? 'إخفاء الفلاتر' : 'إظهار الفلاتر';
    return `
      <section class="daily-journal-topbar" aria-label="ملخص دفتر اليومي">
        <div class="daily-journal-topbar__summary">
          ${renderSummaryChip('عداد الحركات', api.formatNumber(summary.cardCount || 0), 'count')}
          ${renderSummaryChip('عداد السطور', api.formatNumber(summary.lineCount || 0), 'lines')}
          ${renderSummaryChip('إجمالي المدين', getTotalText(summary, 'debit'), 'debit')}
          ${renderSummaryChip('إجمالي الدائن', getTotalText(summary, 'credit'), 'credit')}
        </div>
        <button class="daily-journal-topbar__filter-toggle${runtime.sidebarOpen ? ' is-active' : ''}" type="button" data-daily-journal-action="toggle-sidebar" aria-controls="daily-journal-filter-panel" aria-expanded="${runtime.sidebarOpen ? 'true' : 'false'}" aria-label="${escapeHtml(toggleLabel)}" title="${escapeHtml(toggleLabel)}">
          <span class="daily-journal-topbar__filter-toggle-icon">${DAILY_JOURNAL_FILTER_ICON}</span>
        </button>
      </section>`;
  }

  function getDateCursor(field){
    const safeField = String(field || '').trim();
    const current = runtime.dateCursors[safeField];
    if(current instanceof Date && !Number.isNaN(current.getTime())) return new Date(current.getFullYear(), current.getMonth(), 1);
    return clampMonthCursor(getPendingFilters()[safeField] || todayIso());
  }

  function setDateCursor(field, cursor){
    const safeField = String(field || '').trim();
    if(!safeField) return;
    runtime.dateCursors[safeField] = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
  }

  function renderCalendarDays(field, cursor, selectedValue){
    const first = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
    const startOffset = first.getDay();
    const start = new Date(first.getFullYear(), first.getMonth(), 1 - startOffset);
    const todayValue = todayIso();
    const days = [];
    for(let index = 0; index < 42; index += 1){
      const date = new Date(start.getFullYear(), start.getMonth(), start.getDate() + index);
      const value = toIsoDate(date);
      const classNames = [
        'daily-journal-date-picker__day',
        date.getMonth() === cursor.getMonth() ? '' : 'is-outside',
        value === selectedValue ? 'is-selected' : '',
        value === todayValue ? 'is-today' : ''
      ].filter(Boolean).join(' ');
      days.push(`<button class="${classNames}" type="button" data-daily-journal-date-action="select" data-daily-journal-date-field="${escapeHtml(field)}" data-daily-journal-date-value="${escapeHtml(value)}">${escapeHtml(String(date.getDate()))}</button>`);
    }
    return days.join('');
  }

  function renderDatePicker(field, label){
    const filters = getPendingFilters();
    const safeField = String(field || '').trim();
    const value = sanitizeDate(filters[safeField]);
    const isOpen = isPickerOpen('date', safeField);
    const cursor = getDateCursor(safeField);
    const monthLabel = `${MONTH_LABELS[cursor.getMonth()] || ''} ${cursor.getFullYear()}`;
    return `
      <label class="daily-journal-field daily-journal-field--date">
        <span class="daily-journal-field__label">${escapeHtml(label)}</span>
        <div class="daily-journal-date-picker${isOpen ? ' is-open' : ''}" data-daily-journal-picker-root="true" data-daily-journal-date-picker="true" data-daily-journal-date-field="${escapeHtml(safeField)}">
          <div class="daily-journal-field__control daily-journal-date-picker__trigger daily-journal-date-picker__trigger--manual" aria-label="${escapeHtml(label)}: ${escapeHtml(formatHeaderDate(value))}">
            <div class="daily-journal-date-picker__manual" data-daily-journal-date-manual="true">
              <input class="daily-journal-date-picker__manual-input daily-journal-date-picker__manual-input--day" type="text" value="${escapeHtml(getManualDateParts(safeField, value).day)}" placeholder="يوم" inputmode="numeric" autocomplete="off" dir="ltr" data-daily-journal-date-part="day" data-daily-journal-date-field="${escapeHtml(safeField)}" data-daily-journal-filter="${escapeHtml(safeField)}" aria-label="يوم ${escapeHtml(label)}">
              <span class="daily-journal-date-picker__manual-sep" aria-hidden="true">/</span>
              <input class="daily-journal-date-picker__manual-input daily-journal-date-picker__manual-input--month" type="text" value="${escapeHtml(getManualDateParts(safeField, value).month)}" placeholder="شهر" inputmode="numeric" autocomplete="off" dir="ltr" data-daily-journal-date-part="month" data-daily-journal-date-field="${escapeHtml(safeField)}" data-daily-journal-filter="${escapeHtml(safeField)}" aria-label="شهر ${escapeHtml(label)}">
              <span class="daily-journal-date-picker__manual-sep" aria-hidden="true">/</span>
              <input class="daily-journal-date-picker__manual-input daily-journal-date-picker__manual-input--year" type="text" value="${escapeHtml(getManualDateParts(safeField, value).year)}" placeholder="سنة" inputmode="numeric" autocomplete="off" dir="ltr" data-daily-journal-date-part="year" data-daily-journal-date-field="${escapeHtml(safeField)}" data-daily-journal-filter="${escapeHtml(safeField)}" aria-label="سنة ${escapeHtml(label)}">
            </div>
            <button class="daily-journal-date-picker__trigger-icon-btn" type="button" data-daily-journal-date-trigger="true" data-daily-journal-date-field="${escapeHtml(safeField)}" aria-haspopup="dialog" aria-expanded="${isOpen ? 'true' : 'false'}" aria-label="فتح لوحة ${escapeHtml(label)}">
              <span class="daily-journal-date-picker__trigger-icon">${DAILY_JOURNAL_CALENDAR_ICON}</span>
            </button>
          </div>
          ${isOpen ? `
            <div class="daily-journal-date-picker__popover" role="dialog" aria-label="اختيار التاريخ">
              <div class="daily-journal-date-picker__header">
                <button class="daily-journal-date-picker__nav" type="button" data-daily-journal-date-action="prev-month" data-daily-journal-date-field="${escapeHtml(safeField)}" aria-label="الشهر السابق">${DAILY_JOURNAL_DATE_NEXT_ICON}</button>
                <span class="daily-journal-date-picker__heading-trigger">${escapeHtml(monthLabel)}</span>
                <button class="daily-journal-date-picker__nav" type="button" data-daily-journal-date-action="next-month" data-daily-journal-date-field="${escapeHtml(safeField)}" aria-label="الشهر التالي">${DAILY_JOURNAL_DATE_PREV_ICON}</button>
              </div>
              <div class="daily-journal-date-picker__weekdays">${WEEKDAY_LABELS.map((day) => `<span>${escapeHtml(day)}</span>`).join('')}</div>
              <div class="daily-journal-date-picker__grid">${renderCalendarDays(safeField, cursor, value)}</div>
              <div class="daily-journal-date-picker__footer">
                <button class="daily-journal-date-picker__footer-btn" type="button" data-daily-journal-date-action="today" data-daily-journal-date-field="${escapeHtml(safeField)}" data-daily-journal-date-value="${escapeHtml(todayIso())}">اليوم</button>
                <button class="daily-journal-date-picker__footer-btn daily-journal-date-picker__footer-btn--ghost" type="button" data-daily-journal-date-action="clear" data-daily-journal-date-field="${escapeHtml(safeField)}">مسح</button>
                <button class="daily-journal-date-picker__footer-btn daily-journal-date-picker__footer-btn--ghost" type="button" data-daily-journal-date-action="close" data-daily-journal-date-field="${escapeHtml(safeField)}">إغلاق</button>
              </div>
            </div>` : ''}
        </div>
      </label>`;
  }

  function getOperationOptions(){
    return safeArray(runtime.model?.operationOptions).filter((option) => option?.value && option.value !== 'all');
  }

  function getOperationSelection(filters = getPendingFilters()){
    const options = getOperationOptions();
    const available = options.map((option) => option.value);
    const selected = Array.isArray(filters.operationTypes)
      ? filters.operationTypes
      : (filters.operationType && filters.operationType !== 'all' ? [filters.operationType] : available);
    return available.filter((value) => selected.includes(value));
  }

  function areAllOperationsSelected(selectedValues){
    const available = getOperationOptions().map((option) => option.value);
    return !!available.length && selectedValues.length === available.length;
  }

  function getOperationTriggerLabel(selectedValues){
    const options = getOperationOptions();
    if(!selectedValues.length) return 'اختر العملية';
    if(areAllOperationsSelected(selectedValues)) return 'كل العمليات';
    if(selectedValues.length > 1) return 'خيارات محددة';
    return options.find((option) => option.value === selectedValues[0])?.label || 'خيارات محددة';
  }

  function toggleOperationSelection(toggledValue){
    const options = getOperationOptions();
    const available = options.map((option) => option.value);
    if(!available.length) return [];
    const safeValue = String(toggledValue || '').trim();
    const current = new Set(getOperationSelection());
    if(safeValue === 'all') return current.size === available.length ? [] : available.slice();
    if(!available.includes(safeValue)) return Array.from(current);
    if(current.has(safeValue)) current.delete(safeValue);
    else current.add(safeValue);
    return available.filter((value) => current.has(value));
  }

  function renderOperationPicker(){
    const filters = getPendingFilters();
    const selectedValues = getOperationSelection(filters);
    const isAllSelected = areAllOperationsSelected(selectedValues);
    const isOpen = isPickerOpen('choice', 'operationType');
    const triggerLabel = getOperationTriggerLabel(selectedValues);
    const triggerValueClass = selectedValues.length ? 'daily-journal-choice-picker__value' : 'daily-journal-choice-picker__value is-placeholder';
    const options = getOperationOptions();
    return `
      <label class="daily-journal-field daily-journal-field--choice">
        <span class="daily-journal-field__label">العملية</span>
        <div class="daily-journal-choice-picker${isOpen ? ' is-open' : ''}" data-daily-journal-picker-root="true" data-daily-journal-choice-picker="true" data-daily-journal-choice-field="operationType">
          <button class="daily-journal-field__control daily-journal-choice-picker__trigger" type="button" data-daily-journal-choice-trigger="true" data-daily-journal-choice-field="operationType" aria-haspopup="listbox" aria-expanded="${isOpen ? 'true' : 'false'}">
            <span class="${triggerValueClass}">${escapeHtml(triggerLabel)}</span>
            <span class="daily-journal-choice-picker__icon">${DAILY_JOURNAL_CHEVRON_ICON}</span>
          </button>
          ${isOpen ? `
            <div class="daily-journal-choice-popover daily-journal-choice-popover--multi" role="listbox" aria-label="نوع العملية" aria-multiselectable="true">
              <button class="daily-journal-choice-popover__option daily-journal-choice-popover__option--multi${isAllSelected ? ' is-active' : ''}" type="button" role="option" aria-selected="${isAllSelected ? 'true' : 'false'}" data-daily-journal-choice-action="select" data-daily-journal-choice-field="operationTypes" data-daily-journal-choice-value="all">
                <span class="daily-journal-choice-popover__label">كل العمليات</span>
                <span class="daily-journal-choice-popover__box">${DAILY_JOURNAL_PICKER_CHECK_ICON}</span>
              </button>
              ${options.map((option) => {
                const active = selectedValues.includes(option.value);
                return `
                  <button class="daily-journal-choice-popover__option daily-journal-choice-popover__option--multi${active ? ' is-active' : ''}" type="button" role="option" aria-selected="${active ? 'true' : 'false'}" data-daily-journal-choice-action="select" data-daily-journal-choice-field="operationTypes" data-daily-journal-choice-value="${escapeHtml(option.value)}">
                    <span class="daily-journal-choice-popover__label">${escapeHtml(option.label)}</span>
                    <span class="daily-journal-choice-popover__box">${DAILY_JOURNAL_PICKER_CHECK_ICON}</span>
                  </button>`;
              }).join('')}
            </div>` : ''}
        </div>
      </label>`;
  }

  function renderFiltersPanel(){
    const filters = getPendingFilters();
    return `
      <aside class="daily-journal-sidebar" id="daily-journal-filter-panel" aria-label="فلاتر دفتر اليومي" aria-hidden="${runtime.sidebarOpen ? 'false' : 'true'}">
        <div class="daily-journal-sidebar__content">
          <div class="daily-journal-sidebar__card">
            <div class="daily-journal-sidebar__title">فلترة دفتر اليومي</div>
            <div class="daily-journal-filters">
              <div class="daily-journal-filters__row daily-journal-filters__row--dates">
                ${renderDatePicker('dateFrom', 'من تاريخ')}
                ${renderDatePicker('dateTo', 'إلى تاريخ')}
              </div>
              <div class="daily-journal-filters__row">
                ${renderOperationPicker()}
              </div>
              <div class="daily-journal-filters__row">
                <label class="daily-journal-field daily-journal-field--search">
                  <span class="daily-journal-field__label">البحث داخل السطور</span>
                  <input class="daily-journal-field__control daily-journal-search__control" type="search" value="${escapeHtml(filters.search || '')}" placeholder="رقم، بيان، حساب، مستفيد..." data-daily-journal-filter="search" autocomplete="off" spellcheck="false">
                </label>
              </div>
            </div>
          </div>
        </div>
        <div class="daily-journal-sidebar__actions">
          <button class="daily-journal-sidebar__action daily-journal-sidebar__action--apply" type="button" data-daily-journal-action="apply-filters"><span class="daily-journal-sidebar__action-text">عرض النتيجة</span></button>
          <button class="daily-journal-sidebar__action daily-journal-sidebar__action--reset" type="button" data-daily-journal-action="reset-filters"><span class="daily-journal-sidebar__action-text">إعادة الضبط</span></button>
        </div>
      </aside>`;
  }

  function renderCardBadge(card){
    const tone = card?.typeMeta?.tone || 'primary';
    return `<span class="daily-journal-badge daily-journal-badge--${escapeHtml(tone)}">${escapeHtml(card?.typeMeta?.label || card?.title || 'حركة')}</span>`;
  }

  function renderStatusBadge(status){
    const safeStatus = String(status || '').trim();
    const label = safeStatus === 'reversed' ? 'معكوس' : (safeStatus === 'draft' ? 'مسودة' : 'مرحل');
    const tone = safeStatus === 'reversed' ? 'danger' : (safeStatus === 'draft' ? 'muted' : 'success');
    return `<span class="daily-journal-badge daily-journal-badge--${tone}">${escapeHtml(label)}</span>`;
  }

  function renderAmount(value, currency, side){
    const numeric = Number(value) || 0;
    if(!(numeric > 0)) return '<span class="daily-journal-money daily-journal-money--empty">—</span>';
    return `<span class="daily-journal-money daily-journal-money--${escapeHtml(side)}" dir="ltr">${escapeHtml(api.formatAmount(numeric, currency))}</span>`;
  }

  function renderAmountBreakdown(totals, fallbackValue, fallbackCurrency, side){
    const safeTotals = safeArray(totals).filter((item) => Number(item?.amount) > 0);
    if(safeTotals.length){
      return `<span class="daily-journal-money-stack" dir="ltr">${safeTotals
        .map((item) => renderAmount(item.amount, item.currency, side))
        .join('')}</span>`;
    }
    return renderAmount(fallbackValue, fallbackCurrency, side);
  }

  function renderLine(line, index){
    const safeLine = line && typeof line === 'object' ? line : {};
    return `
      <div class="daily-journal-detail-row" role="row">
        <div class="daily-journal-detail-cell daily-journal-detail-cell--no">${escapeHtml(String(safeLine.lineNo || index + 1))}</div>
        <div class="daily-journal-detail-cell daily-journal-detail-cell--account">
          <strong dir="ltr">${escapeHtml(safeLine.accountNo || '—')}</strong>
          <span>${escapeHtml(safeLine.accountName || '—')}</span>
        </div>
        <div class="daily-journal-detail-cell daily-journal-detail-cell--statement">
          <strong>${escapeHtml(safeLine.roleLabel || 'سطر قيد')}</strong>
          <span>${escapeHtml(safeLine.description || '—')}</span>
        </div>
        <div class="daily-journal-detail-cell daily-journal-detail-cell--amount">${renderAmount(safeLine.debit, safeLine.currency, 'debit')}</div>
        <div class="daily-journal-detail-cell daily-journal-detail-cell--amount">${renderAmount(safeLine.credit, safeLine.currency, 'credit')}</div>
      </div>`;
  }

  function renderDetails(card){
    const lines = safeArray(card.lines);
    const sales = card.linkedSales || null;
    return `
      <section class="daily-journal-card__details" aria-label="تفاصيل ${escapeHtml(card.number || '')}">
        <div class="daily-journal-detail-box">
          <div class="daily-journal-detail-meta">
            <span>المصدر: ${escapeHtml(card.sourceKind === 'sales-linked-entry' ? 'فاتورة شراء/مبيع مرتبطة بالقيد' : (card.sourceKind === 'sales-purchase' ? 'فاتورة شراء/مبيع' : 'قيد/سند'))}</span>
            ${card.partyName ? `<span>المستفيد: ${escapeHtml(card.partyName)}</span>` : ''}
            ${sales && Number(sales.rate) > 0 ? `<span>سعر الصرف: <b dir="ltr">${escapeHtml(String(sales.rate))}</b></span>` : ''}
            ${sales && Number(sales.counterpartAmount) > 0 ? `<span>المقابل: <b dir="ltr">${escapeHtml(api.formatAmount(sales.counterpartAmount, sales.lines?.[1]?.currency || card.currency))}</b></span>` : ''}
          </div>
          <div class="daily-journal-detail-table" role="table" aria-label="سطور الحركة">
            <div class="daily-journal-detail-head" role="row">
              <div>#</div>
              <div>الحساب</div>
              <div>البيان</div>
              <div>مدين</div>
              <div>دائن</div>
            </div>
            <div class="daily-journal-detail-body">
              ${lines.length ? lines.map((line, index) => renderLine(line, index)).join('') : '<div class="daily-journal-detail-empty">لا توجد سطور تفصيلية لهذه الحركة.</div>'}
            </div>
          </div>
        </div>
      </section>`;
  }

  function renderCard(card){
    const safeCard = card && typeof card === 'object' ? card : {};
    const isOpen = runtime.expandedCards.has(safeCard.id);
    return `
      <article class="daily-journal-card${isOpen ? ' is-open' : ''}" data-daily-journal-card-id="${escapeHtml(safeCard.id)}">
        <div class="daily-journal-card__main" role="row">
          <div class="daily-journal-card__cell daily-journal-card__cell--action">
            <button class="daily-journal-card__toggle" type="button" data-daily-journal-action="toggle-card" data-daily-journal-card-id="${escapeHtml(safeCard.id)}" aria-expanded="${isOpen ? 'true' : 'false'}">${isOpen ? 'إخفاء' : 'عرض'}</button>
          </div>
          <div class="daily-journal-card__cell daily-journal-card__cell--number" dir="ltr">${escapeHtml(safeCard.number || '—')}</div>
          <div class="daily-journal-card__cell daily-journal-card__cell--date">${escapeHtml(api.formatDate(safeCard.date))}</div>
          <div class="daily-journal-card__cell daily-journal-card__cell--type">${renderCardBadge(safeCard)}</div>
          <div class="daily-journal-card__cell daily-journal-card__cell--statement">
            <strong>${escapeHtml(safeCard.description || '—')}</strong>
            <span>${escapeHtml(safeCard.partyName || '')}</span>
          </div>
          <div class="daily-journal-card__cell daily-journal-card__cell--amount">${renderAmountBreakdown(safeCard.debitTotals, safeCard.debit, safeCard.currency, 'debit')}</div>
          <div class="daily-journal-card__cell daily-journal-card__cell--amount">${renderAmountBreakdown(safeCard.creditTotals, safeCard.credit, safeCard.currency, 'credit')}</div>
          <div class="daily-journal-card__cell daily-journal-card__cell--status">${renderStatusBadge(safeCard.status)}</div>
        </div>
        ${isOpen ? renderDetails(safeCard) : ''}
      </article>`;
  }

  function renderRecordsPageSizeOptions(activePageSize){
    const safeActivePageSize = normalizeRecordsPageSize(activePageSize);
    const numericOptions = DAILY_JOURNAL_RECORDS_PAGE_SIZE_OPTIONS.map((pageSize) => `
      <option value="${escapeHtml(String(pageSize))}"${safeActivePageSize === pageSize ? ' selected' : ''}>${escapeHtml(String(pageSize))} لكل صفحة</option>
    `).join('');
    return `${numericOptions}
      <option value="${escapeHtml(DAILY_JOURNAL_RECORDS_ALL_PAGE_SIZE)}"${safeActivePageSize === DAILY_JOURNAL_RECORDS_ALL_PAGE_SIZE ? ' selected' : ''}>الكل</option>
    `;
  }

  function renderRecordsPaginationButton(action, label, title, disabled = false){
    const safeAction = String(action || '').trim();
    return `
      <button class="daily-journal-records-pagination__nav-btn" type="button" data-daily-journal-action="records-page-${escapeHtml(safeAction)}" aria-label="${escapeHtml(title)}" title="${escapeHtml(title)}"${disabled ? ' disabled aria-disabled="true"' : ''}>
        <span aria-hidden="true">${escapeHtml(label)}</span>
      </button>`;
  }

  function renderRecordsPaginationBar(pageState){
    if(!pageState || !(Number(pageState.totalCount) > 0)) return '';
    const fromLabel = Number(pageState.startIndex) >= 0 ? Number(pageState.startIndex) + 1 : 0;
    const toLabel = Number(pageState.endIndex) || 0;
    const totalLabel = Number(pageState.totalCount) || 0;
    const currentPageLabel = Math.max(1, Number(pageState.pageIndex) + 1 || 1);
    const canPrev = !!pageState.canPrev;
    const canNext = !!pageState.canNext;
    return `
      <div class="daily-journal-records-pagination" aria-label="شريط تنقل دفتر اليومي">
        <label class="daily-journal-records-pagination__page-size">
          <select class="daily-journal-records-pagination__select" data-daily-journal-records-page-size="true" aria-label="عدد الحركات في الصفحة">
            ${renderRecordsPageSizeOptions(pageState.pageSize)}
          </select>
        </label>
        <div class="daily-journal-records-pagination__summary" aria-live="polite">
          عرض <span dir="ltr">${escapeHtml(String(fromLabel))}</span> - <span dir="ltr">${escapeHtml(String(toLabel))}</span> من <span dir="ltr">${escapeHtml(String(totalLabel))}</span>
        </div>
        <nav class="daily-journal-records-pagination__nav" aria-label="تنقل صفحات دفتر اليومي">
          ${renderRecordsPaginationButton('last', '«', 'الصفحة الأخيرة', !canNext)}
          ${renderRecordsPaginationButton('next', '‹', 'الصفحة التالية', !canNext)}
          <span class="daily-journal-records-pagination__page" dir="ltr" aria-label="الصفحة الحالية">${escapeHtml(String(currentPageLabel))}</span>
          ${renderRecordsPaginationButton('prev', '›', 'الصفحة السابقة', !canPrev)}
          ${renderRecordsPaginationButton('first', '»', 'الصفحة الأولى', !canPrev)}
        </nav>
      </div>`;
  }

  function renderJournalBody(){
    const cards = safeArray(runtime.model?.cards);
    if(!cards.length){
      runtime.recordsPageIndex = 0;
      return `
        <div class="daily-journal-empty">
          <strong>لا توجد حركات ضمن الفلتر الحالي</strong>
          <span>دفتر اليومي يعرض سجلات يوم اليوم تلقائياً، ويمكن تغيير التاريخ من لوحة الفلاتر.</span>
        </div>`;
    }

    const pageState = resolveRecordsPagination(cards);
    const pageCards = safeArray(pageState.cards);
    return `
      <section class="daily-journal-list" role="table" aria-label="سجلات دفتر اليومي">
        <div class="daily-journal-list__head" role="row">
          <div>التفاصيل</div>
          <div>رقم الحركة</div>
          <div>التاريخ</div>
          <div>العملية</div>
          <div>البيان</div>
          <div>مدين</div>
          <div>دائن</div>
          <div>الحالة</div>
        </div>
        <div class="daily-journal-list__body">
          ${pageCards.map((card) => renderCard(card)).join('')}
        </div>
      </section>
      ${renderRecordsPaginationBar(pageState)}`;
  }

  function renderShellMarkup(){
    const shellClassName = [
      'daily-journal-shell',
      runtime.sidebarOpen ? 'daily-journal-shell--sidebar-open' : 'daily-journal-shell--sidebar-closed',
      hasOpenPicker() ? 'daily-journal-shell--picker-open' : ''
    ].filter(Boolean).join(' ');
    return `
      <div class="${shellClassName}" data-owner-view="daily-journal">
        <section class="daily-journal-workspace">
          <div class="daily-journal-sidebar__backdrop" data-daily-journal-action="close-sidebar" aria-hidden="true"></div>
          ${renderFiltersPanel()}
          <section class="daily-journal-board" aria-label="سجل دفتر اليومي">
            ${renderTopbar()}
            <div class="daily-journal-board__body">
              ${renderJournalBody()}
            </div>
          </section>
        </section>
      </div>`;
  }

  function takeFocusSnapshot(){
    const active = document.activeElement;
    if(!(active instanceof HTMLElement) || !runtime.panel?.contains(active)) return null;
    const key = String(active.dataset.dailyJournalFilter || '').trim();
    if(!key) return null;
    return {
      key,
      value: active instanceof HTMLInputElement ? active.value : '',
      selectionStart: typeof active.selectionStart === 'number' ? active.selectionStart : null,
      selectionEnd: typeof active.selectionEnd === 'number' ? active.selectionEnd : null
    };
  }

  function restoreFocusSnapshot(snapshot){
    if(!snapshot || !(runtime.panel instanceof HTMLElement)) return;
    const selector = `[data-daily-journal-filter="${escapeSelectorValue(snapshot.key)}"]`;
    const element = runtime.panel.querySelector(selector);
    if(!(element instanceof HTMLElement)) return;
    try{ element.focus({ preventScroll:true }); }catch{ try{ element.focus(); }catch{} }
    if(element instanceof HTMLInputElement && typeof snapshot.selectionStart === 'number'){
      try{ element.setSelectionRange(snapshot.selectionStart, snapshot.selectionEnd ?? snapshot.selectionStart); }catch{}
    }
  }

  function rerender({ preserveFocus = false } = {}){
    const focusSnapshot = preserveFocus ? takeFocusSnapshot() : null;
    if(!(runtime.panel instanceof HTMLElement)) return;
    runtime.panel.innerHTML = renderShellMarkup();
    if(typeof runtime.detachPanelEvents === 'function') runtime.detachPanelEvents();
    runtime.detachPanelEvents = bindPanelEvents();
    if(focusSnapshot) requestAnimationFrame(() => restoreFocusSnapshot(focusSnapshot));
  }

  function applyFilters(){
    const persisted = api.writeFilters(getPendingFilters());
    runtime.pendingFilters = persisted;
    runtime.model = api.buildModel(persisted);
    runtime.expandedCards = new Set();
    resetRecordsPagination();
    closePicker();
    rerender();
  }

  function resetFilters(){
    const todayFilters = getTodayStartupFilters();
    const persisted = api.writeFilters(todayFilters);
    runtime.pendingFilters = persisted;
    runtime.model = api.buildModel(persisted);
    runtime.expandedCards = new Set();
    resetRecordsPagination();
    runtime.dateCursors = {};
    runtime.dateDrafts = {};
    closePicker();
    rerender();
  }

  function toggleCard(cardId){
    const safeId = String(cardId || '').trim();
    if(!safeId) return;
    if(runtime.expandedCards.has(safeId)) runtime.expandedCards.delete(safeId);
    else runtime.expandedCards.add(safeId);
    rerender();
  }

  function moveRecordsPage(direction = ''){
    const pageState = resolveRecordsPagination(safeArray(runtime.model?.cards));
    let nextPageIndex = pageState.pageIndex;
    const safeDirection = String(direction || '').trim();
    if(safeDirection === 'first') nextPageIndex = 0;
    else if(safeDirection === 'prev') nextPageIndex = pageState.pageIndex - 1;
    else if(safeDirection === 'next') nextPageIndex = pageState.pageIndex + 1;
    else if(safeDirection === 'last') nextPageIndex = pageState.totalPages - 1;
    nextPageIndex = Math.max(0, Math.min(Math.max(1, pageState.totalPages) - 1, nextPageIndex));
    if(nextPageIndex === pageState.pageIndex) return;
    runtime.recordsPageIndex = nextPageIndex;
    runtime.expandedCards = new Set();
    rerender();
  }

  function setRecordsPageSize(value){
    const nextPageSize = normalizeRecordsPageSize(value);
    if(runtime.recordsPageSize === nextPageSize && getRecordsPageIndex() === 0) return;
    runtime.recordsPageSize = nextPageSize;
    runtime.recordsPageIndex = 0;
    runtime.expandedCards = new Set();
    rerender();
  }

  function toggleSidebar(force){
    runtime.sidebarOpen = typeof force === 'boolean' ? force : !runtime.sidebarOpen;
    if(!runtime.sidebarOpen) closePicker();
    rerender();
  }

  function shiftDateCursor(field, delta){
    const cursor = getDateCursor(field);
    setDateCursor(field, new Date(cursor.getFullYear(), cursor.getMonth() + delta, 1));
    openPicker('date', field);
    rerender();
  }

  function selectDate(field, value, { close = true } = {}){
    updatePendingFilter(field, sanitizeDate(value));
    if(close) closePicker();
    else openPicker('date', field);
    rerender();
  }

  function selectChoice(field, value){
    const safeField = String(field || '').trim();
    if(safeField === 'operationTypes' || safeField === 'operationType'){
      updatePendingFilter('operationTypes', toggleOperationSelection(value));
      openPicker('choice', 'operationType');
      rerender();
      return;
    }
    updatePendingFilter(safeField, value);
    closePicker();
    rerender();
  }

  function bindPanelEvents(){
    const panel = runtime.panel;
    if(!(panel instanceof HTMLElement)) return () => {};

    const handleInput = (event) => {
      const target = event.target;
      if(!(target instanceof HTMLElement)) return;
      if(target instanceof HTMLInputElement && target.matches('[data-daily-journal-date-part]')){
        const field = String(target.dataset.dailyJournalDateField || '').trim();
        const part = String(target.dataset.dailyJournalDatePart || '').trim();
        if(!field || !part) return;
        const cleanValue = sanitizeDatePart(part, target.value || '');
        if(target.value !== cleanValue) target.value = cleanValue;
        updateDatePart(field, part, cleanValue);
        return;
      }

      const filterKey = String(target.dataset.dailyJournalFilter || '').trim();
      if(!filterKey) return;
      const value = target instanceof HTMLInputElement ? target.value : '';
      updatePendingFilter(filterKey, value);
      if(filterKey === 'search') rerender({ preserveFocus:true });
    };

    const handleClick = (event) => {
      const clickTarget = event.target instanceof Element ? event.target : null;
      if(!clickTarget) return;
      const actionElement = clickTarget.closest('[data-daily-journal-action]');
      if(actionElement instanceof HTMLElement){
        const action = String(actionElement.dataset.dailyJournalAction || '').trim();
        if(action === 'toggle-sidebar'){
          event.preventDefault();
          toggleSidebar();
          return;
        }
        if(action === 'close-sidebar'){
          event.preventDefault();
          toggleSidebar(false);
          return;
        }
        if(action === 'toggle-card'){
          event.preventDefault();
          toggleCard(actionElement.dataset.dailyJournalCardId);
          return;
        }
        if(action.startsWith('records-page-')){
          event.preventDefault();
          moveRecordsPage(action.replace('records-page-', ''));
          return;
        }
        if(action === 'apply-filters'){
          event.preventDefault();
          applyFilters();
          return;
        }
        if(action === 'reset-filters'){
          event.preventDefault();
          resetFilters();
          return;
        }
      }

      const dateTrigger = clickTarget.closest('[data-daily-journal-date-trigger="true"]');
      if(dateTrigger instanceof HTMLElement){
        event.preventDefault();
        togglePicker('date', dateTrigger.dataset.dailyJournalDateField || '');
        rerender();
        return;
      }

      const dateAction = clickTarget.closest('[data-daily-journal-date-action]');
      if(dateAction instanceof HTMLElement){
        event.preventDefault();
        const field = dateAction.dataset.dailyJournalDateField || '';
        const action = String(dateAction.dataset.dailyJournalDateAction || '').trim();
        if(action === 'prev-month'){
          shiftDateCursor(field, -1);
          return;
        }
        if(action === 'next-month'){
          shiftDateCursor(field, 1);
          return;
        }
        if(action === 'select' || action === 'today'){
          delete runtime.dateDrafts[field];
          selectDate(field, dateAction.dataset.dailyJournalDateValue || todayIso());
          return;
        }
        if(action === 'clear'){
          delete runtime.dateDrafts[field];
          selectDate(field, '');
          return;
        }
        if(action === 'close'){
          closePicker();
          rerender();
          return;
        }
      }

      const choiceTrigger = clickTarget.closest('[data-daily-journal-choice-trigger="true"]');
      if(choiceTrigger instanceof HTMLElement){
        event.preventDefault();
        togglePicker('choice', choiceTrigger.dataset.dailyJournalChoiceField || '');
        rerender();
        return;
      }

      const choiceOption = clickTarget.closest('[data-daily-journal-choice-action="select"]');
      if(choiceOption instanceof HTMLElement){
        event.preventDefault();
        selectChoice(choiceOption.dataset.dailyJournalChoiceField || '', choiceOption.dataset.dailyJournalChoiceValue || 'all');
        return;
      }

      if(hasOpenPicker() && !clickTarget.closest('[data-daily-journal-picker-root="true"]')){
        closePicker();
        rerender();
      }
    };

    const handleChange = (event) => {
      const target = event.target;
      if(target instanceof HTMLSelectElement && target.matches('[data-daily-journal-records-page-size]')){
        event.preventDefault();
        setRecordsPageSize(target.value);
      }
    };

    const handleKeydown = (event) => {
      const target = event.target;
      if(!(target instanceof HTMLElement)) return;
      if(event.key === 'Escape'){
        if(hasOpenPicker()){
          event.preventDefault();
          closePicker();
          rerender();
          return;
        }
        if(runtime.sidebarOpen){
          event.preventDefault();
          toggleSidebar(false);
          return;
        }
      }
      if(String(target.dataset.dailyJournalFilter || '').trim() && event.key === 'Enter'){
        event.preventDefault();
        applyFilters();
      }
    };

    panel.addEventListener('input', handleInput);
    panel.addEventListener('click', handleClick);
    panel.addEventListener('change', handleChange);
    panel.addEventListener('keydown', handleKeydown);

    return () => {
      panel.removeEventListener('input', handleInput);
      panel.removeEventListener('click', handleClick);
      panel.removeEventListener('change', handleChange);
      panel.removeEventListener('keydown', handleKeydown);
    };
  }

  function cleanupView(){
    if(typeof runtime.detachPanelEvents === 'function') runtime.detachPanelEvents();
    runtime.detachPanelEvents = null;
    safeArray(runtime.detachWindowEvents).forEach((dispose) => {
      if(typeof dispose === 'function'){
        try{ dispose(); }catch{}
      }
    });
    runtime.detachWindowEvents = [];
    runtime.panel = null;
    runtime.expandedCards = new Set();
    resetRecordsPagination();
    runtime.pendingFilters = api.readFilters();
    runtime.sidebarOpen = false;
    runtime.dateDrafts = {};
    closePicker();
  }

  function bindWindowEvents(){
    const listeners = [];
    const rerenderIfActive = () => {
      if(!TAIF?.core?.utils?.isActiveView?.('daily-journal')) return;
      runtime.model = api.buildModel(api.readFilters());
      rerender();
    };
    const events = TAIF.core && TAIF.core.events;
    if(events && typeof events.onMany === 'function'){
      listeners.push(events.onMany([
        events.EVENT_NAMES?.ENTRIES_VOUCHERS_UPDATED,
        events.EVENT_NAMES?.SALES_PURCHASE_UPDATED,
        events.EVENT_NAMES?.CASH_BOXES_UPDATED,
        events.EVENT_NAMES?.LEDGER_READ_MODEL_INVALIDATED
      ].filter(Boolean), rerenderIfActive));
    }else{
      ['taif:entries-vouchers-updated', 'taif:sales-purchase-invoice-updated', 'taif:cash-boxes-updated'].forEach((eventName) => {
        window.addEventListener(eventName, rerenderIfActive);
        listeners.push(() => window.removeEventListener(eventName, rerenderIfActive));
      });
    }
    runtime.detachWindowEvents = listeners;
  }

  TAIF.registerViewCleanup('daily-journal', cleanupView);
  TAIF.registerViewRenderer('daily-journal', ({ panel }) => {
    cleanupView();
    runtime.panel = panel;
    const todayFilters = getTodayStartupFilters();
    runtime.pendingFilters = api.writeFilters(todayFilters);
    runtime.model = api.buildModel(runtime.pendingFilters);
    runtime.dateCursors = {};
    runtime.dateDrafts = {};
    resetRecordsPagination();
    bindWindowEvents();
    panel.innerHTML = renderShellMarkup();
    runtime.detachPanelEvents = bindPanelEvents();
  });
})();
