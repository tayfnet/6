
(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  if(!TAIF.core || !TAIF.core.utils) return;

  const utils = TAIF.core.utils;
  const toText = typeof utils.toText === 'function' ? utils.toText : ((value, fallback = '') => String(value == null ? fallback : value).trim());
  const clone = typeof utils.clone === 'function' ? utils.clone : ((value) => JSON.parse(JSON.stringify(value)));
  const readJsonStorage = typeof utils.readJsonStorage === 'function' ? utils.readJsonStorage : (() => null);
  const persistJsonState = typeof utils.persistJsonState === 'function' ? utils.persistJsonState : ((_, value) => value);
  const normalizeAccountCatalog = typeof utils.normalizeAccountCatalog === 'function'
    ? utils.normalizeAccountCatalog
    : ((value) => Array.isArray(value) ? value : []);
  const readChartAccountCatalogSource = typeof utils.readChartAccountCatalogSource === 'function'
    ? utils.readChartAccountCatalogSource
    : (() => []);
  const parseNumericInput = typeof utils.parseNumericInput === 'function'
    ? utils.parseNumericInput
    : ((value, fallback = 0) => {
        const numeric = Number(String(value ?? '').replace(/,/g, '').trim());
        return Number.isFinite(numeric) ? numeric : Number(fallback) || 0;
      });

  const storageKeys = TAIF?.core?.storageKeys || {};
  const ENTRIES_STORAGE_KEY = storageKeys.entriesVouchers || 'taif-entries-vouchers-module-v1';
  const ACCOUNT_STORAGE_KEY = storageKeys.chartOfAccounts || 'taif-chart-of-accounts-centers-v3';
  const SALES_PURCHASE_STORAGE_KEY = storageKeys.salesPurchaseInvoice || 'taif-sales-purchase-invoice-records-v1';
  const FILTER_STORAGE_KEY = 'taif-general-ledger-ui-v1';
  const SOURCE_FOCUS_STORAGE_KEY = 'taif-general-ledger-source-focus-v1';
  const GENERAL_LEDGER_AMOUNT_EPSILON = 1e-9;

  function resolveDomainAdapter(name){
    const registry = TAIF.domain || {};
    if(typeof registry.resolve === 'function') return registry.resolve(name);
    return registry[name] || null;
  }

  function resolveService(name){
    const registry = TAIF.services || {};
    if(typeof registry.resolve === 'function') return registry.resolve(name);
    return registry[name] || null;
  }

  const DEFAULT_LEDGER_ACCOUNT_CATALOG = Object.freeze([
    Object.freeze({ id:'coa-default-001', accountNo:'001', name:'صندوق محلي اساسي', centerType:'main' }),
    Object.freeze({ id:'coa-default-003', accountNo:'002', name:'عملات مدفوعة', centerType:'main' }),
    Object.freeze({ id:'coa-default-004', accountNo:'003', name:'عملات محققة', centerType:'main' }),
    Object.freeze({ id:'coa-default-005', accountNo:'004', name:'حوالات لم تسلم', centerType:'main' }),
    Object.freeze({ id:'coa-default-006', accountNo:'005', name:'حسابات القطع الأجنبي', centerType:'main' }),
    Object.freeze({ id:'coa-default-007', accountNo:'006', name:'رأس المال المدفوع', centerType:'main' }),
    Object.freeze({ id:'coa-default-008', accountNo:'007', name:'مصاريف', centerType:'main' })
  ]);

  const TYPE_META = Object.freeze({
    payment: Object.freeze({ key:'payment', label:'سند دفع', badgeClass:'general-ledger-badge--danger' }),
    receipt: Object.freeze({ key:'receipt', label:'سند قبض', badgeClass:'general-ledger-badge--success' }),
    journal: Object.freeze({ key:'journal', label:'سند يومي', badgeClass:'general-ledger-badge--primary' }),
    settlement: Object.freeze({ key:'settlement', label:'سند تسوية', badgeClass:'general-ledger-badge--journal' }),
    opening: Object.freeze({ key:'opening', label:'قيد افتتاحي', badgeClass:'general-ledger-badge--violet' }),
    sale: Object.freeze({ key:'sale', label:'فاتورة مبيع', badgeClass:'general-ledger-badge--danger' }),
    purchase: Object.freeze({ key:'purchase', label:'فاتورة شراء', badgeClass:'general-ledger-badge--success' })
  });

  const OPERATION_FILTER_OPTIONS = Object.freeze([
    Object.freeze({ value:'payment', label:'سند دفع' }),
    Object.freeze({ value:'receipt', label:'سند قبض' }),
    Object.freeze({ value:'journal', label:'سند يومي' }),
    Object.freeze({ value:'settlement', label:'سند تسوية' }),
    Object.freeze({ value:'opening', label:'سند قيد افتتاحي' }),
    Object.freeze({ value:'sale', label:'فاتورة مبيع' }),
    Object.freeze({ value:'purchase', label:'فاتورة شراء' })
  ]);

  const ALL_OPERATION_FILTER_VALUES = Object.freeze(OPERATION_FILTER_OPTIONS.map((option) => option.value));
  const OPERATION_FILTER_VALUE_SET = new Set(ALL_OPERATION_FILTER_VALUES);

  const EXCHANGE_RATE_MODE_OPTIONS = Object.freeze([
    Object.freeze({ value:'average-cost', label:'سعر التكلفة', columnLabel:'سعر التكلفة' }),
    Object.freeze({ value:'valuation', label:'سعر الوسطي', columnLabel:'سعر الوسطي' })
  ]);
  const DEFAULT_EXCHANGE_RATE_MODE = 'average-cost';
  const EXCHANGE_RATE_MODE_VALUE_SET = new Set(EXCHANGE_RATE_MODE_OPTIONS.map((option) => option.value));

  const DEFAULT_FILTERS = Object.freeze({
    accountNo: '',
    dateFrom: '',
    dateTo: '',
    autoTodayDates: true,
    currency: 'all',
    currencies: ['all'],
    operationTypes: ALL_OPERATION_FILTER_VALUES.slice(),
    exchangeRateMode: DEFAULT_EXCHANGE_RATE_MODE,
    hideOpeningBalance: false,
    search: ''
  });

  function sanitizeDate(value){
    const safeValue = toText(value);
    return /^\d{4}-\d{2}-\d{2}$/.test(safeValue) ? safeValue : '';
  }

  function getTodayIsoDate(){
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function getIsoDateFromTimestamp(value){
    const timestamp = Number(value);
    if(!Number.isFinite(timestamp) || timestamp <= 0) return '';
    const date = new Date(timestamp);
    if(Number.isNaN(date.getTime())) return '';
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function resolveAutoTodayDatesPreference(raw, fallbackTodayIsoDate = ''){
    if(raw && typeof raw.autoTodayDates === 'boolean') return raw.autoTodayDates;
    const storedDateFrom = sanitizeDate(raw?.dateFrom);
    const storedDateTo = sanitizeDate(raw?.dateTo);
    if(!storedDateFrom && !storedDateTo) return true;
    if(!storedDateFrom || !storedDateTo) return false;
    if(storedDateFrom !== storedDateTo) return false;
    const storedUpdatedIsoDate = getIsoDateFromTimestamp(raw?.updatedAt);
    if(storedUpdatedIsoDate && storedDateFrom === storedUpdatedIsoDate) return true;
    return !!fallbackTodayIsoDate && storedDateFrom === fallbackTodayIsoDate && storedDateTo === fallbackTodayIsoDate;
  }

  function normalizeCurrencyCode(value){
    const safe = toText(value).toUpperCase().replace(/[^A-Z]/g, '');
    return safe || '';
  }

  function sanitizeSearch(value){
    return String(value ?? '').replace(/\s+/g, ' ').trim();
  }

  function sanitizeExchangeRateMode(value){
    const safeValue = String(value ?? '').trim().toLowerCase().replace(/_/g, '-');
    if(safeValue === 'cost'
      || safeValue === 'average'
      || safeValue === 'averagecost'
      || safeValue === 'average-cost'
      || safeValue === 'trading'
      || safeValue === 'trading-average'
      || safeValue === 'transaction-average'
      || safeValue === 'transaction-average-cost'
      || safeValue === 'weighted-trading-average'
      || safeValue === 'weighted-average-cost'
      || safeValue === 'trading-average-cost') return 'average-cost';
    if(safeValue === 'evaluation' || safeValue === 'rate-evaluation' || safeValue === 'valuation-rate' || safeValue === 'valuation') return 'valuation';
    return EXCHANGE_RATE_MODE_VALUE_SET.has(safeValue) ? safeValue : DEFAULT_EXCHANGE_RATE_MODE;
  }

  function resolveExchangeRateModeMeta(value){
    const safeValue = sanitizeExchangeRateMode(value);
    return EXCHANGE_RATE_MODE_OPTIONS.find((option) => option.value === safeValue) || EXCHANGE_RATE_MODE_OPTIONS[0];
  }

  function sanitizeCurrencySelections(value, { preserveEmptyArray = false } = {}){
    const inputIsArray = Array.isArray(value);
    const inputValues = inputIsArray ? value : [value];
    const normalized = inputValues.flatMap((entry) => {
      const safeValue = String(entry ?? '').trim();
      if(!safeValue) return [];
      if(safeValue.toLowerCase() === 'all') return ['all'];
      const code = normalizeCurrencyCode(safeValue);
      return code ? [code] : [];
    });
    const uniqueValues = Array.from(new Set(normalized));
    if(uniqueValues.includes('all')) return ['all'];
    if(uniqueValues.length) return uniqueValues;
    if(preserveEmptyArray && inputIsArray && value.length === 0) return [];
    return ['all'];
  }

  function deriveLegacyCurrencyFilter(currencySelections){
    const preserveEmptyArray = Array.isArray(currencySelections) && currencySelections.length === 0;
    const safeValues = sanitizeCurrencySelections(currencySelections, { preserveEmptyArray });
    if(!safeValues.length) return 'none';
    if(safeValues.includes('all')) return 'all';
    if(safeValues.length === 1) return safeValues[0];
    return 'multiple';
  }

  function sanitizeOperationTypes(value, { legacySingle = false, preserveEmptyArray = false } = {}){
    const voucherValues = ['payment', 'receipt', 'journal', 'settlement', 'opening'];
    const tradeValues = ['sale', 'purchase'];

    const normalizeSingle = (entry) => {
      const safeValue = String(entry ?? '').trim().toLowerCase();
      if(!safeValue || safeValue === 'all') return ALL_OPERATION_FILTER_VALUES.slice();
      if(legacySingle && safeValue === 'vouchers') return voucherValues.slice();
      if(safeValue === 'trade') return tradeValues.slice();
      return OPERATION_FILTER_VALUE_SET.has(safeValue) ? [safeValue] : [];
    };

    const inputIsArray = Array.isArray(value);
    const inputValues = inputIsArray ? value : [value];
    const normalized = inputValues.flatMap((entry) => normalizeSingle(entry));
    const uniqueValues = Array.from(new Set(normalized.filter((entry) => OPERATION_FILTER_VALUE_SET.has(entry))));
    if(uniqueValues.length) return uniqueValues;
    if(preserveEmptyArray && inputIsArray && value.length === 0) return [];
    return ALL_OPERATION_FILTER_VALUES.slice();
  }

  function deriveLegacyOperationType(operationTypes){
    const preserveEmptyArray = Array.isArray(operationTypes) && operationTypes.length === 0;
    const safeValues = sanitizeOperationTypes(operationTypes, { preserveEmptyArray });
    if(!safeValues.length) return 'none';
    if(safeValues.length === ALL_OPERATION_FILTER_VALUES.length) return 'all';
    if(safeValues.length === 1) return safeValues[0];
    return 'multiple';
  }

  function normalizeFilters(input){
    const raw = input && typeof input === 'object' ? input : {};
    const todayIsoDate = getTodayIsoDate();
    const autoTodayDates = resolveAutoTodayDatesPreference(raw, todayIsoDate);
    let dateFrom = sanitizeDate(raw.dateFrom);
    let dateTo = sanitizeDate(raw.dateTo);
    if(autoTodayDates){
      dateFrom = todayIsoDate;
      dateTo = todayIsoDate;
    }else{
      dateFrom = dateFrom || todayIsoDate;
      dateTo = dateTo || todayIsoDate;
      if(dateFrom && dateTo && dateFrom > dateTo){
        const swap = dateFrom;
        dateFrom = dateTo;
        dateTo = swap;
      }
    }

    const hasCurrenciesArray = Array.isArray(raw.currencies);
    const preserveEmptyCurrencies = hasCurrenciesArray && raw.currencies.length === 0;
    const currencies = sanitizeCurrencySelections(
      hasCurrenciesArray ? raw.currencies : raw.currency,
      { preserveEmptyArray:preserveEmptyCurrencies }
    );

    const hasOperationTypesArray = Array.isArray(raw.operationTypes);
    const preserveEmptyOperationTypes = hasOperationTypesArray && raw.operationTypes.length === 0;
    const operationTypes = sanitizeOperationTypes(
      hasOperationTypesArray ? raw.operationTypes : raw.operationType,
      {
        legacySingle:!hasOperationTypesArray,
        preserveEmptyArray:preserveEmptyOperationTypes
      }
    );
    return {
      accountNo: toText(raw.accountNo),
      dateFrom,
      dateTo,
      autoTodayDates,
      currency: deriveLegacyCurrencyFilter(currencies),
      currencies,
      operationTypes,
      operationType: deriveLegacyOperationType(operationTypes),
      exchangeRateMode: sanitizeExchangeRateMode(raw.exchangeRateMode || raw.rateMode || raw.exchangeRateBasis),
      hideOpeningBalance: raw.hideOpeningBalance === true || raw.hidePreviousBalance === true || raw.hideOpening === true,
      search: sanitizeSearch(raw.search)
    };
  }

  function readFilters(){
    return normalizeFilters(readJsonStorage(FILTER_STORAGE_KEY, DEFAULT_FILTERS));
  }

  function writeFilters(nextFilters){
    return persistJsonState(FILTER_STORAGE_KEY, nextFilters, normalizeFilters);
  }

  function normalizeLine(line, index = 0){
    const raw = line && typeof line === 'object' ? line : {};
    const debit = Math.max(0, parseNumericInput(raw.debit, 0));
    const credit = Math.max(0, parseNumericInput(raw.credit, 0));
    return {
      lineNo: Math.max(1, Number(raw.lineNo) || index + 1),
      roleKey: toText(raw.roleKey),
      roleLabel: toText(raw.roleLabel),
      accountNo: toText(raw.accountNo),
      accountName: toText(raw.accountName),
      description: toText(raw.description),
      debit,
      credit,
      amount: Math.max(0, parseNumericInput(raw.amount, Math.max(debit, credit))),
      side: raw.side === 'credit' ? 'credit' : 'debit'
    };
  }

  function normalizeRecord(record, index = 0){
    const raw = record && typeof record === 'object' ? record : {};
    const createdAt = Number(raw.createdAt) > 0 ? Number(raw.createdAt) : Date.now() + index;
    const lines = Array.isArray(raw.lines)
      ? raw.lines.map((line, lineIndex) => normalizeLine(line, lineIndex)).filter((line) => line.accountNo)
      : [];
    return {
      id: toText(raw.id) || `general-ledger-entry-${createdAt}-${index + 1}`,
      type: toText(raw.type) || 'journal',
      number: toText(raw.number).toUpperCase(),
      status: raw.status === 'reversed' ? 'reversed' : (raw.status === 'draft' ? 'draft' : 'posted'),
      date: sanitizeDate(raw.date),
      description: toText(raw.description),
      summary: toText(raw.summary),
      counterpartAccountNo: toText(raw.counterpartAccountNo),
      counterpartAccountName: toText(raw.counterpartAccountName),
      beneficiaryName: toText(raw.beneficiaryName),
      partyName: toText(raw.partyName),
      currency: normalizeCurrencyCode(raw.currency) || 'USD',
      amount: Math.max(0, parseNumericInput(raw.amount, 0)),
      grossAmount: Math.max(0, parseNumericInput(raw.grossAmount, parseNumericInput(raw.amount, 0))),
      netAmount: Math.max(0, parseNumericInput(raw.netAmount, parseNumericInput(raw.amount, 0))),
      cashAccountNo: toText(raw.cashAccountNo),
      cashAccountName: toText(raw.cashAccountName),
      lines,
      createdAt,
      updatedAt: Number(raw.updatedAt) > 0 ? Number(raw.updatedAt) : createdAt,
      sourceSalesPurchaseRecordId: toText(raw.sourceSalesPurchaseRecordId),
      sourceSalesPurchaseNumber: toText(raw.sourceSalesPurchaseNumber).toUpperCase(),
      receiptAmount: Math.max(0, parseNumericInput(raw.receiptAmount, 0)),
      paymentAmount: Math.max(0, parseNumericInput(raw.paymentAmount, 0)),
      cashMotionPickerCode: toText(raw.cashMotionPickerCode),
      commissionLabel: toText(raw.commissionLabel),
      commissionCode: toText(raw.commissionCode),
      commissionFeeAmount: Math.max(0, parseNumericInput(raw.commissionFeeAmount, 0))
    };
  }

  function isSalesPurchaseGeneratedEntryRecord(record){
    const safeRecord = record && typeof record === 'object' ? record : {};
    const safeId = toText(safeRecord.id);
    if(safeId.startsWith('entry-record-sales-purchase-')) return true;
    if(toText(safeRecord.sourceSalesPurchaseRecordId)) return true;
    if(toText(safeRecord.sourceSalesPurchaseNumber)) return true;
    return false;
  }

  function resolveSalesPurchaseLinkedEntryType(record, sourceTypeLookup = null){
    const safeRecord = record && typeof record === 'object' ? record : {};
    const directType = toText(safeRecord.type).toLowerCase();
    if(directType === 'sale' || directType === 'purchase') return directType;

    const sourceRecordId = toText(safeRecord.sourceSalesPurchaseRecordId);
    if(sourceRecordId && sourceTypeLookup instanceof Map){
      const mappedType = sourceTypeLookup.get(`id:${sourceRecordId}`);
      if(mappedType === 'sale' || mappedType === 'purchase') return mappedType;
    }

    const sourceNumber = toText(safeRecord.sourceSalesPurchaseNumber).toUpperCase();
    if(sourceNumber && sourceTypeLookup instanceof Map){
      const mappedType = sourceTypeLookup.get(`number:${sourceNumber}`);
      if(mappedType === 'sale' || mappedType === 'purchase') return mappedType;
    }

    if(/^SAL-/.test(sourceNumber)) return 'sale';
    if(/^PUR-/.test(sourceNumber)) return 'purchase';

    const idText = toText(safeRecord.id).toLowerCase();
    if(idText.includes('sp-sale')) return 'sale';
    if(idText.includes('sp-purchase')) return 'purchase';

    const searchableText = [
      safeRecord.summary,
      safeRecord.description,
      safeRecord.number,
      safeRecord.sourceSalesPurchaseNumber,
      ...(Array.isArray(safeRecord.lines) ? safeRecord.lines.flatMap((line) => [line?.description, line?.roleLabel]) : [])
    ].map((value) => toText(value)).join(' ');
    const normalized = normalizeLookupText(searchableText);
    const isLinkedRecord = isSalesPurchaseGeneratedEntryRecord(safeRecord);
    const hasSaleToken = normalized.includes('فاتوره مبيع') || normalized.includes('عمليه مبيع');
    const hasPurchaseToken = normalized.includes('فاتوره شراء') || normalized.includes('عمليه شراء');

    if(hasSaleToken || (isLinkedRecord && normalized.includes(' مبيع'))) return 'sale';
    if(hasPurchaseToken || (isLinkedRecord && normalized.includes(' شراء'))) return 'purchase';

    return '';
  }

  function applySalesPurchaseLinkedEntryTypes(records, sourceTypeLookup = null){
    const safeRecords = Array.isArray(records) ? records : [];
    return safeRecords.map((record) => {
      if(!isSalesPurchaseGeneratedEntryRecord(record)) return record;
      const resolvedType = resolveSalesPurchaseLinkedEntryType(record, sourceTypeLookup);
      if(resolvedType !== 'sale' && resolvedType !== 'purchase') return record;
      return { ...record, type: resolvedType };
    });
  }

  function resolveEntriesSourceVoucherType(record, typeMeta = null){
    const typeKey = toText(typeMeta?.key || record?.type).toLowerCase();
    if(typeKey === 'payment' || typeKey === 'receipt' || typeKey === 'journal' || typeKey === 'settlement' || typeKey === 'opening') return typeKey;
    return 'journal';
  }

  function resolveLedgerRowSourceTarget(record, typeMeta = null){
    const safeRecord = record && typeof record === 'object' ? record : {};
    const metaKey = toText(typeMeta?.key || safeRecord.type).toLowerCase();
    const sourceSalesPurchaseRecordId = toText(safeRecord.sourceSalesPurchaseRecordId);
    const sourceSalesPurchaseNumber = toText(safeRecord.sourceSalesPurchaseNumber).toUpperCase();
    const linkedSalesPurchaseType = metaKey === 'sale' || metaKey === 'purchase'
      ? metaKey
      : resolveSalesPurchaseLinkedEntryType(safeRecord);

    if(linkedSalesPurchaseType === 'sale' || linkedSalesPurchaseType === 'purchase'){
      const number = sourceSalesPurchaseNumber || toText(safeRecord.number).toUpperCase();
      return {
        sourceKind: 'sales-purchase',
        viewId: linkedSalesPurchaseType === 'sale' ? 'sales-purchase-sale' : 'sales-purchase-invoice',
        actionId: linkedSalesPurchaseType,
        recordId: sourceSalesPurchaseRecordId,
        number,
        label: linkedSalesPurchaseType === 'sale' ? 'فاتورة مبيع' : 'فاتورة شراء'
      };
    }

    const recordId = toText(safeRecord.id);
    const number = toText(safeRecord.number).toUpperCase();
    if(!recordId && !number) return null;

    const voucherType = resolveEntriesSourceVoucherType(safeRecord, typeMeta);
    return {
      sourceKind: 'entries-vouchers',
      viewId: 'entries-vouchers',
      voucherType,
      recordId,
      number,
      label: toText(typeMeta?.label) || 'قيد/سند'
    };
  }

  function buildSalesPurchaseSourceTypeLookup(records){
    const lookup = new Map();
    (Array.isArray(records) ? records : []).forEach((record) => {
      const type = record?.type === 'sale' ? 'sale' : (record?.type === 'purchase' ? 'purchase' : '');
      if(!type) return;
      const id = toText(record?.id);
      const number = toText(record?.number).toUpperCase();
      if(id) lookup.set(`id:${id}`, type);
      if(number) lookup.set(`number:${number}`, type);
    });
    return lookup;
  }

  function normalizeSalesPurchaseLedgerSourceRecord(record, index = 0){
    const safeRecord = record && typeof record === 'object' ? record : {};
    const createdAt = Number(safeRecord.createdAt);
    const updatedAt = Number(safeRecord.updatedAt);
    const sequence = Math.max(0, Number(safeRecord.sequence) || 0);
    const amountValue = Math.max(0, parseNumericInput(safeRecord.amountValue, 0));
    const counterpartAmountValue = Math.max(0, parseNumericInput(safeRecord.counterpartAmountValue, 0));
    const rateValue = Math.max(0, parseNumericInput(safeRecord.rateValue, 0));
    const revisionCount = Math.max(0, Number(safeRecord.revisionCount) || 0);
    const lastActionRaw = toText(safeRecord.lastAction).toLowerCase();
    const status = String(safeRecord.status || '').trim() === 'reversed'
      ? 'reversed'
      : (String(safeRecord.status || '').trim() === 'draft' ? 'draft' : 'posted');
    return {
      id: toText(safeRecord.id) || `gl-sp-${Date.now()}-${index + 1}`,
      number: toText(safeRecord.number).toUpperCase(),
      type: String(safeRecord.type || '').trim() === 'sale' ? 'sale' : 'purchase',
      status,
      date: sanitizeDate(safeRecord.date),
      dateKey: parseDateKey(safeRecord.date) || timestampToDateKey(createdAt),
      createdAt: Number.isFinite(createdAt) && createdAt > 0 ? createdAt : (Date.now() + index),
      updatedAt: Number.isFinite(updatedAt) && updatedAt > 0 ? updatedAt : (Number.isFinite(createdAt) && createdAt > 0 ? createdAt : Date.now()),
      sequence,
      cashAccountNo: toText(safeRecord.cashAccountNo),
      cashAccountName: toText(safeRecord.cashAccountName),
      tradeCurrencyCode: normalizeCurrencyCode(safeRecord.tradeCurrencyCode),
      tradeCurrencyName: toText(safeRecord.tradeCurrencyName),
      settlementCurrencyCode: normalizeCurrencyCode(safeRecord.settlementCurrencyCode),
      settlementCurrencyName: toText(safeRecord.settlementCurrencyName),
      amountValue,
      counterpartAmountValue,
      rateValue: rateValue > 0 ? rateValue : (amountValue > GENERAL_LEDGER_AMOUNT_EPSILON && counterpartAmountValue > GENERAL_LEDGER_AMOUNT_EPSILON
        ? (counterpartAmountValue / amountValue)
        : 0),
      rateText: toText(safeRecord.rateText),
      notes: toText(safeRecord.notes),
      counterpartyName: toText(safeRecord.counterpartyName),
      revisionCount,
      lastAction: status === 'reversed'
        ? 'reversed'
        : (lastActionRaw === 'updated'
            ? 'updated'
            : (lastActionRaw === 'created' ? 'created' : (revisionCount > 0 ? 'updated' : 'created'))),
      accountingBridgeAccountNo: toText(safeRecord.accountingBridgeAccountNo),
      accountingBridgeAccountName: toText(safeRecord.accountingBridgeAccountName)
    };
  }

  function normalizeSalesPurchaseLedgerState(stateInput){
    const safeState = stateInput && typeof stateInput === 'object' ? stateInput : {};
    const records = (Array.isArray(safeState.records) ? safeState.records : [])
      .map((record, index) => normalizeSalesPurchaseLedgerSourceRecord(record, index))
      .sort((left, right) => {
        const createdDelta = (Number(right.createdAt) || 0) - (Number(left.createdAt) || 0);
        if(createdDelta) return createdDelta;
        const updatedDelta = (Number(right.updatedAt) || 0) - (Number(left.updatedAt) || 0);
        if(updatedDelta) return updatedDelta;
        return String(right.number || '').localeCompare(String(left.number || ''), 'en', { numeric:true, sensitivity:'base' });
      });
    return {
      version: 1,
      records
    };
  }

  function buildSalesPurchaseOperationLabel(record){
    const safeRecord = record && typeof record === 'object' ? record : {};
    if(safeRecord.status === 'reversed') return 'إلغاء / عكس القيد';
    if(toText(safeRecord.lastAction) === 'updated'){
      const revisionCount = Math.max(0, Number(safeRecord.revisionCount) || 0);
      return revisionCount > 0 ? `تعديل الفاتورة (${revisionCount})` : 'تعديل الفاتورة';
    }
    return 'إنشاء الفاتورة';
  }

  function resolveSalesPurchaseBridgeAccount(record, catalog = readAccounts()){
    const safeCatalog = Array.isArray(catalog) ? catalog : [];
    const safeCashAccountNo = toText(record?.cashAccountNo);
    const exactNameMatchers = [
      'حسابات القطع الأجنبي',
      'حسابات القطع الاجنبي',
      'حسابات القطع',
      'القطع الأجنبي',
      'القطع الاجنبي'
    ].map((value) => normalizeLookupText(value));
    const keywordMatchers = ['حسابات القطع', 'القطع الاجنبي', 'القطع الأجنبي', 'قطع اجنبي', 'قطع أجنبي', 'صرف'].map((value) => normalizeLookupText(value));

    const explicitAccountNo = toText(record?.accountingBridgeAccountNo);
    const explicitAccountName = normalizeLookupText(record?.accountingBridgeAccountName);
    if(explicitAccountNo){
      const explicitAccount = safeCatalog.find((account) => toText(account?.accountNo) === explicitAccountNo && explicitAccountNo !== safeCashAccountNo) || null;
      const explicitNormalizedName = normalizeLookupText(explicitAccount?.name || explicitAccountName);
      const explicitLooksLikeBridge = explicitAccountNo === '005'
        || (!!explicitNormalizedName && exactNameMatchers.includes(explicitNormalizedName))
        || (!!explicitNormalizedName && keywordMatchers.some((keyword) => explicitNormalizedName.includes(keyword)));
      if(explicitAccount && explicitLooksLikeBridge) return explicitAccount;
      if(!explicitAccount && explicitLooksLikeBridge){
        return { accountNo: explicitAccountNo, name: toText(record?.accountingBridgeAccountName) || explicitAccountNo };
      }
    }

    const exactMatch = safeCatalog.find((account) => {
      if(!account || toText(account.accountNo) === safeCashAccountNo) return false;
      const normalizedName = normalizeLookupText(account.name);
      return !!normalizedName && exactNameMatchers.includes(normalizedName);
    }) || null;
    if(exactMatch) return exactMatch;

    const canonicalMatch = safeCatalog.find((account) => toText(account?.accountNo) === '005' && toText(account?.accountNo) !== safeCashAccountNo) || null;
    if(canonicalMatch) return canonicalMatch;

    return safeCatalog.find((account) => {
      if(!account || toText(account.accountNo) === safeCashAccountNo) return false;
      const normalizedName = normalizeLookupText(account.name);
      return keywordMatchers.some((keyword) => normalizedName.includes(keyword));
    }) || null;
  }

  function buildSalesPurchaseLedgerLegs(record){
    const safeRecord = record && typeof record === 'object' ? record : {};
    return [
      {
        kind: 'trade',
        currencyCode: normalizeCurrencyCode(safeRecord.tradeCurrencyCode),
        currencyName: toText(safeRecord.tradeCurrencyName) || normalizeCurrencyCode(safeRecord.tradeCurrencyCode),
        amount: Math.max(0, parseNumericInput(safeRecord.amountValue, 0)),
        cashSide: safeRecord.type === 'purchase' ? 'debit' : 'credit'
      },
      {
        kind: 'settlement',
        currencyCode: normalizeCurrencyCode(safeRecord.settlementCurrencyCode),
        currencyName: toText(safeRecord.settlementCurrencyName) || normalizeCurrencyCode(safeRecord.settlementCurrencyCode),
        amount: Math.max(0, parseNumericInput(safeRecord.counterpartAmountValue, 0)),
        cashSide: safeRecord.type === 'sale' ? 'debit' : 'credit'
      }
    ].filter((leg) => leg.currencyCode && leg.amount > GENERAL_LEDGER_AMOUNT_EPSILON);
  }


  function resolveSalesPurchaseLedgerPostingTargets(record, leg, bridgeAccount){
    const safeRecord = record && typeof record === 'object' ? record : {};
    const safeLeg = leg && typeof leg === 'object' ? leg : {};
    const safeBridgeAccount = bridgeAccount && typeof bridgeAccount === 'object' ? bridgeAccount : {};
    const primaryAccountNo = toText(safeRecord.cashAccountNo);
    const primaryAccountName = toText(safeRecord.cashAccountName);
    const counterpartAccountNo = toText(safeBridgeAccount.accountNo);
    const counterpartAccountName = toText(safeBridgeAccount.name);
    const isPrimaryDebit = safeLeg.cashSide !== 'credit';
    const primaryLabelBase = primaryAccountName || 'الصندوق النقدي';
    const counterpartLabelBase = counterpartAccountName || 'حسابات القطع الأجنبي';
    return {
      primaryAccountNo,
      primaryAccountName,
      counterpartAccountNo,
      counterpartAccountName,
      isPrimaryDebit,
      primaryRoleLabel: `${isPrimaryDebit ? 'زيادة' : 'تخفيض'} ${primaryLabelBase}`,
      counterpartRoleLabel: `${counterpartLabelBase} ${isPrimaryDebit ? 'دائن' : 'مدين'}`
    };
  }

  function describeSalesPurchaseLedgerLeg(record, leg){
    const safeRecord = record && typeof record === 'object' ? record : {};
    const safeLeg = leg && typeof leg === 'object' ? leg : {};
    const operationLabel = safeRecord.type === 'sale' ? 'مبيع' : 'شراء';
    const referenceSuffix = safeRecord.number ? ` - ${safeRecord.number}` : '';
    if(safeRecord.type === 'purchase'){
      return safeLeg.kind === 'trade'
        ? `${operationLabel} ${safeLeg.currencyName}${referenceSuffix}`
        : `دفع ${safeLeg.currencyName}${referenceSuffix}`;
    }
    return safeLeg.kind === 'trade'
      ? `${operationLabel} ${safeLeg.currencyName}${referenceSuffix}`
      : `قبض ${safeLeg.currencyName}${referenceSuffix}`;
  }

  function createSyntheticLedgerRecordFromSalesPurchaseLeg(record, leg, bridgeAccount, index = 0){
    const safeRecord = record && typeof record === 'object' ? record : {};
    const safeLeg = leg && typeof leg === 'object' ? leg : {};
    const amount = Math.max(0, Number(safeLeg.amount) || 0);
    const description = describeSalesPurchaseLedgerLeg(safeRecord, safeLeg);
    const lineDescription = safeRecord.notes ? `${description} | ${safeRecord.notes}` : description;
    const summaryParts = [
      `${safeRecord.type === 'sale' ? 'فاتورة مبيع' : 'فاتورة شراء'} ${safeRecord.tradeCurrencyCode}/${safeRecord.settlementCurrencyCode}`.trim(),
      buildSalesPurchaseOperationLabel(safeRecord),
      safeRecord.rateText && safeRecord.rateText !== '—' ? `سعر الصرف: ${safeRecord.rateText}` : '',
      safeRecord.notes
    ].filter(Boolean);
    const targets = resolveSalesPurchaseLedgerPostingTargets(safeRecord, safeLeg, bridgeAccount);
    const isPrimaryDebit = targets.isPrimaryDebit;
    const counterpartDescription = `${toText(targets.counterpartAccountName) || 'الحساب المقابل'} ${safeLeg.currencyName}`;
    return normalizeRecord({
      id: `gl-sales-purchase-${safeRecord.id}-${index + 1}`,
      type: safeRecord.type === 'sale' ? 'sale' : 'purchase',
      number: safeRecord.number,
      status: safeRecord.status,
      date: safeRecord.date,
      description: lineDescription,
      summary: summaryParts.join(' | '),
      counterpartAccountNo: toText(targets.counterpartAccountNo),
      counterpartAccountName: toText(targets.counterpartAccountName),
      beneficiaryName: toText(safeRecord.counterpartyName),
      partyName: toText(safeRecord.counterpartyName),
      currency: safeLeg.currencyCode,
      amount,
      grossAmount: amount,
      netAmount: amount,
      cashAccountNo: safeRecord.cashAccountNo,
      cashAccountName: safeRecord.cashAccountName,
      lines: [
        {
          lineNo: 1,
          roleKey: safeLeg.kind === 'trade' ? 'bridge' : 'cash',
          roleLabel: toText(targets.primaryRoleLabel),
          accountNo: toText(targets.primaryAccountNo),
          accountName: toText(targets.primaryAccountName),
          description: lineDescription,
          debit: isPrimaryDebit ? amount : 0,
          credit: isPrimaryDebit ? 0 : amount,
          side: isPrimaryDebit ? 'debit' : 'credit',
          amount
        },
        {
          lineNo: 2,
          roleKey: safeLeg.kind === 'trade' ? 'cash' : 'bridge',
          roleLabel: toText(targets.counterpartRoleLabel),
          accountNo: toText(targets.counterpartAccountNo),
          accountName: toText(targets.counterpartAccountName),
          description: counterpartDescription,
          debit: isPrimaryDebit ? 0 : amount,
          credit: isPrimaryDebit ? amount : 0,
          side: isPrimaryDebit ? 'credit' : 'debit',
          amount
        }
      ],
      receiptAmount: safeLeg.kind === 'settlement' && isPrimaryDebit ? amount : 0,
      paymentAmount: safeLeg.kind === 'settlement' && !isPrimaryDebit ? amount : 0,
      cashMotionPickerCode: safeLeg.kind === 'settlement' ? (isPrimaryDebit ? 'cash-in-box' : 'cash-out-box') : 'journal',
      sourceSalesPurchaseRecordId: toText(safeRecord.id),
      sourceSalesPurchaseNumber: toText(safeRecord.number).toUpperCase(),
      createdAt: safeRecord.createdAt - index,
      updatedAt: safeRecord.updatedAt
    }, index);
  }

  function hasPersistedSalesPurchaseEntryRecord(record, entryRecords = []){
    const safeRecordId = toText(record?.id);
    const safeRecordNumber = toText(record?.number).toUpperCase();
    const safeEntryRecords = Array.isArray(entryRecords) ? entryRecords : [];
    return safeEntryRecords.some((entryRecord) => {
      if(!isSalesPurchaseGeneratedEntryRecord(entryRecord)) return false;
      const sourceRecordId = toText(entryRecord?.sourceSalesPurchaseRecordId);
      const sourceNumber = toText(entryRecord?.sourceSalesPurchaseNumber).toUpperCase();
      return (!!safeRecordId && sourceRecordId === safeRecordId)
        || (!!safeRecordNumber && sourceNumber === safeRecordNumber);
    });
  }

  function readSalesPurchaseLedgerSourceState(){
    const salesPurchaseDomain = resolveDomainAdapter('sales-purchase') || {};
    const salesPurchaseApi = TAIF.salesPurchaseInvoice || {};
    const sourceState = typeof salesPurchaseDomain.readState === 'function'
      ? salesPurchaseDomain.readState()
      : (typeof salesPurchaseApi.readState === 'function'
          ? salesPurchaseApi.readState()
          : readJsonStorage(SALES_PURCHASE_STORAGE_KEY, null));
    return normalizeSalesPurchaseLedgerState(sourceState);
  }

  function readSalesPurchaseLedgerRecords(entryRecords = [], sourceState = null){
    const state = sourceState && typeof sourceState === 'object'
      ? sourceState
      : readSalesPurchaseLedgerSourceState();
    const accounts = readAccounts();
    return (Array.isArray(state.records) ? state.records : [])
      .filter((record) => !hasPersistedSalesPurchaseEntryRecord(record, entryRecords))
      .flatMap((record, recordIndex) => {
        const bridgeAccount = resolveSalesPurchaseBridgeAccount(record, accounts)
          || { accountNo: toText(record.accountingBridgeAccountNo), name: toText(record.accountingBridgeAccountName) };
        const legs = buildSalesPurchaseLedgerLegs(record);
        return legs.map((leg, legIndex) => createSyntheticLedgerRecordFromSalesPurchaseLeg(record, leg, bridgeAccount, (recordIndex * 10) + legIndex));
      });
  }

  function normalizeEntriesState(input){
    const raw = input && typeof input === 'object' ? input : {};
    const records = (Array.isArray(raw.records) ? raw.records : [])
      .map((record, index) => normalizeRecord(record, index))
      .sort((left, right) => {
        const createdDelta = (Number(right.createdAt) || 0) - (Number(left.createdAt) || 0);
        if(createdDelta) return createdDelta;
        const updatedDelta = (Number(right.updatedAt) || 0) - (Number(left.updatedAt) || 0);
        if(updatedDelta) return updatedDelta;
        return toText(right.number).localeCompare(toText(left.number), 'en', { numeric:true });
      });

    return {
      version: 1,
      updatedAt: Number(raw.updatedAt) > 0 ? Number(raw.updatedAt) : Date.now(),
      records
    };
  }

  function readLegacyEntryRecords(){
    const domain = resolveDomainAdapter('entries') || TAIF.entriesVouchersDomain || {};
    const rawEntryRecords = typeof domain.getRecords === 'function'
      ? domain.getRecords()
      : (typeof domain.readState === 'function'
          ? normalizeEntriesState(domain.readState()).records
          : normalizeEntriesState(readJsonStorage(ENTRIES_STORAGE_KEY, null)).records);
    return Array.isArray(rawEntryRecords)
      ? rawEntryRecords.map((record, index) => normalizeRecord(record, index))
      : [];
  }

  function readServiceEntryRecords(){
    const ledgerService = resolveService('ledger-service');
    if(!ledgerService || typeof ledgerService.buildReadModel !== 'function') return null;
    try{
      const readModel = ledgerService.buildReadModel({ cache:false });
      const records = Array.isArray(readModel?.records) ? readModel.records : null;
      return Array.isArray(records) ? records.map((record, index) => normalizeRecord(record, index)) : null;
    }catch{
      return null;
    }
  }

  function resolveEntryRecordsForLedger(){
    const legacyEntryRecords = readLegacyEntryRecords();
    const serviceEntryRecords = readServiceEntryRecords();
    if(Array.isArray(serviceEntryRecords) && serviceEntryRecords.length === legacyEntryRecords.length){
      return serviceEntryRecords;
    }
    return legacyEntryRecords;
  }

  function readEntryRecords(){
    const salesPurchaseSourceState = readSalesPurchaseLedgerSourceState();
    const salesPurchaseTypeLookup = buildSalesPurchaseSourceTypeLookup(salesPurchaseSourceState.records);
    const normalizedEntryRecords = applySalesPurchaseLinkedEntryTypes(resolveEntryRecordsForLedger(), salesPurchaseTypeLookup);
    const salesPurchaseRecords = readSalesPurchaseLedgerRecords(normalizedEntryRecords, salesPurchaseSourceState);
    return normalizeEntriesState({
      records: [...normalizedEntryRecords, ...salesPurchaseRecords]
    }).records;
  }

  function readAccounts(){
    const accountsDomain = resolveDomainAdapter('accounts');
    if(accountsDomain && typeof accountsDomain.readCatalog === 'function'){
      const catalog = accountsDomain.readCatalog();
      if(Array.isArray(catalog) && catalog.length) return normalizeAccountCatalog(catalog, toText);
    }
    const source = readChartAccountCatalogSource(ACCOUNT_STORAGE_KEY, readJsonStorage);
    const normalized = normalizeAccountCatalog(source, toText);
    return normalized.length ? normalized : DEFAULT_LEDGER_ACCOUNT_CATALOG.slice();
  }

  function resolveTypeMeta(record){
    const directType = toText(record?.type).toLowerCase();
    if(directType === 'sale') return TYPE_META.sale;
    if(directType === 'purchase') return TYPE_META.purchase;

    const linkedType = resolveSalesPurchaseLinkedEntryType(record);
    if(linkedType === 'sale') return TYPE_META.sale;
    if(linkedType === 'purchase') return TYPE_META.purchase;

    const summary = sanitizeSearch(record?.summary);
    const description = sanitizeSearch(record?.description);
    const hasAnyText = (...tokens) => tokens.some((token) => summary.includes(token) || description.includes(token));
    if(hasAnyText('فاتورة مبيع', 'عملية مبيع')) return TYPE_META.sale;
    if(hasAnyText('فاتورة شراء', 'عملية شراء')) return TYPE_META.purchase;
    return TYPE_META[directType] || TYPE_META.journal;
  }

  function matchesOperationFilter(row, operationTypes){
    const preserveEmptyArray = Array.isArray(operationTypes) && operationTypes.length === 0;
    const safeOperationTypes = sanitizeOperationTypes(operationTypes, { preserveEmptyArray });
    if(!safeOperationTypes.length) return false;
    const rowType = toText(row?.type);
    return safeOperationTypes.includes(rowType);
  }

  function matchesCurrencyFilter(row, currencySelections){
    const preserveEmptyArray = Array.isArray(currencySelections) && currencySelections.length === 0;
    const safeCurrencySelections = sanitizeCurrencySelections(currencySelections, { preserveEmptyArray });
    if(!safeCurrencySelections.length) return false;
    if(safeCurrencySelections.includes('all')) return true;
    const rowCurrency = normalizeCurrencyCode(row?.currency) || 'USD';
    return safeCurrencySelections.includes(rowCurrency);
  }

  function normalizeLookupText(value){
    return String(value ?? '')
      .trim()
      .toLowerCase()
      .replace(/[ً-ٰٟ]/g, '')
      .replace(/[أإآٱ]/g, 'ا')
      .replace(/ة/g, 'ه')
      .replace(/ى/g, 'ي')
      .replace(/ؤ/g, 'و')
      .replace(/ئ/g, 'ي')
      .replace(/ـ/g, '')
      .replace(/[^a-z0-9؀-ۿ\s]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function parseDateKey(value){
    const safe = sanitizeDate(value);
    if(!safe) return 0;
    return Number(safe.replace(/-/g, '')) || 0;
  }

  function timestampToDateKey(value){
    const timestamp = Number(value);
    if(!Number.isFinite(timestamp) || timestamp <= 0) return 0;
    const date = new Date(timestamp);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return Number(`${year}${month}${day}`) || 0;
  }

  function compareRows(left, right){
    const dateDelta = (Number(left.dateSort) || 0) - (Number(right.dateSort) || 0);
    if(dateDelta) return dateDelta;
    const createdDelta = (Number(left.createdAt) || 0) - (Number(right.createdAt) || 0);
    if(createdDelta) return createdDelta;
    const numberDelta = String(left.number || '').localeCompare(String(right.number || ''), 'en', { numeric:true, sensitivity:'base' });
    if(numberDelta) return numberDelta;
    const lineDelta = (Number(left.lineNo) || 0) - (Number(right.lineNo) || 0);
    if(lineDelta) return lineDelta;
    return String(left.id || '').localeCompare(String(right.id || ''), 'en', { numeric:true, sensitivity:'base' });
  }

  function formatDate(value){
    const safe = sanitizeDate(value);
    if(!safe) return '—';
    const [year, month, day] = safe.split('-');
    return `${day}/${month}/${year}`;
  }

  function formatNumber(value){
    const numeric = Number(value);
    if(!Number.isFinite(numeric)) return '0';
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2
    }).format(Math.abs(numeric));
  }

  function formatAmountWithCurrency(value, currencyCode){
    const safeCurrency = normalizeCurrencyCode(currencyCode) || 'USD';
    return `${formatNumber(value)} ${safeCurrency}`;
  }

  function resolveBalanceDirection(amount){
    const numeric = Number(amount) || 0;
    if(Math.abs(numeric) < 1e-9) return 'zero';
    return numeric >= 0 ? 'debit' : 'credit';
  }

  function formatBalanceText(amount, currencyCode){
    const direction = resolveBalanceDirection(amount);
    if(direction === 'zero') return formatAmountWithCurrency(0, currencyCode);
    const sign = direction === 'debit' ? '+' : '-';
    return `${sign} ${formatAmountWithCurrency(amount, currencyCode)}`;
  }

  function resolveCounterpartText(record, matchingLine){
    const otherLines = (Array.isArray(record?.lines) ? record.lines : [])
      .filter((line) => line && String(line.accountNo || '').trim() && String(line.accountNo || '').trim() !== String(matchingLine?.accountNo || '').trim())
      .map((line) => `${toText(line.accountName) || 'بدون اسم'}${toText(line.accountNo) ? ` · ${toText(line.accountNo)}` : ''}`);
    const unique = Array.from(new Set(otherLines.filter(Boolean)));
    if(unique.length) return unique.join(' + ');
    const fallbackParts = [
      toText(record?.counterpartAccountName),
      toText(record?.counterpartAccountNo),
      toText(record?.cashAccountName),
      toText(record?.cashAccountNo),
      toText(record?.partyName),
      toText(record?.beneficiaryName)
    ].filter(Boolean);
    return fallbackParts.length ? fallbackParts.join(' · ') : '—';
  }

  function resolveDescription(record, line){
    return toText(line?.description) || toText(record?.description) || toText(record?.summary) || 'بدون بيان';
  }

  function resolveAuditLabel(record){
    const safeStatus = toText(record?.status);
    const safeSummary = toText(record?.summary);
    if(safeStatus === 'reversed') return 'فاتورة ملغاة / معكوسة';
    if(safeSummary.includes('تعديل الفاتورة')) return 'فاتورة معدلة';
    return '';
  }

  function statusLabel(status){
    const safeStatus = toText(status);
    if(safeStatus === 'reversed') return 'ملغى / معكوس';
    if(safeStatus === 'draft') return 'مسودة';
    if(safeStatus === 'opening') return 'افتتاحي';
    return 'معتمد';
  }

  function decorateNonPostedLedgerRow(row, runningBalance){
    const safeRow = row && typeof row === 'object' ? row : {};
    const safeStatus = toText(safeRow.status);
    const statusText = statusLabel(safeStatus);
    const currentBalance = Number(runningBalance) || 0;
    const nextSummaryParts = [
      safeStatus === 'reversed' ? 'قيد ملغى / معكوس — غير محتسب في الرصيد' : `الحالة: ${statusText}`,
      toText(safeRow.summary)
    ].filter(Boolean);
    return {
      ...safeRow,
      statusLabel: statusText,
      summary: nextSummaryParts.join(' | '),
      runningBalance: currentBalance,
      runningSide: resolveBalanceDirection(currentBalance),
      runningBalanceText: formatBalanceText(currentBalance, safeRow.currency || 'USD'),
      balanceClass: resolveBalanceDirection(currentBalance) === 'credit'
        ? 'is-credit'
        : (resolveBalanceDirection(currentBalance) === 'debit' ? 'is-debit' : 'is-zero')
    };
  }

  function buildSourceRowsForAccount(record, accountNo){
    const safeAccountNo = toText(accountNo);
    if(!safeAccountNo) return [];
    const typeMeta = resolveTypeMeta(record);
    const recordCurrency = normalizeCurrencyCode(record?.currency) || 'USD';
    const dateKey = parseDateKey(record?.date) || timestampToDateKey(record?.createdAt);

    return (Array.isArray(record?.lines) ? record.lines : [])
      .map((line, lineIndex) => normalizeLine(line, lineIndex))
      .filter((line) => toText(line.accountNo) === safeAccountNo && (Number(line.debit) > 0 || Number(line.credit) > 0))
      .map((line, lineIndex) => ({
        id: `${toText(record?.id) || `row-${dateKey}`}-${line.lineNo}-${lineIndex + 1}`,
        kind: 'movement',
        recordId: toText(record?.id),
        number: toText(record?.number),
        type: toText(typeMeta.key),
        typeLabel: toText(typeMeta.label) || 'سند',
        typeBadgeClass: toText(typeMeta.badgeClass),
        status: toText(record?.status) || 'posted',
        date: sanitizeDate(record?.date),
        dateLabel: formatDate(record?.date),
        dateSort: dateKey,
        createdAt: Number(record?.createdAt) || 0,
        updatedAt: Number(record?.updatedAt) || Number(record?.createdAt) || 0,
        lineNo: Number(line.lineNo) || lineIndex + 1,
        description: resolveDescription(record, line),
        summary: toText(record?.summary),
        counterpartText: resolveCounterpartText(record, line),
        debit: Math.max(0, Number(line.debit) || 0),
        credit: Math.max(0, Number(line.credit) || 0),
        currency: recordCurrency,
        referenceLabel: toText(record?.number) || '—',
        searchText: normalizeLookupText([
          record?.number,
          record?.description,
          record?.summary,
          line?.description,
          line?.accountName,
          line?.accountNo,
          resolveCounterpartText(record, line),
          record?.partyName,
          record?.beneficiaryName,
          recordCurrency,
          typeMeta?.label
        ].filter(Boolean).join(' ')),
        accountNo: safeAccountNo,
        accountName: toText(line?.accountName),
        auditLabel: resolveAuditLabel(record),
        sourceTarget: resolveLedgerRowSourceTarget(record, typeMeta),
        rawRecord: clone(record)
      }));
  }

  function accumulateCurrencyMap(targetMap, currencyCode, amount){
    const safeCurrency = normalizeCurrencyCode(currencyCode) || 'USD';
    const numeric = Number(amount) || 0;
    if(!numeric && !Object.prototype.hasOwnProperty.call(targetMap, safeCurrency)) return targetMap;
    targetMap[safeCurrency] = (Number(targetMap[safeCurrency]) || 0) + numeric;
    if(Math.abs(targetMap[safeCurrency]) < 1e-9) targetMap[safeCurrency] = 0;
    return targetMap;
  }

  function createOpeningRows(openingByCurrency, filters = {}){
    const currencies = Object.keys(openingByCurrency || {}).filter((code) => Math.abs(Number(openingByCurrency[code]) || 0) > 1e-9).sort();
    if(!currencies.length) return [];

    return currencies.map((currencyCode, index) => {
      const balance = Number(openingByCurrency[currencyCode]) || 0;
      return {
        id: `opening-${currencyCode}-${index + 1}`,
        kind: 'opening',
        number: '',
        type: 'opening-balance',
        typeLabel: 'رصيد افتتاحي',
        typeBadgeClass: 'general-ledger-badge--muted',
        status: 'opening',
        date: '',
        dateLabel: filters.dateFrom ? `قبل ${formatDate(filters.dateFrom)}` : 'رصيد مرحّل',
        dateSort: Number.MIN_SAFE_INTEGER + index,
        createdAt: 0,
        updatedAt: 0,
        lineNo: index + 1,
        description: `رصيد أول المدة${filters.dateFrom ? ` حتى ${formatDate(filters.dateFrom)}` : ''}`,
        summary: '',
        counterpartText: '—',
        debit: 0,
        credit: 0,
        currency: currencyCode,
        referenceLabel: '—',
        searchText: '',
        runningBalance: balance,
        runningSide: resolveBalanceDirection(balance),
        runningBalanceText: formatBalanceText(balance, currencyCode),
        balanceClass: resolveBalanceDirection(balance) === 'credit'
          ? 'is-credit'
          : (resolveBalanceDirection(balance) === 'debit' ? 'is-debit' : 'is-zero')
      };
    });
  }

  function mapCurrencySummary(metricMap, formatter){
    const safeFormatter = typeof formatter === 'function' ? formatter : ((amount, currencyCode) => formatBalanceText(amount, currencyCode));
    return Object.keys(metricMap || {})
      .sort()
      .map((currencyCode) => ({
        currency: currencyCode,
        value: Number(metricMap[currencyCode]) || 0,
        text: safeFormatter(metricMap[currencyCode], currencyCode)
      }));
  }

  function readCurrencyCatalogOptions(){
    const domain = getCurrencyDomain();
    let currencies = [];

    try{
      const state = domain && typeof domain.readState === 'function' ? domain.readState() : null;
      currencies = Array.isArray(state?.currencies) ? state.currencies : [];
    }catch{}

    if(!currencies.length && Array.isArray(domain?.DEFAULT_CURRENCIES)){
      currencies = domain.DEFAULT_CURRENCIES;
    }

    return currencies
      .map((currency) => {
        const code = normalizeCurrencyCode(currency?.code);
        return code ? { value: code, label: code } : null;
      })
      .filter(Boolean);
  }

  function buildCurrencyOptions(records){
    const orderedCodes = [];
    const seenCodes = new Set();
    const appendCode = (value) => {
      const code = normalizeCurrencyCode(value);
      if(!code || seenCodes.has(code)) return;
      seenCodes.add(code);
      orderedCodes.push(code);
    };

    readCurrencyCatalogOptions().forEach((option) => {
      appendCode(option?.value || option?.code);
    });

    const recordOnlyCodes = [];
    (Array.isArray(records) ? records : []).forEach((record) => {
      const code = normalizeCurrencyCode(record?.currency);
      if(!code || seenCodes.has(code)) return;
      recordOnlyCodes.push(code);
    });

    recordOnlyCodes.sort().forEach(appendCode);
    return orderedCodes.map((code) => ({ value: code, label: code }));
  }

  function getCurrencyDomain(){
    const domain = resolveDomainAdapter('currency') || TAIF.currencyDomain || TAIF.currencyManagement || null;
    return domain && typeof domain === 'object' ? domain : null;
  }

  function readCurrencyState(){
    const domain = getCurrencyDomain();
    if(!domain || typeof domain.readState !== 'function') return null;
    try{ return domain.readState(); }catch{ return null; }
  }

  function getSystemCurrencyCode(){
    const state = readCurrencyState();
    return normalizeCurrencyCode(state?.systemCurrencyCode) || 'USD';
  }

  function getPositiveExchangeRate(value, fallback = 0){
    const numeric = parseNumericInput(value, fallback);
    return Number.isFinite(numeric) && numeric > 0 ? numeric : Math.max(0, Number(fallback) || 0);
  }

  function normalizeUsdConvention(value, fallbackMethod = 'multiply'){
    const raw = String(value ?? '').trim().toLowerCase();
    if(raw === 'usd-base' || raw === 'usdbase' || raw === 'usd_per_currency') return 'usd-base';
    if(raw === 'currency-base' || raw === 'currencybase' || raw === 'currency_per_usd') return 'currency-base';
    return String(fallbackMethod || '').trim().toLowerCase() === 'divide' ? 'usd-base' : 'currency-base';
  }

  function readCurrencyCatalogEntries(stateInput = null){
    const state = stateInput && typeof stateInput === 'object' ? stateInput : readCurrencyState();
    if(state && Array.isArray(state.currencies)) return state.currencies;
    const domain = getCurrencyDomain();
    if(Array.isArray(domain?.DEFAULT_CURRENCIES)) return domain.DEFAULT_CURRENCIES;
    if(Array.isArray(TAIF?.currencyManagementFeature?.DEFAULT_CURRENCIES)) return TAIF.currencyManagementFeature.DEFAULT_CURRENCIES;
    return [];
  }

  function findCurrencyCatalogEntry(stateInput, currencyCode){
    const safeCurrencyCode = normalizeCurrencyCode(currencyCode);
    if(!safeCurrencyCode) return null;
    return readCurrencyCatalogEntries(stateInput).find((currency) => normalizeCurrencyCode(currency?.code) === safeCurrencyCode) || null;
  }

  function resolveCurrencyUsdSystemRateFromState(stateInput, currencyCode){
    const safeCurrencyCode = normalizeCurrencyCode(currencyCode);
    if(!safeCurrencyCode) return 0;
    if(safeCurrencyCode === 'USD') return 1;

    const currency = findCurrencyCatalogEntry(stateInput, safeCurrencyCode);
    if(!currency) return 0;
    const buy = getPositiveExchangeRate(currency.ratioBuy ?? currency.buy, 0);
    const sell = getPositiveExchangeRate(currency.ratioSell ?? currency.sell, buy);
    const bid = Math.min(buy, sell || buy);
    const ask = Math.max(buy, sell || buy);
    const middle = bid > 0 && ask > 0 ? ((bid + ask) / 2) : 0;
    if(!(middle > 0)) return 0;

    const convention = normalizeUsdConvention(currency.usdConvention, currency.method);
    return convention === 'usd-base' ? (1 / middle) : middle;
  }

  function resolveCurrencyRateDisplayConvention(stateInput, currencyCode, systemCurrencyCode){
    const safeCurrencyCode = normalizeCurrencyCode(currencyCode);
    const safeSystemCurrencyCode = normalizeCurrencyCode(systemCurrencyCode) || 'USD';
    if(!safeCurrencyCode || safeCurrencyCode === safeSystemCurrencyCode) return 'identity';

    if(safeSystemCurrencyCode === 'USD'){
      const currency = findCurrencyCatalogEntry(stateInput, safeCurrencyCode);
      return normalizeUsdConvention(currency?.usdConvention, currency?.method);
    }

    if(safeCurrencyCode === 'USD'){
      const systemCurrency = findCurrencyCatalogEntry(stateInput, safeSystemCurrencyCode);
      const systemConvention = normalizeUsdConvention(systemCurrency?.usdConvention, systemCurrency?.method);
      return systemConvention === 'usd-base' ? 'currency-base' : 'usd-base';
    }

    const currency = findCurrencyCatalogEntry(stateInput, safeCurrencyCode);
    return normalizeUsdConvention(currency?.usdConvention, currency?.method);
  }

  function resolveDisplayRatePairLabel(currencyCode, systemCurrencyCode, stateInput = null){
    const safeCurrencyCode = normalizeCurrencyCode(currencyCode);
    const safeSystemCurrencyCode = normalizeCurrencyCode(systemCurrencyCode) || 'USD';
    if(!safeCurrencyCode) return '';
    if(safeCurrencyCode === safeSystemCurrencyCode) return `${safeSystemCurrencyCode}/${safeSystemCurrencyCode}`;

    const state = stateInput && typeof stateInput === 'object' ? stateInput : readCurrencyState();
    const convention = resolveCurrencyRateDisplayConvention(state, safeCurrencyCode, safeSystemCurrencyCode);
    return convention === 'usd-base'
      ? `${safeSystemCurrencyCode}/${safeCurrencyCode}`
      : `${safeCurrencyCode}/${safeSystemCurrencyCode}`;
  }

  function convertCurrencyPerSystemRateToDisplayRate(currencyPerSystemRate, currencyCode, systemCurrencyCode, stateInput = null){
    const rate = Math.max(0, Number(currencyPerSystemRate) || 0);
    const safeCurrencyCode = normalizeCurrencyCode(currencyCode);
    const safeSystemCurrencyCode = normalizeCurrencyCode(systemCurrencyCode) || 'USD';
    if(!safeCurrencyCode || !(rate > 0)) return 0;
    if(safeCurrencyCode === safeSystemCurrencyCode) return 1;

    const state = stateInput && typeof stateInput === 'object' ? stateInput : readCurrencyState();
    const convention = resolveCurrencyRateDisplayConvention(state, safeCurrencyCode, safeSystemCurrencyCode);
    return convention === 'usd-base' ? rate : (1 / rate);
  }

  function resolveFallbackEvaluationDisplayRate(stateInput, currencyCode, systemCurrencyCode){
    const safeCurrencyCode = normalizeCurrencyCode(currencyCode);
    const safeSystemCurrencyCode = normalizeCurrencyCode(systemCurrencyCode) || 'USD';
    if(!safeCurrencyCode) return 0;
    if(safeCurrencyCode === safeSystemCurrencyCode) return 1;

    const currencyUsdRate = resolveCurrencyUsdSystemRateFromState(stateInput, safeCurrencyCode);
    const systemUsdRate = resolveCurrencyUsdSystemRateFromState(stateInput, safeSystemCurrencyCode);
    if(currencyUsdRate > 0 && systemUsdRate > 0) return systemUsdRate / currencyUsdRate;
    return 0;
  }

  function resolveDomainEvaluationDisplayRate(stateInput, currencyCode, systemCurrencyCode){
    const domain = getCurrencyDomain();
    if(!domain || typeof domain.readOperationalQuote !== 'function') return 0;
    const safeCurrencyCode = normalizeCurrencyCode(currencyCode);
    const safeSystemCurrencyCode = normalizeCurrencyCode(systemCurrencyCode) || 'USD';
    if(!safeCurrencyCode) return 0;
    if(safeCurrencyCode === safeSystemCurrencyCode) return 1;

    try{
      const quote = domain.readOperationalQuote(stateInput, safeSystemCurrencyCode, safeCurrencyCode);
      const bid = getPositiveExchangeRate(quote?.bid, 0);
      const ask = getPositiveExchangeRate(quote?.ask, bid);
      const middle = bid > 0 && ask > 0 ? ((Math.min(bid, ask) + Math.max(bid, ask)) / 2) : 0;
      return middle > 0 ? middle : 0;
    }catch{
      return 0;
    }
  }

  function resolveEvaluationDisplayRate(currencyCode, systemCurrencyCode, stateInput = null){
    const safeCurrencyCode = normalizeCurrencyCode(currencyCode);
    const safeSystemCurrencyCode = normalizeCurrencyCode(systemCurrencyCode) || 'USD';
    if(!safeCurrencyCode) return 0;
    if(safeCurrencyCode === safeSystemCurrencyCode) return 1;

    const state = stateInput && typeof stateInput === 'object' ? stateInput : readCurrencyState();
    const domainRate = resolveDomainEvaluationDisplayRate(state, safeCurrencyCode, safeSystemCurrencyCode);
    if(domainRate > 0) return domainRate;
    return resolveFallbackEvaluationDisplayRate(state, safeCurrencyCode, safeSystemCurrencyCode);
  }

  function mapValuationItemToEvaluationRate(item, systemCurrencyCode, stateInput = null){
    const currency = normalizeCurrencyCode(item?.currency);
    const safeSystemCurrency = normalizeCurrencyCode(systemCurrencyCode) || 'USD';
    const quantity = normalizeValuationZero(Number(item?.quantity) || 0);
    if(!currency) return item;

    const currencyPerSystemRate = resolveEvaluationDisplayRate(currency, safeSystemCurrency, stateInput);
    const displayRate = convertCurrencyPerSystemRateToDisplayRate(currencyPerSystemRate, currency, safeSystemCurrency, stateInput);
    const displayRatePairLabel = resolveDisplayRatePairLabel(currency, safeSystemCurrency, stateInput);
    if(currencyPerSystemRate > 0){
      const systemRate = currency === safeSystemCurrency ? 1 : (1 / currencyPerSystemRate);
      return {
        ...item,
        currency,
        quantity,
        systemValue: normalizeValuationZero(quantity * systemRate),
        valuationRate: systemRate,
        displayExchangeRate: displayRate > 0 ? displayRate : null,
        displayExchangeRatePairLabel: displayRatePairLabel,
        hasValue: true,
        basisComplete: true,
        basisWarning: ''
      };
    }

    if(Math.abs(quantity) < 1e-9){
      return {
        ...item,
        currency,
        quantity: 0,
        systemValue: 0,
        valuationRate: null,
        displayExchangeRate: displayRate > 0 ? displayRate : null,
        displayExchangeRatePairLabel: displayRatePairLabel,
        hasValue: true,
        basisComplete: true,
        basisWarning: ''
      };
    }

    return {
      ...item,
      currency,
      quantity,
      systemValue: null,
      valuationRate: null,
      displayExchangeRate: null,
      displayExchangeRatePairLabel: displayRatePairLabel,
      hasValue: false,
      basisComplete: false,
      basisWarning: 'سعر الوسطي غير محدد'
    };
  }


  function resolveTradingOperationTypeForGroup(group){
    const rows = Array.isArray(group?.rows) ? group.rows : [];
    const typedRow = rows.find((row) => row?.type === 'purchase' || row?.type === 'sale') || null;
    if(typedRow?.type === 'purchase' || typedRow?.type === 'sale') return typedRow.type;

    const searchableText = [
      group?.key,
      ...rows.flatMap((row) => [
        row?.type,
        row?.number,
        row?.referenceLabel,
        row?.description,
        row?.summary,
        row?.rawRecord?.number,
        row?.rawRecord?.description,
        row?.rawRecord?.summary,
        row?.rawRecord?.sourceSalesPurchaseNumber
      ])
    ].map((value) => toText(value)).join(' ');

    const upperText = searchableText.toUpperCase();
    if(/\bPUR-\d{3,}\b/.test(upperText)) return 'purchase';
    if(/\bSAL-\d{3,}\b/.test(upperText)) return 'sale';

    const normalized = normalizeLookupText(searchableText);
    if(normalized.includes('عمليه شراء') || normalized.includes('شراء')) return 'purchase';
    if(normalized.includes('عمليه مبيع') || normalized.includes('مبيع')) return 'sale';
    return '';
  }

  function resolveTradingPairForGroup(group){
    const rows = Array.isArray(group?.rows) ? group.rows : [];
    for(const row of rows){
      const pair = resolveRowPairHint(row);
      if(pair) return pair;
    }
    return null;
  }

  function resolveTradingRawRateForGroup(group){
    const rows = Array.isArray(group?.rows) ? group.rows : [];
    for(const row of rows){
      const rate = resolveRowRateHint(row);
      if(rate > 0) return rate;
    }
    return 0;
  }

  function resolveTradingCurrencyPerSystemRateFromPairRate(pair, rawRate, currencyCode, systemCurrencyCode){
    const safeCurrency = normalizeCurrencyCode(currencyCode);
    const safeSystemCurrency = normalizeCurrencyCode(systemCurrencyCode) || 'USD';
    const rate = Math.max(0, Number(rawRate) || 0);
    if(!safeCurrency || safeCurrency === safeSystemCurrency) return 1;
    if(!(rate > 0) || !(pair && typeof pair === 'object')) return 0;
    const baseCode = normalizeCurrencyCode(pair.baseCode);
    const quoteCode = normalizeCurrencyCode(pair.quoteCode);
    if(baseCode === safeSystemCurrency && quoteCode === safeCurrency) return rate;
    if(baseCode === safeCurrency && quoteCode === safeSystemCurrency) return rate > 0 ? (1 / rate) : 0;
    return 0;
  }

  function ensureTradingAverageBucket(bucketMap, currencyCode){
    const safeCurrency = normalizeCurrencyCode(currencyCode);
    if(!safeCurrency) return null;
    if(!bucketMap.has(safeCurrency)){
      bucketMap.set(safeCurrency, {
        currency: safeCurrency,
        purchase: { currencyTotal:0, systemTotal:0 },
        sale: { currencyTotal:0, systemTotal:0 }
      });
    }
    return bucketMap.get(safeCurrency);
  }

  function addTradingAverageBucketTotals(bucketMap, currencyCode, side, currencyAmount, systemAmount){
    const safeSide = side === 'sale' ? 'sale' : (side === 'purchase' ? 'purchase' : '');
    const safeCurrencyAmount = Math.max(0, Number(currencyAmount) || 0);
    const safeSystemAmount = Math.max(0, Number(systemAmount) || 0);
    if(!safeSide || !(safeCurrencyAmount > 1e-9) || !(safeSystemAmount > 1e-9)) return;
    const bucket = ensureTradingAverageBucket(bucketMap, currencyCode);
    if(!bucket) return;
    bucket[safeSide].currencyTotal = normalizeValuationZero((Number(bucket[safeSide].currencyTotal) || 0) + safeCurrencyAmount);
    bucket[safeSide].systemTotal = normalizeValuationZero((Number(bucket[safeSide].systemTotal) || 0) + safeSystemAmount);
  }

  function buildTradingAverageRateMap(rows, filters = {}, systemCurrencyCode = 'USD'){
    const safeSystemCurrency = normalizeCurrencyCode(systemCurrencyCode) || 'USD';
    const startKey = parseDateKey(filters.dateFrom) || 0;
    const endKey = parseDateKey(filters.dateTo) || Number.MAX_SAFE_INTEGER;
    const bucketMap = new Map();

    buildValuationGroups(rows).forEach((group) => {
      const groupDateKey = Number(group?.dateSort) || 0;
      if(startKey && groupDateKey < startKey) return;
      if(filters.dateTo && groupDateKey > endKey) return;

      const operationType = resolveTradingOperationTypeForGroup(group);
      if(operationType !== 'purchase' && operationType !== 'sale') return;

      const pair = resolveTradingPairForGroup(group);
      const rawRate = resolveTradingRawRateForGroup(group);
      const deltas = summarizeGroupCurrencyDeltas(group);
      const amountMap = new Map(deltas.map((item) => [item.currency, Math.abs(Number(item.delta) || 0)]));
      const systemAmount = Math.max(0, Number(amountMap.get(safeSystemCurrency)) || 0);
      const candidateCurrencies = pair
        ? [pair.baseCode, pair.quoteCode].map((code) => normalizeCurrencyCode(code)).filter((code) => code && code !== safeSystemCurrency)
        : deltas.map((item) => normalizeCurrencyCode(item.currency)).filter((code) => code && code !== safeSystemCurrency);
      const uniqueCurrencies = Array.from(new Set(candidateCurrencies));

      uniqueCurrencies.forEach((currencyCode) => {
        const currencyAmount = Math.max(0, Number(amountMap.get(currencyCode)) || 0);
        let resolvedCurrencyAmount = currencyAmount;
        let resolvedSystemAmount = systemAmount;
        let currencyPerSystemRate = resolveTradingCurrencyPerSystemRateFromPairRate(pair, rawRate, currencyCode, safeSystemCurrency);

        if(!(currencyPerSystemRate > 0) && rawRate > 0 && currencyCode !== safeSystemCurrency){
          currencyPerSystemRate = rawRate;
        }
        if(!(resolvedCurrencyAmount > 1e-9) && currencyPerSystemRate > 0 && resolvedSystemAmount > 1e-9){
          resolvedCurrencyAmount = resolvedSystemAmount * currencyPerSystemRate;
        }
        if(!(resolvedSystemAmount > 1e-9) && currencyPerSystemRate > 0 && resolvedCurrencyAmount > 1e-9){
          resolvedSystemAmount = resolvedCurrencyAmount / currencyPerSystemRate;
        }
        if(!(resolvedCurrencyAmount > 1e-9) || !(resolvedSystemAmount > 1e-9)) return;

        addTradingAverageBucketTotals(bucketMap, currencyCode, operationType, resolvedCurrencyAmount, resolvedSystemAmount);
      });
    });

    const state = readCurrencyState();
    const rateMap = new Map();
    bucketMap.forEach((bucket, currencyCode) => {
      const purchaseRate = bucket.purchase.systemTotal > 1e-9 ? (bucket.purchase.currencyTotal / bucket.purchase.systemTotal) : 0;
      const saleRate = bucket.sale.systemTotal > 1e-9 ? (bucket.sale.currencyTotal / bucket.sale.systemTotal) : 0;
      const rates = [purchaseRate, saleRate].filter((rate) => rate > 0 && Number.isFinite(rate));
      const averageRate = rates.length ? (rates.reduce((sum, rate) => sum + rate, 0) / rates.length) : 0;
      const pairLabel = resolveDisplayRatePairLabel(currencyCode, safeSystemCurrency, state);
      const purchaseDisplayRate = purchaseRate > 0 && Number.isFinite(purchaseRate)
        ? convertCurrencyPerSystemRateToDisplayRate(purchaseRate, currencyCode, safeSystemCurrency, state)
        : 0;
      const saleDisplayRate = saleRate > 0 && Number.isFinite(saleRate)
        ? convertCurrencyPerSystemRateToDisplayRate(saleRate, currencyCode, safeSystemCurrency, state)
        : 0;
      const averageDisplayRate = averageRate > 0 && Number.isFinite(averageRate)
        ? convertCurrencyPerSystemRateToDisplayRate(averageRate, currencyCode, safeSystemCurrency, state)
        : 0;
      rateMap.set(currencyCode, {
        currency: currencyCode,
        purchaseRate: purchaseRate > 0 && Number.isFinite(purchaseRate) ? purchaseRate : null,
        saleRate: saleRate > 0 && Number.isFinite(saleRate) ? saleRate : null,
        averageRate: averageRate > 0 && Number.isFinite(averageRate) ? averageRate : null,
        purchaseDisplayRate: purchaseDisplayRate > 0 && Number.isFinite(purchaseDisplayRate) ? purchaseDisplayRate : null,
        saleDisplayRate: saleDisplayRate > 0 && Number.isFinite(saleDisplayRate) ? saleDisplayRate : null,
        averageDisplayRate: averageDisplayRate > 0 && Number.isFinite(averageDisplayRate) ? averageDisplayRate : null,
        displayRatePairLabel: pairLabel
      });
    });
    rateMap.set(safeSystemCurrency, {
      currency: safeSystemCurrency,
      purchaseRate: 1,
      saleRate: 1,
      averageRate: 1,
      purchaseDisplayRate: 1,
      saleDisplayRate: 1,
      averageDisplayRate: 1,
      displayRatePairLabel: `${safeSystemCurrency}/${safeSystemCurrency}`
    });
    return rateMap;
  }

  function mapValuationItemToTradingAverageCostRate(item, systemCurrencyCode, rateMap){
    const currency = normalizeCurrencyCode(item?.currency);
    const safeSystemCurrency = normalizeCurrencyCode(systemCurrencyCode) || 'USD';
    const quantity = normalizeValuationZero(Number(item?.quantity) || 0);
    if(!currency) return item;

    const rateInfo = rateMap?.get(currency) || null;
    const averageRate = Math.max(0, Number(rateInfo?.averageRate) || 0);
    const purchaseDisplayRate = Math.max(0, Number(rateInfo?.purchaseDisplayRate) || 0);
    const saleDisplayRate = Math.max(0, Number(rateInfo?.saleDisplayRate) || 0);
    const averageDisplayRate = Math.max(0, Number(rateInfo?.averageDisplayRate) || 0);
    const displayRatePairLabel = String(rateInfo?.displayRatePairLabel || resolveDisplayRatePairLabel(currency, safeSystemCurrency)).trim();

    if(currency === safeSystemCurrency){
      return {
        ...item,
        currency,
        quantity,
        systemValue: quantity,
        valuationRate: 1,
        tradingPurchaseDisplayRate: 1,
        tradingSaleDisplayRate: 1,
        tradingAverageDisplayRate: 1,
        displayExchangeRate: 1,
        displayExchangeRatePairLabel: displayRatePairLabel || `${safeSystemCurrency}/${safeSystemCurrency}`,
        tradingRatePairLabel: displayRatePairLabel || `${safeSystemCurrency}/${safeSystemCurrency}`,
        hasValue: true,
        basisComplete: true,
        basisWarning: ''
      };
    }

    if(averageRate > 0){
      const systemRate = 1 / averageRate;
      return {
        ...item,
        currency,
        quantity,
        systemValue: normalizeValuationZero(quantity * systemRate),
        valuationRate: systemRate,
        tradingPurchaseDisplayRate: purchaseDisplayRate > 0 ? purchaseDisplayRate : null,
        tradingSaleDisplayRate: saleDisplayRate > 0 ? saleDisplayRate : null,
        tradingAverageDisplayRate: averageDisplayRate > 0 ? averageDisplayRate : null,
        displayExchangeRate: averageDisplayRate > 0 ? averageDisplayRate : null,
        displayExchangeRatePairLabel: displayRatePairLabel,
        tradingRatePairLabel: displayRatePairLabel,
        hasValue: true,
        basisComplete: true,
        basisWarning: ''
      };
    }

    if(Math.abs(quantity) < 1e-9){
      return {
        ...item,
        currency,
        quantity: 0,
        systemValue: 0,
        valuationRate: null,
        tradingPurchaseDisplayRate: purchaseDisplayRate > 0 ? purchaseDisplayRate : null,
        tradingSaleDisplayRate: saleDisplayRate > 0 ? saleDisplayRate : null,
        tradingAverageDisplayRate: null,
        displayExchangeRate: null,
        displayExchangeRatePairLabel: displayRatePairLabel,
        tradingRatePairLabel: displayRatePairLabel,
        hasValue: true,
        basisComplete: true,
        basisWarning: ''
      };
    }

    return {
      ...item,
      currency,
      quantity,
      systemValue: null,
      valuationRate: null,
      tradingPurchaseDisplayRate: purchaseDisplayRate > 0 ? purchaseDisplayRate : null,
      tradingSaleDisplayRate: saleDisplayRate > 0 ? saleDisplayRate : null,
      tradingAverageDisplayRate: null,
      displayExchangeRate: null,
      displayExchangeRatePairLabel: displayRatePairLabel,
      tradingRatePairLabel: displayRatePairLabel,
      hasValue: false,
      basisComplete: false,
      basisWarning: 'سعر التكلفة غير محدد'
    };
  }

  function applyExchangeRateModeToValuation(valuation, filters = {}, sourceRows = []){
    const safeValuation = valuation && typeof valuation === 'object' ? valuation : {};
    const exchangeRateMode = sanitizeExchangeRateMode(filters?.exchangeRateMode);
    const modeMeta = resolveExchangeRateModeMeta(exchangeRateMode);
    const systemCurrencyCode = normalizeCurrencyCode(safeValuation.systemCurrencyCode) || getSystemCurrencyCode();

    if(exchangeRateMode === 'average-cost'){
      const rateMap = buildTradingAverageRateMap(sourceRows, filters, systemCurrencyCode);
      const mapItems = (items) => (Array.isArray(items) ? items : []).map((item) => mapValuationItemToTradingAverageCostRate(item, systemCurrencyCode, rateMap));
      return {
        ...safeValuation,
        systemCurrencyCode,
        opening: mapItems(safeValuation.opening),
        closing: mapItems(safeValuation.closing),
        exchangeRateMode,
        rateColumnLabel: modeMeta.columnLabel,
        rateSourceLabel: modeMeta.label
      };
    }

    if(exchangeRateMode !== 'valuation'){
      return {
        ...safeValuation,
        systemCurrencyCode,
        exchangeRateMode,
        rateColumnLabel: modeMeta.columnLabel,
        rateSourceLabel: modeMeta.label
      };
    }

    const state = readCurrencyState();
    const mapItems = (items) => (Array.isArray(items) ? items : []).map((item) => mapValuationItemToEvaluationRate(item, systemCurrencyCode, state));

    return {
      ...safeValuation,
      systemCurrencyCode,
      opening: mapItems(safeValuation.opening),
      closing: mapItems(safeValuation.closing),
      exchangeRateMode,
      rateColumnLabel: modeMeta.columnLabel,
      rateSourceLabel: modeMeta.label
    };
  }

  function normalizeValuationZero(value){
    const numeric = Number(value) || 0;
    return Math.abs(numeric) < 1e-9 ? 0 : numeric;
  }

  function addSystemMetric(targetMap, key, amount){
    const safeKey = normalizeCurrencyCode(key);
    if(!safeKey) return targetMap;
    const numeric = Number(amount) || 0;
    if(!numeric && !Object.prototype.hasOwnProperty.call(targetMap, safeKey)) return targetMap;
    targetMap[safeKey] = normalizeValuationZero((Number(targetMap[safeKey]) || 0) + numeric);
    if(Math.abs(targetMap[safeKey]) < 1e-9) targetMap[safeKey] = 0;
    return targetMap;
  }

  function createValuationTrackingBucket(){
    return {
      realizedTotal: 0,
      realizedByCurrency: {},
      warnings: [],
      warningKeys: new Set()
    };
  }

  function pushValuationWarning(bucket, key, message){
    if(!(bucket && bucket.warningKeys instanceof Set)) return;
    const safeKey = String(key ?? '').trim() || String(message ?? '').trim();
    if(!safeKey || bucket.warningKeys.has(safeKey)) return;
    bucket.warningKeys.add(safeKey);
    bucket.warnings.push(String(message ?? '').trim() || safeKey);
  }

  function finalizeValuationTrackingBucket(bucket, systemCurrencyCode){
    const safeBucket = bucket && typeof bucket === 'object' ? bucket : createValuationTrackingBucket();
    return {
      realizedTotal: normalizeValuationZero(safeBucket.realizedTotal),
      realizedByCurrency: Object.keys(safeBucket.realizedByCurrency || {})
        .sort()
        .map((currencyCode) => ({
          currency: currencyCode,
          value: normalizeValuationZero(safeBucket.realizedByCurrency[currencyCode]),
          text: `${currencyCode}: ${formatAmountWithCurrency(safeBucket.realizedByCurrency[currencyCode], systemCurrencyCode)}`
        })),
      warnings: Array.isArray(safeBucket.warnings) ? safeBucket.warnings.slice() : []
    };
  }

  function ensureValuationPosition(positionMap, currencyCode, systemCurrencyCode){
    const safeCurrency = normalizeCurrencyCode(currencyCode) || 'USD';
    if(positionMap.has(safeCurrency)) return positionMap.get(safeCurrency);
    const position = {
      currency: safeCurrency,
      quantity: 0,
      systemValue: 0,
      lastRate: safeCurrency === systemCurrencyCode ? 1 : 0,
      basisIncomplete: false
    };
    positionMap.set(safeCurrency, position);
    return position;
  }

  function resolveValuationRate(position, systemCurrencyCode){
    const safePosition = position && typeof position === 'object' ? position : null;
    if(!safePosition) return 0;
    const safeCurrency = normalizeCurrencyCode(safePosition.currency) || 'USD';
    if(safeCurrency === systemCurrencyCode) return 1;
    const quantity = Number(safePosition.quantity) || 0;
    const systemValue = Number(safePosition.systemValue) || 0;
    if(Math.abs(quantity) > 1e-9 && Math.abs(systemValue) > 1e-9){
      return Math.abs(systemValue / quantity);
    }
    const lastRate = Number(safePosition.lastRate) || 0;
    return lastRate > 0 ? lastRate : 0;
  }

  function parseInlineRateText(value){
    const source = String(value ?? '');
    if(!source) return 0;
    const patterns = [
      /سعر\s*الصرف\s*[:：-]?\s*([0-9][0-9.,]*)/u,
      /سعر\s*التقييم\s*[:：-]?\s*([0-9][0-9.,]*)/u,
      /(?:rate|fx)\s*[:=]\s*([0-9][0-9.,]*)/iu
    ];
    for(const pattern of patterns){
      const match = source.match(pattern);
      if(!match) continue;
      const numeric = Math.max(0, parseNumericInput(match[1], 0));
      if(numeric > 0) return numeric;
    }
    return 0;
  }

  function resolveRowRateHint(row){
    const candidates = [
      row?.summary,
      row?.description,
      row?.rawRecord?.summary,
      row?.rawRecord?.description,
      row?.rawRecord?.rateText
    ];
    for(const candidate of candidates){
      const numeric = parseInlineRateText(candidate);
      if(numeric > 0) return numeric;
    }
    return 0;
  }

  function extractCurrencyPairFromText(value){
    const source = String(value ?? '').toUpperCase();
    if(!source) return null;
    const match = source.match(/\b([A-Z]{3})\s*\/\s*([A-Z]{3})\b/);
    if(!match) return null;
    const baseCode = normalizeCurrencyCode(match[1]);
    const quoteCode = normalizeCurrencyCode(match[2]);
    if(!baseCode || !quoteCode || baseCode === quoteCode) return null;
    return { baseCode, quoteCode };
  }

  function resolveRowPairHint(row){
    const candidates = [
      row?.summary,
      row?.description,
      row?.rawRecord?.summary,
      row?.rawRecord?.description,
      row?.rawRecord?.rateText
    ];
    for(const candidate of candidates){
      const pair = extractCurrencyPairFromText(candidate);
      if(pair) return pair;
    }
    return null;
  }

  function extractValuationSourceRef(value){
    const source = String(value ?? '').toUpperCase();
    if(!source) return '';
    const match = source.match(/\b(?:SAL|PUR)-\d{5}\b/);
    return match ? match[0] : '';
  }

  function resolveRowValuationSourceRef(row){
    const candidates = [
      row?.description,
      row?.summary,
      row?.rawRecord?.description,
      row?.rawRecord?.summary,
      row?.referenceLabel,
      row?.number
    ];
    for(const candidate of candidates){
      const ref = extractValuationSourceRef(candidate);
      if(ref) return ref;
    }
    return '';
  }

  function resolveRowRateContext(row, systemCurrencyCode){
    const safeSystemCurrency = normalizeCurrencyCode(systemCurrencyCode) || getSystemCurrencyCode();
    const rowCurrency = normalizeCurrencyCode(row?.currency) || 'USD';
    const rawRate = resolveRowRateHint(row);
    const pair = resolveRowPairHint(row);
    let unitSystemRate = 0;

    if(rowCurrency === safeSystemCurrency){
      unitSystemRate = 1;
    }else if(rawRate > 0 && pair){
      if(pair.baseCode === rowCurrency && pair.quoteCode === safeSystemCurrency){
        unitSystemRate = rawRate;
      }else if(pair.quoteCode === rowCurrency && pair.baseCode === safeSystemCurrency){
        unitSystemRate = 1 / rawRate;
      }
    }

    return {
      rowCurrency,
      systemCurrencyCode: safeSystemCurrency,
      rawRate,
      pair,
      unitSystemRate: unitSystemRate > 0 ? unitSystemRate : 0,
      sourceRef: resolveRowValuationSourceRef(row)
    };
  }

  function applySystemPositionDelta(position, delta){
    const numeric = Number(delta) || 0;
    if(!numeric) return { transferredValue: 0, unitRate: 1 };
    position.quantity = normalizeValuationZero((Number(position.quantity) || 0) + numeric);
    position.systemValue = normalizeValuationZero((Number(position.systemValue) || 0) + numeric);
    position.lastRate = 1;
    if(!position.quantity) position.systemValue = 0;
    return { transferredValue: Math.abs(numeric), unitRate: 1 };
  }

  function applyValuationInflow(position, quantity, systemCost, systemCurrencyCode){
    const safeQuantity = Math.max(0, Number(quantity) || 0);
    const safeCurrency = normalizeCurrencyCode(position?.currency) || 'USD';
    if(!(safeQuantity > 1e-9)){
      return {
        unitRate: resolveValuationRate(position, systemCurrencyCode),
        costKnown: safeCurrency === systemCurrencyCode || resolveValuationRate(position, systemCurrencyCode) > 0
      };
    }

    const safeSystemCost = Math.max(0, Number(systemCost) || 0);
    const explicitRate = safeSystemCost > 1e-9 ? (safeSystemCost / safeQuantity) : 0;
    const fallbackRate = resolveValuationRate(position, systemCurrencyCode);
    const unitRate = explicitRate > 0 ? explicitRate : fallbackRate;
    const costKnown = safeCurrency === systemCurrencyCode || unitRate > 0;

    let remainingQuantity = safeQuantity;
    if((Number(position.quantity) || 0) < -1e-9){
      const shortQuantity = Math.abs(Number(position.quantity) || 0);
      const coverQuantity = Math.min(remainingQuantity, shortQuantity);
      const shortRate = resolveValuationRate(position, systemCurrencyCode) || unitRate;
      if(coverQuantity > 1e-9){
        position.quantity = normalizeValuationZero((Number(position.quantity) || 0) + coverQuantity);
        if(shortRate > 0 || safeCurrency === systemCurrencyCode){
          position.systemValue = normalizeValuationZero((Number(position.systemValue) || 0) + (coverQuantity * (shortRate || 1)));
        }else{
          position.basisIncomplete = true;
        }
        remainingQuantity -= coverQuantity;
      }
    }

    if(remainingQuantity > 1e-9){
      if(costKnown){
        const remainingCost = (explicitRate > 0 ? explicitRate : unitRate || 1) * remainingQuantity;
        position.quantity = normalizeValuationZero((Number(position.quantity) || 0) + remainingQuantity);
        position.systemValue = normalizeValuationZero((Number(position.systemValue) || 0) + remainingCost);
      }else{
        position.quantity = normalizeValuationZero((Number(position.quantity) || 0) + remainingQuantity);
        position.basisIncomplete = true;
      }
    }

    if(!position.quantity){
      position.systemValue = 0;
      position.basisIncomplete = false;
    }
    if(unitRate > 0) position.lastRate = unitRate;
    return { unitRate, costKnown };
  }

  function applyValuationOutflow(position, quantity, systemCurrencyCode, shortRateHint = 0){
    let remainingQuantity = Math.max(0, Number(quantity) || 0);
    const safeCurrency = normalizeCurrencyCode(position?.currency) || 'USD';
    if(!(remainingQuantity > 1e-9)){
      const fallbackRate = resolveValuationRate(position, systemCurrencyCode) || Math.max(0, Number(shortRateHint) || 0);
      return { transferredValue: 0, unitRate: fallbackRate, costKnown: fallbackRate > 0 || safeCurrency === systemCurrencyCode, unknownQuantity: 0 };
    }

    let transferredValue = 0;
    let costKnown = true;
    let unknownQuantity = 0;
    const currentRate = resolveValuationRate(position, systemCurrencyCode);
    const longQuantity = Math.max(0, Number(position.quantity) || 0);

    if(longQuantity > 1e-9){
      const consumeQuantity = Math.min(remainingQuantity, longQuantity);
      if(currentRate > 0 || safeCurrency === systemCurrencyCode){
        transferredValue += consumeQuantity * (currentRate || 1);
        position.systemValue = normalizeValuationZero((Number(position.systemValue) || 0) - (consumeQuantity * (currentRate || 1)));
      }else{
        costKnown = false;
        unknownQuantity += consumeQuantity;
        position.basisIncomplete = true;
      }
      position.quantity = normalizeValuationZero((Number(position.quantity) || 0) - consumeQuantity);
      remainingQuantity -= consumeQuantity;
      if(!position.quantity) position.systemValue = 0;
    }

    if(remainingQuantity > 1e-9){
      const shortRate = Math.max(0, Number(shortRateHint) || 0) || currentRate || resolveValuationRate(position, systemCurrencyCode) || 0;
      if(shortRate > 0 || safeCurrency === systemCurrencyCode){
        transferredValue += remainingQuantity * (shortRate || 1);
        position.systemValue = normalizeValuationZero((Number(position.systemValue) || 0) - (remainingQuantity * (shortRate || 1)));
        if(shortRate > 0) position.lastRate = shortRate;
      }else{
        costKnown = false;
        unknownQuantity += remainingQuantity;
        position.basisIncomplete = true;
      }
      position.quantity = normalizeValuationZero((Number(position.quantity) || 0) - remainingQuantity);
    }else if(currentRate > 0){
      position.lastRate = currentRate;
    }

    if(!position.quantity){
      position.systemValue = 0;
      position.basisIncomplete = false;
    }
    return {
      transferredValue: normalizeValuationZero(transferredValue),
      unitRate: currentRate || Math.max(0, Number(shortRateHint) || 0) || resolveValuationRate(position, systemCurrencyCode),
      costKnown,
      unknownQuantity: normalizeValuationZero(unknownQuantity)
    };
  }

  function buildValuationGroups(rows){
    const grouped = new Map();
    (Array.isArray(rows) ? rows : []).slice().sort(compareRows).forEach((row, index) => {
      const sourceRef = resolveRowValuationSourceRef(row);
      const key = sourceRef
        ? `source:${sourceRef}`
        : (toText(row?.number)
          ? `voucher:${toText(row.number)}`
          : `row:${toText(row?.id) || index + 1}`);
      if(!grouped.has(key)){
        grouped.set(key, {
          key,
          rows: [],
          sortRow: row,
          dateSort: Number(row?.dateSort) || 0,
          createdAt: Number(row?.createdAt) || 0
        });
      }
      const group = grouped.get(key);
      group.rows.push(row);
      if(compareRows(row, group.sortRow) < 0){
        group.sortRow = row;
        group.dateSort = Number(row?.dateSort) || 0;
        group.createdAt = Number(row?.createdAt) || 0;
      }
    });

    return Array.from(grouped.values())
      .map((group) => ({
        ...group,
        rows: group.rows.slice().sort(compareRows)
      }))
      .sort((left, right) => compareRows(left.sortRow, right.sortRow));
  }

  function summarizeGroupCurrencyDeltas(group){
    const deltaMap = new Map();
    (Array.isArray(group?.rows) ? group.rows : []).forEach((row) => {
      const currency = normalizeCurrencyCode(row?.currency) || 'USD';
      const delta = normalizeValuationZero((Number(row?.debit) || 0) - (Number(row?.credit) || 0));
      if(!delta) return;
      deltaMap.set(currency, normalizeValuationZero((deltaMap.get(currency) || 0) + delta));
    });

    return Array.from(deltaMap.entries()).map(([currency, delta]) => ({
      currency,
      delta,
      inflow: delta > 0 ? delta : 0,
      outflow: delta < 0 ? Math.abs(delta) : 0
    }));
  }

  function processValuationGroup(positionMap, group, systemCurrencyCode, trackingBucket = null){
    const deltas = summarizeGroupCurrencyDeltas(group);
    if(!deltas.length) return;

    const positiveItems = deltas.filter((item) => item.delta > 1e-9);
    const negativeItems = deltas.filter((item) => item.delta < -1e-9);
    const systemPositiveTotal = positiveItems
      .filter((item) => item.currency === systemCurrencyCode)
      .reduce((sum, item) => sum + item.inflow, 0);
    const systemNegativeTotal = negativeItems
      .filter((item) => item.currency === systemCurrencyCode)
      .reduce((sum, item) => sum + item.outflow, 0);
    const foreignPositiveItems = positiveItems.filter((item) => item.currency !== systemCurrencyCode);
    const foreignNegativeItems = negativeItems.filter((item) => item.currency !== systemCurrencyCode);
    const totalForeignPositive = foreignPositiveItems.reduce((sum, item) => sum + item.inflow, 0);
    const totalForeignNegative = foreignNegativeItems.reduce((sum, item) => sum + item.outflow, 0);
    let transferPool = 0;

    negativeItems.filter((item) => item.currency === systemCurrencyCode).forEach((item) => {
      const position = ensureValuationPosition(positionMap, item.currency, systemCurrencyCode);
      applySystemPositionDelta(position, -item.outflow);
    });

    foreignNegativeItems.forEach((item) => {
      const position = ensureValuationPosition(positionMap, item.currency, systemCurrencyCode);
      const matchingRow = (Array.isArray(group?.rows) ? group.rows : []).find((row) => (normalizeCurrencyCode(row?.currency) || 'USD') === item.currency);
      const rowRateContext = resolveRowRateContext(matchingRow, systemCurrencyCode);
      const rowRateHint = rowRateContext.unitSystemRate;
      const proportionalSystemRate = (systemPositiveTotal > 1e-9 && totalForeignNegative > 1e-9)
        ? ((systemPositiveTotal * (item.outflow / totalForeignNegative)) / item.outflow)
        : 0;
      const shortRateHint = proportionalSystemRate || rowRateHint || resolveValuationRate(position, systemCurrencyCode);
      const result = applyValuationOutflow(position, item.outflow, systemCurrencyCode, shortRateHint);
      transferPool = normalizeValuationZero(transferPool + (Number(result.transferredValue) || 0));

      const allocatedSystemProceeds = (systemPositiveTotal > 1e-9 && totalForeignNegative > 1e-9)
        ? (systemPositiveTotal * (item.outflow / totalForeignNegative))
        : 0;
      if(trackingBucket && allocatedSystemProceeds > 1e-9){
        if(result.costKnown){
          const realizedValue = normalizeValuationZero(allocatedSystemProceeds - (Number(result.transferredValue) || 0));
          trackingBucket.realizedTotal = normalizeValuationZero((Number(trackingBucket.realizedTotal) || 0) + realizedValue);
          addSystemMetric(trackingBucket.realizedByCurrency, item.currency, realizedValue);
        }else{
          pushValuationWarning(
            trackingBucket,
            `realized-basis-missing:${group?.key || ''}:${item.currency}`,
            `تعذر احتساب الربح أو الخسارة المحققة لعملة ${item.currency} كاملًا لأن أساس التكلفة السابق غير مكتمل.`
          );
        }
      }
    });

    const foreignCostPool = normalizeValuationZero(transferPool + systemNegativeTotal);
    foreignPositiveItems.forEach((item) => {
      const position = ensureValuationPosition(positionMap, item.currency, systemCurrencyCode);
      let allocatedCost = totalForeignPositive > 1e-9
        ? (foreignCostPool * (item.inflow / totalForeignPositive))
        : 0;
      if(!(allocatedCost > 1e-9)){
        const matchingRow = (Array.isArray(group?.rows) ? group.rows : []).find((row) => (normalizeCurrencyCode(row?.currency) || 'USD') === item.currency);
        const rowRateContext = resolveRowRateContext(matchingRow, systemCurrencyCode);
        const fallbackRate = rowRateContext.unitSystemRate || resolveValuationRate(position, systemCurrencyCode);
        allocatedCost = fallbackRate > 0 ? (item.inflow * fallbackRate) : 0;
      }
      const inflowResult = applyValuationInflow(position, item.inflow, allocatedCost, systemCurrencyCode);
      if(trackingBucket && !inflowResult.costKnown && Math.abs(item.inflow) > 1e-9){
        pushValuationWarning(
          trackingBucket,
          `inflow-basis-missing:${group?.key || ''}:${item.currency}`,
          `تم إدخال كمية ${item.currency} بدون أساس تكلفة كافٍ. يلزم توفير تكلفة افتتاحية أو حركة تمويل سابقة حتى يصبح التقييم كاملًا.`
        );
      }
    });

    positiveItems.filter((item) => item.currency === systemCurrencyCode).forEach((item) => {
      const position = ensureValuationPosition(positionMap, item.currency, systemCurrencyCode);
      applySystemPositionDelta(position, item.inflow);
    });
  }

  function serializeValuationPositions(positionMap, systemCurrencyCode){
    return Array.from(positionMap.values())
      .map((position) => {
        const currency = normalizeCurrencyCode(position?.currency) || 'USD';
        const quantity = normalizeValuationZero(position?.quantity);
        const systemValue = normalizeValuationZero(position?.systemValue);
        const valuationRate = resolveValuationRate(position, systemCurrencyCode);
        const basisComplete = Math.abs(quantity) < 1e-9
          || currency === systemCurrencyCode
          || valuationRate > 0
          || Math.abs(systemValue) > 1e-9;
        const hasValue = basisComplete;
        return {
          currency,
          quantity,
          systemValue: hasValue ? systemValue : null,
          valuationRate: valuationRate > 0 ? valuationRate : (currency === systemCurrencyCode ? 1 : null),
          hasValue,
          basisComplete,
          basisWarning: !basisComplete && Math.abs(quantity) > 1e-9 ? 'بحاجة أساس تكلفة' : ''
        };
      })
      .filter((item) => Math.abs(item.quantity) > 1e-9 || item.hasValue)
      .sort((left, right) => left.currency.localeCompare(right.currency, 'en', { sensitivity:'base' }));
  }

  function buildValuationSnapshots(rows, filters = {}){
    const systemCurrencyCode = getSystemCurrencyCode();
    const positionMap = new Map();
    const groups = buildValuationGroups(rows);
    const startKey = parseDateKey(filters.dateFrom) || 0;
    const endKey = parseDateKey(filters.dateTo) || Number.MAX_SAFE_INTEGER;
    const hideOpeningBalance = filters?.hideOpeningBalance === true;
    const trackingBucket = createValuationTrackingBucket();

    if(!hideOpeningBalance){
      groups.forEach((group) => {
        if(!startKey) return;
        const groupDateKey = Number(group?.dateSort) || 0;
        if(groupDateKey >= startKey) return;
        processValuationGroup(positionMap, group, systemCurrencyCode, null);
      });
    }

    const opening = hideOpeningBalance ? [] : serializeValuationPositions(positionMap, systemCurrencyCode);

    groups.forEach((group) => {
      const groupDateKey = Number(group?.dateSort) || 0;
      if(startKey && groupDateKey < startKey) return;
      if(filters.dateTo && groupDateKey > endKey) return;
      processValuationGroup(positionMap, group, systemCurrencyCode, trackingBucket);
    });

    const closing = serializeValuationPositions(positionMap, systemCurrencyCode);
    closing.forEach((item) => {
      if(item?.basisComplete !== false) return;
      pushValuationWarning(
        trackingBucket,
        `closing-basis-missing:${item.currency}`,
        `الرصيد المتبقي لعملة ${item.currency} لا يملك أساس تكلفة مكتمل، لذلك سيظهر الرصيد الرئيسي كسطر غير مكتمل حتى يتم إدخال تكلفة افتتاحية أو حركات تمويل صحيحة.`
      );
    });

    return {
      systemCurrencyCode,
      opening,
      closing,
      ...finalizeValuationTrackingBucket(trackingBucket, systemCurrencyCode)
    };
  }

  function buildModel(filtersInput = null){
    const filters = normalizeFilters(filtersInput || readFilters());
    const accounts = readAccounts();
    const account = accounts.find((entry) => entry.accountNo === filters.accountNo) || null;
    const records = readEntryRecords();
    const currencyOptions = buildCurrencyOptions(records);
    const operationOptions = OPERATION_FILTER_OPTIONS.slice();
    const exchangeRateOptions = EXCHANGE_RATE_MODE_OPTIONS.map((option) => ({ value:option.value, label:option.label }));
    const exchangeRateModeMeta = resolveExchangeRateModeMeta(filters.exchangeRateMode);

    const rowsAllTime = account
      ? records.flatMap((record) => buildSourceRowsForAccount(record, account.accountNo))
      : [];

    const postedRows = rowsAllTime.filter((row) => row.status === 'posted');
    const nonPostedRows = rowsAllTime.filter((row) => row.status !== 'posted');

    const filteredByOperation = postedRows.filter((row) => matchesOperationFilter(row, filters.operationTypes));
    const filteredNonPostedByOperation = nonPostedRows.filter((row) => matchesOperationFilter(row, filters.operationTypes));

    const filteredByCurrency = filteredByOperation.filter((row) => matchesCurrencyFilter(row, filters.currencies));
    const filteredNonPostedByCurrency = filteredNonPostedByOperation.filter((row) => matchesCurrencyFilter(row, filters.currencies));
    const valuation = applyExchangeRateModeToValuation(buildValuationSnapshots(filteredByOperation, filters), filters, filteredByOperation);

    const startKey = parseDateKey(filters.dateFrom) || 0;
    const endKey = parseDateKey(filters.dateTo) || Number.MAX_SAFE_INTEGER;

    const beforeRows = filteredByCurrency.filter((row) => {
      if(!startKey) return false;
      return (Number(row.dateSort) || 0) < startKey;
    }).sort(compareRows);

    const periodRows = filteredByCurrency.filter((row) => {
      const rowKey = Number(row.dateSort) || 0;
      if(startKey && rowKey < startKey) return false;
      if(filters.dateTo && rowKey > endKey) return false;
      return true;
    }).sort(compareRows);

    const rawOpeningByCurrency = {};
    beforeRows.forEach((row) => {
      accumulateCurrencyMap(rawOpeningByCurrency, row.currency, (Number(row.debit) || 0) - (Number(row.credit) || 0));
    });
    const hideOpeningBalance = filters.hideOpeningBalance === true;
    const openingByCurrency = hideOpeningBalance ? {} : rawOpeningByCurrency;

    const runningByCurrency = { ...openingByCurrency };
    const debitTotalsByCurrency = {};
    const creditTotalsByCurrency = {};
    const computedPeriodRows = periodRows.map((row) => {
      const currency = row.currency || 'USD';
      accumulateCurrencyMap(debitTotalsByCurrency, currency, row.debit);
      accumulateCurrencyMap(creditTotalsByCurrency, currency, row.credit);
      const nextBalance = (Number(runningByCurrency[currency]) || 0) + (Number(row.debit) || 0) - (Number(row.credit) || 0);
      runningByCurrency[currency] = nextBalance;
      return {
        ...row,
        runningBalance: nextBalance,
        runningSide: resolveBalanceDirection(nextBalance),
        runningBalanceText: formatBalanceText(nextBalance, currency),
        balanceClass: resolveBalanceDirection(nextBalance) === 'credit'
          ? 'is-credit'
          : (resolveBalanceDirection(nextBalance) === 'debit' ? 'is-debit' : 'is-zero')
      };
    });

    const nonPostedPeriodRows = filteredNonPostedByCurrency.filter((row) => {
      const rowKey = Number(row.dateSort) || 0;
      if(startKey && rowKey < startKey) return false;
      if(filters.dateTo && rowKey > endKey) return false;
      return true;
    }).sort(compareRows);

    const computedRowMap = new Map(computedPeriodRows.map((row) => [row.id, row]));
    const visiblePeriodRows = [...periodRows, ...nonPostedPeriodRows]
      .sort(compareRows)
      .reduce((accumulator, row) => {
        const currency = row.currency || 'USD';
        const lastBalance = accumulator.runningByCurrency[currency] || 0;
        if(row.status === 'posted'){
          const computedRow = computedRowMap.get(row.id) || row;
          accumulator.runningByCurrency[currency] = Number(computedRow.runningBalance) || 0;
          accumulator.rows.push(computedRow);
          return accumulator;
        }
        accumulator.rows.push(decorateNonPostedLedgerRow(row, lastBalance));
        return accumulator;
      }, { rows: [], runningByCurrency: { ...openingByCurrency } }).rows;

    const searchNeedle = normalizeLookupText(filters.search);
    const matchedVisibleRows = searchNeedle
      ? visiblePeriodRows.filter((row) => row.searchText.includes(searchNeedle) || normalizeLookupText(row.summary).includes(searchNeedle) || normalizeLookupText(row.statusLabel).includes(searchNeedle))
      : visiblePeriodRows.slice();

    const openingRows = hideOpeningBalance ? [] : createOpeningRows(openingByCurrency, filters);
    const visibleRows = [...openingRows, ...matchedVisibleRows];

    const closingByCurrency = { ...openingByCurrency };
    computedPeriodRows.forEach((row) => {
      closingByCurrency[row.currency] = Number(row.runningBalance) || 0;
    });

    const periodCurrencyCodes = Array.from(new Set([
      ...Object.keys(openingByCurrency || {}),
      ...computedPeriodRows.map((row) => row.currency).filter(Boolean)
    ])).sort();

    return {
      filters,
      accounts,
      account,
      currencyOptions,
      operationOptions,
      exchangeRateOptions,
      exchangeRateModeMeta,
      rateColumnLabel: exchangeRateModeMeta.columnLabel,
      rows: visibleRows,
      movementRows: computedPeriodRows,
      matchedMovementRows: matchedVisibleRows,
      openingRows,
      periodCurrencyCodes,
      summary: {
        opening: mapCurrencySummary(openingByCurrency),
        debit: mapCurrencySummary(debitTotalsByCurrency, (amount, currencyCode) => formatAmountWithCurrency(amount, currencyCode)),
        credit: mapCurrencySummary(creditTotalsByCurrency, (amount, currencyCode) => formatAmountWithCurrency(amount, currencyCode)),
        closing: mapCurrencySummary(closingByCurrency),
        valuation,
        movementCount: computedPeriodRows.length,
        visibleMovementCount: matchedVisibleRows.length,
        currencyCount: periodCurrencyCodes.length,
        hasSearch: !!searchNeedle
      }
    };
  }

  function normalizeSourceFocusPayload(payload){
    const safePayload = payload && typeof payload === 'object' ? payload : {};
    const number = toText(safePayload.number).toUpperCase();
    const normalized = {
      sourceKind: toText(safePayload.sourceKind || safePayload.kind),
      viewId: toText(safePayload.viewId),
      actionId: toText(safePayload.actionId),
      voucherType: toText(safePayload.voucherType),
      recordId: toText(safePayload.recordId),
      number,
      query: sanitizeSearch(safePayload.query || number || safePayload.recordId || ''),
      createdAt: Number(safePayload.createdAt) > 0 ? Number(safePayload.createdAt) : Date.now()
    };
    if(!normalized.query && !normalized.recordId && !normalized.number) return null;
    return normalized;
  }

  function writePendingSourceFocus(payload){
    const normalized = normalizeSourceFocusPayload(payload);
    if(!normalized) return null;
    return persistJsonState(SOURCE_FOCUS_STORAGE_KEY, normalized, normalizeSourceFocusPayload);
  }

  function consumePendingSourceFocus(){
    const normalized = normalizeSourceFocusPayload(readJsonStorage(SOURCE_FOCUS_STORAGE_KEY, null));
    try{ TAIF.core.utils.storageSet(SOURCE_FOCUS_STORAGE_KEY, ''); }catch{}
    return normalized;
  }

  const api = TAIF.generalLedger = TAIF.generalLedger || {};
  api.readFilters = readFilters;
  api.writeFilters = writeFilters;
  api.normalizeFilters = normalizeFilters;
  api.readAccounts = readAccounts;
  api.readEntryRecords = readEntryRecords;
  api.readLegacyEntryRecords = readLegacyEntryRecords;
  api.readServiceEntryRecords = readServiceEntryRecords;
  api.buildModel = buildModel;
  api.resolveTypeMeta = resolveTypeMeta;
  api.formatDate = formatDate;
  api.formatNumber = formatNumber;
  api.formatAmountWithCurrency = formatAmountWithCurrency;
  api.formatBalanceText = formatBalanceText;
  api.resolveBalanceDirection = resolveBalanceDirection;
  api.operationFilterOptions = OPERATION_FILTER_OPTIONS;
  api.exchangeRateModeOptions = EXCHANGE_RATE_MODE_OPTIONS;
  api.resolveExchangeRateModeMeta = resolveExchangeRateModeMeta;
  api.getSystemCurrencyCode = getSystemCurrencyCode;
  api.buildValuationSnapshots = buildValuationSnapshots;
  api.writePendingSourceFocus = writePendingSourceFocus;
  api.consumePendingSourceFocus = consumePendingSourceFocus;
})();
