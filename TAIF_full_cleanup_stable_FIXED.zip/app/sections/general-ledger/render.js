
(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  const api = TAIF.generalLedger;
  if(!TAIF || !api) return;

  const escapeHtml = typeof TAIF?.core?.utils?.escapeHtml === 'function'
    ? TAIF.core.utils.escapeHtml
    : (value) => String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');

  const escapeSelectorValue = typeof TAIF?.core?.utils?.escapeSelectorValue === 'function'
    ? TAIF.core.utils.escapeSelectorValue
    : (value) => String(value ?? '').replace(/\\/g, '\\\\').replace(/"/g, '\\"');

  const GENERAL_LEDGER_SOURCE_EYE_ICON = `
    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <path d="M2.75 12s3.4-6.25 9.25-6.25S21.25 12 21.25 12 17.85 18.25 12 18.25 2.75 12 2.75 12Z" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"></path>
      <circle cx="12" cy="12" r="2.75" fill="none" stroke="currentColor" stroke-width="1.9"></circle>
    </svg>
  `;

  const runtime = {
    panel: null,
    model: api.buildModel(),
    pendingFilters: api.readFilters(),
    detachPanelEvents: null,
    detachWindowEvents: [],
    selectedRowId: '',
    expandedCurrencies: new Set(),
    sidebarOpen: false
  };

  function getFilters(){
    return runtime.model?.filters || api.readFilters();
  }

  function getPendingFilters(){
    return api.normalizeFilters(runtime.pendingFilters || getFilters());
  }

  function safeArray(value){
    return Array.isArray(value) ? value : [];
  }

  function safeNumber(value, fallback = 0){
    const numeric = Number(value);
    return Number.isFinite(numeric) ? numeric : Number(fallback) || 0;
  }

  function normalizeCurrencyCode(value){
    return String(value ?? '').trim().toUpperCase().replace(/[^A-Z]/g, '');
  }

  function createMovementCountChip(totalCount, visibleCount, hasSearch){
    const safeTotal = Math.max(0, safeNumber(totalCount, 0));
    const safeVisible = Math.max(0, safeNumber(visibleCount, safeTotal));
    const label = hasSearch && safeVisible !== safeTotal
      ? `${api.formatNumber(safeVisible)} من ${api.formatNumber(safeTotal)} حركة`
      : `${api.formatNumber(safeTotal)} حركة`;
    return `<span class="general-ledger-footer__chip">${escapeHtml(label)}</span>`;
  }

  function resolveBalanceClassName(amount){
    const direction = api.resolveBalanceDirection(amount);
    return direction === 'credit'
      ? 'is-credit'
      : (direction === 'debit' ? 'is-debit' : 'is-zero');
  }

  function resolveBalanceSideLabel(amount){
    const direction = api.resolveBalanceDirection(amount);
    if(direction === 'credit') return 'دائن';
    if(direction === 'debit') return 'مدين';
    return 'متعادل';
  }

  function createAmountCurrencyMarkup(amount, currencyCode){
    const currency = normalizeCurrencyCode(currencyCode) || 'USD';
    return `
      <span class="general-ledger-amount-pair" dir="rtl">
        <span class="general-ledger-amount-pair__number">${escapeHtml(api.formatNumber(amount))}</span>
        <span class="general-ledger-amount-pair__code" dir="ltr">${escapeHtml(currency)}</span>
      </span>
    `;
  }

  function createDirectionalBalanceMarkup(amount, currencyCode){
    const numeric = safeNumber(amount, 0);
    const direction = api.resolveBalanceDirection(numeric);
    const sideLabel = resolveBalanceSideLabel(numeric);
    return `
      <span class="general-ledger-balance-inline general-ledger-balance-inline--${escapeHtml(direction)}" dir="rtl">
        <span class="general-ledger-balance-inline__amount">${createAmountCurrencyMarkup(numeric, currencyCode)}</span>
        <span class="general-ledger-balance-inline__side">${escapeHtml(sideLabel)}</span>
      </span>
    `;
  }

  function createBalanceAmountOnlyMarkup(amount, currencyCode){
    const numeric = safeNumber(amount, 0);
    const direction = api.resolveBalanceDirection(numeric);
    return `
      <span class="general-ledger-balance-inline general-ledger-balance-inline--${escapeHtml(direction)}" dir="rtl">
        <span class="general-ledger-balance-inline__amount">${createAmountCurrencyMarkup(numeric, currencyCode)}</span>
      </span>
    `;
  }

  function createEntryDateMarkup(value){
    const raw = String(value || '').trim();
    const match = raw.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if(!match) return escapeHtml(raw || '—');
    const day = match[1].padStart(2, '0');
    const month = match[2].padStart(2, '0');
    const year = match[3];
    return `
      <span class="general-ledger-entry-date" dir="rtl" aria-label="${escapeHtml(day)}/${escapeHtml(month)}/${escapeHtml(year)}">
        <span class="general-ledger-entry-date__part general-ledger-entry-date__part--day">${escapeHtml(day)}</span>
        <span class="general-ledger-entry-date__sep" aria-hidden="true">/</span>
        <span class="general-ledger-entry-date__part general-ledger-entry-date__part--month">${escapeHtml(month)}</span>
        <span class="general-ledger-entry-date__sep" aria-hidden="true">/</span>
        <span class="general-ledger-entry-date__part general-ledger-entry-date__part--year">${escapeHtml(year)}</span>
      </span>
    `;
  }


  function getRowSourceTarget(row){
    const source = row && typeof row === 'object' && row.sourceTarget && typeof row.sourceTarget === 'object'
      ? row.sourceTarget
      : null;
    if(!source) return null;
    const viewId = String(source.viewId || '').trim();
    const sourceKind = String(source.sourceKind || '').trim();
    const recordId = String(source.recordId || '').trim();
    const number = String(source.number || '').trim();
    if(!viewId || (!recordId && !number)) return null;
    return {
      sourceKind,
      viewId,
      actionId: String(source.actionId || '').trim(),
      voucherType: String(source.voucherType || '').trim(),
      recordId,
      number,
      label: String(source.label || '').trim()
    };
  }

  function createSourceButtonMarkup(row){
    const source = getRowSourceTarget(row);
    if(!source){
      return `
        <button class="general-ledger-source-btn general-ledger-source-btn--disabled" type="button" disabled aria-label="لا يوجد مصدر مباشر لهذه الحركة" title="لا يوجد مصدر مباشر لهذه الحركة">
          <span class="general-ledger-source-btn__icon" aria-hidden="true">${GENERAL_LEDGER_SOURCE_EYE_ICON}</span>
        </button>
      `;
    }
    const label = source.label || 'المصدر';
    const titleParts = ['فتح المصدر', label, source.number].filter(Boolean);
    return `
      <button class="general-ledger-source-btn" type="button" data-general-ledger-source-action="open" data-general-ledger-source-kind="${escapeHtml(source.sourceKind)}" data-general-ledger-source-view="${escapeHtml(source.viewId)}" data-general-ledger-source-action-id="${escapeHtml(source.actionId)}" data-general-ledger-source-voucher-type="${escapeHtml(source.voucherType)}" data-general-ledger-source-record-id="${escapeHtml(source.recordId)}" data-general-ledger-source-number="${escapeHtml(source.number)}" aria-label="${escapeHtml(titleParts.join(' - '))}" title="${escapeHtml(titleParts.join(' - '))}">
        <span class="general-ledger-source-btn__icon" aria-hidden="true">${GENERAL_LEDGER_SOURCE_EYE_ICON}</span>
      </button>
    `;
  }


  function resolveAggregateBalanceSideLabel(amount){
    const direction = api.resolveBalanceDirection(amount);
    if(direction === 'credit') return 'دائن - علينا';
    if(direction === 'debit') return 'مدين - لنا';
    return 'متعادل';
  }

  function createAggregateDirectionalBalanceMarkup(amount, currencyCode){
    const numeric = safeNumber(amount, 0);
    const direction = api.resolveBalanceDirection(numeric);
    const sideLabel = resolveAggregateBalanceSideLabel(numeric);
    return `
      <span class="general-ledger-balance-inline general-ledger-balance-inline--${escapeHtml(direction)}" dir="rtl">
        <span class="general-ledger-balance-inline__amount">${createAmountCurrencyMarkup(numeric, currencyCode)}</span>
        <span class="general-ledger-balance-inline__side">${escapeHtml(sideLabel)}</span>
      </span>
    `;
  }

  function createRecordRowMarkup(row){
    const isOpening = row.kind === 'opening';
    const amountCurrency = normalizeCurrencyCode(row.displayCurrency || row.currency) || 'USD';
    const counterpartText = String(row.counterpartText || '').trim();
    const typeLabel = String(row.typeLabel || '').trim();
    const auditLabel = String(row.auditLabel || '').trim();
    const referenceLabel = String(row.referenceLabel || '').trim();
    const referenceMarkup = isOpening
      ? ''
      : (referenceLabel ? `<div class="general-ledger-table__ref-main" dir="ltr">${escapeHtml(referenceLabel)}</div>` : '');

    return `
      <div class="general-ledger-table__row${runtime.selectedRowId === row.id ? ' is-selected' : ''}${isOpening ? ' general-ledger-table__row--opening' : ''}" role="row" data-general-ledger-row-id="${escapeHtml(row.id)}">
        <div class="general-ledger-table__cell general-ledger-table__cell--amount is-debit" role="cell">${createAmountCurrencyMarkup(row.debit || 0, amountCurrency)}</div>
        <div class="general-ledger-table__cell general-ledger-table__cell--amount is-credit" role="cell">${createAmountCurrencyMarkup(row.credit || 0, amountCurrency)}</div>
        <div class="general-ledger-table__cell general-ledger-table__cell--balance ${escapeHtml(row.balanceClass || 'is-zero')}" role="cell">${createBalanceAmountOnlyMarkup(row.runningBalance, amountCurrency)}</div>
        <div class="general-ledger-table__cell general-ledger-table__cell--date" role="cell">${createEntryDateMarkup(row.dateLabel || '—')}</div>
        <div class="general-ledger-table__cell general-ledger-table__cell--statement" role="cell">
          <div class="general-ledger-table__statement">${escapeHtml(row.description || '—')}</div>
          ${auditLabel ? `<div class="general-ledger-table__subtext">${escapeHtml(auditLabel)}</div>` : ''}
          ${row.status && row.status !== 'posted' && row.status !== 'opening' ? `<div class="general-ledger-table__subtext">${escapeHtml(row.statusLabel || '')}</div>` : ''}
          ${row.summary ? `<div class="general-ledger-table__subtext">${escapeHtml(row.summary)}</div>` : ''}
        </div>
        <div class="general-ledger-table__cell general-ledger-table__cell--type" role="cell">${typeLabel ? `<span class="general-ledger-badge ${escapeHtml(row.typeBadgeClass || 'general-ledger-badge--muted')}">${escapeHtml(typeLabel)}</span>` : ''}</div>
        <div class="general-ledger-table__cell general-ledger-table__cell--reference" role="cell">${referenceMarkup}</div>
        <div class="general-ledger-table__cell general-ledger-table__cell--counterpart" role="cell">
          ${counterpartText ? `<div class="general-ledger-table__statement">${escapeHtml(counterpartText)}</div>` : ''}
        </div>
        <div class="general-ledger-table__cell general-ledger-table__cell--source" role="cell">${createSourceButtonMarkup(row)}</div>
      </div>
    `;
  }


  function getCurrencyDomain(){
    const domain = TAIF.currencyDomain || TAIF.currencyManagement || null;
    return domain && typeof domain === 'object' ? domain : null;
  }

  function readCurrencyState(){
    const domain = getCurrencyDomain();
    if(!domain || typeof domain.readState !== 'function') return null;
    try{ return domain.readState(); }catch{ return null; }
  }

  function getSystemCurrencyCode(){
    const valuationCode = normalizeCurrencyCode(runtime.model?.summary?.valuation?.systemCurrencyCode);
    if(valuationCode) return valuationCode;
    const state = readCurrencyState();
    return normalizeCurrencyCode(state?.systemCurrencyCode) || 'USD';
  }

  function createValuationMetaMap(items){
    return safeArray(items).reduce((accumulator, item) => {
      const currency = normalizeCurrencyCode(item?.currency);
      if(!currency) return accumulator;
      const rawSystemValue = Number(item?.systemValue);
      const rawRate = Number(item?.valuationRate);
      const quantity = safeNumber(item?.quantity, 0);
      const systemValue = Number.isFinite(rawSystemValue) ? rawSystemValue : null;
      const valuationRate = rawRate > 0 ? rawRate : null;
      const rawTradingPurchaseRate = Number(item?.tradingPurchaseDisplayRate);
      const rawTradingSaleRate = Number(item?.tradingSaleDisplayRate);
      const rawTradingAverageRate = Number(item?.tradingAverageDisplayRate);
      const rawDisplayExchangeRate = Number(item?.displayExchangeRate);
      const tradingPurchaseDisplayRate = rawTradingPurchaseRate > 0 ? rawTradingPurchaseRate : null;
      const tradingSaleDisplayRate = rawTradingSaleRate > 0 ? rawTradingSaleRate : null;
      const tradingAverageDisplayRate = rawTradingAverageRate > 0 ? rawTradingAverageRate : null;
      const displayExchangeRate = rawDisplayExchangeRate > 0 ? rawDisplayExchangeRate : null;
      const displayExchangeRatePairLabel = normalizeRatePairLabel(item?.displayExchangeRatePairLabel);
      const tradingRatePairLabel = normalizeRatePairLabel(item?.tradingRatePairLabel || item?.displayExchangeRatePairLabel);
      const basisComplete = item?.basisComplete !== false;
      const basisWarning = String(item?.basisWarning || '').trim();
      const hasValue = item?.hasValue !== false && (
        systemValue !== null
        || valuationRate !== null
        || Math.abs(quantity) < 1e-9
      );
      accumulator.set(currency, {
        currency,
        quantity,
        systemValue,
        valuationRate,
        tradingPurchaseDisplayRate,
        tradingSaleDisplayRate,
        tradingAverageDisplayRate,
        displayExchangeRate,
        displayExchangeRatePairLabel,
        tradingRatePairLabel,
        hasValue,
        basisComplete,
        basisWarning
      });
      return accumulator;
    }, new Map());
  }

  function getValuationSummary(){
    const summary = runtime.model?.summary?.valuation;
    if(summary && typeof summary === 'object') return summary;
    return {
      systemCurrencyCode: getSystemCurrencyCode(),
      opening: [],
      closing: []
    };
  }


  function createSystemBalanceMarkupFromValue(amount){
    const systemCurrencyCode = getSystemCurrencyCode();
    if(!Number.isFinite(Number(amount))){
      return '<span class="general-ledger-balance-inline general-ledger-balance-inline--zero">—</span>';
    }
    return createDirectionalBalanceMarkup(Number(amount), systemCurrencyCode);
  }

  function createPrimaryBalanceMarkup(group){
    const mainMarkup = createSystemBalanceMarkupFromValue(group?.mainBalanceValue);
    const basisWarning = String(group?.basisWarning || '').trim();
    const metaLines = [];

    if(basisWarning){
      metaLines.push(`<div class="general-ledger-primary-balance__meta general-ledger-primary-balance__meta--warning">${escapeHtml(basisWarning)}</div>`);
    }

    if(!metaLines.length) return mainMarkup;
    return `
      <div class="general-ledger-primary-balance">
        ${mainMarkup}
        ${metaLines.join('')}
      </div>
    `;
  }

  function getExchangeRateModeMeta(){
    const modelMeta = runtime.model?.exchangeRateModeMeta;
    if(modelMeta && typeof modelMeta === 'object' && modelMeta.columnLabel) return modelMeta;
    const valuationMeta = runtime.model?.summary?.valuation;
    const mode = String(valuationMeta?.exchangeRateMode || getFilters().exchangeRateMode || '').trim();
    if(api && typeof api.resolveExchangeRateModeMeta === 'function') return api.resolveExchangeRateModeMeta(mode);
    return { value:mode || 'average-cost', label:'سعر التكلفة', columnLabel:'سعر التكلفة' };
  }

  function getExchangeRateColumnLabel(){
    return String(runtime.model?.rateColumnLabel || getExchangeRateModeMeta()?.columnLabel || 'سعر التكلفة').trim() || 'سعر التكلفة';
  }

  function shouldShowAverageBreakdownColumns(){
    const mode = String(runtime.model?.summary?.valuation?.exchangeRateMode || getFilters().exchangeRateMode || '').trim();
    return mode === 'average-cost';
  }

  function normalizeRatePairLabel(value){
    const safeValue = String(value || '').trim().toUpperCase().replace(/\s+/g, '');
    return /^[A-Z]{3}\/[A-Z]{3}$/.test(safeValue) ? safeValue : '';
  }

  function resolveFallbackRatePairLabel(currencyCode, systemCurrencyCode){
    const currency = normalizeCurrencyCode(currencyCode);
    const system = normalizeCurrencyCode(systemCurrencyCode) || 'USD';
    if(!currency) return '';
    return currency === system ? `${system}/${system}` : `${currency}/${system}`;
  }

  function createDisplayExchangeRateMarkup(displayRate, currencyCode, label, ratePairLabel = ''){
    const currency = normalizeCurrencyCode(currencyCode);
    const systemCurrencyCode = getSystemCurrencyCode();
    const safeLabel = String(label || 'سعر الصرف').trim() || 'سعر الصرف';
    const numericRate = Number(displayRate);
    if(!currency || !systemCurrencyCode || !(numericRate > 0)){
      return `<span class="general-ledger-average-cost general-ledger-average-cost--empty" title="${escapeHtml(`${safeLabel}: غير محدد`)}">—</span>`;
    }

    const pairLabel = normalizeRatePairLabel(ratePairLabel) || resolveFallbackRatePairLabel(currency, systemCurrencyCode);

    return `
      <span class="general-ledger-average-cost" title="${escapeHtml(`${safeLabel}: ${api.formatNumber(numericRate)} ${pairLabel}`)}">
        <span class="general-ledger-average-cost__amount" dir="ltr">${escapeHtml(api.formatNumber(numericRate))}</span>
      </span>
    `;
  }

  function createTradingRateMarkup(group, field, label){
    const numericRate = Number(group?.[field]);
    const pairLabel = group?.tradingRatePairLabel || group?.displayExchangeRatePairLabel || '';
    return createDisplayExchangeRateMarkup(numericRate, group?.currency, label, pairLabel);
  }

  function createExchangeRateMarkup(group){
    const currency = normalizeCurrencyCode(group?.currency);
    const systemCurrencyCode = getSystemCurrencyCode();
    const valuationRate = Number(group?.valuationRate);
    const columnLabel = String(group?.rateColumnLabel || getExchangeRateColumnLabel()).trim() || 'سعر التكلفة';
    const explicitDisplayRate = Number(group?.displayExchangeRate);
    const averageDisplayRate = Number(group?.tradingAverageDisplayRate);
    const displayRate = explicitDisplayRate > 0
      ? explicitDisplayRate
      : (averageDisplayRate > 0 ? averageDisplayRate : (currency === systemCurrencyCode ? 1 : (valuationRate > 0 ? (1 / valuationRate) : 0)));
    if(!currency || !systemCurrencyCode || !Number.isFinite(displayRate) || !(displayRate > 0)){
      return `<span class="general-ledger-average-cost general-ledger-average-cost--empty" title="${escapeHtml(`${columnLabel}: غير محدد`)}">—</span>`;
    }

    const pairLabel = group?.displayExchangeRatePairLabel || group?.tradingRatePairLabel || resolveFallbackRatePairLabel(currency, systemCurrencyCode);

    return `
      <span class="general-ledger-average-cost" title="${escapeHtml(`${columnLabel}: ${api.formatNumber(displayRate)} ${normalizeRatePairLabel(pairLabel) || resolveFallbackRatePairLabel(currency, systemCurrencyCode)}`)}">
        <span class="general-ledger-average-cost__amount" dir="ltr">${escapeHtml(api.formatNumber(displayRate))}</span>
      </span>
    `;
  }

  function createAggregateSystemBalanceChip(items){
    const systemCurrencyCode = getSystemCurrencyCode();
    let total = 0;
    let hasAny = false;

    safeArray(items).forEach((item) => {
      if(item?.hasValue === false) return;
      const systemValue = Number(item?.systemValue);
      if(Number.isFinite(systemValue)){
        total += systemValue;
        hasAny = true;
        return;
      }
      const quantity = safeNumber(item?.quantity, 0);
      if(Math.abs(quantity) < 1e-9){
        hasAny = true;
      }
    });

    if(!hasAny){
      return '<span class="general-ledger-footer__empty">—</span>';
    }

    const direction = api.resolveBalanceDirection(total);
    return `
      <span class="general-ledger-footer__chip general-ledger-footer__chip--balance general-ledger-footer__chip--${escapeHtml(direction)}">${createAggregateDirectionalBalanceMarkup(total, systemCurrencyCode)}</span>
    `;
  }


  function createLedgerSummaryBarMarkup(summary){
    const toggleLabel = runtime.sidebarOpen ? 'إخفاء الفلاتر' : 'إظهار الفلاتر';
    return `
      <section class="general-ledger-footer" aria-label="ملخص دفتر الأستاذ">
        <div class="general-ledger-footer__strip">
          <div class="general-ledger-footer__summary-group general-ledger-footer__summary-group--balance">
            <span class="general-ledger-footer__inline-label">إجمالي الرصيد</span>
            ${createAggregateSystemBalanceChip(summary.valuation?.closing || [])}
          </div>
          <div class="general-ledger-footer__summary-group general-ledger-footer__summary-group--count">
            <span class="general-ledger-footer__inline-label">عداد الحركات</span>
            ${createMovementCountChip(summary.movementCount, summary.visibleMovementCount, summary.hasSearch)}
          </div>
          <div class="general-ledger-footer__tools">
            <span class="general-ledger-footer__account-label">الحساب :</span>
            ${renderLedgerAccountSearchField()}
            <button class="general-ledger-footer__filter-toggle${runtime.sidebarOpen ? ' is-active' : ''}" type="button" data-general-ledger-action="toggle-sidebar" aria-expanded="${runtime.sidebarOpen ? 'true' : 'false'}" aria-controls="general-ledger-sidebar-panel" aria-label="${escapeHtml(toggleLabel)}" title="${escapeHtml(toggleLabel)}">
              <span class="general-ledger-footer__filter-toggle-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" focusable="false">
                  <path d="M4 6.25C4 5.56 4.56 5 5.25 5h13.5a1.25 1.25 0 0 1 .96 2.05l-5.21 6.25a1.25 1.25 0 0 0-.29.8v3.44a1.25 1.25 0 0 1-.55 1.04l-2 1.32A1.25 1.25 0 0 1 9.75 18.9v-4.8c0-.29-.1-.57-.29-.8L4.29 7.05A1.25 1.25 0 0 1 4 6.25Z" fill="currentColor"></path>
                </svg>
              </span>
            </button>
          </div>
        </div>
      </section>
    `;
  }

  function createSummaryMap(items){
    return safeArray(items).reduce((accumulator, item) => {
      const currency = normalizeCurrencyCode(item?.currency);
      if(!currency) return accumulator;
      accumulator.set(currency, {
        currency,
        value: safeNumber(item?.value, 0),
        text: String(item?.text || '').trim() || '—'
      });
      return accumulator;
    }, new Map());
  }

  function resolveOpeningDateLabel(group){
    const filterDate = String(runtime.model?.filters?.dateFrom || '').trim();
    if(filterDate) return api.formatDate(filterDate);
    const rawOpeningDate = String(group.openingRow?.date || '').trim();
    if(rawOpeningDate) return api.formatDate(rawOpeningDate);
    const firstVisibleDate = String(group.visibleRows?.[0]?.date || '').trim();
    if(firstVisibleDate) return api.formatDate(firstVisibleDate);
    return '—';
  }

  function createOpeningDetailRow(group){
    const openingValue = safeNumber(group.openingValue, 0);
    return {
      id: `opening-detail-${group.currency}`,
      kind: 'opening',
      debit: 0,
      credit: 0,
      displayCurrency: group.currency,
      runningBalance: openingValue,
      balanceClass: resolveBalanceClassName(openingValue),
      dateLabel: resolveOpeningDateLabel(group),
      description: 'الرصيد السابق',
      summary: '',
      typeLabel: '',
      typeBadgeClass: '',
      referenceLabel: '',
      counterpartText: '',
      counterpartCurrency: ''
    };
  }

  function buildCurrencyGroups(){
    const summary = runtime.model?.summary || {};
    const account = runtime.model?.account || null;
    const movementRows = safeArray(runtime.model?.movementRows);
    const matchedRows = safeArray(runtime.model?.matchedMovementRows);
    const openingRows = safeArray(runtime.model?.openingRows);
    if(!account || !(movementRows.length || openingRows.length)) return [];

    const openingMap = createSummaryMap(summary.opening);
    const debitMap = createSummaryMap(summary.debit);
    const creditMap = createSummaryMap(summary.credit);
    const closingMap = createSummaryMap(summary.closing);
    const valuationSummary = getValuationSummary();
    const closingValuationMap = createValuationMetaMap(valuationSummary.closing);
    const searchActive = !!summary.hasSearch;
    const visibleRows = searchActive ? matchedRows : movementRows;
    const visibleCurrencySet = new Set(visibleRows.map((row) => normalizeCurrencyCode(row?.currency)).filter(Boolean));
    if(searchActive && !visibleCurrencySet.size) return [];

    const allCurrencyCodes = safeArray(runtime.model?.periodCurrencyCodes)
      .map((code) => normalizeCurrencyCode(code))
      .filter(Boolean)
      .filter((code, index, array) => array.indexOf(code) === index)
      .filter((code) => !searchActive || visibleCurrencySet.has(code));

    return allCurrencyCodes.map((currencyCode) => {
      const currencyFullRows = movementRows.filter((row) => normalizeCurrencyCode(row?.currency) === currencyCode);
      const currencyVisibleRows = searchActive
        ? matchedRows.filter((row) => normalizeCurrencyCode(row?.currency) === currencyCode)
        : currencyFullRows.slice();
      const openingRow = openingRows.find((row) => normalizeCurrencyCode(row?.currency) === currencyCode) || null;
      const openingMeta = openingMap.get(currencyCode) || { value:0, text: api.formatBalanceText(0, currencyCode) };
      const debitMeta = debitMap.get(currencyCode) || { value:0, text: api.formatAmountWithCurrency(0, currencyCode) };
      const creditMeta = creditMap.get(currencyCode) || { value:0, text: api.formatAmountWithCurrency(0, currencyCode) };
      const lastRunningBalance = safeNumber(currencyFullRows[currencyFullRows.length - 1]?.runningBalance, openingMeta.value);
      const closingMeta = closingMap.get(currencyCode) || { value:lastRunningBalance, text: api.formatBalanceText(lastRunningBalance, currencyCode) };
      const closingValuationMeta = closingValuationMap.get(currencyCode) || null;
      const mainBalanceValue = closingValuationMeta?.hasValue ? safeNumber(closingValuationMeta?.systemValue, 0) : null;
      const rateColumnLabel = String(valuationSummary.rateColumnLabel || getExchangeRateColumnLabel()).trim() || 'سعر التكلفة';
      return {
        currency: currencyCode,
        accountNo: String(account.accountNo || '').trim() || '—',
        accountName: String(account.name || '').trim() || 'بدون اسم',
        openingRow,
        fullRows: currencyFullRows,
        visibleRows: currencyVisibleRows,
        openingValue: openingMeta.value,
        openingText: openingMeta.text,
        debitValue: debitMeta.value,
        debitText: debitMeta.text,
        creditValue: creditMeta.value,
        creditText: creditMeta.text,
        closingValue: closingMeta.value,
        closingText: closingMeta.text,
        closingClass: resolveBalanceClassName(closingMeta.value),
        mainBalanceValue,
        mainBalanceClass: Number.isFinite(mainBalanceValue) ? resolveBalanceClassName(mainBalanceValue) : 'is-zero',
        valuationRate: Number(closingValuationMeta?.valuationRate) > 0 ? Number(closingValuationMeta.valuationRate) : null,
        tradingPurchaseDisplayRate: Number(closingValuationMeta?.tradingPurchaseDisplayRate) > 0 ? Number(closingValuationMeta.tradingPurchaseDisplayRate) : null,
        tradingSaleDisplayRate: Number(closingValuationMeta?.tradingSaleDisplayRate) > 0 ? Number(closingValuationMeta.tradingSaleDisplayRate) : null,
        tradingAverageDisplayRate: Number(closingValuationMeta?.tradingAverageDisplayRate) > 0 ? Number(closingValuationMeta.tradingAverageDisplayRate) : null,
        displayExchangeRate: Number(closingValuationMeta?.displayExchangeRate) > 0 ? Number(closingValuationMeta.displayExchangeRate) : null,
        displayExchangeRatePairLabel: normalizeRatePairLabel(closingValuationMeta?.displayExchangeRatePairLabel),
        tradingRatePairLabel: normalizeRatePairLabel(closingValuationMeta?.tradingRatePairLabel || closingValuationMeta?.displayExchangeRatePairLabel),
        rateColumnLabel,
        exchangeRateMode: String(valuationSummary.exchangeRateMode || getFilters().exchangeRateMode || 'average-cost').trim() || 'average-cost',
        basisComplete: closingValuationMeta?.basisComplete !== false,
        basisWarning: String(closingValuationMeta?.basisWarning || '').trim(),
        visibleCount: currencyVisibleRows.length,
        totalCount: currencyFullRows.length,
        isExpanded: runtime.expandedCurrencies.has(currencyCode)
      };
    }).filter((group) => {
      const hasOpeningOnly = Math.abs(safeNumber(group.openingValue, 0)) > 1e-9 || !!group.openingRow;
      return (group.fullRows.length || hasOpeningOnly) && (!searchActive || group.visibleRows.length);
    });
  }

  function createDetailTableMarkup(group){
    const rows = getFilters().hideOpeningBalance
      ? safeArray(group.visibleRows)
      : [createOpeningDetailRow(group), ...safeArray(group.visibleRows)];
    return `
      <section class="general-ledger-currency-detail" aria-label="تفاصيل ${escapeHtml(group.currency)}">
        <div class="general-ledger-detail-table" role="table" aria-label="تفاصيل حركة ${escapeHtml(group.currency)}">
          <div class="general-ledger-table__row general-ledger-table__row--head" role="row">
            <div class="general-ledger-table__head general-ledger-table__head--amount" role="columnheader">مدين</div>
            <div class="general-ledger-table__head general-ledger-table__head--amount" role="columnheader">دائن</div>
            <div class="general-ledger-table__head general-ledger-table__head--amount" role="columnheader">الرصيد</div>
            <div class="general-ledger-table__head" role="columnheader">تاريخ القيد</div>
            <div class="general-ledger-table__head" role="columnheader">البيان</div>
            <div class="general-ledger-table__head" role="columnheader">العملية</div>
            <div class="general-ledger-table__head" role="columnheader">رقم الحركة</div>
            <div class="general-ledger-table__head" role="columnheader">الحساب المقابل</div>
            <div class="general-ledger-table__head general-ledger-table__head--source" role="columnheader">المصدر</div>
          </div>
          <div class="general-ledger-detail-table__body" role="rowgroup">
            ${rows.map((row) => createRecordRowMarkup(row)).join('')}
          </div>
        </div>
      </section>
    `;
  }


  function createCurrencyCountMarkup(group){
    if(group.totalCount === group.visibleCount){
      return `
        <strong class="general-ledger-currency-row__count-main">${escapeHtml(String(group.totalCount))}</strong>
        <span class="general-ledger-currency-row__count-sub">حركة</span>
      `;
    }

    return `
      <strong class="general-ledger-currency-row__count-main">${escapeHtml(String(group.visibleCount))}</strong>
      <span class="general-ledger-currency-row__count-sub">من ${escapeHtml(String(group.totalCount))}</span>
    `;
  }

  function createCurrencyGroupMarkup(group){
    const averageBreakdownMarkup = shouldShowAverageBreakdownColumns()
      ? `
          <div class="general-ledger-currency-row__cell general-ledger-currency-row__cell--amount general-ledger-currency-row__cell--average-breakdown general-ledger-currency-row__cell--purchase-rate" role="cell">${createTradingRateMarkup(group, 'tradingPurchaseDisplayRate', 'سعر شراء')}</div>
          <div class="general-ledger-currency-row__cell general-ledger-currency-row__cell--amount general-ledger-currency-row__cell--average-breakdown general-ledger-currency-row__cell--sale-rate" role="cell">${createTradingRateMarkup(group, 'tradingSaleDisplayRate', 'سعر مبيع')}</div>
        `
      : '';
    return `
      <article class="general-ledger-currency-card${group.isExpanded ? ' is-open' : ''}" data-general-ledger-currency-card="${escapeHtml(group.currency)}">
        <div class="general-ledger-currency-row" role="row">
          <div class="general-ledger-currency-row__cell general-ledger-currency-row__cell--action" role="cell">
            <button class="general-ledger-currency-row__action" type="button" data-general-ledger-action="toggle-currency" data-general-ledger-currency="${escapeHtml(group.currency)}" aria-expanded="${group.isExpanded ? 'true' : 'false'}" aria-label="${group.isExpanded ? 'إخفاء' : 'عرض'} تفاصيل ${escapeHtml(group.currency)}">${group.isExpanded ? 'إخفاء' : 'عرض'}</button>
          </div>
          <div class="general-ledger-currency-row__cell general-ledger-currency-row__cell--account-name" role="cell">${escapeHtml(group.accountName)}</div>
          <div class="general-ledger-currency-row__cell general-ledger-currency-row__cell--account-no" role="cell" dir="ltr">${escapeHtml(group.accountNo)}</div>
          <div class="general-ledger-currency-row__cell general-ledger-currency-row__cell--currency" role="cell" dir="ltr">${escapeHtml(group.currency)}</div>
          <div class="general-ledger-currency-row__cell general-ledger-currency-row__cell--count" role="cell">${createCurrencyCountMarkup(group)}</div>
          <div class="general-ledger-currency-row__cell general-ledger-currency-row__cell--amount is-debit" role="cell">${createAmountCurrencyMarkup(group.debitValue, group.currency)}</div>
          <div class="general-ledger-currency-row__cell general-ledger-currency-row__cell--amount is-credit" role="cell">${createAmountCurrencyMarkup(group.creditValue, group.currency)}</div>
          <div class="general-ledger-currency-row__cell general-ledger-currency-row__cell--amount general-ledger-currency-row__cell--balance ${escapeHtml(group.closingClass || 'is-zero')}" role="cell">${createBalanceAmountOnlyMarkup(group.closingValue, group.currency)}</div>
          ${averageBreakdownMarkup}
          <div class="general-ledger-currency-row__cell general-ledger-currency-row__cell--amount general-ledger-currency-row__cell--average-cost" role="cell">${createExchangeRateMarkup(group)}</div>
          <div class="general-ledger-currency-row__cell general-ledger-currency-row__cell--amount general-ledger-currency-row__cell--balance general-ledger-currency-row__cell--primary-balance ${escapeHtml(group.mainBalanceClass || 'is-zero')}" role="cell">${createPrimaryBalanceMarkup(group)}</div>
        </div>
        ${group.isExpanded ? createDetailTableMarkup(group) : ''}
      </article>
    `;
  }

  function createRowsMarkup(){
    const account = runtime.model?.account || null;
    const movementRows = safeArray(runtime.model?.movementRows);
    const matchedRows = safeArray(runtime.model?.matchedMovementRows);
    const openingRows = safeArray(runtime.model?.openingRows);
    const filters = getFilters();

    if(!account){
      return `
        <div class="general-ledger-empty-state" data-general-ledger-empty="select-account">
          <div class="general-ledger-empty-state__badge">دفتر الأستاذ</div>
          <h3 class="general-ledger-empty-state__title">اختر حسابًا لبدء الاستعراض</h3>
          <p class="general-ledger-empty-state__text">من الجهة اليمنى اختر الحساب والفترة المطلوبة، وسيظهر الرصيد الافتتاحي والحركات والرصد الجاري بشكل واضح ومتسلسل.</p>
        </div>
      `;
    }

    if(!(movementRows.length || openingRows.length)){
      return `
        <div class="general-ledger-empty-state" data-general-ledger-empty="no-movements">
          <div class="general-ledger-empty-state__badge">لا توجد حركات</div>
          <h3 class="general-ledger-empty-state__title">الحساب المختار لا يحتوي على قيود ضمن المدة الحالية</h3>
          <p class="general-ledger-empty-state__text">غيّر الفترة أو العملة أو نوع العملية لرؤية نتائج أوسع.</p>
        </div>
      `;
    }

    if(filters.search && !matchedRows.length){
      return `
        <div class="general-ledger-empty-state" data-general-ledger-empty="search-miss">
          <div class="general-ledger-empty-state__badge">لا يوجد تطابق</div>
          <h3 class="general-ledger-empty-state__title">لم يتم العثور على سطور تطابق البحث الحالي</h3>
          <p class="general-ledger-empty-state__text">تم الحفاظ على إجماليات الفترة الحقيقية في البطاقات العلوية، بينما لم يظهر داخل السجل أي سطر مطابق للبحث.</p>
        </div>
      `;
    }

    const currencyGroups = buildCurrencyGroups();
    const systemCurrencyCode = getSystemCurrencyCode();
    const rateColumnLabel = getExchangeRateColumnLabel();
    const showAverageBreakdown = shouldShowAverageBreakdownColumns();
    const averageBreakdownHeadMarkup = showAverageBreakdown
      ? `
          <div class="general-ledger-currency-list__head-cell general-ledger-currency-list__head-cell--amount general-ledger-currency-list__head-cell--average-breakdown">سعر شراء</div>
          <div class="general-ledger-currency-list__head-cell general-ledger-currency-list__head-cell--amount general-ledger-currency-list__head-cell--average-breakdown">سعر مبيع</div>
        `
      : '';

    return `
      <div class="general-ledger-currency-list${showAverageBreakdown ? ' general-ledger-currency-list--with-average-breakdown' : ''}" role="table" aria-label="سجل العملات في دفتر الأستاذ">
        <div class="general-ledger-currency-list__head" role="row">
          <div class="general-ledger-currency-list__head-cell general-ledger-currency-list__head-cell--action">التفاصيل</div>
          <div class="general-ledger-currency-list__head-cell general-ledger-currency-list__head-cell--account-name">اسم الحساب</div>
          <div class="general-ledger-currency-list__head-cell">رقم الحساب</div>
          <div class="general-ledger-currency-list__head-cell">العملة</div>
          <div class="general-ledger-currency-list__head-cell">عدد الحركات</div>
          <div class="general-ledger-currency-list__head-cell general-ledger-currency-list__head-cell--amount">إجمالي المدين</div>
          <div class="general-ledger-currency-list__head-cell general-ledger-currency-list__head-cell--amount">إجمالي الدائن</div>
          <div class="general-ledger-currency-list__head-cell general-ledger-currency-list__head-cell--amount">الرصيد</div>
          ${averageBreakdownHeadMarkup}
          <div class="general-ledger-currency-list__head-cell general-ledger-currency-list__head-cell--amount">${escapeHtml(rateColumnLabel)}</div>
          <div class="general-ledger-currency-list__head-cell general-ledger-currency-list__head-cell--amount">الرصيد الرئيسي${systemCurrencyCode ? ` <span dir="ltr">${escapeHtml(systemCurrencyCode)}</span>` : ''}</div>
        </div>
        ${currencyGroups.map((group) => createCurrencyGroupMarkup(group)).join('')}
      </div>
    `;
  }

  const DATE_PICKER_MONTH_NAMES = Array.isArray(TAIF?.core?.constants?.datePickerMonthNames)
    ? TAIF.core.constants.datePickerMonthNames
    : ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];

  const DATE_PICKER_WEEKDAY_LABELS = Array.isArray(TAIF?.core?.constants?.datePickerWeekdayLabels)
    ? TAIF.core.constants.datePickerWeekdayLabels
    : ['ح', 'ن', 'ث', 'ر', 'خ', 'ج', 'س'];

  const GENERAL_LEDGER_PICKER_ICON = '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m5.25 7.5 4.75 5 4.75-5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
  const GENERAL_LEDGER_PICKER_CHECK_ICON = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m5 13 4 4L19 7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
  const GENERAL_LEDGER_DATE_ICON = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M7 3v3M17 3v3M4 9h16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><rect x="4" y="5" width="16" height="15" rx="3" fill="none" stroke="currentColor" stroke-width="2"></rect></svg>';
  const GENERAL_LEDGER_DATE_PREV_ICON = '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m12.5 4.5-5 5 5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
  const GENERAL_LEDGER_DATE_NEXT_ICON = '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m7.5 4.5 5 5-5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>';

  function ensureFilterUiState(){
    if(!runtime.ui || typeof runtime.ui !== 'object'){
      runtime.ui = {
        openPickerKind: '',
        openPickerField: '',
        openPickerPlacement: 'bottom',
        accountQuery: '',
        accountDirty: false,
        dateViewByField: { dateFrom:'days', dateTo:'days' },
        dateMonthCursorByField: { dateFrom:'', dateTo:'' },
        dateDraftsByField: Object.create(null)
      };
    }
    runtime.ui.dateViewByField = runtime.ui.dateViewByField && typeof runtime.ui.dateViewByField === 'object'
      ? runtime.ui.dateViewByField
      : { dateFrom:'days', dateTo:'days' };
    runtime.ui.dateMonthCursorByField = runtime.ui.dateMonthCursorByField && typeof runtime.ui.dateMonthCursorByField === 'object'
      ? runtime.ui.dateMonthCursorByField
      : { dateFrom:'', dateTo:'' };
    runtime.ui.dateDraftsByField = runtime.ui.dateDraftsByField && typeof runtime.ui.dateDraftsByField === 'object'
      ? runtime.ui.dateDraftsByField
      : Object.create(null);
    runtime.ui.accountQuery = String(runtime.ui.accountQuery || '');
    runtime.ui.accountDirty = !!runtime.ui.accountDirty;
    runtime.ui.openPickerKind = String(runtime.ui.openPickerKind || '');
    runtime.ui.openPickerField = String(runtime.ui.openPickerField || '');
    runtime.ui.openPickerPlacement = normalizeFilterPickerPlacement(runtime.ui.openPickerPlacement);
    return runtime.ui;
  }

  function normalizeFilterPickerPlacement(value = 'bottom'){
    const placement = String(value || '').trim().toLowerCase();
    return placement === 'top' ? 'top' : 'bottom';
  }

  function normalizeGeneralLedgerLookupText(value){
    return String(value ?? '')
      .trim()
      .toLowerCase()
      .replace(/[ً-ٰٟ]/g, '')
      .replace(/[أإآٱ]/g, 'ا')
      .replace(/ة/g, 'ه')
      .replace(/ى/g, 'ي')
      .replace(/ؤ/g, 'و')
      .replace(/ئ/g, 'ي')
      .replace(/ـ/g, '')
      .replace(/[^a-z0-9؀-ۿ\s]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function formatLedgerAccountLookupLabel(account){
    const accountNo = String(account?.accountNo || '').trim();
    const name = String(account?.name || '').trim();
    if(accountNo && name) return `${accountNo} — ${name}`;
    return accountNo || name || '';
  }

  function getPendingSelectedAccount(){
    const filters = getPendingFilters();
    const accountNo = String(filters.accountNo || '').trim();
    if(!accountNo) return null;
    return safeArray(runtime.model?.accounts).find((account) => String(account?.accountNo || '').trim() === accountNo) || null;
  }

  function syncFilterUiStateWithPendingFilters({ forceAccountLabel = false, closePickers = false, resetDateState = false } = {}){
    const ui = ensureFilterUiState();
    const selectedAccount = getPendingSelectedAccount();
    const selectedLabel = selectedAccount ? formatLedgerAccountLookupLabel(selectedAccount) : '';
    if(forceAccountLabel || !ui.accountDirty){
      ui.accountQuery = selectedLabel;
      ui.accountDirty = false;
    }
    if(closePickers){
      ui.openPickerKind = '';
      ui.openPickerField = '';
      ui.openPickerPlacement = 'bottom';
    }
    if(resetDateState){
      ui.dateViewByField = { dateFrom:'days', dateTo:'days' };
      ui.dateMonthCursorByField = { dateFrom:'', dateTo:'' };
      ui.dateDraftsByField = Object.create(null);
    }
    return ui;
  }

  function isFilterPickerOpen(kind, field = ''){
    const ui = ensureFilterUiState();
    return ui.openPickerKind === String(kind || '') && ui.openPickerField === String(field || '');
  }

  function hasOpenFilterPicker(){
    const ui = ensureFilterUiState();
    return !!(ui.openPickerKind && ui.openPickerField);
  }

  function closeFilterPicker(){
    const ui = ensureFilterUiState();
    ui.openPickerKind = '';
    ui.openPickerField = '';
    ui.openPickerPlacement = 'bottom';
  }

  function openFilterPicker(kind, field = '', placement = 'bottom'){
    const ui = ensureFilterUiState();
    ui.openPickerKind = String(kind || '');
    ui.openPickerField = String(field || '');
    ui.openPickerPlacement = normalizeFilterPickerPlacement(placement);
  }

  function getFilterPickerPlacement(kind, field = ''){
    const ui = ensureFilterUiState();
    if(ui.openPickerKind !== String(kind || '') || ui.openPickerField !== String(field || '')) return 'bottom';
    return normalizeFilterPickerPlacement(ui.openPickerPlacement);
  }

  function buildLedgerAccountSearchResults(query, limit = 12){
    const accounts = safeArray(runtime.model?.accounts).slice();
    if(!accounts.length) return [];
    const safeLimit = Math.max(1, Number(limit) || 12);
    const rawQuery = String(query || '').trim();
    const queryNeedle = normalizeGeneralLedgerLookupText(rawQuery);
    const collator = new Intl.Collator('en', { numeric:true, sensitivity:'base' });

    const scored = accounts.map((account) => {
      const accountNo = String(account?.accountNo || '').trim();
      const accountName = String(account?.name || '').trim();
      const label = formatLedgerAccountLookupLabel(account);
      const haystack = normalizeGeneralLedgerLookupText(`${accountNo} ${accountName} ${label}`);
      const exactNo = rawQuery && accountNo === rawQuery;
      const exactName = queryNeedle && normalizeGeneralLedgerLookupText(accountName) === queryNeedle;
      const exactLabel = queryNeedle && normalizeGeneralLedgerLookupText(label) === queryNeedle;
      const startsNo = rawQuery && accountNo.startsWith(rawQuery);
      const startsName = queryNeedle && normalizeGeneralLedgerLookupText(accountName).startsWith(queryNeedle);
      const includes = !queryNeedle || haystack.includes(queryNeedle) || (rawQuery && accountNo.includes(rawQuery));
      const score = exactNo ? 0 : (exactName || exactLabel ? 1 : (startsNo ? 2 : (startsName ? 3 : 4)));
      return { account, includes, score, label, accountNo, accountName };
    }).filter((entry) => entry.includes);

    if(!queryNeedle && !rawQuery){
      return scored
        .sort((left, right) => collator.compare(left.accountNo, right.accountNo) || String(left.accountName).localeCompare(String(right.accountName), 'ar'))
        .slice(0, safeLimit)
        .map((entry) => entry.account);
    }

    return scored
      .sort((left, right) => {
        if(left.score !== right.score) return left.score - right.score;
        const noDelta = collator.compare(left.accountNo, right.accountNo);
        if(noDelta) return noDelta;
        return String(left.accountName).localeCompare(String(right.accountName), 'ar');
      })
      .slice(0, safeLimit)
      .map((entry) => entry.account);
  }

  function resolveLedgerAccountFromQuery(query){
    const rawQuery = String(query || '').trim();
    if(!rawQuery) return null;
    const accounts = safeArray(runtime.model?.accounts);
    const queryNeedle = normalizeGeneralLedgerLookupText(rawQuery);
    const exactMatches = accounts.filter((account) => {
      const accountNo = String(account?.accountNo || '').trim();
      const accountName = String(account?.name || '').trim();
      const label = formatLedgerAccountLookupLabel(account);
      return accountNo === rawQuery
        || normalizeGeneralLedgerLookupText(accountName) === queryNeedle
        || normalizeGeneralLedgerLookupText(label) === queryNeedle;
    });
    if(exactMatches.length === 1) return exactMatches[0];

    const prefixMatches = accounts.filter((account) => {
      const accountNo = String(account?.accountNo || '').trim();
      const accountName = normalizeGeneralLedgerLookupText(account?.name || '');
      return accountNo.startsWith(rawQuery) || (queryNeedle && accountName.startsWith(queryNeedle));
    });
    if(prefixMatches.length === 1) return prefixMatches[0];
    return null;
  }

  function ensureAccountSelectionBeforeApply(){
    const ui = ensureFilterUiState();
    if(!ui.accountDirty) return;
    const resolved = resolveLedgerAccountFromQuery(ui.accountQuery);
    if(resolved){
      updatePendingFilter('accountNo', resolved.accountNo);
      ui.accountQuery = formatLedgerAccountLookupLabel(resolved);
      ui.accountDirty = false;
      return;
    }
    if(!String(ui.accountQuery || '').trim()){
      updatePendingFilter('accountNo', '');
      ui.accountDirty = false;
      ui.accountQuery = '';
    }
  }

  function todayInputValue(){
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function parseFilterIsoDate(value){
    const safeValue = String(value || '').trim();
    if(!/^\d{4}-\d{2}-\d{2}$/.test(safeValue)) return null;
    const [year, month, day] = safeValue.split('-').map((part) => Number(part));
    const date = new Date(year, month - 1, day);
    if(Number.isNaN(date.getTime())) return null;
    if(date.getFullYear() !== year || date.getMonth() !== (month - 1) || date.getDate() !== day) return null;
    return date;
  }

  function toFilterIsoDate(date){
    if(!(date instanceof Date) || Number.isNaN(date.getTime())) return todayInputValue();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function parseFilterMonthCursor(value){
    const safeValue = String(value || '').trim();
    if(!/^\d{4}-\d{2}$/.test(safeValue)) return null;
    const [year, month] = safeValue.split('-').map((part) => Number(part));
    if(!Number.isInteger(year) || !Number.isInteger(month) || month < 1 || month > 12) return null;
    return { year, monthIndex: month - 1 };
  }

  function toFilterMonthCursor(date){
    if(!(date instanceof Date) || Number.isNaN(date.getTime())) return todayInputValue().slice(0, 7);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
  }

  function normalizeFilterDateView(value){
    return String(value || '').trim() === 'month-year' ? 'month-year' : 'days';
  }

  function shiftFilterMonthCursor(value, offset = 0){
    const parsed = parseFilterMonthCursor(value) || parseFilterMonthCursor(todayInputValue().slice(0, 7));
    const date = new Date(parsed.year, parsed.monthIndex + Number(offset || 0), 1);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
  }

  function resolveFilterMonthCursor(fieldKey, selectedValue){
    const ui = ensureFilterUiState();
    const safeFieldKey = String(fieldKey || '').trim();
    const openCursor = parseFilterMonthCursor(ui.dateMonthCursorByField[safeFieldKey]);
    if(isFilterPickerOpen('date', safeFieldKey) && openCursor) return ui.dateMonthCursorByField[safeFieldKey];
    const selectedDate = parseFilterIsoDate(selectedValue);
    return toFilterMonthCursor(selectedDate || new Date());
  }

  function getFilterDateManualParts(fieldKey, value){
    const ui = ensureFilterUiState();
    const safeFieldKey = String(fieldKey || '').trim();
    const draft = safeFieldKey ? ui.dateDraftsByField[safeFieldKey] : null;
    if(draft && typeof draft === 'object'){
      return {
        day: String(draft.day || ''),
        month: String(draft.month || ''),
        year: String(draft.year || '')
      };
    }
    const parsed = parseFilterIsoDate(value);
    return {
      day: parsed ? String(parsed.getDate()).padStart(2, '0') : '',
      month: parsed ? String(parsed.getMonth() + 1).padStart(2, '0') : '',
      year: parsed ? String(parsed.getFullYear()) : ''
    };
  }

  function sanitizeFilterDatePart(partKey, value){
    const digits = String(value || '').replace(/\D+/g, '');
    return String(partKey || '').trim() === 'year' ? digits.slice(0, 4) : digits.slice(0, 2);
  }

  function composeFilterIsoDateFromParts(parts){
    const day = String(parts?.day || '').trim();
    const month = String(parts?.month || '').trim();
    const year = String(parts?.year || '').trim();
    if(!day && !month && !year) return '';
    if(day.length !== 2 || month.length !== 2 || year.length !== 4) return null;
    const iso = `${year}-${month}-${day}`;
    return parseFilterIsoDate(iso) ? iso : null;
  }

  function readFilterDateManualParts(fieldKey){
    if(!(runtime.panel instanceof HTMLElement)) return null;
    const safeFieldKey = String(fieldKey || '').trim();
    if(!safeFieldKey) return null;
    const root = runtime.panel.querySelector(`[data-general-ledger-date-picker="true"][data-general-ledger-date-field="${escapeSelectorValue(safeFieldKey)}"]`);
    if(!(root instanceof HTMLElement)) return null;
    const read = (partKey) => {
      const input = root.querySelector(`[data-general-ledger-date-part="${partKey}"]`);
      return input instanceof HTMLInputElement ? String(input.value || '') : '';
    };
    return { day: read('day'), month: read('month'), year: read('year') };
  }

  function updateFilterDatePart(fieldKey, partKey, value){
    const safeFieldKey = String(fieldKey || '').trim();
    const safePartKey = String(partKey || '').trim();
    if(!safeFieldKey || !safePartKey) return;
    const ui = ensureFilterUiState();
    const currentParts = readFilterDateManualParts(safeFieldKey) || getFilterDateManualParts(safeFieldKey, getPendingFilters()[safeFieldKey] || '');
    currentParts[safePartKey] = sanitizeFilterDatePart(safePartKey, value);
    ui.dateDraftsByField[safeFieldKey] = currentParts;
    const isoValue = composeFilterIsoDateFromParts(currentParts);
    if(isoValue === ''){
      delete ui.dateDraftsByField[safeFieldKey];
      updatePendingFilter(safeFieldKey, '');
      return;
    }
    if(isoValue){
      delete ui.dateDraftsByField[safeFieldKey];
      updatePendingFilter(safeFieldKey, isoValue);
      ui.dateMonthCursorByField[safeFieldKey] = isoValue.slice(0, 7);
    }
  }

  function formatFilterDatePickerMonthLabel(monthCursor){
    const parsed = parseFilterMonthCursor(monthCursor) || parseFilterMonthCursor(toFilterMonthCursor(new Date()));
    return `${DATE_PICKER_MONTH_NAMES[parsed.monthIndex] || ''} ${parsed.year}`.trim();
  }

  function buildFilterDatePickerCells(monthCursor, selectedValue){
    const parsed = parseFilterMonthCursor(monthCursor) || parseFilterMonthCursor(toFilterMonthCursor(new Date()));
    const selectedIso = parseFilterIsoDate(selectedValue) ? String(selectedValue) : '';
    const todayIso = todayInputValue();
    const monthStart = new Date(parsed.year, parsed.monthIndex, 1);
    const gridStart = new Date(parsed.year, parsed.monthIndex, 1 - monthStart.getDay());
    return Array.from({ length:42 }, (_, index) => {
      const cellDate = new Date(gridStart.getFullYear(), gridStart.getMonth(), gridStart.getDate() + index);
      const isoValue = toFilterIsoDate(cellDate);
      return {
        value: isoValue,
        label: String(cellDate.getDate()),
        outsideMonth: cellDate.getMonth() !== parsed.monthIndex,
        isToday: isoValue === todayIso,
        isSelected: isoValue === selectedIso
      };
    });
  }

  function buildFilterDatePickerMonthChoices(monthCursor){
    const parsed = parseFilterMonthCursor(monthCursor) || parseFilterMonthCursor(toFilterMonthCursor(new Date()));
    return DATE_PICKER_MONTH_NAMES.map((label, monthIndex) => ({
      label,
      monthCursor: `${parsed.year}-${String(monthIndex + 1).padStart(2, '0')}`,
      isActive: monthIndex === parsed.monthIndex
    }));
  }

  function renderFilterDatePickerDayButton(fieldKey, cell){
    const classes = [
      'general-ledger-date-picker__day',
      cell.outsideMonth ? 'is-outside' : '',
      cell.isToday ? 'is-today' : '',
      cell.isSelected ? 'is-selected' : ''
    ].filter(Boolean).join(' ');
    return `
      <button class="${classes}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="grid" data-general-ledger-date-action="select-day" data-general-ledger-date-field="${escapeHtml(fieldKey)}" data-general-ledger-date-value="${escapeHtml(cell.value)}" aria-pressed="${cell.isSelected ? 'true' : 'false'}" aria-label="اختيار التاريخ ${escapeHtml(cell.value)}">
        <span dir="ltr">${escapeHtml(cell.label)}</span>
      </button>
    `;
  }

  function renderFilterDatePickerMonthButton(fieldKey, monthChoice){
    const classes = [
      'general-ledger-date-picker__month',
      monthChoice.isActive ? 'is-active' : ''
    ].filter(Boolean).join(' ');
    return `
      <button class="${classes}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="grid" data-general-ledger-date-action="pick-month" data-general-ledger-date-field="${escapeHtml(fieldKey)}" data-general-ledger-date-month="${escapeHtml(monthChoice.monthCursor)}" aria-pressed="${monthChoice.isActive ? 'true' : 'false'}" aria-label="اختيار شهر ${escapeHtml(monthChoice.label)}">
        <span>${escapeHtml(monthChoice.label)}</span>
      </button>
    `;
  }

  function renderGeneralLedgerDateField(fieldKey, label, value){
    const safeFieldKey = String(fieldKey || '').trim();
    const ui = ensureFilterUiState();
    const monthCursor = resolveFilterMonthCursor(safeFieldKey, value);
    const isOpen = isFilterPickerOpen('date', safeFieldKey);
    const placement = getFilterPickerPlacement('date', safeFieldKey);
    const view = normalizeFilterDateView(ui.dateViewByField[safeFieldKey]);
    const isMonthYearView = view === 'month-year';
    const cells = buildFilterDatePickerCells(monthCursor, value);
    const monthChoices = buildFilterDatePickerMonthChoices(monthCursor);
    const todayValue = todayInputValue();
    const currentMonth = parseFilterMonthCursor(monthCursor) || parseFilterMonthCursor(toFilterMonthCursor(new Date()));
    const currentYearLabel = String(currentMonth?.year || new Date().getFullYear());
    return `
      <label class="general-ledger-field general-ledger-field--date general-ledger-field--date-${escapeHtml(safeFieldKey)}">
        <span class="general-ledger-field__label">${escapeHtml(label)}</span>
        <div class="general-ledger-date-picker${isOpen ? ' is-open' : ''}" data-general-ledger-date-picker="true" data-general-ledger-date-field="${escapeHtml(safeFieldKey)}" data-general-ledger-picker-placement="${escapeHtml(placement)}">
          <div class="general-ledger-field__control general-ledger-date-picker__trigger general-ledger-date-picker__trigger--manual" aria-label="${escapeHtml(label)}">
            <div class="general-ledger-date-picker__manual" data-general-ledger-date-manual="true">
              <input class="general-ledger-date-picker__manual-input general-ledger-date-picker__manual-input--day" type="text" value="${escapeHtml(getFilterDateManualParts(safeFieldKey, value).day)}" placeholder="يوم" inputmode="numeric" autocomplete="off" dir="ltr" data-general-ledger-date-part="day" data-general-ledger-date-field="${escapeHtml(safeFieldKey)}" data-general-ledger-filter="${escapeHtml(safeFieldKey)}" aria-label="يوم ${escapeHtml(label)}">
              <span class="general-ledger-date-picker__manual-sep" aria-hidden="true">/</span>
              <input class="general-ledger-date-picker__manual-input general-ledger-date-picker__manual-input--month" type="text" value="${escapeHtml(getFilterDateManualParts(safeFieldKey, value).month)}" placeholder="شهر" inputmode="numeric" autocomplete="off" dir="ltr" data-general-ledger-date-part="month" data-general-ledger-date-field="${escapeHtml(safeFieldKey)}" data-general-ledger-filter="${escapeHtml(safeFieldKey)}" aria-label="شهر ${escapeHtml(label)}">
              <span class="general-ledger-date-picker__manual-sep" aria-hidden="true">/</span>
              <input class="general-ledger-date-picker__manual-input general-ledger-date-picker__manual-input--year" type="text" value="${escapeHtml(getFilterDateManualParts(safeFieldKey, value).year)}" placeholder="سنة" inputmode="numeric" autocomplete="off" dir="ltr" data-general-ledger-date-part="year" data-general-ledger-date-field="${escapeHtml(safeFieldKey)}" data-general-ledger-filter="${escapeHtml(safeFieldKey)}" aria-label="سنة ${escapeHtml(label)}">
            </div>
            <button class="general-ledger-date-picker__trigger-icon-btn" type="button" data-general-ledger-date-trigger="true" data-general-ledger-date-field="${escapeHtml(safeFieldKey)}" aria-label="فتح لوحة ${escapeHtml(label)}" aria-haspopup="dialog" aria-expanded="${isOpen ? 'true' : 'false'}">
              <span class="general-ledger-date-picker__trigger-icon" aria-hidden="true">${GENERAL_LEDGER_DATE_ICON}</span>
            </button>
          </div>
          ${isOpen ? `
            <div class="general-ledger-date-picker__popover" data-taif-dropdown-popup="true" data-taif-dropdown-layout="calendar" role="dialog" aria-label="اختيار التاريخ">
              ${isMonthYearView ? `
                <div class="general-ledger-date-picker__header general-ledger-date-picker__header--month-year">
                  <button class="general-ledger-date-picker__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-general-ledger-date-action="prev-year" data-general-ledger-date-field="${escapeHtml(safeFieldKey)}" aria-label="السنة السابقة">${GENERAL_LEDGER_DATE_NEXT_ICON}</button>
                  <button class="general-ledger-date-picker__heading-trigger general-ledger-date-picker__heading-trigger--current" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-general-ledger-date-action="toggle-view" data-general-ledger-date-field="${escapeHtml(safeFieldKey)}" data-general-ledger-date-view="days" aria-label="الرجوع إلى أيام الشهر">
                    <span dir="ltr">${escapeHtml(currentYearLabel)}</span>
                  </button>
                  <button class="general-ledger-date-picker__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-general-ledger-date-action="next-year" data-general-ledger-date-field="${escapeHtml(safeFieldKey)}" aria-label="السنة التالية">${GENERAL_LEDGER_DATE_PREV_ICON}</button>
                </div>
                <div class="general-ledger-date-picker__month-panel">
                  <div class="general-ledger-date-picker__month-grid">
                    ${monthChoices.map((monthChoice) => renderFilterDatePickerMonthButton(safeFieldKey, monthChoice)).join('')}
                  </div>
                </div>
                <div class="general-ledger-date-picker__footer">
                  <button class="general-ledger-date-picker__footer-btn" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-general-ledger-date-action="toggle-view" data-general-ledger-date-field="${escapeHtml(safeFieldKey)}" data-general-ledger-date-view="days">رجوع للتقويم</button>
                  <button class="general-ledger-date-picker__footer-btn general-ledger-date-picker__footer-btn--ghost" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-general-ledger-date-action="close" data-general-ledger-date-field="${escapeHtml(safeFieldKey)}">إغلاق</button>
                </div>
              ` : `
                <div class="general-ledger-date-picker__header">
                  <button class="general-ledger-date-picker__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-general-ledger-date-action="prev-month" data-general-ledger-date-field="${escapeHtml(safeFieldKey)}" aria-label="الشهر السابق">${GENERAL_LEDGER_DATE_NEXT_ICON}</button>
                  <button class="general-ledger-date-picker__heading-trigger" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-general-ledger-date-action="toggle-view" data-general-ledger-date-field="${escapeHtml(safeFieldKey)}" data-general-ledger-date-view="month-year" aria-label="تغيير الشهر أو السنة">${escapeHtml(formatFilterDatePickerMonthLabel(monthCursor))}</button>
                  <button class="general-ledger-date-picker__nav" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-general-ledger-date-action="next-month" data-general-ledger-date-field="${escapeHtml(safeFieldKey)}" aria-label="الشهر التالي">${GENERAL_LEDGER_DATE_PREV_ICON}</button>
                </div>
                <div class="general-ledger-date-picker__weekdays" aria-hidden="true">
                  ${DATE_PICKER_WEEKDAY_LABELS.map((item) => `<span>${escapeHtml(item)}</span>`).join('')}
                </div>
                <div class="general-ledger-date-picker__grid">
                  ${cells.map((cell) => renderFilterDatePickerDayButton(safeFieldKey, cell)).join('')}
                </div>
                <div class="general-ledger-date-picker__footer">
                  <button class="general-ledger-date-picker__footer-btn" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-general-ledger-date-action="today" data-general-ledger-date-field="${escapeHtml(safeFieldKey)}" data-general-ledger-date-value="${escapeHtml(todayValue)}">اليوم</button>
                  <button class="general-ledger-date-picker__footer-btn general-ledger-date-picker__footer-btn--ghost" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-general-ledger-date-action="clear" data-general-ledger-date-field="${escapeHtml(safeFieldKey)}">مسح</button>
                  <button class="general-ledger-date-picker__footer-btn general-ledger-date-picker__footer-btn--ghost" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-general-ledger-date-action="close" data-general-ledger-date-field="${escapeHtml(safeFieldKey)}">إغلاق</button>
                </div>
              `}
            </div>
          ` : ''}
        </div>
      </label>
    `;
  }

  function getLedgerCurrencyCatalogMap(){
    const domain = TAIF.currencyDomain || TAIF.currencyManagement || null;
    let currencies = [];
    try{
      const state = domain && typeof domain.readState === 'function' ? domain.readState() : null;
      currencies = Array.isArray(state?.currencies) ? state.currencies : [];
    }catch{}
    if(!currencies.length && Array.isArray(domain?.DEFAULT_CURRENCIES)) currencies = domain.DEFAULT_CURRENCIES;
    return new Map(currencies.map((currency) => [normalizeCurrencyCode(currency?.code), currency]));
  }

  function createLedgerFlagMarkup(option){
    const domain = TAIF.currencyDomain || TAIF.currencyManagement || null;
    const code = normalizeCurrencyCode(option?.code || option?.value);
    if(!code || !domain || typeof domain.createFlagImageMarkup !== 'function') return '';
    return `<span class="general-ledger-choice-popover__flag" aria-hidden="true">${domain.createFlagImageMarkup({ code, flag: option?.flag || '' }, { className:'general-ledger-choice-popover__flag-image' })}</span>`;
  }

  function normalizeLedgerChoiceOptions(options, pickerType = 'plain'){
    const currencyCatalog = pickerType === 'currency' ? getLedgerCurrencyCatalogMap() : null;
    return safeArray(options).map((option) => {
      const rawValue = pickerType === 'currency'
        ? (normalizeCurrencyCode(option?.value) || String(option?.value || '').trim())
        : String(option?.value || '').trim();
      if(!rawValue && rawValue !== '0') return null;
      if(pickerType === 'currency'){
        const code = normalizeCurrencyCode(rawValue);
        const catalog = currencyCatalog && code ? currencyCatalog.get(code) : null;
        return {
          value: code || rawValue,
          label: String(option?.label || catalog?.name || code || rawValue).trim() || (code || rawValue),
          code,
          flag: String(catalog?.flag || option?.flag || '').trim().toLowerCase()
        };
      }
      return {
        value: rawValue,
        label: String(option?.label || rawValue).trim() || rawValue,
        code: '',
        flag: ''
      };
    }).filter(Boolean);
  }

  function normalizeLedgerMultiSelectionValue(value, pickerType = 'plain'){
    if(String(value || '').trim().toLowerCase() === 'all') return 'all';
    return pickerType === 'currency'
      ? normalizeCurrencyCode(value)
      : String(value || '').trim();
  }

  function normalizeLedgerMultiSelections(options, selectedValues, pickerType = 'plain'){
    const normalizedOptions = normalizeLedgerChoiceOptions(options, pickerType);
    const availableValues = normalizedOptions
      .map((option) => normalizeLedgerMultiSelectionValue(option.value, pickerType))
      .filter(Boolean);
    const availableSet = new Set(availableValues);
    const rawValues = Array.isArray(selectedValues) ? selectedValues : [selectedValues];
    const isExplicitEmptyArray = Array.isArray(selectedValues) && selectedValues.length === 0;
    const hasAllToken = rawValues.some((value) => normalizeLedgerMultiSelectionValue(value, pickerType) === 'all');
    if(hasAllToken) return availableValues.slice();
    const normalizedValues = Array.from(new Set(rawValues
      .map((value) => normalizeLedgerMultiSelectionValue(value, pickerType))
      .filter((value) => value && availableSet.has(value))));
    if(normalizedValues.length) return availableValues.filter((value) => normalizedValues.includes(value));
    if(isExplicitEmptyArray) return [];
    return availableValues.slice();
  }

  function areAllLedgerMultiSelections(options, selectedValues, pickerType = 'plain'){
    const normalizedOptions = normalizeLedgerChoiceOptions(options, pickerType);
    if(!normalizedOptions.length) return false;
    const selected = normalizeLedgerMultiSelections(normalizedOptions, selectedValues, pickerType);
    return selected.length === normalizedOptions.length;
  }

  function resolveLedgerMultiTriggerLabel(options, selectedValues, {
    pickerType = 'plain',
    emptyLabel = 'اختر الخيارات',
    allLabel = 'كافة الخيارات',
    multipleLabel = 'خيارات محددة'
  } = {}){
    const normalizedOptions = normalizeLedgerChoiceOptions(options, pickerType);
    if(!normalizedOptions.length) return emptyLabel;
    const selected = normalizeLedgerMultiSelections(normalizedOptions, selectedValues, pickerType);
    if(!selected.length) return emptyLabel;
    if(selected.length === normalizedOptions.length) return allLabel;
    if(selected.length > 1) return multipleLabel;
    return normalizedOptions.find((option) => normalizeLedgerMultiSelectionValue(option.value, pickerType) === selected[0])?.label || emptyLabel;
  }

  function toggleLedgerMultiSelection(options, selectedValues, toggledValue, pickerType = 'plain'){
    const normalizedOptions = normalizeLedgerChoiceOptions(options, pickerType);
    const availableValues = normalizedOptions
      .map((option) => normalizeLedgerMultiSelectionValue(option.value, pickerType))
      .filter(Boolean);
    if(!availableValues.length) return [];

    const safeToggledValue = normalizeLedgerMultiSelectionValue(toggledValue, pickerType);
    const currentSelection = normalizeLedgerMultiSelections(normalizedOptions, selectedValues, pickerType);
    const isAllSelected = currentSelection.length === availableValues.length;

    if(safeToggledValue === 'all') return isAllSelected ? [] : availableValues.slice();
    if(!availableValues.includes(safeToggledValue)) return currentSelection;

    const nextSelection = new Set(currentSelection);
    if(nextSelection.has(safeToggledValue)) nextSelection.delete(safeToggledValue);
    else nextSelection.add(safeToggledValue);

    return availableValues.filter((value) => nextSelection.has(value));
  }

  function renderLedgerMultiChoicePicker({
    fieldKey,
    label,
    options,
    selectedValues,
    pickerType = 'plain',
    emptyLabel = 'اختر الخيارات',
    allLabel = 'كافة الخيارات',
    multipleLabel = 'خيارات محددة'
  }){
    const safeFieldKey = String(fieldKey || '').trim();
    const normalizedOptions = normalizeLedgerChoiceOptions(options, pickerType);
    const effectiveSelection = normalizeLedgerMultiSelections(normalizedOptions, selectedValues, pickerType);
    const isAllSelected = areAllLedgerMultiSelections(normalizedOptions, effectiveSelection, pickerType);
    const isOpen = isFilterPickerOpen('choice', safeFieldKey);
    const placement = getFilterPickerPlacement('choice', safeFieldKey);
    const listId = `general-ledger-choice-${escapeHtml(safeFieldKey)}`;
    const triggerLabel = resolveLedgerMultiTriggerLabel(normalizedOptions, effectiveSelection, { pickerType, emptyLabel, allLabel, multipleLabel });
    const triggerValueClass = effectiveSelection.length ? 'general-ledger-choice-picker__value' : 'general-ledger-choice-picker__value is-placeholder';

    const listContent = normalizedOptions.length
      ? `
          <button class="general-ledger-choice-popover__option general-ledger-choice-popover__option--multi${isAllSelected ? ' is-active' : ''}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-taif-inline-picker-option="true" role="option" data-general-ledger-choice-action="select" data-general-ledger-choice-field="${escapeHtml(safeFieldKey)}" data-general-ledger-choice-value="all" aria-selected="${isAllSelected ? 'true' : 'false'}" aria-label="اختيار ${escapeHtml(allLabel)}">
            <span class="general-ledger-choice-popover__label" data-taif-dropdown-label="true">${escapeHtml(allLabel)}</span>
            <span class="general-ledger-choice-popover__box" aria-hidden="true">${GENERAL_LEDGER_PICKER_CHECK_ICON}</span>
          </button>
          ${normalizedOptions.map((option) => {
            const optionValue = normalizeLedgerMultiSelectionValue(option.value, pickerType);
            const isActive = effectiveSelection.includes(optionValue);
            const optionLabel = pickerType === 'currency'
              ? `
                <span class="general-ledger-choice-popover__meta" data-taif-dropdown-label="true">
                  ${createLedgerFlagMarkup(option)}
                  <span class="general-ledger-choice-popover__label">${escapeHtml(option.label)}</span>
                </span>
              `
              : `<span class="general-ledger-choice-popover__label" data-taif-dropdown-label="true">${escapeHtml(option.label)}</span>`;
            return `
              <button class="general-ledger-choice-popover__option general-ledger-choice-popover__option--multi${isActive ? ' is-active' : ''}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-taif-inline-picker-option="true" role="option" data-general-ledger-choice-action="select" data-general-ledger-choice-field="${escapeHtml(safeFieldKey)}" data-general-ledger-choice-value="${escapeHtml(optionValue)}"${pickerType === 'currency' ? ' data-general-ledger-currency-kind="currency"' : ''} aria-selected="${isActive ? 'true' : 'false'}" aria-label="اختيار ${escapeHtml(option.label)}">
                ${optionLabel}
                <span class="general-ledger-choice-popover__box" aria-hidden="true">${GENERAL_LEDGER_PICKER_CHECK_ICON}</span>
              </button>
            `;
          }).join('')}
        `
      : '<div class="general-ledger-choice-popover__empty">لا توجد خيارات متاحة.</div>';

    return `
      <label class="${['general-ledger-field', 'general-ledger-field--full'].filter(Boolean).join(' ')}">
        <span class="general-ledger-field__label">${escapeHtml(label)}</span>
        <div class="general-ledger-choice-picker${isOpen ? ' is-open' : ''}" data-general-ledger-choice-picker="true" data-general-ledger-choice-field="${escapeHtml(safeFieldKey)}" data-general-ledger-picker-placement="${escapeHtml(placement)}" data-taif-inline-picker-host="true">
          <button class="general-ledger-field__control general-ledger-choice-picker__trigger" type="button" data-general-ledger-choice-trigger="true" data-general-ledger-choice-field="${escapeHtml(safeFieldKey)}" data-general-ledger-filter="${escapeHtml(safeFieldKey)}" aria-label="${escapeHtml(label)}" aria-haspopup="listbox" aria-controls="${listId}" aria-expanded="${isOpen ? 'true' : 'false'}">
            <span class="${triggerValueClass}">${escapeHtml(triggerLabel)}</span>
            <span class="general-ledger-choice-picker__icon" aria-hidden="true">${GENERAL_LEDGER_PICKER_ICON}</span>
          </button>
          <div class="general-ledger-choice-popover general-ledger-choice-popover--multi" id="${listId}" role="listbox" aria-label="${escapeHtml(label)}" aria-multiselectable="true" data-taif-dropdown-popup="true" data-taif-dropdown-layout="list" data-general-ledger-choice-scroll-field="${escapeHtml(safeFieldKey)}"${isOpen ? '' : ' hidden'}>${listContent}</div>
        </div>
      </label>
    `;
  }

  function renderLedgerSingleChoicePicker({ fieldKey, label, options, value, emptyLabel = 'اختر الخيار' }){
    const safeFieldKey = String(fieldKey || '').trim();
    const normalizedOptions = normalizeLedgerChoiceOptions(options, 'plain');
    const availableValues = normalizedOptions.map((option) => String(option.value || '').trim()).filter(Boolean);
    const requestedValue = String(value || '').trim();
    const selectedValue = availableValues.includes(requestedValue) ? requestedValue : (availableValues[0] || '');
    const selectedLabel = normalizedOptions.find((option) => String(option.value || '').trim() === selectedValue)?.label || emptyLabel;
    const isOpen = isFilterPickerOpen('choice', safeFieldKey);
    const placement = getFilterPickerPlacement('choice', safeFieldKey);
    const listId = `general-ledger-choice-${escapeHtml(safeFieldKey)}`;
    const triggerValueClass = selectedValue ? 'general-ledger-choice-picker__value' : 'general-ledger-choice-picker__value is-placeholder';

    const listContent = normalizedOptions.length
      ? normalizedOptions.map((option) => {
          const optionValue = String(option.value || '').trim();
          const isActive = optionValue === selectedValue;
          return `
            <button class="general-ledger-choice-popover__option${isActive ? ' is-active' : ''}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-taif-inline-picker-option="true" role="option" data-general-ledger-choice-action="select" data-general-ledger-choice-field="${escapeHtml(safeFieldKey)}" data-general-ledger-choice-value="${escapeHtml(optionValue)}" aria-selected="${isActive ? 'true' : 'false'}" aria-label="اختيار ${escapeHtml(option.label)}">
              <span class="general-ledger-choice-popover__label" data-taif-dropdown-label="true">${escapeHtml(option.label)}</span>
              <span class="general-ledger-choice-popover__box" aria-hidden="true">${GENERAL_LEDGER_PICKER_CHECK_ICON}</span>
            </button>
          `;
        }).join('')
      : '<div class="general-ledger-choice-popover__empty">لا توجد خيارات متاحة.</div>';

    return `
      <label class="${['general-ledger-field', 'general-ledger-field--full'].filter(Boolean).join(' ')}">
        <span class="general-ledger-field__label">${escapeHtml(label)}</span>
        <div class="general-ledger-choice-picker${isOpen ? ' is-open' : ''}" data-general-ledger-choice-picker="true" data-general-ledger-choice-field="${escapeHtml(safeFieldKey)}" data-general-ledger-picker-placement="${escapeHtml(placement)}" data-taif-inline-picker-host="true">
          <button class="general-ledger-field__control general-ledger-choice-picker__trigger" type="button" data-general-ledger-choice-trigger="true" data-general-ledger-choice-field="${escapeHtml(safeFieldKey)}" data-general-ledger-filter="${escapeHtml(safeFieldKey)}" aria-label="${escapeHtml(label)}" aria-haspopup="listbox" aria-controls="${listId}" aria-expanded="${isOpen ? 'true' : 'false'}">
            <span class="${triggerValueClass}">${escapeHtml(selectedLabel)}</span>
            <span class="general-ledger-choice-picker__icon" aria-hidden="true">${GENERAL_LEDGER_PICKER_ICON}</span>
          </button>
          <div class="general-ledger-choice-popover" id="${listId}" role="listbox" aria-label="${escapeHtml(label)}" data-taif-dropdown-popup="true" data-taif-dropdown-layout="list" data-general-ledger-choice-scroll-field="${escapeHtml(safeFieldKey)}"${isOpen ? '' : ' hidden'}>${listContent}</div>
        </div>
      </label>
    `;
  }

  function renderLedgerExchangeRatePicker({ fieldKey, label, options, value }){
    return renderLedgerSingleChoicePicker({
      fieldKey,
      label,
      options,
      value,
      emptyLabel:'اختر سعر الصرف'
    });
  }

  function renderLedgerCurrencyPicker({ fieldKey, label, options, selectedValues }){
    return renderLedgerMultiChoicePicker({
      fieldKey,
      label,
      options,
      selectedValues,
      pickerType:'currency',
      emptyLabel:'اختر العملات',
      allLabel:'كافة العملات',
      multipleLabel:'عملات محددة'
    });
  }

  function renderLedgerOperationPicker({ fieldKey, label, options, selectedValues }){
    return renderLedgerMultiChoicePicker({
      fieldKey,
      label,
      options,
      selectedValues,
      pickerType:'plain',
      emptyLabel:'اختر العمليات',
      allLabel:'كافة العمليات',
      multipleLabel:'عمليات محددة'
    });
  }

  function renderHideOpeningBalanceToggle(checked){
    const isChecked = checked === true;
    return `
      <button class="general-ledger-opening-balance-toggle${isChecked ? ' is-checked' : ''}" type="button" data-general-ledger-action="toggle-hide-opening-balance" role="checkbox" aria-checked="${isChecked ? 'true' : 'false'}" aria-label="اخفاء الرصيد السابق" title="اخفاء الرصيد السابق">
        <span class="general-ledger-opening-balance-toggle__label">اخفاء الرصيد السابق</span>
        <span class="general-ledger-opening-balance-toggle__box" aria-hidden="true">${isChecked ? GENERAL_LEDGER_PICKER_CHECK_ICON : ''}</span>
      </button>
    `;
  }

  function renderLedgerAccountSearchField(){
    syncFilterUiStateWithPendingFilters();
    const ui = ensureFilterUiState();
    const filters = getPendingFilters();
    const queryValue = String(ui.accountQuery || '');
    const searchResults = buildLedgerAccountSearchResults(queryValue, 12);
    const selectedAccountNo = String(filters.accountNo || '').trim();
    const isOpen = isFilterPickerOpen('account', 'accountNo');
    const placement = getFilterPickerPlacement('account', 'accountNo');
    const listContent = searchResults.length
      ? searchResults.map((option) => {
          const accountLabel = formatLedgerAccountLookupLabel(option);
          const accountNo = String(option.accountNo || '').trim();
          const isActive = accountNo === selectedAccountNo;
          return `
            <button class="general-ledger-account-search__result${isActive ? ' is-active' : ''}" type="button" data-taif-dropdown-item="true" data-taif-dropdown-item-kind="list" data-taif-inline-picker-option="true" role="option" data-general-ledger-account-option="select" data-general-ledger-account-no="${escapeHtml(accountNo)}" aria-label="اختيار الحساب ${escapeHtml(accountLabel)}">
              <span class="general-ledger-account-search__result-copy">
                <span class="general-ledger-account-search__result-name" data-taif-dropdown-label="true">${escapeHtml(String(option.name || ''))}</span>
                <span class="general-ledger-account-search__result-no" dir="ltr">${escapeHtml(accountNo)}</span>
              </span>
            </button>
          `;
        }).join('')
      : '<div class="general-ledger-account-search__empty">لا يوجد حساب مطابق لما كتبته.</div>';

    return `
      <label class="general-ledger-field general-ledger-field--account-search general-ledger-field--header-account">
        <span class="general-ledger-field__label general-ledger-field__label--sr-only">الحساب</span>
        <div class="general-ledger-account-search${isOpen ? ' is-open' : ''}" data-general-ledger-account-root="true" data-general-ledger-picker-placement="${escapeHtml(placement)}">
          <input class="general-ledger-field__control general-ledger-account-search__control" type="text" value="${escapeHtml(queryValue)}" aria-controls="general-ledger-account-search-list-header" aria-expanded="${isOpen ? 'true' : 'false'}" aria-autocomplete="list" role="combobox" placeholder="الحساب" data-general-ledger-account-input="true" data-general-ledger-filter="accountNo" aria-label="اختيار الحساب" autocomplete="off" spellcheck="false">
          <div class="general-ledger-account-search__popover" id="general-ledger-account-search-list-header" role="listbox" aria-label="اقتراحات الحسابات"${isOpen ? '' : ' hidden'}>${isOpen ? listContent : ''}</div>
        </div>
      </label>
    `;
  }

  function createFiltersMarkup(){
    syncFilterUiStateWithPendingFilters();
    const filters = getPendingFilters();
    const currencyOptions = safeArray(runtime.model?.currencyOptions);
    const operationOptions = safeArray(runtime.model?.operationOptions);
    const exchangeRateOptions = safeArray(runtime.model?.exchangeRateOptions);

    return `
      <section class="general-ledger-sidebar__card">
        <div class="general-ledger-filters">
          <div class="general-ledger-filters__row general-ledger-filters__row--dates">
            ${renderGeneralLedgerDateField('dateFrom', 'من تاريخ', filters.dateFrom || '')}
            ${renderGeneralLedgerDateField('dateTo', 'إلى تاريخ', filters.dateTo || '')}
          </div>
          <label class="general-ledger-field general-ledger-field--full general-ledger-field--search">
            <span class="general-ledger-field__label">البحث داخل السطور</span>
            <input class="general-ledger-field__control" type="text" value="${escapeHtml(filters.search || '')}" placeholder="رقم السند أو البيان أو الحساب المقابل" data-general-ledger-filter="search" aria-label="البحث داخل السطور" autocomplete="off" spellcheck="false">
          </label>
          ${renderLedgerCurrencyPicker({ fieldKey:'currency', label:'العملة', options:currencyOptions, selectedValues:filters.currencies })}
          ${renderLedgerOperationPicker({ fieldKey:'operationType', label:'نوع العملية', options:operationOptions, selectedValues:filters.operationTypes })}
          ${renderLedgerExchangeRatePicker({ fieldKey:'exchangeRateMode', label:'سعر الصرف', options:exchangeRateOptions, value:filters.exchangeRateMode })}
          ${renderHideOpeningBalanceToggle(filters.hideOpeningBalance)}
        </div>
      </section>
    `;
  }

  function createSidebarActionsMarkup(){
    return `
      <div class="general-ledger-sidebar__actions" aria-label="أزرار دفتر الأستاذ">
        <button class="general-ledger-sidebar__action general-ledger-sidebar__action--apply" type="button" data-general-ledger-action="apply-filters">
          <span class="general-ledger-sidebar__action-text">عرض النتيجة</span>
        </button>
        <button class="general-ledger-sidebar__action general-ledger-sidebar__action--reset" type="button" data-general-ledger-action="reset-filters">
          <span class="general-ledger-sidebar__action-text">إعادة الضبط</span>
        </button>
      </div>
    `;
  }

  function renderShellMarkup(){
    const summary = runtime.model?.summary || {};
    const shellClassName = [
      'general-ledger-shell',
      hasOpenFilterPicker() ? 'general-ledger-shell--picker-open' : '',
      runtime.sidebarOpen ? 'general-ledger-shell--sidebar-open' : 'general-ledger-shell--sidebar-closed'
    ].filter(Boolean).join(' ');
    return `
      <div class="${shellClassName}" data-owner-view="general-ledger">
        <section class="general-ledger-workspace">
          <div class="general-ledger-sidebar__backdrop" data-general-ledger-action="toggle-sidebar" aria-hidden="true"></div>
          <aside class="general-ledger-sidebar" id="general-ledger-sidebar-panel" aria-label="لوحة التحكم في دفتر الأستاذ" aria-hidden="${runtime.sidebarOpen ? 'false' : 'true'}">
            <div class="general-ledger-sidebar__content">
              ${createFiltersMarkup()}
            </div>
            ${createSidebarActionsMarkup()}
          </aside>

          <section class="general-ledger-board" aria-label="سجل دفتر الأستاذ">
            ${createLedgerSummaryBarMarkup(summary)}
            <div class="general-ledger-board__body">
              ${createRowsMarkup()}
            </div>
          </section>
        </section>
      </div>
    `;
  }

  function buildFilterFocusSelector(element){
    if(!(element instanceof HTMLElement)) return '';

    const dateField = String(element.dataset.generalLedgerDateField || '').trim();
    const datePart = String(element.dataset.generalLedgerDatePart || '').trim();
    if(dateField && datePart){
      return `[data-general-ledger-date-field="${escapeSelectorValue(dateField)}"][data-general-ledger-date-part="${escapeSelectorValue(datePart)}"]`;
    }

    if(element.matches('[data-general-ledger-account-input="true"]')){
      return '[data-general-ledger-account-input="true"]';
    }

    const filterKey = String(element.dataset.generalLedgerFilter || '').trim();
    return filterKey ? `[data-general-ledger-filter="${escapeSelectorValue(filterKey)}"]` : '';
  }

  function takeFocusSnapshot(){
    const panel = runtime.panel;
    const activeElement = document.activeElement;
    if(!(panel instanceof HTMLElement) || !(activeElement instanceof HTMLElement) || !panel.contains(activeElement)) return null;

    const selector = buildFilterFocusSelector(activeElement);
    if(!selector) return null;

    return {
      selector,
      selectionStart: typeof activeElement.selectionStart === 'number' ? activeElement.selectionStart : null,
      selectionEnd: typeof activeElement.selectionEnd === 'number' ? activeElement.selectionEnd : null
    };
  }

  function restoreFocusSnapshot(snapshot){
    if(!snapshot || !(runtime.panel instanceof HTMLElement)) return;
    const selector = String(snapshot.selector || '').trim();
    if(!selector) return;

    const control = runtime.panel.querySelector(selector);
    if(!(control instanceof HTMLElement)) return;
    try{ control.focus({ preventScroll:true }); }catch{ try{ control.focus(); }catch{} }
    if(control instanceof HTMLInputElement && typeof snapshot.selectionStart === 'number' && typeof snapshot.selectionEnd === 'number'){
      try{ control.setSelectionRange(snapshot.selectionStart, snapshot.selectionEnd); }catch{}
    }
  }

  function takeSidebarScrollSnapshot(){
    if(!(runtime.panel instanceof HTMLElement)) return null;
    const sidebarContent = runtime.panel.querySelector('.general-ledger-sidebar__content');
    if(!(sidebarContent instanceof HTMLElement)) return null;
    return { scrollTop: sidebarContent.scrollTop };
  }

  function restoreSidebarScrollSnapshot(snapshot){
    if(!snapshot || !(runtime.panel instanceof HTMLElement)) return;
    const sidebarContent = runtime.panel.querySelector('.general-ledger-sidebar__content');
    if(!(sidebarContent instanceof HTMLElement)) return;
    sidebarContent.scrollTop = Math.max(0, Number(snapshot.scrollTop) || 0);
  }

  function takeChoicePopoverScrollSnapshot(fieldKey){
    if(!(runtime.panel instanceof HTMLElement)) return null;
    const safeFieldKey = String(fieldKey || '').trim();
    if(!safeFieldKey) return null;
    const selector = `.general-ledger-choice-popover[data-general-ledger-choice-scroll-field="${escapeSelectorValue(safeFieldKey)}"]`;
    const popover = runtime.panel.querySelector(selector);
    if(!(popover instanceof HTMLElement)) return null;
    return {
      fieldKey: safeFieldKey,
      scrollTop: popover.scrollTop,
      scrollLeft: popover.scrollLeft
    };
  }

  function restoreChoicePopoverScrollSnapshot(snapshot){
    if(!snapshot || !(runtime.panel instanceof HTMLElement)) return;
    const safeFieldKey = String(snapshot.fieldKey || '').trim();
    if(!safeFieldKey) return;
    const selector = `.general-ledger-choice-popover[data-general-ledger-choice-scroll-field="${escapeSelectorValue(safeFieldKey)}"]`;
    const popover = runtime.panel.querySelector(selector);
    if(!(popover instanceof HTMLElement)) return;
    popover.scrollTop = Math.max(0, Number(snapshot.scrollTop) || 0);
    popover.scrollLeft = Math.max(0, Number(snapshot.scrollLeft) || 0);
  }

  function syncExpandedCurrencies(){
    const validCodes = new Set(safeArray(runtime.model?.periodCurrencyCodes).map((code) => normalizeCurrencyCode(code)).filter(Boolean));
    runtime.expandedCurrencies = new Set(Array.from(runtime.expandedCurrencies).filter((code) => validCodes.has(normalizeCurrencyCode(code))));
  }

  function rerender({ preserveFocus = false, preserveSidebarScroll = false, preserveChoiceScrollField = '' } = {}){
    const focusSnapshot = preserveFocus ? takeFocusSnapshot() : null;
    const sidebarScrollSnapshot = preserveSidebarScroll ? takeSidebarScrollSnapshot() : null;
    const choiceScrollSnapshot = preserveChoiceScrollField ? takeChoicePopoverScrollSnapshot(preserveChoiceScrollField) : null;
    runtime.model = api.buildModel(getFilters());
    syncExpandedCurrencies();
    if(!(runtime.panel instanceof HTMLElement)) return;
    runtime.panel.innerHTML = renderShellMarkup();
    if(typeof runtime.detachPanelEvents === 'function') runtime.detachPanelEvents();
    runtime.detachPanelEvents = bindPanelEvents();
    if(focusSnapshot || sidebarScrollSnapshot || choiceScrollSnapshot){
      requestAnimationFrame(() => {
        if(sidebarScrollSnapshot) restoreSidebarScrollSnapshot(sidebarScrollSnapshot);
        if(choiceScrollSnapshot) restoreChoicePopoverScrollSnapshot(choiceScrollSnapshot);
        if(focusSnapshot) restoreFocusSnapshot(focusSnapshot);
      });
    }
  }

  function updatePendingFilter(key, value){
    const current = { ...getPendingFilters() };
    current[key] = value;
    if(key === 'dateFrom' || key === 'dateTo'){
      const todayIsoDate = todayInputValue();
      const nextDateFrom = String(key === 'dateFrom' ? value : current.dateFrom || '').trim();
      const nextDateTo = String(key === 'dateTo' ? value : current.dateTo || '').trim();
      current.autoTodayDates = nextDateFrom === todayIsoDate && nextDateTo === todayIsoDate;
    }
    runtime.pendingFilters = api.normalizeFilters(current);
  }

  function applyPendingFilters(){
    ensureAccountSelectionBeforeApply();
    const persisted = api.writeFilters(getPendingFilters());
    runtime.pendingFilters = persisted;
    runtime.model = api.buildModel(persisted);
    runtime.selectedRowId = '';
    runtime.expandedCurrencies = new Set();
    syncFilterUiStateWithPendingFilters({ closePickers:true });
    rerender();
  }

  function resetFilters(){
    const resetFiltersState = api.normalizeFilters({});
    const persisted = api.writeFilters(resetFiltersState);
    runtime.pendingFilters = persisted;
    runtime.model = api.buildModel(persisted);
    runtime.selectedRowId = '';
    runtime.expandedCurrencies = new Set();
    syncFilterUiStateWithPendingFilters({ forceAccountLabel:true, closePickers:true, resetDateState:true });
    rerender();
  }

  function toggleCurrencyDetails(currencyCode){
    const safeCurrencyCode = normalizeCurrencyCode(currencyCode);
    if(!safeCurrencyCode) return;
    if(runtime.expandedCurrencies.has(safeCurrencyCode)) runtime.expandedCurrencies.delete(safeCurrencyCode);
    else runtime.expandedCurrencies.add(safeCurrencyCode);
    rerender();
  }

  function toggleSidebar(){
    runtime.sidebarOpen = !runtime.sidebarOpen;
    if(!runtime.sidebarOpen && hasOpenFilterPicker()){
      closeFilterPicker();
    }
    rerender();
  }


  function readSourceTargetFromButton(button){
    if(!(button instanceof HTMLElement)) return null;
    const recordId = String(button.dataset.generalLedgerSourceRecordId || '').trim();
    const number = String(button.dataset.generalLedgerSourceNumber || '').trim();
    const viewId = String(button.dataset.generalLedgerSourceView || '').trim();
    if(!viewId || (!recordId && !number)) return null;
    return {
      sourceKind: String(button.dataset.generalLedgerSourceKind || '').trim(),
      viewId,
      actionId: String(button.dataset.generalLedgerSourceActionId || '').trim(),
      voucherType: String(button.dataset.generalLedgerSourceVoucherType || '').trim(),
      recordId,
      number,
      query: number || recordId
    };
  }

  function navigateToSourceView(viewId){
    const safeViewId = String(viewId || '').trim();
    if(!safeViewId) return false;
    const selector = `.navbtn[data-view="${escapeSelectorValue(safeViewId)}"]`;
    const navButton = document.querySelector(selector);
    if(navButton instanceof HTMLElement){
      navButton.click();
      return true;
    }
    const panel = document.getElementById('panel');
    if(panel instanceof HTMLElement && TAIF.views && typeof TAIF.views.renderActive === 'function'){
      TAIF.views.renderActive(panel, safeViewId);
      return true;
    }
    return false;
  }

  function openLedgerSource(button){
    const sourceTarget = readSourceTargetFromButton(button);
    if(!sourceTarget || !api || typeof api.writePendingSourceFocus !== 'function') return false;
    const persisted = api.writePendingSourceFocus(sourceTarget);
    if(!persisted) return false;
    return navigateToSourceView(sourceTarget.viewId);
  }


  function bindPanelEvents(){
    const panel = runtime.panel;
    if(!(panel instanceof HTMLElement)) return () => {};

    const handleInput = (event) => {
      const target = event.target;
      if(!(target instanceof HTMLElement)) return;

      if(target instanceof HTMLInputElement && target.matches('[data-general-ledger-date-part]')){
        const fieldKey = String(target.dataset.generalLedgerDateField || '').trim();
        const partKey = String(target.dataset.generalLedgerDatePart || '').trim();
        if(!fieldKey || !partKey) return;
        const cleanValue = sanitizeFilterDatePart(partKey, target.value || '');
        if(target.value !== cleanValue) target.value = cleanValue;
        updateFilterDatePart(fieldKey, partKey, cleanValue);
        return;
      }

      if(target.matches('[data-general-ledger-account-input="true"]')){
        const ui = ensureFilterUiState();
        ui.accountQuery = target.value || '';
        ui.accountDirty = true;
        updatePendingFilter('accountNo', '');
        openFilterPicker('account', 'accountNo');
        rerender({ preserveFocus:true, preserveSidebarScroll:true });
        return;
      }

      const filterKey = String(target.dataset.generalLedgerFilter || '').trim();
      if(!filterKey) return;
      if(target instanceof HTMLInputElement && filterKey === 'search'){
        updatePendingFilter(filterKey, target.value);
      }
    };

    const handleFocusIn = (event) => {
      const target = event.target;
      if(!(target instanceof HTMLElement)) return;
      if(target.matches('[data-general-ledger-account-input="true"]') && !isFilterPickerOpen('account', 'accountNo')){
        openFilterPicker('account', 'accountNo');
        rerender({ preserveFocus:true, preserveSidebarScroll:true });
      }
    };

    const handleClick = (event) => {
      const clickTarget = event.target instanceof Element ? event.target : null;
      if(!clickTarget) return;

      const sourceButton = clickTarget.closest('[data-general-ledger-source-action="open"]');
      if(sourceButton instanceof HTMLElement){
        event.preventDefault();
        event.stopPropagation();
        openLedgerSource(sourceButton);
        return;
      }

      const actionTarget = clickTarget.closest('[data-general-ledger-action]');
      if(actionTarget instanceof HTMLElement){
        const action = String(actionTarget.dataset.generalLedgerAction || '').trim();
        const currencyCode = String(actionTarget.dataset.generalLedgerCurrency || '').trim();
        if(action === 'toggle-currency' && currencyCode){
          event.preventDefault();
          toggleCurrencyDetails(currencyCode);
          return;
        }
        if(action === 'toggle-sidebar'){
          event.preventDefault();
          toggleSidebar();
          return;
        }
        if(action === 'apply-filters'){
          event.preventDefault();
          applyPendingFilters();
          return;
        }
        if(action === 'reset-filters'){
          event.preventDefault();
          resetFilters();
          return;
        }
        if(action === 'toggle-hide-opening-balance'){
          event.preventDefault();
          updatePendingFilter('hideOpeningBalance', !getPendingFilters().hideOpeningBalance);
          const persisted = api.writeFilters(getPendingFilters());
          runtime.pendingFilters = persisted;
          runtime.model = api.buildModel(persisted);
          runtime.selectedRowId = '';
          syncFilterUiStateWithPendingFilters({ closePickers:true });
          rerender({ preserveSidebarScroll:true });
          return;
        }
      }

      const accountOption = clickTarget.closest('[data-general-ledger-account-option="select"]');
      if(accountOption instanceof HTMLElement){
        event.preventDefault();
        const accountNo = String(accountOption.dataset.generalLedgerAccountNo || '').trim();
        const account = safeArray(runtime.model?.accounts).find((entry) => String(entry?.accountNo || '').trim() === accountNo) || null;
        const ui = ensureFilterUiState();
        updatePendingFilter('accountNo', accountNo);
        ui.accountQuery = account ? formatLedgerAccountLookupLabel(account) : '';
        ui.accountDirty = false;
        closeFilterPicker();
        rerender();
        return;
      }

      const choiceOption = clickTarget.closest('[data-general-ledger-choice-action="select"]');
      if(choiceOption instanceof HTMLElement){
        event.preventDefault();
        const fieldKey = String(choiceOption.dataset.generalLedgerChoiceField || '').trim();
        const value = String(choiceOption.dataset.generalLedgerChoiceValue || '').trim();
        if(fieldKey){
          if(fieldKey === 'operationType'){
            const nextSelection = toggleLedgerMultiSelection(runtime.model?.operationOptions, getPendingFilters().operationTypes, value, 'plain');
            updatePendingFilter('operationTypes', nextSelection);
            openFilterPicker('choice', fieldKey, getFilterPickerPlacement('choice', fieldKey));
            rerender({ preserveSidebarScroll:true, preserveChoiceScrollField:fieldKey });
            return;
          }
          if(fieldKey === 'currency'){
            const nextSelection = toggleLedgerMultiSelection(runtime.model?.currencyOptions, getPendingFilters().currencies, value, 'currency');
            updatePendingFilter('currencies', nextSelection);
            openFilterPicker('choice', fieldKey, getFilterPickerPlacement('choice', fieldKey));
            rerender({ preserveSidebarScroll:true, preserveChoiceScrollField:fieldKey });
            return;
          }

          updatePendingFilter(fieldKey, value);
          closeFilterPicker();
          rerender();
        }
        return;
      }

      const choiceTrigger = clickTarget.closest('[data-general-ledger-choice-trigger="true"]');
      if(choiceTrigger instanceof HTMLElement){
        event.preventDefault();
        const fieldKey = String(choiceTrigger.dataset.generalLedgerChoiceField || '').trim();
        if(fieldKey){
          if(isFilterPickerOpen('choice', fieldKey)) closeFilterPicker();
          else openFilterPicker('choice', fieldKey);
          rerender({ preserveFocus:true, preserveSidebarScroll:true, preserveChoiceScrollField:fieldKey });
        }
        return;
      }

      const dateButton = clickTarget.closest('[data-general-ledger-date-trigger="true"], [data-general-ledger-date-action]');
      if(dateButton instanceof HTMLElement){
        event.preventDefault();
        const fieldKey = String(dateButton.dataset.generalLedgerDateField || '').trim();
        if(!fieldKey) return;
        const ui = ensureFilterUiState();
        const filters = getPendingFilters();
        const currentValue = String(filters[fieldKey] || '').trim();
        const action = String(dateButton.dataset.generalLedgerDateAction || '').trim();

        if(dateButton.matches('[data-general-ledger-date-trigger="true"]') && !action){
          if(isFilterPickerOpen('date', fieldKey)) closeFilterPicker();
          else {
            openFilterPicker('date', fieldKey);
            ui.dateViewByField[fieldKey] = 'days';
            ui.dateMonthCursorByField[fieldKey] = resolveFilterMonthCursor(fieldKey, currentValue);
          }
          rerender({ preserveFocus:true, preserveSidebarScroll:true });
          return;
        }

        if(action === 'close'){
          closeFilterPicker();
          rerender();
          return;
        }
        if(action === 'prev-month'){
          openFilterPicker('date', fieldKey, getFilterPickerPlacement('date', fieldKey));
          ui.dateMonthCursorByField[fieldKey] = shiftFilterMonthCursor(resolveFilterMonthCursor(fieldKey, currentValue), -1);
          rerender();
          return;
        }
        if(action === 'next-month'){
          openFilterPicker('date', fieldKey, getFilterPickerPlacement('date', fieldKey));
          ui.dateMonthCursorByField[fieldKey] = shiftFilterMonthCursor(resolveFilterMonthCursor(fieldKey, currentValue), 1);
          rerender();
          return;
        }
        if(action === 'prev-year'){
          openFilterPicker('date', fieldKey, getFilterPickerPlacement('date', fieldKey));
          ui.dateMonthCursorByField[fieldKey] = shiftFilterMonthCursor(resolveFilterMonthCursor(fieldKey, currentValue), -12);
          rerender();
          return;
        }
        if(action === 'next-year'){
          openFilterPicker('date', fieldKey, getFilterPickerPlacement('date', fieldKey));
          ui.dateMonthCursorByField[fieldKey] = shiftFilterMonthCursor(resolveFilterMonthCursor(fieldKey, currentValue), 12);
          rerender();
          return;
        }
        if(action === 'toggle-view'){
          openFilterPicker('date', fieldKey, getFilterPickerPlacement('date', fieldKey));
          ui.dateViewByField[fieldKey] = normalizeFilterDateView(dateButton.dataset.generalLedgerDateView || 'days');
          rerender();
          return;
        }
        if(action === 'pick-month'){
          openFilterPicker('date', fieldKey, getFilterPickerPlacement('date', fieldKey));
          ui.dateMonthCursorByField[fieldKey] = String(dateButton.dataset.generalLedgerDateMonth || '').trim() || resolveFilterMonthCursor(fieldKey, currentValue);
          ui.dateViewByField[fieldKey] = 'days';
          rerender();
          return;
        }
        if(action === 'today' || action === 'select-day'){
          const value = String(dateButton.dataset.generalLedgerDateValue || '').trim();
          delete ui.dateDraftsByField[fieldKey];
          updatePendingFilter(fieldKey, value);
          closeFilterPicker();
          rerender();
          return;
        }
        if(action === 'clear'){
          delete ui.dateDraftsByField[fieldKey];
          updatePendingFilter(fieldKey, '');
          closeFilterPicker();
          rerender();
          return;
        }
        return;
      }

      const accountInput = clickTarget.closest('[data-general-ledger-account-input="true"]');
      if(accountInput instanceof HTMLElement){
        if(!isFilterPickerOpen('account', 'accountNo')){
          openFilterPicker('account', 'accountNo');
          rerender({ preserveFocus:true, preserveSidebarScroll:true });
        }
        return;
      }

      if(hasOpenFilterPicker() && !clickTarget.closest('[data-general-ledger-account-root="true"], [data-general-ledger-choice-picker="true"], [data-general-ledger-date-picker="true"]')){
        closeFilterPicker();
        const clickedFilterControl = clickTarget.closest('[data-general-ledger-filter]');
        rerender({
          preserveFocus: clickedFilterControl instanceof HTMLElement,
          preserveSidebarScroll: true
        });
      }
    };

    const handleKeydown = (event) => {
      const target = event.target;
      if(!(target instanceof HTMLElement)) return;

      if(event.key === 'Escape' && hasOpenFilterPicker()){
        event.preventDefault();
        closeFilterPicker();
        rerender();
        return;
      }

      if(target.matches('[data-general-ledger-account-input="true"]') && event.key === 'Enter'){
        event.preventDefault();
        const resolved = resolveLedgerAccountFromQuery(String(target.value || '').trim());
        if(resolved){
          const ui = ensureFilterUiState();
          updatePendingFilter('accountNo', resolved.accountNo);
          ui.accountQuery = formatLedgerAccountLookupLabel(resolved);
          ui.accountDirty = false;
          closeFilterPicker();
          rerender();
          return;
        }
        applyPendingFilters();
        return;
      }

      if(String(target.dataset.generalLedgerFilter || '').trim() && event.key === 'Enter'){
        event.preventDefault();
        applyPendingFilters();
      }
    };

    const handleDocumentMouseDown = (event) => {
      if(!hasOpenFilterPicker()) return;
      const target = event.target instanceof Element ? event.target : null;
      if(!target) return;
      if(runtime.panel instanceof HTMLElement && runtime.panel.contains(target)) return;
      closeFilterPicker();
      rerender();
    };

    panel.addEventListener('input', handleInput);
    panel.addEventListener('focusin', handleFocusIn);
    panel.addEventListener('click', handleClick);
    panel.addEventListener('keydown', handleKeydown);
    document.addEventListener('mousedown', handleDocumentMouseDown, true);

    return () => {
      panel.removeEventListener('input', handleInput);
      panel.removeEventListener('focusin', handleFocusIn);
      panel.removeEventListener('click', handleClick);
      panel.removeEventListener('keydown', handleKeydown);
      document.removeEventListener('mousedown', handleDocumentMouseDown, true);
    };
  }

  function cleanupView(){
    if(typeof runtime.detachPanelEvents === 'function') runtime.detachPanelEvents();
    runtime.detachPanelEvents = null;
    runtime.ui = null;
    safeArray(runtime.detachWindowEvents).forEach((dispose) => {
      if(typeof dispose === 'function'){
        try{ dispose(); }catch{}
      }
    });
    runtime.detachWindowEvents = [];
    runtime.panel = null;
    runtime.pendingFilters = api.readFilters();
    runtime.selectedRowId = '';
    runtime.expandedCurrencies = new Set();
  }

  function bindWindowEvents(){
    const listeners = [];
    const onEntriesUpdated = () => {
      if(!TAIF?.core?.utils?.isActiveView?.('general-ledger')) return;
      runtime.model = api.buildModel(getFilters());
      runtime.pendingFilters = getPendingFilters();
      syncExpandedCurrencies();
      rerender();
    };
    const onChartUpdated = () => {
      if(!TAIF?.core?.utils?.isActiveView?.('general-ledger')) return;
      runtime.model = api.buildModel(getFilters());
      runtime.pendingFilters = getPendingFilters();
      syncExpandedCurrencies();
      rerender();
    };
    const events = TAIF.core && TAIF.core.events;
    if(events && typeof events.onMany === 'function'){
      listeners.push(events.onMany([
        events.EVENT_NAMES.ENTRIES_VOUCHERS_UPDATED,
        events.EVENT_NAMES.SALES_PURCHASE_UPDATED,
        events.EVENT_NAMES.CASH_BOXES_UPDATED,
        events.EVENT_NAMES.CHART_OF_ACCOUNTS_UPDATED,
        events.EVENT_NAMES.CURRENCY_UPDATED,
        events.EVENT_NAMES.CURRENCY_MANAGEMENT_UPDATED,
        events.EVENT_NAMES.LEDGER_READ_MODEL_INVALIDATED
      ], onEntriesUpdated));
    }else{
      window.addEventListener('taif:entries-vouchers-updated', onEntriesUpdated);
      window.addEventListener('taif:chart-of-accounts-updated', onChartUpdated);
      window.addEventListener('taif:currency-domain-updated', onEntriesUpdated);
      window.addEventListener('taif:currency-management-updated', onEntriesUpdated);
      listeners.push(() => window.removeEventListener('taif:entries-vouchers-updated', onEntriesUpdated));
      listeners.push(() => window.removeEventListener('taif:chart-of-accounts-updated', onChartUpdated));
      listeners.push(() => window.removeEventListener('taif:currency-domain-updated', onEntriesUpdated));
      listeners.push(() => window.removeEventListener('taif:currency-management-updated', onEntriesUpdated));
    }
    runtime.detachWindowEvents = listeners;
  }

  TAIF.registerViewCleanup('general-ledger', cleanupView);
  TAIF.registerViewRenderer('general-ledger', ({ panel }) => {
    cleanupView();
    runtime.panel = panel;
    runtime.pendingFilters = api.readFilters();
    runtime.model = api.buildModel(runtime.pendingFilters);
    syncFilterUiStateWithPendingFilters({ forceAccountLabel:true, closePickers:true, resetDateState:true });
    bindWindowEvents();
    panel.innerHTML = renderShellMarkup();
    runtime.detachPanelEvents = bindPanelEvents();
  });
})();
