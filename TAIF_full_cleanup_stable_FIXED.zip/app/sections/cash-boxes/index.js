(()=>{
  const TAIF = window.TAIF;
  const { clone, escapeHtml, readJsonStorage, persistJsonState, createAnimationFrameScheduler, createStateWriter, parseNumericInput, storageGet, runCleanupCallbacks, resolveCurrencyDecimals } = TAIF.core.utils;
  const storageKeys = TAIF?.core?.storageKeys || {};
  const STORAGE_KEY = storageKeys.cashBoxes || 'taif-cash-boxes-module-v1';
  const COA_STORAGE_KEY = storageKeys.chartOfAccounts || 'taif-chart-of-accounts-centers-v3';
  const ENTRIES_STORAGE_KEY = storageKeys.entriesVouchers || 'taif-entries-vouchers-module-v1';
  const SALES_PURCHASE_STORAGE_KEY = storageKeys.salesPurchaseInvoice || 'taif-sales-purchase-invoice-records-v1';
  const CURRENCY_STORAGE_KEY = storageKeys.currencyDomain || storageKeys.currencyManagement || 'taif-currency-management-module-v1';
  const SALES_PURCHASE_UPDATED_EVENT = 'taif:sales-purchase-invoice-updated';
  const BALANCE_EPSILON = 1e-9;
  const runtime = {
    listenersBound: false,
    refreshHandler: null,
    modalBackdrop: null,
    modalWindow: null,
    modalBody: null,
    modalCleanups: [],
    pendingFocusCenterId: '',
    storageHandler: null,
    refreshScheduler: null,
    cachedStateRaw: '',
    cachedComparableStateRaw: '',
    cachedStateValue: null
  };

  const DEFAULT_ACCOUNT = {
    accountNo: '001',
    name: 'صندوق محلي اساسي'
  };

  const DEFAULT_STATE = {
    version: 1,
    updatedAt: Date.now(),
    selectedCenterId: '',
    selectedCenterAccountNo: '',
    boxes: [
      {
        id: 'cash-box-main-local',
        linkedAccountNo: DEFAULT_ACCOUNT.accountNo,
        linkedAccountName: DEFAULT_ACCOUNT.name,
        balances: { USD: 0 }
      }
    ]
  };

  const DEFAULT_CENTER_SEEDS = [
    { id:'coa-default-001', accountNo:'001', name:'صندوق محلي اساسي' },
    { id:'coa-default-003', accountNo:'002', name:'عملات مدفوعة' },
    { id:'coa-default-004', accountNo:'003', name:'عملات محققة' },
    { id:'coa-default-005', accountNo:'004', name:'حوالات لم تسلم' },
    { id:'coa-default-006', accountNo:'005', name:'حسابات القطع الأجنبي' },
    { id:'coa-default-007', accountNo:'006', name:'رأس المال المدفوع' },
    { id:'coa-default-008', accountNo:'007', name:'مصاريف' }
  ];

  const toNumber = parseNumericInput;


  function resolveService(name){
    const registry = TAIF.services || {};
    if(typeof registry.resolve === 'function') return registry.resolve(name);
    return registry[name] || null;
  }

  function normalizeBalances(input){
    const source = input && typeof input === 'object' ? input : {};
    const balances = {};
    Object.keys(source).forEach((code) => {
      const safeCode = String(code || '').trim().toUpperCase();
      if(!safeCode) return;
      balances[safeCode] = toNumber(source[code], 0);
    });
    if(!Object.prototype.hasOwnProperty.call(balances, 'USD')) balances.USD = 0;
    return balances;
  }

  function normalizeBox(input){
    const raw = input && typeof input === 'object' ? input : {};
    return {
      id: String(raw.id || 'cash-box-main-local'),
      linkedAccountNo: String(raw.linkedAccountNo || DEFAULT_ACCOUNT.accountNo).trim() || DEFAULT_ACCOUNT.accountNo,
      linkedAccountName: String(raw.linkedAccountName || DEFAULT_ACCOUNT.name).trim() || DEFAULT_ACCOUNT.name,
      balances: normalizeBalances(raw.balances)
    };
  }

  function normalizeState(input){
    const raw = input && typeof input === 'object' ? input : {};
    const boxes = Array.isArray(raw.boxes) && raw.boxes.length ? raw.boxes.map(normalizeBox) : clone(DEFAULT_STATE.boxes);
    return {
      version: 1,
      updatedAt: Number(raw.updatedAt) > 0 ? Number(raw.updatedAt) : 1,
      selectedCenterId: String(raw.selectedCenterId || '').trim(),
      selectedCenterAccountNo: String(raw.selectedCenterAccountNo || '').trim(),
      boxes
    };
  }

  const safeEscape = escapeHtml;

  function normalizeChartCenter(input, index = 0){
    const raw = input && typeof input === 'object' ? input : {};
    const createdAt = Number(raw.createdAt) > 0 ? Number(raw.createdAt) : (index + 1);
    const updatedAt = Number(raw.updatedAt) > 0 ? Number(raw.updatedAt) : createdAt;
    return {
      id: String(raw.id || `cash-center-${index + 1}`).trim() || `cash-center-${index + 1}`,
      accountNo: String(raw.accountNo || '').trim(),
      name: String(raw.name || '').trim(),
      imageDataUrl: String(raw.imageDataUrl || '').trim(),
      deleted: !!raw.deleted,
      createdAt,
      updatedAt
    };
  }

  function readChartCenters(){
    const chartApi = TAIF.chartOfAccounts;
    const source = chartApi && typeof chartApi.readState === 'function'
      ? chartApi.readState()
      : readJsonStorage(COA_STORAGE_KEY, DEFAULT_CENTER_SEEDS);

    return (Array.isArray(source) ? source : DEFAULT_CENTER_SEEDS)
      .map(normalizeChartCenter)
      .filter((center) => !center.deleted && (center.name || center.accountNo))
      .sort((left, right) => (Number(left.createdAt) || 0) - (Number(right.createdAt) || 0));
  }

  function resolveSelectedCenterId(state, centers){
    const activeCenters = Array.isArray(centers) ? centers : [];
    if(!activeCenters.length) return '';

    const storedId = state && typeof state.selectedCenterId === 'string' ? state.selectedCenterId.trim() : '';
    if(storedId && activeCenters.some((center) => center.id === storedId)) return storedId;

    const storedAccountNo = state && typeof state.selectedCenterAccountNo === 'string'
      ? state.selectedCenterAccountNo.trim()
      : '';
    if(storedAccountNo){
      const matched = activeCenters.find((center) => center.accountNo === storedAccountNo);
      if(matched) return matched.id;
    }

    const linkedAccountNo = state && Array.isArray(state.boxes) && state.boxes[0] && state.boxes[0].linkedAccountNo
      ? String(state.boxes[0].linkedAccountNo).trim()
      : '';
    if(linkedAccountNo){
      const matched = activeCenters.find((center) => center.accountNo === linkedAccountNo);
      if(matched) return matched.id;
    }

    return activeCenters[0].id;
  }

  function resolveSelectedCenter(centers, selectedCenterId){
    const activeCenters = Array.isArray(centers) ? centers : [];
    if(!activeCenters.length) return null;
    return activeCenters.find((center) => center.id === selectedCenterId) || activeCenters[0] || null;
  }

  function resolveCenterImageSrc(center){
    const imageValue = center && typeof center.imageDataUrl === 'string' ? center.imageDataUrl.trim() : '';
    const chartApi = TAIF.chartOfAccounts && typeof TAIF.chartOfAccounts === 'object'
      ? TAIF.chartOfAccounts
      : null;
    if(chartApi && typeof chartApi.getCenterImageSrc === 'function'){
      return chartApi.getCenterImageSrc(imageValue);
    }
    return imageValue || 'assets/icons/chart-of-accounts-default-avatar.png';
  }

  function formatCenterDate(value){
    const date = new Date(Number(value) || Date.now());
    if(Number.isNaN(date.getTime())) return '—';
    const year = String(date.getFullYear()).padStart(4, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function createCenterCheckIcon(){
    return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m5 13 4 4L19 7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
  }

  function createCentersPanelMarkup(centers, selectedCenterId){
    const activeCenters = Array.isArray(centers) ? centers : [];
    if(!activeCenters.length){
      return `
        <div class="cash-boxes-centers" data-cash-box-centers-root="true">
          <div class="cash-boxes-centers__empty">لا توجد مراكز متاحة حالياً داخل شجرة الحسابات.</div>
        </div>
      `;
    }

    const optionsMarkup = activeCenters.map((center) => {
      const isActive = center.id === selectedCenterId;
      const centerName = safeEscape(center.name || 'بدون اسم');
      const accountNo = safeEscape(center.accountNo || '—');
      const centerId = safeEscape(center.id);
      return `
        <button class="cash-boxes-center-option${isActive ? ' is-active' : ''}" type="button" role="option" aria-selected="${isActive ? 'true' : 'false'}" data-cash-box-center-id="${centerId}" aria-label="اختيار المركز ${centerName} ${accountNo}">
          <span class="cash-boxes-center-option__copy">
            <span class="cash-boxes-center-option__name">${centerName}</span>
            <span class="cash-boxes-center-option__account" dir="ltr">${accountNo}</span>
          </span>
          <span class="cash-boxes-center-option__check" aria-hidden="true">${createCenterCheckIcon()}</span>
        </button>
      `;
    }).join('');

    return `
      <div class="cash-boxes-centers" data-cash-box-centers-root="true">
        <div class="cash-boxes-centers__list" data-cash-box-centers-list="true" role="listbox" aria-label="مراكز شجرة الحسابات">${optionsMarkup}</div>
      </div>
    `;
  }

  function getCenterOptionButtons(root = runtime.modalBody){
    if(!(root instanceof HTMLElement)) return [];
    return Array.from(root.querySelectorAll('[data-cash-box-center-id]')).filter((button) => button instanceof HTMLButtonElement);
  }

  function getCenterButtonById(centerId, root = runtime.modalBody){
    const targetId = String(centerId || '').trim();
    if(!(root instanceof HTMLElement) || !targetId) return null;
    return getCenterOptionButtons(root).find((button) => button.dataset.cashBoxCenterId === targetId) || null;
  }

  function focusCenterButton(centerId){
    const button = getCenterButtonById(centerId);
    if(!(button instanceof HTMLButtonElement)) return;
    requestAnimationFrame(() => {
      try{ button.focus({ preventScroll:true }); }catch{ try{ button.focus(); }catch{} }
      try{ button.scrollIntoView({ block:'nearest', inline:'nearest' }); }catch{}
    });
  }

  function updateCenterSelectionUi(selectedCenterId, root = runtime.modalBody){
    const buttons = getCenterOptionButtons(root);
    buttons.forEach((button) => {
      const isActive = button.dataset.cashBoxCenterId === selectedCenterId;
      button.classList.toggle('is-active', isActive);
      button.setAttribute('aria-selected', isActive ? 'true' : 'false');
    });
  }

  function commitCenterSelection(centerId, { focus = false } = {}){
    const nextId = String(centerId || '').trim();
    if(!nextId) return false;

    const state = readState();
    const selectedCenter = resolveSelectedCenter(readChartCenters(), nextId);
    const nextAccountNo = String(selectedCenter?.accountNo || '').trim();
    if(state.selectedCenterId === nextId && state.selectedCenterAccountNo === nextAccountNo){
      updateCenterSelectionUi(nextId);
      if(focus) focusCenterButton(nextId);
      return true;
    }

    runtime.pendingFocusCenterId = nextId;
    writeState({
      ...state,
      selectedCenterId: nextId,
      selectedCenterAccountNo: nextAccountNo,
      updatedAt: Date.now()
    });
    updateCenterSelectionUi(nextId);
    if(focus) focusCenterButton(nextId);
    return true;
  }

  function moveCenterSelectionFrom(button, direction){
    const buttons = getCenterOptionButtons();
    if(!buttons.length) return false;
    const currentIndex = Math.max(0, buttons.indexOf(button));
    let nextIndex = currentIndex;

    if(direction === 'start') nextIndex = 0;
    else if(direction === 'end') nextIndex = buttons.length - 1;
    else {
      const step = direction < 0 ? -1 : 1;
      nextIndex = Math.min(buttons.length - 1, Math.max(0, currentIndex + step));
    }

    const nextButton = buttons[nextIndex];
    if(!(nextButton instanceof HTMLButtonElement)) return false;
    const nextId = nextButton.dataset.cashBoxCenterId || '';
    commitCenterSelection(nextId, { focus:true });
    return true;
  }

  function bindSurfaceInteractions(body){
    if(!(body instanceof HTMLElement)) return () => {};

    const resolveCenterButton = (event) => {
      const target = event && event.target instanceof Element ? event.target : null;
      if(!target) return null;
      const button = target.closest('[data-cash-box-center-id]');
      if(!(button instanceof HTMLButtonElement) || !body.contains(button)) return null;
      return button;
    };

    const onPointerDown = (event) => {
      const button = resolveCenterButton(event);
      if(!(button instanceof HTMLButtonElement)) return;
      button.dataset.cashBoxPressed = 'true';
    };

    const onPointerUp = (event) => {
      const button = resolveCenterButton(event);
      if(!(button instanceof HTMLButtonElement)) return;
      if(button.dataset.cashBoxPressed === 'true'){
        delete button.dataset.cashBoxPressed;
        event.preventDefault();
        commitCenterSelection(button.dataset.cashBoxCenterId, { focus:true });
      }
    };

    const onClick = (event) => {
      const button = resolveCenterButton(event);
      if(!(button instanceof HTMLButtonElement)) return;
      delete button.dataset.cashBoxPressed;
      event.preventDefault();
      commitCenterSelection(button.dataset.cashBoxCenterId, { focus:true });
    };

    const onPointerCancel = (event) => {
      const button = resolveCenterButton(event);
      if(!(button instanceof HTMLButtonElement)) return;
      delete button.dataset.cashBoxPressed;
    };

    const onKeyDown = (event) => {
      const button = resolveCenterButton(event);
      if(!(button instanceof HTMLButtonElement)) return;

      if(event.key === 'ArrowDown'){
        event.preventDefault();
        moveCenterSelectionFrom(button, 1);
        return;
      }

      if(event.key === 'ArrowUp'){
        event.preventDefault();
        moveCenterSelectionFrom(button, -1);
        return;
      }

      if(event.key === 'Home'){
        event.preventDefault();
        moveCenterSelectionFrom(button, 'start');
        return;
      }

      if(event.key === 'End'){
        event.preventDefault();
        moveCenterSelectionFrom(button, 'end');
        return;
      }

      if(event.key === 'Enter' || event.key === ' '){
        event.preventDefault();
        commitCenterSelection(button.dataset.cashBoxCenterId, { focus:true });
      }
    };

    body.addEventListener('pointerdown', onPointerDown, true);
    body.addEventListener('pointerup', onPointerUp, true);
    body.addEventListener('pointercancel', onPointerCancel, true);
    body.addEventListener('click', onClick);
    body.addEventListener('keydown', onKeyDown);

    return () => {
      body.removeEventListener('pointerdown', onPointerDown, true);
      body.removeEventListener('pointerup', onPointerUp, true);
      body.removeEventListener('pointercancel', onPointerCancel, true);
      body.removeEventListener('click', onClick);
      body.removeEventListener('keydown', onKeyDown);
    };
  }


  function serializeCashBoxesState(value){
    try{
      return JSON.stringify(value);
    }catch{
      return '';
    }
  }

  function serializeComparableCashBoxesState(value){
    const normalized = normalizeState(value);
    return serializeCashBoxesState({
      version: normalized.version,
      selectedCenterId: normalized.selectedCenterId,
      selectedCenterAccountNo: normalized.selectedCenterAccountNo,
      boxes: normalized.boxes
    });
  }

  function cacheCashBoxesState(nextState){
    runtime.cachedStateValue = nextState && typeof nextState === 'object' ? nextState : normalizeState(DEFAULT_STATE);
    runtime.cachedStateRaw = serializeCashBoxesState(runtime.cachedStateValue);
    runtime.cachedComparableStateRaw = serializeComparableCashBoxesState(runtime.cachedStateValue);
    return runtime.cachedStateValue;
  }

  function dispatchCashBoxesUpdated(state){
    const detail = { state: clone(state) };
    const emit = () => {
      const events = TAIF.core && TAIF.core.events;
      if(events && typeof events.emitDomainUpdate === 'function'){
        events.emitDomainUpdate('cash-boxes', detail, { source:'cash-boxes-view' });
        return;
      }
      try{
        window.dispatchEvent(new CustomEvent('taif:cash-boxes-updated', { detail }));
      }catch{}
    };

    if(typeof window.requestAnimationFrame === 'function'){
      window.requestAnimationFrame(emit);
      return;
    }

    window.setTimeout(emit, 0);
  }

  const persistState = typeof createStateWriter === 'function'
    ? createStateWriter(STORAGE_KEY, normalizeState)
    : ((input) => persistJsonState(STORAGE_KEY, input, normalizeState));

  function writeState(input){
    const normalizedInput = normalizeState(input);
    const comparableRaw = serializeComparableCashBoxesState(normalizedInput);
    if(comparableRaw && runtime.cachedStateValue && comparableRaw === runtime.cachedComparableStateRaw){
      return runtime.cachedStateValue;
    }

    const nextState = cacheCashBoxesState(persistState(normalizedInput));
    dispatchCashBoxesUpdated(nextState);
    return nextState;
  }

  function readState(){
    const storedRaw = typeof storageGet === 'function' ? storageGet(STORAGE_KEY, '') : '';
    if(storedRaw && runtime.cachedStateValue && storedRaw === runtime.cachedStateRaw) return runtime.cachedStateValue;

    const stored = storedRaw ? readJsonStorage(STORAGE_KEY, null) : null;
    if(!stored) return writeState(DEFAULT_STATE);

    const normalized = normalizeState(stored);
    if(serializeCashBoxesState(stored) !== serializeCashBoxesState(normalized)) return writeState(normalized);
    return cacheCashBoxesState(normalized);
  }

  function getLinkedAccount(){
    const chartApi = TAIF.chartOfAccounts;
    const rows = chartApi && typeof chartApi.readState === 'function' ? chartApi.readState() : [];
    const found = Array.isArray(rows)
      ? rows.find((item) => !item.deleted && (String(item.accountNo) === DEFAULT_ACCOUNT.accountNo || String(item.name).trim() === DEFAULT_ACCOUNT.name))
      : null;

    return {
      accountNo: found && found.accountNo ? String(found.accountNo) : DEFAULT_ACCOUNT.accountNo,
      name: found && found.name ? String(found.name) : DEFAULT_ACCOUNT.name
    };
  }


  function buildSyncedPrimaryState(state){
    const safeState = state && typeof state === 'object' ? state : readState();
    const account = getLinkedAccount();
    const current = Array.isArray(safeState.boxes) && safeState.boxes.length ? safeState.boxes[0] : normalizeBox(DEFAULT_STATE.boxes[0]);
    const next = normalizeBox({
      ...current,
      linkedAccountNo: account.accountNo,
      linkedAccountName: account.name
    });

    const stateChanged = !safeState.boxes
      || !safeState.boxes.length
      || safeState.boxes[0].linkedAccountNo !== next.linkedAccountNo
      || safeState.boxes[0].linkedAccountName !== next.linkedAccountName;

    if(!stateChanged) return safeState;

    return writeState({
      ...safeState,
      boxes: [next],
      updatedAt: Date.now()
    });
  }

  function syncPrimaryBoxState(state = null){
    return buildSyncedPrimaryState(state || readState());
  }


  function normalizeCurrencyMeta(input){
    const raw = input && typeof input === 'object' ? input : {};
    const code = String(raw.code || raw.value || '').trim().toUpperCase().replace(/[^A-Z]/g, '').slice(0, 5);
    if(!code) return null;
    const flags = TAIF.assets && TAIF.assets.flags ? TAIF.assets.flags : null;
    const resolvedFlag = String(raw.flag || '').trim().toLowerCase()
      || (flags && typeof flags.resolveCountryCodeForCurrency === 'function' ? flags.resolveCountryCodeForCurrency(code) : '')
      || 'xx';
    return {
      code,
      name: String(raw.name || code).trim() || code,
      flag: resolvedFlag,
      decimals: resolveCurrencyDecimals(raw.decimals, 2)
    };
  }

  function readCurrencyCatalogSafe(){
    const currencyApi = TAIF.currencyDomain || TAIF.currencyManagement || {};
    const currencyFeature = TAIF.currencyDomain || TAIF.currencyManagementFeature || {};
    const defaultCurrencies = Array.isArray(currencyFeature.DEFAULT_CURRENCIES) && currencyFeature.DEFAULT_CURRENCIES.length
      ? currencyFeature.DEFAULT_CURRENCIES
      : [{ code:'USD', name:'الدولار الأمريكي', flag:'us', decimals:2 }];

    const state = typeof currencyApi.readState === 'function'
      ? currencyApi.readState()
      : readJsonStorage(CURRENCY_STORAGE_KEY, null);

    const source = Array.isArray(state?.currencies)
      ? state.currencies
      : (Array.isArray(state) ? state : defaultCurrencies);

    const catalog = source.map(normalizeCurrencyMeta).filter(Boolean);
    return catalog.length ? catalog : defaultCurrencies.map(normalizeCurrencyMeta).filter(Boolean);
  }

  function normalizeEntryLineForBalance(input){
    const raw = input && typeof input === 'object' ? input : {};
    const side = String(raw.side || '').trim().toLowerCase() === 'credit' ? 'credit' : 'debit';
    const amount = toNumber(raw.amount, 0);
    let debit = toNumber(raw.debit, 0);
    let credit = toNumber(raw.credit, 0);

    if(debit <= BALANCE_EPSILON && credit <= BALANCE_EPSILON && amount > BALANCE_EPSILON){
      if(side === 'credit') credit = amount;
      else debit = amount;
    }

    return {
      accountNo: String(raw.accountNo || '').trim(),
      debit,
      credit
    };
  }

  function inferFallbackPrimarySide(record){
    const type = String(record?.type || '').trim().toLowerCase();
    if(type === 'payment') return 'credit';
    if(type === 'receipt') return 'debit';
    if(type === 'journal'){
      if(toNumber(record?.paymentAmount, 0) > BALANCE_EPSILON) return 'credit';
      if(toNumber(record?.receiptAmount, 0) > BALANCE_EPSILON) return 'debit';
    }
    if(type === 'opening'){
      return toNumber(record?.paymentAmount, 0) > BALANCE_EPSILON ? 'credit' : 'debit';
    }
    return 'debit';
  }

  function inferFallbackLinesForRecord(record){
    const amount = Math.max(
      toNumber(record?.amount, 0),
      toNumber(record?.netAmount, 0),
      toNumber(record?.grossAmount, 0)
    );

    if(amount <= BALANCE_EPSILON) return [];

    const cashAccountNo = String(record?.cashAccountNo || '').trim();
    const counterpartAccountNo = String(record?.counterpartAccountNo || '').trim();
    const primarySide = inferFallbackPrimarySide(record);
    const lines = [];

    if(cashAccountNo){
      lines.push({
        accountNo: cashAccountNo,
        debit: primarySide === 'debit' ? amount : 0,
        credit: primarySide === 'credit' ? amount : 0
      });
    }

    if(counterpartAccountNo){
      lines.push({
        accountNo: counterpartAccountNo,
        debit: primarySide === 'credit' ? amount : 0,
        credit: primarySide === 'debit' ? amount : 0
      });
    }

    return lines;
  }

  function normalizeEntryRecordForBalance(input){
    const raw = input && typeof input === 'object' ? input : {};
    const rawLines = Array.isArray(raw.lines) ? raw.lines.map(normalizeEntryLineForBalance).filter((line) => line.accountNo) : [];
    const lines = rawLines.length ? rawLines : inferFallbackLinesForRecord(raw);
    return {
      status: String(raw.status || '').trim().toLowerCase() === 'posted' ? 'posted' : 'draft',
      currency: String(raw.currency || 'USD').trim().toUpperCase() || 'USD',
      lines
    };
  }

  function isSalesPurchaseGeneratedEntryRecord(record){
    const safeRecord = record && typeof record === 'object' ? record : {};
    const safeId = String(safeRecord.id || '').trim();
    if(safeId.startsWith('entry-record-sales-purchase-')) return true;
    if(String(safeRecord.sourceSalesPurchaseRecordId || '').trim()) return true;
    if(String(safeRecord.sourceSalesPurchaseNumber || '').trim()) return true;
    return false;
  }

  function normalizeLookupText(value){
    return String(value ?? '')
      .trim()
      .toLowerCase()
      .replace(/[ً-ٰٟ]/g, '')
      .replace(/[أإآٱ]/g, 'ا')
      .replace(/ة/g, 'ه')
      .replace(/ى/g, 'ي')
      .replace(/ؤ/g, 'و')
      .replace(/ئ/g, 'ي')
      .replace(/ـ/g, '')
      .replace(/[^a-z0-9؀-ۿ\s]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function normalizeSalesPurchaseRecordForBalance(input, index = 0){
    const raw = input && typeof input === 'object' ? input : {};
    const createdAt = Number(raw.createdAt) > 0 ? Number(raw.createdAt) : (Date.now() + index);
    const updatedAt = Number(raw.updatedAt) > 0 ? Number(raw.updatedAt) : createdAt;
    const status = String(raw.status || '').trim().toLowerCase() === 'reversed'
      ? 'reversed'
      : (String(raw.status || '').trim().toLowerCase() === 'draft' ? 'draft' : 'posted');
    return {
      id: String(raw.id || `cash-balance-sp-${createdAt}-${index + 1}`).trim(),
      status,
      cashAccountNo: String(raw.cashAccountNo || '').trim(),
      cashAccountName: String(raw.cashAccountName || '').trim(),
      tradeCurrencyCode: String(raw.tradeCurrencyCode || '').trim().toUpperCase(),
      tradeCurrencyName: String(raw.tradeCurrencyName || '').trim(),
      settlementCurrencyCode: String(raw.settlementCurrencyCode || '').trim().toUpperCase(),
      settlementCurrencyName: String(raw.settlementCurrencyName || '').trim(),
      amountValue: Math.max(0, toNumber(raw.amountValue, 0)),
      counterpartAmountValue: Math.max(0, toNumber(raw.counterpartAmountValue, 0)),
      accountingBridgeAccountNo: String(raw.accountingBridgeAccountNo || '').trim(),
      accountingBridgeAccountName: String(raw.accountingBridgeAccountName || '').trim(),
      createdAt,
      updatedAt,
      type: String(raw.type || '').trim().toLowerCase() === 'sale' ? 'sale' : 'purchase'
    };
  }

  function readSalesPurchaseStateSafe(){
    const salesPurchaseApi = TAIF.salesPurchaseInvoice || {};
    const state = typeof salesPurchaseApi.readState === 'function'
      ? salesPurchaseApi.readState()
      : readJsonStorage(SALES_PURCHASE_STORAGE_KEY, null);
    const sourceRecords = Array.isArray(state?.records)
      ? state.records
      : (Array.isArray(state) ? state : []);
    return {
      records: sourceRecords.map((record, index) => normalizeSalesPurchaseRecordForBalance(record, index))
    };
  }

  function resolveSalesPurchaseBridgeCenter(record, centers = readChartCenters()){
    const safeRecord = record && typeof record === 'object' ? record : {};
    const activeCenters = Array.isArray(centers) ? centers : [];
    const safeCashAccountNo = String(safeRecord.cashAccountNo || '').trim();
    const explicitAccountNo = String(safeRecord.accountingBridgeAccountNo || '').trim();
    const explicitAccountName = String(safeRecord.accountingBridgeAccountName || '').trim();

    const exactNames = [
      'حسابات القطع الأجنبي',
      'حسابات القطع الاجنبي',
      'حسابات القطع',
      'القطع الأجنبي',
      'القطع الاجنبي'
    ].map((value) => normalizeLookupText(value));
    const keywordMatchers = ['حسابات القطع', 'القطع الاجنبي', 'القطع الأجنبي', 'قطع اجنبي', 'قطع أجنبي', 'صرف'].map((value) => normalizeLookupText(value));

    if(explicitAccountNo && explicitAccountNo !== safeCashAccountNo){
      const explicitCenter = activeCenters.find((center) => String(center?.accountNo || '').trim() === explicitAccountNo) || null;
      const explicitNormalizedName = normalizeLookupText(explicitCenter?.name || explicitAccountName);
      const explicitLooksLikeBridge = explicitAccountNo === '005'
        || (!!explicitNormalizedName && exactNames.includes(explicitNormalizedName))
        || (!!explicitNormalizedName && keywordMatchers.some((keyword) => explicitNormalizedName.includes(keyword)));
      if(explicitCenter && explicitLooksLikeBridge) return explicitCenter;
      if(!explicitCenter && explicitLooksLikeBridge){
        return { accountNo: explicitAccountNo, name: explicitAccountName || explicitAccountNo };
      }
    }

    const exactMatch = activeCenters.find((center) => {
      const accountNo = String(center?.accountNo || '').trim();
      if(!accountNo || accountNo === safeCashAccountNo) return false;
      const normalizedName = normalizeLookupText(center?.name);
      return !!normalizedName && exactNames.includes(normalizedName);
    }) || null;
    if(exactMatch) return exactMatch;

    const canonicalMatch = activeCenters.find((center) => String(center?.accountNo || '').trim() === '005' && String(center?.accountNo || '').trim() !== safeCashAccountNo) || null;
    if(canonicalMatch) return canonicalMatch;

    const keywordMatch = activeCenters.find((center) => {
      const accountNo = String(center?.accountNo || '').trim();
      if(!accountNo || accountNo === safeCashAccountNo) return false;
      const normalizedName = normalizeLookupText(center?.name);
      return keywordMatchers.some((keyword) => normalizedName.includes(keyword));
    }) || null;
    if(keywordMatch) return keywordMatch;

    return { accountNo: '005', name: 'حسابات القطع الأجنبي' };
  }

  function buildSalesPurchaseBalanceLegs(record){
    const safeRecord = record && typeof record === 'object' ? record : {};
    return [
      {
        kind: 'trade',
        currencyCode: String(safeRecord.tradeCurrencyCode || '').trim().toUpperCase(),
        amount: Math.max(0, toNumber(safeRecord.amountValue, 0)),
        cashSide: safeRecord.type === 'purchase' ? 'debit' : 'credit'
      },
      {
        kind: 'settlement',
        currencyCode: String(safeRecord.settlementCurrencyCode || '').trim().toUpperCase(),
        amount: Math.max(0, toNumber(safeRecord.counterpartAmountValue, 0)),
        cashSide: safeRecord.type === 'sale' ? 'debit' : 'credit'
      }
    ].filter((leg) => leg.currencyCode && leg.amount > BALANCE_EPSILON);
  }


  function resolveSalesPurchaseBalancePostingTargets(record, leg, bridgeCenter){
    const safeRecord = record && typeof record === 'object' ? record : {};
    const safeLeg = leg && typeof leg === 'object' ? leg : {};
    const safeBridgeCenter = bridgeCenter && typeof bridgeCenter === 'object' ? bridgeCenter : {};
    const isTradeLeg = safeLeg.kind === 'trade';
    const primaryAccountNo = String(isTradeLeg ? safeBridgeCenter.accountNo : safeRecord.cashAccountNo || '').trim();
    const primaryAccountName = String(isTradeLeg ? safeBridgeCenter.name : safeRecord.cashAccountName || '').trim();
    const counterpartAccountNo = String(isTradeLeg ? safeRecord.cashAccountNo : safeBridgeCenter.accountNo || '').trim();
    const counterpartAccountName = String(isTradeLeg ? safeRecord.cashAccountName : safeBridgeCenter.name || '').trim();
    const isPrimaryDebit = safeLeg.cashSide !== 'credit';
    return {
      primaryAccountNo,
      primaryAccountName,
      counterpartAccountNo,
      counterpartAccountName,
      isPrimaryDebit
    };
  }

  function createSyntheticSalesPurchaseBalanceRecord(record, leg, bridgeCenter){
    const safeRecord = record && typeof record === 'object' ? record : {};
    const safeBridgeCenter = bridgeCenter && typeof bridgeCenter === 'object' ? bridgeCenter : { accountNo:'005', name:'حسابات القطع الأجنبي' };
    const targets = resolveSalesPurchaseBalancePostingTargets(safeRecord, leg, safeBridgeCenter);
    const amount = Math.max(0, toNumber(leg?.amount, 0));
    if(!targets.primaryAccountNo || !targets.counterpartAccountNo || amount <= BALANCE_EPSILON) return null;
    return normalizeEntryRecordForBalance({
      status: safeRecord.status,
      currency: leg.currencyCode,
      lines: [
        {
          accountNo: targets.primaryAccountNo,
          debit: targets.isPrimaryDebit ? amount : 0,
          credit: targets.isPrimaryDebit ? 0 : amount
        },
        {
          accountNo: targets.counterpartAccountNo,
          debit: targets.isPrimaryDebit ? 0 : amount,
          credit: targets.isPrimaryDebit ? amount : 0
        }
      ]
    });
  }

  function readSalesPurchaseSyntheticBalanceRecords(){
    const salesPurchaseFeature = TAIF.salesPurchaseFeature || {};
    if(typeof salesPurchaseFeature.buildSalesPurchasePostedCashTotals === 'function'){
      return Array.from(salesPurchaseFeature.buildSalesPurchasePostedCashTotals().entries())
        .map(([key, amount], index) => {
          const [accountNo = '', currencyCode = 'USD'] = String(key || '').split('::');
          const safeAccountNo = String(accountNo || '').trim();
          const safeCurrencyCode = String(currencyCode || 'USD').trim().toUpperCase() || 'USD';
          const numericAmount = toNumber(amount, 0);
          if(!safeAccountNo || Math.abs(numericAmount) <= BALANCE_EPSILON) return null;
          return normalizeEntryRecordForBalance({
            id: String(`cash-balance-sp-${safeAccountNo}-${safeCurrencyCode}-${index + 1}`),
            status: 'posted',
            currency: safeCurrencyCode,
            lines: [{
              accountNo: safeAccountNo,
              debit: numericAmount > 0 ? numericAmount : 0,
              credit: numericAmount < 0 ? Math.abs(numericAmount) : 0
            }]
          });
        })
        .filter(Boolean);
    }

    const centers = readChartCenters();
    const salesRecords = readSalesPurchaseStateSafe().records;
    return salesRecords.flatMap((record) => {
      const bridgeCenter = resolveSalesPurchaseBridgeCenter(record, centers);
      return buildSalesPurchaseBalanceLegs(record)
        .map((leg) => createSyntheticSalesPurchaseBalanceRecord(record, leg, bridgeCenter))
        .filter(Boolean);
    });
  }

  function readEntriesStateSafe(){
    const entriesDomain = TAIF.entriesVouchersDomain || {};
    const entriesFeature = TAIF.entriesVouchersFeature || {};
    let state = null;

    if(typeof entriesDomain.readState === 'function'){
      state = entriesDomain.readState();
    }else if(typeof entriesFeature.readState === 'function'){
      state = entriesFeature.readState();
    }else{
      state = readJsonStorage(ENTRIES_STORAGE_KEY, null);
    }

    const sourceRecords = Array.isArray(state?.records)
      ? state.records
      : (Array.isArray(state) ? state : []);

    return {
      records: sourceRecords.map(normalizeEntryRecordForBalance)
    };
  }

  function buildLegacyAccountCurrencyTotals(){
    const salesPurchaseFeature = TAIF.salesPurchaseFeature || {};
    if(typeof salesPurchaseFeature.buildSalesPurchaseCompositeAccountCurrencyTotals === 'function'){
      try{
        const totals = salesPurchaseFeature.buildSalesPurchaseCompositeAccountCurrencyTotals();
        if(totals instanceof Map) return new Map(totals);
        if(Array.isArray(totals)) return new Map(totals);
      }catch{}
    }

    const totals = new Map();
    const records = readEntriesStateSafe().records;
    records.forEach((record) => {
      if(record.status !== 'posted') return;
      const currencyCode = String(record.currency || 'USD').trim().toUpperCase() || 'USD';
      const lines = Array.isArray(record.lines) ? record.lines : [];
      lines.forEach((line) => {
        const accountNo = String(line?.accountNo || '').trim();
        if(!accountNo) return;
        const delta = toNumber(line?.debit, 0) - toNumber(line?.credit, 0);
        if(Math.abs(delta) <= BALANCE_EPSILON) return;
        const key = `${accountNo}::${currencyCode}`;
        totals.set(key, toNumber(totals.get(key), 0) + delta);
      });
    });
    return totals;
  }

  function buildServiceLedgerAccountCurrencyTotals(){
    const ledgerService = resolveService('ledger-service');
    if(!ledgerService || typeof ledgerService.buildAccountCurrencyTotals !== 'function') return null;
    try{
      const serviceTotals = ledgerService.buildAccountCurrencyTotals();
      if(!(serviceTotals instanceof Map)) return null;
      const normalized = new Map();
      serviceTotals.forEach((value, key) => {
        const amount = value && typeof value === 'object'
          ? toNumber(value.balance, 0)
          : toNumber(value, 0);
        if(Math.abs(amount) <= BALANCE_EPSILON) return;
        normalized.set(String(key || '').trim(), amount);
      });
      return normalized;
    }catch{
      return null;
    }
  }

  function buildAuthoritativeAccountCurrencyTotals(){
    const legacyTotals = buildLegacyAccountCurrencyTotals();
    const serviceTotals = buildServiceLedgerAccountCurrencyTotals();
    if(serviceTotals instanceof Map && (!legacyTotals || !legacyTotals.size) && serviceTotals.size){
      return new Map(serviceTotals);
    }
    return new Map(legacyTotals);
  }

  function resolveBalanceDecimals(currency){
    return resolveCurrencyDecimals(currency?.decimals, 2);
  }

  function buildAccountBalanceCards(accountNo){
    const safeAccountNo = String(accountNo || '').trim();
    if(!safeAccountNo) return [];

    const currencyCatalog = readCurrencyCatalogSafe();
    const currencyMap = new Map(currencyCatalog.map((currency, index) => [currency.code, { ...currency, order:index }]));
    const totals = new Map();
    const accountCurrencyTotals = buildAuthoritativeAccountCurrencyTotals();

    accountCurrencyTotals.forEach((amount, key) => {
      const [accountKey = '', currencyCode = 'USD'] = String(key || '').split('::');
      if(String(accountKey || '').trim() !== safeAccountNo) return;
      const safeCurrencyCode = String(currencyCode || 'USD').trim().toUpperCase() || 'USD';
      const numericAmount = toNumber(amount, 0);
      if(Math.abs(numericAmount) <= BALANCE_EPSILON) return;
      totals.set(safeCurrencyCode, toNumber(totals.get(safeCurrencyCode), 0) + numericAmount);
    });

    const balances = Array.from(totals.entries())
      .map(([code, netAmount]) => {
        if(Math.abs(netAmount) <= BALANCE_EPSILON) return null;
        const currency = currencyMap.get(code) || normalizeCurrencyMeta({ code, name: code, flag: code, decimals:2 }) || { code, name: code, flag:'xx', decimals:2 };
        return {
          code,
          name: currency.name || code,
          flag: currency.flag || code.toLowerCase(),
          decimals: resolveBalanceDecimals(currency),
          amount: netAmount,
          side: netAmount < 0 ? 'credit' : 'debit',
          order: Number(currency.order) >= 0 ? Number(currency.order) : Number.MAX_SAFE_INTEGER
        };
      })
      .filter(Boolean)
      .sort((left, right) => {
        const orderDelta = left.order - right.order;
        if(orderDelta) return orderDelta;
        return left.code.localeCompare(right.code, 'en');
      });

    return balances;
  }

  function formatBalanceAmount(value, decimals = 2){
    const number = Math.abs(toNumber(value, 0));
    const sign = value < 0 ? '-' : '+';
    const formatted = new Intl.NumberFormat('en-US', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    }).format(number);
    return `${sign}${formatted}`;
  }

  function createBalanceFlagMarkup(balance){
    const flags = TAIF.assets && TAIF.assets.flags ? TAIF.assets.flags : null;
    const asset = flags && typeof flags.resolveFlagAsset === 'function'
      ? flags.resolveFlagAsset(balance.flag || balance.code, 'circle')
      : { src:'assets/flags/circle/xx.png' };
    const imageSrc = safeEscape(asset && asset.src ? asset.src : 'assets/flags/circle/xx.png');
    return `
      <span class="cash-boxes-balance-card__flag" aria-hidden="true">
        <img src="${imageSrc}" alt="" draggable="false" loading="lazy" decoding="async">
      </span>
    `;
  }

  function createBalanceCardMarkup(balance){
    const name = safeEscape(balance.name || balance.code || 'عملة');
    const code = safeEscape(balance.code || '—');
    const sideLabel = balance.side === 'credit' ? 'دائن' : 'مدين';
    const amountText = safeEscape(formatBalanceAmount(balance.amount, balance.decimals));
    const toneClass = balance.side === 'credit' ? 'cash-boxes-balance-card--credit' : 'cash-boxes-balance-card--debit';

    return `
      <article class="cash-boxes-balance-card ${toneClass}" aria-label="رصيد ${name} ${sideLabel}">
        <div class="cash-boxes-balance-card__header">
          <div class="cash-boxes-balance-card__currency" title="${name}">
            ${createBalanceFlagMarkup(balance)}
            <span class="cash-boxes-balance-card__name">${name}</span>
          </div>
          <span class="cash-boxes-balance-card__side">${sideLabel}</span>
        </div>
        <div class="cash-boxes-balance-card__amount" dir="ltr">${amountText}</div>
        <div class="cash-boxes-balance-card__code" dir="ltr">${code}</div>
      </article>
    `;
  }

  function createBalancesEmptyMarkup(center){
    const accountName = safeEscape(center && center.name ? center.name : 'الحساب المحدد');
    return `
      <div class="cash-boxes-balances-empty" data-cash-box-balances-empty="true">
        لا يوجد على ${accountName} أي رصيد مدين أو دائن حالياً.
      </div>
    `;
  }


  function createPrimaryFieldCardMarkup(center){
    if(!center){
      return '<div class="cash-boxes-field-card cash-boxes-field-card--empty"><div class="cash-boxes-field-card__empty">اختر حسابًا من القائمة اليمنى لعرض بياناته هنا.</div></div>';
    }

    const title = safeEscape(center.name || 'بدون اسم');
    const accountNo = safeEscape(center.accountNo || '—');
    const imageSrc = safeEscape(resolveCenterImageSrc(center));
    const dateValue = safeEscape(formatCenterDate(center.updatedAt || center.createdAt));
    return `
      <article class="cash-boxes-field-card" aria-label="بيانات الحساب المحدد">
        <div class="cash-boxes-field-card__avatar-wrap">
          <span class="cash-boxes-field-card__avatar">
            <img data-coa-center-image="true" src="${imageSrc}" alt="" draggable="false" loading="eager" decoding="async">
          </span>
        </div>
        <div class="cash-boxes-field-card__identity">
          <div class="cash-boxes-field-card__title-line" title="${title} ${accountNo}">
            <span class="cash-boxes-field-card__name">${title}</span>
            <span class="cash-boxes-field-card__account" dir="ltr">${accountNo}</span>
          </div>
        </div>
        <div class="cash-boxes-field-card__date-block">
          <div class="cash-boxes-field-card__date-label">التاريخ</div>
          <div class="cash-boxes-field-card__date-value" dir="ltr">${dateValue}</div>
        </div>
      </article>
    `;
  }


  function createMainFieldsMarkup(selectedCenter){
    const balanceCards = selectedCenter ? buildAccountBalanceCards(selectedCenter.accountNo) : [];
    const balanceMarkup = balanceCards.length
      ? balanceCards.map((balance, index) => `
          <div class="cash-boxes-field-slot cash-boxes-field-slot--balance" data-cash-box-balance-slot="${index + 1}">
            ${createBalanceCardMarkup(balance)}
          </div>
        `).join('')
      : createBalancesEmptyMarkup(selectedCenter);

    return `
      <div class="cash-boxes-fields" data-cash-box-fields-root="true" aria-label="حقول الصندوق الرئيسية">
        <div class="cash-boxes-fields__grid">
          <div class="cash-boxes-field-slot cash-boxes-field-slot--primary" data-cash-box-field-slot="primary">${createPrimaryFieldCardMarkup(selectedCenter)}</div>
          <div class="cash-boxes-field-spacer" aria-hidden="true"></div>
          <div class="cash-boxes-field-spacer" aria-hidden="true"></div>
          ${balanceMarkup}
        </div>
      </div>
    `;
  }

  function hydrateCashBoxCenterImages(root){
    const chartApi = TAIF.chartOfAccounts && typeof TAIF.chartOfAccounts === 'object'
      ? TAIF.chartOfAccounts
      : null;
    if(chartApi && typeof chartApi.ensureCenterImageFallbackHandling === 'function'){
      chartApi.ensureCenterImageFallbackHandling(root);
    }
    if(chartApi && typeof chartApi.hydrateCenterImages === 'function'){
      chartApi.hydrateCenterImages(root);
    }
  }

  function createSurfaceMarkup(){
    const state = syncPrimaryBoxState();
    const centers = readChartCenters();
    const selectedCenterId = resolveSelectedCenterId(state, centers);
    const selectedCenter = resolveSelectedCenter(centers, selectedCenterId);
    return `
      <section class="cash-boxes-surface" aria-label="مساحة عمل الصناديق النقدية" data-cash-boxes-canvas="true">
        <div class="cash-boxes-layout">
          <section class="cash-boxes-panel cash-boxes-panel--right" aria-label="مراكز شجرة الحسابات">${createCentersPanelMarkup(centers, selectedCenterId)}</section>
          <section class="cash-boxes-panel cash-boxes-panel--left" aria-label="المساحة الرئيسية">${createMainFieldsMarkup(selectedCenter)}</section>
        </div>
      </section>
    `;
  }

  function removeLegacyFloatingArtifacts(){
    document.querySelectorAll('.cash-boxes-modal-window, .cash-boxes-modal-backdrop, .cash-boxes-window-layer').forEach((node) => {
      if(!(node instanceof HTMLElement)) return;
      if(typeof node.__cleanup === 'function'){
        try{ node.__cleanup(); }catch{}
      }
      node.remove();
    });
    document.body?.classList?.remove('cash-boxes--dragging-window');
  }

  function refreshModalBody(){
    if(!(runtime.modalBody instanceof HTMLElement) || !document.body.contains(runtime.modalBody)) return;
    runtime.modalBody.innerHTML = createSurfaceMarkup();
    hydrateCashBoxCenterImages(runtime.modalBody);

    if(runtime.pendingFocusCenterId){
      const focusId = runtime.pendingFocusCenterId;
      runtime.pendingFocusCenterId = '';
      focusCenterButton(focusId);
    }
  }

  function clearModalRefs(){
    runtime.modalBackdrop = null;
    runtime.modalWindow = null;
    runtime.modalBody = null;
    runtime.modalCleanups = [];
  }

  function runModalCleanups(){
    if(typeof runCleanupCallbacks === 'function'){
      runCleanupCallbacks(runtime.modalCleanups, { clearSource:true });
      return;
    }
    const callbacks = Array.isArray(runtime.modalCleanups) ? runtime.modalCleanups.splice(0, runtime.modalCleanups.length) : [];
    callbacks.forEach((cleanup) => {
      if(typeof cleanup !== 'function') return;
      try{ cleanup(); }catch{}
    });
  }

  function closeWindow(event){
    if(event){
      event.preventDefault();
      event.stopPropagation();
    }

    const body = runtime.modalBody;
    runModalCleanups();
    removeLegacyFloatingArtifacts();

    if(body instanceof HTMLElement){
      body.removeAttribute('data-cash-boxes-mounted');
      body.innerHTML = '';
    }

    runtime.refreshScheduler?.cancel?.();
    clearModalRefs();
  }

  function openWindow(panel = document.getElementById('panel')){
    bindListeners();
    removeLegacyFloatingArtifacts();
    const body = panel instanceof HTMLElement ? panel : document.getElementById('panel');
    if(!(body instanceof HTMLElement)) return null;

    if(runtime.modalBody instanceof HTMLElement && runtime.modalBody !== body){
      closeWindow();
    }else{
      runModalCleanups();
    }

    runtime.modalBackdrop = body;
    runtime.modalWindow = body;
    runtime.modalBody = body;
    runtime.modalCleanups = [];

    body.setAttribute('data-cash-boxes-mounted', 'true');
    body.innerHTML = createSurfaceMarkup();
    hydrateCashBoxCenterImages(body);
    runtime.modalCleanups.push(bindSurfaceInteractions(body));

    if(runtime.pendingFocusCenterId){
      const focusId = runtime.pendingFocusCenterId;
      runtime.pendingFocusCenterId = '';
      focusCenterButton(focusId);
    }

    return {
      backdrop: body,
      modal: body,
      body
    };
  }

  function refresh({ immediate = false } = {}){

    if(immediate || typeof createAnimationFrameScheduler !== 'function'){
      refreshModalBody();
      return;
    }
    if(!runtime.refreshScheduler){
      runtime.refreshScheduler = createAnimationFrameScheduler(() => {
        refreshModalBody();
      });
    }
    runtime.refreshScheduler.schedule();
  }

  function bindListeners(){
    if(runtime.listenersBound) return;
    runtime.listenersBound = true;
    runtime.refreshHandler = () => refresh();
    const storageKeys = new Set([
      STORAGE_KEY,
      COA_STORAGE_KEY,
      CURRENCY_STORAGE_KEY,
      ENTRIES_STORAGE_KEY,
      SALES_PURCHASE_STORAGE_KEY
    ].map((key) => {
      const safeKey = String(key || '').trim();
      if(!safeKey) return '';
      return typeof TAIF?.core?.utils?.resolveStorageKey === 'function'
        ? TAIF.core.utils.resolveStorageKey(safeKey)
        : safeKey;
    }).filter(Boolean));
    runtime.storageHandler = (event) => {
      const key = event && typeof event.key === 'string' ? event.key.trim() : '';
      if(!key || !storageKeys.has(key)) return;
      refresh();
    };
    const events = TAIF.core && TAIF.core.events;
    if(events && typeof events.onMany === 'function'){
      runtime.domainEventsCleanup = events.onMany([
        events.EVENT_NAMES.CURRENCY_UPDATED,
        events.EVENT_NAMES.CASH_BOXES_UPDATED,
        events.EVENT_NAMES.ENTRIES_VOUCHERS_UPDATED,
        events.EVENT_NAMES.SALES_PURCHASE_UPDATED,
        events.EVENT_NAMES.CHART_OF_ACCOUNTS_UPDATED
      ], runtime.refreshHandler);
    }else{
      window.addEventListener('taif:currency-domain-updated', runtime.refreshHandler);
      window.addEventListener('taif:cash-boxes-updated', runtime.refreshHandler);
      window.addEventListener('taif:entries-vouchers-updated', runtime.refreshHandler);
      window.addEventListener(SALES_PURCHASE_UPDATED_EVENT, runtime.refreshHandler);
      window.addEventListener('taif:chart-of-accounts-updated', runtime.refreshHandler);
    }
    window.addEventListener('storage', runtime.storageHandler);
  }

  function unbindListeners(){
    if(!runtime.listenersBound) return;
    if(typeof runtime.domainEventsCleanup === 'function'){
      runtime.domainEventsCleanup();
      runtime.domainEventsCleanup = null;
    }else if(typeof runtime.refreshHandler === 'function'){
      window.removeEventListener('taif:currency-domain-updated', runtime.refreshHandler);
      window.removeEventListener('taif:cash-boxes-updated', runtime.refreshHandler);
      window.removeEventListener('taif:entries-vouchers-updated', runtime.refreshHandler);
      window.removeEventListener(SALES_PURCHASE_UPDATED_EVENT, runtime.refreshHandler);
      window.removeEventListener('taif:chart-of-accounts-updated', runtime.refreshHandler);
    }
    if(typeof runtime.storageHandler === 'function'){
      window.removeEventListener('storage', runtime.storageHandler);
    }
    runtime.refreshHandler = null;
    runtime.storageHandler = null;
    runtime.listenersBound = false;
  }

  TAIF.cashBoxes = TAIF.cashBoxes || {};
  TAIF.cashBoxes.readState = readState;
  TAIF.cashBoxes.writeState = writeState;
  TAIF.cashBoxes.refresh = refresh;
  TAIF.cashBoxes.buildLegacyAccountCurrencyTotals = buildLegacyAccountCurrencyTotals;
  TAIF.cashBoxes.buildServiceLedgerAccountCurrencyTotals = buildServiceLedgerAccountCurrencyTotals;
  TAIF.cashBoxes.open = openWindow;
  TAIF.cashBoxes.close = closeWindow;
  TAIF.cashBoxes.isOpen = () => !!(runtime.modalBody instanceof HTMLElement && runtime.modalBody.isConnected && runtime.modalBody.dataset.cashBoxesMounted === 'true');

  function cleanupView(){
    runtime.refreshScheduler?.cancel?.();
    runtime.refreshScheduler = null;
    closeWindow();
    unbindListeners();
  }

  TAIF.registerViewCleanup('cash-boxes', cleanupView);
  TAIF.registerViewRenderer('cash-boxes', ({ panel }) => {
    openWindow(panel);
  });
})();
