(()=>{
  /*
   * TAIF Cash Boxes domain public API.
   * Exposes storage/state access without loading the Cash Boxes view renderer.
   */
  const TAIF = window.TAIF || (window.TAIF = {});
  const utils = TAIF.core && TAIF.core.utils ? TAIF.core.utils : {};
  const readJsonStorage = typeof utils.readJsonStorage === 'function' ? utils.readJsonStorage : null;
  const persistJsonState = typeof utils.persistJsonState === 'function' ? utils.persistJsonState : null;
  const parseNumericInput = typeof utils.parseNumericInput === 'function'
    ? utils.parseNumericInput
    : ((value, fallback = 0) => {
        const numeric = Number(String(value ?? '').replace(/,/g, '').trim());
        return Number.isFinite(numeric) ? numeric : Number(fallback) || 0;
      });

  const storageKeys = TAIF?.core?.storageKeys || {};
  const STORAGE_KEY = storageKeys.cashBoxes || 'taif-cash-boxes-module-v1';
  const DEFAULT_ACCOUNT = Object.freeze({
    accountNo: '001',
    name: 'صندوق محلي اساسي'
  });
  const DEFAULT_STATE = Object.freeze({
    version: 1,
    updatedAt: 1,
    selectedCenterId: '',
    boxes: [
      Object.freeze({
        id: 'cash-box-main-local',
        linkedAccountNo: DEFAULT_ACCOUNT.accountNo,
        linkedAccountName: DEFAULT_ACCOUNT.name,
        balances: Object.freeze({ USD: 0 })
      })
    ]
  });

  const domain = TAIF.cashBoxesDomain || (TAIF.cashBoxesDomain = {});

  function toNumber(value, fallback = 0){
    return parseNumericInput(value, fallback);
  }

  function normalizeBalances(input){
    const source = input && typeof input === 'object' ? input : {};
    const balances = {};
    Object.keys(source).forEach((code) => {
      const safeCode = String(code || '').trim().toUpperCase();
      if(!safeCode) return;
      balances[safeCode] = toNumber(source[code], 0);
    });
    if(!Object.prototype.hasOwnProperty.call(balances, 'USD')) balances.USD = 0;
    return balances;
  }

  function normalizeBox(input){
    const raw = input && typeof input === 'object' ? input : {};
    return {
      id: String(raw.id || 'cash-box-main-local').trim() || 'cash-box-main-local',
      linkedAccountNo: String(raw.linkedAccountNo || DEFAULT_ACCOUNT.accountNo).trim() || DEFAULT_ACCOUNT.accountNo,
      linkedAccountName: String(raw.linkedAccountName || DEFAULT_ACCOUNT.name).trim() || DEFAULT_ACCOUNT.name,
      balances: normalizeBalances(raw.balances)
    };
  }

  function createDefaultState(){
    return {
      version: 1,
      updatedAt: Date.now(),
      selectedCenterId: '',
      boxes: DEFAULT_STATE.boxes.map((box) => normalizeBox(box))
    };
  }

  function normalizeState(input){
    const raw = input && typeof input === 'object' ? input : {};
    const boxes = Array.isArray(raw.boxes) && raw.boxes.length
      ? raw.boxes.map(normalizeBox)
      : createDefaultState().boxes;
    return {
      version: 1,
      updatedAt: Number(raw.updatedAt) > 0 ? Number(raw.updatedAt) : Date.now(),
      selectedCenterId: String(raw.selectedCenterId || '').trim(),
      boxes
    };
  }

  function fallbackReadState(){
    const stored = readJsonStorage ? readJsonStorage(STORAGE_KEY, null) : null;
    if(!stored) return createDefaultState();
    return normalizeState(stored);
  }

  function fallbackWriteState(nextState, { notify = true } = {}){
    const normalized = normalizeState(nextState);
    const persisted = persistJsonState
      ? persistJsonState(STORAGE_KEY, normalized, normalizeState)
      : normalized;
    const safeState = normalizeState(persisted);
    if(notify){
      const events = TAIF.core && TAIF.core.events;
      if(events && typeof events.emitDomainUpdate === 'function'){
        events.emitDomainUpdate('cash-boxes', { state: safeState }, { source:'cash-boxes-domain-public-api' });
      }else if(typeof window !== 'undefined' && typeof window.dispatchEvent === 'function'){
        try{
          window.dispatchEvent(new CustomEvent('taif:cash-boxes-updated', { detail: { state: safeState } }));
        }catch{}
      }
    }
    return safeState;
  }

  function isDomainBridge(fn){
    return typeof fn === 'function' && fn.__taifCashBoxesDomainBridge === true;
  }

  domain.createDefaultState = createDefaultState;
  domain.normalizeState = normalizeState;

  const readStateBridge = function(){
    const publicApi = TAIF.cashBoxes || {};
    const publicReadState = publicApi.readState;
    if(typeof publicReadState === 'function' && publicReadState !== readStateBridge && !isDomainBridge(publicReadState)){
      return publicReadState();
    }
    return fallbackReadState();
  };
  readStateBridge.__taifCashBoxesDomainBridge = true;

  const writeStateBridge = function(nextState, options = {}){
    const publicApi = TAIF.cashBoxes || {};
    const publicWriteState = publicApi.writeState;
    if(typeof publicWriteState === 'function' && publicWriteState !== writeStateBridge && !isDomainBridge(publicWriteState)){
      return publicWriteState(nextState, options);
    }
    return fallbackWriteState(nextState, options);
  };
  writeStateBridge.__taifCashBoxesDomainBridge = true;

  domain.readState = readStateBridge;
  domain.writeState = writeStateBridge;

  TAIF.cashBoxes = TAIF.cashBoxes || {};
  TAIF.cashBoxes.readState = domain.readState;
  TAIF.cashBoxes.writeState = domain.writeState;
})();
