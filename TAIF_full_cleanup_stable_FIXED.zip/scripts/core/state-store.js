(()=>{
  const TAIF = window.TAIF;
  TAIF.core.createStateStore = function({ root, config }){
    const views = Array.isArray(config?.views) ? config.views : [];
    const validIds = new Set(views.map((view) => view && view.id).filter(Boolean));
    const floatingViewIds = new Set();
    const fallbackViewId = (() => {
      const configuredDefault = typeof config?.defaultView === 'string' ? config.defaultView : '';
      if(configuredDefault && validIds.has(configuredDefault) && !floatingViewIds.has(configuredDefault)) return configuredDefault;
      const firstStandardView = views.find((view) => view && view.id && !floatingViewIds.has(view.id));
      return firstStandardView?.id || views[0]?.id || 'cash-boxes';
    })();

    function resolveActiveView(candidate){
      const nextViewId = typeof candidate === 'string' ? candidate.trim() : '';
      if(nextViewId && validIds.has(nextViewId) && !floatingViewIds.has(nextViewId)) return nextViewId;
      return fallbackViewId;
    }

    function validate(next){
      return {
        activeView: resolveActiveView(next?.activeView),
        sidebarCollapsed: !!next?.sidebarCollapsed
      };
    }

    const rawSavedState = TAIF.core.storage.getItem(config.key, '');
    let savedState = {};
    if(rawSavedState){
      try{
        const parsed = JSON.parse(rawSavedState);
        if(parsed && typeof parsed === 'object') savedState = parsed;
      }catch{}
    }

    const rootSidebarState = root.dataset.sidebar;
    let state = validate({
      activeView: validIds.has(root.dataset.view) ? root.dataset.view : savedState.activeView,
      sidebarCollapsed: rootSidebarState === 'collapsed' ? true : (rootSidebarState === 'open' ? false : savedState.sidebarCollapsed)
    });

    let lastSaved = rawSavedState;
    const listeners = new Set();

    function save(){
      try{
        const serialized = JSON.stringify(state);
        if(serialized === lastSaved) return;
        lastSaved = serialized;
        TAIF.core.storage.setItem(config.key, serialized);
      }catch{}
    }

    function emit(){
      listeners.forEach((listener) => listener(state));
    }

    return {
      getState(){
        return state;
      },
      setState(patch){
        const next = { ...state, ...patch };
        state = validate(next);
        save();
        emit();
      },
      subscribe(listener){
        if(typeof listener !== 'function') return () => {};
        listeners.add(listener);
        return () => listeners.delete(listener);
      },
      save
    };
  };
})();
