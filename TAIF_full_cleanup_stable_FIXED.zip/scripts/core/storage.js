(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.core = TAIF.core || {};

  const memoryStore = TAIF.__memoryStorage || (TAIF.__memoryStorage = new Map());
  let resolvedBackend = null;

  function resolveBackend(){
    if(resolvedBackend) return resolvedBackend;
    try{
      if(window?.localStorage){
        const probeKey = '__taif-storage-probe__';
        window.localStorage.setItem(probeKey, '1');
        window.localStorage.removeItem(probeKey);
        resolvedBackend = window.localStorage;
        return resolvedBackend;
      }
    }catch{}

    resolvedBackend = {
      getItem(key){
        const safeKey = String(key ?? '');
        return memoryStore.has(safeKey) ? memoryStore.get(safeKey) : null;
      },
      setItem(key, value){
        memoryStore.set(String(key ?? ''), String(value ?? ''));
      },
      removeItem(key){
        memoryStore.delete(String(key ?? ''));
      },
      clear(){
        memoryStore.clear();
      },
      key(index){
        return Array.from(memoryStore.keys())[Number(index)] ?? null;
      },
      get length(){
        return memoryStore.size;
      }
    };
    return resolvedBackend;
  }

  function resolveScopedKey(key){
    const safeKey = String(key ?? '').trim();
    if(!safeKey) return '';
    const resolver = TAIF?.core?.utils?.resolveStorageKey;
    if(typeof resolver === 'function') return resolver(safeKey);
    return safeKey;
  }

  function hasExplicitStorageScope(){
    return !!String(document.documentElement?.dataset?.storageScope || '').trim();
  }

  function scoreStoredValue(rawValue){
    if(rawValue == null) return 0;
    try{
      const parsed = JSON.parse(rawValue);
      if(Array.isArray(parsed)){
        return parsed.reduce((maxScore, item) => {
          const updatedAt = Number(item?.updatedAt) || Number(item?.createdAt) || 0;
          return updatedAt > maxScore ? updatedAt : maxScore;
        }, 0);
      }
      if(parsed && typeof parsed === 'object'){
        return Number(parsed.updatedAt) || Number(parsed.createdAt) || 0;
      }
    }catch{}
    return 0;
  }

  function findMigratedScopedValue(backend, safeKey, scopedKey){
    if(!hasExplicitStorageScope()) return null;
    if(!backend || typeof backend.getItem !== 'function' || typeof backend.length !== 'number' || typeof backend.key !== 'function') return null;

    const suffix = `::${safeKey}`;
    let bestValue = null;
    let bestScore = -1;

    for(let index = 0; index < backend.length; index += 1){
      const candidateKey = backend.key(index);
      if(typeof candidateKey !== 'string' || !candidateKey || candidateKey === scopedKey) continue;
      if(!candidateKey.endsWith(suffix)) continue;
      let candidateValue = null;
      try{
        candidateValue = backend.getItem(candidateKey);
      }catch{}
      if(candidateValue == null) continue;
      const candidateScore = scoreStoredValue(candidateValue);
      if(candidateScore >= bestScore){
        bestScore = candidateScore;
        bestValue = candidateValue;
      }
    }

    if(bestValue != null && scopedKey && typeof backend.setItem === 'function'){
      try{ backend.setItem(scopedKey, bestValue); }catch{}
    }
    return bestValue;
  }

  TAIF.core.storage = {
    getItem(key, fallback=''){
      const safeKey = String(key ?? '').trim();
      if(!safeKey) return fallback;
      try{
        const backend = resolveBackend();
        const scopedKey = resolveScopedKey(safeKey);
        const scopedValue = backend.getItem(scopedKey);
        if(scopedValue != null) return scopedValue;

        if(scopedKey !== safeKey){
          const legacyValue = backend.getItem(safeKey);
          if(legacyValue != null){
            try{ backend.setItem(scopedKey, legacyValue); }catch{}
            return legacyValue;
          }

          const migratedValue = findMigratedScopedValue(backend, safeKey, scopedKey);
          if(migratedValue != null) return migratedValue;
        }

        return fallback;
      }catch{
        return fallback;
      }
    },
    setItem(key, value){
      const scopedKey = resolveScopedKey(key);
      if(!scopedKey) return;
      try{
        resolveBackend().setItem(scopedKey, value);
      }catch{}
    },
    removeItem(key){
      const scopedKey = resolveScopedKey(key);
      if(!scopedKey) return;
      try{
        resolveBackend().removeItem(scopedKey);
      }catch{}
    },
    clear(){
      try{
        resolveBackend().clear();
      }catch{}
    }
  };
})();
