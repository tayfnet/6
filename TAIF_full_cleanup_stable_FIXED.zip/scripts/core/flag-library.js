(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.assets = TAIF.assets || {};
  const { normalizeLookupText } = TAIF.core?.utils || {};
  const AVAILABLE_FLAG_CODES = new Set([
  "ae",
  "af",
  "am",
  "ar",
  "at",
  "au",
  "az",
  "bd",
  "be",
  "bh",
  "br",
  "by",
  "ca",
  "ch",
  "ci",
  "cl",
  "cm",
  "cn",
  "co",
  "cr",
  "cy",
  "cz",
  "de",
  "dj",
  "dk",
  "do",
  "dz",
  "ec",
  "eg",
  "er",
  "es",
  "et",
  "eu",
  "fr",
  "gb",
  "ge",
  "gh",
  "gr",
  "gt",
  "hk",
  "hn",
  "hu",
  "id",
  "ie",
  "in",
  "iq",
  "ir",
  "it",
  "jo",
  "jp",
  "ke",
  "kg",
  "kh",
  "km",
  "kr",
  "kw",
  "kz",
  "la",
  "lb",
  "lk",
  "ly",
  "ma",
  "md",
  "mm",
  "mr",
  "mx",
  "my",
  "mz",
  "ng",
  "ni",
  "nl",
  "no",
  "np",
  "nz",
  "om",
  "pa",
  "pe",
  "ph",
  "pk",
  "pl",
  "ps",
  "pt",
  "qa",
  "ro",
  "ru",
  "rw",
  "sa",
  "sd",
  "se",
  "sg",
  "sn",
  "so",
  "sv",
  "sy",
  "th",
  "tj",
  "tn",
  "tr",
  "tz",
  "ua",
  "ug",
  "us",
  "uz",
  "vn",
  "xx",
  "ye",
  "za",
  "zm",
  "zw"
]);
  const PRIORITY_FLAG_CODES = [
  "us",
  "eu",
  "tr",
  "sa",
  "ae",
  "jo",
  "kw",
  "qa",
  "eg",
  "gb",
  "ch",
  "iq",
  "sy",
  "lb",
  "ye",
  "om",
  "bh",
  "tn",
  "dz",
  "ma",
  "ly",
  "sd",
  "ps",
  "fr",
  "de",
  "it",
  "es"
];
  const CURRENCY_TO_FLAG_CODE = {
  "USD": "us",
  "EUR": "eu",
  "TRY": "tr",
  "SAR": "sa",
  "AED": "ae",
  "JOD": "jo",
  "GBP": "gb",
  "CHF": "ch",
  "SEK": "se",
  "NOK": "no",
  "DKK": "dk",
  "KWD": "kw",
  "QAR": "qa",
  "IQD": "iq",
  "EGP": "eg",
  "RUB": "ru",
  "CNY": "cn",
  "JPY": "jp",
  "CAD": "ca",
  "AUD": "au",
  "NZD": "nz",
  "HKD": "hk",
  "SGD": "sg",
  "BHD": "bh",
  "OMR": "om",
  "MAD": "ma",
  "TND": "tn",
  "DZD": "dz",
  "SYP": "sy",
  "LBP": "lb",
  "YER": "ye",
  "SDG": "sd",
  "LYD": "ly",
  "KHR": "kh",
  "PKR": "pk",
  "INR": "in",
  "AFN": "af",
  "AMD": "am",
  "ARS": "ar",
  "AZN": "az",
  "BDT": "bd",
  "BRL": "br",
  "BYN": "by",
  "CLP": "cl",
  "COP": "co",
  "CRC": "cr",
  "CZK": "cz",
  "ETB": "et",
  "GEL": "ge",
  "GHS": "gh",
  "HUF": "hu",
  "IDR": "id",
  "IRR": "ir",
  "KES": "ke",
  "KGS": "kg",
  "KRW": "kr",
  "KZT": "kz",
  "LAK": "la",
  "LKR": "lk",
  "MDL": "md",
  "MMK": "mm",
  "MRO": "mr",
  "MRU": "mr",
  "MXN": "mx",
  "MYR": "my",
  "MZN": "mz",
  "NGN": "ng",
  "NIO": "ni",
  "NPR": "np",
  "PAB": "pa",
  "PEN": "pe",
  "PHP": "ph",
  "PLN": "pl",
  "RON": "ro",
  "RWF": "rw",
  "THB": "th",
  "TJS": "tj",
  "TZS": "tz",
  "UAH": "ua",
  "UGX": "ug",
  "UZS": "uz",
  "VND": "vn",
  "ZAR": "za",
  "ZMW": "zm",
  "ZWL": "zw",
  "SVC": "sv",
  "DJF": "dj",
  "XOF": "ci",
  "XAF": "cm"
};
  const FLAG_CATALOG = {
  "ae": "الدرهم الإماراتي",
  "af": "الأفغاني",
  "am": "الدرام الأرميني",
  "ar": "البيزو الأرجنتيني",
  "at": "اليورو الأوروبي",
  "au": "الدولار الأسترالي",
  "az": "المانات الأذربيجاني",
  "bd": "التاكا البنغلاديشية",
  "be": "اليورو الأوروبي",
  "bh": "الدينار البحريني",
  "br": "الريال البرازيلي",
  "by": "الروبل البيلاروسي",
  "ca": "الدولار الكندي",
  "ch": "الفرنك السويسري",
  "ci": "فرنك غرب أفريقيا CFA",
  "cl": "البيزو التشيلي",
  "cm": "فرنك وسط أفريقيا CFA",
  "cn": "اليوان الصيني",
  "co": "البيزو الكولومبي",
  "cr": "الكولون الكوستاريكي",
  "cy": "اليورو الأوروبي",
  "cz": "الكرونة التشيكية",
  "de": "اليورو الأوروبي",
  "dj": "الفرنك الجيبوتي",
  "dk": "الكرونة الدنماركية",
  "do": "البيزو الدومينيكاني",
  "dz": "الدينار الجزائري",
  "ec": "الدولار الأمريكي",
  "eg": "الجنيه المصري",
  "er": "الناكفا الإريترية",
  "es": "اليورو الأوروبي",
  "et": "البر الإثيوبي",
  "eu": "اليورو الأوروبي",
  "fr": "اليورو الأوروبي",
  "gb": "الجنيه الإسترليني البريطاني",
  "ge": "اللاري الجورجي",
  "gh": "السيدي الغاني",
  "gr": "اليورو الأوروبي",
  "gt": "الكيتزال الغواتيمالي",
  "hk": "دولار هونغ كونغ",
  "hn": "اللمبيرا الهندوراسية",
  "hu": "الفورنت المجري",
  "id": "الروبية الإندونيسية",
  "ie": "اليورو الأوروبي",
  "in": "الروبية الهندية",
  "iq": "الدينار العراقي",
  "ir": "الريال الإيراني",
  "it": "اليورو الأوروبي",
  "jo": "الدينار الأردني",
  "jp": "الين الياباني",
  "ke": "الشلن الكيني",
  "kg": "السوم القرغيزي",
  "kh": "الريال الكمبودي",
  "km": "الفرنك القمري",
  "kr": "الوون الكوري الجنوبي",
  "kw": "الدينار الكويتي",
  "kz": "التنغ الكازاخستاني",
  "la": "الكيب اللاوسي",
  "lb": "الليرة اللبنانية",
  "lk": "الروبية السريلانكية",
  "ly": "الدينار الليبي",
  "ma": "الدرهم المغربي",
  "md": "الليو المولدوفي",
  "mm": "الكيات الميانماري",
  "mr": "الأوقية الموريتانية",
  "mx": "البيزو المكسيكي",
  "my": "الرينغيت الماليزي",
  "mz": "الميتيكال الموزمبيقي",
  "ng": "النايرا النيجيرية",
  "ni": "الكوردوبا النيكاراغوية",
  "nl": "اليورو الأوروبي",
  "no": "الكرونة النرويجية",
  "np": "الروبية النيبالية",
  "nz": "الدولار النيوزيلندي",
  "om": "الريال العماني",
  "pa": "البالبوا البنمية",
  "pe": "السول البيروفي",
  "ph": "البيزو الفلبيني",
  "pk": "الروبية الباكستانية",
  "pl": "الزلوتي البولندي",
  "ps": "الشيكل الإسرائيلي الجديد",
  "pt": "اليورو الأوروبي",
  "qa": "الريال القطري",
  "ro": "الليو الروماني",
  "ru": "الروبل الروسي",
  "rw": "الفرنك الرواندي",
  "sa": "الريال السعودي",
  "sd": "الجنيه السوداني",
  "se": "الكرونة السويدية",
  "sg": "الدولار السنغافوري",
  "sn": "فرنك غرب أفريقيا CFA",
  "so": "الشلن الصومالي",
  "sv": "الدولار الأمريكي",
  "sy": "الليرة السورية",
  "th": "البات التايلندي",
  "tj": "السوموني الطاجيكي",
  "tn": "الدينار التونسي",
  "tr": "الليرة التركية",
  "tz": "الشلن التنزاني",
  "ua": "الهريفنيا الأوكرانية",
  "ug": "الشلن الأوغندي",
  "us": "الدولار الأمريكي",
  "uz": "السوم الأوزبكي",
  "vn": "الدونغ الفيتنامي",
  "xx": "بدون علم",
  "ye": "الريال اليمني",
  "za": "الراند الجنوب أفريقي",
  "zm": "الكواشا الزامبية",
  "zw": "الدولار الزيمبابوي"
};

  const FLAG_SEARCH_ALIASES = {
    "at": "النمسا يورو أوروبا",
    "be": "بلجيكا يورو أوروبا",
    "ci": "ساحل العاج غرب أفريقيا غرب افريقيا فرنك cfa",
    "cm": "الكاميرون وسط أفريقيا وسط افريقيا فرنك cfa",
    "cy": "قبرص يورو أوروبا",
    "de": "ألمانيا المانيا يورو أوروبا",
    "ec": "الإكوادور اكوادور امريكا دولار",
    "es": "إسبانيا اسبانيا يورو أوروبا",
    "eu": "الاتحاد الأوروبي الاتحاد الاوروبي أوروبا اوروبا يورو",
    "fr": "فرنسا يورو أوروبا",
    "gb": "بريطانيا المملكة المتحدة الجنيه البريطاني",
    "gr": "اليونان يورو أوروبا",
    "hk": "هونغ كونغ هونج كونج",
    "ie": "أيرلندا ايرلندا يورو أوروبا",
    "it": "إيطاليا ايطاليا يورو أوروبا",
    "kr": "كوريا الجنوبية وون كوريا",
    "nl": "هولندا يورو أوروبا",
    "ps": "فلسطين شيكل",
    "pt": "البرتغال يورو أوروبا",
    "sn": "السنغال غرب أفريقيا غرب افريقيا فرنك cfa",
    "sv": "السلفادور امريكا دولار",
    "us": "الولايات المتحدة أمريكا امريكا دولار"
  };

  const AVAILABLE_FLAG_VARIANTS = new Set(["circle"]);

  function normalizeToken(value){
    return String(value ?? '').trim().toLowerCase().replace(/[^a-z]/g, '');
  }

  function normalizeCurrencyCode(value){
    return String(value ?? '').trim().toUpperCase().replace(/[^A-Z]/g, '');
  }

  function normalizeCurrencyName(value){
    return typeof normalizeLookupText === 'function'
      ? normalizeLookupText(value)
      : String(value ?? '').trim().toLowerCase();
  }

  function normalizeVariant(value){
    const normalized = String(value || '').trim().toLowerCase();
    return AVAILABLE_FLAG_VARIANTS.has(normalized) ? normalized : 'circle';
  }

  function buildFlagAssetPath(countryCode, variant = 'circle'){
    const safeCountryCode = resolveCountryCode(countryCode) || 'xx';
    const safeVariant = normalizeVariant(variant);
    return `assets/flags/${safeVariant}/${safeCountryCode}.png`;
  }

  function resolveCountryCode(value){
    const direct = normalizeToken(value);
    if(direct && AVAILABLE_FLAG_CODES.has(direct)) return direct;
    return '';
  }

  function resolveCountryCodeForCurrency(currencyCode){
    const normalizedCurrency = normalizeCurrencyCode(currencyCode);
    if(!normalizedCurrency) return 'xx';
    const mapped = resolveCountryCode(CURRENCY_TO_FLAG_CODE[normalizedCurrency]);
    if(mapped) return mapped;
    const firstTwo = resolveCountryCode(normalizedCurrency.slice(0, 2));
    if(firstTwo) return firstTwo;
    return 'xx';
  }

  function getPrioritizedFlagCodes(includePlaceholder = false){
    const prioritySet = new Set(PRIORITY_FLAG_CODES);
    return Array.from(AVAILABLE_FLAG_CODES)
      .filter((code) => includePlaceholder || code !== 'xx')
      .sort((a, b) => {
        const aPriority = prioritySet.has(a) ? PRIORITY_FLAG_CODES.indexOf(a) : 9999;
        const bPriority = prioritySet.has(b) ? PRIORITY_FLAG_CODES.indexOf(b) : 9999;
        if(aPriority !== bPriority) return aPriority - bPriority;
        return a.localeCompare(b);
      });
  }

  function resolveCountryCodeForCurrencyName(currencyName){
    const normalizedName = normalizeCurrencyName(currencyName);
    if(!normalizedName) return 'xx';

    const queryTokens = normalizedName.split(' ').filter(Boolean);
    let bestCode = '';
    let bestScore = 0;

    getPrioritizedFlagCodes(false).forEach((code) => {
      const normalizedCatalogName = normalizeCurrencyName(FLAG_CATALOG[code] || '');
      if(!normalizedCatalogName) return;

      let score = 0;
      if(normalizedCatalogName === normalizedName) score = 1000;
      else if(normalizedName.startsWith(normalizedCatalogName) || normalizedCatalogName.startsWith(normalizedName)) score = 700;
      else if(normalizedName.includes(normalizedCatalogName) || normalizedCatalogName.includes(normalizedName)) score = 500;
      else {
        const catalogTokens = normalizedCatalogName.split(' ').filter(Boolean);
        const directMatches = queryTokens.filter((token) => token.length > 1 && catalogTokens.includes(token)).length;
        const softMatches = queryTokens.filter((token) => token.length >= 3 && catalogTokens.some((catalogToken) => catalogToken.includes(token) || token.includes(catalogToken))).length;
        score = Math.max(directMatches * 120, softMatches * 90);
        if(directMatches >= Math.min(2, catalogTokens.length) && directMatches > 0) score += 150;
      }

      if(score > bestScore){
        bestScore = score;
        bestCode = code;
      }
    });

    return bestScore >= 180 ? (resolveCountryCode(bestCode) || 'xx') : 'xx';
  }

  function resolveFlagAsset(value, variant = 'circle'){
    const safeVariant = normalizeVariant(variant);
    const directCountryCode = resolveCountryCode(value);
    const countryCode = directCountryCode || resolveCountryCodeForCurrency(value);
    return {
      currencyCode: normalizeCurrencyCode(value),
      countryCode,
      variant: safeVariant,
      src: buildFlagAssetPath(countryCode, safeVariant)
    };
  }

  function resolveFlagAssetByCurrency(currencyCode, variant = 'circle'){
    return resolveFlagAsset(currencyCode, variant);
  }

  function getFlagMeta(value){
    const countryCode = resolveCountryCode(value) || 'xx';
    const srcCircle = buildFlagAssetPath(countryCode, 'circle');
    return {
      code: countryCode,
      countryCode: countryCode.toUpperCase(),
      currencyName: FLAG_CATALOG[countryCode] || FLAG_CATALOG.xx,
      srcCircle,
      srcRect: srcCircle
    };
  }

  function getFlagCatalog(variant = 'circle', options = {}){
    const safeVariant = normalizeVariant(variant);
    const includePlaceholder = Boolean(options && options.includePlaceholder);
    const sortedCodes = getPrioritizedFlagCodes(includePlaceholder);

    return sortedCodes.map((code) => {
      const meta = getFlagMeta(code);
      const searchAlias = FLAG_SEARCH_ALIASES[code] || '';
      return {
        ...meta,
        variant: safeVariant,
        src: safeVariant === 'rect' ? meta.srcRect : meta.srcCircle,
        searchText: `${meta.countryCode} ${meta.currencyName} ${searchAlias}`.toLowerCase()
      };
    });
  }

  TAIF.assets.flags = {
    availableCodes: Array.from(AVAILABLE_FLAG_CODES),
    availableVariants: Array.from(AVAILABLE_FLAG_VARIANTS),
    currencyToFlagCode: Object.freeze({ ...CURRENCY_TO_FLAG_CODE }),
    resolveCountryCode,
    resolveCountryCodeForCurrency,
    resolveCountryCodeForCurrencyName,
    normalizeVariant,
    resolveFlagAsset,
    resolveFlagAssetByCurrency,
    getFlagMeta,
    getFlagCatalog
  };
})();
