(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.core = TAIF.core || {};
  TAIF.core.utils = TAIF.core.utils || {};
  const utils = TAIF.core.utils;

  const DEFAULT_POPOVER_SELECTOR = '[data-taif-dropdown-popup="true"]';

  const DEFAULT_INTERACTIVE_SELECTOR = '[data-taif-dropdown-item="true"]';

  const DEFAULT_INTENT_ATTRIBUTE = 'data-taif-nav-intent';
  const KEYBOARD_INTENT_KEYS = new Set([
    'ArrowDown',
    'ArrowUp',
    'ArrowLeft',
    'ArrowRight',
    'Home',
    'End',
    'PageUp',
    'PageDown',
    'Enter',
    'NumpadEnter',
    ' ',
    'Spacebar',
    'Tab'
  ]);

  function toElement(target){
    return target instanceof Element ? target : null;
  }

  function isKeyboardIntentKey(key){
    if(KEYBOARD_INTENT_KEYS.has(String(key || ''))) return true;
    return typeof key === 'string' && key.length === 1;
  }

  function resolveDropdownPopover(target, { popoverSelector = DEFAULT_POPOVER_SELECTOR } = {}){
    const element = toElement(target);
    if(!element || !popoverSelector) return null;

    const directPopover = element.closest(popoverSelector);
    if(directPopover instanceof HTMLElement) return directPopover;

    return null;
  }

  function setDropdownNavIntent(target, intent = '', {
    popoverSelector = DEFAULT_POPOVER_SELECTOR,
    intentAttribute = DEFAULT_INTENT_ATTRIBUTE
  } = {}){
    const popover = resolveDropdownPopover(target, { popoverSelector });
    if(!(popover instanceof HTMLElement)) return false;

    const safeIntent = String(intent || '').trim();
    if(safeIntent === 'keyboard' || safeIntent === 'pointer'){
      popover.setAttribute(intentAttribute, safeIntent);
      return true;
    }

    popover.removeAttribute(intentAttribute);
    return true;
  }

  function clearDropdownNavIntent(target, options = {}){
    return setDropdownNavIntent(target, '', options);
  }

  function mountDropdownNavIntentDelegation({
    root = document,
    popoverSelector = DEFAULT_POPOVER_SELECTOR,
    interactiveSelector = DEFAULT_INTERACTIVE_SELECTOR,
    intentAttribute = DEFAULT_INTENT_ATTRIBUTE
  } = {}){
    const targetRoot = root && typeof root.addEventListener === 'function' ? root : document;
    let lastIntent = '';

    function resolveInteractiveTarget(rawTarget){
      const element = toElement(rawTarget);
      if(!element || !interactiveSelector) return null;
      return element.closest(interactiveSelector);
    }

    function markIntentForTarget(rawTarget, intent){
      const interactiveTarget = resolveInteractiveTarget(rawTarget) || toElement(rawTarget);
      if(!(interactiveTarget instanceof Element)) return false;
      const popover = resolveDropdownPopover(interactiveTarget, { popoverSelector });
      if(!(popover instanceof HTMLElement) || popover.hidden) return false;
      return setDropdownNavIntent(popover, intent, { popoverSelector, intentAttribute });
    }

    function onKeyDown(event){
      if(event.defaultPrevented || event.isComposing || event.altKey || event.ctrlKey || event.metaKey) return;
      if(!isKeyboardIntentKey(event.key)) return;
      const popover = resolveDropdownPopover(event.target, { popoverSelector });
      if(!(popover instanceof HTMLElement) || popover.hidden) return;
      lastIntent = 'keyboard';
      setDropdownNavIntent(popover, 'keyboard', { popoverSelector, intentAttribute });
    }

    function onFocusIn(event){
      const interactiveTarget = resolveInteractiveTarget(event.target);
      if(!(interactiveTarget instanceof HTMLElement)) return;
      const popover = resolveDropdownPopover(interactiveTarget, { popoverSelector });
      if(!(popover instanceof HTMLElement) || popover.hidden) return;
      const resolvedIntent = lastIntent === 'pointer' ? 'pointer' : 'keyboard';
      setDropdownNavIntent(popover, resolvedIntent, { popoverSelector, intentAttribute });
    }

    function onPointerIntent(event){
      const pointerType = String(event?.pointerType || '').trim().toLowerCase();
      if(pointerType === 'touch') return;
      if(!markIntentForTarget(event.target, 'pointer')) return;
      lastIntent = 'pointer';
    }

    targetRoot.addEventListener('keydown', onKeyDown, true);
    targetRoot.addEventListener('focusin', onFocusIn, true);
    targetRoot.addEventListener('pointerdown', onPointerIntent, true);
    targetRoot.addEventListener('pointermove', onPointerIntent, { capture:true, passive:true });
    targetRoot.addEventListener('pointerover', onPointerIntent, true);

    return {
      setIntent(target, intent){
        if(intent === 'keyboard' || intent === 'pointer') lastIntent = intent;
        return setDropdownNavIntent(target, intent, { popoverSelector, intentAttribute });
      },
      clearIntent(target){
        return clearDropdownNavIntent(target, { popoverSelector, intentAttribute });
      },
      destroy(){
        targetRoot.removeEventListener('keydown', onKeyDown, true);
        targetRoot.removeEventListener('focusin', onFocusIn, true);
        targetRoot.removeEventListener('pointerdown', onPointerIntent, true);
        targetRoot.removeEventListener('pointermove', onPointerIntent, true);
        targetRoot.removeEventListener('pointerover', onPointerIntent, true);
      }
    };
  }

  utils.resolveDropdownPopover = utils.resolveDropdownPopover || resolveDropdownPopover;
  utils.setDropdownNavIntent = utils.setDropdownNavIntent || setDropdownNavIntent;
  utils.clearDropdownNavIntent = utils.clearDropdownNavIntent || clearDropdownNavIntent;
  utils.mountDropdownNavIntentDelegation = utils.mountDropdownNavIntentDelegation || mountDropdownNavIntentDelegation;
  utils.dropdownNavIntentDefaults = utils.dropdownNavIntentDefaults || Object.freeze({
    popoverSelector: DEFAULT_POPOVER_SELECTOR,
    interactiveSelector: DEFAULT_INTERACTIVE_SELECTOR,
    intentAttribute: DEFAULT_INTENT_ATTRIBUTE
  });

  if(!TAIF.core.__taifGlobalDropdownNavIntentMounted){
    const mount = () => {
      if(TAIF.core.__taifGlobalDropdownNavIntentMounted) return;
      TAIF.core.__taifGlobalDropdownNavIntentMounted = mountDropdownNavIntentDelegation();
    };

    if(document.readyState === 'loading'){
      document.addEventListener('DOMContentLoaded', mount, { once:true });
    }else{
      mount();
    }
  }
})();
