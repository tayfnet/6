(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.registry = TAIF.registry || { viewMeta: [], viewRenderers: {}, viewCleanup: {} };
  TAIF.core = TAIF.core || {};
  TAIF.core.constants = TAIF.core.constants || {};
  TAIF.core.utils = TAIF.core.utils || {};
  TAIF.config = TAIF.config || {};
  TAIF.domain = TAIF.domain || {};
  TAIF.platform = TAIF.platform || {};
  TAIF.ui = TAIF.ui || {};
  TAIF.ui.nav = TAIF.ui.nav || {};
  TAIF.ui.shell = TAIF.ui.shell || {};
  TAIF.ui.selectionGuard = TAIF.ui.selectionGuard || {};
  TAIF.views = TAIF.views || {};
  TAIF.app = TAIF.app || {};

  TAIF.core.storageKeys = TAIF.core.storageKeys || Object.freeze({
    shell:'taif-shell-state-v3',
    chartOfAccounts:'taif-chart-of-accounts-centers-v3',
    chartOfAccountsAutoSequence:'taif-chart-of-accounts-account-sequence-v1',
    currencyDomain:'taif-currency-management-module-v1',
    currencyManagement:'taif-currency-management-module-v1',
    cashBoxes:'taif-cash-boxes-module-v1',
    customerCard:'taif-customer-card-module-v1',
    entriesVouchers:'taif-entries-vouchers-module-v1',
    salesPurchaseInvoice:'taif-sales-purchase-invoice-records-v1'
  });

  TAIF.core.constants.datePickerMonthNames = TAIF.core.constants.datePickerMonthNames || Object.freeze([
    'يناير',
    'فبراير',
    'مارس',
    'أبريل',
    'مايو',
    'يونيو',
    'يوليو',
    'أغسطس',
    'سبتمبر',
    'أكتوبر',
    'نوفمبر',
    'ديسمبر'
  ]);

  TAIF.core.constants.datePickerWeekdayLabels = TAIF.core.constants.datePickerWeekdayLabels || Object.freeze(['ح', 'ن', 'ث', 'ر', 'خ', 'ج', 'س']);

  TAIF.core.utils.clone = TAIF.core.utils.clone || function(value){
    if(value == null || typeof value !== 'object') return value;
    try{
      return JSON.parse(JSON.stringify(value));
    }catch{
      if(Array.isArray(value)) return value.slice();
      return { ...value };
    }
  };

  TAIF.core.utils.escapeHtml = TAIF.core.utils.escapeHtml || function(value){
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  };

  TAIF.core.utils.escapeSelectorValue = TAIF.core.utils.escapeSelectorValue || function(value){
    return String(value ?? '').replace(/\\/g, '\\\\').replace(/"/g, '\\"');
  };

  TAIF.core.utils.focusElementWithoutScroll = TAIF.core.utils.focusElementWithoutScroll || function(element){
    if(!(element instanceof HTMLElement)) return false;
    try{
      element.focus({ preventScroll: true });
    }catch{
      try{ element.focus(); }catch{}
    }
    return document.activeElement === element;
  };

  TAIF.core.utils.wrapControlTextMarkup = TAIF.core.utils.wrapControlTextMarkup || function(content, extraClass = ''){
    const className = ['taif-control-text', String(extraClass || '').trim()].filter(Boolean).join(' ');
    return `<span class="${className}">${content ?? ''}</span>`;
  };

  TAIF.core.utils.normalizeTypeaheadText = TAIF.core.utils.normalizeTypeaheadText || function(value){
    return String(value ?? '')
      .replace(/[ً-ٰٟۖ-ۭ]/g, '')
      .replace(/[̀-ͯ]/g, '')
      .replace(/[أإآٱ]/g, 'ا')
      .replace(/[ؤ]/g, 'و')
      .replace(/[ئ]/g, 'ي')
      .replace(/[ى]/g, 'ي')
      .replace(/[^0-9A-Za-z؀-ۿ\s]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  };

  TAIF.core.utils.normalizeLookupText = TAIF.core.utils.normalizeLookupText || function(value){
    return String(value ?? '')
      .trim()
      .toLowerCase()
      .replace(/[ً-ٰٟ]/g, '')
      .replace(/[أإآ]/g, 'ا')
      .replace(/ة/g, 'ه')
      .replace(/ى/g, 'ي')
      .replace(/ؤ/g, 'و')
      .replace(/ئ/g, 'ي')
      .replace(/ـ/g, '')
      .replace(/[^a-z0-9؀-ۿ\s]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  };

  TAIF.core.utils.createTypeaheadNavigator = TAIF.core.utils.createTypeaheadNavigator || function({
    getItems = null,
    getCurrentIndex = null,
    resolveLabel = null,
    onMatch = null,
    timeout = 760
  } = {}){
    let buffer = '';
    let lastInputAt = 0;

    function reset(){
      buffer = '';
      lastInputAt = 0;
    }

    function getSearchItems(){
      const items = typeof getItems === 'function' ? getItems() : [];
      return Array.isArray(items) ? items : [];
    }

    function getSearchLabel(item){
      if(typeof resolveLabel === 'function') return TAIF.core.utils.normalizeTypeaheadText(resolveLabel(item));
      if(item && typeof item === 'object'){
        return TAIF.core.utils.normalizeTypeaheadText(item.label ?? item.value ?? '');
      }
      return TAIF.core.utils.normalizeTypeaheadText(item);
    }

    function matchesQuery(label, query){
      if(!label || !query) return false;
      if(label.startsWith(query)) return true;
      return label.split(' ').some((part) => part && part.startsWith(query));
    }

    function findMatch(query, currentIndex, allowCycle = true){
      const items = getSearchItems();
      if(!items.length) return { item:null, index:-1, items };
      const normalizedQuery = TAIF.core.utils.normalizeTypeaheadText(query);
      if(!normalizedQuery) return { item:null, index:-1, items };

      const fallbackIndex = typeof getCurrentIndex === 'function' ? Number(getCurrentIndex()) : -1;
      const baseIndex = Number.isInteger(currentIndex) ? currentIndex : (Number.isInteger(fallbackIndex) ? fallbackIndex : -1);
      const startIndex = allowCycle ? Math.max(-1, baseIndex) + 1 : 0;

      for(let pass = 0; pass < 2; pass += 1){
        const from = pass === 0 ? startIndex : 0;
        const to = pass === 0 ? items.length : Math.min(items.length, Math.max(0, startIndex));
        if(from >= to) continue;
        for(let index = from; index < to; index += 1){
          if(matchesQuery(getSearchLabel(items[index]), normalizedQuery)){
            return { item:items[index], index, items };
          }
        }
      }

      return { item:null, index:-1, items };
    }

    function handleKey(key, { currentIndex = null } = {}){
      if(typeof key !== 'string' || key.length !== 1) return false;
      const normalizedKey = TAIF.core.utils.normalizeTypeaheadText(key);
      if(!normalizedKey || normalizedKey.includes(' ')) return false;

      const now = Date.now();
      const resolvedTimeout = Math.max(240, Number(timeout) || 760);
      if(now - lastInputAt > resolvedTimeout) buffer = '';
      lastInputAt = now;

      const singleCharacter = normalizedKey.length === 1;
      const repeatedSingleCharacter = singleCharacter && buffer === normalizedKey;
      const query = repeatedSingleCharacter ? normalizedKey : `${buffer}${normalizedKey}`;
      let match = findMatch(query, currentIndex, true);

      if(!match.item && query !== normalizedKey){
        match = findMatch(normalizedKey, currentIndex, true);
        buffer = match.item ? normalizedKey : '';
      } else {
        buffer = query;
      }

      if(!match.item) return false;
      if(typeof onMatch === 'function') onMatch(match.item, match.index, { query:buffer, items:match.items });
      return true;
    }

    return {
      reset,
      handleKey,
      getBuffer(){
        return buffer;
      }
    };
  };

  TAIF.core.utils.storageGet = TAIF.core.utils.storageGet || function(key, fallback = ''){
    const storage = TAIF.core && TAIF.core.storage;
    if(!storage || typeof storage.getItem !== 'function') return fallback;
    return storage.getItem(key, fallback);
  };

  TAIF.core.utils.storageSet = TAIF.core.utils.storageSet || function(key, value){
    const storage = TAIF.core && TAIF.core.storage;
    if(!storage || typeof storage.setItem !== 'function') return;
    storage.setItem(key, value);
  };

  TAIF.core.utils.resolveStorageNamespace = TAIF.core.utils.resolveStorageNamespace || (() => {
    let cachedNamespace = '';
    const storageScopeHelpers = TAIF.__shared?.storageScope || {};
    const normalizeStorageScopeSeed = typeof storageScopeHelpers.normalizeStorageScopeSeed === 'function'
      ? storageScopeHelpers.normalizeStorageScopeSeed
      : (value) => String(value ?? '')
        .trim()
        .replace(/^file:\/*/i, '')
        .replace(/[?#].*$/, '')
        .replace(/\\/g, '/')
        .replace(/\/+/g, '/')
        .toLowerCase();
    const hashStorageScopeSeed = typeof storageScopeHelpers.hashStorageScopeSeed === 'function'
      ? storageScopeHelpers.hashStorageScopeSeed
      : (value) => {
        let hash = 2166136261;
        for(let index = 0; index < value.length; index += 1){
          hash ^= value.charCodeAt(index);
          hash = Math.imul(hash, 16777619);
        }
        return (hash >>> 0).toString(36);
      };

    return function(){
      if(cachedNamespace) return cachedNamespace;
      const root = document.documentElement;
      const explicitScope = String(root?.dataset?.storageScope || '').trim();
      const locationScope = [
        window.location?.protocol || '',
        window.location?.host || '',
        window.location?.pathname || ''
      ].filter(Boolean).join('|');
      const seed = normalizeStorageScopeSeed(explicitScope || locationScope || 'default');
      cachedNamespace = `taif:${hashStorageScopeSeed(seed)}`;
      return cachedNamespace;
    };
  })();

  TAIF.core.utils.resolveStorageKey = TAIF.core.utils.resolveStorageKey || function(key){
    const safeKey = String(key ?? '').trim();
    if(!safeKey) return '';
    const namespace = typeof TAIF.core.utils.resolveStorageNamespace === 'function'
      ? TAIF.core.utils.resolveStorageNamespace()
      : '';
    return namespace ? `${namespace}::${safeKey}` : safeKey;
  };

  TAIF.core.utils.readJsonStorage = TAIF.core.utils.readJsonStorage || function(key, fallback = null){
    const raw = TAIF.core.utils.storageGet(key, '');
    if(!raw) return TAIF.core.utils.clone(fallback);
    try{
      return JSON.parse(raw);
    }catch{
      return TAIF.core.utils.clone(fallback);
    }
  };

  TAIF.core.utils.persistJsonState = TAIF.core.utils.persistJsonState || function(key, value, normalizer){
    const normalized = typeof normalizer === 'function' ? normalizer(value) : value;
    const state = normalized && typeof normalized === 'object' ? normalized : {};
    state.updatedAt = Date.now();
    TAIF.core.utils.storageSet(key, JSON.stringify(state));
    return state;
  };


  TAIF.core.utils.createStateWriter = TAIF.core.utils.createStateWriter || function(key, normalizer){
    return function(value){
      return TAIF.core.utils.persistJsonState(key, value, normalizer);
    };
  };

  TAIF.core.utils.parseNumericInput = TAIF.core.utils.parseNumericInput || function(value, fallback = 0){
    const number = Number(String(value ?? '').replace(/,/g, '').trim());
    return Number.isFinite(number) ? number : fallback;
  };

  TAIF.core.utils.toText = TAIF.core.utils.toText || function(value, fallback = ''){
    return String(value == null ? fallback : value).trim();
  };

  TAIF.core.utils.getActiveView = TAIF.core.utils.getActiveView || function(){
    const explicit = String(document.documentElement?.dataset?.activeView || '').trim();
    if(explicit) return explicit;
    const bodyValue = String(document.body?.dataset?.activeView || '').trim();
    if(bodyValue) return bodyValue;
    const panel = document.getElementById('panel');
    if(panel instanceof HTMLElement){
      const rendered = String(panel.dataset.renderedView || panel.dataset.view || panel.dataset.requestedView || '').trim();
      if(rendered) return rendered;
    }
    return '';
  };

  TAIF.core.utils.isActiveView = TAIF.core.utils.isActiveView || function(viewId){
    const safeViewId = String(viewId ?? '').trim();
    if(!safeViewId) return false;
    return TAIF.core.utils.getActiveView() === safeViewId;
  };

  TAIF.core.utils.markOwnedNode = TAIF.core.utils.markOwnedNode || function(node, ownerView){
    if(!(node instanceof HTMLElement)) return node;
    const safeOwnerView = String(ownerView ?? '').trim();
    if(!safeOwnerView) return node;
    node.dataset.ownerView = safeOwnerView;
    node.setAttribute('data-owner-view', safeOwnerView);
    return node;
  };

  TAIF.core.utils.clampNumber = TAIF.core.utils.clampNumber || function(value, min, max){
    const safeMin = Number(min) || 0;
    const safeMax = Number(max) || 0;
    if(safeMax < safeMin) return safeMin;
    const numericValue = Number(value) || 0;
    return Math.min(safeMax, Math.max(safeMin, numericValue));
  };

  TAIF.core.utils.resolveCurrencyDecimals = TAIF.core.utils.resolveCurrencyDecimals || function(value, fallback = 2, { min = 0, max = 4 } = {}){
    const safeMin = Number.isFinite(Number(min)) ? Number(min) : 0;
    const safeMaxCandidate = Number.isFinite(Number(max)) ? Number(max) : 4;
    const safeMax = safeMaxCandidate >= safeMin ? safeMaxCandidate : safeMin;
    const numeric = Number(value);
    if(Number.isFinite(numeric)) return Math.max(safeMin, Math.min(safeMax, numeric));
    return Math.max(safeMin, Math.min(safeMax, Number(fallback) || 2));
  };

  TAIF.core.utils.renderToolbarChip = TAIF.core.utils.renderToolbarChip || function(kind, label, value){
    const escapeHtml = TAIF.core.utils.escapeHtml || ((input) => String(input ?? ''));
    const safeKind = escapeHtml(kind);
    return `
      <span class="taif-chip entries-chip taif-chip--${safeKind} entries-chip--${safeKind}">
        <span class="taif-chip__label entries-chip__label">${escapeHtml(label)}</span>
        <span class="taif-chip__count entries-chip__count">${escapeHtml(String(value))}</span>
      </span>
    `;
  };

  TAIF.core.utils.renderToolbarCommandButton = TAIF.core.utils.renderToolbarCommandButton || function(action, label, className = '', iconMarkup = '', {
    disabled = false,
    title = '',
    actionAttribute = 'data-entry-action'
  } = {}){
    const escapeHtml = TAIF.core.utils.escapeHtml || ((input) => String(input ?? ''));
    const safeTitle = String(title || '').trim() || String(label || '').trim();
    const safeClassName = String(className || '').trim();
    const safeActionAttribute = /^data-[a-z0-9_-]+$/i.test(String(actionAttribute || '').trim())
      ? String(actionAttribute || '').trim()
      : 'data-entry-action';
    const neutralClassName = safeClassName.split('entries-toolbar-btn').join('taif-toolbar-btn').split('entries-chip').join('taif-chip');
    const mergedClassName = [safeClassName, neutralClassName].filter(Boolean).join(' ').trim();
    return `
      <button class="taif-toolbar-btn entries-toolbar-btn${mergedClassName ? ` ${mergedClassName}` : ''}" type="button" ${safeActionAttribute}="${escapeHtml(action)}" aria-label="${escapeHtml(safeTitle)}" title="${escapeHtml(safeTitle)}"${disabled ? ' disabled' : ''}>
        <span class="taif-toolbar-btn__icon entries-toolbar-btn__icon" aria-hidden="true">${iconMarkup ?? ''}</span>
        <span class="taif-toolbar-btn__text entries-toolbar-btn__text taif-control-text">${escapeHtml(label)}</span>
      </button>
    `;
  };

  TAIF.core.utils.clearModalMaximizedFrame = TAIF.core.utils.clearModalMaximizedFrame || function(modal){
    if(!(modal instanceof HTMLElement)) return;
    modal.style.removeProperty('width');
    modal.style.removeProperty('max-width');
    modal.style.removeProperty('height');
    modal.style.removeProperty('max-height');
  };

  TAIF.core.utils.stopEventPropagation = TAIF.core.utils.stopEventPropagation || function(event, { preventDefault = false } = {}){
    if(!event || typeof event !== 'object') return;
    if(preventDefault && typeof event.preventDefault === 'function'){
      event.preventDefault();
    }
    if(typeof event.stopPropagation === 'function'){
      event.stopPropagation();
    }
  };

  TAIF.core.utils.runCleanupSlot = TAIF.core.utils.runCleanupSlot || function(owner, key){
    if(!owner || !key) return null;
    const cleanup = owner[key];
    owner[key] = null;
    if(typeof cleanup !== 'function') return null;
    try{
      cleanup();
    }catch{
      return null;
    }
    return cleanup;
  };

  TAIF.core.utils.clearTimerSlot = TAIF.core.utils.clearTimerSlot || function(owner, key, clearHandler = null){
    if(!owner || !key) return null;
    const timerId = owner[key];
    owner[key] = null;
    if(timerId == null) return null;

    const disposer = typeof clearHandler === 'function'
      ? clearHandler
      : (typeof window !== 'undefined' && typeof window.clearTimeout === 'function'
        ? window.clearTimeout.bind(window)
        : (typeof clearTimeout === 'function' ? clearTimeout : null));

    if(typeof disposer === 'function'){
      try{
        disposer(timerId);
      }catch{
        return null;
      }
    }

    return timerId;
  };

  TAIF.core.utils.getViewportBoundsForSize = TAIF.core.utils.getViewportBoundsForSize || function(width, height, padding = 12){
    const safeWidth = Math.max(Number(width) || 0, 0);
    const safeHeight = Math.max(Number(height) || 0, 0);
    const safePadding = Math.max(Number(padding) || 0, 0);
    return {
      minLeft: safePadding,
      maxLeft: Math.max(safePadding, window.innerWidth - safeWidth - safePadding),
      minTop: safePadding,
      maxTop: Math.max(safePadding, window.innerHeight - safeHeight - safePadding)
    };
  };

  TAIF.core.utils.setDisclosureOpenState = TAIF.core.utils.setDisclosureOpenState || function({ root = null, popup = null, trigger = null, isOpen = false, rootOpenClass = 'is-open', popupOpenClass = 'is-open' } = {}){
    const open = !!isOpen;
    if(root instanceof HTMLElement && rootOpenClass){
      root.classList.toggle(rootOpenClass, open);
    }
    if(popup instanceof HTMLElement){
      popup.hidden = !open;
      if(popupOpenClass){
        popup.classList.toggle(popupOpenClass, open);
      }
      popup.setAttribute('aria-hidden', open ? 'false' : 'true');
    }
    if(trigger instanceof HTMLElement){
      trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
    }
    return open;
  };

  TAIF.core.utils.readChartAccountCatalogSource = TAIF.core.utils.readChartAccountCatalogSource || function(accountStorageKey = '', readJsonStorageOverride = null){
    const publicApi = TAIF.chartOfAccounts || {};
    const internalApi = publicApi.internal || {};

    if(typeof publicApi.readState === 'function'){
      const state = publicApi.readState();
      return Array.isArray(state) ? state : [];
    }
    if(typeof internalApi.getCenters === 'function'){
      const state = internalApi.getCenters(true);
      return Array.isArray(state) ? state : [];
    }
    if(typeof internalApi.readCenters === 'function'){
      const state = internalApi.readCenters();
      return Array.isArray(state) ? state : [];
    }

    const readJson = typeof readJsonStorageOverride === 'function'
      ? readJsonStorageOverride
      : TAIF.core.utils.readJsonStorage;
    if(typeof readJson !== 'function') return [];

    const stored = readJson(accountStorageKey, null);
    if(Array.isArray(stored)) return stored;
    return Array.isArray(stored?.centers) ? stored.centers : [];
  };

  TAIF.core.utils.normalizeAccountCatalog = TAIF.core.utils.normalizeAccountCatalog || function(source, resolveText = null){
    const toText = typeof resolveText === 'function'
      ? (value, fallback = '') => String(resolveText(value, fallback) ?? fallback ?? '').trim()
      : (value, fallback = '') => String(value ?? fallback ?? '').trim();

    return (Array.isArray(source) ? source : [])
      .map((item) => {
        const sourceItem = item && typeof item === 'object' ? item : {};
        const accountNo = toText(sourceItem.accountNo);
        const name = toText(sourceItem.name);
        if(!accountNo || !name || sourceItem.deleted) return null;
        return {
          id: toText(sourceItem.id),
          accountNo,
          name,
          centerType: toText(sourceItem.centerType),
          country: toText(sourceItem.country),
          city: toText(sourceItem.city)
        };
      })
      .filter(Boolean)
      .sort((left, right) => left.accountNo.localeCompare(right.accountNo, 'en'));
  };

  TAIF.core.utils.isEditableFormControl = TAIF.core.utils.isEditableFormControl || function(element, { allowSelect = true, excludeInputTypes = [] } = {}){
    if(element instanceof HTMLTextAreaElement){
      return !element.disabled && !element.readOnly;
    }

    if(allowSelect && element instanceof HTMLSelectElement){
      return !element.disabled;
    }

    if(!(element instanceof HTMLInputElement)) return false;
    if(element.disabled || element.readOnly) return false;

    const blockedTypes = new Set([
      'hidden',
      'file',
      'button',
      'submit',
      'reset',
      'checkbox',
      'radio',
      'range',
      'color',
      'image',
      ...((Array.isArray(excludeInputTypes) ? excludeInputTypes : []).map((type) => String(type || '').trim().toLowerCase()).filter(Boolean))
    ]);
    const type = String(element.type || 'text').trim().toLowerCase();
    return !blockedTypes.has(type);
  };

  TAIF.core.utils.runCleanupCallbacks = TAIF.core.utils.runCleanupCallbacks || function(cleanups, { clearSource = false, reverse = false } = {}){
    const callbacks = Array.isArray(cleanups)
      ? (clearSource ? cleanups.splice(0, cleanups.length) : cleanups.slice())
      : [];
    if(reverse) callbacks.reverse();

    callbacks.forEach((cleanup) => {
      if(typeof cleanup !== 'function') return;
      try{
        cleanup();
      }catch{}
    });

    return callbacks.length;
  };

  TAIF.core.utils.pushCleanupCallback = TAIF.core.utils.pushCleanupCallback || function(list, cleanup){
    if(typeof cleanup !== 'function') return cleanup;
    if(Array.isArray(list)) list.push(cleanup);
    return cleanup;
  };

  TAIF.core.utils.createAnimationFrameScheduler = TAIF.core.utils.createAnimationFrameScheduler || function(callback){
    let frameId = 0;

    function cancel(){
      if(!frameId) return 0;
      const activeId = frameId;
      frameId = 0;
      try{
        window.cancelAnimationFrame(activeId);
      }catch{}
      return activeId;
    }

    function schedule(){
      cancel();
      frameId = window.requestAnimationFrame(() => {
        frameId = 0;
        if(typeof callback === 'function') callback();
      });
      return frameId;
    }

    return {
      schedule,
      cancel,
      isScheduled(){
        return frameId !== 0;
      }
    };
  };

  TAIF.core.utils.mountSteppedFitClasses = TAIF.core.utils.mountSteppedFitClasses || function({
    element = null,
    fitClasses = [],
    observedElements = [],
    fitsLayout = null,
    reset = null,
    onQueue = null,
    onDispose = null
  } = {}){
    if(!(element instanceof HTMLElement) || typeof fitsLayout !== 'function') return () => {};

    const safeFitClasses = Array.isArray(fitClasses) ? fitClasses.filter(Boolean) : [];
    const targets = [element, ...(Array.isArray(observedElements) ? observedElements : [])]
      .filter((node, index, list) => node instanceof HTMLElement && list.indexOf(node) === index);
    let disposed = false;
    let resizeObserver = null;

    const resetClasses = () => {
      safeFitClasses.forEach((className) => element.classList.remove(className));
      if(typeof reset === 'function') reset();
    };

    const applyFit = () => {
      if(disposed) return;
      resetClasses();
      if(fitsLayout()) return;
      for(const className of safeFitClasses){
        element.classList.add(className);
        if(fitsLayout()) return;
      }
    };

    const scheduler = TAIF.core.utils.createAnimationFrameScheduler(applyFit);
    const queueFit = () => {
      if(disposed) return 0;
      if(typeof onQueue === 'function') onQueue();
      return scheduler.schedule();
    };

    queueFit();

    if(typeof ResizeObserver === 'function' && targets.length){
      resizeObserver = new ResizeObserver(() => {
        queueFit();
      });
      targets.forEach((node) => resizeObserver.observe(node));
    }

    window.addEventListener('resize', queueFit, { passive:true });

    return () => {
      disposed = true;
      scheduler.cancel();
      if(resizeObserver) resizeObserver.disconnect();
      window.removeEventListener('resize', queueFit);
      resetClasses();
      if(typeof onDispose === 'function') onDispose();
    };
  };

  TAIF.core.utils.mountAdaptiveToolbarFit = TAIF.core.utils.mountAdaptiveToolbarFit || function({
    panel = null,
    topbarSelector = '',
    toolsSelector = '',
    searchSelector = '',
    fitClasses = ['is-fit-1', 'is-fit-2', 'is-fit-3', 'is-fit-4']
  } = {}){
    const topbar = panel instanceof HTMLElement && topbarSelector ? panel.querySelector(topbarSelector) : null;
    const tools = topbar instanceof HTMLElement && toolsSelector ? topbar.querySelector(toolsSelector) : null;
    const search = topbar instanceof HTMLElement && searchSelector ? topbar.querySelector(searchSelector) : null;
    if(!(topbar instanceof HTMLElement) || !(tools instanceof HTMLElement) || !(search instanceof HTMLElement) || typeof TAIF.core.utils.mountSteppedFitClasses !== 'function') return () => {};

    return TAIF.core.utils.mountSteppedFitClasses({
      element: topbar,
      fitClasses,
      observedElements: [tools, search],
      fitsLayout(){
        const tolerance = 2;
        const toolsFits = tools.scrollWidth <= (tools.clientWidth + tolerance);
        const topbarFits = topbar.scrollWidth <= (topbar.clientWidth + tolerance);
        return toolsFits && topbarFits;
      }
    });
  };

  TAIF.core.utils.createInlinePickerCommitController = TAIF.core.utils.createInlinePickerCommitController || function({
    trigger = null,
    selectionDatasetKey = 'taifPickerSelectionCommitted'
  } = {}){
    let suppressTriggerRefocusUntil = 0;
    let selectionCommittedFromPicker = false;

    function markDatasetSelection(isCommitted){
      if(!trigger || !trigger.dataset || !selectionDatasetKey) return;
      if(isCommitted) trigger.dataset[selectionDatasetKey] = 'true';
      else delete trigger.dataset[selectionDatasetKey];
    }

    function shouldRestoreTriggerFocusAfterSelection(){
      const shouldRestore = Date.now() >= suppressTriggerRefocusUntil;
      suppressTriggerRefocusUntil = 0;
      return shouldRestore;
    }

    function markCommittedSelection(){
      selectionCommittedFromPicker = true;
      markDatasetSelection(true);
    }

    function clearCommittedSelection(){
      selectionCommittedFromPicker = false;
      markDatasetSelection(false);
    }

    function consumeCommittedSelection(){
      const isCommitted = selectionCommittedFromPicker || !!(trigger && trigger.dataset && trigger.dataset[selectionDatasetKey] === 'true');
      if(!isCommitted) return false;
      clearCommittedSelection();
      return true;
    }

    function prepareKeyboardSelection(delay = 250){
      suppressTriggerRefocusUntil = Date.now() + Math.max(0, Number(delay) || 0);
      clearCommittedSelection();
    }

    return {
      shouldRestoreTriggerFocusAfterSelection,
      markCommittedSelection,
      clearCommittedSelection,
      consumeCommittedSelection,
      prepareKeyboardSelection
    };
  };

  TAIF.core.utils.registerInlinePickerApi = TAIF.core.utils.registerInlinePickerApi || function({
    picker = null,
    trigger = null,
    getPopover = null,
    api = null,
    clearCommittedSelection = null,
    registerCleanup = null
  } = {}){
    if(!picker || !api) return;

    picker.__taifInlinePickerApi = api;
    const popover = typeof getPopover === 'function' ? getPopover() : null;
    if(popover) popover.__taifInlinePickerApi = api;

    if(trigger && typeof clearCommittedSelection === 'function'){
      trigger.addEventListener('blur', clearCommittedSelection);
    }

    if(typeof registerCleanup === 'function'){
      registerCleanup(() => {
        if(picker.__taifInlinePickerApi === api) delete picker.__taifInlinePickerApi;
        const livePopover = typeof getPopover === 'function' ? getPopover() : null;
        if(livePopover && livePopover.__taifInlinePickerApi === api) delete livePopover.__taifInlinePickerApi;
        if(trigger && typeof clearCommittedSelection === 'function'){
          trigger.removeEventListener('blur', clearCommittedSelection);
        }
      });
    }
  };

  TAIF.registerViewMeta = function(definition){
    if(!definition || typeof definition !== 'object') return null;

    const status = String(definition.status ?? 'implemented').trim() || 'implemented';
    const normalized = {
      id:String(definition.id ?? '').trim(),
      label:String(definition.label ?? '').trim(),
      icon:String(definition.icon ?? '').trim(),
      status,
      category:String(definition.category ?? '').trim(),
      phase:String(definition.phase ?? '').trim(),
      navVisible:definition.navVisible !== false,
      routeEnabled:definition.routeEnabled !== false,
      implemented:definition.implemented !== false && status === 'implemented',
      placeholder:definition.placeholder === true || status === 'placeholder' || status === 'deferred',
      deprecated:definition.deprecated === true || status === 'deprecated',
      order:Number.isFinite(Number(definition.order)) ? Number(definition.order) : 0,
      note:String(definition.note ?? '').trim()
    };

    if(!normalized.id) return null;
    if(!normalized.label) normalized.label = normalized.id;

    const registry = Array.isArray(TAIF.registry.viewMeta)
      ? TAIF.registry.viewMeta
      : (TAIF.registry.viewMeta = []);
    const existingIndex = registry.findIndex((item) => item && item.id === normalized.id);

    if(existingIndex >= 0) registry.splice(existingIndex, 1, normalized);
    else registry.push(normalized);

    return normalized;
  };
  TAIF.registerViewRenderer = function(viewId, renderer){
    const safeViewId = String(viewId ?? '').trim();
    if(!safeViewId) return null;
    if(typeof renderer !== 'function'){
      delete TAIF.registry.viewRenderers[safeViewId];
      return null;
    }
    TAIF.registry.viewRenderers[safeViewId] = renderer;
    return renderer;
  };
  TAIF.registerNoopViewRenderer = function(viewId){
    return TAIF.registerViewRenderer(viewId, ({ panel }) => {
      void panel;
    });
  };
  TAIF.registerViewCleanup = function(viewId, cleanup){
    const safeViewId = String(viewId ?? '').trim();
    if(!safeViewId) return;
    if(typeof cleanup === 'function') TAIF.registry.viewCleanup[safeViewId] = cleanup;
    else delete TAIF.registry.viewCleanup[safeViewId];
  };
  TAIF.runViewCleanup = function(viewId, context = {}){
    const safeViewId = String(viewId ?? '').trim();
    if(!safeViewId) return;
    const cleanupRegistry = TAIF.registry && TAIF.registry.viewCleanup ? TAIF.registry.viewCleanup : null;
    const cleanup = cleanupRegistry ? cleanupRegistry[safeViewId] : null;
    if(typeof cleanup !== 'function') return;
    try{ cleanup({ viewId:safeViewId, ...context }); }catch{}
  };
})();
