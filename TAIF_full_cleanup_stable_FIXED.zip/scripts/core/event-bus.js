(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.core = TAIF.core || {};

  const EVENT_CONTRACT_VERSION = 1;
  const MAX_HISTORY = 80;

  const EVENT_NAMES = Object.freeze({
    CHART_OF_ACCOUNTS_UPDATED:'taif:chart-of-accounts-updated',
    CURRENCY_UPDATED:'taif:currency-domain-updated',
    CURRENCY_MANAGEMENT_UPDATED:'taif:currency-management-updated',
    CASH_BOXES_UPDATED:'taif:cash-boxes-updated',
    CUSTOMER_CARD_UPDATED:'taif:customer-card-updated',
    ENTRIES_VOUCHERS_UPDATED:'taif:entries-vouchers-updated',
    SALES_PURCHASE_UPDATED:'taif:sales-purchase-invoice-updated',
    LEDGER_READ_MODEL_INVALIDATED:'taif:ledger-read-model-invalidated'
  });

  const DOMAIN_UPDATE_EVENTS = Object.freeze({
    accounts:EVENT_NAMES.CHART_OF_ACCOUNTS_UPDATED,
    'chart-of-accounts':EVENT_NAMES.CHART_OF_ACCOUNTS_UPDATED,
    currency:EVENT_NAMES.CURRENCY_UPDATED,
    'cash-boxes':EVENT_NAMES.CASH_BOXES_UPDATED,
    customers:EVENT_NAMES.CUSTOMER_CARD_UPDATED,
    'customer-card':EVENT_NAMES.CUSTOMER_CARD_UPDATED,
    entries:EVENT_NAMES.ENTRIES_VOUCHERS_UPDATED,
    'entries-vouchers':EVENT_NAMES.ENTRIES_VOUCHERS_UPDATED,
    'sales-purchase':EVENT_NAMES.SALES_PURCHASE_UPDATED,
    'sales-purchase-invoice':EVENT_NAMES.SALES_PURCHASE_UPDATED,
    ledger:EVENT_NAMES.LEDGER_READ_MODEL_INVALIDATED
  });

  const CANONICAL_EVENT_ALIASES = Object.freeze({
    [EVENT_NAMES.CURRENCY_UPDATED]:Object.freeze([EVENT_NAMES.CURRENCY_MANAGEMENT_UPDATED])
  });

  const EVENT_ALIAS_TO_CANONICAL = Object.freeze(Object.keys(CANONICAL_EVENT_ALIASES).reduce((map, canonical) => {
    (CANONICAL_EVENT_ALIASES[canonical] || []).forEach((alias) => {
      map[alias] = canonical;
    });
    return map;
  }, {}));

  const history = [];

  function normalizeText(value){
    return String(value ?? '').trim();
  }

  function normalizeDomain(value){
    return normalizeText(value).replace(/[^a-z0-9-]/gi, '').toLowerCase();
  }

  function resolveEventName(eventName){
    const safeEventName = normalizeText(eventName);
    if(!safeEventName) return '';
    return EVENT_ALIAS_TO_CANONICAL[safeEventName] || safeEventName;
  }

  function resolveAliases(eventName){
    const canonical = resolveEventName(eventName);
    if(!canonical) return [];
    return (CANONICAL_EVENT_ALIASES[canonical] || []).filter((alias) => alias && alias !== canonical);
  }

  function buildDetail(eventName, detail = {}, options = {}){
    const canonicalEvent = resolveEventName(eventName);
    const safeDetail = detail && typeof detail === 'object' ? detail : {};
    const safeOptions = options && typeof options === 'object' ? options : {};
    const domain = normalizeDomain(safeOptions.domain || safeDetail.domain || resolveDomainByEvent(canonicalEvent));
    return {
      ...safeDetail,
      domain,
      source:normalizeText(safeOptions.source || safeDetail.source || ''),
      reason:normalizeText(safeOptions.reason || safeDetail.reason || ''),
      eventContract:'taif-domain-update-v1',
      eventContractVersion:EVENT_CONTRACT_VERSION,
      canonicalEvent,
      eventName:canonicalEvent,
      emittedAt:Date.now()
    };
  }

  function resolveDomainByEvent(eventName){
    const canonical = resolveEventName(eventName);
    const match = Object.keys(DOMAIN_UPDATE_EVENTS).find((domain) => DOMAIN_UPDATE_EVENTS[domain] === canonical);
    return match || '';
  }

  function remember(record){
    history.push(record);
    while(history.length > MAX_HISTORY) history.shift();
  }

  function dispatchEventName(eventName, detail, { aliasOf = '' } = {}){
    if(!eventName || typeof window === 'undefined' || typeof window.dispatchEvent !== 'function') return false;
    try{
      const payload = aliasOf ? { ...detail, aliasOf } : detail;
      window.dispatchEvent(new CustomEvent(eventName, { detail:payload }));
      remember({ eventName, canonicalEvent:detail?.canonicalEvent || eventName, domain:detail?.domain || '', source:detail?.source || '', aliasOf, emittedAt:detail?.emittedAt || Date.now() });
      return true;
    }catch{
      return false;
    }
  }

  function emit(eventName, detail = {}, options = {}){
    const canonicalEvent = resolveEventName(eventName);
    if(!canonicalEvent) return false;
    const payload = buildDetail(canonicalEvent, detail, options);
    const dispatched = dispatchEventName(canonicalEvent, payload);
    resolveAliases(canonicalEvent).forEach((alias) => {
      dispatchEventName(alias, payload, { aliasOf:canonicalEvent });
    });
    return dispatched;
  }

  function emitDomainUpdate(domain, detail = {}, options = {}){
    const safeDomain = normalizeDomain(domain);
    const eventName = DOMAIN_UPDATE_EVENTS[safeDomain];
    if(!eventName) return false;
    return emit(eventName, detail, { ...options, domain:safeDomain });
  }

  function invalidateLedger(reason = '', detail = {}, options = {}){
    return emit(EVENT_NAMES.LEDGER_READ_MODEL_INVALIDATED, { ...(detail && typeof detail === 'object' ? detail : {}), reason:normalizeText(reason) }, { ...options, domain:'ledger' });
  }

  function on(eventName, handler, options = {}){
    const safeEventName = normalizeText(eventName);
    if(!safeEventName || typeof handler !== 'function' || typeof window === 'undefined') return () => {};
    window.addEventListener(safeEventName, handler, options);
    return () => {
      try{ window.removeEventListener(safeEventName, handler, options); }catch{}
    };
  }

  function off(eventName, handler, options = {}){
    const safeEventName = normalizeText(eventName);
    if(!safeEventName || typeof handler !== 'function' || typeof window === 'undefined') return false;
    try{
      window.removeEventListener(safeEventName, handler, options);
      return true;
    }catch{
      return false;
    }
  }

  function onMany(eventNames, handler, options = {}){
    const names = Array.from(new Set((Array.isArray(eventNames) ? eventNames : [eventNames]).map(normalizeText).filter(Boolean)));
    const cleanups = names.map((name) => on(name, handler, options));
    return () => cleanups.splice(0).forEach((cleanup) => {
      try{ cleanup(); }catch{}
    });
  }

  function listContract(){
    return {
      version:EVENT_CONTRACT_VERSION,
      events:{ ...EVENT_NAMES },
      domainEvents:{ ...DOMAIN_UPDATE_EVENTS },
      aliases:Object.keys(CANONICAL_EVENT_ALIASES).reduce((map, eventName) => {
        map[eventName] = (CANONICAL_EVENT_ALIASES[eventName] || []).slice();
        return map;
      }, {})
    };
  }

  TAIF.core.events = {
    EVENT_CONTRACT_VERSION,
    EVENT_NAMES,
    DOMAIN_UPDATE_EVENTS,
    CANONICAL_EVENT_ALIASES,
    resolveEventName,
    resolveAliases,
    emit,
    emitDomainUpdate,
    invalidateLedger,
    on,
    off,
    onMany,
    listContract,
    getHistory(){
      return history.slice();
    }
  };
})();
