(()=>{
  'use strict';
  const TAIF = window.TAIF || (window.TAIF = {});
  const root = document.documentElement;
  const resolveDomNode = (id) => {
    const node = document.getElementById(id);
    return node instanceof HTMLElement ? node : null;
  };
  const dom = {
    nav: resolveDomNode('nav'),
    panel: resolveDomNode('panel'),
    btnToggle: resolveDomNode('btnToggle'),
    contentTrail: resolveDomNode('contentTrail')
  };
  const requiredConfig = TAIF.config && typeof TAIF.config === 'object' ? TAIF.config : null;
  const canCreateStore = typeof TAIF?.core?.createStateStore === 'function';
  const hasPanel = dom?.panel instanceof HTMLElement;
  const hasNav = dom?.nav instanceof HTMLElement;
  const hasToggle = dom?.btnToggle instanceof HTMLElement;

  if(!requiredConfig || !canCreateStore || !hasPanel || !hasNav) return;

  const store = TAIF.core.createStateStore({ root, config: requiredConfig });
  let previousState = null;

  function recoverActiveViewIfNeeded(force = false){
    const state = store.getState();
    const renderedView = String(dom.panel.dataset.renderedView || '').trim();
    const hasLoadingState = !!dom.panel.querySelector('.panel__status--loading');
    if(!force && !hasLoadingState && renderedView === state.activeView) return;
    TAIF.views.renderActive(dom.panel, state.activeView);
  }

  TAIF.ui.nav.render(dom.nav, requiredConfig.views);
  TAIF.ui.nav.bind(dom.nav, store);
  TAIF.ui.selectionGuard?.bind(document);
  TAIF.ui.smartWritingFields?.bind(document);
  if(hasToggle && typeof TAIF?.ui?.shell?.bindToggle === 'function') TAIF.ui.shell.bindToggle(root, dom.btnToggle, store);

  function apply(state){
    const previousViewId = previousState ? previousState.activeView : '';
    const shouldRenderActiveView = !previousState || previousViewId !== state.activeView || dom.panel.dataset.renderedView !== state.activeView;

    TAIF.ui.shell.apply(root, dom, state);
    if(shouldRenderActiveView){
      TAIF.views.renderActive(dom.panel, state.activeView);
    }

    previousState = { ...state };
  }

  store.subscribe(apply);
  apply(store.getState());
  store.save();
  window.addEventListener('load', () => {
    recoverActiveViewIfNeeded(false);
  }, { once: true });
  requestAnimationFrame(() => { root.classList.add('taif-ready'); });
})();
