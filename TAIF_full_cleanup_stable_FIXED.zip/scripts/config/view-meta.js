(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  const registerViewMeta = typeof TAIF.registerViewMeta === 'function'
    ? TAIF.registerViewMeta.bind(TAIF)
    : null;

  if(typeof registerViewMeta !== 'function') return;

  const VIEW_STATUS = Object.freeze({
    IMPLEMENTED:'implemented'
  });

  const VIEW_META = Object.freeze([
    Object.freeze({ id:'cash-boxes', label:'الصناديق النقدي', icon:'assets/icons/cash-boxes.png', status:VIEW_STATUS.IMPLEMENTED, category:'accounting', order:10 }),
    Object.freeze({ id:'price-screen', label:'شاشة الاسعار', icon:'assets/icons/price-screen.png', status:VIEW_STATUS.IMPLEMENTED, category:'currency', order:20 }),
    Object.freeze({ id:'currency-management', label:'إدارة العملات', icon:'assets/icons/currency-management.png', status:VIEW_STATUS.IMPLEMENTED, category:'currency', order:30 }),
    Object.freeze({ id:'chart-of-accounts', label:'شجرة الحسابات', icon:'assets/icons/chart-of-accounts.png', status:VIEW_STATUS.IMPLEMENTED, category:'accounting', order:40 }),
    Object.freeze({ id:'customer-card', label:'بطاقة العميل', icon:'assets/icons/customer-card.png', status:VIEW_STATUS.IMPLEMENTED, category:'parties', order:50 }),
    Object.freeze({ id:'entries-vouchers', label:'القيود والسندات', icon:'assets/icons/entries-vouchers.png', status:VIEW_STATUS.IMPLEMENTED, category:'accounting', order:60 }),
    Object.freeze({ id:'sales-purchase-invoice', label:'فاتورة شراء', icon:'assets/icons/sales-purchase-invoice.png', status:VIEW_STATUS.IMPLEMENTED, category:'operations', order:70 }),
    Object.freeze({ id:'sales-purchase-sale', label:'فاتورة مبيع', icon:'assets/icons/sales-purchase-invoice.png', status:VIEW_STATUS.IMPLEMENTED, category:'operations', order:71 }),
    Object.freeze({ id:'general-ledger', label:'دفتر الاستاذ', icon:'assets/icons/general-ledger.png', status:VIEW_STATUS.IMPLEMENTED, category:'reports', order:80 }),
    Object.freeze({ id:'daily-journal', label:'دفتر اليومي', icon:'assets/icons/daily-journal.png', status:VIEW_STATUS.IMPLEMENTED, category:'reports', order:81 })
  ]);

  VIEW_META.forEach((definition) => {
    registerViewMeta(definition);
  });
})();
