(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  const currentConfig = TAIF.config && typeof TAIF.config === 'object' ? TAIF.config : {};

  const freezeTextList = (items) => Object.freeze(items.map((item) => String(item || '').trim()).filter(Boolean));
  const createBundle = ({ styles = [], scripts = [] } = {}) => Object.freeze({
    styles: freezeTextList(styles),
    scripts: freezeTextList(scripts)
  });

  const sharedUiLayerStyles = freezeTextList([
    'styles/24-shared-flag-system.css',
    'styles/26-shared-dropdown-unification.css',
    'styles/27-shared-ui-primitives.css',
    'styles/32-window-system.css',
    'styles/33-button-system.css',
    'styles/34-field-system.css']);

  const entriesSurfaceStyles = freezeTextList([
    ...sharedUiLayerStyles,
    'app/sections/entries-vouchers/styles.css'
  ]);

  const salesPurchaseSurfaceStyles = freezeTextList([
    ...sharedUiLayerStyles,
    'app/sections/sales-purchase/styles.css'
  ]);


  const chartOfAccountsScripts = freezeTextList([
    'app/sections/chart-of-accounts/core.js',
    'app/sections/chart-of-accounts/public-api.js',
    'app/sections/chart-of-accounts/pickers.js',
    'app/sections/chart-of-accounts/modal.js',
    'app/sections/chart-of-accounts/render.js',
    'app/sections/chart-of-accounts/dialogs.js',
    'app/sections/chart-of-accounts/index.js'
  ]);


  const chartDomainScripts = freezeTextList([
    'app/sections/chart-of-accounts/core.js',
    'app/sections/chart-of-accounts/public-api.js'
  ]);

  const currencyDomainScripts = freezeTextList([
    'app/sections/currency-management/number-system.js',
    'app/sections/currency-management/core.js',
    'app/sections/currency-management/pricing-engine.js',
    'app/sections/currency-management/domain-public-api.js'
  ]);

  const currencyDisplayScripts = freezeTextList([
    'app/sections/currency-management/display-ui.js'
  ]);

  const cashBoxesDomainScripts = freezeTextList([
    'app/sections/cash-boxes/domain-public-api.js'
  ]);

  const entriesDomainScripts = freezeTextList([
    'app/sections/entries-vouchers/domain-public-api.js'
  ]);

  const salesPurchaseScripts = freezeTextList([
    ...chartDomainScripts,
    ...currencyDomainScripts,
    ...cashBoxesDomainScripts,
    ...entriesDomainScripts,
    'app/sections/sales-purchase/foundation.js',
    'app/sections/sales-purchase/records-store.js',
    'app/sections/sales-purchase/accounting-service.js',
    'app/sections/sales-purchase/workspace.js',
    'app/sections/sales-purchase/board-controller.js',
    'app/sections/sales-purchase/bootstrap.js'
  ]);

  const currencyManagementViewScripts = freezeTextList([
    ...currencyDomainScripts,
    ...currencyDisplayScripts,
    'app/sections/currency-management/windowing.js',
    'app/sections/currency-management/modal-ui.js',
    'app/sections/currency-management/index.js'
  ]);

  const entriesVoucherScripts = freezeTextList([
    'app/sections/entries-vouchers/core.js',
    'app/sections/entries-vouchers/catalogs.js',
    'app/sections/entries-vouchers/drafts.js',
    'app/sections/entries-vouchers/records.js',
    'app/sections/entries-vouchers/render.js',
    'app/sections/entries-vouchers/windowing.js',
    'app/sections/entries-vouchers/navigator.js',
    'app/sections/entries-vouchers/interactions.js',
    'app/sections/entries-vouchers/flow.js',
    'app/sections/entries-vouchers/controller.js',
    'app/sections/entries-vouchers/bindings.js',
    'app/sections/entries-vouchers/index.js'
  ]);

  const nextViewAssets = Object.freeze({
    ...((currentConfig && currentConfig.viewAssets) || {}),
    'cash-boxes': createBundle({
      styles: [
        ...sharedUiLayerStyles,
        'app/sections/cash-boxes/styles.css'
      ],
      scripts: [
        ...chartDomainScripts,
        ...currencyDomainScripts,
        ...cashBoxesDomainScripts,
        ...entriesDomainScripts,
        'app/sections/cash-boxes/index.js'
      ]
    }),
    'chart-of-accounts': createBundle({
      styles: [
        ...sharedUiLayerStyles,
        'app/sections/chart-of-accounts/styles.css'
      ],
      scripts: [
        ...currencyDomainScripts,
        ...chartOfAccountsScripts
      ]
    }),
    'customer-card': createBundle({
      styles: [
        ...sharedUiLayerStyles,
        'app/sections/customer-card/styles.css'
      ],
      scripts: [
        'app/sections/customer-card/domain.js',
        'app/sections/customer-card/index.js'
      ]
    }),
    'general-ledger': createBundle({
      styles: [
        ...sharedUiLayerStyles,
        'app/sections/general-ledger/styles.css'
      ],
      scripts: [
        ...currencyDomainScripts
      ]
    }),
    'daily-journal': createBundle({
      styles: [
        ...sharedUiLayerStyles,
        'app/sections/daily-journal/styles.css'
      ],
      scripts: [
        ...chartDomainScripts,
        ...currencyDomainScripts,
        ...cashBoxesDomainScripts,
        ...entriesDomainScripts,
        'app/sections/daily-journal/controller.js',
        'app/sections/daily-journal/render.js'
      ]
    }),
    'entries-vouchers': createBundle({
      styles: [
        ...entriesSurfaceStyles
      ],
      scripts: [
        ...chartDomainScripts,
        ...currencyDomainScripts,
        ...cashBoxesDomainScripts,
        ...entriesDomainScripts,
        ...entriesVoucherScripts
      ]
    }),
    'currency-management': createBundle({
      styles: [
        ...sharedUiLayerStyles,
        'app/sections/currency-management/styles.css'
      ],
      scripts: currencyManagementViewScripts
    }),
    'price-screen': createBundle({
      styles: [
        ...sharedUiLayerStyles,
        'app/sections/price-screen/styles.css'
      ],
      scripts: [
        ...currencyDomainScripts,
        ...currencyDisplayScripts,
        'app/sections/price-screen/index.js'
      ]
    }),
    'sales-purchase-invoice': createBundle({
      styles: [
        ...salesPurchaseSurfaceStyles
      ],
      scripts: salesPurchaseScripts
    }),
    'sales-purchase-sale': createBundle({
      styles: [
        ...salesPurchaseSurfaceStyles
      ],
      scripts: salesPurchaseScripts
    })
  });

  TAIF.config = Object.freeze({
    ...currentConfig,
    viewAssets: nextViewAssets
  });
})();
