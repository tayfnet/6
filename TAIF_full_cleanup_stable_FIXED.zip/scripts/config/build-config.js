(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  const root = document.documentElement;
  const registeredViews = Array.isArray(TAIF?.registry?.viewMeta) ? TAIF.registry.viewMeta : [];
  const allViews = Object.freeze(registeredViews
    .map((view) => Object.freeze({ ...view }))
    .sort((left, right) => (Number(left?.order) || 0) - (Number(right?.order) || 0)));
  const views = Object.freeze(allViews.filter((view) => view
    && view.routeEnabled !== false
    && view.navVisible !== false
    && !['hidden', 'deprecated', 'deferred'].includes(String(view.status || '').trim())
  ));
  const requestedDefaultView = String(root?.dataset?.view || '').trim();
  const defaultView = views.some((view) => view.id === requestedDefaultView)
    ? requestedDefaultView
    : (views[0]?.id || 'cash-boxes');
  const viewRegistryStats = Object.freeze({
    total:allViews.length,
    active:views.length,
    hidden:allViews.filter((view) => view.navVisible === false || view.routeEnabled === false).length,
    implemented:allViews.filter((view) => view.status === 'implemented').length,
    deferred:allViews.filter((view) => view.status === 'deferred').length,
    deprecated:allViews.filter((view) => view.status === 'deprecated').length
  });

  const shellStorageKey = TAIF?.core?.storageKeys?.shell || 'taif-shell-state-v3';

  TAIF.config = Object.freeze({
    key: root?.dataset?.key || shellStorageKey,
    defaultView,
    views,
    allViews,
    viewRegistryStats
  });
})();
