(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.ui = TAIF.ui || {};
  TAIF.ui.nav = TAIF.ui.nav || {};

  TAIF.ui.nav.setActive = function(navElement, viewId){
    if(!(navElement instanceof HTMLElement)) return;
    const safeViewId = typeof TAIF?.core?.utils?.escapeSelectorValue === 'function'
      ? TAIF.core.utils.escapeSelectorValue(viewId)
      : String(viewId ?? '').replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    const previous = navElement.querySelector('.navbtn.active');
    if(previous) previous.classList.remove('active');
    if(!safeViewId) return;
    const next = navElement.querySelector(`.navbtn[data-view="${safeViewId}"]`);
    if(next) next.classList.add('active');
  };
})();
