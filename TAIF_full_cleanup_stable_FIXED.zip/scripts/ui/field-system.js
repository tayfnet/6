(()=>{

  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.ui = TAIF.ui || {};
  TAIF.core = TAIF.core || {};
  TAIF.core.utils = TAIF.core.utils || {};

  const utils = TAIF.core.utils;

  const CONTROL_SELECTOR = [
    'input:not([type="hidden"]):not([type="file"]):not([type="checkbox"]):not([type="radio"])',
    'textarea',
    'select',
    '[contenteditable="true"]',
    '[contenteditable="plaintext-only"]',
    '[data-taif-picker-trigger="true"]',
    '[data-customer-card-segment]',
    '[data-sales-purchase-party-segment]',
    '.entries-voucher-field__control',
    '.entries-voucher-navbox__input',
    '.entries-search__input',
    '.coa-form__input',
    '.chart-accounts__search-input',
    '.currency-management-input',
    '.currency-management-search-input',
    '.customer-card-field__control',
    '.general-ledger-field__control',
    '.sales-purchase-form-field__control',
    '.sales-purchase-name-field__input',
    '.sales-purchase-top-field__text-input',
    '.sales-purchase-side-field__control'
  ].join(', ');

  const FIELD_SELECTOR = [
    '.taif-field',
    'label',
    '.coa-form__field',
    '.currency-management-field',
    '.entries-voucher-field',
    '.entries-voucher-navbox__field',
    '.sales-purchase-form-field',
    '.sales-purchase-name-field',
    '.sales-purchase-top-field',
    '.sales-purchase-side-field',
    '.customer-card-field',
    '.customer-card-phone-field',
    '.general-ledger-field'
  ].join(', ');

  const LABEL_SELECTOR = [
    '.taif-field__label',
    '.coa-form__label',
    '.currency-management-field__caption',
    '.entries-voucher-field__label',
    '.sales-purchase-form-field__label',
    '.sales-purchase-name-field__label',
    '.sales-purchase-top-field__stack-label',
    '.sales-purchase-side-field__label',
    '.customer-card-field__label',
    '.general-ledger-field__label'
  ].join(', ');

  const LEGACY_FIELD_HINTS = Object.freeze([
    'coa-form__field','currency-management-field','entries-voucher-field','entries-voucher-navbox__field',
    'sales-purchase-form-field','sales-purchase-name-field','sales-purchase-top-field','sales-purchase-side-field',
    'customer-card-field','customer-card-phone-field','general-ledger-field'
  ]);

  function toText(value, fallback = ''){
    const text = String(value ?? '').trim();
    return text || fallback;
  }

  function normalizeToken(value, fallback = ''){
    return toText(value, fallback).toLowerCase().replace(/\s+/g, '-');
  }

  function isElement(value){ return value instanceof Element; }
  function isHTMLElement(value){ return value instanceof HTMLElement; }

  function classText(node){ return String(node?.className || '').toLowerCase(); }

  function inferOwner(node = null, ownerView = ''){
    const explicit = normalizeToken(ownerView || node?.dataset?.ownerView || node?.getAttribute?.('data-owner-view') || '');
    if(explicit) return explicit;

    if(isHTMLElement(node)){
      const parent = node.closest('[data-owner-view], [data-taif-window-owner], [data-taif-button-owner], [data-taif-field-owner]');
      if(parent instanceof HTMLElement){
        const parentOwner = normalizeToken(parent.dataset.ownerView || parent.dataset.taifWindowOwner || parent.dataset.taifButtonOwner || parent.dataset.taifFieldOwner || '');
        if(parentOwner) return parentOwner;
      }

      const classes = classText(node);
      if(classes.includes('currency-management')) return 'currency-management';
      if(classes.includes('coa-') || classes.includes('chart-accounts')) return 'chart-of-accounts';
      if(classes.includes('entries-')) return 'entries-vouchers';
      if(classes.includes('sales-purchase-')) return 'sales-purchase-invoice';
      if(classes.includes('customer-card')) return 'customer-card';
      if(classes.includes('general-ledger')) return 'general-ledger';
      if(classes.includes('cash-boxes')) return 'cash-boxes';
    }

    if(typeof utils.getActiveView === 'function'){
      const active = normalizeToken(utils.getActiveView());
      if(active) return active;
    }

    const htmlView = normalizeToken(document.documentElement?.dataset?.activeView || '');
    if(htmlView) return htmlView;
    const bodyView = normalizeToken(document.body?.dataset?.activeView || '');
    if(bodyView) return bodyView;
    const panel = document.getElementById('panel');
    if(panel instanceof HTMLElement) return normalizeToken(panel.dataset.renderedView || panel.dataset.view || '');
    return '';
  }

  function isSkippableControl(control){
    if(!isHTMLElement(control)) return true;
    if(control.matches('[data-taif-field-skip="true"], [data-taif-control-skip="true"]')) return true;
    if(control.matches('input[type="hidden"], input[type="file"], input[type="checkbox"], input[type="radio"]')) return true;
    return false;
  }

  function hasLegacyFieldHint(field){
    if(!isHTMLElement(field)) return false;
    const classes = String(field.className || '');
    return LEGACY_FIELD_HINTS.some((hint) => classes.includes(hint));
  }

  function inferKind(control){
    if(!isHTMLElement(control)) return 'control';
    if(control.matches('[data-taif-picker-trigger="true"], [aria-haspopup="listbox"]')) return 'picker';
    if(control.matches('[aria-haspopup="dialog"], .entries-voucher-date__trigger, .customer-card-field__control--date-trigger')) return 'date';
    if(control instanceof HTMLTextAreaElement) return 'textarea';
    if(control instanceof HTMLSelectElement) return 'select';
    if(control.matches('[contenteditable="true"], [contenteditable="plaintext-only"]')) return 'editable';
    if(control instanceof HTMLInputElement){
      const type = normalizeToken(control.type || control.getAttribute('type') || 'text', 'text');
      const inputMode = normalizeToken(control.inputMode || control.getAttribute('inputmode') || '');
      if(type === 'search') return 'search';
      if(type === 'tel') return 'phone';
      if(type === 'number' || inputMode === 'decimal' || inputMode === 'numeric') return 'number';
      if(type === 'date' || type === 'month') return 'date-native';
      if(type === 'email') return 'email';
      if(type === 'password') return 'password';
      return 'text';
    }
    if(control.getAttribute('role') === 'radio' || control.matches('[data-customer-card-segment], [data-sales-purchase-party-segment]')) return 'segmented';
    if(control instanceof HTMLButtonElement || control.getAttribute('role') === 'button') return 'button-control';
    return 'control';
  }

  function getFieldWrapper(control){
    if(!isHTMLElement(control)) return null;
    if(control.matches(FIELD_SELECTOR)) return control;
    const wrapper = control.closest(FIELD_SELECTOR);
    if(wrapper instanceof HTMLElement) return wrapper;
    const label = control.closest('label');
    return label instanceof HTMLElement ? label : null;
  }

  function getFieldName(control, field = null){
    if(!isHTMLElement(control)) return '';
    const attrs = [
      control.dataset.taifFieldName,
      control.dataset.field,
      control.dataset.coaField,
      control.dataset.customerCardField,
      control.dataset.salesPurchaseField,
      control.dataset.salesPurchasePartyField,
      control.dataset.generalLedgerFilter,
      control.getAttribute('name'),
      control.getAttribute('aria-label'),
      field?.dataset?.taifFieldName
    ];
    for(const value of attrs){
      const safe = toText(value);
      if(safe) return safe;
    }
    return '';
  }

  function normalizeLabel(label, { ownerView = '', field = null } = {}){
    if(!isHTMLElement(label)) return null;
    label.classList.add('taif-field__label');
    label.dataset.taifFieldLabel = 'true';
    const owner = inferOwner(label, ownerView || field?.dataset?.taifFieldOwner || '');
    if(owner) label.dataset.taifFieldOwner = owner;
    return label;
  }

  function normalizeField(field, { control = null, ownerView = '', kind = '', name = '', source = 'field-system' } = {}){
    if(!isHTMLElement(field)) return null;
    const owner = inferOwner(field, ownerView || control?.dataset?.taifFieldOwner || '');
    const safeKind = normalizeToken(kind || control?.dataset?.taifControlKind || inferKind(control) || 'control', 'control');
    const safeName = toText(name || getFieldName(control, field));

    field.classList.add('taif-field');
    field.dataset.taifField = 'true';
    field.dataset.taifFieldKind = safeKind;
    field.dataset.taifFieldSource = source;
    if(owner) field.dataset.taifFieldOwner = owner;
    if(safeName) field.dataset.taifFieldName = safeName;
    if(hasLegacyFieldHint(field)) field.dataset.taifFieldAdapter = 'legacy';

    const label = field.querySelector(LABEL_SELECTOR);
    if(label instanceof HTMLElement) normalizeLabel(label, { ownerView:owner, field });

    return field;
  }

  function normalizeControl(control, { ownerView = '', source = 'field-system' } = {}){
    if(!isHTMLElement(control) || isSkippableControl(control)) return null;

    const kind = inferKind(control);
    const field = getFieldWrapper(control);
    const owner = inferOwner(control, ownerView || field?.dataset?.taifFieldOwner || '');
    const name = getFieldName(control, field);
    const isReadOnly = !!(control.matches('[readonly], [aria-readonly="true"]') || control.getAttribute('contenteditable') === 'false');
    const isDisabled = !!(control.matches('[disabled], [aria-disabled="true"]'));

    control.dataset.taifControl = 'true';
    control.dataset.taifControlKind = kind;
    control.dataset.taifFieldSource = source;
    if(owner) control.dataset.taifFieldOwner = owner;
    if(name) control.dataset.taifFieldName = name;
    if(isReadOnly) control.dataset.taifControlReadonly = 'true';
    if(isDisabled) control.dataset.taifControlDisabled = 'true';

    control.classList.add('taif-control');
    if(control instanceof HTMLInputElement){
      control.classList.add('taif-input');
      if(kind === 'number') control.classList.add('taif-number');
      if(kind === 'search') control.classList.add('taif-search');
    }else if(control instanceof HTMLTextAreaElement){
      control.classList.add('taif-textarea');
    }else if(control instanceof HTMLSelectElement){
      control.classList.add('taif-select');
    }else if(kind === 'date' || kind === 'date-native'){
      control.classList.add('taif-date-trigger');
    }else if(kind === 'picker'){
      control.classList.add('taif-picker-trigger');
    }

    if(kind === 'date') control.classList.add('taif-date-trigger');
    if(kind === 'picker') control.classList.add('taif-picker-trigger');

    normalizeField(field, { control, ownerView:owner, kind, name, source });
    return control;
  }

  function normalizeRoot(root = document, { ownerView = '', source = 'field-system' } = {}){
    const target = (isElement(root) || root === document) ? root : document;
    const result = { fields:0, controls:0, labels:0 };

    target.querySelectorAll?.(CONTROL_SELECTOR).forEach((control) => {
      if(!(control instanceof HTMLElement)) return;
      const normalized = normalizeControl(control, { ownerView, source });
      if(normalized) result.controls += 1;
    });

    target.querySelectorAll?.(FIELD_SELECTOR).forEach((field) => {
      if(!(field instanceof HTMLElement)) return;
      const firstControl = field.querySelector?.(CONTROL_SELECTOR);
      const normalized = normalizeField(field, { control:firstControl instanceof HTMLElement ? firstControl : null, ownerView, source });
      if(normalized) result.fields += 1;
    });

    target.querySelectorAll?.(LABEL_SELECTOR).forEach((label) => {
      if(!(label instanceof HTMLElement)) return;
      normalizeLabel(label, { ownerView });
      result.labels += 1;
    });

    return result;
  }

  let observer = null;
  let pending = new Set();
  let scheduled = false;

  function flushPending(){
    scheduled = false;
    const nodes = Array.from(pending);
    pending.clear();
    nodes.forEach((node) => {
      if(!isHTMLElement(node) || !node.isConnected) return;
      try{ normalizeRoot(node, { source:'field-system-mutation' }); }catch{}
      if(node.matches?.(CONTROL_SELECTOR)){
        try{ normalizeControl(node, { source:'field-system-mutation' }); }catch{}
      }
    });
  }

  function scheduleNode(node){
    if(!isHTMLElement(node)) return;
    pending.add(node);
    if(!scheduled){
      scheduled = true;
      window.requestAnimationFrame(flushPending);
    }
  }

  function startObserver(){
    if(observer || typeof MutationObserver !== 'function' || !document.body) return;
    observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if(node instanceof HTMLElement) scheduleNode(node);
        });
      });
    });
    observer.observe(document.body, { childList:true, subtree:true });
  }

  function getContractSelectors(){
    return { controls:CONTROL_SELECTOR, fields:FIELD_SELECTOR, labels:LABEL_SELECTOR };
  }

  TAIF.ui.fieldSystem = Object.freeze({
    selectors:Object.freeze(getContractSelectors()),
    normalizeRoot,
    normalizeControl,
    normalizeField,
    normalizeLabel,
    getContractSelectors,
    startObserver
  });

  function bootstrap(){
    try{ normalizeRoot(document, { source:'initial-document-scan' }); }catch{}
    startObserver();
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', bootstrap, { once:true });
  }else{
    bootstrap();
  }
})();
