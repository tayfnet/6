(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.ui = TAIF.ui || {};
  TAIF.ui.nav = TAIF.ui.nav || {};

  TAIF.ui.nav.bind = function(navElement, store){
    if(!(navElement instanceof HTMLElement) || !store || typeof store.getState !== 'function' || typeof store.setState !== 'function') return;

    navElement.addEventListener('click', (event) => {
      const button = event.target instanceof Element ? event.target.closest('.navbtn') : null;
      if(!(button instanceof HTMLElement)) return;

      const actionId = String(button.dataset.action || '').trim();
      if(actionId === 'factory-reset'){
        event.preventDefault();
        event.stopPropagation();
        TAIF?.ui?.factoryReset?.open?.();
        return;
      }

      const viewId = String(button.dataset.view || '').trim();
      if(!viewId) return;
      if(viewId !== store.getState().activeView) store.setState({ activeView: viewId });
    });
  };
})();
