(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.ui = TAIF.ui || {};
  const flow = TAIF.ui.flow || (TAIF.ui.flow = {});

  const FLOW_ITEM_SELECTOR = '[data-taif-flow-item="true"]';
  const FLOW_SKIP_SELECTOR = '[data-taif-flow-skip="true"], [data-taif-flow-item="false"]';
  const PICKER_TRIGGER_SELECTOR = '[data-taif-picker-trigger="true"]';
  const FOCUSABLE_SELECTOR = [
    'input:not([type="hidden"]):not([disabled])',
    'textarea:not([disabled])',
    'select:not([disabled])',
    'button:not([disabled])',
    '[tabindex]'
  ].join(', ');

  function isElement(value){
    return value instanceof Element;
  }

  function isHtmlElement(value){
    return value instanceof HTMLElement;
  }

  function isFlowSkipped(element){
    if(!isElement(element)) return false;
    return Boolean(element.closest(FLOW_SKIP_SELECTOR));
  }

  function isExplicitFlowItem(element){
    return isElement(element) && element.matches(FLOW_ITEM_SELECTOR);
  }

  function isPickerTrigger(element){
    return isElement(element) && element.matches(PICKER_TRIGGER_SELECTOR);
  }

  function isFocusableCandidate(element){
    if(!isHtmlElement(element)) return false;
    if(isFlowSkipped(element)) return false;
    if(element.matches('[disabled], [aria-disabled="true"]')) return false;
    if(element instanceof HTMLInputElement){
      if(element.type === 'hidden' || element.disabled || element.readOnly) return false;
    }
    if(element instanceof HTMLTextAreaElement && (element.disabled || element.readOnly)) return false;
    if(element instanceof HTMLSelectElement && element.disabled) return false;
    if(element instanceof HTMLButtonElement && element.disabled) return false;
    return true;
  }

  function rememberAndSetTabIndex(element, nextTabIndex){
    if(!isHtmlElement(element)) return;
    if(!element.dataset.taifFlowOriginalTabindex){
      element.dataset.taifFlowOriginalTabindex = element.hasAttribute('tabindex')
        ? String(element.getAttribute('tabindex'))
        : '__none__';
    }
    element.setAttribute('tabindex', String(nextTabIndex));
  }

  function applySkipTabIndex(root){
    if(!isElement(root)) return 0;
    const skippedContainers = Array.from(root.querySelectorAll('[data-taif-flow-skip="true"]'));
    if(root.matches && root.matches('[data-taif-flow-skip="true"]')) skippedContainers.unshift(root);

    const skippedTargets = new Set();
    skippedContainers.forEach((container) => {
      if(isHtmlElement(container) && container.matches(FOCUSABLE_SELECTOR)) skippedTargets.add(container);
      container.querySelectorAll?.(FOCUSABLE_SELECTOR).forEach((element) => {
        if(isHtmlElement(element)) skippedTargets.add(element);
      });
    });

    root.querySelectorAll?.('[data-taif-flow-item="false"]').forEach((element) => {
      if(isHtmlElement(element)) skippedTargets.add(element);
    });

    skippedTargets.forEach((element) => rememberAndSetTabIndex(element, -1));
    return skippedTargets.size;
  }

  function normalizeRoot(root){
    if(!isElement(root)) return { skipped:0 };
    return { skipped: applySkipTabIndex(root) };
  }

  function getContractSelectors(){
    return {
      item: FLOW_ITEM_SELECTOR,
      skip: FLOW_SKIP_SELECTOR,
      pickerTrigger: PICKER_TRIGGER_SELECTOR,
      focusable: FOCUSABLE_SELECTOR
    };
  }

  flow.itemSelector = FLOW_ITEM_SELECTOR;
  flow.skipSelector = FLOW_SKIP_SELECTOR;
  flow.pickerTriggerSelector = PICKER_TRIGGER_SELECTOR;
  flow.focusableSelector = FOCUSABLE_SELECTOR;
  flow.isSkipped = isFlowSkipped;
  flow.isExplicitFlowItem = isExplicitFlowItem;
  flow.isPickerTrigger = isPickerTrigger;
  flow.isFocusableCandidate = isFocusableCandidate;
  flow.normalizeRoot = normalizeRoot;
  flow.getContractSelectors = getContractSelectors;
})();
