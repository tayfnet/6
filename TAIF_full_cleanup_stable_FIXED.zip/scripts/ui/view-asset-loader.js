(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.ui = TAIF.ui || {};
  const { toText } = TAIF.core.utils;

  const stylePromises = new Map();
  const scriptPromises = new Map();
  let assetRequestSerial = 0;
  let latestAssetRequestSerial = 0;
  let latestRequestedViewId = '';
  const knownStyleNodes = new Map();
  const knownScriptNodes = new Map();
  const loadedStyleSources = new Set();
  const loadedScriptSources = new Set();


  function normalizeArray(value){
    if(!Array.isArray(value)) return [];
    const seen = new Set();
    const result = [];
    value.forEach((item) => {
      const safeItem = toText(item);
      if(!safeItem || seen.has(safeItem)) return;
      seen.add(safeItem);
      result.push(safeItem);
    });
    return result;
  }

  function rememberExistingAssets(){
    document.querySelectorAll('link[rel="stylesheet"][href]').forEach((node) => {
      if(!(node instanceof HTMLLinkElement)) return;
      const href = toText(node.getAttribute('href'));
      if(href) knownStyleNodes.set(href, node);
    });

    document.querySelectorAll('script[src]').forEach((node) => {
      if(!(node instanceof HTMLScriptElement)) return;
      const src = toText(node.getAttribute('src'));
      if(src) knownScriptNodes.set(src, node);
    });
  }

  rememberExistingAssets();

  function findExistingAssetNode(tagName, attrName, value){
    const safeValue = toText(value);
    if(!safeValue) return null;
    const selector = `${tagName}[${attrName}]`;
    const nodes = Array.from(document.querySelectorAll(selector));
    return nodes.find((node) => node instanceof Element && toText(node.getAttribute(attrName)) === safeValue) || null;
  }

  function rememberExistingStyle(href){
    const safeHref = toText(href);
    if(!safeHref) return null;
    const known = knownStyleNodes.get(safeHref);
    if(known instanceof HTMLLinkElement && known.isConnected) return known;
    const discovered = findExistingAssetNode('link', 'href', safeHref);
    if(discovered instanceof HTMLLinkElement){
      knownStyleNodes.set(safeHref, discovered);
      return discovered;
    }
    return null;
  }

  function rememberExistingScript(src){
    const safeSrc = toText(src);
    if(!safeSrc) return null;
    const known = knownScriptNodes.get(safeSrc);
    if(known instanceof HTMLScriptElement && known.isConnected) return known;
    const discovered = findExistingAssetNode('script', 'src', safeSrc);
    if(discovered instanceof HTMLScriptElement){
      knownScriptNodes.set(safeSrc, discovered);
      return discovered;
    }
    return null;
  }

  function markScriptSourceLoaded(src){
    const safeSrc = toText(src);
    if(!safeSrc) return;
    loadedScriptSources.add(safeSrc);
    const node = knownScriptNodes.get(safeSrc);
    if(node instanceof HTMLScriptElement){
      try{ node.dataset.taifScriptLoaded = 'true'; }catch{}
    }
  }

  function hasStaticScriptAlreadyRun(node){
    if(!(node instanceof HTMLScriptElement)) return false;
    if(node.dataset.taifManagedAsset === 'script') return false;
    if(document.readyState !== 'loading') return true;
    const currentScript = document.currentScript;
    if(!(currentScript instanceof HTMLScriptElement) || currentScript === node) return false;
    try{
      return Boolean(node.compareDocumentPosition(currentScript) & Node.DOCUMENT_POSITION_FOLLOWING);
    }catch{
      return false;
    }
  }

  function waitForExistingScriptNode(node, src){
    const safeSrc = toText(src || node?.getAttribute?.('src'));
    if(!(node instanceof HTMLScriptElement) || !safeSrc) return Promise.resolve(null);
    if(loadedScriptSources.has(safeSrc) || node.dataset.taifScriptLoaded === 'true'){
      markScriptSourceLoaded(safeSrc);
      return Promise.resolve(node);
    }

    /*
      Static deferred scripts can be discovered after this loader has already run.
      If the discovered script appears before the currently executing bootstrap script,
      it has already executed; resolving it prevents duplicate re-execution and keeps
      section runtime state stable.
    */
    if(hasStaticScriptAlreadyRun(node)){
      markScriptSourceLoaded(safeSrc);
      return Promise.resolve(node);
    }

    return new Promise((resolve, reject) => {
      let settled = false;
      const finish = (didError = false) => {
        if(settled) return;
        settled = true;
        try{ node.removeEventListener('load', handleLoad); }catch{}
        try{ node.removeEventListener('error', handleError); }catch{}
        if(didError){
          unloadScript(safeSrc);
          reject(new Error(`Failed to load script: ${safeSrc}`));
          return;
        }
        markScriptSourceLoaded(safeSrc);
        resolve(node);
      };
      const handleLoad = () => finish(false);
      const handleError = () => finish(true);
      try{ node.addEventListener('load', handleLoad, { once:true }); }catch{}
      try{ node.addEventListener('error', handleError, { once:true }); }catch{}
      if(node.dataset.taifScriptLoaded === 'true') finish(false);
    });
  }

  function isLatestAssetRequest(requestSerial, viewId){
    const safeViewId = toText(viewId);
    return !!safeViewId
      && requestSerial === latestAssetRequestSerial
      && safeViewId === latestRequestedViewId;
  }

  function resolveExistingAssetPromise(map, key, node){
    const existingPromise = Promise.resolve(node);
    map.set(key, existingPromise);
    return existingPromise;
  }

  function markStyleSourceLoaded(href){
    const safeHref = toText(href);
    if(!safeHref) return;
    loadedStyleSources.add(safeHref);
    const node = knownStyleNodes.get(safeHref);
    if(node instanceof HTMLLinkElement){
      try{ node.dataset.taifStyleLoaded = 'true'; }catch{}
    }
  }

  function isStyleNodeReady(node){
    if(!(node instanceof HTMLLinkElement)) return false;
    if(node.dataset.taifStyleLoaded === 'true') return true;
    try{
      if(node.sheet) return true;
    }catch{}
    return false;
  }

  function waitForStyleNode(node, href){
    if(!(node instanceof HTMLLinkElement)) return Promise.resolve(null);
    const safeHref = toText(href || node.getAttribute('href'));
    if(isStyleNodeReady(node)){
      markStyleSourceLoaded(safeHref);
      return Promise.resolve(node);
    }

    return new Promise((resolve, reject) => {
      let settled = false;
      const finish = (didError = false) => {
        if(settled) return;
        settled = true;
        try{ node.removeEventListener('load', handleLoad); }catch{}
        try{ node.removeEventListener('error', handleError); }catch{}
        try{ window.clearInterval(pollId); }catch{}
        if(didError){
          unloadStyle(safeHref);
          reject(new Error(`Failed to load stylesheet: ${safeHref}`));
          return;
        }
        markStyleSourceLoaded(safeHref);
        resolve(node);
      };
      const handleLoad = () => finish(false);
      const handleError = () => finish(true);
      const pollId = window.setInterval(() => {
        if(isStyleNodeReady(node)) finish(false);
      }, 16);
      try{ node.addEventListener('load', handleLoad, { once:true }); }catch{}
      try{ node.addEventListener('error', handleError, { once:true }); }catch{}
      if(isStyleNodeReady(node)) finish(false);
    });
  }

  function unloadStyle(href){
    const safeHref = toText(href);
    if(!safeHref) return;

    const node = knownStyleNodes.get(safeHref);
    if(node instanceof HTMLLinkElement && node.dataset.taifManagedAsset === 'style'){
      try{ node.remove(); }catch{}
    }

    knownStyleNodes.delete(safeHref);
    stylePromises.delete(safeHref);
    loadedStyleSources.delete(safeHref);
  }

  function unloadScript(src){
    const safeSrc = toText(src);
    if(!safeSrc) return;

    const node = knownScriptNodes.get(safeSrc);
    if(node instanceof HTMLScriptElement && node.dataset.taifManagedAsset === 'script' && !node.isConnected){
      try{ node.remove(); }catch{}
      knownScriptNodes.delete(safeSrc);
      scriptPromises.delete(safeSrc);
      loadedScriptSources.delete(safeSrc);
      return;
    }

    if(!(node instanceof HTMLScriptElement)){
      knownScriptNodes.delete(safeSrc);
      scriptPromises.delete(safeSrc);
      loadedScriptSources.delete(safeSrc);
    }
  }

  function sweepDetachedAssetRefs(){
    Array.from(knownStyleNodes.entries()).forEach(([href, node]) => {
      if(node instanceof HTMLLinkElement && node.isConnected) return;
      knownStyleNodes.delete(href);
      stylePromises.delete(href);
      loadedStyleSources.delete(href);
    });

    Array.from(knownScriptNodes.entries()).forEach(([src, node]) => {
      if(node instanceof HTMLScriptElement && node.isConnected) return;
      knownScriptNodes.delete(src);
      scriptPromises.delete(src);
      loadedScriptSources.delete(src);
    });
  }

  function unloadInactiveManagedStyles(activeHrefs = []){
    const activeSet = new Set(normalizeArray(activeHrefs));
    Array.from(knownStyleNodes.entries()).forEach(([href, node]) => {
      if(!(node instanceof HTMLLinkElement)){
        unloadStyle(href);
        return;
      }
      if(node.dataset.taifStaticAsset === 'style') return;
      if(node.dataset.taifManagedAsset !== 'style') return;
      if(activeSet.has(href)) return;
      unloadStyle(href);
    });
  }

  function unloadInactiveManagedScripts(activeSrcs = []){
    const activeSet = new Set(normalizeArray(activeSrcs));
    Array.from(knownScriptNodes.entries()).forEach(([src, node]) => {
      if(!(node instanceof HTMLScriptElement)){
        unloadScript(src);
        return;
      }
      if(node.dataset.taifManagedAsset !== 'script') return;
      if(node.isConnected) return;
      if(activeSet.has(src)) return;
      unloadScript(src);
    });
  }

  function loadStyle(href){
    const safeHref = toText(href);
    if(!safeHref) return Promise.resolve();
    if(stylePromises.has(safeHref)) return stylePromises.get(safeHref);

    if(loadedStyleSources.has(safeHref)){
      const existingNode = knownStyleNodes.get(safeHref);
      return resolveExistingAssetPromise(stylePromises, safeHref, existingNode instanceof HTMLLinkElement ? existingNode : null);
    }

    const existing = rememberExistingStyle(safeHref);
    if(existing instanceof HTMLLinkElement && existing.isConnected){
      const existingPromise = waitForStyleNode(existing, safeHref);
      stylePromises.set(safeHref, existingPromise);
      return existingPromise;
    }

    const promise = new Promise((resolve, reject) => {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = safeHref;
      link.dataset.taifManagedAsset = 'style';
      link.addEventListener('load', () => {
        markStyleSourceLoaded(safeHref);
        resolve(link);
      }, { once:true });
      link.addEventListener('error', () => {
        unloadStyle(safeHref);
        reject(new Error(`Failed to load stylesheet: ${safeHref}`));
      }, { once:true });
      document.head.appendChild(link);
      knownStyleNodes.set(safeHref, link);
    });

    stylePromises.set(safeHref, promise);
    return promise;
  }

  function reorderManagedStyles(hrefs){
    const orderedHrefs = normalizeArray(hrefs);
    if(!orderedHrefs.length) return;

    orderedHrefs.forEach((href) => {
      const node = knownStyleNodes.get(href);
      if(!(node instanceof HTMLLinkElement) || !node.isConnected) return;
      if(node.parentNode !== document.head) return;
      if(node.dataset.taifStaticAsset === 'style') return;
      document.head.appendChild(node);
    });
  }

  function loadScript(src){
    const safeSrc = toText(src);
    if(!safeSrc) return Promise.resolve();
    if(scriptPromises.has(safeSrc)) return scriptPromises.get(safeSrc);

    if(loadedScriptSources.has(safeSrc)){
      const existingNode = knownScriptNodes.get(safeSrc);
      return resolveExistingAssetPromise(scriptPromises, safeSrc, existingNode instanceof HTMLScriptElement ? existingNode : null);
    }

    const existing = rememberExistingScript(safeSrc);
    if(existing instanceof HTMLScriptElement && existing.isConnected){
      const existingPromise = waitForExistingScriptNode(existing, safeSrc);
      scriptPromises.set(safeSrc, existingPromise);
      return existingPromise;
    }

    const promise = new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = safeSrc;
      script.defer = true;
      script.async = false;
      script.dataset.taifManagedAsset = 'script';
      script.addEventListener('load', () => {
        markScriptSourceLoaded(safeSrc);
        resolve(script);
      }, { once:true });
      script.addEventListener('error', () => {
        unloadScript(safeSrc);
        reject(new Error(`Failed to load script: ${safeSrc}`));
      }, { once:true });
      document.body.appendChild(script);
      knownScriptNodes.set(safeSrc, script);
    });

    scriptPromises.set(safeSrc, promise);
    return promise;
  }

  async function loadSequentialScripts(scripts){
    for(const src of normalizeArray(scripts)){
      await loadScript(src);
    }
  }

  async function ensureBundleAssets(viewId, { requestSerial = 0 } = {}){
    sweepDetachedAssetRefs();
    const config = TAIF.config && TAIF.config.viewAssets ? TAIF.config.viewAssets : null;
    const bundle = config ? config[toText(viewId)] : null;
    if(!bundle || typeof bundle !== 'object'){
      if(isLatestAssetRequest(requestSerial, viewId)){
        unloadInactiveManagedStyles([]);
        unloadInactiveManagedScripts([]);
      }
      return null;
    }

    const styles = normalizeArray(bundle.styles);
    const scripts = normalizeArray(bundle.scripts);

    if(styles.length){
      await Promise.all(styles.map((href) => loadStyle(href)));
      if(isLatestAssetRequest(requestSerial, viewId)) reorderManagedStyles(styles);
    }
    if(isLatestAssetRequest(requestSerial, viewId)){
      unloadInactiveManagedStyles(styles);
    }

    if(scripts.length){
      await loadSequentialScripts(scripts);
    }
    if(isLatestAssetRequest(requestSerial, viewId)){
      unloadInactiveManagedScripts(scripts);
    }

    return bundle;
  }

  TAIF.ui.ensureViewAssets = async function(viewId){
    const safeViewId = toText(viewId);
    if(!safeViewId) return null;

    const requestSerial = ++assetRequestSerial;
    latestAssetRequestSerial = requestSerial;
    latestRequestedViewId = safeViewId;

    return ensureBundleAssets(safeViewId, { requestSerial });
  };
})();
