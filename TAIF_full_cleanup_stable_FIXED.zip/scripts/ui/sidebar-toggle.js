(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.ui = TAIF.ui || {};
  TAIF.ui.shell = TAIF.ui.shell || {};

  let busyTimerId = 0;

  TAIF.ui.shell.bindToggle = function(root, button, store){
    if(!(root instanceof HTMLElement) || !(button instanceof HTMLElement) || !store || typeof store.getState !== 'function' || typeof store.setState !== 'function') return;

    button.addEventListener('click', () => {
      if(root.classList.contains('taif-busy')) return;
      root.classList.add('taif-busy');
      if(busyTimerId){
        window.clearTimeout(busyTimerId);
        busyTimerId = 0;
      }
      store.setState({ sidebarCollapsed: !store.getState().sidebarCollapsed });
      busyTimerId = window.setTimeout(() => {
        root.classList.remove('taif-busy');
        busyTimerId = 0;
      }, 320);
    });
  };
})();
