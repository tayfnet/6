(()=>{
  const TAIF = window.TAIF;

  TAIF.ui.nav.render = function(navElement, views){
    if(!(navElement instanceof HTMLElement)) return;

    const safeViews = (Array.isArray(views) ? views : [])
      .filter((view) => view && typeof view === 'object' && String(view.id || '').trim())
      .filter((view) => view.navVisible !== false && view.routeEnabled !== false)
      .filter((view) => !['hidden', 'deprecated', 'deferred'].includes(String(view.status || '').trim()));
    const extraAction = typeof TAIF?.ui?.factoryReset?.getMeta === 'function'
      ? TAIF.ui.factoryReset.getMeta()
      : null;
    const renderQueue = extraAction ? [...safeViews, extraAction] : safeViews;
    const fragment = document.createDocumentFragment();

    renderQueue.forEach((view) => {
      const button = document.createElement('button');
      const classNames = ['navbtn'];
      if(typeof view.className === 'string' && view.className.trim()) classNames.push(view.className.trim());
      button.className = classNames.join(' ');
      button.type = 'button';
      if(view.isAction) button.dataset.action = String(view.action || view.id).trim();
      else button.dataset.view = String(view.id).trim();
      button.setAttribute('aria-label', String(view.label || view.id).trim());
      button.setAttribute('title', String(view.label || view.id).trim());

      const iconWrap = document.createElement('span');
      iconWrap.className = 'nav-ico';
      iconWrap.setAttribute('aria-hidden', 'true');

      const img = document.createElement('img');
      img.className = 'nav-img';
      img.src = String(view.icon || '').trim();
      img.alt = '';
      img.draggable = false;
      iconWrap.appendChild(img);

      const textWrap = document.createElement('span');
      textWrap.className = 'nav-txt';
      textWrap.textContent = String(view.label || view.id).trim();

      button.append(iconWrap, textWrap);
      fragment.appendChild(button);
    });

    navElement.replaceChildren(fragment);
  };
})();
