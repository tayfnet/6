(()=>{
  /*
   * TAIF shared question dialog primitive.
   * This is the single compact confirmation window used by destructive flows.
   * It must stay independent from feature-specific window, button, or modal classes.
   */
  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.ui = TAIF.ui || {};

  const utils = TAIF.core && TAIF.core.utils ? TAIF.core.utils : {};
  const windowChrome = TAIF.ui.windowChrome || {};
  const windowSystem = TAIF.ui.windowSystem || {};
  const buttonSystem = TAIF.ui.buttonSystem || {};

  const escapeHtml = typeof utils.escapeHtml === 'function'
    ? utils.escapeHtml
    : (value) => String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');

  const focusElement = typeof windowChrome.focusElement === 'function'
    ? windowChrome.focusElement.bind(windowChrome)
    : ((element) => {
        if(!(element instanceof HTMLElement)) return false;
        try{ element.focus({ preventScroll:true }); }
        catch{ try{ element.focus(); }catch{} }
        return document.activeElement === element;
      });

  const bindFormNavigation = typeof windowChrome.bindFormNavigation === 'function'
    ? windowChrome.bindFormNavigation.bind(windowChrome)
    : (() => () => {});

  function toText(value, fallback = ''){
    const text = String(value ?? '').trim();
    return text || fallback;
  }

  function sanitizeClassName(value){
    return String(value || '')
      .split(/\s+/)
      .map((item) => item.trim())
      .filter((item) => /^[-_a-zA-Z0-9:]+$/.test(item))
      .join(' ');
  }

  function getIconMarkup(type){
    if(type === 'close' && typeof windowChrome.getIconMarkup === 'function') return windowChrome.getIconMarkup('close');
    if(type === 'expand' && typeof windowChrome.getIconMarkup === 'function') return windowChrome.getIconMarkup('expand');
    if(type === 'collapse' && typeof windowChrome.getIconMarkup === 'function') return windowChrome.getIconMarkup('collapse');
    if(type === 'trash'){
      return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M3 6h18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path><path d="M8 6V4h8v2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="m19 6-.85 13.6A2 2 0 0 1 16.15 21h-8.3a2 2 0 0 1-2-1.4L5 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M10 11v5M14 11v5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path></svg>';
    }
    return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m5 12 4 4L19 6" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
  }

  function normalizeTone(tone){
    const safeTone = String(tone || '').trim().toLowerCase();
    if(safeTone === 'success') return 'success';
    if(safeTone === 'primary') return 'primary';
    if(safeTone === 'dark') return 'dark';
    return 'danger';
  }


  function createCardMarkup({ title = '', subtitle = '', meta = [], avatarHtml = '', tone = 'primary', className = '' } = {}){
    const safeTitle = toText(title, 'العنصر المحدد');
    const safeSubtitle = toText(subtitle, '');
    const safeTone = normalizeTone(tone === 'danger' ? 'danger' : 'primary');
    const safeClass = sanitizeClassName(className);
    const metaItems = Array.isArray(meta) ? meta : [];
    const metaMarkup = metaItems
      .map((item) => toText(item))
      .filter(Boolean)
      .slice(0, 4)
      .map((item) => `<span class="taif-question-dialog__card-badge"><span class="taif-control-text">${escapeHtml(item)}</span></span>`)
      .join('');
    const avatar = toText(avatarHtml)
      ? `<span class="taif-question-dialog__card-avatar taif-question-dialog__card-avatar--${escapeHtml(safeTone)}" aria-hidden="true">${avatarHtml}</span>`
      : `<span class="taif-question-dialog__card-avatar taif-question-dialog__card-avatar--${escapeHtml(safeTone)}" aria-hidden="true">${getIconMarkup(safeTone === 'danger' ? 'trash' : 'check')}</span>`;

    return `
      <div class="taif-question-dialog__card${safeClass ? ` ${safeClass}` : ''}" data-taif-question-card="true">
        ${avatar}
        <div class="taif-question-dialog__card-text">
          <strong>${escapeHtml(safeTitle)}</strong>
          ${safeSubtitle ? `<span>${escapeHtml(safeSubtitle)}</span>` : ''}
        </div>
        ${metaMarkup ? `<div class="taif-question-dialog__card-meta">${metaMarkup}</div>` : ''}
      </div>
    `;
  }

  function createActionButton({ action, label, tone = '', icon = '', role = '' } = {}){
    const safeAction = toText(action, 'cancel');
    const safeLabel = toText(label, safeAction === 'confirm' ? 'تأكيد' : 'إلغاء');
    const safeTone = normalizeTone(tone);
    const toneClass = safeAction === 'cancel' && !tone
      ? ''
      : ` taif-question-dialog__action-btn--${safeTone}`;
    const safeRole = toText(role, safeAction === 'confirm' ? 'commit' : 'cancel');
    const safeIcon = toText(icon, safeAction === 'confirm' ? 'trash' : 'close');
    const actionTone = safeRole === 'commit' ? ` data-taif-action-tone="${escapeHtml(safeTone)}"` : '';
    return `
      <button class="taif-question-dialog__action-btn taif-question-dialog__action-btn--${escapeHtml(safeAction)}${toneClass}" type="button" data-taif-question-action="${escapeHtml(safeAction)}" data-taif-action-role="${escapeHtml(safeRole)}"${actionTone}>
        <span class="taif-question-dialog__action-icon" aria-hidden="true">${getIconMarkup(safeIcon)}</span>
        <span class="taif-control-text">${escapeHtml(safeLabel)}</span>
      </button>
    `;
  }

  function openQuestionDialog(options = {}){
    const title = toText(options.title, 'تأكيد');
    const owner = toText(options.owner, 'shared');
    const titleId = `taif-question-title-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const descId = `taif-question-description-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const cardHtml = toText(options.cardHtml, '');
    const message = toText(options.message, '');
    const warning = toText(options.warning, '');
    const confirmTone = normalizeTone(options.confirmTone || 'danger');
    const confirmLabel = toText(options.confirmLabel, 'تأكيد');
    const cancelLabel = toText(options.cancelLabel, 'إلغاء');
    const confirmIcon = toText(options.confirmIcon, confirmTone === 'danger' ? 'trash' : 'check');
    const focusConfirm = options.focusConfirm !== false;
    const restoreFocusTarget = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const extraClass = sanitizeClassName(options.className);
    const extraBodyClass = sanitizeClassName(options.bodyClass);

    const backdrop = document.createElement('div');
    backdrop.className = 'taif-question-backdrop';
    backdrop.dataset.taifQuestionOwner = owner;
    backdrop.innerHTML = `
      <div class="taif-question-dialog taif-question-dialog--size-sm taif-question-dialog--variant-grand is-positioned${extraClass ? ` ${extraClass}` : ''}" role="alertdialog" aria-modal="false" aria-labelledby="${escapeHtml(titleId)}" aria-describedby="${escapeHtml(descId)}" data-modal-size="sm" data-modal-variant="question" tabindex="-1">
        <div class="taif-question-dialog__head">
          <div class="taif-question-dialog__heading">
            <h3 class="taif-question-dialog__title" id="${escapeHtml(titleId)}" data-taif-detail-title="true">${escapeHtml(title)}</h3>
          </div>
          <div class="taif-question-dialog__window-actions" data-taif-window-actions="true">
            <button class="taif-question-dialog__chrome-btn taif-question-dialog__expand" type="button" data-taif-question-action="expand" aria-label="تكبير النافذة" title="تكبير النافذة">${getIconMarkup('expand')}</button>
            <button class="taif-question-dialog__chrome-btn taif-question-dialog__close" type="button" data-taif-question-action="cancel" aria-label="إغلاق" title="إغلاق">${getIconMarkup('close')}</button>
          </div>
        </div>
        <div class="taif-question-dialog__body${extraBodyClass ? ` ${extraBodyClass}` : ''}">
          <div class="taif-question-dialog__box">
            ${cardHtml}
            ${message ? `<div class="taif-question-dialog__message" id="${escapeHtml(descId)}">${escapeHtml(message)}</div>` : `<span hidden id="${escapeHtml(descId)}"></span>`}
            ${warning ? `<div class="taif-question-dialog__warning">${escapeHtml(warning)}</div>` : ''}
            <div class="taif-question-dialog__actions" data-taif-footer-actions="true">
              ${createActionButton({ action:'cancel', label:cancelLabel, icon:'close', role:'cancel' })}
              ${createActionButton({ action:'confirm', label:confirmLabel, tone:confirmTone, icon:confirmIcon, role:'commit' })}
            </div>
          </div>
        </div>
      </div>
    `;

    const dialog = backdrop.querySelector('.taif-question-dialog');
    const confirmButton = backdrop.querySelector('[data-taif-question-action="confirm"]');
    const cancelButtons = Array.from(backdrop.querySelectorAll('[data-taif-question-action="cancel"]'));
    const expandButton = backdrop.querySelector('[data-taif-question-action="expand"]');
    let isClosed = false;
    let restoreFocusOnClose = true;
    let formNavigationCleanup = null;

    function cleanupRuntimeBindings(){
      document.removeEventListener('keydown', handleKeydown, true);
      if(typeof formNavigationCleanup === 'function'){
        try{ formNavigationCleanup(); }catch{}
        formNavigationCleanup = null;
      }
    }

    function syncExpandButton(){
      if(!(expandButton instanceof HTMLElement) || !(dialog instanceof HTMLElement)) return;
      const isMaximized = dialog.classList.contains('is-maximized');
      if(typeof windowChrome.syncExpandButton === 'function'){
        windowChrome.syncExpandButton(expandButton, isMaximized);
        return;
      }
      expandButton.innerHTML = getIconMarkup(isMaximized ? 'collapse' : 'expand');
      expandButton.setAttribute('aria-label', isMaximized ? 'استعادة الحجم المرجعي' : 'تكبير النافذة');
      expandButton.setAttribute('title', isMaximized ? 'استعادة الحجم المرجعي' : 'تكبير النافذة');
      expandButton.setAttribute('aria-pressed', isMaximized ? 'true' : 'false');
    }

    function close(restoreFocus = true){
      if(isClosed) return;
      isClosed = true;
      restoreFocusOnClose = !!restoreFocus;
      cleanupRuntimeBindings();
      try{ backdrop.__cleanup = null; }catch{}
      backdrop.classList.add('is-closing');
      window.setTimeout(() => {
        backdrop.remove();
        if(typeof options.onClose === 'function'){
          try{ options.onClose(); }catch(error){ console.error(error); }
        }
        if(restoreFocusOnClose && restoreFocusTarget instanceof HTMLElement && restoreFocusTarget.isConnected){
          window.requestAnimationFrame(() => focusElement(restoreFocusTarget));
        }
      }, 110);
    }

    function cancel(event){
      if(event){
        event.preventDefault();
        event.stopPropagation();
      }
      if(typeof options.onCancel === 'function'){
        try{ options.onCancel(); }catch(error){ console.error(error); }
      }
      close(true);
    }

    function confirm(event){
      if(event){
        event.preventDefault();
        event.stopPropagation();
      }
      let shouldClose = options.closeOnConfirm !== false;
      if(typeof options.onConfirm === 'function'){
        try{
          const result = options.onConfirm({ close, backdrop, dialog, confirmButton });
          if(result === false) shouldClose = false;
        }catch(error){
          console.error(error);
          shouldClose = false;
        }
      }
      if(shouldClose) close(false);
    }

    function toggleExpand(event){
      if(event){
        event.preventDefault();
        event.stopPropagation();
      }
      if(!(dialog instanceof HTMLElement)) return;
      dialog.classList.toggle('is-maximized');
      syncExpandButton();
    }

    function handleKeydown(event){
      if(event.key === 'Escape'){
        event.preventDefault();
        event.stopPropagation();
        cancel(event);
        return;
      }
      if(event.key === 'F11' || (event.altKey && event.key === 'Enter')){
        toggleExpand(event);
      }
    }

    backdrop.__cleanup = () => {
      if(isClosed) return;
      isClosed = true;
      cleanupRuntimeBindings();
      try{ backdrop.__cleanup = null; }catch{}
      if(typeof options.onClose === 'function'){
        try{ options.onClose(); }catch(error){ console.error(error); }
      }
    };

    if(typeof utils.markOwnedNode === 'function'){
      try{ utils.markOwnedNode(backdrop, owner); }catch{}
    }

    cancelButtons.forEach((button) => button.addEventListener('click', cancel));
    confirmButton?.addEventListener('click', confirm);
    expandButton?.addEventListener('click', toggleExpand);
    document.addEventListener('keydown', handleKeydown, true);
    document.body.appendChild(backdrop);
    if(typeof windowSystem.registerWindow === 'function'){
      try{
        windowSystem.registerWindow({
          backdrop,
          modal:dialog,
          ownerView:owner,
          source:'question-dialog',
          size:'sm'
        });
      }catch{}
    }
    syncExpandButton();
    if(typeof buttonSystem.normalizeRoot === 'function'){
      try{ buttonSystem.normalizeRoot(backdrop, { ownerView:owner, source:'question-dialog' }); }catch{}
    }

    if(dialog instanceof HTMLElement){
      formNavigationCleanup = bindFormNavigation({ root:dialog, autoFocus:false });
      window.requestAnimationFrame(() => {
        if(focusConfirm && confirmButton instanceof HTMLElement){
          focusElement(confirmButton);
          return;
        }
        focusElement(dialog);
      });
    }

    return Object.freeze({
      backdrop,
      dialog,
      close,
      focusConfirm: () => confirmButton instanceof HTMLElement && focusElement(confirmButton)
    });
  }

  TAIF.ui.questionDialog = Object.freeze({
    open: openQuestionDialog,
    createCardMarkup,
    getIconMarkup
  });
})();
