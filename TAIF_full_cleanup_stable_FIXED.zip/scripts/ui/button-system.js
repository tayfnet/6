(()=>{

  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.ui = TAIF.ui || {};
  TAIF.core = TAIF.core || {};
  TAIF.core.utils = TAIF.core.utils || {};

  const utils = TAIF.core.utils;
  const VARIANTS = Object.freeze(['primary','secondary','success','danger','ghost','window','toolbar','icon']);

  const SELECTORS = Object.freeze({
    buttons: [
      'button','[role="button"]','input[type="button"]','input[type="submit"]','input[type="reset"]',
      '.taif-btn','.currency-management-btn','.coa-btn','.entries-action-btn','.entries-toolbar-btn',
      '.sales-purchase-action-btn','.sales-purchase-toolbar__btn','.sales-purchase-records__action',
      '.customer-card-action-btn','.customer-card-toolbar-btn','.cash-boxes-btn','.cash-boxes-modal__action',
      '.general-ledger-btn','.taif-question-dialog__action-btn','.taif-question-dialog__chrome-btn'
    ].join(', '),
    actionGroups: [
      '[data-taif-window-actions="true"]','[data-taif-footer-actions="true"]','[data-taif-button-group="true"]',
      '.taif-question-dialog__actions','.taif-question-dialog__window-actions','.currency-management-modal-actions',
      '.entries-sheet__footer','.sales-purchase-sheet__footer','.coa-modal__footer',
      '.customer-card-toolbar','.entries-toolbar','.sales-purchase-toolbar'
    ].join(', ')
  });

  const LEGACY_HINTS = Object.freeze([
    'currency-management-btn','coa-btn','entries-action-btn','entries-toolbar-btn','sales-purchase-action-btn',
    'sales-purchase-toolbar__btn','sales-purchase-records__action','customer-card-action-btn','customer-card-toolbar-btn',
    'cash-boxes-btn','cash-boxes-modal__action','general-ledger-btn','taif-question-dialog__action-btn','taif-question-dialog__chrome-btn'
  ]);

  function toText(value, fallback = ''){ const text = String(value ?? '').trim(); return text || fallback; }
  function isHTMLElement(node){ return node instanceof HTMLElement; }
  function normalizeToken(value, fallback = ''){ return toText(value, fallback).toLowerCase().replace(/\s+/g, '-'); }
  function classText(button){ return String(button?.className || '').toLowerCase(); }
  function hasLegacyHint(button){
    if(!isHTMLElement(button)) return false;
    const className = String(button.className || '');
    return LEGACY_HINTS.some((hint) => className.includes(hint));
  }
  function isIconOnly(button){
    if(!isHTMLElement(button)) return false;
    const className = classText(button);
    if(/chrome|icon|window-actions|expand|close/.test(className)) return true;
    const text = toText(button.textContent || '');
    const aria = toText(button.getAttribute('aria-label') || button.getAttribute('title') || '');
    return !text && !!aria;
  }

  function inferRole(button){
    if(!isHTMLElement(button)) return '';
    const explicit = normalizeToken(button.dataset.taifButtonRole || button.dataset.taifActionRole || button.getAttribute('data-taif-action-role') || '');
    if(explicit) return explicit;
    const action = normalizeToken(button.dataset.taifQuestionAction || button.getAttribute('data-taif-question-action') || '');
    if(action === 'confirm') return 'commit';
    if(action === 'cancel' || action === 'close') return 'cancel';
    const haystack = `${classText(button)} ${normalizeToken(button.textContent || button.getAttribute('aria-label') || button.getAttribute('title') || '')}`;
    if(/delete|remove|trash|danger|حذف/.test(haystack)) return 'destructive';
    if(/save|add|create|confirm|submit|execute|حفظ|اضافة|إضافة|تنفيذ|تأكيد/.test(haystack)) return 'commit';
    if(/cancel|close|back|إلغاء|اغلاق|إغلاق/.test(haystack)) return 'cancel';
    return '';
  }

  function inferVariant(button){
    if(!isHTMLElement(button)) return 'secondary';
    const explicit = normalizeToken(button.dataset.taifButtonVariant || button.getAttribute('data-taif-button-variant') || '');
    if(VARIANTS.includes(explicit)) return explicit;
    const tone = normalizeToken(button.dataset.taifActionTone || button.getAttribute('data-taif-action-tone') || '');
    if(['danger','success','primary','secondary','ghost','dark'].includes(tone)) return tone === 'dark' ? 'primary' : tone;
    const role = inferRole(button);
    const haystack = `${classText(button)} ${normalizeToken(button.textContent || button.getAttribute('aria-label') || button.getAttribute('title') || '')} ${role}`;
    if(/danger|delete|remove|trash|destructive|حذف/.test(haystack)) return 'danger';
    if(/success|save|add|create|confirm|commit|execute|حفظ|اضافة|إضافة|تنفيذ|تأكيد/.test(haystack)) return 'primary';
    if(/ghost|close|chrome|window-actions|expand|collapse|اغلاق|إغلاق/.test(haystack)) return 'ghost';
    return 'secondary';
  }

  function inferOwner(button, ownerView = ''){
    const explicit = normalizeToken(ownerView || button?.dataset?.ownerView || button?.getAttribute?.('data-owner-view') || '');
    if(explicit) return explicit;
    const ownedParent = isHTMLElement(button) ? button.closest('[data-owner-view]') : null;
    if(ownedParent instanceof HTMLElement){
      const owner = normalizeToken(ownedParent.dataset.ownerView || ownedParent.getAttribute('data-owner-view') || '');
      if(owner) return owner;
    }
    if(typeof utils.getActiveView === 'function'){
      const active = normalizeToken(utils.getActiveView());
      if(active) return active;
    }
    const htmlView = normalizeToken(document.documentElement?.dataset?.activeView || '');
    if(htmlView) return htmlView;
    const panel = document.getElementById('panel');
    if(panel instanceof HTMLElement) return normalizeToken(panel.dataset.renderedView || panel.dataset.view || '');
    return '';
  }

  function normalizeButton(button, { ownerView = '', source = 'button-system' } = {}){
    if(!isHTMLElement(button)) return null;
    if(button.matches('[data-taif-button-skip="true"]')) return button;

    const owner = inferOwner(button, ownerView);
    const wasLegacy = hasLegacyHint(button) && !button.classList.contains('taif-btn');
    const variant = inferVariant(button);
    const role = inferRole(button);
    const icon = isIconOnly(button);
    const inWindowActions = !!button.closest('[data-taif-window-actions="true"], .taif-question-dialog__window-actions, .entries-sheet__window-actions, .sales-purchase-sheet__window-actions, .coa-window-actions, .taif-currency-management-modal__window-actions');
    const inToolbar = !!button.closest('.entries-toolbar, .sales-purchase-toolbar, .customer-card-toolbar, [data-taif-toolbar="true"]');

    button.dataset.taifButton = 'true';
    button.dataset.taifButtonSource = source;
    button.dataset.taifButtonVariant = variant;
    if(owner) button.dataset.taifButtonOwner = owner;
    if(role) button.dataset.taifButtonRole = role;
    if(wasLegacy) button.dataset.taifButtonAdapter = 'legacy';
    if(icon) button.dataset.taifButtonIcon = 'true';
    if(inWindowActions) button.dataset.taifButtonWindow = 'true';
    if(inToolbar) button.dataset.taifButtonToolbar = 'true';

    button.classList.add('taif-btn');
    button.classList.add(`taif-btn--${variant}`);
    if(icon) button.classList.add('taif-btn--icon');
    if(inWindowActions) button.classList.add('taif-btn--window');
    if(inToolbar) button.classList.add('taif-btn--toolbar');

    if(button instanceof HTMLButtonElement && !button.getAttribute('type')){
      button.setAttribute('type', 'button');
    }

    return button;
  }

  function normalizeGroups(root, ownerView = ''){
    if(!(root instanceof Document || root instanceof Element)) return 0;
    let count = 0;
    root.querySelectorAll?.(SELECTORS.actionGroups).forEach((group) => {
      if(!(group instanceof HTMLElement)) return;
      group.dataset.taifButtonGroup = 'true';
      const owner = inferOwner(group, ownerView);
      if(owner) group.dataset.taifButtonOwner = owner;
      count += 1;
    });
    return count;
  }

  function normalizeRoot(root = document, { ownerView = '', source = 'button-system' } = {}){
    const target = (root instanceof Document || root instanceof Element) ? root : document;
    const result = { groups:0, buttons:0 };
    result.groups = normalizeGroups(target, ownerView);
    target.querySelectorAll?.(SELECTORS.buttons).forEach((button) => {
      if(!(button instanceof HTMLElement)) return;
      normalizeButton(button, { ownerView, source });
      result.buttons += 1;
    });
    return result;
  }

  let observer = null;
  let pending = new Set();
  let scheduled = false;

  function flushPending(){
    scheduled = false;
    const nodes = Array.from(pending);
    pending.clear();
    nodes.forEach((node) => {
      if(!isHTMLElement(node) || !node.isConnected) return;
      try{ normalizeRoot(node, { source:'button-system-mutation' }); }catch{}
      if(node.matches?.(SELECTORS.buttons)){
        try{ normalizeButton(node, { source:'button-system-mutation' }); }catch{}
      }
    });
  }

  function scheduleNode(node){
    if(!isHTMLElement(node)) return;
    pending.add(node);
    if(!scheduled){
      scheduled = true;
      window.requestAnimationFrame(flushPending);
    }
  }

  function startObserver(){
    if(observer || typeof MutationObserver !== 'function' || !document.body) return;
    observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if(node instanceof HTMLElement) scheduleNode(node);
        });
      });
    });
    observer.observe(document.body, { childList:true, subtree:true });
  }

  function getContractSelectors(){ return SELECTORS; }

  TAIF.ui.buttonSystem = Object.freeze({
    variants: VARIANTS,
    selectors: SELECTORS,
    normalizeButton,
    normalizeRoot,
    getContractSelectors,
    startObserver
  });

  function normalizeDocumentSoon(){
    window.requestAnimationFrame(() => {
      try{ normalizeRoot(document, { source:'initial-document-scan' }); }catch{}
      startObserver();
    });
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', normalizeDocumentSoon, { once:true });
  }else{
    normalizeDocumentSoon();
  }
})();
