(()=>{

  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.ui = TAIF.ui || {};
  TAIF.core = TAIF.core || {};
  TAIF.core.utils = TAIF.core.utils || {};

  const utils = TAIF.core.utils;

  const SIZE_TOKENS = Object.freeze(['sm', 'md', 'lg', 'workspace']);

  const SELECTORS = Object.freeze({
    layers: [
      '.taif-window-layer',
      '.taif-currency-management-window-layer',
      '.coa-window-layer',
      '.entries-window-layer',
      '.sales-purchase-window-layer',
      '.cash-boxes-window-layer'
    ].join(', '),
    backdrops: [
      '.taif-window-backdrop',
      '.taif-currency-management-modal-backdrop',
      '.coa-modal-backdrop',
      '.entries-modal-backdrop',
      '.sales-purchase-modal-backdrop',
      '.cash-boxes-modal-backdrop',
      '.taif-question-backdrop'
    ].join(', '),
    windows: [
      '.taif-window',
      '.taif-currency-management-modal',
      '.coa-modal',
      '.entries-modal-window',
      '.sales-purchase-modal-window',
      '.cash-boxes-modal-window',
      '.taif-question-dialog'
    ].join(', '),
    heads: [
      '.taif-window__head',
      '.taif-currency-management-modal__head',
      '.coa-modal__head',
      '.entries-sheet__head',
      '.sales-purchase-sheet__head',
      '.cash-boxes-modal__head',
      '.taif-question-dialog__head'
    ].join(', '),
    bodies: [
      '.taif-window__body',
      '.taif-currency-management-modal__body',
      '.coa-modal__body',
      '.entries-sheet__body',
      '.sales-purchase-sheet__body',
      '.cash-boxes-modal__body',
      '.taif-question-dialog__body'
    ].join(', '),
    footers: [
      '.taif-window__footer',
      '.taif-currency-management-modal__footer',
      '.coa-modal__footer',
      '.entries-sheet__footer',
      '.sales-purchase-sheet__footer',
      '.cash-boxes-modal__footer',
      '.taif-question-dialog__actions',
      '[data-taif-footer-actions="true"]'
    ].join(', '),
    actions: [
      '[data-taif-window-actions="true"]',
      '.taif-window__actions',
      '.taif-currency-management-modal__window-actions',
      '.coa-window-actions',
      '.entries-sheet__window-actions',
      '.sales-purchase-sheet__window-actions',
      '.taif-question-dialog__window-actions'
    ].join(', ')
  });

  const OWNER_CLASS_HINTS = Object.freeze([
    ['taif-currency-management', 'currency-management'],
    ['currency-management', 'currency-management'],
    ['coa-', 'chart-of-accounts'],
    ['chart-of-accounts', 'chart-of-accounts'],
    ['entries-', 'entries-vouchers'],
    ['sales-purchase-', 'sales-purchase-invoice'],
    ['cash-boxes-', 'cash-boxes'],
    ['customer-card-', 'customer-card'],
    ['general-ledger-', 'general-ledger'],
    ['taif-question-', 'shared-question-dialog']
  ]);

  function toText(value, fallback = ''){
    const text = String(value ?? '').trim();
    return text || fallback;
  }

  function normalizeToken(value, fallback = ''){
    return toText(value, fallback).replace(/\s+/g, '-');
  }

  function isHTMLElement(node){
    return node instanceof HTMLElement;
  }

  function inferOwnerFromClassName(node){
    if(!isHTMLElement(node)) return '';
    const className = String(node.className || '');
    for(const [hint, owner] of OWNER_CLASS_HINTS){
      if(className.includes(hint)) return owner;
    }
    return '';
  }

  function getActiveOwnerFallback(){
    if(typeof utils.getActiveView === 'function'){
      const active = normalizeToken(utils.getActiveView());
      if(active) return active;
    }

    const htmlView = normalizeToken(document.documentElement?.dataset?.activeView || '');
    if(htmlView) return htmlView;
    const bodyView = normalizeToken(document.body?.dataset?.activeView || '');
    if(bodyView) return bodyView;

    const panel = document.getElementById('panel');
    if(panel instanceof HTMLElement){
      const panelView = normalizeToken(panel.dataset.renderedView || panel.dataset.view || '');
      if(panelView) return panelView;
    }

    return '';
  }

  function resolveOwner(ownerView = '', node = null){
    const explicit = normalizeToken(ownerView);
    if(explicit) return explicit;

    if(isHTMLElement(node)){
      const existing = normalizeToken(node.dataset.ownerView || node.getAttribute('data-owner-view') || '');
      if(existing) return existing;

      const ownedParent = node.closest('[data-owner-view]');
      if(ownedParent instanceof HTMLElement){
        const parentOwner = normalizeToken(ownedParent.dataset.ownerView || ownedParent.getAttribute('data-owner-view') || '');
        if(parentOwner) return parentOwner;
      }

      const classOwner = inferOwnerFromClassName(node);
      if(classOwner) return classOwner;
    }

    return getActiveOwnerFallback();
  }

  function inferSize(node, fallback = 'md'){
    if(!isHTMLElement(node)) return fallback;
    const datasetSize = normalizeToken(node.dataset.taifWindowSize || node.dataset.modalSize || node.getAttribute('data-modal-size') || '');
    if(SIZE_TOKENS.includes(datasetSize)) return datasetSize;

    const className = String(node.className || '').toLowerCase();
    if(/--size-sm|--sm|\bsize-sm\b/.test(className)) return 'sm';
    if(/--size-lg|--lg|\bsize-lg\b|--grand/.test(className)) return 'lg';
    if(/workspace|full|maximized/.test(className)) return 'workspace';
    return fallback;
  }

  function markRuntimeNode(node, ownerView = '', type = ''){
    if(!isHTMLElement(node)) return node;
    const owner = resolveOwner(ownerView, node);
    if(typeof utils.markOwnedNode === 'function'){
      try{ utils.markOwnedNode(node, owner, { type:type || 'window-node' }); }catch{}
    }else if(owner){
      node.dataset.ownerView = owner;
      node.setAttribute('data-owner-view', owner);
    }
    return node;
  }

  function setDatasetFlag(node, key, value = 'true'){
    if(!isHTMLElement(node)) return node;
    node.dataset[key] = value;
    return node;
  }

  function markNode(node, { ownerView = '', type = '', size = '', source = '' } = {}){
    if(!isHTMLElement(node)) return node;

    const owner = resolveOwner(ownerView, node);
    if(owner){
      node.dataset.taifWindowOwner = owner;
    }
    if(source) node.dataset.taifWindowSource = toText(source);
    if(type) node.dataset.taifWindowType = type;

    if(size){
      const safeSize = SIZE_TOKENS.includes(String(size)) ? String(size) : inferSize(node);
      node.dataset.taifWindowSize = safeSize;
    }

    return markRuntimeNode(node, owner, type || 'window-node');
  }

  function getWindowFromBackdrop(backdrop){
    if(!isHTMLElement(backdrop)) return null;
    if(backdrop.matches(SELECTORS.windows)) return backdrop;
    const direct = backdrop.querySelector(SELECTORS.windows);
    return direct instanceof HTMLElement ? direct : null;
  }

  function normalizePart(part, key, ownerView){
    if(!isHTMLElement(part)) return null;
    setDatasetFlag(part, key);
    const owner = resolveOwner(ownerView, part);
    if(owner) part.dataset.taifWindowOwner = owner;
    return part;
  }

  function normalizeWindowParts(windowElement, ownerView = ''){
    if(!isHTMLElement(windowElement)) return {};
    const head = windowElement.querySelector(SELECTORS.heads);
    const body = windowElement.querySelector(SELECTORS.bodies);
    const footer = windowElement.querySelector(SELECTORS.footers);
    const actions = windowElement.querySelector(SELECTORS.actions);

    normalizePart(head, 'taifWindowHead', ownerView);
    normalizePart(body, 'taifWindowBody', ownerView);
    normalizePart(footer, 'taifWindowFooter', ownerView);
    normalizePart(actions, 'taifWindowActions', ownerView);

    if(actions instanceof HTMLElement){
      actions.dataset.taifWindowActions = 'true';
    }

    return { head, body, footer, actions };
  }

  function registerLayer(layer, { ownerView = '', source = '', className = '' } = {}){
    if(!isHTMLElement(layer)) return null;
    layer.dataset.taifWindowLayer = 'true';
    if(className) layer.dataset.taifWindowLayerClass = String(className).trim();
    markNode(layer, { ownerView, type:'window-layer', source:source || 'window-system' });
    return layer;
  }

  function registerBackdrop(backdrop, { ownerView = '', source = '' } = {}){
    if(!isHTMLElement(backdrop)) return null;
    backdrop.dataset.taifWindowBackdrop = 'true';
    markNode(backdrop, { ownerView, type:'window-backdrop', source:source || 'window-system' });
    return backdrop;
  }

  function registerWindow({ layer = null, backdrop = null, modal = null, windowElement = null, ownerView = '', source = '', size = '' } = {}){
    const resolvedWindow = isHTMLElement(windowElement) ? windowElement : (isHTMLElement(modal) ? modal : getWindowFromBackdrop(backdrop));
    const resolvedOwner = resolveOwner(ownerView, resolvedWindow || backdrop || layer);

    if(isHTMLElement(layer)) registerLayer(layer, { ownerView:resolvedOwner, source });
    if(isHTMLElement(backdrop)) registerBackdrop(backdrop, { ownerView:resolvedOwner, source });

    if(isHTMLElement(resolvedWindow)){
      resolvedWindow.dataset.taifWindow = 'true';
      resolvedWindow.dataset.taifWindowSize = SIZE_TOKENS.includes(String(size)) ? String(size) : inferSize(resolvedWindow);
      resolvedWindow.dataset.taifWindowOwner = resolvedOwner;
      if(!resolvedWindow.hasAttribute('role')){
        resolvedWindow.setAttribute('role', 'dialog');
      }
      if(!resolvedWindow.hasAttribute('tabindex')){
        resolvedWindow.setAttribute('tabindex', '-1');
      }
      markNode(resolvedWindow, {
        ownerView:resolvedOwner,
        type:'window',
        source:source || 'window-system',
        size:resolvedWindow.dataset.taifWindowSize
      });
      normalizeWindowParts(resolvedWindow, resolvedOwner);
    }

    return {
      layer: isHTMLElement(layer) ? layer : null,
      backdrop: isHTMLElement(backdrop) ? backdrop : null,
      window: isHTMLElement(resolvedWindow) ? resolvedWindow : null,
      ownerView: resolvedOwner
    };
  }

  function normalizeRoot(root = document, { ownerView = '', source = 'normalize-root' } = {}){
    const target = (root instanceof Document || root instanceof Element) ? root : document;
    const owner = resolveOwner(ownerView, target instanceof HTMLElement ? target : null);
    const result = { layers:0, backdrops:0, windows:0 };

    target.querySelectorAll?.(SELECTORS.layers).forEach((layer) => {
      if(!(layer instanceof HTMLElement)) return;
      registerLayer(layer, { ownerView:owner, source });
      result.layers += 1;
    });

    target.querySelectorAll?.(SELECTORS.backdrops).forEach((backdrop) => {
      if(!(backdrop instanceof HTMLElement)) return;
      const localOwner = resolveOwner(owner, backdrop);
      const layer = backdrop.closest(SELECTORS.layers);
      const modal = getWindowFromBackdrop(backdrop);
      registerWindow({
        layer: layer instanceof HTMLElement ? layer : null,
        backdrop,
        modal,
        ownerView:localOwner,
        source
      });
      result.backdrops += 1;
      if(modal instanceof HTMLElement) result.windows += 1;
    });

    target.querySelectorAll?.(SELECTORS.windows).forEach((windowNode) => {
      if(!(windowNode instanceof HTMLElement)) return;
      if(windowNode.dataset.taifWindow === 'true') return;
      const backdrop = windowNode.closest(SELECTORS.backdrops);
      const layer = windowNode.closest(SELECTORS.layers);
      registerWindow({
        layer: layer instanceof HTMLElement ? layer : null,
        backdrop: backdrop instanceof HTMLElement ? backdrop : null,
        modal: windowNode,
        ownerView:resolveOwner(owner, windowNode),
        source
      });
      result.windows += 1;
    });

    return result;
  }


  let observer = null;
  let pending = new Set();
  let scheduled = false;

  function flushPending(){
    scheduled = false;
    const nodes = Array.from(pending);
    pending.clear();
    nodes.forEach((node) => {
      if(!isHTMLElement(node) || !node.isConnected) return;
      try{ normalizeRoot(node, { source:'window-system-mutation' }); }catch{}
      if(node.matches?.(SELECTORS.windows) || node.matches?.(SELECTORS.backdrops) || node.matches?.(SELECTORS.layers)){
        try{ normalizeRoot(node.parentElement || node, { source:'window-system-mutation-self' }); }catch{}
      }
    });
  }

  function scheduleNode(node){
    if(!isHTMLElement(node)) return;
    pending.add(node);
    if(!scheduled){
      scheduled = true;
      window.requestAnimationFrame(flushPending);
    }
  }

  function startObserver(){
    if(observer || typeof MutationObserver !== 'function' || !document.body) return;
    observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if(node instanceof HTMLElement) scheduleNode(node);
        });
      });
    });
    observer.observe(document.body, { childList:true, subtree:true });
  }

  TAIF.ui.windowSystem = Object.freeze({
    sizes: SIZE_TOKENS,
    selectors: SELECTORS,
    markNode,
    inferSize,
    registerLayer,
    registerBackdrop,
    registerWindow,
    normalizeRoot,
    startObserver
  });

  function bootstrap(){
    try{ normalizeRoot(document, { source:'initial-document-scan' }); }catch{}
    startObserver();
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', bootstrap, { once:true });
  }else{
    bootstrap();
  }
})();

