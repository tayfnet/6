(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.ui = TAIF.ui || {};

  const ACTION_ID = 'factory-reset';
  const ACTION_LABEL = 'اعادة ضبط مصنع';
  const storageKeys = TAIF?.core?.storageKeys || {};
  const LEGACY_STORAGE_KEYS = Object.freeze(Array.from(new Set([
    storageKeys.shell,
    storageKeys.chartOfAccounts,
    storageKeys.chartOfAccountsAutoSequence,
    storageKeys.currencyManagement,
    storageKeys.cashBoxes,
    storageKeys.entriesVouchers,
    storageKeys.salesPurchaseInvoice,
    'taif-shell-state-v3',
    'taif-chart-of-accounts-centers-v3',
    'taif-chart-of-accounts-account-sequence-v1',
    'taif-currency-management-module-v1',
    'taif-cash-boxes-module-v1',
    'taif-entries-vouchers-module-v1',
    'taif-sales-purchase-invoice-records-v1'
  ].filter(Boolean))));

  const FACTORY_RESET_ICON = (() => {
    const svg = `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none">
        <defs>
          <linearGradient id="factoryResetBg" x1="12" y1="10" x2="52" y2="54" gradientUnits="userSpaceOnUse">
            <stop stop-color="#60A5FA"/>
            <stop offset="1" stop-color="#2563EB"/>
          </linearGradient>
        </defs>
        <rect x="7" y="7" width="50" height="50" rx="18" fill="#fff"/>
        <path d="M44.5 21.5A15.5 15.5 0 1 0 48 32" stroke="url(#factoryResetBg)" stroke-width="4.25" stroke-linecap="round"/>
        <path d="M43.5 14v12h-12" stroke="#DC2626" stroke-width="4.25" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M23 43h18M26 35h12M29 27h6" stroke="#0F172A" stroke-width="3.25" stroke-linecap="round" opacity=".72"/>
      </svg>`;
    return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
  })();

  let activeBackdrop = null;

  function getMeta(){
    return {
      id: ACTION_ID,
      label: ACTION_LABEL,
      icon: FACTORY_RESET_ICON,
      isAction: true,
      action: ACTION_ID,
      className: 'navbtn--danger'
    };
  }

  function createTitleIconMarkup(){
    return `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" aria-hidden="true" focusable="false">
        <path d="M43.5 14v12h-12" stroke="#fff" stroke-width="4.25" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M44.5 21.5A15.5 15.5 0 1 0 48 32" stroke="#fff" stroke-width="4.25" stroke-linecap="round"/>
        <path d="M23 43h18M26 35h12M29 27h6" stroke="#fff" stroke-width="3.25" stroke-linecap="round" opacity=".92"/>
      </svg>`;
  }

  function closeActiveBackdrop(){
    const backdrop = activeBackdrop;
    if(!(backdrop instanceof HTMLElement)) return;
    activeBackdrop = null;
    const cleanup = backdrop.__cleanup;
    if(typeof cleanup === 'function'){
      try{ cleanup(); }catch{}
      backdrop.__cleanup = null;
    }
    backdrop.classList.remove('is-visible');
    window.setTimeout(() => {
      if(backdrop.isConnected) backdrop.remove();
    }, 180);
  }

  function collectMatchingStorageKeys(backend, prefix){
    const keys = [];
    if(!backend || typeof backend.length !== 'number' || typeof backend.key !== 'function') return keys;
    for(let index = 0; index < backend.length; index += 1){
      const key = backend.key(index);
      if(typeof key !== 'string' || !key) continue;
      if(prefix && key.startsWith(prefix)) keys.push(key);
    }
    return keys;
  }

  function collectMatchingStorageKeysBySuffix(backend, suffix){
    const keys = [];
    if(!backend || typeof backend.length !== 'number' || typeof backend.key !== 'function' || !suffix) return keys;
    const safeSuffix = `::${suffix}`;
    for(let index = 0; index < backend.length; index += 1){
      const key = backend.key(index);
      if(typeof key !== 'string' || !key) continue;
      if(key === suffix || key.endsWith(safeSuffix)) keys.push(key);
    }
    return keys;
  }

  function deleteKeysFromBackend(backend, keys){
    if(!backend || typeof backend.removeItem !== 'function') return;
    Array.from(new Set(keys)).forEach((key) => {
      if(typeof key !== 'string' || !key) return;
      try{ backend.removeItem(key); }catch{}
    });
  }

  function collectMatchingMemoryKeys(prefix){
    const keys = [];
    const memoryStore = TAIF.__memoryStorage;
    if(!(memoryStore instanceof Map)) return keys;
    memoryStore.forEach((_, key) => {
      if(typeof key !== 'string' || !key) return;
      if(prefix && key.startsWith(prefix)) keys.push(key);
    });
    return keys;
  }

  function collectMatchingMemoryKeysBySuffix(suffix){
    const keys = [];
    const memoryStore = TAIF.__memoryStorage;
    if(!(memoryStore instanceof Map) || !suffix) return keys;
    const safeSuffix = `::${suffix}`;
    memoryStore.forEach((_, key) => {
      if(typeof key !== 'string' || !key) return;
      if(key === suffix || key.endsWith(safeSuffix)) keys.push(key);
    });
    return keys;
  }

  function deleteKeysFromMemoryStore(keys){
    const memoryStore = TAIF.__memoryStorage;
    if(!(memoryStore instanceof Map)) return;
    Array.from(new Set(keys)).forEach((key) => {
      if(typeof key !== 'string' || !key) return;
      memoryStore.delete(key);
    });
  }

  function clearPersistedAppState(){
    const namespace = typeof TAIF?.core?.utils?.resolveStorageNamespace === 'function'
      ? String(TAIF.core.utils.resolveStorageNamespace() || '').trim()
      : '';
    const scopedPrefix = namespace ? `${namespace}::` : '';
    const documentStateKey = String(document.documentElement?.dataset?.key || '').trim();
    const directKeys = new Set(LEGACY_STORAGE_KEYS);
    if(documentStateKey) directKeys.add(documentStateKey);

    const localBackend = (() => {
      try{ return window.localStorage; }catch{ return null; }
    })();

    const scopedKeys = [
      ...collectMatchingStorageKeys(localBackend, scopedPrefix),
      ...Array.from(directKeys).map((key) => scopedPrefix ? `${scopedPrefix}${key}` : key),
      ...Array.from(directKeys).flatMap((key) => collectMatchingStorageKeysBySuffix(localBackend, key))
    ];

    const legacyKeys = Array.from(directKeys);
    const memoryScopedKeys = [
      ...collectMatchingMemoryKeys(scopedPrefix),
      ...Array.from(directKeys).map((key) => scopedPrefix ? `${scopedPrefix}${key}` : key),
      ...Array.from(directKeys).flatMap((key) => collectMatchingMemoryKeysBySuffix(key))
    ];

    deleteKeysFromBackend(localBackend, [...scopedKeys, ...legacyKeys]);
    deleteKeysFromMemoryStore([...memoryScopedKeys, ...legacyKeys]);
  }

  function lockModalUi(backdrop, isLocked){
    if(!(backdrop instanceof HTMLElement)) return;
    backdrop.querySelectorAll('button').forEach((button) => {
      button.disabled = !!isLocked;
    });
  }

  function triggerFactoryReset(backdrop){
    if(!(backdrop instanceof HTMLElement)) return;
    const confirmButton = backdrop.querySelector('[data-factory-reset-confirm]');
    if(confirmButton instanceof HTMLButtonElement){
      confirmButton.textContent = 'جارٍ إعادة الضبط...';
    }
    lockModalUi(backdrop, true);
    clearPersistedAppState();
    window.setTimeout(() => {
      window.location.reload();
    }, 80);
  }

  function open(){
    if(activeBackdrop instanceof HTMLElement && activeBackdrop.isConnected){
      activeBackdrop.querySelector('[data-factory-reset-cancel]')?.focus();
      return;
    }

    const backdrop = document.createElement('div');
    backdrop.className = 'taif-factory-reset-backdrop';
    backdrop.innerHTML = `
      <div class="taif-factory-reset-modal" role="dialog" aria-modal="true" aria-labelledby="taifFactoryResetTitle" aria-describedby="taifFactoryResetDescription">
        <div class="taif-factory-reset__topbar">
          <button class="taif-factory-reset__close" type="button" data-factory-reset-close aria-label="إغلاق نافذة اعادة الضبط">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6 6 18" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>
          </button>
          <div class="taif-factory-reset__title-block">
            <span class="taif-factory-reset__eyebrow">تحذير نهائي</span>
            <h2 id="taifFactoryResetTitle" class="taif-factory-reset__title">اعادة ضبط مصنع</h2>
          </div>
          <div class="taif-factory-reset__title-icon">${createTitleIconMarkup()}</div>
        </div>
        <div class="taif-factory-reset__body">
          <p id="taifFactoryResetDescription" class="taif-factory-reset__lead">سيؤدي هذا الإجراء إلى حذف كل البيانات التي أضافها المستخدم داخل المشروع وإرجاع النظام إلى حالته الافتراضية مباشرة.</p>
          <div class="taif-factory-reset__warning">عند التأكيد سيتم حذف الحسابات المضافة، الصناديق، العملات، القيود والسندات، وبيانات المبيع والشراء المخزنة محليًا. لا يمكن التراجع عن هذه العملية بعد التنفيذ.</div>
          <div class="taif-factory-reset__chips" aria-hidden="true">
            <span class="taif-factory-reset__chip">شجرة الحسابات</span>
            <span class="taif-factory-reset__chip">الصناديق النقدية</span>
            <span class="taif-factory-reset__chip">إدارة العملات</span>
            <span class="taif-factory-reset__chip">القيود والسندات</span>
            <span class="taif-factory-reset__chip">المبيع والشراء</span>
          </div>
          <div class="taif-factory-reset__actions">
            <button class="taif-factory-reset__btn taif-factory-reset__btn--ghost" type="button" data-factory-reset-cancel>إلغاء</button>
            <button class="taif-factory-reset__btn taif-factory-reset__btn--danger" type="button" data-factory-reset-confirm>تأكيد اعادة الضبط</button>
          </div>
        </div>
      </div>`;

    const close = () => closeActiveBackdrop();
    const onKeyDown = (event) => {
      if(event.key === 'Escape'){
        event.preventDefault();
        close();
      }
    };

    backdrop.addEventListener('click', (event) => {
      if(event.target === backdrop) close();
    });
    backdrop.querySelector('[data-factory-reset-close]')?.addEventListener('click', close);
    backdrop.querySelector('[data-factory-reset-cancel]')?.addEventListener('click', close);
    backdrop.querySelector('[data-factory-reset-confirm]')?.addEventListener('click', () => {
      triggerFactoryReset(backdrop);
    });
    window.addEventListener('keydown', onKeyDown, true);
    backdrop.__cleanup = () => {
      window.removeEventListener('keydown', onKeyDown, true);
    };

    TAIF?.core?.utils?.markOwnedNode?.(backdrop, 'factory-reset');
    document.body.appendChild(backdrop);
    activeBackdrop = backdrop;
    requestAnimationFrame(() => {
      backdrop.classList.add('is-visible');
      backdrop.querySelector('[data-factory-reset-cancel]')?.focus();
    });
  }

  TAIF.ui.factoryReset = {
    ...(TAIF.ui.factoryReset || {}),
    getMeta,
    open,
    clearPersistedAppState
  };
})();
