(()=>{
  'use strict';
  const TAIF = window.TAIF;
  const BLOCKED_INPUT_TYPES = new Set(['hidden','button','submit','reset','checkbox','radio','range','color','file','image']);

  function asElement(target){
    if(target instanceof Element) return target;
    if(target && target.parentElement instanceof Element) return target.parentElement;
    return null;
  }

  function isEditableInput(element){
    if(!(element instanceof HTMLInputElement)) return false;
    const type = String(element.type || 'text').toLowerCase();
    if(BLOCKED_INPUT_TYPES.has(type)) return false;
    if(element.disabled || element.readOnly) return false;
    return true;
  }

  function isWritableField(element){
    const target = asElement(element);
    if(!target) return false;
    if(target.closest('[data-allow-text-selection="true"], .taif-allow-text-selection')) return true;

    const editable = target.closest('input, textarea, [contenteditable]');
    if(!editable) return false;

    if(editable instanceof HTMLInputElement) return isEditableInput(editable);
    if(editable instanceof HTMLTextAreaElement) return !editable.disabled && !editable.readOnly;

    const rawState = editable.getAttribute('contenteditable');
    if(rawState === 'false') return false;
    return editable.isContentEditable || rawState === '' || rawState === 'true' || rawState === 'plaintext-only';
  }

  function clearSelection(){
    const selection = window.getSelection?.();
    if(selection && selection.rangeCount) selection.removeAllRanges();
  }

  function shouldBlockSelection(event){
    return !isWritableField(event.target);
  }

  TAIF.ui.selectionGuard.isWritableField = isWritableField;
  TAIF.ui.selectionGuard.bind = function bindSelectionGuard(doc = document){
    const body = doc.body;
    if(!body || body.dataset.taifSelectionGuardBound === 'true') return;

    body.dataset.taifSelectionGuardBound = 'true';
    body.classList.add('taif-selection-guard-active');

    const clearIfNeeded = (event) => {
      if(!shouldBlockSelection(event)) return;
      clearSelection();
    };

    doc.addEventListener('selectstart', (event) => {
      if(!shouldBlockSelection(event)) return;
      event.preventDefault();
      clearSelection();
    }, true);

    doc.addEventListener('pointerdown', clearIfNeeded, true);
    doc.addEventListener('dblclick', clearIfNeeded, true);
    doc.addEventListener('dragstart', (event) => {
      if(!shouldBlockSelection(event)) return;
      event.preventDefault();
    }, true);

    doc.addEventListener('keydown', (event) => {
      const modifierPressed = event.ctrlKey || event.metaKey;
      if(!modifierPressed) return;
      if(String(event.key || '').toLowerCase() !== 'a') return;
      if(!shouldBlockSelection(event)) return;
      event.preventDefault();
      clearSelection();
    }, true);
  };
})();
