(()=>{
  'use strict';

  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.ui = TAIF.ui || {};
  TAIF.ui.smartWritingFields = TAIF.ui.smartWritingFields || {};

  const BLOCKED_INPUT_TYPES = new Set(['hidden', 'button', 'submit', 'reset', 'checkbox', 'radio', 'range', 'color', 'file', 'image']);
  const LTR_FALLBACK_TYPES = new Set(['email', 'url', 'tel', 'number', 'password']);
  const CARET_END_FRAME_KEY = '__taifCaretEndFrame';

  function isEditableTextField(element){
    if(element instanceof HTMLInputElement){
      const type = String(element.type || 'text').toLowerCase();
      if(BLOCKED_INPUT_TYPES.has(type)) return false;
      if(element.disabled || element.readOnly) return false;
      return true;
    }
    if(element instanceof HTMLTextAreaElement){
      return !element.disabled && !element.readOnly;
    }
    return false;
  }

  function resolveField(target){
    if(target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) return target;
    if(target instanceof Element) return target.closest('input, textarea');
    return null;
  }

  function isSearchField(field){
    if(!(field instanceof HTMLInputElement || field instanceof HTMLTextAreaElement)) return false;

    const type = String(field.type || '').toLowerCase();
    if(type === 'search') return true;

    const identifier = `${field.id || ''} ${field.name || ''} ${field.className || ''} ${field.getAttribute('placeholder') || ''}`.toLowerCase();
    return /search|ابحث/.test(identifier);
  }

  function isArabicCharacter(character){
    return /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/.test(character);
  }

  function isLatinCharacter(character){
    return /[A-Za-z]/.test(character);
  }

  function isAsciiDigit(character){
    return /[0-9]/.test(character);
  }

  function isArabicIndicDigit(character){
    return /[\u0660-\u0669\u06F0-\u06F9]/.test(character);
  }

  function isLtrNumericPunctuation(character){
    return /[+\-.,/%:]/.test(character);
  }

  function detectDirectionFromValue(value){
    const text = String(value ?? '');
    for(const character of text){
      if(/\s/.test(character)) continue;
      if(isArabicCharacter(character) || isArabicIndicDigit(character)) return 'rtl';
      if(isLatinCharacter(character) || isAsciiDigit(character) || isLtrNumericPunctuation(character)) return 'ltr';
    }
    return null;
  }

  function detectFallbackDirection(field){
    if(!(field instanceof HTMLInputElement || field instanceof HTMLTextAreaElement)) return null;

    const explicitDefault = field.getAttribute('data-smart-writing-default-dir');
    if(explicitDefault === 'ltr' || explicitDefault === 'rtl') return explicitDefault;

    if(field.dataset.smartNumberInput === 'true') return 'ltr';

    const inputMode = String(field.inputMode || '').toLowerCase();
    if(inputMode === 'decimal' || inputMode === 'numeric') return 'ltr';

    if(field instanceof HTMLInputElement){
      const type = String(field.type || 'text').toLowerCase();
      if(LTR_FALLBACK_TYPES.has(type)) return 'ltr';
    }

    const identifier = `${field.id || ''} ${field.name || ''} ${field.className || ''}`.toLowerCase();
    if(/code|currency-code/.test(identifier)) return 'ltr';

    return null;
  }

  function clearManagedDirection(field){
    if(!(field instanceof HTMLInputElement || field instanceof HTMLTextAreaElement)) return;
    field.removeAttribute('dir');
    delete field.dataset.smartWritingResolvedDir;
  }

  function applyDirection(field){
    if(!isEditableTextField(field)) return;

    if(isSearchField(field)){
      clearManagedDirection(field);
      return;
    }

    const detectedDirection = detectDirectionFromValue(field.value);
    const nextDirection = detectedDirection || detectFallbackDirection(field);

    if(nextDirection === 'ltr' || nextDirection === 'rtl'){
      field.setAttribute('dir', nextDirection);
      field.dataset.smartWritingResolvedDir = nextDirection;
      return;
    }

    clearManagedDirection(field);
  }

  function cancelQueuedCaret(field){
    if(!field || !field[CARET_END_FRAME_KEY]) return;
    try{ cancelAnimationFrame(field[CARET_END_FRAME_KEY]); }catch{}
    field[CARET_END_FRAME_KEY] = 0;
  }

  function moveCaretToEnd(field){
    if(!isEditableTextField(field)) return;
    if(document.activeElement !== field) return;
    if(typeof field.setSelectionRange !== 'function') return;

    const value = String(field.value ?? '');
    const end = value.length;
    try{
      field.setSelectionRange(end, end);
    }catch{}
  }

  function focusFieldAtEnd(field){
    if(!isEditableTextField(field)) return;

    cancelQueuedCaret(field);
    try{
      field.focus({ preventScroll: true });
    }catch{
      try{ field.focus(); }catch{}
    }
    moveCaretToEnd(field);
    field[CARET_END_FRAME_KEY] = requestAnimationFrame(() => {
      field[CARET_END_FRAME_KEY] = 0;
      moveCaretToEnd(field);
    });
  }

  function shouldManagePointerFocus(event, field, doc){
    if(!isEditableTextField(field)) return false;
    if(isSearchField(field)) return false;
    if(doc.activeElement === field) return false;
    if(event.defaultPrevented) return false;
    if('button' in event && event.button !== 0) return false;
    if('isPrimary' in event && event.isPrimary === false) return false;
    if(event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return false;
    return true;
  }

  function applyWithin(root){
    const scope = root instanceof Element || root instanceof Document ? root : document;
    const directField = scope instanceof HTMLInputElement || scope instanceof HTMLTextAreaElement ? scope : null;
    if(directField) applyDirection(directField);
    scope.querySelectorAll?.('input, textarea').forEach((field) => applyDirection(field));
  }

  TAIF.ui.smartWritingFields.applyDirection = applyDirection;
  TAIF.ui.smartWritingFields.applyWithin = applyWithin;
  TAIF.ui.smartWritingFields.bind = function bindSmartWritingFields(doc = document){
    const body = doc.body;
    if(!body || body.dataset.taifSmartWritingFieldsBound === 'true') return;

    body.dataset.taifSmartWritingFieldsBound = 'true';

    doc.addEventListener('pointerdown', (event) => {
      const field = resolveField(event.target);
      if(!shouldManagePointerFocus(event, field, doc)){
        if(isEditableTextField(field)) applyDirection(field);
        return;
      }

      applyDirection(field);
      event.preventDefault();
      focusFieldAtEnd(field);
    }, true);

    doc.addEventListener('focusin', (event) => {
      const field = resolveField(event.target);
      if(!isEditableTextField(field)) return;
      applyDirection(field);
    }, true);

    doc.addEventListener('blur', (event) => {
      const field = resolveField(event.target);
      cancelQueuedCaret(field);
    }, true);

    doc.addEventListener('input', (event) => {
      const field = resolveField(event.target);
      if(!isEditableTextField(field)) return;
      applyDirection(field);
    }, true);

    doc.addEventListener('change', (event) => {
      const field = resolveField(event.target);
      if(!isEditableTextField(field)) return;
      applyDirection(field);
    }, true);

    doc.addEventListener('compositionend', (event) => {
      const field = resolveField(event.target);
      if(!isEditableTextField(field)) return;
      applyDirection(field);
    }, true);

    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if(!(node instanceof Element)) return;
          applyWithin(node);
        });
      });
    });

    observer.observe(body, { childList: true, subtree: true });
    applyWithin(doc);
  };
})();
