(()=>{

  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.ui = TAIF.ui || {};
  TAIF.core = TAIF.core || {};
  TAIF.core.utils = TAIF.core.utils || {};
  const utils = TAIF.core.utils;

  const previousRegisterInlinePickerApi = typeof utils.registerInlinePickerApi === 'function' ? utils.registerInlinePickerApi.bind(utils) : null;
  const previousSetDisclosureOpenState = typeof utils.setDisclosureOpenState === 'function' ? utils.setDisclosureOpenState.bind(utils) : null;

  const HOST_SELECTOR = '[data-taif-picker-host="true"], [data-taif-inline-picker-host="true"]';
  const TRIGGER_SELECTOR = '[data-taif-picker-trigger="true"], [data-taif-dropdown-trigger="true"], button[aria-haspopup="listbox"], button[aria-haspopup="dialog"]';
  const POPOVER_SELECTOR = '[data-taif-picker-popover="true"], [data-taif-dropdown-popup="true"], [data-taif-inline-picker="true"]';
  const OPTION_SELECTOR = '[data-taif-picker-option="true"], [data-taif-inline-picker-option="true"], [data-taif-dropdown-item="true"], [role="option"]';

  function toText(value, fallback = ''){
    const text = String(value ?? '').trim();
    return text || fallback;
  }

  function isElement(value){ return value instanceof Element; }
  function isHTMLElement(value){ return value instanceof HTMLElement; }

  function normalizeOwner(ownerView = '', node = null){
    const explicit = toText(ownerView).replace(/\s+/g, '-');
    if(explicit) return explicit;

    if(node instanceof HTMLElement){
      const existing = toText(node.dataset.ownerView || node.getAttribute('data-owner-view') || '').replace(/\s+/g, '-');
      if(existing) return existing;
      const ownedParent = node.closest('[data-owner-view]');
      if(ownedParent instanceof HTMLElement){
        const parentOwner = toText(ownedParent.dataset.ownerView || ownedParent.getAttribute('data-owner-view') || '').replace(/\s+/g, '-');
        if(parentOwner) return parentOwner;
      }
    }

    if(typeof utils.getActiveView === 'function'){
      const active = toText(utils.getActiveView()).replace(/\s+/g, '-');
      if(active) return active;
    }

    const htmlView = toText(document.documentElement?.dataset?.activeView || '').replace(/\s+/g, '-');
    if(htmlView) return htmlView;
    const bodyView = toText(document.body?.dataset?.activeView || '').replace(/\s+/g, '-');
    if(bodyView) return bodyView;
    const panel = document.getElementById('panel');
    if(panel instanceof HTMLElement) return toText(panel.dataset.renderedView || panel.dataset.view || '').replace(/\s+/g, '-');
    return '';
  }

  function markPopover(popover, ownerView = ''){
    if(!(popover instanceof HTMLElement)) return popover;
    const owner = normalizeOwner(ownerView, popover);
    if(typeof utils.markOwnedNode === 'function'){
      try{ utils.markOwnedNode(popover, owner, { type:'picker-popover' }); }catch{}
    }else if(owner){
      popover.dataset.ownerView = owner;
      popover.setAttribute('data-owner-view', owner);
    }
    return popover;
  }

  function getHost(element){
    if(!(element instanceof Element)) return null;
    const host = element.closest(HOST_SELECTOR);
    return host instanceof HTMLElement ? host : null;
  }

  function getTrigger(host, explicitTrigger = null){
    if(explicitTrigger instanceof HTMLElement) return explicitTrigger;
    if(!(host instanceof HTMLElement)) return null;
    const trigger = host.querySelector(TRIGGER_SELECTOR) || host.querySelector('button, input, select, textarea, [tabindex]:not([tabindex="-1"])');
    return trigger instanceof HTMLElement ? trigger : null;
  }

  function getControlledPopover(trigger){
    if(!(trigger instanceof HTMLElement)) return null;
    const id = toText(trigger.getAttribute('aria-controls'));
    if(!id) return null;
    const popover = document.getElementById(id);
    return popover instanceof HTMLElement && popover.matches(POPOVER_SELECTOR) ? popover : null;
  }

  function getPopovers(host, { trigger = null, getPopover = null, popover = null } = {}){
    const result = [];
    const add = (node) => {
      if(node instanceof HTMLElement && !result.includes(node)) result.push(node);
    };
    add(popover);
    if(typeof getPopover === 'function'){
      try{ add(getPopover()); }catch{}
    }
    if(host instanceof HTMLElement) host.querySelectorAll(POPOVER_SELECTOR).forEach(add);
    add(getControlledPopover(trigger));
    return result;
  }

  function normalizeTrigger(trigger, { skipFlow = false } = {}){
    if(!(trigger instanceof HTMLElement)) return null;
    trigger.dataset.taifPickerTrigger = 'true';
    if(!trigger.hasAttribute('aria-haspopup')) trigger.setAttribute('aria-haspopup', 'listbox');
    const skipped = !!skipFlow || trigger.matches('[data-taif-flow-skip="true"]') || !!trigger.closest('[data-taif-flow-skip="true"]');
    if(!skipped && trigger.dataset.taifFlowItem !== 'false') trigger.dataset.taifFlowItem = 'true';
    return trigger;
  }

  function normalizeOptions(popover){
    if(!(popover instanceof HTMLElement)) return 0;
    let count = 0;
    popover.querySelectorAll(OPTION_SELECTOR).forEach((option) => {
      if(!(option instanceof HTMLElement)) return;
      option.dataset.taifPickerOption = 'true';
      if(option.getAttribute('role') === 'option' || option.matches('[data-taif-dropdown-item-kind="list"]')){
        option.dataset.taifInlinePickerOption = 'true';
      }
      count += 1;
    });
    return count;
  }

  function normalizePopover(popover, { host = null, trigger = null, ownerView = '' } = {}){
    if(!(popover instanceof HTMLElement)) return null;
    popover.dataset.taifPickerPopover = 'true';
    popover.dataset.taifDropdownPopup = 'true';
    if(!popover.dataset.taifDropdownLayout && popover.getAttribute('role') === 'listbox') popover.dataset.taifDropdownLayout = 'list';
    if(popover.getAttribute('role') === 'listbox') popover.dataset.taifInlinePicker = 'true';
    popover.setAttribute('aria-hidden', popover.hidden ? 'true' : 'false');
    if(trigger instanceof HTMLElement && trigger.id && !popover.getAttribute('aria-labelledby')) popover.setAttribute('aria-labelledby', trigger.id);
    normalizeOptions(popover);
    markPopover(popover, ownerView || normalizeOwner('', host || trigger || popover));
    return popover;
  }

  function normalizeHost(host, { trigger = null, getPopover = null, popover = null, ownerView = '', api = null } = {}){
    if(!(host instanceof HTMLElement)) return null;
    host.dataset.taifPickerHost = 'true';
    if(host.hasAttribute('data-taif-inline-picker-host')) host.dataset.taifInlinePickerHost = 'true';
    const resolvedTrigger = normalizeTrigger(getTrigger(host, trigger), { skipFlow:host.matches('[data-taif-flow-skip="true"]') });
    const owner = normalizeOwner(ownerView, host || resolvedTrigger);
    const popovers = getPopovers(host, { trigger:resolvedTrigger, getPopover, popover });
    popovers.forEach((node) => normalizePopover(node, { host, trigger:resolvedTrigger, ownerView:owner }));
    if(api && typeof api === 'object'){
      host.__taifPickerSystemApi = api;
      if(resolvedTrigger) resolvedTrigger.__taifPickerSystemApi = api;
      popovers.forEach((node) => { node.__taifPickerSystemApi = api; });
    }
    return { host, trigger:resolvedTrigger, popovers };
  }

  function normalizeRoot(root = document, { ownerView = '' } = {}){
    const target = isElement(root) || root === document ? root : document;
    let hosts = 0;
    let popovers = 0;
    target.querySelectorAll?.(HOST_SELECTOR).forEach((host) => {
      if(!(host instanceof HTMLElement)) return;
      normalizeHost(host, { ownerView });
      hosts += 1;
    });
    target.querySelectorAll?.(POPOVER_SELECTOR).forEach((popover) => {
      if(!(popover instanceof HTMLElement)) return;
      const host = getHost(popover);
      normalizePopover(popover, { host, trigger:host ? getTrigger(host) : null, ownerView });
      popovers += 1;
    });
    const flow = TAIF.ui && TAIF.ui.flow;
    if(isElement(root) && flow && typeof flow.normalizeRoot === 'function'){
      try{ flow.normalizeRoot(root); }catch{}
    }
    return { hosts, popovers };
  }

  function syncDisclosureState({ root = null, popup = null, trigger = null, isOpen = false } = {}){
    const host = root instanceof HTMLElement ? root : getHost(trigger || popup);
    const normalized = host ? normalizeHost(host, { trigger, popover:popup }) : null;
    const resolvedTrigger = trigger instanceof HTMLElement ? trigger : normalized?.trigger;
    const resolvedPopup = popup instanceof HTMLElement ? popup : normalized?.popovers?.[0];
    const open = !!isOpen;
    if(resolvedPopup instanceof HTMLElement){
      resolvedPopup.dataset.taifPickerOpen = open ? 'true' : 'false';
      resolvedPopup.setAttribute('aria-hidden', open ? 'false' : 'true');
    }
    if(resolvedTrigger instanceof HTMLElement){
      resolvedTrigger.dataset.taifPickerOpen = open ? 'true' : 'false';
      resolvedTrigger.setAttribute('aria-expanded', open ? 'true' : 'false');
    }
    if(host instanceof HTMLElement) host.dataset.taifPickerOpen = open ? 'true' : 'false';
    return open;
  }

  function getOptionNodes(popover){
    if(!(popover instanceof HTMLElement)) return [];
    return Array.from(popover.querySelectorAll(OPTION_SELECTOR)).filter((node) => {
      if(!(node instanceof HTMLElement)) return false;
      if(node.matches('[disabled], [aria-disabled="true"]')) return false;
      if(node instanceof HTMLButtonElement && node.disabled) return false;
      return true;
    });
  }

  function focusOption(popover, index){
    const options = getOptionNodes(popover);
    if(!options.length) return false;
    const safeIndex = Math.max(0, Math.min(options.length - 1, Number(index) || 0));
    const target = options[safeIndex];
    try{ target.focus({ preventScroll:true }); }catch{ try{ target.focus(); }catch{} }
    try{ target.scrollIntoView({ block:'nearest', inline:'nearest' }); }catch{}
    return document.activeElement === target;
  }

  function stepOption(popover, currentElement = document.activeElement, step = 1){
    const options = getOptionNodes(popover);
    if(!options.length) return false;
    const currentIndex = options.indexOf(currentElement instanceof HTMLElement ? currentElement : null);
    const nextIndex = Math.max(0, Math.min(options.length - 1, (currentIndex >= 0 ? currentIndex : (step < 0 ? options.length : -1)) + (step < 0 ? -1 : 1)));
    return focusOption(popover, nextIndex);
  }

  function handleListboxKeydown(event, { popover = null, onCommit = null, onClose = null } = {}){
    if(!event || event.defaultPrevented) return false;
    const targetPopover = popover instanceof HTMLElement ? popover : (event.target instanceof Element ? event.target.closest(POPOVER_SELECTOR) : null);
    if(!(targetPopover instanceof HTMLElement)) return false;
    if(event.key === 'ArrowDown'){
      event.preventDefault();
      return stepOption(targetPopover, event.target, 1);
    }
    if(event.key === 'ArrowUp'){
      event.preventDefault();
      return stepOption(targetPopover, event.target, -1);
    }
    if(event.key === 'Home'){
      event.preventDefault();
      return focusOption(targetPopover, 0);
    }
    if(event.key === 'End'){
      event.preventDefault();
      return focusOption(targetPopover, getOptionNodes(targetPopover).length - 1);
    }
    if(event.key === 'Enter' || event.key === 'NumpadEnter' || event.key === ' ' || event.key === 'Spacebar'){
      const option = event.target instanceof Element ? event.target.closest(OPTION_SELECTOR) : null;
      if(option instanceof HTMLElement){
        event.preventDefault();
        if(typeof onCommit === 'function') onCommit(option, event);
        else option.click();
        return true;
      }
    }
    if(event.key === 'Escape' && typeof onClose === 'function'){
      event.preventDefault();
      onClose(event);
      return true;
    }
    return false;
  }

  function registerPickerApi({ picker = null, trigger = null, getPopover = null, api = null, clearCommittedSelection = null, registerCleanup = null, ownerView = '' } = {}){
    const host = picker instanceof HTMLElement ? picker : getHost(trigger);
    const safeGetPopover = typeof getPopover === 'function'
      ? () => {
          let resolved = null;
          try{ resolved = getPopover(); }catch{}
          if(resolved instanceof HTMLElement) normalizePopover(resolved, { host, trigger, ownerView });
          return resolved;
        }
      : getPopover;
    if(host instanceof HTMLElement) normalizeHost(host, { trigger, getPopover:safeGetPopover, api, ownerView });
    if(previousRegisterInlinePickerApi){
      previousRegisterInlinePickerApi({ picker, trigger, getPopover:safeGetPopover, api, clearCommittedSelection, registerCleanup });
    }
    if(api && typeof api === 'object' && !api.normalizePickerContract){
      try{ api.normalizePickerContract = () => normalizeHost(host, { trigger, getPopover:safeGetPopover, api, ownerView }); }catch{}
    }
    return api;
  }

  TAIF.ui.pickerSystem = {
    ...(TAIF.ui.pickerSystem || {}),
    selectors:Object.freeze({ host:HOST_SELECTOR, trigger:TRIGGER_SELECTOR, popover:POPOVER_SELECTOR, option:OPTION_SELECTOR }),
    normalizeRoot,
    normalizeHost,
    normalizePopover,
    normalizeTrigger,
    normalizeOptions,
    syncDisclosureState,
    getOptionNodes,
    focusOption,
    stepOption,
    handleListboxKeydown,
    registerPickerApi
  };

  utils.registerInlinePickerApi = function(options = {}){
    return registerPickerApi(options);
  };

  if(previousSetDisclosureOpenState){
    utils.setDisclosureOpenState = function(options = {}){
      const result = previousSetDisclosureOpenState(options);
      try{ syncDisclosureState(options); }catch{}
      return result;
    };
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', () => normalizeRoot(document), { once:true });
  }else{
    try{ normalizeRoot(document); }catch{}
  }
})();
