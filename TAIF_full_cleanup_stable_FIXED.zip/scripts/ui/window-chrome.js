(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.ui = TAIF.ui || {};
  const chrome = TAIF.ui.windowChrome || (TAIF.ui.windowChrome = {});
  const flowSystem = TAIF.ui.flow || {};
  const { getViewportBoundsForSize, isEditableFormControl, clearModalMaximizedFrame: clearSharedModalMaximizedFrame, stopEventPropagation } = TAIF.core.utils;

  const CHROME_BUTTON_SELECTOR = '[data-taif-window-actions="true"] button';
  const PRIMARY_FLOW_SELECTOR = [
    'input:not([type="hidden"]):not([type="file"]):not([disabled]):not([readonly])',
    'textarea:not([disabled]):not([readonly])',
    'select:not([disabled])',
    '[data-taif-picker-trigger="true"]:not([disabled])',
    '[data-taif-flow-item="true"]:not([disabled])'
  ].join(', ');
  const FOOTER_FLOW_SELECTOR = [
    '[data-taif-footer-actions="true"] button:not([disabled])'
  ].join(', ');
  const FALLBACK_FLOW_SELECTOR = [
    '[data-taif-dropdown-item="true"]:not([disabled])',
    'button:not([disabled])'
  ].join(', ');
  const FLOW_EXCLUDE_SELECTOR = [
    CHROME_BUTTON_SELECTOR,
    '[data-entry-action="remove-line"]',
    '[data-taif-clear-control="true"]',
    '[data-taif-flow-skip="true"]',
    '[data-taif-flow-item="false"]'
  ].join(', ');
  const VERTICAL_ARROW_GROUP_SELECTOR = [
    '[data-taif-dropdown-popup="true"]',
    '[data-taif-arrow-group="vertical"]'
  ].join(', ');
  const HORIZONTAL_ARROW_GROUP_SELECTOR = [
    '[data-taif-footer-actions="true"]',
    '[data-taif-footer-group="true"]',
    '[data-taif-window-actions="true"]'
  ].join(', ');

  function getIconMarkup(type){
    if(type === 'close'){
      return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="none" stroke="currentColor" stroke-width="2.25" stroke-linecap="round" d="M18 6 6 18"></path><path fill="none" stroke="currentColor" stroke-width="2.25" stroke-linecap="round" d="m6 6 12 12"></path></svg>';
    }
    if(type === 'collapse'){
      return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round" d="M9 9H4V4M15 9h5V4M9 15H4v5M15 15h5v5"></path></svg>';
    }
    return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round" d="M8 3H3v5M16 3h5v5M8 21H3v-5M16 21h5v-5"></path></svg>';
  }

  function syncExpandButton(button, isMaximized){
    if(!button) return;
    button.innerHTML = getIconMarkup(isMaximized ? 'collapse' : 'expand');
    button.setAttribute('aria-label', isMaximized ? 'استعادة الحجم المرجعي' : 'تكبير النافذة');
    button.setAttribute('title', isMaximized ? 'استعادة الحجم المرجعي' : 'تكبير النافذة');
    button.setAttribute('aria-pressed', isMaximized ? 'true' : 'false');
  }

  function primeCloseButton(button){
    if(!button) return;
    button.innerHTML = getIconMarkup('close');
    button.setAttribute('aria-label', 'إغلاق');
    button.setAttribute('title', 'إغلاق');
  }

  function isElementVisible(element){
    if(!(element instanceof HTMLElement)) return false;
    if(element.hidden) return false;
    if(element.closest('[hidden], [aria-hidden="true"]')) return false;
    const style = window.getComputedStyle(element);
    if(style.display === 'none' || style.visibility === 'hidden') return false;
    return element.getClientRects().length > 0;
  }

  function uniqueElements(elements){
    const seen = new Set();
    return elements.filter((element) => {
      if(!(element instanceof HTMLElement)) return false;
      if(seen.has(element)) return false;
      seen.add(element);
      return true;
    });
  }

  function collectElements(root, selector, { excludeSelector = '', skipPopoverFields = false } = {}){
    if(!(root instanceof Element) || !selector) return [];
    return uniqueElements(Array.from(root.querySelectorAll(selector)).filter((element) => {
      if(!isElementVisible(element)) return false;
      if(typeof flowSystem.isSkipped === 'function' && flowSystem.isSkipped(element)) return false;
      if(excludeSelector && element.matches(excludeSelector)) return false;
      if(excludeSelector && element.closest(excludeSelector)) return false;
      if(skipPopoverFields && element.closest('[data-taif-inline-picker="true"]')) return false;
      return true;
    }));
  }

  function isFieldTriggerButton(element){
    return element instanceof HTMLButtonElement && element.matches('[data-taif-picker-trigger="true"]');
  }

  function getInlinePickerHost(element){
    if(!(element instanceof Element)) return null;
    const host = element.closest('[data-taif-inline-picker-host="true"], [data-taif-inline-picker="true"]');
    return host instanceof HTMLElement ? host : null;
  }

  function getInlinePickerApi(element){
    const host = getInlinePickerHost(element);
    return host && host.__taifInlinePickerApi ? host.__taifInlinePickerApi : null;
  }

  function isInlinePickerTrigger(element){
    return isFieldTriggerButton(element) && !!getInlinePickerApi(element);
  }

  function isInlinePickerOption(element){
    if(!(element instanceof HTMLElement)) return false;
    if(element.matches('[data-taif-inline-picker-option="true"]')) return true;
    if(element.getAttribute('role') !== 'option') return false;
    return Boolean(element.closest('[data-taif-inline-picker="true"]'));
  }

  function isInlinePickerPopoverControl(element){
    return element instanceof HTMLElement && Boolean(element.closest('[data-taif-inline-picker="true"]'));
  }

  function queueRelativeFlowFocus(root, anchor, step){
    if(!(root instanceof Element)) return;
    const safeStep = step < 0 ? -1 : 1;
    let attemptsLeft = 3;

    function tryFocus(){
      const candidateAnchor = anchor instanceof HTMLElement && root.contains(anchor)
        ? anchor
        : (document.activeElement instanceof HTMLElement && root.contains(document.activeElement) ? document.activeElement : null);
      if(focusRelativeFlowTarget(root, candidateAnchor, safeStep)) return;
      attemptsLeft -= 1;
      if(attemptsLeft > 0) requestAnimationFrame(tryFocus);
    }

    requestAnimationFrame(tryFocus);
  }

  function triggerElementPress(element){
    if(!(element instanceof HTMLElement) || typeof element.click !== 'function') return false;
    element.click();
    return true;
  }

  function isTextLikeField(element){
    return element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement;
  }

  function isEnterFlowTarget(element){
    if(!(element instanceof HTMLElement)) return false;
    if(element.closest('[data-taif-inline-picker="true"]')) return false;
    if(isFieldTriggerButton(element)) return true;
    return typeof isEditableFormControl === 'function'
      ? isEditableFormControl(element)
      : false;
  }

  function resolveInteractiveElement(target, root){
    if(!(root instanceof Element) || !(target instanceof Element)) return null;
    const control = target.closest('input, textarea, select, button, [role="option"], [data-taif-dropdown-item="true"]');
    if(!(control instanceof HTMLElement) || !root.contains(control)) return null;
    if(typeof flowSystem.isSkipped === 'function' && flowSystem.isSkipped(control)) return null;
    return control;
  }

  function focusElement(element){
    if(!(element instanceof HTMLElement) || !isElementVisible(element)) return false;
    if(typeof element.scrollIntoView === 'function'){
      try{
        element.scrollIntoView({ block: 'nearest', inline: 'nearest' });
      }catch{}
    }
    try{
      element.focus({ preventScroll: true });
    }catch{
      try{ element.focus(); }catch{}
    }

    if(isTextLikeField(element) && typeof element.setSelectionRange === 'function'){
      const type = element instanceof HTMLInputElement ? String(element.type || 'text').toLowerCase() : 'textarea';
      if(!['date', 'time', 'datetime-local', 'month', 'week', 'color', 'range'].includes(type)){
        const end = String(element.value ?? '').length;
        try{ element.setSelectionRange(end, end); }catch{}
      }
    }
    return document.activeElement === element;
  }

  function isFooterFlowButton(element){
    return element instanceof HTMLElement && element.matches(FOOTER_FLOW_SELECTOR);
  }

  function resolveFooterActionSignature(element){
    if(!(element instanceof HTMLElement)) return '';
    const dataset = element.dataset || {};
    const parts = [
      dataset.currencyManagementAction,
      dataset.rowAction,
      dataset.entryAction,
      dataset.coaAction,
      dataset.action,
      element.getAttribute('aria-label'),
      element.getAttribute('title'),
      element.textContent
    ].filter(Boolean);
    return parts.join(' ').trim().toLowerCase();
  }

  function resolveFooterFlowPriority(element){
    if(!(element instanceof HTMLElement)) return 3;

    const signature = resolveFooterActionSignature(element);
    const actionTone = String(element.dataset.taifActionTone || '').trim().toLowerCase();
    const actionRole = String(element.dataset.taifActionRole || '').trim().toLowerCase();
    const isPrimaryClass = actionTone === 'primary' || actionTone === 'danger' || actionTone === 'success';
    const isCancelLike = /(^|\s)(cancel|close|dismiss|back|ignore)(\s|$)/.test(signature)
      || /إلغاء|إغلاق|رجوع|عودة|تجاهل/.test(signature);
    const isCommitLike = /(^|\s)(save|confirm|submit|create|add|apply|update|delete|remove|restore)(\s|$)/.test(signature)
      || /حفظ|تأكيد|إضافة|إنشاء|تطبيق|تحديث|حذف|استعادة/.test(signature);

    if(isPrimaryClass || actionRole === 'commit' || isCommitLike) return 0;
    if(actionRole === 'cancel' || isCancelLike) return 2;
    return 1;
  }

  function sortFooterFlowTargets(elements){
    if(!Array.isArray(elements) || !elements.length) return [];
    return elements
      .map((element, index) => ({ element, index, priority: resolveFooterFlowPriority(element) }))
      .sort((left, right) => {
        if(left.priority !== right.priority) return left.priority - right.priority;
        return left.index - right.index;
      })
      .map((entry) => entry.element);
  }

  function buildFlowTargets(root, { footerOrder = 'priority' } = {}){
    const footerElements = collectElements(root, FOOTER_FLOW_SELECTOR, {
      excludeSelector: FLOW_EXCLUDE_SELECTOR
    });
    const footerButtons = footerOrder === 'dom' ? footerElements : sortFooterFlowTargets(footerElements);

    const primaryFields = collectElements(root, PRIMARY_FLOW_SELECTOR, {
      excludeSelector: FLOW_EXCLUDE_SELECTOR,
      skipPopoverFields: true
    });
    if(primaryFields.length){
      return uniqueElements(primaryFields.concat(footerButtons));
    }

    const fallbackButtons = collectElements(root, FALLBACK_FLOW_SELECTOR, {
      excludeSelector: FLOW_EXCLUDE_SELECTOR
    });
    if(fallbackButtons.length){
      const nonFooterFallbackButtons = fallbackButtons.filter((element) => !isFooterFlowButton(element));
      if(nonFooterFallbackButtons.length) return uniqueElements(nonFooterFallbackButtons.concat(footerButtons));
      if(footerButtons.length) return footerButtons;
      return fallbackButtons;
    }

    if(footerButtons.length) return footerButtons;
    return collectElements(root, CHROME_BUTTON_SELECTOR);
  }

  function findFlowInsertionIndex(flowTargets, reference){
    if(!(reference instanceof Node)) return flowTargets.length;
    for(let index = 0; index < flowTargets.length; index += 1){
      const candidate = flowTargets[index];
      if(candidate === reference) return index;
      const relation = reference.compareDocumentPosition(candidate);
      if(relation & Node.DOCUMENT_POSITION_FOLLOWING) return index;
    }
    return flowTargets.length;
  }

  function resolveRelativeFlowTarget(root, current, step, { footerOrder = 'priority', clamp = false, referenceElement = null } = {}){
    const flowTargets = buildFlowTargets(root, { footerOrder });
    if(!flowTargets.length) return null;

    const normalizedStep = step < 0 ? -1 : 1;
    const reference = referenceElement instanceof HTMLElement && root.contains(referenceElement)
      ? referenceElement
      : (current instanceof HTMLElement && root.contains(current) ? current : null);
    const currentIndex = reference ? flowTargets.indexOf(reference) : -1;
    let nextIndex = -1;

    if(currentIndex !== -1){
      nextIndex = currentIndex + normalizedStep;
    }else{
      const insertionIndex = findFlowInsertionIndex(flowTargets, reference || current);
      nextIndex = normalizedStep < 0 ? insertionIndex - 1 : insertionIndex;
    }

    if(clamp){
      nextIndex = Math.max(0, Math.min(flowTargets.length - 1, nextIndex));
    }

    if(nextIndex < 0 || nextIndex >= flowTargets.length) return null;
    return flowTargets[nextIndex] || null;
  }

  function resolvePreferredFooterEntryTarget(root, nextTarget, referenceElement){
    if(!(root instanceof Element)) return nextTarget;
    if(!(nextTarget instanceof HTMLElement) || !isFooterFlowButton(nextTarget)) return nextTarget;
    if(isFooterFlowButton(referenceElement)) return nextTarget;

    const preferredFooterTarget = sortFooterFlowTargets(collectElements(root, FOOTER_FLOW_SELECTOR, {
      excludeSelector: FLOW_EXCLUDE_SELECTOR
    }))[0] || null;

    if(preferredFooterTarget instanceof HTMLElement && isElementVisible(preferredFooterTarget)){
      return preferredFooterTarget;
    }

    return nextTarget;
  }

  function focusRelativeFlowTarget(root, current, step, options = {}){
    const nextTarget = resolveRelativeFlowTarget(root, current, step, options);
    const referenceElement = options && options.referenceElement instanceof HTMLElement ? options.referenceElement : null;
    const resolvedTarget = step > 0
      ? resolvePreferredFooterEntryTarget(root, nextTarget, referenceElement)
      : nextTarget;
    return resolvedTarget ? focusElement(resolvedTarget) : false;
  }

  function resolveArrowGroup(element, root, key){
    if(!(element instanceof HTMLElement) || !(root instanceof Element)) return null;

    if(key === 'ArrowUp' || key === 'ArrowDown'){
      const verticalGroup = element.closest(VERTICAL_ARROW_GROUP_SELECTOR);
      if(verticalGroup && root.contains(verticalGroup)) return verticalGroup;
    }

    const horizontalGroup = element.closest(HORIZONTAL_ARROW_GROUP_SELECTOR);
    if(horizontalGroup && root.contains(horizontalGroup)) return horizontalGroup;

    const fallbackVerticalGroup = element.closest(VERTICAL_ARROW_GROUP_SELECTOR);
    if(fallbackVerticalGroup && root.contains(fallbackVerticalGroup)) return fallbackVerticalGroup;

    return null;
  }

  function collectArrowTargets(group){
    if(!(group instanceof Element)) return [];
    return uniqueElements(Array.from(group.querySelectorAll('button:not([disabled]), [role="option"]:not([disabled]), [data-taif-dropdown-item="true"]:not([disabled])')).filter((element) => {
      if(!(element instanceof HTMLElement)) return false;
      if(!isElementVisible(element)) return false;
      if(element.matches(FLOW_EXCLUDE_SELECTOR)) return false;
      return true;
    }));
  }

  function findDirectionalTarget(current, candidates, key){
    if(!(current instanceof HTMLElement) || !Array.isArray(candidates) || !candidates.length) return null;

    const currentRect = current.getBoundingClientRect();
    const currentCenterX = currentRect.left + (currentRect.width / 2);
    const currentCenterY = currentRect.top + (currentRect.height / 2);
    let bestTarget = null;
    let bestScore = Number.POSITIVE_INFINITY;

    candidates.forEach((candidate) => {
      if(!(candidate instanceof HTMLElement) || candidate === current) return;
      const rect = candidate.getBoundingClientRect();
      const centerX = rect.left + (rect.width / 2);
      const centerY = rect.top + (rect.height / 2);
      const dx = centerX - currentCenterX;
      const dy = centerY - currentCenterY;
      let primaryDistance = 0;
      let secondaryDistance = 0;
      let isEligible = false;

      if(key === 'ArrowRight'){
        isEligible = dx > 4;
        primaryDistance = Math.abs(dx);
        secondaryDistance = Math.abs(dy);
      }else if(key === 'ArrowLeft'){
        isEligible = dx < -4;
        primaryDistance = Math.abs(dx);
        secondaryDistance = Math.abs(dy);
      }else if(key === 'ArrowDown'){
        isEligible = dy > 4;
        primaryDistance = Math.abs(dy);
        secondaryDistance = Math.abs(dx);
      }else if(key === 'ArrowUp'){
        isEligible = dy < -4;
        primaryDistance = Math.abs(dy);
        secondaryDistance = Math.abs(dx);
      }

      if(!isEligible) return;
      const score = (primaryDistance * 1000) + secondaryDistance;
      if(score < bestScore){
        bestScore = score;
        bestTarget = candidate;
      }
    });

    if(bestTarget) return bestTarget;

    const currentIndex = candidates.indexOf(current);
    if(currentIndex === -1) return null;
    if(key === 'ArrowLeft' || key === 'ArrowUp') return candidates[currentIndex - 1] || null;
    return candidates[currentIndex + 1] || null;
  }

  function bindFormNavigation(options){
    const root = options && options.root;
    const autoFocus = !(options && options.autoFocus === false);
    if(!(root instanceof Element)){
      const noop = () => {};
      noop.focusInitialTarget = () => false;
      noop.focusTarget = () => false;
      return noop;
    }
    if(typeof flowSystem.normalizeRoot === 'function'){
      try{ flowSystem.normalizeRoot(root); }catch{}
    }

    if(root.dataset.taifFormNavigationBound === 'true'){
      const noop = () => {};
      noop.focusInitialTarget = () => false;
      noop.focusTarget = focusElement;
      return noop;
    }

    root.dataset.taifFormNavigationBound = 'true';
    let initialFocusFrame = 0;

    function focusInitialTarget(){
      const explicitInitialTarget = root.querySelector('[data-taif-initial-focus="true"]');
      if(explicitInitialTarget && !(typeof flowSystem.isSkipped === 'function' && flowSystem.isSkipped(explicitInitialTarget)) && focusElement(explicitInitialTarget)) return true;
      const firstTarget = buildFlowTargets(root)[0];
      if(firstTarget) return focusElement(firstTarget);
      return false;
    }

    function onKeydown(event){
      if(event.defaultPrevented || event.isComposing || event.altKey || event.ctrlKey || event.metaKey) return;
      const control = resolveInteractiveElement(event.target, root);
      if(!control) return;
      const pickerApi = getInlinePickerApi(control);

      if(event.key === 'Tab'){
        const step = event.shiftKey ? -1 : 1;
        const isPopoverControl = isInlinePickerPopoverControl(control);
        const pickerTrigger = pickerApi && typeof pickerApi.getTrigger === 'function' ? pickerApi.getTrigger() : null;
        const shouldClosePicker = Boolean(pickerApi && typeof pickerApi.close === 'function' && (
          isPopoverControl
          || (isInlinePickerTrigger(control) && typeof pickerApi.isOpen === 'function' && pickerApi.isOpen())
        ));
        const referenceElement = pickerTrigger instanceof HTMLElement && root.contains(pickerTrigger)
          ? pickerTrigger
          : control;
        const focusNextTabTarget = () => {
          if(focusRelativeFlowTarget(root, control, step, {
            footerOrder: 'dom',
            clamp: true,
            referenceElement
          })) return;
          focusElement(referenceElement);
        };

        event.preventDefault();
        event.stopPropagation();

        if(shouldClosePicker){
          pickerApi.close();
          requestAnimationFrame(focusNextTabTarget);
          return;
        }

        focusNextTabTarget();
        return;
      }

      if(event.key === 'Enter' || event.key === 'NumpadEnter'){
        if(isInlinePickerOption(control)){
          event.preventDefault();
          const step = event.shiftKey ? -1 : 1;
          if(pickerApi && typeof pickerApi.prepareKeyboardSelection === 'function'){
            pickerApi.prepareKeyboardSelection(step);
          }
          const anchor = pickerApi && typeof pickerApi.getTrigger === 'function' ? pickerApi.getTrigger() : control;
          triggerElementPress(control);
          queueRelativeFlowFocus(root, anchor, step);
          return;
        }

        if(isInlinePickerTrigger(control)){
          if(event.shiftKey){
            event.preventDefault();
            if(pickerApi && typeof pickerApi.clearCommittedSelection === 'function'){
              pickerApi.clearCommittedSelection();
            }
            focusRelativeFlowTarget(root, control, -1);
            return;
          }
          if(pickerApi && typeof pickerApi.consumeCommittedSelection === 'function' && pickerApi.consumeCommittedSelection()){
            event.preventDefault();
            focusRelativeFlowTarget(root, control, 1);
            return;
          }
          if(pickerApi && typeof pickerApi.openForKeyboard === 'function'){
            event.preventDefault();
            pickerApi.openForKeyboard();
            return;
          }
        }

        if(isEnterFlowTarget(control)){
          event.preventDefault();
          focusRelativeFlowTarget(root, control, event.shiftKey ? -1 : 1);
          return;
        }
      }

      if(!event.shiftKey && (event.key === 'ArrowLeft' || event.key === 'ArrowRight') && isInlinePickerTrigger(control) && pickerApi && typeof pickerApi.stepValue === 'function'){
        if(typeof pickerApi.isOpen !== 'function' || !pickerApi.isOpen()){
          event.preventDefault();
          const didStepValue = pickerApi.stepValue(event.key === 'ArrowRight' ? 1 : -1);
          if(didStepValue && typeof pickerApi.markCommittedSelection === 'function') pickerApi.markCommittedSelection();
          else if(!didStepValue && typeof pickerApi.clearCommittedSelection === 'function') pickerApi.clearCommittedSelection();
          return;
        }
      }

      if(event.shiftKey) return;
      if(!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) return;
      if(!(control instanceof HTMLButtonElement) && control.getAttribute('role') !== 'option') return;

      const group = resolveArrowGroup(control, root, event.key);
      if(!group) return;
      const candidates = collectArrowTargets(group);
      if(candidates.length < 2) return;
      const nextTarget = findDirectionalTarget(control, candidates, event.key);
      if(!nextTarget) return;

      event.preventDefault();
      focusElement(nextTarget);
    }

    root.addEventListener('keydown', onKeydown, true);

    if(autoFocus){
      initialFocusFrame = requestAnimationFrame(() => {
        initialFocusFrame = 0;
        focusInitialTarget();
      });
    }

    const cleanup = () => {
      if(initialFocusFrame){
        cancelAnimationFrame(initialFocusFrame);
        initialFocusFrame = 0;
      }
      root.removeEventListener('keydown', onKeydown, true);
      delete root.dataset.taifFormNavigationBound;
    };

    cleanup.focusInitialTarget = focusInitialTarget;
    cleanup.focusTarget = focusElement;
    return cleanup;
  }

  function getPrimaryWorkspaceRect(preferredRoot = null){
    const workspace = (preferredRoot instanceof Element && preferredRoot.isConnected)
      ? preferredRoot
      : document.getElementById('panel') || document.querySelector('.content');

    if(!(workspace instanceof Element) || typeof workspace.getBoundingClientRect !== 'function') return null;

    const rect = workspace.getBoundingClientRect();
    const width = Math.round(rect.width);
    const height = Math.round(rect.height);
    if(width < 40 || height < 40) return null;

    return {
      left: Math.round(rect.left),
      top: Math.round(rect.top),
      width,
      height
    };
  }

  function getModalViewportBoundsForSize(width, height){
    if(typeof getViewportBoundsForSize === 'function'){
      return getViewportBoundsForSize(width, height, 12);
    }
    return { minLeft:12, maxLeft:12, minTop:12, maxTop:12 };
  }

  function getModalViewportBounds(modal){
    const rect = modal.getBoundingClientRect();
    return getModalViewportBoundsForSize(rect.width, rect.height);
  }

  function clearModalMaximizedFrame(modal){
    if(typeof clearSharedModalMaximizedFrame === 'function') return clearSharedModalMaximizedFrame(modal);
    modal.style.removeProperty('width');
    modal.style.removeProperty('max-width');
    modal.style.removeProperty('height');
    modal.style.removeProperty('max-height');
  }

  function maximizeModalWindow(modal, applyModalMaximizedFrame){
    const rect = modal.getBoundingClientRect();
    modal.dataset.restoreLeft = modal.dataset.windowLeft || String(Math.round(rect.left));
    modal.dataset.restoreTop = modal.dataset.windowTop || String(Math.round(rect.top));
    applyModalMaximizedFrame(modal);
    modal.classList.add('is-maximized');
  }

  function restoreModalWindow(modal, { clearModalMaximizedFrame: clearFrame = clearModalMaximizedFrame, applyModalPosition, positionModalAtCascade } = {}){
    modal.classList.remove('is-maximized');
    clearFrame(modal);
    void modal.offsetWidth;

    const restoreLeft = Number(modal.dataset.restoreLeft);
    const restoreTop = Number(modal.dataset.restoreTop);
    if(Number.isFinite(restoreLeft) && Number.isFinite(restoreTop)){
      applyModalPosition(modal, restoreLeft, restoreTop);
      return;
    }

    positionModalAtCascade(modal);
  }

  function syncModalWithinViewport(modal, { applyModalMaximizedFrame, applyModalPosition, positionModalAtCascade } = {}){
    if(modal.classList.contains('is-maximized')){
      applyModalMaximizedFrame(modal);
      return;
    }

    const currentLeft = Number(modal.dataset.windowLeft);
    const currentTop = Number(modal.dataset.windowTop);
    if(Number.isFinite(currentLeft) && Number.isFinite(currentTop)){
      applyModalPosition(modal, currentLeft, currentTop);
      return;
    }

    positionModalAtCascade(modal);
  }

  function createModalViewportApi({ applyModalMaximizedFrame, applyModalPosition, positionModalAtCascade } = {}){
    return {
      getModalViewportBoundsForSize,
      getModalViewportBounds,
      clearModalMaximizedFrame,
      maximizeModalWindow(modal){
        maximizeModalWindow(modal, applyModalMaximizedFrame);
      },
      restoreModalWindow(modal){
        restoreModalWindow(modal, { clearModalMaximizedFrame, applyModalPosition, positionModalAtCascade });
      },
      syncModalWithinViewport(modal){
        syncModalWithinViewport(modal, { applyModalMaximizedFrame, applyModalPosition, positionModalAtCascade });
      }
    };
  }

  function toggleModalExpand({ modal, expandButton, maximizeModalWindow, restoreModalWindow, syncExpandButton, activateModalWindow } = {}){
    if(!expandButton) return false;
    if(modal.classList.contains('is-maximized')) restoreModalWindow(modal);
    else maximizeModalWindow(modal);
    if(typeof syncExpandButton === 'function') syncExpandButton();
    if(typeof activateModalWindow === 'function') activateModalWindow();
    return true;
  }

  function createToggleExpandHandler(options){
    return function handleToggleExpand(){
      return toggleModalExpand(options);
    };
  }

  function bindWindowChrome(options){
    const windowElement = options && options.windowElement;
    const expandButton = options && options.expandButton;
    const closeButton = options && options.closeButton;
    const onClose = options && options.onClose;
    const onToggle = options && options.onToggle;
    const isActive = typeof (options && options.isActive) === 'function' ? options.isActive : (() => !!(windowElement && windowElement.isConnected));

    if(!windowElement) return () => {};

    primeCloseButton(closeButton);
    syncExpandButton(expandButton, windowElement.classList.contains('is-maximized'));

    function stopPointer(event){
      if(typeof stopEventPropagation === 'function'){
        stopEventPropagation(event);
        return;
      }
      event.stopPropagation();
    }

    function toggle(event){
      if(event){
        event.preventDefault();
        event.stopPropagation();
      }
      const isMaximized = windowElement.classList.toggle('is-maximized');
      syncExpandButton(expandButton, isMaximized);
      if(typeof onToggle === 'function') onToggle(isMaximized, windowElement);
    }

    function handleClose(event){
      if(typeof onClose === 'function') onClose(event);
    }

    function handleKeydown(event){
      if(!isActive()) return;
      if(!expandButton) return;
      if(event.key === 'F11' || (event.altKey && event.key === 'Enter')){
        event.preventDefault();
        toggle();
      }
    }

    expandButton?.addEventListener('click', toggle);
    expandButton?.addEventListener('pointerdown', stopPointer, true);
    closeButton?.addEventListener('click', handleClose);
    closeButton?.addEventListener('pointerdown', stopPointer, true);
    document.addEventListener('keydown', handleKeydown);

    return () => {
      expandButton?.removeEventListener('click', toggle);
      expandButton?.removeEventListener('pointerdown', stopPointer, true);
      closeButton?.removeEventListener('click', handleClose);
      closeButton?.removeEventListener('pointerdown', stopPointer, true);
      document.removeEventListener('keydown', handleKeydown);
    };
  }

  chrome.getIconMarkup = chrome.getIconMarkup || getIconMarkup;
  chrome.syncExpandButton = chrome.syncExpandButton || syncExpandButton;
  chrome.primeCloseButton = chrome.primeCloseButton || primeCloseButton;
  chrome.isElementVisible = chrome.isElementVisible || isElementVisible;
  chrome.focusElement = chrome.focusElement || focusElement;
  chrome.findDirectionalTarget = chrome.findDirectionalTarget || findDirectionalTarget;
  chrome.triggerElementPress = chrome.triggerElementPress || triggerElementPress;
  chrome.getPrimaryWorkspaceRect = chrome.getPrimaryWorkspaceRect || getPrimaryWorkspaceRect;
  chrome.getModalViewportBoundsForSize = chrome.getModalViewportBoundsForSize || getModalViewportBoundsForSize;
  chrome.getModalViewportBounds = chrome.getModalViewportBounds || getModalViewportBounds;
  chrome.clearModalMaximizedFrame = chrome.clearModalMaximizedFrame || clearModalMaximizedFrame;
  chrome.maximizeModalWindow = chrome.maximizeModalWindow || maximizeModalWindow;
  chrome.restoreModalWindow = chrome.restoreModalWindow || restoreModalWindow;
  chrome.syncModalWithinViewport = chrome.syncModalWithinViewport || syncModalWithinViewport;
  chrome.createModalViewportApi = chrome.createModalViewportApi || createModalViewportApi;
  chrome.toggleModalExpand = chrome.toggleModalExpand || toggleModalExpand;
  chrome.createToggleExpandHandler = chrome.createToggleExpandHandler || createToggleExpandHandler;
  chrome.bindWindowChrome = chrome.bindWindowChrome || bindWindowChrome;
  chrome.bindFormNavigation = chrome.bindFormNavigation || bindFormNavigation;
})();
