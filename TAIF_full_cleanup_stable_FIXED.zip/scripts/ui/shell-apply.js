(()=>{
  const TAIF = window.TAIF;
  const { escapeHtml } = TAIF.core.utils;
  const DETAIL_TITLE_SELECTOR = '[data-taif-detail-title="true"]';


  function normalizeLabel(value){
    return String(value ?? '').replace(/\s+/g, ' ').trim();
  }

  function isElementVisible(element){
    if(!(element instanceof HTMLElement)) return false;
    if(element.hidden) return false;
    if(element.closest('[hidden], [aria-hidden="true"]')) return false;
    const style = window.getComputedStyle(element);
    if(style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity || '1') === 0) return false;
    return element.getClientRects().length > 0;
  }

  function getViewLabel(viewId){
    const safeViewId = normalizeLabel(viewId);
    const views = Array.isArray(TAIF?.config?.views) ? TAIF.config.views : [];
    const view = views.find((entry) => normalizeLabel(entry?.id) === safeViewId);
    return normalizeLabel(view?.label || safeViewId || 'لوحة التحكم') || 'لوحة التحكم';
  }

  function getSafeDocument(){
    if(typeof document === 'undefined' || !document || typeof document.querySelectorAll !== 'function') return null;
    return document;
  }

  function resolveDetailTitle(){
    const safeDocument = getSafeDocument();
    if(!safeDocument) return '';
    const candidates = Array.from(safeDocument.querySelectorAll(DETAIL_TITLE_SELECTOR))
      .filter(isElementVisible)
      .map((element) => normalizeLabel(element.textContent))
      .filter(Boolean);
    return candidates.length ? candidates[candidates.length - 1] : '';
  }

  function normalizeLooseLabel(value){
    return normalizeLabel(value)
      .replace(/[ةه]$/u, '')
      .replace(/ى$/u, 'ي');
  }

  function isKnownViewLabel(label){
    const safeLabel = normalizeLabel(label);
    if(!safeLabel) return false;
    const safeLooseLabel = normalizeLooseLabel(safeLabel);
    const views = Array.isArray(TAIF?.config?.views) ? TAIF.config.views : [];
    return views.some((view) => {
      const viewLabel = normalizeLabel(view?.label);
      return viewLabel === safeLabel || normalizeLooseLabel(viewLabel) === safeLooseLabel;
    });
  }

  function buildPathParts(viewLabel, detailLabel){
    const base = normalizeLabel(viewLabel) || 'لوحة التحكم';
    const detail = normalizeLabel(detailLabel);
    if(!detail || detail === base) return [base];
    if(isKnownViewLabel(detail)) return [detail];
    return [base, detail];
  }

  function buildTrailMarkup(parts){
    if(!Array.isArray(parts) || !parts.length) return '';
    return `
      <div class="content-trail__path">
        ${parts.map((part, index) => `${index ? '<span class="content-trail__separator" aria-hidden="true"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 4.5 7.5 10 13 15.5"></path></svg></span>' : ''}<span class="content-trail__segment" title="${escapeHtml(part)}">${escapeHtml(part)}</span>`).join('')}
      </div>
    `;
  }

  function renderContentTrail(root, dom){
    const trail = dom?.contentTrail;
    if(!(trail instanceof HTMLElement)) return;
    const viewLabel = getViewLabel(root?.dataset?.view);
    const detailLabel = resolveDetailTitle();
    const parts = buildPathParts(viewLabel, detailLabel);
    const signature = parts.join(' | ');
    if(trail.dataset.signature === signature) return;
    trail.dataset.signature = signature;
    trail.innerHTML = buildTrailMarkup(parts);
  }

  function ensureContentTrailObserver(root, dom){
    const trail = dom?.contentTrail;
    const safeDocument = getSafeDocument();
    if(!(trail instanceof HTMLElement) || trail.__taifTrailObserverBound || !safeDocument?.body) return;

    let frameId = 0;
    const scheduleRender = () => {
      if(!trail.isConnected) return;
      if(frameId) cancelAnimationFrame(frameId);
      frameId = requestAnimationFrame(() => {
        frameId = 0;
        if(!trail.isConnected) return;
        renderContentTrail(root, dom);
      });
    };

    const observer = new MutationObserver(scheduleRender);
    observer.observe(safeDocument.body, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ['class', 'style', 'hidden', 'aria-hidden', 'open']
    });

    const teardownObserver = () => {
      if(frameId) cancelAnimationFrame(frameId);
      frameId = 0;
      try{ observer.disconnect(); }catch{}
    };

    trail.__taifTrailObserverBound = true;
    trail.__taifTrailObserver = observer;
    trail.__taifTrailScheduleRender = scheduleRender;
    window.addEventListener('resize', scheduleRender, { passive: true });
    window.addEventListener('beforeunload', teardownObserver, { once:true });
  }

  TAIF.ui.shell.apply = function(root, dom, state){
    if(!(root instanceof HTMLElement) || !state || typeof state !== 'object') return;
    const panel = dom?.panel instanceof HTMLElement ? dom.panel : null;
    const nav = dom?.nav instanceof HTMLElement ? dom.nav : null;
    const btnToggle = dom?.btnToggle instanceof HTMLElement ? dom.btnToggle : null;

    root.dataset.sidebar = state.sidebarCollapsed ? 'collapsed' : 'open';
    root.dataset.view = state.activeView;
    root.dataset.activeView = state.activeView;
    if(document.body) document.body.dataset.activeView = state.activeView;
    if(panel) panel.dataset.requestedView = state.activeView;
    if(nav && typeof TAIF?.ui?.nav?.setActive === 'function') TAIF.ui.nav.setActive(nav, state.activeView);
    if(btnToggle){
      btnToggle.setAttribute('aria-expanded', String(!state.sidebarCollapsed));
      btnToggle.setAttribute('title', state.sidebarCollapsed ? 'توسيع' : 'تصغير');
    }
    ensureContentTrailObserver(root, dom);
    renderContentTrail(root, dom);
  };
})();
