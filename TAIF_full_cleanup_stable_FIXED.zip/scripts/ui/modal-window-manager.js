(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.ui = TAIF.ui || {};
  const windowChrome = TAIF.ui.windowChrome || (TAIF.ui.windowChrome = {});
  const windowSystem = TAIF.ui.windowSystem || {};
  const { getViewportBoundsForSize, clearModalMaximizedFrame: clearSharedModalMaximizedFrame, clampNumber: clampDefault } = TAIF.core.utils;

  function getFallbackViewportBoundsForSize(width, height){
    if(typeof getViewportBoundsForSize === 'function'){
      return getViewportBoundsForSize(width, height, 12);
    }
    return { minLeft:12, maxLeft:12, minTop:12, maxTop:12 };
  }

  function createViewportApi({ applyModalMaximizedFrame, applyModalPosition, positionModalAtCascade } = {}){
    const getModalViewportBoundsForSize = typeof windowChrome.getModalViewportBoundsForSize === 'function'
      ? windowChrome.getModalViewportBoundsForSize.bind(windowChrome)
      : getFallbackViewportBoundsForSize;
    const getModalViewportBounds = typeof windowChrome.getModalViewportBounds === 'function'
      ? windowChrome.getModalViewportBounds.bind(windowChrome)
      : ((modal) => {
          const rect = modal.getBoundingClientRect();
          return getModalViewportBoundsForSize(rect.width, rect.height);
        });

    if(typeof windowChrome.createModalViewportApi === 'function'){
      return {
        getModalViewportBoundsForSize,
        getModalViewportBounds,
        ...windowChrome.createModalViewportApi({
          applyModalMaximizedFrame,
          applyModalPosition,
          positionModalAtCascade
        })
      };
    }

    const clearModalMaximizedFrame = clearSharedModalMaximizedFrame;

    function maximizeModalWindow(modal){
      const rect = modal.getBoundingClientRect();
      modal.dataset.restoreLeft = modal.dataset.windowLeft || String(Math.round(rect.left));
      modal.dataset.restoreTop = modal.dataset.windowTop || String(Math.round(rect.top));
      applyModalMaximizedFrame(modal);
      modal.classList.add('is-maximized');
    }

    function restoreModalWindow(modal){
      modal.classList.remove('is-maximized');
      clearModalMaximizedFrame(modal);
      void modal.offsetWidth;

      const restoreLeft = Number(modal.dataset.restoreLeft);
      const restoreTop = Number(modal.dataset.restoreTop);
      if(Number.isFinite(restoreLeft) && Number.isFinite(restoreTop)){
        applyModalPosition(modal, restoreLeft, restoreTop);
        return;
      }

      positionModalAtCascade(modal);
    }

    function syncModalWithinViewport(modal){
      if(modal.classList.contains('is-maximized')){
        applyModalMaximizedFrame(modal);
        return;
      }

      const currentLeft = Number(modal.dataset.windowLeft);
      const currentTop = Number(modal.dataset.windowTop);
      if(Number.isFinite(currentLeft) && Number.isFinite(currentTop)){
        applyModalPosition(modal, currentLeft, currentTop);
        return;
      }

      positionModalAtCascade(modal);
    }

    return {
      getModalViewportBoundsForSize,
      getModalViewportBounds,
      clearModalMaximizedFrame,
      maximizeModalWindow,
      restoreModalWindow,
      syncModalWithinViewport
    };
  }

  function createModalWindowManager({
    runtime = null,
    layerSelector = '',
    layerClassName = '',
    backdropSelector = '',
    modalSelector = '',
    dragHandleSelector = '',
    dragBlockSelectors = '',
    bodyDraggingClass = '',
    clamp = null,
    getWorkspace = null,
    getCascadeSlotLimit = null,
    getDragInitialPoint = null,
    onPositionApplied = null,
    baseZIndex = 2398,
    ownerView = ''
  } = {}){
    const safeRuntime = runtime && typeof runtime === 'object' ? runtime : {};
    const clampValue = typeof clamp === 'function' ? clamp : clampDefault;
    safeRuntime.modalStack = Array.isArray(safeRuntime.modalStack) ? safeRuntime.modalStack : [];
    safeRuntime.modalZIndex = Number(safeRuntime.modalZIndex) || baseZIndex;

    const getModalFromBackdrop = (backdrop) => (
      backdrop && typeof backdrop.querySelector === 'function'
        ? backdrop.querySelector(modalSelector)
        : null
    );

    function markOwnedNode(node){
      if(!(node instanceof HTMLElement)) return node;
      const marker = TAIF?.core?.utils?.markOwnedNode;
      if(typeof marker === 'function') return marker(node, ownerView);
      const safeOwnerView = String(ownerView || '').trim();
      if(safeOwnerView){
        node.dataset.ownerView = safeOwnerView;
        node.setAttribute('data-owner-view', safeOwnerView);
      }
      return node;
    }

    function registerWindowSystemLayer(layer){
      if(!(layer instanceof HTMLElement)) return layer;
      if(typeof windowSystem.registerLayer === 'function'){
        try{
          windowSystem.registerLayer(layer, {
            ownerView,
            source:'modal-window-manager',
            className:layerClassName
          });
        }catch{}
      }
      return layer;
    }

    function registerWindowSystemBackdrop(backdrop){
      if(!(backdrop instanceof HTMLElement)) return backdrop;
      if(typeof windowSystem.registerWindow === 'function'){
        try{
          windowSystem.registerWindow({
            layer:(safeRuntime.modalLayer && safeRuntime.modalLayer.isConnected) ? safeRuntime.modalLayer : document.querySelector(layerSelector),
            backdrop,
            modal:getModalFromBackdrop(backdrop),
            ownerView,
            source:'modal-window-manager'
          });
        }catch{}
      }
      return backdrop;
    }

    function disposeManagedLayerChildNode(node){
      if(!(node instanceof HTMLElement)) return;
      const cleanup = node.__cleanup;
      try{ node.__cleanup = null; }catch{}
      if(typeof cleanup === 'function'){
        try{ cleanup(); }catch{}
      }
      if(node.isConnected){
        try{ node.remove(); }catch{}
      }
    }

    function disposeBackdropNode(node){
      disposeManagedLayerChildNode(node);
    }

    function dismissOverlays(){
      const layer = (safeRuntime.modalLayer && safeRuntime.modalLayer.isConnected)
        ? safeRuntime.modalLayer
        : document.querySelector(layerSelector);

      if(!layer){
        cleanupModalRegistry();
        return;
      }

      Array.from(layer.children).forEach((node) => {
        if(!(node instanceof HTMLElement)) return;
        if(node.matches(backdropSelector)) disposeBackdropNode(node);
        else disposeManagedLayerChildNode(node);
      });
      cleanupModalRegistry();
    }

    function ensureModalLayer(){
      if(safeRuntime.modalLayer && safeRuntime.modalLayer.isConnected) return safeRuntime.modalLayer;

      let layer = document.querySelector(layerSelector);
      if(!(layer instanceof HTMLElement)) layer = null;
      if(!layer){
        layer = document.createElement('div');
        layer.className = layerClassName;
        markOwnedNode(layer);
        document.body.appendChild(layer);
      }else{
        markOwnedNode(layer);
      }

      safeRuntime.modalLayer = layer;
      registerWindowSystemLayer(layer);
      return layer;
    }

    function cleanupModalRegistry(){
      safeRuntime.modalStack = (Array.isArray(safeRuntime.modalStack) ? safeRuntime.modalStack : [])
        .filter((entry) => entry && entry.backdrop && entry.backdrop.isConnected);

      const activeLayer = (safeRuntime.modalLayer && safeRuntime.modalLayer.isConnected)
        ? safeRuntime.modalLayer
        : document.querySelector(layerSelector);

      if(activeLayer instanceof HTMLElement){
        const trackedBackdrops = new Set(
          (Array.isArray(safeRuntime.modalStack) ? safeRuntime.modalStack : [])
            .map((entry) => entry && entry.backdrop)
            .filter((backdrop) => backdrop instanceof HTMLElement)
        );

        Array.from(activeLayer.children).forEach((node) => {
          if(!(node instanceof HTMLElement) || trackedBackdrops.has(node)) return;
          if(node.matches(backdropSelector)) disposeBackdropNode(node);
          else disposeManagedLayerChildNode(node);
        });
      }

      if(safeRuntime.modalStack.length) return;
      if(activeLayer instanceof HTMLElement && activeLayer.childElementCount === 0){
        activeLayer.remove();
      }
      safeRuntime.modalLayer = null;
      safeRuntime.modalZIndex = baseZIndex;
    }

    function readModalWindowSlot(target){
      const rawValue = target?.dataset?.windowSlot;
      const slot = Number(rawValue);
      return Number.isInteger(slot) && slot >= 0 ? slot : null;
    }

    function assignModalWindowSlot(backdrop){
      const existingSlot = readModalWindowSlot(backdrop);
      if(existingSlot !== null){
        const existingModal = getModalFromBackdrop(backdrop);
        if(existingModal) existingModal.dataset.windowSlot = String(existingSlot);
        return existingSlot;
      }

      const usedSlots = new Set();
      (Array.isArray(safeRuntime.modalStack) ? safeRuntime.modalStack : []).forEach((entry) => {
        if(!entry || !entry.backdrop || entry.backdrop === backdrop) return;
        const slot = readModalWindowSlot(entry.backdrop);
        if(slot !== null) usedSlots.add(slot);
      });

      let nextSlot = 0;
      while(usedSlots.has(nextSlot)) nextSlot += 1;

      backdrop.dataset.windowSlot = String(nextSlot);
      const modal = getModalFromBackdrop(backdrop);
      if(modal) modal.dataset.windowSlot = String(nextSlot);
      return nextSlot;
    }

    function releaseModalWindowSlot(backdrop){
      if(backdrop?.removeAttribute) backdrop.removeAttribute('data-window-slot');
      const modal = getModalFromBackdrop(backdrop);
      if(modal) modal.removeAttribute('data-window-slot');
    }

    function registerModalWindow(backdrop){
      if(!(backdrop instanceof HTMLElement)) return;
      markOwnedNode(backdrop);
      markOwnedNode(getModalFromBackdrop(backdrop));
      assignModalWindowSlot(backdrop);
      registerWindowSystemBackdrop(backdrop);
      safeRuntime.modalStack = (Array.isArray(safeRuntime.modalStack) ? safeRuntime.modalStack : [])
        .filter((entry) => entry && entry.backdrop !== backdrop);
      safeRuntime.modalStack.push({ backdrop });
      cleanupModalRegistry();
      activateModalWindow(backdrop);
    }

    function unregisterModalWindow(backdrop){
      releaseModalWindowSlot(backdrop);
      safeRuntime.modalStack = (Array.isArray(safeRuntime.modalStack) ? safeRuntime.modalStack : [])
        .filter((entry) => entry.backdrop !== backdrop);
      safeRuntime.modalStack.forEach((entry) => {
        entry.backdrop.classList.remove('is-window-active');
      });

      const nextTop = safeRuntime.modalStack[safeRuntime.modalStack.length - 1];
      if(nextTop) activateModalWindow(nextTop.backdrop);
      else cleanupModalRegistry();
    }

    function bringModalLayerToFront(){
      const layer = (safeRuntime.modalLayer && safeRuntime.modalLayer.isConnected)
        ? safeRuntime.modalLayer
        : document.querySelector(layerSelector);
      if(!(layer instanceof HTMLElement) || layer.parentNode !== document.body) return;
      if(document.body.lastElementChild === layer) return;
      document.body.appendChild(layer);
      safeRuntime.modalLayer = layer;
    }

    function activateModalWindow(backdrop){
      cleanupModalRegistry();
      const target = (Array.isArray(safeRuntime.modalStack) ? safeRuntime.modalStack : [])
        .find((entry) => entry.backdrop === backdrop);
      if(!target) return;

      bringModalLayerToFront();
      safeRuntime.modalZIndex = Number(safeRuntime.modalZIndex) || baseZIndex;
      safeRuntime.modalZIndex += 2;
      backdrop.style.zIndex = String(safeRuntime.modalZIndex);

      safeRuntime.modalStack.forEach((entry) => {
        entry.backdrop.classList.toggle('is-window-active', entry.backdrop === backdrop);
      });

      safeRuntime.modalStack = safeRuntime.modalStack.filter((entry) => entry.backdrop !== backdrop);
      safeRuntime.modalStack.push(target);
    }

    function isTopmostModal(backdrop){
      cleanupModalRegistry();
      return !!(safeRuntime.modalStack && safeRuntime.modalStack.length && safeRuntime.modalStack[safeRuntime.modalStack.length - 1].backdrop === backdrop);
    }

    const getModalViewportBoundsForSize = typeof windowChrome.getModalViewportBoundsForSize === 'function'
      ? windowChrome.getModalViewportBoundsForSize.bind(windowChrome)
      : getFallbackViewportBoundsForSize;
    const getModalViewportBounds = typeof windowChrome.getModalViewportBounds === 'function'
      ? windowChrome.getModalViewportBounds.bind(windowChrome)
      : ((modal) => {
          const rect = modal.getBoundingClientRect();
          return getModalViewportBoundsForSize(rect.width, rect.height);
        });

    function applyModalPosition(modal, left, top, presetBounds = null){
      const bounds = presetBounds || getModalViewportBounds(modal);
      const nextLeft = clampValue(Number(left) || 0, bounds.minLeft, bounds.maxLeft);
      const nextTop = clampValue(Number(top) || 0, bounds.minTop, bounds.maxTop);
      const roundedLeft = Math.round(nextLeft);
      const roundedTop = Math.round(nextTop);

      modal.style.left = `${roundedLeft}px`;
      modal.style.top = `${roundedTop}px`;
      modal.dataset.windowLeft = String(roundedLeft);
      modal.dataset.windowTop = String(roundedTop);
      modal.classList.add('is-positioned');
      if(typeof onPositionApplied === 'function') onPositionApplied(modal, { left:roundedLeft, top:roundedTop });
    }

    function getPrimaryWorkspaceRect(){
      if(typeof windowChrome.getPrimaryWorkspaceRect === 'function') return windowChrome.getPrimaryWorkspaceRect(typeof getWorkspace === 'function' ? getWorkspace() : null);

      const workspace = typeof getWorkspace === 'function' ? getWorkspace() : null;
      if(!(workspace instanceof Element) || typeof workspace.getBoundingClientRect !== 'function') return null;
      const rect = workspace.getBoundingClientRect();
      const width = Math.round(rect.width);
      const height = Math.round(rect.height);
      if(width < 40 || height < 40) return null;

      return { left:Math.round(rect.left), top:Math.round(rect.top), width, height };
    }

    function positionModalAtCascade(modal){
      const rect = modal.getBoundingClientRect();
      const slot = readModalWindowSlot(modal);
      const slotLimit = Math.max(Number(typeof getCascadeSlotLimit === 'function' ? getCascadeSlotLimit() : safeRuntime.modalCascadeSlots) || 0, 1);
      const offsetIndex = (slot !== null ? slot : 0) % slotLimit;
      const preferredTopShift = Number(modal?.dataset?.cascadeTopShift);
      const topShift = Number.isFinite(preferredTopShift) ? preferredTopShift : 0;
      const preferredLeftShift = Number(modal?.dataset?.cascadeLeftShift);
      const leftShift = Number.isFinite(preferredLeftShift) ? preferredLeftShift : 0;

      const centeredLeft = (window.innerWidth - rect.width) / 2;
      const centeredTop = (window.innerHeight - rect.height) / 2;
      const offsetLeft = offsetIndex * 28;
      const offsetTop = offsetIndex * 24;

      applyModalPosition(modal, centeredLeft + offsetLeft + leftShift, centeredTop + offsetTop + topShift);
    }

    function getModalMaximizedFrame(){
      const workspaceRect = getPrimaryWorkspaceRect();
      if(workspaceRect) return workspaceRect;

      return {
        left: 12,
        top: 12,
        width: Math.max(320, Math.round(window.innerWidth - 24)),
        height: Math.max(220, Math.round(window.innerHeight - 24))
      };
    }

    function applyModalMaximizedFrame(modal){
      const frame = getModalMaximizedFrame();
      modal.style.width = `${frame.width}px`;
      modal.style.maxWidth = `${frame.width}px`;
      modal.style.height = `${frame.height}px`;
      modal.style.maxHeight = `${frame.height}px`;

      applyModalPosition(modal, frame.left, frame.top, {
        minLeft: frame.left,
        maxLeft: frame.left,
        minTop: frame.top,
        maxTop: frame.top
      });
    }

    const modalViewportApi = createViewportApi({
      applyModalMaximizedFrame,
      applyModalPosition,
      positionModalAtCascade
    });
    const clearModalMaximizedFrame = modalViewportApi.clearModalMaximizedFrame;
    const maximizeModalWindow = modalViewportApi.maximizeModalWindow;
    const restoreModalWindow = modalViewportApi.restoreModalWindow;
    const syncModalWithinViewport = modalViewportApi.syncModalWithinViewport;

    function bindModalDragging({ backdrop, modal }){
      const handle = modal.querySelector(dragHandleSelector);
      if(!(handle instanceof HTMLElement)) return () => {};

      let dragState = null;

      function releaseDragState(event){
        if(!dragState) return;
        if(event && typeof event.pointerId === 'number' && dragState.pointerId !== event.pointerId) return;

        handle.classList.remove('is-grabbing');
        backdrop.classList.remove('is-dragging');
        if(bodyDraggingClass) document.body.classList.remove(bodyDraggingClass);
        document.removeEventListener('pointermove', onPointerMove, true);
        document.removeEventListener('pointerup', onPointerUp, true);
        document.removeEventListener('pointercancel', onPointerUp, true);

        try{
          handle.releasePointerCapture(dragState.pointerId);
        }catch{}

        dragState = null;
      }

      function onPointerMove(event){
        if(!dragState || dragState.pointerId !== event.pointerId) return;
        if(modal.classList.contains('is-maximized')){
          releaseDragState(event);
          return;
        }

        const coalescedEvents = typeof event.getCoalescedEvents === 'function' ? event.getCoalescedEvents() : null;
        const moveEvent = coalescedEvents && coalescedEvents.length ? coalescedEvents[coalescedEvents.length - 1] : event;
        const deltaX = moveEvent.clientX - dragState.startX;
        const deltaY = moveEvent.clientY - dragState.startY;
        if(!dragState.hasMoved && Math.hypot(deltaX, deltaY) < 2) return;

        if(!dragState.hasMoved){
          dragState.hasMoved = true;
          handle.classList.add('is-grabbing');
          backdrop.classList.add('is-dragging');
          if(bodyDraggingClass) document.body.classList.add(bodyDraggingClass);
        }

        event.preventDefault();
        dragState.nextLeft = clampValue(dragState.originLeft + deltaX, dragState.bounds.minLeft, dragState.bounds.maxLeft);
        dragState.nextTop = clampValue(dragState.originTop + deltaY, dragState.bounds.minTop, dragState.bounds.maxTop);
        applyModalPosition(modal, dragState.nextLeft, dragState.nextTop, dragState.bounds);
      }

      function onPointerUp(event){
        releaseDragState(event);
      }

      function onPointerDown(event){
        if(event.button !== 0) return;
        if(modal.classList.contains('is-maximized')) return;

        const target = event.target;
        if(!(target instanceof Element)) return;
        if(dragBlockSelectors && target.closest(dragBlockSelectors)) return;

        activateModalWindow(backdrop);
        const rect = modal.getBoundingClientRect();
        const initialPoint = typeof getDragInitialPoint === 'function'
          ? getDragInitialPoint({ backdrop, modal, rect })
          : {
              left: Number.isFinite(Number(modal.dataset.windowLeft)) ? Number(modal.dataset.windowLeft) : rect.left,
              top: Number.isFinite(Number(modal.dataset.windowTop)) ? Number(modal.dataset.windowTop) : rect.top
            };

        dragState = {
          pointerId: event.pointerId,
          startX: event.clientX,
          startY: event.clientY,
          originLeft: Number.isFinite(Number(initialPoint?.left)) ? Number(initialPoint.left) : rect.left,
          originTop: Number.isFinite(Number(initialPoint?.top)) ? Number(initialPoint.top) : rect.top,
          nextLeft: Number.isFinite(Number(initialPoint?.left)) ? Number(initialPoint.left) : rect.left,
          nextTop: Number.isFinite(Number(initialPoint?.top)) ? Number(initialPoint.top) : rect.top,
          bounds: getModalViewportBoundsForSize(rect.width, rect.height),
          hasMoved: false
        };

        try{
          handle.setPointerCapture(event.pointerId);
        }catch{}

        event.preventDefault();
        document.removeEventListener('pointermove', onPointerMove, true);
        document.removeEventListener('pointerup', onPointerUp, true);
        document.removeEventListener('pointercancel', onPointerUp, true);
        document.addEventListener('pointermove', onPointerMove, true);
        document.addEventListener('pointerup', onPointerUp, true);
        document.addEventListener('pointercancel', onPointerUp, true);
      }

      handle.addEventListener('pointerdown', onPointerDown);

      return () => {
        handle.removeEventListener('pointerdown', onPointerDown);
        releaseDragState();
      };
    }

    return {
      dismissOverlays,
      ensureModalLayer,
      cleanupModalRegistry,
      readModalWindowSlot,
      assignModalWindowSlot,
      releaseModalWindowSlot,
      registerModalWindow,
      unregisterModalWindow,
      activateModalWindow,
      isTopmostModal,
      clamp: clampValue,
      getModalViewportBoundsForSize,
      getModalViewportBounds,
      applyModalPosition,
      positionModalAtCascade,
      getPrimaryWorkspaceRect,
      getModalMaximizedFrame,
      applyModalMaximizedFrame,
      clearModalMaximizedFrame,
      maximizeModalWindow,
      restoreModalWindow,
      syncModalWithinViewport,
      bindModalDragging
    };
  }

  windowChrome.createModalWindowManager = windowChrome.createModalWindowManager || createModalWindowManager;
})();
