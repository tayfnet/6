(()=>{

  const TAIF = window.TAIF || (window.TAIF = {});
  TAIF.ui = TAIF.ui || {};

  const DEFAULT_MONTH_NAMES = Object.freeze([
    'يناير',
    'فبراير',
    'مارس',
    'أبريل',
    'مايو',
    'يونيو',
    'يوليو',
    'أغسطس',
    'سبتمبر',
    'أكتوبر',
    'نوفمبر',
    'ديسمبر'
  ]);
  const DEFAULT_WEEKDAY_LABELS = Object.freeze(['ح', 'ن', 'ث', 'ر', 'خ', 'ج', 'س']);

  function pad2(value){
    return String(value).padStart(2, '0');
  }

  function pad4(value){
    return String(value).padStart(4, '0');
  }

  function todayIsoDate(){
    return toIsoDate(new Date(), '');
  }

  function parseIsoDate(value){
    const safeValue = String(value || '').trim();
    const match = safeValue.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if(!match) return null;
    const year = Number(match[1]);
    const month = Number(match[2]);
    const day = Number(match[3]);
    if(!Number.isInteger(year) || !Number.isInteger(month) || !Number.isInteger(day)) return null;
    const date = new Date(year, month - 1, day);
    if(
      Number.isNaN(date.getTime())
      || date.getFullYear() !== year
      || date.getMonth() !== (month - 1)
      || date.getDate() !== day
    ) return null;
    return date;
  }

  function toIsoDate(date, fallback = null){
    if(date instanceof Date && !Number.isNaN(date.getTime())){
      return `${pad4(date.getFullYear())}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
    }
    if(typeof fallback === 'string') return fallback;
    const now = new Date();
    return `${pad4(now.getFullYear())}-${pad2(now.getMonth() + 1)}-${pad2(now.getDate())}`;
  }

  function normalizeIsoDate(value, fallback = null){
    const parsed = parseIsoDate(value);
    if(parsed) return toIsoDate(parsed);
    if(typeof fallback === 'string' && fallback.trim()){
      const fallbackDate = parseIsoDate(fallback);
      if(fallbackDate) return toIsoDate(fallbackDate);
    }
    return todayIsoDate();
  }

  function parseMonthCursor(value){
    const safeValue = String(value || '').trim();
    const match = safeValue.match(/^(\d{4})-(\d{2})$/);
    if(!match) return null;
    const year = Number(match[1]);
    const month = Number(match[2]);
    if(!Number.isInteger(year) || !Number.isInteger(month) || month < 1 || month > 12) return null;
    return { year, monthIndex: month - 1 };
  }

  function toMonthCursor(date, fallback = null){
    if(date instanceof Date && !Number.isNaN(date.getTime())){
      return `${pad4(date.getFullYear())}-${pad2(date.getMonth() + 1)}`;
    }
    if(typeof fallback === 'string') return fallback;
    return todayIsoDate().slice(0, 7);
  }

  function normalizeMonthCursor(value, fallbackDate = null){
    const parsed = parseMonthCursor(value);
    if(parsed) return `${pad4(parsed.year)}-${pad2(parsed.monthIndex + 1)}`;
    const source = fallbackDate instanceof Date && !Number.isNaN(fallbackDate.getTime())
      ? fallbackDate
      : new Date();
    return toMonthCursor(source);
  }

  function normalizePickerView(value){
    return String(value || '').trim() === 'month-year' ? 'month-year' : 'days';
  }

  function shiftMonthCursor(value, offset = 0){
    const parsed = parseMonthCursor(value) || parseMonthCursor(todayIsoDate().slice(0, 7));
    const date = new Date(parsed.year, parsed.monthIndex + Number(offset || 0), 1);
    return toMonthCursor(date);
  }

  function resolveMonthCursor(selectedValue, currentCursor = ''){
    const parsedCurrent = parseMonthCursor(currentCursor);
    if(parsedCurrent) return `${pad4(parsedCurrent.year)}-${pad2(parsedCurrent.monthIndex + 1)}`;
    return toMonthCursor(parseIsoDate(selectedValue) || new Date());
  }

  function getDisplayParts(value){
    const date = parseIsoDate(value);
    if(!date){
      return Object.freeze({ day: '--', month: '--', year: '----' });
    }
    return Object.freeze({
      day: pad2(date.getDate()),
      month: pad2(date.getMonth() + 1),
      year: pad4(date.getFullYear())
    });
  }

  function formatSlashDate(value, fallback = '—'){
    const parsed = parseIsoDate(value);
    if(!parsed) return fallback;
    const parts = getDisplayParts(toIsoDate(parsed));
    return `${parts.day}/${parts.month}/${parts.year}`;
  }

  function buildCalendarCells(monthCursor, selectedValue){
    const parsed = parseMonthCursor(monthCursor) || parseMonthCursor(todayIsoDate().slice(0, 7));
    const selectedIso = parseIsoDate(selectedValue) ? toIsoDate(parseIsoDate(selectedValue)) : '';
    const todayIso = todayIsoDate();
    const monthStart = new Date(parsed.year, parsed.monthIndex, 1);
    const gridStart = new Date(parsed.year, parsed.monthIndex, 1 - monthStart.getDay());
    return Array.from({ length: 42 }, (_, index) => {
      const cellDate = new Date(gridStart.getFullYear(), gridStart.getMonth(), gridStart.getDate() + index);
      const isoValue = toIsoDate(cellDate);
      return {
        value: isoValue,
        label: String(cellDate.getDate()),
        outsideMonth: cellDate.getMonth() !== parsed.monthIndex,
        isToday: isoValue === todayIso,
        isSelected: isoValue === selectedIso
      };
    });
  }

  function buildMonthChoices(monthCursor, monthNames = null){
    const parsed = parseMonthCursor(monthCursor) || parseMonthCursor(todayIsoDate().slice(0, 7));
    const labels = Array.isArray(monthNames) && monthNames.length ? monthNames : DEFAULT_MONTH_NAMES;
    return labels.map((label, monthIndex) => ({
      label,
      monthCursor: `${pad4(parsed.year)}-${pad2(monthIndex + 1)}`,
      isActive: monthIndex === parsed.monthIndex
    }));
  }

  function formatMonthLabel(monthCursor, monthNames = null){
    const parsed = parseMonthCursor(monthCursor) || parseMonthCursor(todayIsoDate().slice(0, 7));
    const labels = Array.isArray(monthNames) && monthNames.length ? monthNames : DEFAULT_MONTH_NAMES;
    return `${labels[parsed.monthIndex] || ''} ${parsed.year}`.trim();
  }

  function normalizeDateInputPart(part, kind){
    const digits = String(part || '').replace(/\D/g, '');
    if(kind === 'year') return digits.slice(0, 4);
    return digits.slice(0, 2);
  }

  TAIF.ui.dateSystem = Object.freeze({
    DEFAULT_MONTH_NAMES,
    DEFAULT_WEEKDAY_LABELS,
    todayIsoDate,
    parseIsoDate,
    toIsoDate,
    normalizeIsoDate,
    parseMonthCursor,
    toMonthCursor,
    normalizeMonthCursor,
    normalizePickerView,
    shiftMonthCursor,
    resolveMonthCursor,
    getDisplayParts,
    formatSlashDate,
    buildCalendarCells,
    buildMonthChoices,
    formatMonthLabel,
    normalizeDateInputPart
  });
})();
