(()=>{

  const TAIF = window.TAIF || (window.TAIF = {});
  const services = TAIF.services || (TAIF.services = {});
  const domain = TAIF.domain || (TAIF.domain = {});
  const utils = TAIF.core && TAIF.core.utils ? TAIF.core.utils : {};

  const EPSILON = 0.000001;
  const toText = typeof utils.toText === 'function'
    ? utils.toText
    : ((value, fallback = '') => String(value == null ? fallback : value).trim());
  const toNumber = typeof utils.parseNumericInput === 'function'
    ? utils.parseNumericInput
    : ((value, fallback = 0) => {
        const numeric = Number(String(value ?? '').replace(/,/g, '').trim());
        return Number.isFinite(numeric) ? numeric : Number(fallback) || 0;
      });

  function normalizeCurrencyCode(value, fallback = 'USD'){
    const safe = String(value ?? '').trim().toUpperCase().replace(/[^A-Z]/g, '');
    return safe || fallback;
  }

  function resolveDomain(name){
    if(typeof domain.resolve === 'function') return domain.resolve(name);
    return domain[name] || null;
  }

  function resolveService(name){
    if(typeof services.resolve === 'function') return services.resolve(name);
    return services[name] || null;
  }

  function normalizeBalances(source = {}){
    const raw = source && typeof source === 'object' ? source : {};
    const balances = {};
    Object.keys(raw).forEach((code) => {
      const currencyCode = normalizeCurrencyCode(code, '');
      if(!currencyCode) return;
      balances[currencyCode] = toNumber(raw[code], 0);
    });
    if(!Object.prototype.hasOwnProperty.call(balances, 'USD')) balances.USD = 0;
    return balances;
  }

  function normalizeBox(box, index = 0){
    const raw = box && typeof box === 'object' ? box : {};
    return {
      ...raw,
      id:toText(raw.id) || `cash-box-${index + 1}`,
      linkedAccountNo:toText(raw.linkedAccountNo) || '001',
      linkedAccountName:toText(raw.linkedAccountName) || 'صندوق محلي اساسي',
      balances:normalizeBalances(raw.balances)
    };
  }

  function normalizeState(state){
    const cashBoxes = resolveDomain('cash-boxes');
    if(cashBoxes && typeof cashBoxes.normalizeState === 'function'){
      try{ return cashBoxes.normalizeState(state); }catch{}
    }
    const raw = state && typeof state === 'object' ? state : {};
    const boxes = Array.isArray(raw.boxes) && raw.boxes.length
      ? raw.boxes.map(normalizeBox)
      : [normalizeBox({ id:'cash-box-main-local', linkedAccountNo:'001', linkedAccountName:'صندوق محلي اساسي', balances:{ USD:0 } })];
    return {
      version:1,
      updatedAt:Number(raw.updatedAt) > 0 ? Number(raw.updatedAt) : Date.now(),
      selectedCenterId:toText(raw.selectedCenterId),
      boxes
    };
  }

  function readState(){
    const cashBoxes = resolveDomain('cash-boxes');
    if(cashBoxes && typeof cashBoxes.readState === 'function'){
      try{ return normalizeState(cashBoxes.readState()); }catch{}
    }
    return normalizeState(null);
  }

  function writeState(nextState, options = {}){
    const normalized = normalizeState(nextState);
    const cashBoxes = resolveDomain('cash-boxes');
    if(cashBoxes && typeof cashBoxes.writeState === 'function'){
      try{ return normalizeState(cashBoxes.writeState(normalized, options)); }catch{}
    }
    return normalized;
  }

  function normalizeDeltaMap(source){
    const result = new Map();
    if(source instanceof Map){
      source.forEach((value, key) => result.set(String(key), toNumber(value, 0)));
      return result;
    }
    if(Array.isArray(source)){
      source.forEach((item) => {
        const accountNo = toText(item?.accountNo);
        const currency = normalizeCurrencyCode(item?.currency, '');
        if(!accountNo || !currency) return;
        result.set(`${accountNo}::${currency}`, toNumber(item?.delta ?? item?.amount ?? item?.balance, 0));
      });
      return result;
    }
    const raw = source && typeof source === 'object' ? source : {};
    Object.keys(raw).forEach((key) => result.set(String(key), toNumber(raw[key], 0)));
    return result;
  }

  function applyBalanceDelta(deltaSource, options = {}){
    const deltaMap = normalizeDeltaMap(deltaSource);
    if(!deltaMap.size) return { ok:true, changed:false, state:readState(), changedBoxes:[] };
    const state = readState();
    let didChange = false;
    const changedBoxes = [];
    const boxes = (Array.isArray(state.boxes) ? state.boxes : []).map((box) => {
      const safeBox = normalizeBox(box);
      const accountNo = toText(safeBox.linkedAccountNo);
      if(!accountNo) return safeBox;
      const balances = { ...safeBox.balances };
      let boxChanged = false;
      deltaMap.forEach((delta, key) => {
        const [deltaAccountNo, currencyCode = ''] = String(key).split('::');
        const currency = normalizeCurrencyCode(currencyCode, '');
        if(deltaAccountNo !== accountNo || !currency) return;
        const previous = toNumber(balances[currency], 0);
        const next = previous + toNumber(delta, 0);
        if(Math.abs(next - previous) <= EPSILON && Object.prototype.hasOwnProperty.call(balances, currency)) return;
        balances[currency] = Math.abs(next) <= EPSILON ? 0 : next;
        boxChanged = true;
      });
      if(!boxChanged) return safeBox;
      didChange = true;
      changedBoxes.push(safeBox.id);
      return { ...safeBox, balances };
    });
    if(!didChange) return { ok:true, changed:false, state, changedBoxes:[] };
    const nextState = options.dryRun === true ? { ...state, boxes } : writeState({ ...state, boxes }, { notify:options.notify !== false });
    return { ok:true, changed:true, state:nextState, changedBoxes };
  }

  function buildLedgerBalanceMap(){
    const ledger = resolveService('ledger-service');
    if(!ledger || typeof ledger.buildAccountCurrencyTotals !== 'function') return new Map();
    try{
      const totals = ledger.buildAccountCurrencyTotals();
      const map = new Map();
      totals.forEach((value, key) => map.set(key, toNumber(value?.balance, 0)));
      return map;
    }catch{
      return new Map();
    }
  }

  function buildCashBoxSnapshot(){
    const state = readState();
    const ledgerBalances = buildLedgerBalanceMap();
    const boxes = (Array.isArray(state.boxes) ? state.boxes : []).map((box) => {
      const safeBox = normalizeBox(box);
      const accountNo = toText(safeBox.linkedAccountNo);
      const currencies = new Set(Object.keys(safeBox.balances || {}));
      ledgerBalances.forEach((_, key) => {
        const [ledgerAccountNo, currency = ''] = String(key).split('::');
        if(ledgerAccountNo === accountNo && currency) currencies.add(currency);
      });
      const balances = Array.from(currencies).sort().map((currency) => {
        const stored = toNumber(safeBox.balances?.[currency], 0);
        const ledger = toNumber(ledgerBalances.get(`${accountNo}::${currency}`), 0);
        return {
          currency,
          stored,
          ledger,
          difference:stored - ledger,
          balanced:Math.abs(stored - ledger) <= EPSILON
        };
      });
      return { ...safeBox, balanceSnapshot:balances };
    });
    return { version:1, updatedAt:Date.now(), boxes };
  }

  function reconcileFromLedger(options = {}){
    const state = readState();
    const ledgerBalances = buildLedgerBalanceMap();
    if(!ledgerBalances.size) return { ok:true, changed:false, state, reason:'no-ledger-balances' };
    let didChange = false;
    const boxes = (Array.isArray(state.boxes) ? state.boxes : []).map((box) => {
      const safeBox = normalizeBox(box);
      const accountNo = toText(safeBox.linkedAccountNo);
      if(!accountNo) return safeBox;
      const balances = { ...safeBox.balances };
      ledgerBalances.forEach((ledgerBalance, key) => {
        const [ledgerAccountNo, currencyCode = ''] = String(key).split('::');
        const currency = normalizeCurrencyCode(currencyCode, '');
        if(ledgerAccountNo !== accountNo || !currency) return;
        if(Math.abs(toNumber(balances[currency], 0) - toNumber(ledgerBalance, 0)) <= EPSILON && Object.prototype.hasOwnProperty.call(balances, currency)) return;
        balances[currency] = Math.abs(toNumber(ledgerBalance, 0)) <= EPSILON ? 0 : toNumber(ledgerBalance, 0);
        didChange = true;
      });
      return { ...safeBox, balances };
    });
    if(!didChange) return { ok:true, changed:false, state };
    const nextState = options.dryRun === true ? { ...state, boxes } : writeState({ ...state, boxes }, { notify:options.notify !== false });
    return { ok:true, changed:true, state:nextState };
  }

  const api = {
    EPSILON,
    normalizeCurrencyCode,
    normalizeBalances,
    normalizeBox,
    normalizeState,
    readState,
    writeState,
    normalizeDeltaMap,
    applyBalanceDelta,
    buildLedgerBalanceMap,
    buildCashBoxSnapshot,
    reconcileFromLedger
  };

  if(typeof services.define === 'function'){
    services.define('cashbox-service', api, { status:'active-reconciliation', source:'cash-boxes-domain' });
  }else{
    services['cashbox-service'] = api;
  }
})();
