(()=>{

  const TAIF = window.TAIF || (window.TAIF = {});
  const services = TAIF.services || (TAIF.services = {});
  const domain = TAIF.domain || (TAIF.domain = {});
  const utils = TAIF.core && TAIF.core.utils ? TAIF.core.utils : {};
  const events = TAIF.core && TAIF.core.events ? TAIF.core.events : null;

  const EPSILON = 0.000001;
  let cachedReadModel = null;
  let lastInvalidatedAt = 0;
  let lastInvalidationReason = '';

  const toText = typeof utils.toText === 'function'
    ? utils.toText
    : ((value, fallback = '') => String(value == null ? fallback : value).trim());
  const toNumber = typeof utils.parseNumericInput === 'function'
    ? utils.parseNumericInput
    : ((value, fallback = 0) => {
        const numeric = Number(String(value ?? '').replace(/,/g, '').trim());
        return Number.isFinite(numeric) ? numeric : Number(fallback) || 0;
      });

  function normalizeCurrencyCode(value, fallback = 'USD'){
    const safe = String(value ?? '').trim().toUpperCase().replace(/[^A-Z]/g, '');
    return safe || fallback;
  }

  function resolveDomain(name){
    if(typeof domain.resolve === 'function') return domain.resolve(name);
    return domain[name] || null;
  }

  function readAccounts(){
    const accounts = resolveDomain('accounts');
    if(accounts && typeof accounts.readCatalog === 'function'){
      try{
        const catalog = accounts.readCatalog();
        return Array.isArray(catalog) ? catalog : [];
      }catch{}
    }
    return [];
  }

  function readEntriesState(){
    const entries = resolveDomain('entries');
    if(entries && typeof entries.readState === 'function'){
      try{ return entries.readState(); }catch{}
    }
    return { version:1, updatedAt:Date.now(), counters:{}, records:[] };
  }

  function readSalesPurchaseState(){
    const salesPurchase = resolveDomain('sales-purchase');
    if(salesPurchase && typeof salesPurchase.readState === 'function'){
      try{ return salesPurchase.readState(); }catch{}
    }
    return { version:1, updatedAt:Date.now(), counters:{}, records:[] };
  }

  function normalizeLine(line, index = 0, record = {}){
    const raw = line && typeof line === 'object' ? line : {};
    const recordCurrency = normalizeCurrencyCode(record.currency || record.tradeCurrencyCode || record.settlementCurrencyCode || 'USD');
    const debit = Math.max(0, toNumber(raw.debit, 0));
    const credit = Math.max(0, toNumber(raw.credit, 0));
    const amount = Math.max(0, toNumber(raw.amount, Math.max(debit, credit)));
    return {
      lineNo:Math.max(1, Number(raw.lineNo) || index + 1),
      accountNo:toText(raw.accountNo),
      accountName:toText(raw.accountName),
      roleKey:toText(raw.roleKey),
      roleLabel:toText(raw.roleLabel),
      description:toText(raw.description || record.description || record.summary),
      debit,
      credit,
      amount,
      side:credit > debit ? 'credit' : 'debit',
      currency:normalizeCurrencyCode(raw.currency || recordCurrency),
      date:toText(raw.date || record.date),
      sourceRecordId:toText(record.id),
      sourceRecordNumber:toText(record.number).toUpperCase(),
      sourceRecordType:toText(record.type || record.ownerActionId || 'entry')
    };
  }

  function normalizeRecord(record, index = 0){
    const raw = record && typeof record === 'object' ? record : {};
    const currency = normalizeCurrencyCode(raw.currency || raw.tradeCurrencyCode || raw.settlementCurrencyCode || 'USD');
    const lines = Array.isArray(raw.lines)
      ? raw.lines.map((line, lineIndex) => normalizeLine(line, lineIndex, raw)).filter((line) => line.accountNo)
      : [];
    return {
      id:toText(raw.id) || `ledger-record-${index + 1}`,
      number:toText(raw.number).toUpperCase(),
      type:toText(raw.type || raw.ownerActionId || 'entry'),
      status:raw.status === 'draft' ? 'draft' : (raw.status === 'reversed' ? 'reversed' : 'posted'),
      date:toText(raw.date),
      description:toText(raw.description || raw.summary || raw.notes),
      currency,
      amount:Math.max(0, toNumber(raw.amount || raw.amountValue || raw.grossAmount || raw.netAmount, 0)),
      sourceSalesPurchaseRecordId:toText(raw.sourceSalesPurchaseRecordId),
      sourceSalesPurchaseNumber:toText(raw.sourceSalesPurchaseNumber).toUpperCase(),
      createdAt:Number(raw.createdAt) || 0,
      updatedAt:Number(raw.updatedAt) || Number(raw.createdAt) || 0,
      lines
    };
  }

  function validateRecord(record){
    const safeRecord = normalizeRecord(record);
    const totalDebit = safeRecord.lines.reduce((sum, line) => sum + toNumber(line.debit, 0), 0);
    const totalCredit = safeRecord.lines.reduce((sum, line) => sum + toNumber(line.credit, 0), 0);
    const delta = totalDebit - totalCredit;
    const issues = [];
    if(!safeRecord.lines.length) issues.push('record-has-no-lines');
    if(Math.abs(delta) > EPSILON) issues.push('record-not-balanced');
    safeRecord.lines.forEach((line) => {
      if(!line.accountNo) issues.push(`line-${line.lineNo}-missing-account`);
      if(toNumber(line.debit, 0) > EPSILON && toNumber(line.credit, 0) > EPSILON) issues.push(`line-${line.lineNo}-has-debit-and-credit`);
    });
    return {
      ok:issues.length === 0,
      issues,
      totalDebit,
      totalCredit,
      delta
    };
  }

  function buildRows(records, options = {}){
    const includeDraft = options.includeDraft === true;
    return (Array.isArray(records) ? records : [])
      .map(normalizeRecord)
      .filter((record) => includeDraft || record.status === 'posted')
      .flatMap((record) => record.lines.map((line) => ({
        recordId:record.id,
        number:record.number,
        type:record.type,
        status:record.status,
        date:line.date || record.date,
        description:line.description || record.description,
        accountNo:line.accountNo,
        accountName:line.accountName,
        currency:normalizeCurrencyCode(line.currency || record.currency),
        debit:toNumber(line.debit, 0),
        credit:toNumber(line.credit, 0),
        balanceDelta:toNumber(line.debit, 0) - toNumber(line.credit, 0),
        roleKey:line.roleKey,
        roleLabel:line.roleLabel,
        sourceSalesPurchaseRecordId:record.sourceSalesPurchaseRecordId,
        sourceSalesPurchaseNumber:record.sourceSalesPurchaseNumber
      })));
  }

  function buildAccountCurrencyTotals(input = {}){
    const options = input && typeof input === 'object' ? input : {};
    const records = Array.isArray(options.records) ? options.records : (Array.isArray(input) ? input : readEntriesState().records);
    const rows = buildRows(records, options);
    const totals = new Map();
    rows.forEach((row) => {
      const accountNo = toText(row.accountNo);
      const currency = normalizeCurrencyCode(row.currency);
      if(!accountNo || !currency) return;
      const key = `${accountNo}::${currency}`;
      const current = totals.get(key) || { accountNo, currency, debit:0, credit:0, balance:0, rowCount:0 };
      current.debit += toNumber(row.debit, 0);
      current.credit += toNumber(row.credit, 0);
      current.balance += toNumber(row.balanceDelta, 0);
      current.rowCount += 1;
      totals.set(key, current);
    });
    return totals;
  }

  function readAccountCurrencyBalance(accountNo, currencyCode, options = {}){
    const safeAccountNo = toText(accountNo);
    const safeCurrencyCode = normalizeCurrencyCode(currencyCode, '');
    if(!safeAccountNo || !safeCurrencyCode) return 0;
    const totals = buildAccountCurrencyTotals(options);
    return toNumber(totals.get(`${safeAccountNo}::${safeCurrencyCode}`)?.balance, 0);
  }

  function buildReadModel(options = {}){
    if(options.cache !== false && cachedReadModel) return cachedReadModel;
    const entriesState = readEntriesState();
    const salesPurchaseState = readSalesPurchaseState();
    const records = Array.isArray(entriesState?.records) ? entriesState.records : [];
    const normalizedRecords = records.map(normalizeRecord);
    const rows = buildRows(normalizedRecords, options);
    const totals = Array.from(buildAccountCurrencyTotals({ records:normalizedRecords, ...options }).values())
      .sort((left, right) => `${left.accountNo}:${left.currency}`.localeCompare(`${right.accountNo}:${right.currency}`, 'en'));
    const issues = normalizedRecords.flatMap((record) => {
      const validation = validateRecord(record);
      return validation.ok ? [] : [{ recordId:record.id, number:record.number, issues:validation.issues }];
    });
    cachedReadModel = {
      version:1,
      updatedAt:Date.now(),
      lastInvalidatedAt,
      lastInvalidationReason,
      accounts:readAccounts(),
      entriesState,
      salesPurchaseState,
      records:normalizedRecords,
      rows,
      totals,
      issues
    };
    return cachedReadModel;
  }

  function invalidate(reason = ''){
    cachedReadModel = null;
    lastInvalidatedAt = Date.now();
    lastInvalidationReason = toText(reason);
    if(events && typeof events.invalidateLedger === 'function'){
      events.invalidateLedger(lastInvalidationReason || 'service-invalidate', { service:'ledger-service' }, { source:'ledger-service' });
    }
    return true;
  }

  if(events && typeof events.onMany === 'function'){
    const names = events.EVENT_NAMES || {};
    events.onMany([
      names.CHART_OF_ACCOUNTS_UPDATED,
      names.CURRENCY_UPDATED,
      names.CASH_BOXES_UPDATED,
      names.ENTRIES_VOUCHERS_UPDATED,
      names.SALES_PURCHASE_UPDATED
    ].filter(Boolean), (event) => {
      cachedReadModel = null;
      lastInvalidatedAt = Date.now();
      lastInvalidationReason = toText(event?.detail?.eventName || event?.type || 'domain-update');
    });
  }

  const api = {
    EPSILON,
    normalizeCurrencyCode,
    readAccounts,
    readEntriesState,
    readSalesPurchaseState,
    normalizeLine,
    normalizeRecord,
    validateRecord,
    buildRows,
    buildAccountCurrencyTotals,
    readAccountCurrencyBalance,
    buildReadModel,
    invalidate
  };

  if(typeof services.define === 'function'){
    services.define('ledger-service', api, { status:'active-read-model', source:'domain-adapters' });
  }else{
    services['ledger-service'] = api;
  }
  if(domain.ledger && typeof domain.ledger === 'object'){
    Object.assign(domain.ledger, {
      service:api,
      buildReadModel,
      buildAccountCurrencyTotals,
      readAccountCurrencyBalance,
      validateRecord,
      invalidateReadModel:invalidate
    });
  }
})();
