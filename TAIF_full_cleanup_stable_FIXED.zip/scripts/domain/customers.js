(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  const registry = TAIF.domain || (TAIF.domain = {});
  const utils = TAIF.core && TAIF.core.utils ? TAIF.core.utils : {};
  const storageKeys = TAIF.core && TAIF.core.storageKeys ? TAIF.core.storageKeys : {};
  const STORAGE_KEY = storageKeys.customerCard || 'taif-customer-card-module-v1';
  const readJsonStorage = typeof utils.readJsonStorage === 'function' ? utils.readJsonStorage : (() => null);
  const persistJsonState = typeof utils.persistJsonState === 'function' ? utils.persistJsonState : ((_, value) => value);

  function legacy(){
    return TAIF.customerCard || {};
  }

  function readDomain(){
    const api = legacy();
    if(api && typeof api.readDomain === 'function'){
      try{ return api.readDomain(); }catch{}
    }
    const stored = readJsonStorage(STORAGE_KEY, null);
    return stored && typeof stored === 'object' ? stored : { draft:{}, records:[] };
  }

  function writeDomain(nextDomain, options = {}){
    const api = legacy();
    if(api && typeof api.writeDomain === 'function'){
      try{ return api.writeDomain(nextDomain, options); }catch{}
    }
    const safeDomain = nextDomain && typeof nextDomain === 'object' ? nextDomain : { draft:{}, records:[] };
    const persisted = persistJsonState(STORAGE_KEY, safeDomain, null);
    if(options.notify !== false && typeof registry.notify === 'function'){
      registry.notify('customers', 'taif:customer-card-updated', { domain:persisted });
    }
    return persisted;
  }

  function readState(){
    const api = legacy();
    if(api && typeof api.readState === 'function'){
      try{ return api.readState(); }catch{}
    }
    return readDomain().draft || {};
  }

  function writeState(nextState, options = {}){
    const api = legacy();
    if(api && typeof api.writeState === 'function'){
      try{ return api.writeState(nextState, options); }catch{}
    }
    return writeDomain({ ...readDomain(), draft:nextState }, options).draft || nextState;
  }

  function readRecords(){
    const api = legacy();
    if(api && typeof api.readRecords === 'function'){
      try{
        const records = api.readRecords();
        return Array.isArray(records) ? records : [];
      }catch{}
    }
    const records = readDomain().records;
    return Array.isArray(records) ? records : [];
  }

  function writeRecords(records, options = {}){
    const api = legacy();
    if(api && typeof api.writeRecords === 'function'){
      try{ return api.writeRecords(records, options); }catch{}
    }
    return writeDomain({ ...readDomain(), records:Array.isArray(records) ? records : [] }, options).records || [];
  }

  function normalizeRecord(record){
    const api = legacy();
    if(api && typeof api.normalizeRecord === 'function'){
      try{ return api.normalizeRecord(record); }catch{}
    }
    return record && typeof record === 'object' ? { ...record } : {};
  }

  function findRecord(query){
    const api = legacy();
    if(api && typeof api.findRecord === 'function'){
      try{ return api.findRecord(query); }catch{}
    }
    const safeQuery = String(query ?? '').trim().toLowerCase();
    if(!safeQuery) return null;
    return readRecords().find((record) => JSON.stringify(record || {}).toLowerCase().includes(safeQuery)) || null;
  }

  const api = {
    storageKey:STORAGE_KEY,
    readDomain,
    writeDomain,
    readState,
    writeState,
    readRecords,
    writeRecords,
    normalizeRecord,
    findRecord
  };

  if(typeof registry.define === 'function') registry.define('customers', api, { status:'baseline-adapter', source:'customer-card' });
})();
