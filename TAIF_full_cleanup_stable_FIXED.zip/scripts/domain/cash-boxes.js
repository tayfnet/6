(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  const registry = TAIF.domain || (TAIF.domain = {});
  const utils = TAIF.core && TAIF.core.utils ? TAIF.core.utils : {};
  const storageKeys = TAIF.core && TAIF.core.storageKeys ? TAIF.core.storageKeys : {};
  const STORAGE_KEY = storageKeys.cashBoxes || 'taif-cash-boxes-module-v1';
  const readJsonStorage = typeof utils.readJsonStorage === 'function' ? utils.readJsonStorage : (() => null);
  const persistJsonState = typeof utils.persistJsonState === 'function' ? utils.persistJsonState : ((_, value) => value);
  const parseNumericInput = typeof utils.parseNumericInput === 'function' ? utils.parseNumericInput : ((value, fallback = 0) => {
    const numeric = Number(String(value ?? '').replace(/,/g, '').trim());
    return Number.isFinite(numeric) ? numeric : Number(fallback) || 0;
  });

  function legacy(){
    return TAIF.cashBoxesDomain || TAIF.cashBoxes || {};
  }

  function normalizeBalances(source = {}){
    const raw = source && typeof source === 'object' ? source : {};
    const balances = {};
    Object.keys(raw).forEach((code) => {
      const safeCode = String(code || '').trim().toUpperCase();
      if(!safeCode) return;
      balances[safeCode] = parseNumericInput(raw[code], 0);
    });
    if(!Object.prototype.hasOwnProperty.call(balances, 'USD')) balances.USD = 0;
    return balances;
  }

  function normalizeBox(box, index = 0){
    const raw = box && typeof box === 'object' ? box : {};
    return {
      id:String(raw.id || `cash-box-${index + 1}`).trim() || `cash-box-${index + 1}`,
      linkedAccountNo:String(raw.linkedAccountNo || '001').trim() || '001',
      linkedAccountName:String(raw.linkedAccountName || 'صندوق محلي اساسي').trim() || 'صندوق محلي اساسي',
      balances:normalizeBalances(raw.balances)
    };
  }

  function normalizeState(state){
    const api = legacy();
    if(api && typeof api.normalizeState === 'function'){
      try{ return api.normalizeState(state); }catch{}
    }
    const raw = state && typeof state === 'object' ? state : {};
    const boxes = Array.isArray(raw.boxes) && raw.boxes.length
      ? raw.boxes.map(normalizeBox)
      : [normalizeBox({ id:'cash-box-main-local', linkedAccountNo:'001', linkedAccountName:'صندوق محلي اساسي', balances:{ USD:0 } })];
    return {
      version:1,
      updatedAt:Number(raw.updatedAt) > 0 ? Number(raw.updatedAt) : Date.now(),
      selectedCenterId:String(raw.selectedCenterId || '').trim(),
      boxes
    };
  }

  function readState(){
    const api = legacy();
    if(api && typeof api.readState === 'function'){
      try{ return normalizeState(api.readState()); }catch{}
    }
    return normalizeState(readJsonStorage(STORAGE_KEY, null));
  }

  function writeState(nextState, options = {}){
    const normalized = normalizeState(nextState);
    const api = legacy();
    if(api && typeof api.writeState === 'function'){
      try{ return normalizeState(api.writeState(normalized, options)); }catch{}
    }
    const persisted = normalizeState(persistJsonState(STORAGE_KEY, normalized, normalizeState));
    if(options.notify !== false && typeof registry.notify === 'function'){
      registry.notify('cash-boxes', 'taif:cash-boxes-updated', { state:persisted });
    }
    return persisted;
  }

  const api = {
    storageKey:STORAGE_KEY,
    normalizeBalances,
    normalizeBox,
    normalizeState,
    readState,
    writeState
  };

  if(typeof registry.define === 'function') registry.define('cash-boxes', api, { status:'baseline-adapter', source:'cash-boxes' });
})();
