(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  const registry = TAIF.domain || (TAIF.domain = {});

  function resolve(name){
    return typeof registry.resolve === 'function' ? registry.resolve(name) : registry[name];
  }

  function readAccounts(){
    const accounts = resolve('accounts');
    return accounts && typeof accounts.readCatalog === 'function' ? accounts.readCatalog() : [];
  }

  function readEntriesState(){
    const entries = resolve('entries');
    return entries && typeof entries.readState === 'function' ? entries.readState() : { records:[] };
  }

  function readSalesPurchaseState(){
    const salesPurchase = resolve('sales-purchase');
    return salesPurchase && typeof salesPurchase.readState === 'function' ? salesPurchase.readState() : { records:[] };
  }

  function readCashBoxesState(){
    const cashBoxes = resolve('cash-boxes');
    return cashBoxes && typeof cashBoxes.readState === 'function' ? cashBoxes.readState() : { boxes:[] };
  }

  function readCurrencyState(){
    const currency = resolve('currency');
    return currency && typeof currency.readState === 'function' ? currency.readState() : null;
  }

  function buildReadModel(){
    return {
      version:1,
      updatedAt:Date.now(),
      accounts:readAccounts(),
      entries:readEntriesState(),
      salesPurchase:readSalesPurchaseState(),
      cashBoxes:readCashBoxesState(),
      currency:readCurrencyState()
    };
  }

  function invalidateReadModel(reason = ''){
    if(typeof registry.notify === 'function'){
      registry.notify('ledger', 'taif:ledger-read-model-invalidated', { reason:String(reason || '').trim() });
    }
    return true;
  }

  const api = {
    readAccounts,
    readEntriesState,
    readSalesPurchaseState,
    readCashBoxesState,
    readCurrencyState,
    buildReadModel,
    invalidateReadModel
  };

  if(typeof registry.define === 'function') registry.define('ledger', api, { status:'baseline-read-model', source:'domain-adapters' });
})();
