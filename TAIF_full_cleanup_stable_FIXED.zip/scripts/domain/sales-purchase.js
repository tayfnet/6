(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  const registry = TAIF.domain || (TAIF.domain = {});
  const utils = TAIF.core && TAIF.core.utils ? TAIF.core.utils : {};
  const storageKeys = TAIF.core && TAIF.core.storageKeys ? TAIF.core.storageKeys : {};
  const STORAGE_KEY = storageKeys.salesPurchaseInvoice || 'taif-sales-purchase-invoice-records-v1';
  const readJsonStorage = typeof utils.readJsonStorage === 'function' ? utils.readJsonStorage : (() => null);
  const persistJsonState = typeof utils.persistJsonState === 'function' ? utils.persistJsonState : ((_, value) => value);

  function resolveFeatureApi(){
    return TAIF.salesPurchaseFeature || TAIF.salesPurchaseInvoice || {};
  }

  function warnFeatureApiFailure(methodName, error){
    if(typeof console !== 'undefined' && typeof console.warn === 'function'){
      console.warn(`[sales-purchase-domain] فشل استدعاء ${methodName}، تم استخدام المسار الاحتياطي.`, error || '');
    }
  }

  function callFeatureApi(methodName, args = []){
    const api = resolveFeatureApi();
    const method = api && typeof api[methodName] === 'function' ? api[methodName] : null;
    if(!method) return { ok:false, value:null };
    try{
      return { ok:true, value:method.apply(api, args) };
    }catch(error){
      warnFeatureApiFailure(methodName, error);
      return { ok:false, value:null };
    }
  }

  function normalizeStateFallback(state){
    const raw = state && typeof state === 'object' ? state : {};
    return {
      ...raw,
      version:1,
      updatedAt:Number(raw.updatedAt) > 0 ? Number(raw.updatedAt) : Date.now(),
      counters:raw.counters && typeof raw.counters === 'object' ? { ...raw.counters } : {},
      records:Array.isArray(raw.records) ? raw.records.slice() : []
    };
  }

  function normalizeState(state){
    const featureResult = callFeatureApi('normalizeSalesPurchaseState', [state]);
    if(featureResult.ok && featureResult.value && typeof featureResult.value === 'object') return featureResult.value;
    return normalizeStateFallback(state);
  }

  function readState(){
    const primaryResult = callFeatureApi('readSalesPurchaseState');
    if(primaryResult.ok) return normalizeState(primaryResult.value);

    const secondaryResult = callFeatureApi('readState');
    if(secondaryResult.ok) return normalizeState(secondaryResult.value);

    return normalizeState(readJsonStorage(STORAGE_KEY, null));
  }

  function writeState(nextState, options = {}){
    const normalized = normalizeState(nextState);

    const primaryResult = callFeatureApi('writeSalesPurchaseState', [normalized, options]);
    if(primaryResult.ok) return normalizeState(primaryResult.value);

    const secondaryResult = callFeatureApi('writeState', [normalized, options]);
    if(secondaryResult.ok) return normalizeState(secondaryResult.value);

    const persisted = normalizeState(persistJsonState(STORAGE_KEY, normalized, normalizeState));
    if(options.notify !== false && typeof registry.notify === 'function'){
      registry.notify('sales-purchase', 'taif:sales-purchase-invoice-updated', { state:persisted });
    }
    return persisted;
  }

  function normalizeRecordFallback(record){
    return record && typeof record === 'object' ? { ...record } : {};
  }

  function normalizeRecord(record){
    const featureResult = callFeatureApi('normalizeSalesPurchaseRecord', [record]);
    return featureResult.ok ? normalizeRecordFallback(featureResult.value) : normalizeRecordFallback(record);
  }

  function appendRecord(record, options = {}){
    const featureResult = callFeatureApi('appendSalesPurchaseRecord', [record, options]);
    if(featureResult.ok) return featureResult.value;

    const state = readState();
    const nextRecord = normalizeRecord(record);
    const nextState = writeState({ ...state, records:[nextRecord, ...(Array.isArray(state.records) ? state.records : [])] }, options);
    return { record:nextRecord, state:nextState };
  }

  function getRecords(){
    return readState().records || [];
  }

  const api = {
    storageKey:STORAGE_KEY,
    normalizeState,
    normalizeRecord,
    readState,
    writeState,
    getRecords,
    appendRecord
  };

  if(typeof registry.define === 'function') registry.define('sales-purchase', api, { status:'stable-adapter', source:'sales-purchase-invoice' });
})();
