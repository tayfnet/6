(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  const registry = TAIF.domain || (TAIF.domain = {});
  const utils = TAIF.core && TAIF.core.utils ? TAIF.core.utils : {};
  const storageKeys = TAIF.core && TAIF.core.storageKeys ? TAIF.core.storageKeys : {};
  const STORAGE_KEY = storageKeys.chartOfAccounts || 'taif-chart-of-accounts-centers-v3';

  const toText = typeof utils.toText === 'function'
    ? utils.toText
    : ((value, fallback = '') => String(value == null ? fallback : value).trim());
  const readJsonStorage = typeof utils.readJsonStorage === 'function' ? utils.readJsonStorage : (() => null);
  const normalizeAccountCatalog = typeof utils.normalizeAccountCatalog === 'function'
    ? utils.normalizeAccountCatalog
    : ((source) => Array.isArray(source) ? source : []);
  const readChartAccountCatalogSource = typeof utils.readChartAccountCatalogSource === 'function'
    ? utils.readChartAccountCatalogSource
    : null;

  function readRawSource(){
    const publicApi = TAIF.chartOfAccounts || {};
    const internalApi = publicApi.internal || {};
    if(typeof publicApi.readState === 'function'){
      const state = publicApi.readState();
      if(Array.isArray(state)) return state;
      if(Array.isArray(state?.centers)) return state.centers;
    }
    if(typeof internalApi.getCenters === 'function') return internalApi.getCenters(true);
    if(typeof internalApi.readCenters === 'function') return internalApi.readCenters();
    if(typeof readChartAccountCatalogSource === 'function') return readChartAccountCatalogSource(STORAGE_KEY, readJsonStorage);
    const stored = readJsonStorage(STORAGE_KEY, null);
    if(Array.isArray(stored)) return stored;
    return Array.isArray(stored?.centers) ? stored.centers : [];
  }

  function readCatalog(){
    const source = readRawSource();
    return normalizeAccountCatalog(source, toText);
  }

  function readState(){
    const accounts = readCatalog();
    return {
      version:1,
      updatedAt:Date.now(),
      accounts
    };
  }

  function findByNo(accountNo, catalog = readCatalog()){
    const safeAccountNo = toText(accountNo);
    if(!safeAccountNo) return null;
    return (Array.isArray(catalog) ? catalog : []).find((item) => toText(item?.accountNo) === safeAccountNo) || null;
  }

  function findByName(keywords, catalog = readCatalog()){
    const source = Array.isArray(keywords) ? keywords : [keywords];
    const normalizedKeywords = source
      .map((keyword) => toText(keyword).toLowerCase())
      .filter(Boolean);
    if(!normalizedKeywords.length) return null;
    return (Array.isArray(catalog) ? catalog : []).find((item) => {
      const name = toText(item?.name).toLowerCase();
      return !!name && normalizedKeywords.some((keyword) => name.includes(keyword));
    }) || null;
  }

  const api = {
    storageKey:STORAGE_KEY,
    readRawSource,
    readCatalog,
    readState,
    findByNo,
    findByName
  };

  if(typeof registry.define === 'function') registry.define('accounts', api, { status:'baseline-adapter', source:'chart-of-accounts' });
})();
