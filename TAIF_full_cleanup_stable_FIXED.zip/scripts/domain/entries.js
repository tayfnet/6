(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  const registry = TAIF.domain || (TAIF.domain = {});
  const utils = TAIF.core && TAIF.core.utils ? TAIF.core.utils : {};
  const storageKeys = TAIF.core && TAIF.core.storageKeys ? TAIF.core.storageKeys : {};
  const STORAGE_KEY = storageKeys.entriesVouchers || 'taif-entries-vouchers-module-v1';
  const readJsonStorage = typeof utils.readJsonStorage === 'function' ? utils.readJsonStorage : (() => null);
  const persistJsonState = typeof utils.persistJsonState === 'function' ? utils.persistJsonState : ((_, value) => value);

  function legacy(){
    return TAIF.entriesVouchersDomain || {};
  }

  function createDefaultState(){
    const api = legacy();
    if(api && typeof api.createDefaultState === 'function'){
      try{ return api.createDefaultState(); }catch{}
    }
    return { version:1, updatedAt:Date.now(), counters:{ PV:1, RV:1, JV:1, SV:1, OV:1 }, records:[] };
  }

  function normalizeState(state){
    const api = legacy();
    if(api && typeof api.normalizeState === 'function'){
      try{ return api.normalizeState(state); }catch{}
    }
    const raw = state && typeof state === 'object' ? state : createDefaultState();
    return {
      version:1,
      updatedAt:Number(raw.updatedAt) > 0 ? Number(raw.updatedAt) : Date.now(),
      counters:raw.counters && typeof raw.counters === 'object' ? { ...raw.counters } : { PV:1, RV:1, JV:1, SV:1, OV:1 },
      records:Array.isArray(raw.records) ? raw.records.slice() : []
    };
  }

  function readState(){
    const api = legacy();
    if(api && typeof api.readState === 'function'){
      try{ return normalizeState(api.readState()); }catch{}
    }
    return normalizeState(readJsonStorage(STORAGE_KEY, createDefaultState()));
  }

  function writeState(nextState, options = {}){
    const normalized = normalizeState(nextState);
    const api = legacy();
    if(api && typeof api.writeState === 'function'){
      try{ return normalizeState(api.writeState(normalized, options)); }catch{}
    }
    const persisted = normalizeState(persistJsonState(STORAGE_KEY, normalized, normalizeState));
    if(options.notify !== false && typeof registry.notify === 'function'){
      registry.notify('entries', 'taif:entries-vouchers-updated', { state:persisted });
    }
    return persisted;
  }

  function getRecords(){
    const api = legacy();
    if(api && typeof api.getRecords === 'function'){
      try{
        const records = api.getRecords();
        return Array.isArray(records) ? records : [];
      }catch{}
    }
    return readState().records;
  }

  function isSalesPurchaseGeneratedRecord(record){
    const api = legacy();
    if(api && typeof api.isSalesPurchaseGeneratedRecord === 'function'){
      try{ return !!api.isSalesPurchaseGeneratedRecord(record); }catch{}
    }
    const id = String(record?.id || '').trim();
    return id.startsWith('entry-record-sales-purchase-')
      || !!String(record?.sourceSalesPurchaseRecordId || '').trim()
      || !!String(record?.sourceSalesPurchaseNumber || '').trim();
  }

  const api = {
    storageKey:STORAGE_KEY,
    createDefaultState,
    normalizeState,
    readState,
    writeState,
    getRecords,
    isSalesPurchaseGeneratedRecord
  };

  if(typeof registry.define === 'function') registry.define('entries', api, { status:'baseline-adapter', source:'entries-vouchers' });
})();
