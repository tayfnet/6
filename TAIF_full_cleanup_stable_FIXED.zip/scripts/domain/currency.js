(()=>{
  const TAIF = window.TAIF || (window.TAIF = {});
  const registry = TAIF.domain || (TAIF.domain = {});
  const utils = TAIF.core && TAIF.core.utils ? TAIF.core.utils : {};
  const storageKeys = TAIF.core && TAIF.core.storageKeys ? TAIF.core.storageKeys : {};
  const STORAGE_KEY = storageKeys.currencyDomain || storageKeys.currencyManagement || 'taif-currency-management-module-v1';
  const readJsonStorage = typeof utils.readJsonStorage === 'function' ? utils.readJsonStorage : (() => null);
  const persistJsonState = typeof utils.persistJsonState === 'function' ? utils.persistJsonState : ((_, value) => value);

  function legacy(){
    return TAIF.currencyDomain || TAIF.currencyManagement || TAIF.currencyManagementFeature || {};
  }

  function call(name, fallback, ...args){
    const api = legacy();
    if(api && typeof api[name] === 'function'){
      try{ return api[name](...args); }catch{}
    }
    return typeof fallback === 'function' ? fallback(...args) : fallback;
  }

  function readState(){
    return call('readState', () => readJsonStorage(STORAGE_KEY, null));
  }

  function writeState(nextState, options = {}){
    return call('writeState', () => {
      const persisted = persistJsonState(STORAGE_KEY, nextState, null);
      if(options.notify !== false && typeof registry.notify === 'function'){
        registry.notify('currency', 'taif:currency-domain-updated', { state:persisted });
      }
      return persisted;
    }, nextState, options);
  }

  function resetState(options = {}){
    return call('resetState', null, options);
  }

  function computeRows(state = readState()){
    return call('computeRows', [], state);
  }

  function getActiveRateBook(state = readState()){
    return call('getActiveRateBook', null, state);
  }

  function readOperationalQuote(...args){
    return call('readOperationalQuote', null, ...args);
  }

  function getCounterpartCurrency(state = readState()){
    return call('getCounterpartCurrency', null, state);
  }

  function normalizeCurrencyCode(value){
    return String(value ?? '').trim().toUpperCase();
  }

  function toNumber(value, fallback = 0){
    return call('toNumber', () => {
      const numeric = Number(String(value ?? '').replace(/,/g, '').trim());
      return Number.isFinite(numeric) ? numeric : Number(fallback) || 0;
    }, value, fallback);
  }

  function formatNumeric(value, options = {}){
    return call('formatCurrencyNumericDisplay', () => String(value ?? ''), value, options);
  }

  const api = {
    storageKey:STORAGE_KEY,
    readState,
    writeState,
    resetState,
    computeRows,
    getActiveRateBook,
    readOperationalQuote,
    getCounterpartCurrency,
    normalizeCurrencyCode,
    toNumber,
    formatNumeric
  };

  if(typeof registry.define === 'function') registry.define('currency', api, { status:'baseline-adapter', source:'currency-management' });
})();
