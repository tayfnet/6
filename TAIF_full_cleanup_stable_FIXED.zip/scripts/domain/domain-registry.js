(()=>{

  const TAIF = window.TAIF || (window.TAIF = {});
  const root = TAIF.domain || (TAIF.domain = {});
  const registry = root.registry || (root.registry = {});

  function toName(value){
    return String(value ?? '').trim().replace(/[^a-z0-9-]/gi, '').toLowerCase();
  }

  function cloneMetadata(value){
    if(!value || typeof value !== 'object') return {};
    return { ...value };
  }

  function define(name, api = {}, metadata = {}){
    const safeName = toName(name);
    if(!safeName) return null;
    const safeApi = api && typeof api === 'object' ? api : {};
    const previous = registry[safeName] || {};
    const entry = {
      name:safeName,
      api:safeApi,
      metadata:{
        ...(previous.metadata && typeof previous.metadata === 'object' ? previous.metadata : {}),
        ...cloneMetadata(metadata),
        updatedAt:Date.now()
      }
    };
    registry[safeName] = entry;
    root[safeName] = safeApi;
    try{
      Object.defineProperty(safeApi, '__taifDomainName', {
        value:safeName,
        configurable:true
      });
    }catch{}
    return safeApi;
  }

  function resolve(name){
    const safeName = toName(name);
    if(!safeName) return null;
    const entry = registry[safeName];
    if(entry && entry.api && typeof entry.api === 'object') return entry.api;
    const direct = root[safeName];
    return direct && typeof direct === 'object' ? direct : null;
  }

  function has(name){
    return !!resolve(name);
  }

  function list(){
    return Object.keys(registry)
      .sort()
      .map((name) => ({
        name,
        metadata:{ ...(registry[name]?.metadata || {}) },
        methods:Object.keys(registry[name]?.api || {}).filter((key) => typeof registry[name].api[key] === 'function').sort()
      }));
  }

  function readState(name, fallback = null){
    const api = resolve(name);
    if(!api || typeof api.readState !== 'function') return fallback;
    try{
      const value = api.readState();
      return value == null ? fallback : value;
    }catch{
      return fallback;
    }
  }

  function writeState(name, nextState, options = {}){
    const api = resolve(name);
    if(!api || typeof api.writeState !== 'function') return nextState;
    try{
      return api.writeState(nextState, options);
    }catch{
      return nextState;
    }
  }

  function notify(name, eventName, detail = {}, options = {}){
    const safeEvent = String(eventName || '').trim();
    if(!safeEvent) return false;
    const safeDomain = toName(name);
    const safeDetail = detail && typeof detail === 'object' ? detail : {};
    const events = TAIF.core && TAIF.core.events;
    if(events && typeof events.emit === 'function'){
      return events.emit(safeEvent, { domain:safeDomain, ...safeDetail }, { ...(options && typeof options === 'object' ? options : {}), domain:safeDomain, source:'domain-registry' });
    }
    if(typeof window === 'undefined' || typeof window.dispatchEvent !== 'function') return false;
    try{
      window.dispatchEvent(new CustomEvent(safeEvent, {
        detail:{ domain:safeDomain, ...safeDetail }
      }));
      return true;
    }catch{
      return false;
    }
  }

  root.define = define;
  root.resolve = resolve;
  root.has = has;
  root.list = list;
  root.readState = readState;
  root.writeState = writeState;
  root.notify = notify;
})();
