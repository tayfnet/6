(()=>{
    const TAIF = window.TAIF || (window.TAIF = {});
    TAIF.__shared = TAIF.__shared || {};
    const root = document.documentElement;
    const shellStorageKey = window.TAIF?.core?.storageKeys?.shell || 'taif-shell-state-v3';
    const key = root.dataset.key || shellStorageKey;
    const fallbackStore = window.TAIF?.__memoryStorage instanceof Map ? window.TAIF.__memoryStorage : null;

    const storageScopeHelpers = TAIF.__shared.storageScope || (TAIF.__shared.storageScope = {
      normalizeStorageScopeSeed(value){
        return String(value ?? '')
          .trim()
          .replace(/^file:\/*/i, '')
          .replace(/[?#].*$/, '')
          .replace(/\\/g, '/')
          .replace(/\/+/g, '/')
          .toLowerCase();
      },
      hashStorageScopeSeed(value){
        let hash = 2166136261;
        for(let index = 0; index < value.length; index += 1){
          hash ^= value.charCodeAt(index);
          hash = Math.imul(hash, 16777619);
        }
        return (hash >>> 0).toString(36);
      }
    });
    const { normalizeStorageScopeSeed, hashStorageScopeSeed } = storageScopeHelpers;

    function resolveScopedKey(rawKey){
      const safeKey = String(rawKey || '').trim();
      if(!safeKey) return '';
      const explicitScope = String(root?.dataset?.storageScope || '').trim();
      const locationScope = [
        window.location?.protocol || '',
        window.location?.host || '',
        window.location?.pathname || ''
      ].filter(Boolean).join('|');
      const seed = normalizeStorageScopeSeed(explicitScope || locationScope || 'default');
      return `taif:${hashStorageScopeSeed(seed)}::${safeKey}`;
    }

    function hasExplicitStorageScope(){
      return !!String(root?.dataset?.storageScope || '').trim();
    }

    function scoreStoredValue(rawValue){
      if(rawValue == null) return 0;
      try{
        const parsed = JSON.parse(rawValue);
        if(Array.isArray(parsed)){
          return parsed.reduce((maxScore, item) => {
            const updatedAt = Number(item?.updatedAt) || Number(item?.createdAt) || 0;
            return updatedAt > maxScore ? updatedAt : maxScore;
          }, 0);
        }
        if(parsed && typeof parsed === 'object'){
          return Number(parsed.updatedAt) || Number(parsed.createdAt) || 0;
        }
      }catch{}
      return 0;
    }

    function readMigratedScopedValueFromStore(store, scopedKey, legacyKey){
      if(!hasExplicitStorageScope()) return '';
      if(!store || typeof store.getItem !== 'function' || typeof store.length !== 'number' || typeof store.key !== 'function') return '';
      const suffix = `::${legacyKey}`;
      let bestValue = '';
      let bestScore = -1;
      for(let index = 0; index < store.length; index += 1){
        const candidateKey = store.key(index);
        if(typeof candidateKey !== 'string' || !candidateKey || candidateKey === scopedKey) continue;
        if(!candidateKey.endsWith(suffix)) continue;
        const candidateValue = store.getItem(candidateKey);
        if(candidateValue == null) continue;
        const candidateScore = scoreStoredValue(candidateValue);
        if(candidateScore >= bestScore){
          bestScore = candidateScore;
          bestValue = candidateValue;
        }
      }
      if(bestValue){
        try{
          if(typeof store.setItem === 'function') store.setItem(scopedKey, bestValue);
        }catch{}
      }
      return bestValue;
    }

    function readMigratedScopedValueFromMemory(store, scopedKey, legacyKey){
      if(!hasExplicitStorageScope()) return '';
      if(!(store instanceof Map)) return '';
      const suffix = `::${legacyKey}`;
      let bestValue = '';
      let bestScore = -1;
      store.forEach((candidateValue, candidateKey) => {
        if(typeof candidateKey !== 'string' || !candidateKey || candidateKey === scopedKey) return;
        if(!candidateKey.endsWith(suffix)) return;
        const candidateScore = scoreStoredValue(candidateValue);
        if(candidateScore >= bestScore){
          bestScore = candidateScore;
          bestValue = candidateValue;
        }
      });
      if(bestValue){
        store.set(scopedKey, bestValue);
      }
      return bestValue;
    }

    function readFromStore(store, scopedKey, legacyKey){
      if(!store || typeof store.getItem !== 'function') return '';
      const scopedValue = store.getItem(scopedKey);
      if(scopedValue != null) return scopedValue;
      const legacyValue = store.getItem(legacyKey);
      if(legacyValue != null){
        try{
          if(typeof store.setItem === 'function') store.setItem(scopedKey, legacyValue);
        }catch{}
        return legacyValue;
      }
      return readMigratedScopedValueFromStore(store, scopedKey, legacyKey);
    }

    function readRaw(){
      const scopedKey = resolveScopedKey(key);
      try{
        if(window.localStorage){
          const value = readFromStore(window.localStorage, scopedKey, key);
          if(value) return value;
        }
      }catch{}

      if(fallbackStore){
        const scopedValue = fallbackStore.get(scopedKey);
        if(scopedValue != null) return scopedValue;
        const legacyValue = fallbackStore.get(key);
        if(legacyValue != null){
          fallbackStore.set(scopedKey, legacyValue);
          return legacyValue;
        }
        const migratedValue = readMigratedScopedValueFromMemory(fallbackStore, scopedKey, key);
        if(migratedValue) return migratedValue;
      }

      return '';
    }

    try{
      const raw = readRaw();
      if(!raw) return;
      const state = JSON.parse(raw) || {};
      root.dataset.sidebar = state.sidebarCollapsed ? 'collapsed' : 'open';
      const savedView = typeof state.activeView === 'string' ? state.activeView.trim() : '';
      if(savedView) root.dataset.view = savedView;
    }catch{}
  })();
