(()=>{
  const TAIF = window.TAIF;
  let renderToken = 0;
  let renderWatchdogId = 0;

  const TRANSIENT_VIEW_ARTIFACT_SELECTORS = Object.freeze([
    '.entries-window-layer',
    '.entries-modal-backdrop',
    '.entries-modal',
    '.entries-toast',
    '.entries-account-search__popover',
    '.entries-voucher-choice-popover',
    '.entries-voucher-date__popover',
    '.sales-purchase-window-layer',
    '.sales-purchase-modal-backdrop',
    '.sales-purchase-modal-window',
    '.sales-purchase-currency-popover',
    '.sales-purchase-top-field__popover',
    '.coa-window-layer',
    '.coa-modal-backdrop',
    '.coa-choice-popover',
    '.coa-toast',
    '.taif-currency-management-window-layer',
    '.taif-currency-management-modal-backdrop',
    '.taif-currency-management-modal',
    '.currency-management-counterpart-popover',
    '.currency-management-method-popover',
    '.currency-management-flag-popover',
    '.currency-management-name-autocomplete__popover',
    '.currency-management-toast',
    '.cash-boxes-window-layer',
    '.cash-boxes-modal-backdrop',
    '.cash-boxes-modal-window',
    '.cash-boxes-modal',
    '.customer-card-phone-country__popover',
    '.general-ledger-date__popover',
    '.taif-factory-reset-backdrop',
    '.taif-factory-reset-modal',
    '[data-taif-dropdown-popup="true"]',
    '[data-owner-view]'
  ]);
  const TRANSIENT_VIEW_ARTIFACT_SELECTOR = TRANSIENT_VIEW_ARTIFACT_SELECTORS.join(', ');

  function clearRenderWatchdog(){
    if(!renderWatchdogId) return;
    try{ window.clearTimeout(renderWatchdogId); }catch{}
    renderWatchdogId = 0;
  }

  function setPanelRenderState(panel, viewId, isBusy){
    if(!(panel instanceof HTMLElement)) return;
    panel.dataset.renderingView = isBusy ? String(viewId || '').trim() : '';
    panel.setAttribute('aria-busy', isBusy ? 'true' : 'false');
  }

  function setActiveViewMarkers(viewId){
    const safeViewId = String(viewId || '').trim();
    try{ document.documentElement.dataset.activeView = safeViewId; }catch{}
    try{
      if(document.body) document.body.dataset.activeView = safeViewId;
    }catch{}
  }

  function renderLoadingState(panel, viewId){
    if(!(panel instanceof HTMLElement)) return;
    panel.innerHTML = `
      <div class="panel__status panel__status--loading" role="status" aria-live="polite">
        <div class="panel__status-badge">جارٍ التحميل</div>
        <div class="panel__status-title">${TAIF.core.utils.escapeHtml(String(viewId || ''))}</div>
      </div>
    `;
  }

  function renderErrorState(panel, viewId, message){
    if(!(panel instanceof HTMLElement)) return;
    panel.dataset.view = String(viewId || '').trim();
    panel.innerHTML = `
      <div class="panel__status panel__status--error" role="alert">
        <div class="panel__status-badge">تعذر التحميل</div>
        <div class="panel__status-title">${TAIF.core.utils.escapeHtml(String(message || 'حدث خطأ غير متوقع.'))}</div>
      </div>
    `;
  }

  function getNodeDepth(node){
    let depth = 0;
    let current = node;
    while(current && current.parentElement){
      depth += 1;
      current = current.parentElement;
    }
    return depth;
  }

  function runRegisteredViewCleanup(panel, nextViewId){
    const cleanupRegistry = TAIF?.registry?.viewCleanup;
    if(!cleanupRegistry || typeof cleanupRegistry !== 'object') return;

    Object.entries(cleanupRegistry).forEach(([registeredViewId, cleanup]) => {
      if(typeof cleanup !== 'function') return;
      try{
        cleanup({
          viewId: String(registeredViewId || '').trim(),
          panel,
          nextViewId,
          reason: 'view-transition-isolation'
        });
      }catch{}
    });
  }

  function runNodeCleanup(node, context = {}){
    if(!(node instanceof HTMLElement)) return;
    const sharedCleanup = TAIF?.core?.utils?.runOwnedNodeCleanup;
    if(typeof sharedCleanup === 'function'){
      try{ sharedCleanup(node, context); }catch{}
      return;
    }

    const cleanup = node.__cleanup;
    if(typeof cleanup === 'function'){
      try{ node.__cleanup = null; }catch{}
      try{ cleanup(context); }catch{}
    }
  }

  function resetDocumentInteractionState(){
    if(document.body?.classList){
      Array.from(document.body.classList).forEach((className) => {
        if(/--dragging-window$/i.test(String(className || ''))) document.body.classList.remove(className);
      });
    }

    const selection = typeof window.getSelection === 'function' ? window.getSelection() : null;
    if(selection && selection.rangeCount){
      try{ selection.removeAllRanges(); }catch{}
    }
  }

  function clearTransientViewArtifacts(options = {}){
    if(typeof document === 'undefined') return;

    const safeOptions = options && typeof options === 'object' ? options : {};
    const cleanupOwnedArtifacts = TAIF?.core?.utils?.cleanupOwnedRuntimeArtifacts;
    const hasOwnershipCleaner = typeof cleanupOwnedArtifacts === 'function';
    const ownerView = String(safeOptions.ownerView || '').trim();
    const nextViewId = String(safeOptions.nextViewId || '').trim();
    const reason = String(safeOptions.reason || 'view-transition-artifact-cleanup').trim();

    if(hasOwnershipCleaner){
      try{
        cleanupOwnedArtifacts({
          ownerView,
          exceptOwnerView: nextViewId,
          includeAllOwners: !ownerView,
          reason
        });
      }catch{}
    }

    const nodes = Array.from(new Set(
      Array.from(document.querySelectorAll(TRANSIENT_VIEW_ARTIFACT_SELECTOR))
        .filter((node) => node instanceof HTMLElement)
        .filter((node) => {
          if(hasOwnershipCleaner && node.matches('[data-owner-view], [data-taif-runtime-artifact="true"]')) return false;
          const nodeOwner = String(node.getAttribute('data-owner-view') || node.dataset?.ownerView || '').trim();
          if(nextViewId && nodeOwner === nextViewId) return false;
          return true;
        })
    )).sort((left, right) => getNodeDepth(right) - getNodeDepth(left));

    nodes.forEach((node) => {
      if(!(node instanceof HTMLElement) || !node.isConnected) return;
      runNodeCleanup(node, { reason, ownerView, nextViewId });
      try{ node.remove(); }catch{}
    });

    resetDocumentInteractionState();
  }

  function performImmediateTransitionCleanup(panel, previousViewId, nextViewId){
    const safePreviousViewId = String(previousViewId || '').trim();
    const safeNextViewId = String(nextViewId || '').trim();
    if(!safePreviousViewId || safePreviousViewId === safeNextViewId) return;

    try{
      TAIF.runViewCleanup?.(safePreviousViewId, {
        panel,
        nextViewId: safeNextViewId,
        reason: 'view-transition-start'
      });
    }catch{}

    clearTransientViewArtifacts({ ownerView: safePreviousViewId, nextViewId: safeNextViewId, reason: 'view-transition-start' });
  }

  function finalizeRender(panel, viewId, renderer, previousViewId, activeToken){
    if(activeToken !== renderToken || !(panel instanceof HTMLElement)) return;
    runRegisteredViewCleanup(panel, viewId);
    clearTransientViewArtifacts({ reason: 'pre-render-reset' });
    panel.innerHTML = '';
    panel.dataset.view = String(viewId || '').trim();
    panel.dataset.renderedView = '';
    if(typeof renderer === 'function'){
      renderer({ panel, viewId, previousViewId });
    }
    if(TAIF?.ui?.windowSystem && typeof TAIF.ui.windowSystem.normalizeRoot === 'function'){
      try{ TAIF.ui.windowSystem.normalizeRoot(panel, { ownerView:viewId, source:'render-active-finalize' }); }catch{}
    }
    if(TAIF?.ui?.buttonSystem && typeof TAIF.ui.buttonSystem.normalizeRoot === 'function'){
      try{ TAIF.ui.buttonSystem.normalizeRoot(panel, { ownerView:viewId, source:'render-active-finalize' }); }catch{}
    }
    if(TAIF?.ui?.fieldSystem && typeof TAIF.ui.fieldSystem.normalizeRoot === 'function'){
      try{ TAIF.ui.fieldSystem.normalizeRoot(panel, { ownerView:viewId, source:'render-active-finalize' }); }catch{}
    }
    if(TAIF?.ui?.pickerSystem && typeof TAIF.ui.pickerSystem.normalizeRoot === 'function'){
      try{ TAIF.ui.pickerSystem.normalizeRoot(panel, { ownerView:viewId }); }catch{}
    }
    if(TAIF?.ui?.flow && typeof TAIF.ui.flow.normalizeRoot === 'function'){
      try{ TAIF.ui.flow.normalizeRoot(panel); }catch{}
    }
    panel.dataset.renderedView = viewId;
    setActiveViewMarkers(viewId);
    setPanelRenderState(panel, viewId, false);
    clearRenderWatchdog();
  }

  TAIF.views.renderActive = function(panel, viewId){
    const activeToken = ++renderToken;
    const previousViewId = String(panel?.dataset.renderedView || panel?.dataset.view || '').trim();
    const safeViewId = String(viewId || '').trim();
    const hasMountedView = panel instanceof HTMLElement
      && !!previousViewId
      && !panel.querySelector('.panel__status--loading');
    const isViewTransition = !!previousViewId && previousViewId !== safeViewId;

    clearRenderWatchdog();

    if(isViewTransition){
      performImmediateTransitionCleanup(panel, previousViewId, safeViewId);
    }

    if(panel instanceof HTMLElement){
      setPanelRenderState(panel, viewId, true);
      if(!hasMountedView){
        panel.dataset.renderedView = '';
        panel.dataset.view = '';
        renderLoadingState(panel, viewId);
      }
    }

    renderWatchdogId = window.setTimeout(() => {
      if(activeToken !== renderToken || !(panel instanceof HTMLElement)) return;
      if(String(panel.dataset.renderedView || '').trim() === String(viewId || '').trim()) return;

      if(!hasMountedView){
        renderErrorState(panel, viewId, 'استغرق تحميل مكونات العرض وقتًا أطول من المتوقع.');
      }

      setPanelRenderState(panel, viewId, false);
      clearRenderWatchdog();
    }, 4000);

    Promise.resolve(typeof TAIF.ui.ensureViewAssets === 'function' ? TAIF.ui.ensureViewAssets(viewId) : null)
      .then(() => {
        const renderer = TAIF.registry.viewRenderers[viewId];
        if(typeof renderer !== 'function'){
          if(activeToken !== renderToken || !(panel instanceof HTMLElement)) return;
          renderErrorState(panel, viewId, `لم يتم تسجيل واجهة العرض: ${String(viewId || '').trim()}`);
          setPanelRenderState(panel, viewId, false);
          clearRenderWatchdog();
          return;
        }
        finalizeRender(panel, viewId, renderer, previousViewId, activeToken);
      })
      .catch((error) => {
        if(activeToken !== renderToken || !(panel instanceof HTMLElement)) return;
        if(!hasMountedView){
          renderErrorState(panel, viewId, error && error.message ? error.message : 'فشل تحميل مكونات العرض.');
        }
        setPanelRenderState(panel, viewId, false);
        clearRenderWatchdog();
      });
  };
})();
